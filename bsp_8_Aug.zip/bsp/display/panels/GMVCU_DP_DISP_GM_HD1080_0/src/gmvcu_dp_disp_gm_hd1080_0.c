/*! \file */
/*
   ===========================================================================

FILE:  gmvcu_dp_disp_gm_hd1080.c

Description: RBAC implementation for a GM hd1080 panel driver instance.

$File: $

===========================================================================
Copyright (c) 2018-2020 Qualcomm Technologies, Inc.
All Rights Reserved.
Qualcomm Technologies Proprietary and Confidential.
Copyright (c) 2019 Bosch Automotive Products (Suzhou) Co.,Ltd(RBAC).
All Rights Reserved.
RBAC Proprietary and Confidential.
===========================================================================
*/

/* -----------------------------------------------------------------------
 ** Includes
 ** ----------------------------------------------------------------------- */
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "qdi_types.h"
#include "qdi_oem.h"
#include "mdss_osal.h"
#include "qdi_oem.h"
#include "mdss_drvconfig.h"
#include "mdss_log.h"
#include "dp_host.h"
#include "bridgechip.h"

/* -----------------------------------------------------------------------------
 ** Structure Types
 ** ---------------------------------------------------------------------------*/
static MDSS_DrvConfig_PanelConfigType gsPanelConfig =
{
   .eDisplayId          = QDI_DISPLAY_PRIMARY,
   .bIsDisplayPresent   = TRUE,
   .sVideoTiming =
   {
      .ePixelFormatType = QDI_PIXEL_FORMAT_RGB_888_24BPP,
      .uVisWidth        = 1920,
      .uVisHeight       = 1080,
      .uPixelFreqInHz   = 148500000,
      .uHsyncBackPorch  = 148,
      .uHsyncFrontPorch = 88,
      .uVsyncBackPorch  = 36,
      .uVsyncFrontPorch = 4,
      .uHsyncWidth      = 44,
      .uVsyncWidth      = 5,
      .bHsyncPolarity   = FALSE,
      .bVsyncPolarity   = FALSE,
      .bDEPolarity      = FALSE,
   },
   .unIntfParams =
   {
      .sDPConfigParams =
      {
         .cBridgeChipID = "bridge_ds90uh983q_ub948q_0",
         .uMapSelect    = 0,
         .bHPDSupport   = 1,
         .uLinkRate     = 810000,
         .uNumOfLanes   = 4,
      },
   },
   .uNumOfVideoModes    = 0,
   .uNumOfAudioModes    = 0,
   .uNumOfDispNodes     = 0,
   .pVideoModeList      = NULL,
   .pAudioModeList      = NULL,
   .pDispNodeList       = NULL,
};

/* Placeholder struct until we move to the bridge chip server */
typedef struct
{
   bool32 bIsBridgeChipPresent;
   BridgeChip_HandleType hBridgeChip;
} gmvcu_dp_disp_gm_hd1080_BridgeChipInfo;

/*
 * Internal structure for holding DP command data
 */
typedef struct {
   QDI_HandleType                  hOemHandle;
   QDI_Display_IDType              eDisplayId;                                            /**< Physical display ID                                 */
   QDI_HandleType                  hDPHandle;                                             /**< DP device handle for DP Host driver                 */
   uint32                          uLastHostErrorCode;                                    /**< DP last host error code for packet to peripheral    */
   uint32                          uLastPanelErrorCode;                                   /**< DP last panel error code for packet from peripheral */
   uint32                          uCmdBufSize;                                           /**< DP command buffer size                              */
   bool32                          bDPPowerOn;                                            /**< DP component has been powered on                    */
   uint32                          uTotalModes;                                           /**< Total number of supported modes                     */
   uint32                          uModeIndex;                                            /**< Current mode                                        */
   uint32                          uMaxNumReAuthentication;                               /**< Maximum number of times to reattempt authentication */
   uint32                          uLaneMapping;                                          /**< Defines Physical to logic lane mapping              */
   MDSS_DrvConfig_PanelConfigType  sPanelConfig;
   bool32                          bForceModeXML;                                         /**< Force mode which is configured in XML               */
   bool32                          bForceDPCD;                                            /**< Force DPCD parameters configured in XML             */
   bool32                          bDualPixelMode;                                        /**< DP Controller and PHY supports dual pixel mode      */
} DPDriverConfigType;

typedef struct
{
   QDI_Display_IDType eDeviceId;
   /*TODO: Replace with BridgeChip_HandleType when we move to the bridge chip server*/
   gmvcu_dp_disp_gm_hd1080_BridgeChipInfo sBridgeChipInfo;
   MDSS_DrvConfig_PanelConfigType *psPanelConfig;
   QDI_HandleType hDCHandle; /**< Logic Handle for DC */
   QDI_HandleType hDSIHandle;
   DP_HandleType hDisplayHandle;
   DPDriverConfigType *psDPDriverConfig;
} gmvcu_dp_disp_gm_hd1080_Ctx;

/* -----------------------------------------------------------------------
 ** Global variables
 ** ----------------------------------------------------------------------- */
DPDriverConfigType gDPDriverConfig;

static gmvcu_dp_disp_gm_hd1080_Ctx gPanelDrvCtx;

/* LUT to convert the DP_Status to MDP_Status */
QDI_ErrorType DPStatusToMDPStatus[DP_STATUS_MAX] =
{
   QDI_STATUS_OK,                      //DP_STATUS_SUCCESS
   QDI_STATUS_FAILED,                  //DP_STATUS_FAIL
   QDI_STATUS_BAD_PARAM,               //DP_STATUS_FAILED_INVALID_INPUT_PARAMETER
   QDI_STATUS_TIMEOUT,                 //DP_STATUS_FAILED_TIMEOUT
   QDI_STATUS_HW_ERROR,                //DP_STATUS_FAILED_RESOURCE_FATAL_ERROR
   QDI_STATUS_NO_RESOURCES,            //DP_STATUS_FAILED_RESOURCE_FAILED
   QDI_STATUS_INVALID_STATE,           //DP_STATUS_FAILED_DRIVER_ALREADY_INITIALIZED
   QDI_STATUS_INVALID_STATE,           //DP_STATUS_FAILED_DRIVER_NOT_INITIALIZED
   QDI_STATUS_NOT_SUPPORTED,           //DP_STATUS_FAILED_NOT_SUPPORTED
   QDI_STATUS_BUFFER_TOO_SMALL,        //DP_STATUS_FAILED_PKT_LENGTH_EXCEED
   QDI_STATUS_FAILED,                  //DP_STATUS_FAILED_LINK_TRAINING
};

/* LUT to convert the DP color format to MDP color format */
QDI_PixelFormatType DPColorToMDPColor[DP_PIXEL_FORMAT_MAX] =
{
   QDI_PIXEL_FORMAT_NONE,                      //DP_PIXEL_FORMAT_NONE
   QDI_PIXEL_FORMAT_RGB_666_18BPP,             //DP_PIXEL_FORMAT_RGB_666_18BPP
   QDI_PIXEL_FORMAT_RGB_888_24BPP,             //DP_PIXEL_FORMAT_RGB_888_24BPP
   QDI_PIXEL_FORMAT_RGB_101010_30BPP,          //DP_PIXEL_FORMAT_RGB_101010_30_BPP
};

/* Table of QDI to DP connection polarity mapping */
DP_ConnectionStatusType gQDIToDPConnectionPolarityMapping [QDI_DP_CONNECTION_POLARITY_MAX] =
{
   DP_CONNECTION_STATUS_DISCONNECTED,              // QDI_DP_CONNECTION_POLARITY_DISCONNECTED
   DP_CONNECTION_POLARITY_POLARITY_DEFAULT,        // QDI_DP_CONNECTION_POLARITY_POLARITY_DEFAULT
   DP_CONNECTION_POLARITY_POLARITY_REVERSE,        // QDI_DP_CONNECTION_POLARITY_POLARITY_REVERSE
};

/* Table of QDI to DP connection pin assignment mapping */
DP_ConnectionPinAssignment gQDIToDPConnectionPinMapping [QDI_DP_CONNECTION_PINASSIGNMENT_MAX] =
{
   DP_CONNECTION_PINASSIGNMENT_INVALID,        // QDI_DP_CONNECTION_PINASSIGNMENT_INVALID
   DP_CONNECTION_PINASSIGNMENT_DFPD_A,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_A
   DP_CONNECTION_PINASSIGNMENT_DFPD_B,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_B
   DP_CONNECTION_PINASSIGNMENT_DFPD_C,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_C
   DP_CONNECTION_PINASSIGNMENT_DFPD_D,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_D
   DP_CONNECTION_PINASSIGNMENT_DFPD_E,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_E
   DP_CONNECTION_PINASSIGNMENT_DFPD_F,         // QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_F
};

/* -----------------------------------------------------------------------
 ** Macro defines
 ** ----------------------------------------------------------------------- */
#define Q16                         (16)
/* Convert an integer to a Q16.16 value. */
#define Q16_VALUE(x)                ((int32)((uint64)x<<Q16))

/* Truncate a Q16.16 value and only return the whole number portion */
#define Q16_WHOLE(x)                ((int32)(x>>16))

/* -----------------------------------------------------------------------
 ** Defines
 ** ----------------------------------------------------------------------- */
#define DP_HDCP_INTERRUPT_POLL_INTERVAL       100      // 100 ms
#define DP_HDCP_MAX_REAUTHENTICATION          10       // Maximum number of times to re-attempt authentication
#define DPDRIVER_MIN_PIXEL_CLOCK_HZ           25200000 // Minimum pixel clock for custom mode validation

#define MDSS_PANEL_LOG_ERROR(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_ERROR_INFO_TYPE, __VA_ARGS__)

#define MDSS_PANEL_LOG_CRITICAL_INFO(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_CRITICAL_INFO_TYPE, __VA_ARGS__) // MDSS_LOG_CRITICAL_INFO_TYPE

#define MDSS_PANEL_LOG_INFO(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_INFO_TYPE, __VA_ARGS__) // MDSS_LOG_CRITICAL_INFO_TYPE

#define MDSS_PANEL_LOG_WARNING(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_WARNING_INFO_TYPE, __VA_ARGS__) // MDSS_LOG_WARNING_INFO_TYPE

#define MDSS_PANEL_LOG_API_ENTER(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_API_TYPE , "ENTER: " __VA_ARGS__) // MDSS_LOG_API_TYPE

#define MDSS_PANEL_LOG_API_EXIT(...)\
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_API_TYPE  , "EXIT: " __VA_ARGS__) // MDSS_LOG_API_TYPE

#define DP_LINKFAIL_LOGGING(DEVICE_ID, BRIDGECHIP_NAME) \
do \
{ \
    FILE *f; \
    char dp_status_path[128]; \
    memset(dp_status_path, 0, sizeof(dp_status_path)); \
    sprintf (dp_status_path, "/tmp/DP_PORT_LINKFAIL_%d_%s", DEVICE_ID, BRIDGECHIP_NAME); \
    f = fopen(dp_status_path, "w+"); \
    fclose(f); \
} while(0);

/* -----------------------------------------------------------------------
 ** Local Prototypes
 ** ----------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_GetModeInfo(QDI_HandleType hOemHandle, QDI_Panel_ModeInfoType *psModeInfo, uint32 uFlags);
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_SelectMode(QDI_HandleType hOemHandle);
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_ReadXMLData(QDI_HandleType hOemHandle);

static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf, bool32 bPowerOn, uint32 uFlags);
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipInit(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf);
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipDeInit(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf);
static void Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipCallback(BridgeChip_CallbackInfoType *pCbInfo);
/* -----------------------------------------------------------------------
 ** Local functions
 ** ----------------------------------------------------------------------- */
static void Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipCallback(BridgeChip_CallbackInfoType *pCbInfo)
{
   uint32 uEventMask = 0;
   uint32 uI = 0;
   uint32 uEventId = 0;

   if (NULL == pCbInfo)
   {
      MDSS_PANEL_LOG_ERROR("pCbInfo is NULL!");
   }
   else
   {
      MDSS_PANEL_LOG_CRITICAL_INFO("Received callback, events = %x", pCbInfo->sEventInfo.uEventMask);

      uEventMask = pCbInfo->sEventInfo.uEventMask;
      /*
      * Check all error masks and their corresponding structure
      * if recovery-requiring error, signal recovery thread
      * if recovery event, signal the recovery thread to issue a power ON call
      */
      for (uI = 1, uEventId = 0; uI < (BRIDGECHIP_EVENT_ALL + 1); uI = uI << 1, uEventId++)
      {
         if (0x00 != (uEventMask & uI))
         {
            switch (uI)
            {
               case BRIDGECHIP_EVENT_REMOTE_DEVICE_INTERRUPT:
               case BRIDGECHIP_EVENT_HDCP:
               case BRIDGECHIP_EVENT_DEVICE_RECOVERY:
               case BRIDGECHIP_EVENT_PLL:
               case BRIDGECHIP_EVENT_HPD:
               {
                  /* Nothing to do */
                  break;
               }
               default:
               {
                  /* Should never reach here */
                  MDSS_PANEL_LOG_WARNING("Unsupported interrupt (%x) - should not reach here", uI);
                  continue;
               }
            }
         }
      }
   }
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipInit()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipInit function initializes the bridge chip.
 *
 * \param [in]  psSelf - Pointer to panel driver context
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipInit(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf)
{
   QDI_Status eRetStatus = QDI_STATUS_SUCCESS;
   BridgeChip_HandleType hDevice = NULL;
   BridgeChip_StatusType eBCStatus = BRIDGECHIP_STATUS_SUCCESS;
   BridgeChip_OpenParamsType sOpenParams;
   BridgeChip_CallbackRegisterInfo sCbRegInfo;

   if ((!MDSS_OSAL_StrCmp(psSelf->psPanelConfig->unIntfParams.sDPConfigParams.cBridgeChipID, "NATIVE"))
            || (FALSE == psSelf->psPanelConfig->bIsDisplayPresent))
   {
      /* NATIVE indicates that there is no bridge chip present */
      psSelf->sBridgeChipInfo.bIsBridgeChipPresent = FALSE;
      MDSS_PANEL_LOG_CRITICAL_INFO("Using NATIVE DP interface");
   }
   else
   {
      MDSS_PANEL_LOG_ERROR("confirmed not NATIVE");
      MDSS_OSAL_MemSet((char *) &sOpenParams, 0x00, sizeof(sOpenParams));
      MDSS_OSAL_StrCpy(sOpenParams.iBridgeChipID,
      BRIDGECHIP_MAX_CHIP_ID_STRING_LENGTH, psSelf->psPanelConfig->unIntfParams.sDPConfigParams.cBridgeChipID);
      sOpenParams.uVersion = BRIDGECHIP_API_VERSION;
      MDSS_PANEL_LOG_ERROR("Open bridgechip device");
      eBCStatus = BridgeChip_Device_Open(&sOpenParams, &hDevice, 0x00);

      if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
      {
         MDSS_PANEL_LOG_ERROR("BridgeChip_device_open failed (%d)", eBCStatus);
         psSelf->sBridgeChipInfo.bIsBridgeChipPresent = FALSE;
         eRetStatus = QDI_STATUS_FAILED;
      }
      else
      {
         MDSS_PANEL_LOG_CRITICAL_INFO("Using %s bridge chip for DP interface", sOpenParams.iBridgeChipID);
         psSelf->sBridgeChipInfo.bIsBridgeChipPresent = TRUE;
         psSelf->sBridgeChipInfo.hBridgeChip = hDevice;

         MDSS_OSAL_MemSet((char *) &sCbRegInfo, 0x00, sizeof(BridgeChip_CallbackRegisterInfo));
         sCbRegInfo.pCallback = Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipCallback;
         sCbRegInfo.uEventMask = (BRIDGECHIP_EVENT_HDCP | BRIDGECHIP_EVENT_HPD | BRIDGECHIP_EVENT_PLL
                    | BRIDGECHIP_EVENT_DEVICE_RECOVERY);

         MDSS_PANEL_LOG_ERROR("Bridge chip register event callback");
         eBCStatus = BridgeChip_Register_EventCallback(psSelf->sBridgeChipInfo.hBridgeChip, &sCbRegInfo);

         if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
         {
            MDSS_PANEL_LOG_ERROR("Failed to register events, eStatus=%u", eBCStatus);
         }
      }
   }

   return eRetStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_1_BridgeChipDeinit()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dp_disp_gm_hd1080_1_BridgeChipDeinit function performs the necessary
 *   cleanup operations to deinitialize the bridge chip..
 *
 * \param [in]  psSelf - Pointer to panel driver context
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipDeInit(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf)
{
   QDI_Status eRetStatus = QDI_STATUS_SUCCESS;
   BridgeChip_StatusType eBCStatus = BRIDGECHIP_STATUS_SUCCESS;
   BridgeChip_PropertyDataType sPropData;
   BridgeChip_CallbackRegisterInfo sCbRegInfo;

   if (psSelf->sBridgeChipInfo.bIsBridgeChipPresent)
   {
      MDSS_OSAL_MemSet((char *) &sPropData, 0x00, sizeof(BridgeChip_PropertyDataType));
      MDSS_OSAL_MemSet((char *) &sCbRegInfo, 0x00, sizeof(BridgeChip_CallbackRegisterInfo));

      /* De-register by providing a NULL CB function */
      eBCStatus = BridgeChip_Register_EventCallback(psSelf->sBridgeChipInfo.hBridgeChip, &sCbRegInfo);
      if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
      {
         MDSS_PANEL_LOG_ERROR("failed to de-register callbacks, eStatus=%u", eBCStatus);
         eRetStatus = QDI_STATUS_FAILED;
      }

      eBCStatus = BridgeChip_Device_Close(psSelf->sBridgeChipInfo.hBridgeChip, 0x00);
      if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
      {
         MDSS_PANEL_LOG_ERROR("BridgeChip_Device_Close failed (%d)", eBCStatus);
         eRetStatus = QDI_STATUS_FAILED;
      }
   }
   return eRetStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower function powers ON/OFF
 *   the bridge chip.
 *
 * \param [in]  psSelf   - Pointer to panel driver context
 * \param [in]  bPowerOn - Power ON/OFF boolean
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower(gmvcu_dp_disp_gm_hd1080_Ctx *psSelf, bool32 bPowerOn,
                                                            uint32 uFlags)
{
   QDI_Status eQdiStatus = QDI_STATUS_FAILED;
   BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
   BridgeChip_PropertyDataType sPropData;

   MDSS_PANEL_LOG_CRITICAL_INFO("bPowerOn=%d, uFlags=0x%x", bPowerOn, uFlags);

   MDSS_OSAL_MemSet((char *) &sPropData, 0x00, sizeof(BridgeChip_PropertyDataType));
   sPropData.bPowerOn = bPowerOn;
   eStatus = BridgeChip_Device_SetProperty(psSelf->sBridgeChipInfo.hBridgeChip, BRIDGECHIP_PROPERTY_POWER, &sPropData,
             uFlags);

   if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
   {
      MDSS_PANEL_LOG_ERROR("setProperty(BRIDGECHIP_PROPERTY_POWER=%d) failed", bPowerOn);
   }
   else
   {
      eStatus = BridgeChip_Device_Commit(psSelf->sBridgeChipInfo.hBridgeChip, 0x00);
      if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
      {
         MDSS_PANEL_LOG_ERROR("bridge chip commit failed");
      }
      else
      {
         eQdiStatus = QDI_STATUS_OK;
      }
   }

   return eQdiStatus;
}
/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: GetStreamID()
 **
 ** DESCRIPTION:
 **   Map QDI_Display_IDType to DP_MSTStreamIDType
 **
 *//* -------------------------------------------------------------------- */
static DP_MSTStreamIDType GetStreamID(QDI_Display_IDType eDisplayId)
{
   DP_MSTStreamIDType eStreamID = DP_MST_STREAM_ID_0;

   switch (eDisplayId)
   {
      case QDI_DISPLAY_EXTERNAL2:
      case QDI_DISPLAY_EXTERNAL4:
      case QDI_DISPLAY_EXTERNAL6:
         eStreamID = DP_MST_STREAM_ID_1;
         break;
      default:
         break;
   }

   return eStreamID;
}


/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: GetDPDeviceID()
 **
 ** DESCRIPTION:
 **   Map QDI_Display_IDType to DP_DeviceIDType
 **
 *//* -------------------------------------------------------------------- */
static DP_DeviceIDType GetDPDeviceID(QDI_Display_IDType eDisplayId)
{
   DP_DeviceIDType         eDeviceID  = DP_DEVICE_ID_NONE;

   switch (eDisplayId)
   {
      // TODO: Remap this for Poipu
      case QDI_DISPLAY_PRIMARY:
         eDeviceID = DP_DEVICE_ID_EDP;
         break;
      case QDI_DISPLAY_EXTERNAL:
      case QDI_DISPLAY_THIRD:
         eDeviceID = DP_DEVICE_ID_ALT_MODE_0;
         break;
      default:
         break;
   }

   return eDeviceID;
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: GetDPConnector()
 **
 ** DESCRIPTION:
 **   Map QDI_Display_IDType to QDI_DisplayConnectType
 **
 *//* -------------------------------------------------------------------- */
static QDI_DisplayConnectType GetDPConnector(QDI_Display_IDType eDisplayId)
{
   QDI_DisplayConnectType ePhysConnect = QDI_DISPLAY_CONNECT_NONE;

   switch (eDisplayId)
   {
      // TODO: Remap this for Poipu
      case QDI_DISPLAY_PRIMARY:
         ePhysConnect = QDI_DISPLAY_CONNECT_EDP;
         break;
      case QDI_DISPLAY_EXTERNAL:
      case QDI_DISPLAY_THIRD:
         ePhysConnect = QDI_DISPLAY_CONNECT_DP;
         break;
      case QDI_DISPLAY_EXTERNAL2:
      case QDI_DISPLAY_EXTERNAL3:
         ePhysConnect = QDI_DISPLAY_CONNECT_DP_ALT_MODE;
         break;
      default:
         break;
   }

   return ePhysConnect;
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: GetChannelMapping
 **
 ** DESCRIPTION:
 **   Map uChannelMap to HAL_DP_LaneMapType
 **
 *//* -------------------------------------------------------------------- */
static HAL_DP_LaneMapType GetChannelMapping(uint32 uChannelMap)
{
   HAL_DP_LaneMapType eRetVal = HAL_DP_LANEMAP_TYPE_NONE;

   switch (uChannelMap)
   {
      case 0123:
         eRetVal = HAL_DP_LANEMAP_TYPE_0123;
         break;
      case 0132:
         eRetVal = HAL_DP_LANEMAP_TYPE_0132;
         break;
      case 0213:
         eRetVal = HAL_DP_LANEMAP_TYPE_0213;
         break;
      case 0231:
         eRetVal = HAL_DP_LANEMAP_TYPE_0231;
         break;
      case 0312:
         eRetVal = HAL_DP_LANEMAP_TYPE_0312;
         break;
      case 0321:
         eRetVal = HAL_DP_LANEMAP_TYPE_0321;
         break;
      case 1023:
         eRetVal = HAL_DP_LANEMAP_TYPE_1023;
         break;
      case 1032:
         eRetVal = HAL_DP_LANEMAP_TYPE_1032;
         break;
      case 1203:
         eRetVal = HAL_DP_LANEMAP_TYPE_1203;
         break;
      case 1230:
         eRetVal = HAL_DP_LANEMAP_TYPE_1230;
         break;
      case 1302:
         eRetVal = HAL_DP_LANEMAP_TYPE_1302;
         break;
      case 1320:
         eRetVal = HAL_DP_LANEMAP_TYPE_1320;
         break;
      case 2013:
         eRetVal = HAL_DP_LANEMAP_TYPE_2013;
         break;
      case 2031:
         eRetVal = HAL_DP_LANEMAP_TYPE_2031;
         break;
      case 2103:
         eRetVal = HAL_DP_LANEMAP_TYPE_2103;
         break;
      case 2130:
         eRetVal = HAL_DP_LANEMAP_TYPE_2130;
         break;
      case 2301:
         eRetVal = HAL_DP_LANEMAP_TYPE_2301;
         break;
      case 2310:
         eRetVal = HAL_DP_LANEMAP_TYPE_2310;
         break;
      case 3012:
         eRetVal = HAL_DP_LANEMAP_TYPE_3012;
         break;
      case 3021:
         eRetVal = HAL_DP_LANEMAP_TYPE_3021;
         break;
      case 3102:
         eRetVal = HAL_DP_LANEMAP_TYPE_3102;
         break;
      case 3120:
         eRetVal = HAL_DP_LANEMAP_TYPE_3120;
         break;
      case 3201:
         eRetVal = HAL_DP_LANEMAP_TYPE_3201;
         break;
      case 3210:
         eRetVal = HAL_DP_LANEMAP_TYPE_3210;
         break;
      default:
         eRetVal = HAL_DP_LANEMAP_TYPE_0123;
         break;
   }

   return eRetVal;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: SetupOpenConfig()
 **
 ** DESCRIPTION:
 **    Setup the config for DP_Host_Open
 **
 -------------------------------------------------------------------- */
static void Panel_gmvcu_dp_disp_gm_hd1080_SetupOpenConfig(QDI_Display_IDType eDisplayId, DP_HostOpenConfigType *pOpenConfig)
{
   DPDriverConfigType      *pDPConfig    = &gDPDriverConfig;

   if (NULL == pOpenConfig)
   {
      MDSS_PANEL_LOG_ERROR("Invalid input ");
   }
   else
   {
      QDI_DP_ConnectionPolarityType  eConnectionPolarity = QDI_DP_CONNECTION_POLARITY_POLARITY_REVERSE;
      QDI_DP_ConnectionPinAssignment ePinAssignement     = QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_A;

      /* Initialize the DP open context data */
      MDSS_OSAL_MemZero((char *)pOpenConfig, sizeof(DP_HostOpenConfigType));

      /* Save DP displayID */
      pOpenConfig->eDeviceID           = GetDPDeviceID(eDisplayId);
      pOpenConfig->bSkipHotPlugDetect  = TRUE;            // Skip GPIO based HPD
      pOpenConfig->bReadDPCD           = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.bReadDPCD;
      pOpenConfig->bReadEDID           = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.bReadEDID;
      pOpenConfig->bHPDActiveLow       = TRUE;
      pOpenConfig->uPowerupWaitinMs    = 10;
      pOpenConfig->uMaxAuxRetry        = 5;
      pOpenConfig->uLaneSwingLevel     = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.uVoltageSwingLevel;
      pOpenConfig->uPreemphasisLevel   = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.uPreEmphasisLevel;
      pOpenConfig->bEnableSSCMode      = TRUE;
      pOpenConfig->eConnectionPolarity = gQDIToDPConnectionPolarityMapping[eConnectionPolarity];
      pOpenConfig->ePinAssignment      = gQDIToDPConnectionPinMapping[ePinAssignement];
      pOpenConfig->eCapabilityMask     = DP_CAPS_NONE;
      pOpenConfig->bAuxUsePolling      = TRUE;
      pOpenConfig->eStreamId           = GetStreamID(eDisplayId);
   }
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_SetPanelOverrides()
 **
 ** DESCRIPTION:
 **   Set override parameters from XML Data
 **
 *//* -------------------------------------------------------------------- */
static DP_Status Panel_gmvcu_dp_disp_gm_hd1080_SetPanelOverrides(QDI_HandleType       hOemHandle,
                                                      QDI_Panel_AttrType  *pPanelInfo)
{
   DPDriverConfigType       *pDPConfig        = &gDPDriverConfig;
   DP_SetPropertyParamsType  sPropertyData    = { 0 };
   DP_Status                 eStatus          = DP_STATUS_SUCCESS;
   DP_SetPropertyParamsType  sDPProp          = { 0 };

   if ((NULL  == pDPConfig) ||
       (NULL  == pDPConfig->hDPHandle))
   {
      MDSS_PANEL_LOG_ERROR("Invalid input ");
      eStatus = DP_STATUS_FAILED_RESOURCE_NOT_READY;
   }
   else
   {
      MDSS_OSAL_MemZero((char *)&sDPProp, sizeof(DP_SetPropertyParamsType));

      if (TRUE == pDPConfig->bForceDPCD)
      {
         sPropertyData.uLinkRate = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.uLinkRate;

         /* Check the value of the LinkRate configured is correct */
         if (!((162000 == sPropertyData.uLinkRate) ||
               (270000 == sPropertyData.uLinkRate) ||
               (540000 == sPropertyData.uLinkRate) ||
               (810000 == sPropertyData.uLinkRate)))
         {
            MDSS_PANEL_LOG_ERROR("Link rate value %d configured in XML is wrong",sPropertyData.uLinkRate);
            eStatus = DP_STATUS_FAILED_INVALID_INPUT_PARAMETER;
         }

         if (DP_STATUS_SUCCESS == eStatus)
         {
            if(DP_STATUS_SUCCESS != (eStatus = (DP_Status)DP_Host_SetProperty(pDPConfig->hDPHandle, DP_SETPROPERTY_LINK_RATE, &sPropertyData)))
            {
               MDSS_PANEL_LOG_ERROR("failed to set link rate");
            }

            sPropertyData.uLaneNumber = pDPConfig->sPanelConfig.unIntfParams.sDPConfigParams.uNumOfLanes;
            /* Check the value of the lane number configured is correct */
            if ((0 >= sPropertyData.uLaneNumber) || (4 < sPropertyData.uLaneNumber))
            {
               MDSS_PANEL_LOG_ERROR("lane number value %d configured in XML is wrong",sPropertyData.uLaneNumber);
               eStatus = DP_STATUS_FAILED_INVALID_INPUT_PARAMETER;
            }

            if (DP_STATUS_SUCCESS == eStatus)
            {
               if (DP_STATUS_SUCCESS != (eStatus = (DP_Status)DP_Host_SetProperty(pDPConfig->hDPHandle, DP_SETPROPERTY_LANE_NUMBER, &sPropertyData)))
               {
                  MDSS_PANEL_LOG_ERROR("failed to set lane number");
               }
            }
         }
      }

      if ((DP_STATUS_SUCCESS == eStatus) && (TRUE == pDPConfig->bForceModeXML))
      {
         sDPProp.sPanelInfo.uModeIndex               = 0;
         sDPProp.sPanelInfo.uVisibleWidthInPixels    = pPanelInfo->iVisWidthPx;
         sDPProp.sPanelInfo.uHsyncFrontPorchInPixels = pPanelInfo->sActiveTiming.iHsyncFrontPorchDclk;
         sDPProp.sPanelInfo.uHsyncBackPorchInPixels  = pPanelInfo->sActiveTiming.iHsyncBackPorchDclk;
         sDPProp.sPanelInfo.uHsyncPulseInPixels      = pPanelInfo->sActiveTiming.iHsyncPulseWidthDclk;
         sDPProp.sPanelInfo.uVisibleHeightInPixels   = pPanelInfo->iVisHeightPx;
         sDPProp.sPanelInfo.uVsyncFrontPorchInLines  = pPanelInfo->sActiveTiming.iVsyncFrontPorchLines;
         sDPProp.sPanelInfo.uVsyncBackPorchInLines   = pPanelInfo->sActiveTiming.iVsyncBackPorchLines;
         sDPProp.sPanelInfo.uVsyncPulseInLines       = pPanelInfo->sActiveTiming.iVsyncPulseWidthLines;
         sDPProp.sPanelInfo.bHSyncActiveLow          = pPanelInfo->sActiveTiming.bIsHsyncActiveLow;
         sDPProp.sPanelInfo.bVSyncActiveLow          = pPanelInfo->sActiveTiming.bIsVsyncActiveLow;

         sDPProp.sPanelInfo.uPclkFreq                = (uint32)((pPanelInfo->iVisWidthPx +
                  pPanelInfo->sActiveTiming.iHsyncFrontPorchDclk +
                  pPanelInfo->sActiveTiming.iHsyncBackPorchDclk +
                  pPanelInfo->sActiveTiming.iHsyncPulseWidthDclk) *
               (uint64) (pPanelInfo->iVisHeightPx +
                  pPanelInfo->sActiveTiming.iVsyncFrontPorchLines +
                  pPanelInfo->sActiveTiming.iVsyncBackPorchLines +
                  pPanelInfo->sActiveTiming.iVsyncPulseWidthLines) *
               pPanelInfo->uAttrs.sDP.uRefreshRate / 1000);

         pPanelInfo->uAttrs.sDP.uRefreshRate         = Q16_VALUE(pPanelInfo->uAttrs.sDP.uRefreshRate/1000);
         sDPProp.sPanelInfo.uRefreshRate             = pPanelInfo->uAttrs.sDP.uRefreshRate;

         if (QDI_PIXEL_FORMAT_RGB_666_18BPP == pPanelInfo->eColorFormat)
         {
            sDPProp.sPanelInfo.eColorFormat = DP_PIXEL_FORMAT_RGB_666_18BPP;
         }
         else if (QDI_PIXEL_FORMAT_RGB_101010_30BPP == pPanelInfo->eColorFormat)
         {
            sDPProp.sPanelInfo.eColorFormat = DP_PIXEL_FORMAT_RGB_101010_30BPP;
         }
         else
         {
            sDPProp.sPanelInfo.eColorFormat = DP_PIXEL_FORMAT_RGB_888_24BPP;
         }

         MDSS_PANEL_LOG_CRITICAL_INFO("Refresh Rate[%d] PClkFreq[%d]",sDPProp.sPanelInfo.uRefreshRate,sDPProp.sPanelInfo.uPclkFreq);

         /* The calculated pixel clock is validated against the pclk for VGA which is 25200000Mhz */
         if (sDPProp.sPanelInfo.uPclkFreq < DPDRIVER_MIN_PIXEL_CLOCK_HZ)
         {
            MDSS_PANEL_LOG_ERROR("Pixel clock (0x%x) is too low for custom mode.",
                  sDPProp.sPanelInfo.uPclkFreq);
         }
         /* Set the timings in DP Host */
         else if (DP_STATUS_SUCCESS != (eStatus = (DP_Status)DP_Host_SetProperty(pDPConfig->hDPHandle, DP_SETPROPERTY_PANEL_INFO, &sDPProp)))
         {
            MDSS_PANEL_LOG_ERROR("failed to set panel info");
         }
      }
      if (DP_STATUS_SUCCESS == eStatus)
      {
         eStatus = (DP_Status)DP_Host_Commit(pDPConfig->hDPHandle);
      }
   }
   return eStatus;
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_Open()
 **
 ** DESCRIPTION:
 **   Initialize DP host driver
 **
 *//* -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_Open(QDI_HandleType     hOemHandle)
{
   MDSS_Status              eStatus      = MDSS_STATUS_SUCCESS;
   QDI_ErrorType            eQdiStatus   = QDI_STATUS_SUCCESS;
   DPDriverConfigType      *pDPConfig    = &gDPDriverConfig;
   HAL_DP_LaneMapType       eLaneMapping = HAL_DP_LANEMAP_TYPE_NONE;

   MDSS_PANEL_LOG_API_ENTER("");
   do
   {
      DP_HostOpenConfigType          sOpenConfig;

      if (QDI_STATUS_SUCCESS != Panel_gmvcu_dp_disp_gm_hd1080_ReadXMLData(hOemHandle))
      {
         MDSS_PANEL_LOG_ERROR("Failed to read the timing data from the XML");
         eQdiStatus = QDI_STATUS_FAILED;
      }
      else
      {
         /* Poplulate sOpenConfig using panel attributes */
         Panel_gmvcu_dp_disp_gm_hd1080_SetupOpenConfig(pDPConfig->eDisplayId, &sOpenConfig);
         eLaneMapping                            = GetChannelMapping(gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.uLaneMapping);
         pDPConfig->uLaneMapping                 = eLaneMapping;
         pDPConfig->bDPPowerOn                   = FALSE;
         pDPConfig->bForceDPCD                   = TRUE;
         sOpenConfig.bInitContextOnly            = FALSE;
         sOpenConfig.uLaneMapping                = eLaneMapping;
         sOpenConfig.uPNSwapConfig               = gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.uPNSwapConfig;
         sOpenConfig.bLinkTrainingSupported      = gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.bLinkTrainingSupported;
         sOpenConfig.bMSTSideBandMSGSupported    = gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.bMSTSideBandMSGSupported;

         /* Initialize the host side */
         eStatus = DP_Host_Open(&pDPConfig->hDPHandle, &sOpenConfig);

         if (MDSS_STATUS_DP_FAILED_NO_PANEL_CONNECTED == eStatus)
         {
            pDPConfig->bForceModeXML = TRUE;
            pDPConfig->bForceDPCD    = TRUE;
            eStatus                  = MDSS_STATUS_SUCCESS;
         }
         else if (MDSS_STATUS_SUCCESS != eStatus)
         {
            MDSS_PANEL_LOG_ERROR("DP_Host_Open failed eStatus = %d", eStatus);
            eQdiStatus = MDSS_Get_QDI_Status(eStatus);
         }
         else if(MDSS_STATUS_SUCCESS == eStatus)
         {
            if (FALSE == gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.bReadDPCD)
            {
                pDPConfig->bForceDPCD    = TRUE;
            }

            if (TRUE == gDPDriverConfig.sPanelConfig.unIntfParams.sDPConfigParams.bReadEDID)
            {
               /*
                * If panel is connected then try to read different modes from the panel and
                * select the mode which is specified in the XML
                */
               eQdiStatus = Panel_gmvcu_dp_disp_gm_hd1080_SelectMode(hOemHandle);
               if (QDI_STATUS_NOT_SUPPORTED == eQdiStatus)
               {
                  pDPConfig->bForceModeXML = TRUE;
                  MDSS_PANEL_LOG_WARNING("Panel doesn't support the specified mode. Forcing configuration defined in the XML.");
                  eQdiStatus = QDI_STATUS_SUCCESS;
               }
               else if (QDI_STATUS_SUCCESS != eQdiStatus)
               {
                  MDSS_PANEL_LOG_ERROR("Mode selection of the panel failed. eQdiStatus = %d", eQdiStatus);
                  eQdiStatus = QDI_STATUS_FAILED;
               }
            }
            else
            {
               pDPConfig->bForceModeXML = TRUE;
            }
         }
         MDSS_PANEL_LOG_INFO("DP: Open [Display:%i sts: %i]", pDPConfig->eDisplayId, eQdiStatus);
      }
   }while(0);
   MDSS_PANEL_LOG_API_EXIT("");
   return eQdiStatus;
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_Init()
 **
 ** DESCRIPTION:
 **   Initializes the DP driver
 **
 *//* -------------------------------------------------------------------- */
QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_Init(QDI_HandleType   hOemHandle,
        uint32           uFlags)
{
   QDI_ErrorType                    eStatus;
   gmvcu_dp_disp_gm_hd1080_Ctx *psSelf = NULL;

   MDSS_PANEL_LOG_API_ENTER("");

   psSelf = &gPanelDrvCtx;
   eStatus = Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipInit(psSelf);
   if (DP_STATUS_SUCCESS == eStatus)
   {
      eStatus = Panel_gmvcu_dp_disp_gm_hd1080_Open(hOemHandle);
   }

   MDSS_PANEL_LOG_API_EXIT("");

   return eStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_Term()
 **
 ** DESCRIPTION:
 **    Close the DP Host driver
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_Term(QDI_HandleType  hOemHandle,
                                             uint32          uFlags)
{
   DP_Status                eStatus    = DP_STATUS_SUCCESS;
   DPDriverConfigType      *pDPConfig  = &gDPDriverConfig;
   gmvcu_dp_disp_gm_hd1080_Ctx *psSelf = &gPanelDrvCtx;

   MDSS_PANEL_LOG_API_ENTER("");

   Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipDeInit(psSelf);

   do
   {
      // Powerdown the host driver
      if (DP_STATUS_SUCCESS != (eStatus = (DP_Status)DP_Host_Close(pDPConfig->hDPHandle)))
      {
         MDSS_PANEL_LOG_ERROR("DP_Host_Close failed, eStatus =%d", eStatus);
      }

      MDSS_PANEL_LOG_INFO("DP: Term [Display:%i sts: %i]", pDPConfig->eDisplayId, eStatus);
   }while(0);
   MDSS_PANEL_LOG_API_EXIT("");

   return eStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_Power()
 **
 ** DESCRIPTION:
 **    Power up the DP Core
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_Power(QDI_HandleType  hOemHandle,
                                              bool32          bPowerEnable,
                                              uint32          uFlags)
{
   QDI_ErrorType             eRetStatus     = QDI_STATUS_SUCCESS;
   DPDriverConfigType       *pDPConfig      = &gDPDriverConfig;
   DP_SetPropertyParamsType  sPropertyData  = { 0 };
   gmvcu_dp_disp_gm_hd1080_Ctx *psSelf      = &gPanelDrvCtx;
   uint32                    retry          = 0;
   bool32                    dplink = FALSE;
   MDSS_PANEL_LOG_API_ENTER("");
   do
   {
      eRetStatus = Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower(psSelf, bPowerEnable, uFlags);
      if (DP_STATUS_SUCCESS == eRetStatus)
      {
         MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower() Success, bPowerEnable=%d", bPowerEnable);
      }

      if (TRUE == bPowerEnable)
      {
         if (FALSE == pDPConfig->bDPPowerOn)
         {
            do
            {

               sPropertyData.sPanelInfo.uModeIndex = pDPConfig->uModeIndex;
               eRetStatus = DP_Host_SetProperty(pDPConfig->hDPHandle, DP_SETPROPERTY_PANEL_MODE_INDEX, &sPropertyData);
               if (DP_STATUS_SUCCESS == eRetStatus)
               {
                  eRetStatus = DP_Host_Commit(pDPConfig->hDPHandle);

                  if (DP_STATUS_SUCCESS == eRetStatus)
                  {
                    dplink = TRUE;
                    MDSS_PANEL_LOG_CRITICAL_INFO("DP Host commit success");
                    pDPConfig->bDPPowerOn = TRUE;
                    break;
                  }
                  else
                  {
                     MDSS_PANEL_LOG_CRITICAL_INFO("DP commit failed, re-init serializer and retry DP commit");
                     eRetStatus = Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower(psSelf, FALSE, uFlags);
                     if (QDI_STATUS_SUCCESS != eRetStatus)
                     {
                        MDSS_PANEL_LOG_ERROR("BridgeChipPower OFF failed, status=%d", eRetStatus);
                     }
                     (void)usleep(1000*100);
                     eRetStatus = Panel_gmvcu_dp_disp_gm_hd1080_BridgeChipPower(psSelf, bPowerEnable, uFlags);
                     if (QDI_STATUS_SUCCESS != eRetStatus)
                     {
                        MDSS_PANEL_LOG_ERROR("BridgeChipPower ON, status=%d", eRetStatus);
                     }

                  }

               }
               MDSS_PANEL_LOG_CRITICAL_INFO("DP: SetProperty [Mode:%i Display:%i Status: %i] Retry:%d", pDPConfig->uModeIndex, pDPConfig->eDisplayId, eRetStatus,retry);

            }while ((dplink == FALSE) && (retry++ < 5));

            if (dplink == FALSE)
            {
               DP_LINKFAIL_LOGGING(psSelf->eDeviceId, psSelf->psPanelConfig->unIntfParams.sDPConfigParams.cBridgeChipID);
            }
         }
      }
   }while(0);
   MDSS_PANEL_LOG_API_EXIT("");
   return eRetStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_PowerStateEvent()
 **
 ** DESCRIPTION:
 **    This function is used to turn off the DP controller and PHY
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_PowerStateEvent(QDI_HandleType  hOemHandle,
                                                        QDI_PowerState_Event          bPowerStateEvent,
                                                        uint32          uFlags)
{
   QDI_ErrorType          eRetStatus      = QDI_STATUS_SUCCESS;
   DPDriverConfigType    *pDPConfig       = &gDPDriverConfig;

   MDSS_PANEL_LOG_API_ENTER("");
   do
   {
      if (QDI_POWERSTATE_EVENT_PRE_VIDEO_OFF == bPowerStateEvent)
      {
         MDSS_PANEL_LOG_CRITICAL_INFO("QDI_POWERSTATE_EVENT_**PRE**_VIDEO_OFF");
         if (DP_STATUS_SUCCESS != (eRetStatus = DP_Host_PrePower(pDPConfig->hDPHandle, 0)))
         {
            MDSS_PANEL_LOG_ERROR("DP_Host_PrePower failed, eRetStatus =%d", eRetStatus);
         }
      }
      else if (QDI_POWERSTATE_EVENT_POST_VIDEO_OFF == bPowerStateEvent)
      {
         MDSS_PANEL_LOG_CRITICAL_INFO("QDI_POWERSTATE_EVENT_POST_VIDEO_OFF");
         // Powerdown the host driver
         if (DP_STATUS_SUCCESS != (eRetStatus = DP_Host_Power(pDPConfig->hDPHandle, 0)))
         {
            MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dp_disp_gm_hd1080_Power: DP_Host_Power failed, eRetStatus =%d", eRetStatus);
         }
         else
         {
            /* DP component has been powered off */
            pDPConfig->bDPPowerOn = FALSE;
         }
      }
   }while(0);

   MDSS_PANEL_LOG_API_EXIT("");
   return eRetStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_ReadXMLData()
 **
 ** DESCRIPTION:
 **   Read the Display panel configurations from the XML
 **
 -------------------------------------------------------------------- */
static QDI_Status Panel_gmvcu_dp_disp_gm_hd1080_ReadXMLData(QDI_HandleType       hOemHandle)
{
   QDI_Status                         eRetStatus       = QDI_STATUS_SUCCESS;
   MDSS_Status                        eDrvCfgStatus    = MDSS_STATUS_SUCCESS;
   DPDriverConfigType                *pDPConfig        = &gDPDriverConfig;
   MDSS_DrvConfig_VideoModeType     **ppVideoModeList  = NULL;
   MDSS_DrvConfig_AudioModeType     **ppAudioModeList  = NULL;
   MDSS_DrvConfig_DisplayNodeType   **ppDispNodeList   = NULL;
   uint32                             uNumOfVideoModes = 0;
   uint32                             uNumOfAudioModes = 0;
   uint32                             uNumOfDispNodes  = 0;

   MDSS_OSAL_MemZero((char *)&pDPConfig->sPanelConfig, sizeof(pDPConfig->sPanelConfig));
   pDPConfig->sPanelConfig.eDisplayId = pDPConfig->eDisplayId;

   eDrvCfgStatus = MDSS_DrvConfig_GetProperty(MDSS_DRVCONFIG_PROPERTY_PANEL_CONFIG, &pDPConfig->sPanelConfig);

   if (MDSS_STATUS_SUCCESS != eDrvCfgStatus)
   {
      MDSS_PANEL_LOG_ERROR("Did not find Panel Configuration from XML");
      eRetStatus = QDI_STATUS_FAILED;
   }
   else
   {
      ppVideoModeList  = &pDPConfig->sPanelConfig.pVideoModeList;
      uNumOfVideoModes = pDPConfig->sPanelConfig.uNumOfVideoModes;
      ppAudioModeList  = &pDPConfig->sPanelConfig.pAudioModeList;
      uNumOfAudioModes = pDPConfig->sPanelConfig.uNumOfAudioModes;
      ppDispNodeList   = &pDPConfig->sPanelConfig.pDispNodeList;
      uNumOfDispNodes  = pDPConfig->sPanelConfig.uNumOfDispNodes;
   }

   /* Allocate memory for video mode list */
   if((QDI_STATUS_SUCCESS == eRetStatus) && (0 < uNumOfVideoModes))
   {
      *ppVideoModeList = (MDSS_DrvConfig_VideoModeType *)MDSS_OSAL_Malloc(
            sizeof(MDSS_DrvConfig_VideoModeType) * uNumOfVideoModes,
            MDSS_OSAL_COMP_PANEL);

      if(NULL == *ppVideoModeList)
      {
         eRetStatus = QDI_STATUS_NO_RESOURCES;
         MDSS_PANEL_LOG_ERROR("Malloc failed");
      }
      else
      {
         MDSS_OSAL_MemZero(
               (char *)(*ppVideoModeList),
               sizeof(MDSS_DrvConfig_VideoModeType) * uNumOfVideoModes);
      }
   }
   /* Allocate memory for audio mode list */
   if((QDI_STATUS_SUCCESS == eRetStatus) && (0 < uNumOfAudioModes))
   {
      *ppAudioModeList = (MDSS_DrvConfig_AudioModeType *)MDSS_OSAL_Malloc(
            sizeof(MDSS_DrvConfig_AudioModeType) * uNumOfAudioModes,
            MDSS_OSAL_COMP_PANEL);

      if(NULL == *ppAudioModeList)
      {
         eRetStatus = QDI_STATUS_NO_RESOURCES;
         MDSS_PANEL_LOG_ERROR("Malloc failed");
      }
      else
      {
         MDSS_OSAL_MemZero(
               (char *)(*ppAudioModeList),
               sizeof(MDSS_DrvConfig_AudioModeType) * uNumOfAudioModes);
      }
   }

   /* Allocate memory for display node list */
   if((QDI_STATUS_SUCCESS == eRetStatus) && (0 < uNumOfDispNodes))
   {
      *ppDispNodeList = (MDSS_DrvConfig_DisplayNodeType *)MDSS_OSAL_Malloc(
            sizeof(MDSS_DrvConfig_DisplayNodeType) * uNumOfDispNodes,
            MDSS_OSAL_COMP_PANEL);

      if(NULL == *ppDispNodeList)
      {
         eRetStatus = QDI_STATUS_NO_RESOURCES;
         MDSS_PANEL_LOG_ERROR("Malloc failed");
      }
      else
      {
         MDSS_OSAL_MemZero(
               (char *)(*ppDispNodeList),
               sizeof(MDSS_DrvConfig_DisplayNodeType) * uNumOfDispNodes);
      }
   }
   if(QDI_STATUS_SUCCESS == eRetStatus)
   {
      eRetStatus = (QDI_Status)MDSS_DrvConfig_GetProperty(
            MDSS_DRVCONFIG_PROPERTY_PANEL_CONFIG, &pDPConfig->sPanelConfig);

      if(QDI_STATUS_SUCCESS != eRetStatus)
      {
         MDSS_PANEL_LOG_ERROR(
               "Failed to get video modes / audio modes / display nodes, error=%u",
               eRetStatus);
      }
   }
   else
   {
      if((NULL != ppVideoModeList) && (NULL != *ppVideoModeList))
      {
         MDSS_OSAL_Free(*ppVideoModeList);
         *ppVideoModeList = NULL;
      }
      if((NULL != ppAudioModeList) && (NULL != *ppAudioModeList))
      {
         MDSS_OSAL_Free(*ppAudioModeList);
         *ppAudioModeList = NULL;
      }
      if((NULL != ppDispNodeList) && (NULL != *ppDispNodeList))
      {
         MDSS_OSAL_Free(*ppDispNodeList);
         *ppDispNodeList = NULL;
      }
   }

   return eRetStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_DP_COMMON_MST_QC_SelectMode()
 **
 ** DESCRIPTION:
 **   Function checks whether the mode configured in the XML is supported
 **   by the panel connected.
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_SelectMode(QDI_HandleType       hOemHandle)
{
   QDI_ErrorType                    eStatus         = QDI_STATUS_OK;
   DPDriverConfigType              *pDPConfig       = &gDPDriverConfig;
   DP_GetPropertyParamsType         sDPProp;
   MDSS_DrvConfig_VideoModeType    *pVideoTiming    = NULL;
   uint32                           uNumOfModes     = 0;
   uint32                           uI              = 0;

   MDSS_PANEL_LOG_API_ENTER("");

   if (NULL == pDPConfig)
   {
      MDSS_PANEL_LOG_ERROR("Wrong OEM handle");
      eStatus = QDI_STATUS_FAILED;
   }
   else
   {
      if (MDSS_STATUS_SUCCESS  == DP_Host_GetProperty(pDPConfig->hDPHandle, DP_GETPROPERTY_NUM_OF_MODES_INFO, &sDPProp))
      {
         uNumOfModes   = sDPProp.uNumOfModes;
         pVideoTiming  = &pDPConfig->sPanelConfig.pVideoModeList[0];

         /* Select the mode which contains the same timing values specified in the XML */
         for (uI = 0; uI < uNumOfModes; uI++)
         {
            MDSS_OSAL_MemZero((char *)&sDPProp, sizeof(DP_GetPropertyParamsType));
            sDPProp.sPanelInfo.uModeIndex = uI;

            if (MDSS_STATUS_SUCCESS  == DP_Host_GetProperty(pDPConfig->hDPHandle, DP_GETPROPERTY_GET_MODE_INFO, &sDPProp))
            {
               if((sDPProp.sPanelInfo.uVisibleWidthInPixels    == pVideoTiming->uActiveH)       &&
                  (sDPProp.sPanelInfo.uVisibleHeightInPixels   == pVideoTiming->uActiveV)       &&
                  (sDPProp.sPanelInfo.uVsyncFrontPorchInLines  == pVideoTiming->uFrontPorchV)   &&
                  (sDPProp.sPanelInfo.uVsyncBackPorchInLines   == pVideoTiming->uBackPorchV)    &&
                  (sDPProp.sPanelInfo.uHsyncBackPorchInPixels  == pVideoTiming->uBackPorchH)    &&
                  (sDPProp.sPanelInfo.uHsyncFrontPorchInPixels == pVideoTiming->uFrontPorchH)   &&
                  (sDPProp.sPanelInfo.uHsyncPulseInPixels      == pVideoTiming->uPulseWidthH)   &&
                  (sDPProp.sPanelInfo.uVsyncBackPorchInLines   == pVideoTiming->uBackPorchV)    &&
                  (sDPProp.sPanelInfo.uVsyncFrontPorchInLines  == pVideoTiming->uFrontPorchV)   &&
                  (sDPProp.sPanelInfo.uVsyncPulseInLines       == pVideoTiming->uPulseWidthV)   &&
                  (sDPProp.sPanelInfo.bHSyncActiveLow          == pVideoTiming->bActiveLowH)    &&
                  (sDPProp.sPanelInfo.bVSyncActiveLow          == pVideoTiming->bActiveLowV)    &&
                  (sDPProp.sPanelInfo.uPclkFreq                == pVideoTiming->uPixelFreqInHz))
               {
                  pDPConfig->uModeIndex        = uI;
                  break;
               }
            }
         }
         if (uI == uNumOfModes)
         {
            MDSS_PANEL_LOG_ERROR("Mode configured in the XML is not supported by panel");
            eStatus = QDI_STATUS_NOT_SUPPORTED;
         }
      }
      else
      {
         MDSS_PANEL_LOG_ERROR("DP_Host_GetProperty: DP_GETPROPERTY_NUM_OF_MODES_INFO failed");
         eStatus = QDI_STATUS_FAILED;
      }
   }

   return eStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_GetInfo()
 **
 ** DESCRIPTION:
 **   Return DP panel info
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_GetInfo(QDI_HandleType       hOemHandle,
                                                QDI_Panel_AttrType  *pPanelConfig,
                                                uint32               uFlags)
{
   QDI_ErrorType                    eStatus         = QDI_STATUS_OK;
   DPDriverConfigType              *pDPConfig       = &gDPDriverConfig;
   DP_GetPropertyParamsType         sDPProp;
   MDSS_DrvConfig_VideoModeType    *pVideoTiming    = NULL;

   MDSS_PANEL_LOG_API_ENTER("");

   if (NULL == pDPConfig)
   {
      MDSS_PANEL_LOG_ERROR("Wrong OEM handle");
      eStatus = QDI_STATUS_FAILED;
   }
   else
   {
      pVideoTiming                                       = &pDPConfig->sPanelConfig.pVideoModeList[0];
      pPanelConfig->uNumOfDisplayModes                   = 1; //TODO : Query this from DP Host
      pPanelConfig->iVisWidthPx                          = pVideoTiming->uActiveH;
      pPanelConfig->iVisHeightPx                         = pVideoTiming->uActiveV;
      pPanelConfig->iFrontPorchPx                        = pVideoTiming->uFrontPorchV;
      pPanelConfig->iBackPorchPx                         = pVideoTiming->uBackPorchV;
      pPanelConfig->iRefreshRowsPerSecond                = ((pVideoTiming->uPixelFreqInHz) /
                                                            (pVideoTiming->uActiveH     +
                                                             pVideoTiming->uBackPorchH  +
                                                             pVideoTiming->uFrontPorchH +
                                                             pVideoTiming->uPulseWidthH)
                                                            );
      pPanelConfig->uAttrs.sDP.uRefreshRate              = pVideoTiming->uRefreshRate;

      pPanelConfig->sActiveTiming.iHsyncBackPorchDclk    = pVideoTiming->uBackPorchH;
      pPanelConfig->sActiveTiming.iHsyncFrontPorchDclk   = pVideoTiming->uFrontPorchH;
      pPanelConfig->sActiveTiming.iHsyncPulseWidthDclk   = pVideoTiming->uPulseWidthH;
      pPanelConfig->sActiveTiming.iHsyncSkewDclk         = 0;

      pPanelConfig->sActiveTiming.iVsyncBackPorchLines   = pVideoTiming->uBackPorchV;
      pPanelConfig->sActiveTiming.iVsyncFrontPorchLines  = pVideoTiming->uFrontPorchV;
      pPanelConfig->sActiveTiming.iVsyncPulseWidthLines  = pVideoTiming->uPulseWidthV;

      pPanelConfig->sActiveTiming.iHLeftBorderDClk       = 0;
      pPanelConfig->sActiveTiming.iHRightBorderDClk      = 0;
      pPanelConfig->sActiveTiming.iVTopBorderLines       = 0;
      pPanelConfig->sActiveTiming.iVBottomBorderLines    = 0;

      pPanelConfig->sActiveTiming.bIsHsyncActiveLow      = pVideoTiming->bActiveLowH;
      pPanelConfig->sActiveTiming.bIsVsyncActiveLow      = pVideoTiming->bActiveLowV;
      pPanelConfig->sActiveTiming.bIsDataEnableActiveLow = TRUE;

      /* Update the active region */
      pPanelConfig->sActiveRoi.sCordXY.iPosX            = 0;
      pPanelConfig->sActiveRoi.sCordXY.iPosY            = 0;
      pPanelConfig->sActiveRoi.uHeightY                 = pPanelConfig->iVisHeightPx;
      pPanelConfig->sActiveRoi.uWidthX                  = pPanelConfig->iVisWidthPx;

      pPanelConfig->ePhysConnect                        = GetDPConnector(pDPConfig->eDisplayId);
      pPanelConfig->eColorFormat                        = pVideoTiming->ePixelFormatType;

      pPanelConfig->uPhysicalPanelWidth                 = 225 << 16; // 225mm in 16.16 fixed point format
      pPanelConfig->uPhysicalPanelHeight                = 127 << 16; // 127mm in 16.16 fixed point format

      pPanelConfig->uAttrs.sDP.eConnectionPolarity      = QDI_DP_CONNECTION_POLARITY_POLARITY_REVERSE;
      pPanelConfig->uAttrs.sDP.eConnectionPinAssignment = QDI_DP_CONNECTION_PINASSIGNMENT_DFPD_A;

      /* Also set these timing paramters to the DPHost */
      if (MDSS_STATUS_SUCCESS != (eStatus = Panel_gmvcu_dp_disp_gm_hd1080_SetPanelOverrides(hOemHandle, pPanelConfig)))
      {
         MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dp_disp_gm_hd1080_SetPanelOverrides failed");
      }
   }

   MDSS_OSAL_MemZero((char *)&sDPProp, sizeof(DP_GetPropertyParamsType));
   if (MDSS_STATUS_SUCCESS  == DP_Host_GetProperty(pDPConfig->hDPHandle, DP_GETPROPERTY_DUALPIXEL_MODE_INFO, &sDPProp))
   {
      pPanelConfig->bDualPixelMode                      = sDPProp.bDualPixelMode;
      pDPConfig->bDualPixelMode                         = sDPProp.bDualPixelMode; //Store this value in global structure also
   }
   else
   {
      MDSS_PANEL_LOG_ERROR("DP_Host_GetProperty: DP_GETPROPERTY_DUALPIXEL_MODE_INFO failed");
      eStatus = QDI_STATUS_FAILED;
   }

   MDSS_PANEL_LOG_API_EXIT("");
   return eStatus;
}

/* ----------------------------------------------------------------------
 ** FUNCTION: DPDriverGetInfo()
 **
 ** DESCRIPTION:
 **    Get DP panel mode info.
 **
 -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_GetModeInfo(QDI_HandleType            hOemHandle,
                                                    QDI_Panel_ModeInfoType   *psModeInfo,
                                                    uint32                    uFlags)
{
   QDI_ErrorType             eStatus    = QDI_STATUS_OK;
   DPDriverConfigType       *pDPConfig  = &gDPDriverConfig;
   DP_GetPropertyParamsType  sDPProp;

   MDSS_PANEL_LOG_API_ENTER("");
   if ((NULL == pDPConfig) ||
       (NULL == pDPConfig->hDPHandle))
   {
      eStatus = QDI_STATUS_NO_RESOURCES;
   }
   else
   {
      MDSS_OSAL_MemZero((char *)&sDPProp, sizeof(DP_GetPropertyParamsType));
      sDPProp.sPanelInfo.uModeIndex = pDPConfig->uModeIndex;

      /* Query the mode */
      if (MDSS_STATUS_SUCCESS == DP_Host_GetProperty(pDPConfig->hDPHandle, DP_GETPROPERTY_GET_MODE_INFO, &sDPProp))
      {
         psModeInfo->sDisplayModeInfo.uWidthPx        = sDPProp.sPanelInfo.uVisibleWidthInPixels;
         psModeInfo->sDisplayModeInfo.uWidthTotalPx   = sDPProp.sPanelInfo.uVisibleWidthInPixels + sDPProp.sPanelInfo.uHsyncBackPorchInPixels + sDPProp.sPanelInfo.uHsyncFrontPorchInPixels + sDPProp.sPanelInfo.uHsyncPulseInPixels;
         psModeInfo->sDisplayModeInfo.uHeightPx       = sDPProp.sPanelInfo.uVisibleHeightInPixels;
         psModeInfo->sDisplayModeInfo.uHeightTotalPx  = sDPProp.sPanelInfo.uVisibleHeightInPixels + sDPProp.sPanelInfo.uVsyncBackPorchInLines + sDPProp.sPanelInfo.uVsyncFrontPorchInLines + sDPProp.sPanelInfo.uVsyncPulseInLines;
         if (TRUE == pDPConfig->bDualPixelMode)
         {
            psModeInfo->sDisplayModeInfo.uPixelClk       = sDPProp.sPanelInfo.uPclkFreq / 2;
         }
         else
         {
            psModeInfo->sDisplayModeInfo.uPixelClk       = sDPProp.sPanelInfo.uPclkFreq;
         }
         psModeInfo->sDisplayModeInfo.bAudioSupported = sDPProp.sPanelInfo.bAudioSupported;
         psModeInfo->sDisplayModeInfo.bInterlaced     = sDPProp.sPanelInfo.bInterlaced;
         psModeInfo->sDisplayModeInfo.e3DFrameFormat  = (QDI_3D_FrameFormatType)sDPProp.sPanelInfo.u3DFrameFormat;
         psModeInfo->sDisplayModeInfo.eAspectRatio    = (QDI_Display_ModeAspectRatioType)sDPProp.sPanelInfo.uAspectRatio;
         psModeInfo->sDisplayModeInfo.eRotation       = (QDI_RotateFlipType)sDPProp.sPanelInfo.uRotation;
         psModeInfo->sDisplayModeInfo.uRefreshRate    = sDPProp.sPanelInfo.uRefreshRate;
         psModeInfo->sDisplayModeInfo.uPixelRate      = sDPProp.sPanelInfo.uPclkFreq;

         if (DP_PIXEL_FORMAT_RGB_888_24BPP == sDPProp.sPanelInfo.eColorFormat)
         {
            psModeInfo->sDisplayModeInfo.eColorFormat = QDI_PIXEL_FORMAT_RGB_888_24BPP;
         }
         else if (DP_PIXEL_FORMAT_RGB_101010_30BPP == sDPProp.sPanelInfo.eColorFormat)
         {
            psModeInfo->sDisplayModeInfo.eColorFormat = QDI_PIXEL_FORMAT_RGB_101010_30BPP;
         }
         else
         {
            psModeInfo->sDisplayModeInfo.eColorFormat = QDI_PIXEL_FORMAT_RGB_666_18BPP;
         }

         MDSS_PANEL_LOG_INFO("DP: GetMode [Display:%i Index:%i  %ix%i @ %iHz PClk:%iHz  Fmt: %i Audio: %i]", pDPConfig->eDisplayId,
               sDPProp.sPanelInfo.uModeIndex,
               psModeInfo->sDisplayModeInfo.uWidthPx,
               psModeInfo->sDisplayModeInfo.uHeightPx,
               (psModeInfo->sDisplayModeInfo.uRefreshRate >> 16),
               psModeInfo->sDisplayModeInfo.uPixelRate,
               psModeInfo->sDisplayModeInfo.eColorFormat,
               psModeInfo->sDisplayModeInfo.bAudioSupported ? 1 : 0);
      }
      else
      {
         eStatus = QDI_STATUS_FAILED;
         MDSS_PANEL_LOG_ERROR("DP_Host_GetProperty: DP_GETPROPERTY_GET_MODE_INFO failed");
      }
   }

   MDSS_PANEL_LOG_API_EXIT("");
   return eStatus;
}

/* ---------------------------------------------------------------------- */
/**
 ** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_GetEDID()
 **
 ** DESCRIPTION:
 **   Retrieve panel EDID.
 **
 *//* -------------------------------------------------------------------- */
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_GetEDID(QDI_HandleType          hOemHandle,
                                                QDI_PanelEdidInfoType  *pEdidInfo,
                                                uint32                  uFlags)
{
   QDI_ErrorType          eRetStatus = QDI_STATUS_SUCCESS;
   DPDriverConfigType    *pDPConfig  = &gDPDriverConfig;

   MDSS_PANEL_LOG_API_ENTER("");
   if ((NULL == pDPConfig) ||
       (NULL == pDPConfig->hDPHandle))
   {
      eRetStatus = QDI_STATUS_NO_RESOURCES;
   }
   else
   {
      DP_GetPropertyParamsType       sPropertyParam;
      sPropertyParam.sEdidInfo.uDataLength = 0;

      if (NULL == pEdidInfo)
      {
         eRetStatus = QDI_STATUS_FAILED;
      }
      else
      {
         if(uFlags & QDI_PANEL_GET_EDID_INFO_DATA)
         {
            if(pEdidInfo->pDataBuf)
            {
               sPropertyParam.sEdidInfo.uDataLength = pEdidInfo->uDataLength;
               sPropertyParam.sEdidInfo.pDataBuf    = pEdidInfo->pDataBuf;
            }
            else
            {
               eRetStatus = QDI_STATUS_FAILED;
            }
         }

         if(QDI_STATUS_SUCCESS == eRetStatus)
         {
            eRetStatus = DP_Host_GetProperty(pDPConfig->hDPHandle, DP_GETPROPERTY_EDID_INFO, &sPropertyParam);
         }

         if(QDI_STATUS_SUCCESS == eRetStatus)
         {
            pEdidInfo->uDataLength = sPropertyParam.sEdidInfo.uDataLength;
         }
         else
         {
            pEdidInfo->uDataLength = 0;
         }

         do
         {
            uint8  *pEDID  = (uint8*)pEdidInfo;
            uint32  uIndex = 0;
            uint32  i;

            MDSS_PANEL_LOG_INFO("DP: EDID Read [Display:%i Size: %ibytes  sts: %i]", pDPConfig->eDisplayId,
                  sPropertyParam.sEdidInfo.uDataLength,
                  eRetStatus);


            // Dump the RAW EDID
            for (i = 0; (i < (sPropertyParam.sEdidInfo.uDataLength/8)) && (uIndex < sPropertyParam.sEdidInfo.uDataLength); i++)
            {
               MDSS_PANEL_LOG_INFO("DP: EDID [%02x %02x %02x %02x %02x %02x %02x %02x]", pEDID [uIndex+0],
                     pEDID[uIndex+1],
                     pEDID[uIndex+2],
                     pEDID[uIndex+3],
                     pEDID[uIndex+4],
                     pEDID[uIndex+5],
                     pEDID[uIndex+6],
                     pEDID[uIndex+7]);
               uIndex += 8;
            }
         }while(0);
      }
   }

   MDSS_PANEL_LOG_API_EXIT("");
   return eRetStatus;
}

//-------------------------------------------------------------------------------------------------
//  Panel_gmvcu_dp_disp_gm_hd1080_SetInfo
//
//  @brief
//      Set DP panel properties.
//
//  @return
//      QDI_STATUS_SUCCESS.
//-------------------------------------------------------------------------------------------------
//
QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_SetInfo(QDI_HandleType   hOemHandle,
                                         void            *pAttr,
                                         uint32           uFlags)
{
   QDI_ErrorType          eRetStatus  = QDI_STATUS_SUCCESS;
   DPDriverConfigType    *pDPConfig   = &gDPDriverConfig;

   MDSS_PANEL_LOG_API_ENTER("");
   if ((NULL == pDPConfig) ||
       (NULL == pDPConfig->hDPHandle)||
       (NULL == pAttr))
   {
      eRetStatus = QDI_STATUS_NO_RESOURCES;
   }
   else
   {
      QDI_Panel_DPAttrType          *psDPAttr = (QDI_Panel_DPAttrType*)pAttr;
      DP_SetPropertyParamsType       sDPProp;

      MDSS_OSAL_MemZero((char *)&sDPProp, sizeof(DP_SetPropertyParamsType));

      if (psDPAttr->uAttributeType &  QDI_PANEL_HDMI_AUDIO_ATTRIBUTE_TYPE)
      {
         sDPProp.sAudioParams.eAudioNumOfChannel   = (DP_AudioChannelType)psDPAttr->sDPAudioAttr.eAudioChannelNum;
         sDPProp.sAudioParams.eAudioSampleBitDepth = (DP_AudioSampleBitDepthType)psDPAttr->sDPAudioAttr.eAudioSampleBitDepth;
         sDPProp.sAudioParams.eAudioFormat         = (DP_AudioFormatType)psDPAttr->sDPAudioAttr.eAudioFormat;
         sDPProp.sAudioParams.eAudioSampleRate     = (DP_AudioSampleRateType)psDPAttr->sDPAudioAttr.eAudioSampleRate;

         eRetStatus = DP_Host_SetProperty(pDPConfig->hDPHandle, DP_SETPROPERTY_AUDIO_CONFIG, &sDPProp);
      }
   }

   MDSS_PANEL_LOG_API_EXIT("");
   return eRetStatus;
}

/*******************************************************************************
*
** FUNCTION: Panel_gmvcu_dp_disp_gm_hd1080_GetCustomAttr()
*/
/*!
* \brief
*   The \b Panel_gmvcu_dp_disp_gm_hd1080_GetCustomAttr function retrieves display node
*   custom attribute
*
* \param [in]     hOemHandle       - Logic handle of display control driver
* \param [in/out] psCustomAttrInfo - Void pointer to custom attribute parameters
* \param [in]     uFlags           - Reserved
*
* \retval QDI_ErrorType
*
*******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_GetCustomAttr(QDI_HandleType              hOemHandle,
                                                          QDI_Panel_CustomAttrInfo   *psCustomAttrInfo,
                                                          uint32                      uFlags)
{
   QDI_ErrorType                     eRetStatus    = QDI_STATUS_SUCCESS;
   DPDriverConfigType               *pDPConfig     = &gDPDriverConfig;
   MDSS_DrvConfig_PanelConfigType   *psPanelConfig = NULL;
   uint32                           *puNumOfNodes  = NULL;
   QDI_Panel_NodeInfoType           *psNodeInfo    = NULL;
   MDSS_DrvConfig_DisplayNodeType   *psNode        = NULL;
   MDSS_DrvConfig_DispNodeAttrType  *psNodeAttribs = NULL;
   uint32                            uNodeId       = 0;
   uint32                            uI            = 0;

   MDSS_PANEL_LOG_API_ENTER(", uFlags=0x%x", uFlags);

   if (NULL == psCustomAttrInfo)
   {
      eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
      MDSS_PANEL_LOG_ERROR("NULL psCustomAttrInfo");
   }

   if (QDI_STATUS_SUCCESS == eRetStatus)
   {
      psPanelConfig = &pDPConfig->sPanelConfig;

      switch (psCustomAttrInfo->eAttrType)
      {
         case QDI_PANEL_CUSTOM_ATTR_NUM_OF_NODES:
         {
            puNumOfNodes = &psCustomAttrInfo->sAttrData.uNumOfNodes;
            *puNumOfNodes = psPanelConfig->uNumOfDispNodes;
            MDSS_PANEL_LOG_CRITICAL_INFO("uNumOfNodes(%u)", *puNumOfNodes);
            break;
         }

         case QDI_PANEL_CUSTOM_ATTR_NODE_INFO:
         {
            psNodeInfo = &psCustomAttrInfo->sAttrData.sNodeInfo;
            uNodeId    = psNodeInfo->uNodeId;

            if ((0 == uNodeId)                              ||
                (psPanelConfig->uNumOfDispNodes < uNodeId) )
            {
               eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
               MDSS_PANEL_LOG_ERROR("uNodeId(%u) out of bounds", uNodeId);
            }
            else
            {
               /* find node with matching node id */
               for (uI = 0; uI < psPanelConfig->uNumOfDispNodes; uI++)
               {
                  if (psPanelConfig->pDispNodeList[uI].uId == uNodeId)
                  {
                     psNode = &psPanelConfig->pDispNodeList[uI];
                     break;
                  }
               }

               /* node id not found */
               if (NULL == psNode)
               {
                  eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
                  MDSS_PANEL_LOG_ERROR("uNodeId(%u) not found", uNodeId);
               }
               else
               {
                  /* copy node info */
                  psNodeAttribs = &psNode->sAttributes;
                  psNodeInfo->uWidth                = psNodeAttribs->uVisWidth;
                  psNodeInfo->uHeight               = psNodeAttribs->uVisHeight;
                  psNodeInfo->uOffsetX              = psNodeAttribs->uOffsetX;
                  psNodeInfo->uOffsetY              = psNodeAttribs->uOffsetY;
                  psNodeInfo->bLinePadEnabled       = psNodeAttribs->bLinePadEnabled;
                  psNodeInfo->uPaddedHeight         = psNodeAttribs->uPaddedHeight;
                  psNodeInfo->uActiveLines          = psNodeAttribs->uActiveLines;
                  psNodeInfo->uPaddingLines         = psNodeAttribs->uPaddingLines;
                  psNodeInfo->bPaddingInfoSetByUser = psNodeAttribs->bPaddingInfoSetByUser;

                  MDSS_PANEL_LOG_CRITICAL_INFO("Node id(%u):",
                                               uNodeId);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uWidth          = %u",
                                               psNodeInfo->uWidth);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uHeight         = %u",
                                               psNodeInfo->uHeight);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uOffsetX        = %u",
                                               psNodeInfo->uOffsetX);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uOffsetY        = %u",
                                               psNodeInfo->uOffsetY);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   bLinePadEnabled = %u",
                                               psNodeInfo->bLinePadEnabled);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uPaddedHeight  = %u",
                                               psNodeInfo->uPaddedHeight);
                  if (TRUE == psNodeInfo->bPaddingInfoSetByUser)
                  {
                     MDSS_PANEL_LOG_CRITICAL_INFO("   uActiveLines  = %u",
                                                  psNodeInfo->uActiveLines);
                     MDSS_PANEL_LOG_CRITICAL_INFO("   uPaddingLines  = %u",
                                                  psNodeInfo->uPaddingLines);
                  }
               }
            }
            break;
         }

         default:
         {
            eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
            MDSS_PANEL_LOG_ERROR("Custom Attribute not supported, eAttrType=%u",
                                 psCustomAttrInfo->eAttrType);
            break;
         }
      }
   }

   MDSS_PANEL_LOG_API_EXIT(", uFlags=0x%x", uFlags);
   return eRetStatus;
}
/* -----------------------------------------------------------------------
 ** Public Functions
 ** ----------------------------------------------------------------------- */

//-------------------------------------------------------------------------------------------------
//  Panel_gmvcu_dp_disp_gm_hd1080_0_DrvInstall
//
//  @brief
//      Install panel driver function table.
//
//  @params
//      [IN] hOemHandle
//          Logic handle of display control driver.
//      [IN] eDisplayId
//          Display ID.
//      [OUT] psDcFxn
//          Panel function table populated in this function.
//
//  @return
//      QDI_STATUS_SUCCESS.
//-------------------------------------------------------------------------------------------------
//
QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_0_DrvInstall(QDI_HandleType                hOemHandle,
                                            QDI_Display_IDType            eDisplayId,
                                            QDI_Panel_FunctionTableType  *psDcFxn)
{
   QDI_ErrorType            eRetStatus   = QDI_STATUS_SUCCESS;
   gmvcu_dp_disp_gm_hd1080_Ctx *psSelf = NULL;


   MDSS_PANEL_LOG_API_ENTER(", eDisplayId=%d", eDisplayId);

   psSelf = &gPanelDrvCtx;
   psSelf->psPanelConfig = &gsPanelConfig;
   psSelf->hDCHandle = hOemHandle;

   if(NULL == psDcFxn)
   {
      eRetStatus = QDI_PANEL_STATUS_FAILED_EXPECTED_NON_NULL_PTR;
   }
   else
   {
      if(NULL != gDPDriverConfig.hOemHandle)
      {
         eRetStatus = QDI_PANEL_STATUS_FAILED_DRIVER_ALREADY_INITIALIZED;
      }
      else
      {
         MDSS_OSAL_MemSet((char *)&gDPDriverConfig, 0x00, sizeof(gDPDriverConfig));
         if(QDI_STATUS_SUCCESS == eRetStatus)
         {
            /* Lock this driver for use by this instance of the DLL only */
            gDPDriverConfig.hOemHandle = hOemHandle;

            /* Save the logical channel connected */
            gDPDriverConfig.eDisplayId = eDisplayId;

            /* Map the local functions to be returned! */
            MDSS_OSAL_MemSet((char *)psDcFxn, 0x00, sizeof(*psDcFxn));

            psDcFxn->QDI_Panel_Init                        = Panel_gmvcu_dp_disp_gm_hd1080_Init;
            psDcFxn->QDI_Panel_SetPower                    = Panel_gmvcu_dp_disp_gm_hd1080_Power;
            psDcFxn->QDI_Panel_PowerStateEvent             = Panel_gmvcu_dp_disp_gm_hd1080_PowerStateEvent;
            psDcFxn->QDI_Panel_GetInfo                     = Panel_gmvcu_dp_disp_gm_hd1080_GetInfo;
            psDcFxn->QDI_Panel_GetModeInfo                 = Panel_gmvcu_dp_disp_gm_hd1080_GetModeInfo;
            psDcFxn->QDI_Panel_GetEdidInfo                 = Panel_gmvcu_dp_disp_gm_hd1080_GetEDID;
            psDcFxn->QDI_Panel_HdmiSetConfig               = Panel_gmvcu_dp_disp_gm_hd1080_SetInfo;
            psDcFxn->QDI_Panel_Term                        = Panel_gmvcu_dp_disp_gm_hd1080_Term;
            psDcFxn->QDI_Panel_GetCustomAttr               = Panel_gmvcu_dp_disp_gm_hd1080_GetCustomAttr;
            psSelf->psDPDriverConfig = &gDPDriverConfig;
         }
         /* Initialize DP Host  */
         if (QDI_STATUS_SUCCESS != (eRetStatus = DP_Host_Init()))
         {
            MDSS_PANEL_LOG_ERROR("Failed to initialize DP_Host, display = %d, eStatus = %d", eDisplayId, eRetStatus);
         }
      }
   }

   MDSS_PANEL_LOG_API_EXIT(", eDisplayId=%d", eDisplayId);
   return eRetStatus;
}

//-------------------------------------------------------------------------------------------------
//  Panel_gmvcu_dp_disp_gm_hd1080_0_UnInstall
//
//  @brief
//      Uninstall panel driver function table.
//
//  @params
//      [IN] hOemHandle
//          Logic handle of display control driver.
//      [IN] eDisplayId
//          Display ID.
//      [OUT] psDcFxn
//          Panel function table populated in this function.
//
//  @return
//      QDI_STATUS_SUCCESS.
//-------------------------------------------------------------------------------------------------
//
QDI_ErrorType Panel_gmvcu_dp_disp_gm_hd1080_0_DrvUnInstall(QDI_HandleType                hOemHandle,
                                              QDI_Display_IDType            eDisplayId,
                                              QDI_Panel_FunctionTableType   *psDcFxn)
{
   QDI_ErrorType   eRetStatus  = QDI_PANEL_STATUS_SUCCESS;
   gmvcu_dp_disp_gm_hd1080_Ctx *psSelf = &gPanelDrvCtx;

   MDSS_PANEL_LOG_API_ENTER(", eDisplayId=%d", eDisplayId);

   if(NULL == psDcFxn)
   {
      eRetStatus = QDI_PANEL_STATUS_FAILED_EXPECTED_NON_NULL_PTR;
   }
   else
   {
      if(hOemHandle != gDPDriverConfig.hOemHandle)
      {
         eRetStatus = QDI_PANEL_STATUS_FAILED_DRIVER_NOT_INITIALIZED;
      }
      else
      {
         psDcFxn->QDI_Panel_Init                      = NULL;
         psDcFxn->QDI_Panel_SetPower                  = NULL;
         psDcFxn->QDI_Panel_PowerStateEvent           = NULL;
         psDcFxn->QDI_Panel_GetInfo                   = NULL;
         psDcFxn->QDI_Panel_GetModeInfo               = NULL;
         psDcFxn->QDI_Panel_GetEdidInfo               = NULL;
         psDcFxn->QDI_Panel_HdmiSetConfig             = NULL;
         psDcFxn->QDI_Panel_Term                      = NULL;
         psDcFxn->QDI_Panel_GetCustomAttr             = NULL;

         MDSS_OSAL_MemSet((char*)&gDPDriverConfig, 0x00, sizeof(gDPDriverConfig));
         MDSS_OSAL_MemZero((char*) psSelf, sizeof(gmvcu_dp_disp_gm_hd1080_Ctx));
      }
   }

   MDSS_PANEL_LOG_API_EXIT(", eDisplayId=%d", eDisplayId);
   return eRetStatus;
}
