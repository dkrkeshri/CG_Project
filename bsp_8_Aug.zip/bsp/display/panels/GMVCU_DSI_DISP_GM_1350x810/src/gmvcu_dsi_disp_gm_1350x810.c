/*! \file */
/*
 ================================================================================

 File: gmvcu_dsi_disp_gm_1350x810.c

 Description: RBAC implementation for GM 1350x810 panel driver.

 The packing name convention for this driver is: gmvcu_dsi_disp_gm_1350x810
 DSI         = Output DSI interface

 $File:  $

 ================================================================================
 Copyright (c) 2018 Qualcomm Technologies, Inc.
 All Rights Reserved.
 Qualcomm Technologies Proprietary and Confidential.

 Copyright (c) 2019 Bosch Automotive (Suzhou) Co., Ltd(RBAC).
 All Rights Reserved.
 RBAC Proprietary and Confidential.

 ================================================================================
 */

/* -----------------------------------------------------------------------------
 ** Includes
 ** ---------------------------------------------------------------------------*/
#include <unistd.h>

#include "qdi_dsi.h"
#include "mdss_osal.h"
#include "qdi_oem.h"
#include "mdss_drvconfig.h"
#include "mdss_log.h"
#include "bridgechip.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* -----------------------------------------------------------------------------
 ** Defines
 ** ---------------------------------------------------------------------------*/
#define HSYNC_SKEW_DCLK                      0
#define VSYNC_SKEW_DCLK                      0
#define VSYNC_START                          0
#define VSYNC_END                            0
#define MAX_NUM_OF_DISP_MODES                1
#define MAX_NUM_OF_AUDIO_MODES               1

/* Logging APIs */
#define MDSS_PANEL_LOG_ERROR(...)                                              \
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_ERROR_INFO_TYPE,     \
   __VA_ARGS__)

#define MDSS_PANEL_LOG_CRITICAL_INFO(...)                                      \
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_CRITICAL_INFO_TYPE,  \
   __VA_ARGS__)

#define MDSS_PANEL_LOG_WARNING(...)                                            \
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_WARNING_INFO_TYPE,   \
   __VA_ARGS__)

#define MDSS_PANEL_LOG_API_ENTER(...)                                          \
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_API_TYPE, "ENTER: ", \
   __VA_ARGS__)

#define MDSS_PANEL_LOG_API_EXIT(...)                                           \
   MDSS_LOG_MESSAGE(MDSS_MODULE_SW_PANEL_DRIVER, MDSS_LOG_API_TYPE, "EXIT: ",  \
   __VA_ARGS__)

/* -----------------------------------------------------------------------------
** Structure Types
** ---------------------------------------------------------------------------*/
static MDSS_DrvConfig_PanelConfigType gsPanelConfig =
{
   .eDisplayId          = QDI_DISPLAY_PRIMARY,
   .bIsDisplayPresent   = TRUE,
   .sVideoTiming =
   {
       .ePixelFormatType = QDI_PIXEL_FORMAT_RGB_888_24BPP,
       .uVisWidth        = 1350,
       .uVisHeight       = 810,
       .uPixelFreqInHz   = 73630000,
       .uHsyncBackPorch  = 64,
       .uHsyncFrontPorch = 28,
       .uVsyncBackPorch  = 9,
       .uVsyncFrontPorch = 4,
       .uHsyncWidth      = 40,
       .uVsyncWidth      = 5,
       .bHsyncPolarity   = FALSE,
       .bVsyncPolarity   = FALSE,
       .bDEPolarity      = FALSE,
   },
   .unIntfParams =
   {
      .sDSIConfigParams =
      {
         .cBridgeChipID = "bridge_ds90uh981q_ub988q_1",
         .uNumOfLanes   = 4,
      },
   },
   .uNumOfVideoModes    = 0,
   .uNumOfAudioModes    = 0,
   .uNumOfDispNodes     = 0,
   .pVideoModeList      = NULL,
   .pAudioModeList      = NULL,
   .pDispNodeList       = NULL,
};

/* Placeholder struct until we move to the bridge chip server */
typedef struct
{
  bool32 bIsBridgeChipPresent;
  BridgeChip_HandleType hBridgeChip;
} gmvcu_dsi_disp_gm_1350x810_BridgeChipInfo;

typedef struct
{
  QDI_Display_IDType eDeviceId;
  /*TODO: Replace with BridgeChip_HandleType when we move to the bridge chip server*/
  gmvcu_dsi_disp_gm_1350x810_BridgeChipInfo sBridgeChipInfo;
  MDSS_DrvConfig_PanelConfigType *psPanelConfig;
  QDI_HandleType hDCHandle; /**< Logic Handle for DC */
  QDI_HandleType hDSIHandle;
  DSI_HandleType hDisplayHandle;
} gmvcu_dsi_disp_gm_1350x810_Ctx;

/* -----------------------------------------------------------------------------
 ** Prototypes
 ** ---------------------------------------------------------------------------*/

static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf, bool32 bPowerOn,
                                                            uint32 uFlags);
static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipInit(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf);
static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeInit(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf);
static void Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipCallback(BridgeChip_CallbackInfoType *pCbInfo);
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_Config(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf, bool32 bEnable);

/* -----------------------------------------------------------------------------
 ** Global Variables
 ** ---------------------------------------------------------------------------*/
static gmvcu_dsi_disp_gm_1350x810_Ctx gPanelDrvCtx;

/* -----------------------------------------------------------------------------
 ** Static Functions
 ** ---------------------------------------------------------------------------*/
/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle function checks if the input logic
 *   handle is valid
 *
 * \param [in]  psSelf     - Pointer to panel driver context
 * \param [in]  hOemHandle - Input logic handle for display handle array
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf,
    QDI_HandleType hOemHandle)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;

  if (NULL == hOemHandle)
  {
    eStatusRet = QDI_PANEL_STATUS_FAILED_DRIVER_NOT_INITIALIZED;
    MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle() FAILED, hOemHandle=%p, eStatusRet=0x%08x",
        hOemHandle, eStatusRet);
  }
  else
  {
    if (hOemHandle != psSelf->hDCHandle)
    {
      eStatusRet = QDI_PANEL_STATUS_FAILED_DRIVER_ALREADY_INITIALIZED;
      MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle() FAILED, hOemHandle=%p, eStatusRet=0x%08x",
          hOemHandle, eStatusRet);
    }
  }

  return eStatusRet;
}

static void Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipCallback(BridgeChip_CallbackInfoType *pCbInfo)
{
  uint32 uEventMask = 0;
  uint32 uI = 0;
  uint32 uEventId = 0;

  if (NULL == pCbInfo)
  {
    MDSS_PANEL_LOG_ERROR("pCbInfo is NULL!");
  }
  else
  {
    MDSS_PANEL_LOG_CRITICAL_INFO("Received callback, events = %x", pCbInfo->sEventInfo.uEventMask);

    uEventMask = pCbInfo->sEventInfo.uEventMask;

    /*
     * Check all error masks and their corresponding structure
     * if recovery-requiring error, signal recovery thread
     * if recovery event, signal the recovery thread to issue a power ON call
     */
    for (uI = 1, uEventId = 0; uI < (BRIDGECHIP_EVENT_ALL + 1); uI = uI << 1, uEventId++)
    {
      if (0x00 != (uEventMask & uI))
      {
        switch (uI)
        {
          case BRIDGECHIP_EVENT_REMOTE_DEVICE_INTERRUPT:
          case BRIDGECHIP_EVENT_HDCP:
          case BRIDGECHIP_EVENT_DEVICE_RECOVERY:
          case BRIDGECHIP_EVENT_PLL:
          case BRIDGECHIP_EVENT_HPD:
          {
            /* Nothing to do */
            break;
          }
          default:
          {
            /* Should never reach here */
            MDSS_PANEL_LOG_WARNING("Unsupported interrupt (%x) - should not reach here", uI);
            continue;
          }
        }
      }
    }
  }
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipInit()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipInit function initializes the bridge chip.
 *
 * \param [in]  psSelf - Pointer to panel driver context
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipInit(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf)
{
  QDI_Status eRetStatus = QDI_STATUS_SUCCESS;
  BridgeChip_HandleType hDevice = NULL;
  BridgeChip_StatusType eBCStatus = BRIDGECHIP_STATUS_SUCCESS;
  BridgeChip_OpenParamsType sOpenParams;
  BridgeChip_CallbackRegisterInfo sCbRegInfo;

  if ((!MDSS_OSAL_StrCmp(psSelf->psPanelConfig->unIntfParams.sDSIConfigParams.cBridgeChipID, "NATIVE"))
      || (FALSE == psSelf->psPanelConfig->bIsDisplayPresent))
  {
    /* NATIVE indicates that there is no bridge chip present */
    psSelf->sBridgeChipInfo.bIsBridgeChipPresent = FALSE;
    MDSS_PANEL_LOG_CRITICAL_INFO("Using NATIVE DSI interface");
  }
  else
  {
    MDSS_PANEL_LOG_ERROR("confirmed not NATIVE");
    MDSS_OSAL_MemSet((char *) &sOpenParams, 0x00, sizeof(sOpenParams));
    MDSS_OSAL_StrCpy(sOpenParams.iBridgeChipID,
    BRIDGECHIP_MAX_CHIP_ID_STRING_LENGTH, psSelf->psPanelConfig->unIntfParams.sDSIConfigParams.cBridgeChipID);
    sOpenParams.uVersion = BRIDGECHIP_API_VERSION;
    MDSS_PANEL_LOG_ERROR("Open bridgechip device");
    eBCStatus = BridgeChip_Device_Open(&sOpenParams, &hDevice, 0x00);

    if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
    {
      MDSS_PANEL_LOG_ERROR("BridgeChip_device_open failed (%d)", eBCStatus);
      psSelf->sBridgeChipInfo.bIsBridgeChipPresent = FALSE;
      eRetStatus = QDI_STATUS_FAILED;
    }
    else
    {
      MDSS_PANEL_LOG_CRITICAL_INFO("Using %s bridge chip for DSI interface", sOpenParams.iBridgeChipID);
      psSelf->sBridgeChipInfo.bIsBridgeChipPresent = TRUE;
      psSelf->sBridgeChipInfo.hBridgeChip = hDevice;

      MDSS_OSAL_MemSet((char *) &sCbRegInfo, 0x00, sizeof(BridgeChip_CallbackRegisterInfo));
      sCbRegInfo.pCallback = Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipCallback;
      sCbRegInfo.uEventMask = (BRIDGECHIP_EVENT_HDCP | BRIDGECHIP_EVENT_HPD | BRIDGECHIP_EVENT_PLL
          | BRIDGECHIP_EVENT_DEVICE_RECOVERY);

      MDSS_PANEL_LOG_ERROR("Bridge chip register event callback");
      eBCStatus = BridgeChip_Register_EventCallback(psSelf->sBridgeChipInfo.hBridgeChip, &sCbRegInfo);

      if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
      {
        MDSS_PANEL_LOG_ERROR("Failed to register events, eStatus=%u", eBCStatus);
      }
    }
  }

  return eRetStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeinit()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeinit function performs the necessary
 *   cleanup operations to deinitialize the bridge chip..
 *
 * \param [in]  psSelf - Pointer to panel driver context
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeInit(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf)
{
  QDI_Status eRetStatus = QDI_STATUS_SUCCESS;
  BridgeChip_StatusType eBCStatus = BRIDGECHIP_STATUS_SUCCESS;
  BridgeChip_PropertyDataType sPropData;
  BridgeChip_CallbackRegisterInfo sCbRegInfo;

  if (psSelf->sBridgeChipInfo.bIsBridgeChipPresent)
  {
    MDSS_OSAL_MemSet((char *) &sPropData, 0x00, sizeof(BridgeChip_PropertyDataType));
    MDSS_OSAL_MemSet((char *) &sCbRegInfo, 0x00, sizeof(BridgeChip_CallbackRegisterInfo));

    /* De-register by providing a NULL CB function */
    eBCStatus = BridgeChip_Register_EventCallback(psSelf->sBridgeChipInfo.hBridgeChip, &sCbRegInfo);
    if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
    {
      MDSS_PANEL_LOG_ERROR("failed to de-register callbacks, eStatus=%u", eBCStatus);
      eRetStatus = QDI_STATUS_FAILED;
    }

    eBCStatus = BridgeChip_Device_Close(psSelf->sBridgeChipInfo.hBridgeChip, 0x00);
    if (BRIDGECHIP_STATUS_SUCCESS != eBCStatus)
    {
      MDSS_PANEL_LOG_ERROR("BridgeChip_Device_Close failed (%d)", eBCStatus);
      eRetStatus = QDI_STATUS_FAILED;
    }
  }

  return eRetStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower function powers ON/OFF
 *   the bridge chip.
 *
 * \param [in]  psSelf   - Pointer to panel driver context
 * \param [in]  bPowerOn - Power ON/OFF boolean
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_Status Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf, bool32 bPowerOn,
    uint32 uFlags)
{
  QDI_Status eQdiStatus = QDI_STATUS_FAILED;
  BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
  BridgeChip_PropertyDataType sPropData;

  MDSS_PANEL_LOG_CRITICAL_INFO("bPowerOn=%d, uFlags=0x%x", bPowerOn, uFlags);

  MDSS_OSAL_MemSet((char *) &sPropData, 0x00, sizeof(BridgeChip_PropertyDataType));
  sPropData.bPowerOn = bPowerOn;
  eStatus = BridgeChip_Device_SetProperty(psSelf->sBridgeChipInfo.hBridgeChip, BRIDGECHIP_PROPERTY_POWER, &sPropData,
      uFlags);

  if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
  {
    MDSS_PANEL_LOG_ERROR("setProperty(BRIDGECHIP_PROPERTY_POWER=%d) failed", bPowerOn);
  }
  else
  {
    eStatus = BridgeChip_Device_Commit(psSelf->sBridgeChipInfo.hBridgeChip, 0x00);
    if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
    {
      MDSS_PANEL_LOG_ERROR("bridge chip commit failed");
    }
    else
    {
      eQdiStatus = QDI_STATUS_OK;
    }
  }

  return eQdiStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_Config()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_Config function configures Panel Parameters
 *
 * \param [in]  psSelf  - Pointer to panel driver context
 * \param [in]  bEnable - Panel power ON/OFF boolean
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_Config(gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf, bool32 bEnable)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;
  DSI_PropertyParamsType sPropertyData;
  DSI_PowerStateType *pPowerCfg;

  pPowerCfg = (DSI_PowerStateType *) &sPropertyData;
  pPowerCfg->bPowerOn = bEnable;

  eStatusRet = DSI_Display_SetProperty(psSelf->hDisplayHandle, DSI_DISPLAY_PROPERTYID_POWER, &sPropertyData);
  if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
  {
    MDSS_PANEL_LOG_ERROR("DSI_Display_SetProperty(POWER %s) FAILED, eStatusRet=%d",
        ((TRUE == bEnable) ? ("ON") : ("OFF")), eStatusRet);
  }
  else
  {
    eStatusRet = DSI_Display_Commit(psSelf->hDSIHandle, 0);
    if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
    {
      MDSS_PANEL_LOG_ERROR("DSI_Display_Commit() FAILED, eStatusRet=%d", eStatusRet);
    }
    MDSS_PANEL_LOG_CRITICAL_INFO("DSI_Display_SetProperty(POWER %s)",
        ((TRUE == bEnable) ? ("ON") : ("OFF")));
  }

  return eStatusRet;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_PowerLCD()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_PowerLCD function initializes LCD panel to
 *   use display
 *
 * \param [in]  hOemHandle   - Logic handle of display control driver
 * \param [in]  bPowerEnable - Enable LCD power
 * \param [in]  uFlags       - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_PowerLCD(QDI_HandleType hOemHandle, bool32 bPowerEnable, uint32 uFlags)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;
  bool32 bSkipHwInit = (0 != (QDI_OEM_SKIP_HW_INIT & uFlags));

  MDSS_PANEL_LOG_CRITICAL_INFO(", bPowerEnable=%d, uFlags=%d, bSkipHwInit=%d", bPowerEnable, uFlags, bSkipHwInit);

  eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);
  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
     if (FALSE == bSkipHwInit)
     {
        eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_Config(psSelf, bPowerEnable);
        if (QDI_STATUS_OK != eStatusRet)
        {
          MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dsi_disp_gm_1350x810_Config() FAILED, PowerEnable=%d", bPowerEnable);
        }
     }
  }
  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    if (FALSE == bSkipHwInit)
    {
      eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower(psSelf, bPowerEnable, uFlags);
      if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
      {
        MDSS_PANEL_LOG_ERROR("Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipPower() FAILED, bPowerEnable=%d", bPowerEnable);
      }
    }
  }

  MDSS_PANEL_LOG_API_EXIT(", bPowerEnable=%d", bPowerEnable);

  return eStatusRet;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_Init()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_Init function initializes LCD panel to use
 *   display
 *
 * \param [in]  hOemHandle - Logic handle of display control driver
 * \param [in]  uFlags     - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_Init(QDI_HandleType hOemHandle, uint32 uFlags)
{
  QDI_ErrorType eStatusRet = QDI_STATUS_OK;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = NULL;
  MDSS_DrvConfig_PanelVideoTiming *psVideoTiming = NULL;
  DSI_DisplayInfoType *psDisplayInfo = NULL;
  DSI_CmdModeConfigType *psCmdModeConfg = NULL;
  DSI_VideoConfigType *psVideoModeConfg = NULL;
  DSI_VideoTimingType *psDsiVideoTiming = NULL;
  DSI_VPowerOptionType *psPowerOptions = NULL;
  MDSS_DrvConfig_DisplayNodeType **ppDispNodeList = NULL;
  MDSS_Status eDrvCfgStatus = MDSS_STATUS_SUCCESS;
  uint32 uRefreshRate = 0;
  uint32 uNumLanes = 0;
  uint32 uLaneIndex = 0;
  uint32 uNumOfDispNodes = 0;
  MDSS_DrvConfig_PanelConfigType sPanelCfgInfo;
  DSI_DeviceConfigType sDeviceConfig;
  DSI_DisplayConfigType sDisplayConfig;
  DSI_ColorFormatType eColorFormat;

  MDSS_PANEL_LOG_API_ENTER("");

  psSelf = &gPanelDrvCtx;
  psVideoTiming = &psSelf->psPanelConfig->sVideoTiming;

  MDSS_OSAL_MemZero((char *) &sPanelCfgInfo, sizeof(sPanelCfgInfo));
  sPanelCfgInfo.eDisplayId = psSelf->eDeviceId;

  eDrvCfgStatus = MDSS_DrvConfig_GetProperty(MDSS_DRVCONFIG_PROPERTY_PANEL_CONFIG, &sPanelCfgInfo);

  if (MDSS_STATUS_SUCCESS != eDrvCfgStatus)
  {
    MDSS_PANEL_LOG_WARNING("Did not find Panel Configuration. Using default config");
  }
  else
  {
    if (TRUE == sPanelCfgInfo.bIsDisplayPresent)
    {
      /* Override default settings with new settings from XML file */
      MDSS_OSAL_MemCpy(psSelf->psPanelConfig, &sPanelCfgInfo, sizeof(MDSS_DrvConfig_PanelConfigType));
    }
    else
    {
      MDSS_PANEL_LOG_WARNING("Did not find Panel Configuration. Using default config");
    }
  }

  MDSS_OSAL_MemZero((char *) &sDeviceConfig, sizeof(sDeviceConfig));

  sDeviceConfig.eDeviceID = DSI_DeviceID_0;
  sDeviceConfig.bLittleEndian = TRUE;
  sDeviceConfig.bNonCompliantMode = FALSE;
  sDeviceConfig.bEnableCRCCheck = FALSE;
  sDeviceConfig.bEnableECCCheck = FALSE;
  sDeviceConfig.bEnableClkLaneHighPwrMode = TRUE;

  eStatusRet = DSI_Device_Open(&sDeviceConfig, &psSelf->hDSIHandle);
  if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
  {
    MDSS_PANEL_LOG_ERROR("DSI_Device_Open() FAILED, eStatusret=%d", eStatusRet);
  }

  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    uRefreshRate = (psVideoTiming->uPixelFreqInHz)
        / ((psVideoTiming->uVisWidth + psVideoTiming->uHsyncBackPorch + psVideoTiming->uHsyncWidth
            + psVideoTiming->uHsyncFrontPorch)
            * (psVideoTiming->uVisHeight + psVideoTiming->uVsyncBackPorch + psVideoTiming->uVsyncWidth
                + psVideoTiming->uVsyncFrontPorch));

    MDSS_OSAL_MemZero((char *) &sDisplayConfig, sizeof(DSI_DisplayConfigType));

    psDisplayInfo = &sDisplayConfig.sDisplayInfo;
    psDisplayInfo->eChannelType = DSI_ChannelID_Video0;
    psDisplayInfo->eDisplayVC = DSI_Display_VC_0;
    switch (psVideoTiming->ePixelFormatType)
    {
      case QDI_PIXEL_FORMAT_RGB_101010_30BPP:
           eColorFormat = DSI_COLOR_RGB_101010_30BPP;
           break;
      case QDI_PIXEL_FORMAT_RGB_888_24BPP:
           eColorFormat = DSI_COLOR_RGB_888_24BPP;
           break;
      case QDI_PIXEL_FORMAT_RGB_565_16BPP:
           eColorFormat = DSI_COLOR_RGB_565_16BPP;
           break;
      default:
           MDSS_PANEL_LOG_WARNING("dsi: fall back to use RGB_888_24BPP");
           eColorFormat = DSI_COLOR_RGB_888_24BPP;
           break;
    }
    psDisplayInfo->eColorFormat = eColorFormat;
    psDisplayInfo->iVisWidthPx = psVideoTiming->uVisWidth;
    psDisplayInfo->iVisHeightPx = psVideoTiming->uVisHeight;
    psDisplayInfo->uRefreshRate = uRefreshRate;
    psDisplayInfo->uActualWidthPx = psVideoTiming->uVisWidth;
    psDisplayInfo->uActualHeightPx = psVideoTiming->uVisHeight;

    /* All lanes are initially set to NONE */
    uNumLanes = psSelf->psPanelConfig->unIntfParams.sDSIConfigParams.uNumOfLanes;
    for (uLaneIndex = 0; uLaneIndex < uNumLanes; uLaneIndex++)
    {
      switch (uLaneIndex)
      {
        case 0:
          sDisplayConfig.eDisplayLane[uLaneIndex] = DSI_LaneMap_0;
          break;
        case 1:
          sDisplayConfig.eDisplayLane[uLaneIndex] = DSI_LaneMap_1;
          break;
        case 2:
          sDisplayConfig.eDisplayLane[uLaneIndex] = DSI_LaneMap_2;
          break;
        case 3:
          sDisplayConfig.eDisplayLane[uLaneIndex] = DSI_LaneMap_3;
          break;
        default:
          sDisplayConfig.eDisplayLane[uLaneIndex] = DSI_LaneMap_NONE;
          break;
      }
    }

    psVideoModeConfg = &sDisplayConfig.sVideoModeConfg;
    psVideoModeConfg->bEnable = TRUE;
    psVideoModeConfg->eVideoTraffic = DSI_Video_TrafficMode_NonBurst_VSPulse;

    psDsiVideoTiming = &psVideoModeConfg->sVideoTiming;
    psDsiVideoTiming->iHsyncPulseWidthDclk = psVideoTiming->uHsyncWidth;
    psDsiVideoTiming->iHsyncBackPorchDclk = psVideoTiming->uHsyncBackPorch;
    psDsiVideoTiming->iHsyncFrontPorchDclk = psVideoTiming->uHsyncFrontPorch;
    psDsiVideoTiming->iHsyncSkewDclk = HSYNC_SKEW_DCLK;
    psDsiVideoTiming->iVsyncPulseWidthLines = psVideoTiming->uVsyncWidth;
    psDsiVideoTiming->iVsyncBackPorchLine = psVideoTiming->uVsyncBackPorch;
    psDsiVideoTiming->iVsyncFrontPorchLine = psVideoTiming->uVsyncFrontPorch;
    psDsiVideoTiming->iVsyncSkewDclk = VSYNC_SKEW_DCLK;
    psDsiVideoTiming->iVsyncStart = VSYNC_START;
    psDsiVideoTiming->iVsyncEnd = VSYNC_END;

    psPowerOptions = &psVideoModeConfg->sPowerOptions;
    psPowerOptions->bSendHsaHseAfterVsVe = TRUE;
    psPowerOptions->bEnableLowPowerModeInHFP = FALSE;
    psPowerOptions->bEnableLowPowerModeInHBP = FALSE;
    psPowerOptions->bEnableLowPowerModeInHSA = FALSE;
    psPowerOptions->bEnableLowPowerModeInBLLPEOF = FALSE;
    psPowerOptions->bEnableLowPowerModeInBLLP = TRUE;

    psCmdModeConfg = &sDisplayConfig.sCmdModeConfg;
    psCmdModeConfg->bEnable = FALSE;
    /* TODO: need to investigate why not working without the following */
    psCmdModeConfg->eImageTrigger = DSI_Display_ImageTrigger_NONE;
    psCmdModeConfg->eCMDTrigger = DSI_Display_CMDTrigger_SW;
    psCmdModeConfg->sExtTEConfig.eExtTEMode = DSI_ExtTEMode_NONE;
    MDSS_PANEL_LOG_WARNING("Panel Configuration width: %d,height: %d", psVideoTiming->uVisWidth,
        psVideoTiming->uVisHeight);
    eStatusRet = DSI_Display_Open(psSelf->hDSIHandle, &sDisplayConfig, &psSelf->hDisplayHandle);
    if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
    {
      MDSS_PANEL_LOG_ERROR("DSI_Display_Open() FAILED, eStatusRet=%d", eStatusRet);
    }
  }

  eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipInit(psSelf);

  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    ppDispNodeList = &psSelf->psPanelConfig->pDispNodeList;
    uNumOfDispNodes = psSelf->psPanelConfig->uNumOfDispNodes;

    /* Allocate memory for display node list */
    if (0 < uNumOfDispNodes)
    {
      *ppDispNodeList = (MDSS_DrvConfig_DisplayNodeType *)MDSS_OSAL_Malloc(sizeof(MDSS_DrvConfig_DisplayNodeType) * uNumOfDispNodes,
          MDSS_OSAL_COMP_PANEL);

      if (NULL == *ppDispNodeList)
      {
        MDSS_PANEL_LOG_ERROR("Malloc failed");
        eStatusRet = QDI_STATUS_NO_RESOURCES;
      }
      else
      {
        MDSS_OSAL_MemZero((char *) (*ppDispNodeList), sizeof(MDSS_DrvConfig_DisplayNodeType) * uNumOfDispNodes);
      }
    }
  }

  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
     eDrvCfgStatus = MDSS_DrvConfig_GetProperty(
        MDSS_DRVCONFIG_PROPERTY_PANEL_CONFIG, psSelf->psPanelConfig);

     if (MDSS_STATUS_SUCCESS != eDrvCfgStatus)
     {
        eStatusRet = QDI_STATUS_FAILED;
        MDSS_PANEL_LOG_ERROR(
           "Failed to get display nodes, error=0x%08x", eDrvCfgStatus);
     }
  }

  /* cleanup due to errors */
  if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
  {
    if ((NULL != ppDispNodeList) && (NULL != *ppDispNodeList))
    {
      MDSS_OSAL_Free(*ppDispNodeList);
      *ppDispNodeList = NULL;
    }

    Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeInit(psSelf);

    if (NULL != psSelf->hDisplayHandle)
    {
      DSI_Display_Close(psSelf->hDisplayHandle);
      psSelf->hDisplayHandle = NULL;
    }
    if (NULL != psSelf->hDSIHandle)
    {
      DSI_Device_Close(psSelf->hDSIHandle);
      psSelf->hDSIHandle = NULL;
    }
  }

  MDSS_PANEL_LOG_API_EXIT("");

  return eStatusRet;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_GetInfo()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_GetInfo function gets display info
 *
 * \param [in]  hOemHandle    - Logic handle of display control driver
 * \param [out] psDisplayAttr - Display attributes
 * \param [in]  uFlags        - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_GetInfo(QDI_HandleType hOemHandle, QDI_Panel_AttrType *psDisplayAttr,
    uint32 uFlags)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;
  uint32 iBorderColorRgb888 = 0x000000;
  uint32 iUnderflowColorRgb888 = 0xff0000;
  MDSS_DrvConfig_PanelVideoTiming *psVideoTiming = &psSelf->psPanelConfig->sVideoTiming;
  QDI_Panel_DsiVideoAttrType *pIdsivdoAttr = &(psDisplayAttr->uAttrs.sDsiVideo);

  MDSS_PANEL_LOG_API_ENTER("");

  eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);
  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    psDisplayAttr->eColorFormat = psVideoTiming->ePixelFormatType;
    psDisplayAttr->eColorComponentsPacking = QDI_COLOR_COMPONENTS_PACKING_TIGHT;
    psDisplayAttr->eColorComponentAlignment = QDI_COLOR_COMPONENT_ALIGNMENT_LSB;
    psDisplayAttr->ePhysConnect = QDI_DISPLAY_CONNECT_PRIMARY_DSI_VIDEO;
    psDisplayAttr->eDefaultTimingSource = QDI_DISPLAY_TIMINGSOURCE_DEFAULT;
    psDisplayAttr->eSynchModeTimingSource = QDI_DISPLAY_TIMINGSOURCE_DEFAULT;
    psDisplayAttr->ePanelMounting = QDI_PANEL_MOUNT_UNKNOWN;
    psDisplayAttr->iVisWidthPx = psVideoTiming->uVisWidth;
    psDisplayAttr->iVisHeightPx = psVideoTiming->uVisHeight;
    psDisplayAttr->iFrontPorchPx = psVideoTiming->uVsyncFrontPorch;
    psDisplayAttr->iBackPorchPx = psVideoTiming->uVsyncBackPorch;
    psDisplayAttr->iRefreshRowsPerSecond = ((psVideoTiming->uPixelFreqInHz) /
                                            (psVideoTiming->uVisWidth       +
                                             psVideoTiming->uHsyncWidth     +
                                             psVideoTiming->uHsyncBackPorch +
                                             psVideoTiming->uHsyncFrontPorch)
                                           );
    psDisplayAttr->uPclkFreq = (uint32)(psVideoTiming->uPixelFreqInHz);
    psDisplayAttr->sBacklight.bIsSupported = FALSE;
    psDisplayAttr->sContrast.bIsSupported = FALSE;

    pIdsivdoAttr->iDataLaneNum = psSelf->psPanelConfig->unIntfParams.sDSIConfigParams.uNumOfLanes;
    pIdsivdoAttr->iHsyncPulseWidthDclk = psVideoTiming->uHsyncWidth;
    pIdsivdoAttr->iHsyncBackPorchDclk = psVideoTiming->uHsyncBackPorch;
    pIdsivdoAttr->iHsyncFrontPorchDclk = psVideoTiming->uHsyncFrontPorch;
    pIdsivdoAttr->iHsyncSkewDclk = 0;
    pIdsivdoAttr->iVsyncPulseWidthLines = psVideoTiming->uVsyncWidth;
    pIdsivdoAttr->iBorderColorRgb888 = iBorderColorRgb888;
    pIdsivdoAttr->bDisableAutoRecovery = FALSE;
    pIdsivdoAttr->iUnderflowColorRgb888 = iUnderflowColorRgb888;
    pIdsivdoAttr->bIsDataEnableActiveLow = TRUE;
    pIdsivdoAttr->bSplitDSI = FALSE;

    psDisplayAttr->sActiveRoi.sCordXY.iPosX = 0;
    psDisplayAttr->sActiveRoi.sCordXY.iPosY = 0;
    psDisplayAttr->sActiveRoi.uWidthX = psVideoTiming->uVisWidth;
    psDisplayAttr->sActiveRoi.uHeightY = psVideoTiming->uVisHeight;
    psDisplayAttr->uPhysicalPanelWidth = 0; //TODO
    psDisplayAttr->uPhysicalPanelHeight = 0; //TODO
    psDisplayAttr->uNumOfDisplayModes = MAX_NUM_OF_DISP_MODES;
    psDisplayAttr->uNumOfAudioModes = MAX_NUM_OF_AUDIO_MODES;

    psDisplayAttr->bDualPixelMode = FALSE;
  }

  MDSS_PANEL_LOG_API_EXIT("");

  return eStatusRet;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_Term()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_Term function terminates LCD panel to use
 *   display
 *
 * \param [in]  hOemHandle - Logic handle of display control driver
 * \param [in]  uFlags     - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_Term(QDI_HandleType hOemHandle, uint32 uFlags)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;
  QDI_ErrorType eStatus = QDI_PANEL_STATUS_SUCCESS;

  MDSS_PANEL_LOG_API_ENTER("");

  Panel_gmvcu_dsi_disp_gm_1350x810_BridgeChipDeInit(psSelf);

  eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);

  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    eStatus = DSI_Display_Close(psSelf->hDisplayHandle);
    if (QDI_PANEL_STATUS_SUCCESS != eStatus)
    {
      MDSS_PANEL_LOG_ERROR("DSI_Display_Close() FAILED, eStatus=%u", eStatus);
      eStatusRet = eStatus;
    }
    psSelf->hDisplayHandle = NULL;

    eStatus = DSI_Device_Close(psSelf->hDSIHandle);
    if (QDI_PANEL_STATUS_SUCCESS != eStatus)
    {
      MDSS_PANEL_LOG_ERROR("DSI_Device_Close() FAILED, eStatus=%d", eStatus);
      eStatusRet = eStatus;
    }
    psSelf->hDSIHandle = NULL;

    if (NULL != psSelf->psPanelConfig->pDispNodeList)
    {
      MDSS_OSAL_Free(psSelf->psPanelConfig->pDispNodeList);
    }
  }

  MDSS_PANEL_LOG_API_EXIT("");

  return eStatusRet;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_InterfaceLock()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_InterfaceLock function to acquire/release
 *   lock to send data on DSI DMA Engine
 *
 * \param [in]  hOemHandle   - Logic handle of display control driver
 * \param [in]  bObtainLock  - Lock/unlock DMA on the display interface
 * \param [in]  bBlockThread - Block the thread requesting Lock
 * \param [in]  uFlags       - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_InterfaceLock(QDI_HandleType hOemHandle, bool32 bObtainLock,
    bool32 bBlockThread, uint32 uFlags)
{
  QDI_ErrorType eStatusRet = QDI_PANEL_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;
  DSI_PropertyParamsType sPropertyData;

  MDSS_PANEL_LOG_API_ENTER("");

  eStatusRet = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);
  if (QDI_PANEL_STATUS_SUCCESS == eStatusRet)
  {
    sPropertyData.sDmaEngineLockCfg.bObtainLock = bObtainLock;
    sPropertyData.sDmaEngineLockCfg.bBlockThread = bBlockThread;
    eStatusRet = DSI_Display_SetProperty(psSelf->hDisplayHandle, DSI_DISPLAY_PROPERTYID_DMA_ENGINE_LOCK,
        &sPropertyData);
    if (QDI_PANEL_STATUS_SUCCESS != eStatusRet)
    {
      MDSS_PANEL_LOG_ERROR("DSI_Display_SetProperty(DMA_ENGINE_LOCK) FAILED, eStatusRet=%d", eStatusRet);
    }
  }

  MDSS_PANEL_LOG_API_EXIT("");

  return eStatusRet;
}

/*******************************************************************************
*
** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_GetCustomAttr()
*/
/*!
* \brief
*   The \b Panel_gmvcu_dsi_disp_gm_1350x810_GetCustomAttr function retrieves display node
*   custom attribute
*
* \param [in]  hOemHandle       - Logic handle of display control driver
* \param [in]  psCustomAttrInfo - Void pointer to custom attribute parameters
* \param [in]  uFlags           - Reserved
*
* \retval QDI_ErrorType
*
*******************************************************************************/
static QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_GetCustomAttr(
   QDI_HandleType              hOemHandle,
   QDI_Panel_CustomAttrInfo   *psCustomAttrInfo,
   uint32                      uFlags)
{
   QDI_ErrorType                     eRetStatus    = QDI_STATUS_SUCCESS;
   gmvcu_dsi_disp_gm_1350x810_Ctx      *psSelf        = NULL;
   MDSS_DrvConfig_PanelConfigType   *psPanelConfig = NULL;
   uint32                           *puNumOfNodes  = NULL;
   QDI_Panel_NodeInfoType           *psNodeInfo    = NULL;
   MDSS_DrvConfig_DisplayNodeType   *psNode        = NULL;
   MDSS_DrvConfig_DispNodeAttrType  *psNodeAttribs = NULL;
   uint32                            uNodeId       = 0;
   uint32                            uI            = 0;

   MDSS_PANEL_LOG_API_ENTER(", uFlags=0x%x", uFlags);

   psSelf = &gPanelDrvCtx;

   /* Did the user pass the correct handle? */
   eRetStatus = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);
   if (QDI_STATUS_SUCCESS != eRetStatus)
   {
      eRetStatus = QDI_PANEL_STATUS_FAILED_RESOURCE_NOT_READY;
      MDSS_PANEL_LOG_ERROR(
         "Bad OEM handle(%p) or driver not initialized", hOemHandle);
   }

   if (NULL == psCustomAttrInfo)
   {
      eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
      MDSS_PANEL_LOG_ERROR("NULL psCustomAttrInfo");
   }

   if (QDI_STATUS_SUCCESS == eRetStatus)
   {
      psPanelConfig = psSelf->psPanelConfig;

      switch (psCustomAttrInfo->eAttrType)
      {
         case QDI_PANEL_CUSTOM_ATTR_NUM_OF_NODES:
         {
            puNumOfNodes = &psCustomAttrInfo->sAttrData.uNumOfNodes;
            *puNumOfNodes = psPanelConfig->uNumOfDispNodes;
            MDSS_PANEL_LOG_CRITICAL_INFO("uNumOfNodes(%u)", *puNumOfNodes);
            break;
         }

         case QDI_PANEL_CUSTOM_ATTR_NODE_INFO:
         {
            psNodeInfo = &psCustomAttrInfo->sAttrData.sNodeInfo;
            uNodeId    = psNodeInfo->uNodeId;

            if ((0 == uNodeId)                              ||
                (psPanelConfig->uNumOfDispNodes < uNodeId) )
            {
               eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
               MDSS_PANEL_LOG_ERROR("uNodeId(%u) out of bounds", uNodeId);
            }
            else
            {
               /* find node with matching node id */
               for (uI = 0; uI < psPanelConfig->uNumOfDispNodes; uI++)
               {
                  if (psPanelConfig->pDispNodeList[uI].uId == uNodeId)
                  {
                     psNode = &psPanelConfig->pDispNodeList[uI];
                     break;
                  }
               }

               /* node id not found */
               if (NULL == psNode)
               {
                  eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
                  MDSS_PANEL_LOG_ERROR("uNodeId(%u) not found", uNodeId);
               }
               else
               {
                  /* copy node info */
                  psNodeAttribs = &psNode->sAttributes;
                  psNodeInfo->uWidth                = psNodeAttribs->uVisWidth;
                  psNodeInfo->uHeight               = psNodeAttribs->uVisHeight;
                  psNodeInfo->uOffsetX              = psNodeAttribs->uOffsetX;
                  psNodeInfo->uOffsetY              = psNodeAttribs->uOffsetY;
                  psNodeInfo->bLinePadEnabled       = psNodeAttribs->bLinePadEnabled;
                  psNodeInfo->uPaddedHeight         = psNodeAttribs->uPaddedHeight;
                  psNodeInfo->uActiveLines          = psNodeAttribs->uActiveLines;
                  psNodeInfo->uPaddingLines         = psNodeAttribs->uPaddingLines;
                  psNodeInfo->bPaddingInfoSetByUser = psNodeAttribs->bPaddingInfoSetByUser;

                  MDSS_PANEL_LOG_CRITICAL_INFO("Node id(%u):",
                                               uNodeId);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uWidth          = %u",
                                               psNodeInfo->uWidth);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uHeight         = %u",
                                               psNodeInfo->uHeight);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uOffsetX        = %u",
                                               psNodeInfo->uOffsetX);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uOffsetY        = %u",
                                               psNodeInfo->uOffsetY);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   bLinePadEnabled = %u",
                                               psNodeInfo->bLinePadEnabled);
                  MDSS_PANEL_LOG_CRITICAL_INFO("   uPaddedHeight  = %u",
                                               psNodeInfo->uPaddedHeight);
                  if (TRUE == psNodeInfo->bPaddingInfoSetByUser)
                  {
                     MDSS_PANEL_LOG_CRITICAL_INFO("   uActiveLines  = %u",
                                                  psNodeInfo->uActiveLines);
                     MDSS_PANEL_LOG_CRITICAL_INFO("   uPaddingLines  = %u",
                                                  psNodeInfo->uPaddingLines);
                  }
               }
            }
            break;
         }
         default:
         {
            eRetStatus = QDI_PANEL_STATUS_FAILED_BAD_PARAM;
            MDSS_PANEL_LOG_ERROR("Custom Attribute not supported, eAttrType=%u",
                                 psCustomAttrInfo->eAttrType);
            break;
         }
      }
   }

   MDSS_PANEL_LOG_API_EXIT(", uFlags=0x%x", uFlags);
   return eRetStatus;
}

/* -----------------------------------------------------------------------------
 ** Public Functions
 ** ---------------------------------------------------------------------------*/
/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_DrvInstall()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_1_DrvInstall function installs panel driver
 *   function table
 *
 * \param [in]  hOemHandle - Logic handle of display control driver
 * \param [in]  eDeviceId  - Logic display channel
 * \param [in]  psDcFxn    - Display control function table
 * \param [in]  uFlags     - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_DrvInstall(QDI_HandleType hOemHandle, QDI_Display_IDType eDeviceId,
    QDI_Panel_FunctionTableType *psDcFxn, uint32 uFlags)
{
  QDI_ErrorType eRetStatus = QDI_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;

  MDSS_PANEL_LOG_API_ENTER(", eDeviceId=%d", eDeviceId);

  /* Did the caller provide a table to assign the functions to? */
  if (NULL == psDcFxn)
  {
    eRetStatus = QDI_PANEL_STATUS_FAILED_EXPECTED_NON_NULL_PTR;
  }

  if (NULL != psSelf->hDCHandle)
  {
    eRetStatus = QDI_PANEL_STATUS_FAILED_DRIVER_ALREADY_INITIALIZED;
  }

  if (QDI_PANEL_STATUS_SUCCESS == eRetStatus)
  {
    MDSS_OSAL_MemZero((char*) psSelf, sizeof(gmvcu_dsi_disp_gm_1350x810_Ctx));

    psSelf->psPanelConfig = &gsPanelConfig;
    psSelf->hDCHandle = hOemHandle;

    /* Save the Channel Connected */
    psSelf->eDeviceId = eDeviceId;

    psDcFxn->QDI_Panel_Init = Panel_gmvcu_dsi_disp_gm_1350x810_Init;
    psDcFxn->QDI_Panel_GetInfo = Panel_gmvcu_dsi_disp_gm_1350x810_GetInfo;
    psDcFxn->QDI_Panel_SetPower = Panel_gmvcu_dsi_disp_gm_1350x810_PowerLCD;
    psDcFxn->QDI_Panel_Term = Panel_gmvcu_dsi_disp_gm_1350x810_Term;
    psDcFxn->QDI_Panel_RegisterCallback = NULL;
    psDcFxn->QDI_Panel_DeRegisterCallback = NULL;
    psDcFxn->QDI_Panel_AcquireInterfaceLockEvent = Panel_gmvcu_dsi_disp_gm_1350x810_InterfaceLock;
    psDcFxn->QDI_Panel_GetCustomAttr = Panel_gmvcu_dsi_disp_gm_1350x810_GetCustomAttr;
    psDcFxn->QDI_Panel_SetCustomAttr = NULL;

  }
  MDSS_PANEL_LOG_ERROR("%s width:%d, height:%d", __func__, gsPanelConfig.sVideoTiming.uVisWidth,
      gsPanelConfig.sVideoTiming.uVisHeight);
  MDSS_PANEL_LOG_API_EXIT(", eDeviceId=%d", eDeviceId);

  return eRetStatus;
}

/*******************************************************************************
 *
 ** FUNCTION: Panel_gmvcu_dsi_disp_gm_1350x810_DrvUnInstall()
 */
/*!
 * \brief
 *   The \b Panel_gmvcu_dsi_disp_gm_1350x810_DrvUnInstall function uninstalls panel
 *   driver function table
 *
 * \param [in]  hOemHandle - Logic handle of display control driver
 * \param [in]  eDeviceId  - Logic display channel
 * \param [in]  psDcFxn    - Display control function table
 * \param [in]  uFlags     - Flags
 *
 * \retval QDI_ErrorType
 *
 *******************************************************************************/
QDI_ErrorType Panel_gmvcu_dsi_disp_gm_1350x810_DrvUnInstall(QDI_HandleType hOemHandle, QDI_Display_IDType eDeviceId,
    QDI_Panel_FunctionTableType *psDcFxn, uint32 uFlags)
{
  QDI_ErrorType eRetStatus = QDI_PANEL_STATUS_SUCCESS;
  gmvcu_dsi_disp_gm_1350x810_Ctx *psSelf = &gPanelDrvCtx;

  MDSS_PANEL_LOG_API_ENTER(", eDeviceId=%d", eDeviceId);

  if (NULL == psDcFxn)
  {
    eRetStatus = QDI_PANEL_STATUS_FAILED_EXPECTED_NON_NULL_PTR;
  }
  else
  {
    eRetStatus = Panel_gmvcu_dsi_disp_gm_1350x810_CheckHandle(psSelf, hOemHandle);
    if (QDI_PANEL_STATUS_SUCCESS == eRetStatus)
    {
      psDcFxn->QDI_Panel_Init = NULL;
      psDcFxn->QDI_Panel_GetInfo = NULL;
      psDcFxn->QDI_Panel_SetPower = NULL;
      psDcFxn->QDI_Panel_Term = NULL;
      psDcFxn->QDI_Panel_GetCalibrationInfo = NULL;
      psDcFxn->QDI_Panel_GetCustomAttr = NULL;
      psDcFxn->QDI_Panel_SetCustomAttr = NULL;
      psDcFxn->QDI_Panel_SetMode = NULL;

      MDSS_OSAL_MemZero((char*) psSelf, sizeof(gmvcu_dsi_disp_gm_1350x810_Ctx));
    }
  }

  MDSS_PANEL_LOG_API_EXIT(", eDeviceId=%d", eDeviceId);

  return eRetStatus;
}

#ifdef __cplusplus
}
#endif
