Display configuration with select.sh
====================================

Recent update:

1. Configration 17
    Preset Id: 0017019
    DV2/3 Cadillac 34" FF  (Mid B2/B2.5/B3)

2. Configration 13
    Preset Id: 0013146/0013147/0013148  (Mid B2/B2.5/B3)
    DV2 11.34(P/N: 84878416) + DV2 8" (P/N: 85003480)

3. Configration 15
    preset ID: 0015151  (Mid B2/B2.5/B3)
    DV2 11.34(P/N: 84878416) + DV1 11" (P/N: 13538706)

Display selection:
1. Command to list all the supported displays
----------------------------------------------
Command:

    /scripts/video-outputs/select.sh -l

Sample Console Output:

OPTION 1
        Preset Id: 0000013
        ENV: gmvcu_topology_13.env
        Description: "Mid B2: 8' SLIM SD I(Default)@DSI as IPD - 11'+ SD I (11.34)(Default)@DP as VCD"

OPTION 2
        Preset Id: 0013007
        ENV: qcdisplaycfg_gmvcu_b1-2Kx974-dp_android-1350x810-dsi_qnx.env
        Description: "Mid B2: 8' SLIM SD I(Engineering)@DSI as IPD - 11'+ SD I (11.34)(Engineering)@DP as VCD"

OPTION 3
        Preset Id: 0013008
        ENV: qcdisplaycfg_gmvcu_b1-dv1-2Kx974-dp_android-1350x810-dsi_qnx.env
        Description: "Mid B2: 8' SLIM SD I(DV1)@DSI as IPD - 11'+ SD I (11.34)(DV1)@DP as VCD"

OPTION 4
        Preset Id: 0013011
        ENV: qcdisplaycfg_gmvcu_b1-2Kx974-dp_android-1350x810-dsi_qnx.env
        Description: "Mid B2.5: 8' SLIM SD I(Engineering)@DSI as IPD - 11'+ SD I (11.34)(Engineering)@DP as VCD"

OPTION 5
        Preset Id: 0013012
        ENV: qcdisplaycfg_gmvcu_b1-dv1-2Kx974-dp_android-1350x810-dsi_qnx.env
        Description: "Mid B2.5: 8' SLIM SD I(DV1)@DSI as IPD - 11'+ SD I (11.34)(DV1)@DP as VCD"

OPTION 6
        Preset Id: 0013146
        ENV: qcdisplaycfg_gmvcu_b1-dv2-2Kx974-dp_android-1352x810-dsi_qnx.env
        Description: "Mid B2: 8' SLIM SD I(DV2)@DSI as IPD - 11'+ SD I (11.34)(DV2)@DP as VCD"

OPTION 7
        Preset Id: 0013147
        ENV: qcdisplaycfg_gmvcu_b1-dv2-2Kx974-dp_android-1352x810-dsi_qnx.env
        Description: "Mid B2.5: 8' SLIM SD I(DV2)@DSI as IPD - 11'+ SD I (11.34)(DV2)@DP as VCD"

OPTION 8
        Preset Id: 0013148
        ENV: qcdisplaycfg_gmvcu_b1-dv2-2Kx974-dp_android-1352x810-dsi_qnx.env
        Description: "Mid B3: 8' SLIM SD I(DV2)@DSI as IPD - 11'+ SD I (11.34)(DV2)@DP as VCD"

OPTION 9
        Preset Id: 0015151
        ENV: qcdisplaycfg_gmvcu-topology-15-dv2-2Kx974-dp_android-2Kx810-dsi_qnx.env
        Description: "Mid B2: 11' SLIM SD I(DV2)@DSI as IPD - 11'+ SD I (11.34)(DV2)@DP as VCD"

OPTION 10
        Preset Id: 0017017
        ENV: qcdisplaycfg_gmvcu_b1-freeform-dp_android-dsi_none.env
        Description: "Mid B2: Cadillac Freeform #1(Engineering 39Hz@24 bits)@DP as VCD"

OPTION 11
        Preset Id: 0017019
        ENV: qcdisplaycfg_gmvcu_b1-freeform-dp_android-dsi_none.env
        Description: "Mid B2.5: Cadillac Freeform #1(Engineering 39Hz@24 bits)@DP as VCD"

OPTION 12
        Preset Id: 0017069
        ENV: qcdisplaycfg_gmvcu_b2.5-cadillac-freeform-asic39-dp_android-dsi_none.env
        Description: "Mid B2.5: Cadillac Freeform #1(DV2 39HZ@24bits )@DP as VCD"

OPTION 13
        Preset Id: 0017072
        ENV: qcdisplaycfg_gmvcu_b3-cadillac-freeform-asic60-dp_android-dsi_none.env
        Description: "Mid B3: Cadillac Freeform #1(DV2 60HZ@30bits)@DP as VCD"

OPTION 14
        Preset Id: 0018021
        ENV: qcdisplaycfg_gmvcu_b1-freeform-dp_android-hud0-dsi_qnx.env
        Description: "Mid B2: Cadillac Freeform #1(Engineering 39Hz@24 bits)@DP as VCD - Slim Windshield HUD(Engineering)@DSI as HUD"

OPTION 15
        Preset Id: 0018078
        ENV: qcdisplaycfg_gmvcu_b1-freeform-dp_android-hud0-dsi_qnx.env
        Description: "Mid B2.5: Cadillac Freeform #1(Engineering 39Hz@24 bits)@DP as VCD - Slim Windshield HUD(Engineering)@DSI as HUD"

OPTION 16
        Preset Id: 0018080
        ENV: qcdisplaycfg_gmvcu_b1-freeform-dp_android-hud0-dsi_qnx.env
        Description: "Mid B3: Cadillac Freeform #1(Engineering 39Hz@24 bits)@DP as VCD - Slim Windshield HUD(Engineering)@DSI as HUD"

OPTION 17
        Preset Id: 0022027
        ENV: qcdisplaycfg_gmvcu_b1-buick-freeform-dp_android-dsi_none.env
        Description: "Mid B2: Buick Freeform #1(Engineering)@DP as IPD"

OPTION 18
        Preset Id: 0022028
        ENV: qcdisplaycfg_gmvcu_b1-buick-freeform-dp_android-dsi_none.env
        Description: "Mid B2.5: Buick Freeform #1(Engineering)@DP as IPD"

OPTION 19
        Preset Id: 0200035
        ENV: qcdisplaycfg_gmvcu_b1-bosch-dp_android_dsi-qnx.env
        Description: "Mid B2: Bosch(Default)@DSI as IPD - Bosch(Default)@DP as VCD"

OPTION 20
        Preset Id: 0200036
        ENV: qcdisplaycfg_gmvcu_b1-bosch-dp_android_dsi-qnx.env
        Description: "Mid B2.5: Bosch(Default)@DSI as IPD - Bosch(Default)@DP as VCD"

OPTION 21
        Preset Id: 0200047
        ENV: qcdisplaycfg_gmvcu_b1-hd1080d-dp_android-dsi_qnx.env
        Description: "Mid B2: Innolux 10'(Default)@DSI as IPD - Innolux 10'(Default)@DP as VCD"

OPTION 22
        Preset Id: 0200048
        ENV: qcdisplaycfg_gmvcu_b1-hd1080d-dp_android-dsi_qnx.env
        Description: "Mid B2.5: Innolux 10'(Default)@DSI as IPD - Innolux 10'(Default)@DP as VCD"

OPTION 23
        Preset Id: 0200067
        ENV: qcdisplaycfg_gmvcu_b1-alpine-hd1080d-dp_android-dsi_qnx.env
        Description: "Mid B2: Alpine 10'(Default)@DSI as IPD - Alpine 10'(Default)@DP as VCD"

OPTION 24
        Preset Id: 0200068
        ENV: qcdisplaycfg_gmvcu_b1-alpine-hd1080d-dp_android-dsi_qnx.env
        Description: "Mid B2.5: Alpine 10'(Default)@DSI as IPD - Alpine 10'(Default)@DP as VCD"

OPTION 25
        Preset Id: 0200062
        ENV: qcdisplaycfg_gmvcu_b1-tianma-2Kx974-dp_android-2Kx810-dsi_qnx.env
        Description: "Mid B2: 11' SLIM SD T(Engineering)@DP as IPD - 11'+ SD T (11.34)(Engineering)@DP as VCD"

OPTION 26
        Preset Id: 0200063
        ENV: qcdisplaycfg_gmvcu_b1-tianma-2Kx974-dp_android-2Kx810-dsi_qnx.env
        Description: "Mid B2.5: 11' SLIM SD T(Engineering)@DP as IPD - 11'+ SD T (11.34)(Engineering)@DP as VCD"

2. Command to check the current selected display
-------------------------------------------------
Command:

    /scripts/video-outputs/select.sh -c

Sample Console output:

        Preset Id: 0000255
        ENV: qcdisplaycfg_gmvcu_b1-bosch-dp_android_dsi-qnx.env
        Description: "Mid B1: Bosch(Default)@DSI as IPD - Bosch(Default)@DP as VCD"

Note: By default, the target will be configured to use Bosch display for android and QNX

3. Command to select a display
------------------------------
For example if we want to configure the target to use 8' SLIM SD I(Engineering) for QNX and 11'SD I (11.34)(Engineering) display for
Android we have to choose the following configuration

OPTION 5
        Preset Id: 0013003
        ENV: qcdisplaycfg_gmvcu_b1-2Kx974-dp_android-1350x810-dsi_qnx.env
        Description: "Mid B1: 8' SLIM SD I(Engineering)@DSI as IPD - 11'+ SD I (11.34)(Engineering)@DP as VCD"

We can do it by any one of the two following commandqcdisplaycfg_gmvcu_b1-hd1080d-dp_android-dsi_qnx.env



Using preset ID

Command:

    /scripts/video-outputs/select.sh -s 0013003

OR

Using environment name

Command:

    /scripts/video-outputs/select.sh -s qcdisplaycfg_gmvcu_b1-2Kx974-dp_android-1350x810-dsi_qnx.env

Now reboot the target. For the next power cycle the target will choose the new configuration

4. To reset the display configuration to default
-------------------------------------------------
Command:

    /scripts/video-outputs/select.sh -r

Now the target will boot up in the next power cycle with default display configuration which right now is Bosch displays.
