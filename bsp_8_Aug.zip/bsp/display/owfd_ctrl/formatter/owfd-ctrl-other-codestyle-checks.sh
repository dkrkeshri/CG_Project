grep_file_pattern="--include=*.cpp --include=*.h"

echo -e "------------------------------------------------------------"
echo -e "- Check memory allocation/deallocation API: (replace with alloc_data/clear_data)"
        grep -rnE '\<malloc\>|\<calloc\>|\<free\>|\<realloc\>' $grep_file_pattern
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "- Check string comparison:"
        grep -rn 'strcmp' $grep_file_pattern | grep -v "EQUAL"
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "- Check for single token condition"
        grep -rn "if (" $grep_file_pattern | grep -E -v \
        ' !=| ==|, | < | > | <= | >= | & '
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo    "- Check for \n absence in logs"
        grep -rn 'LOG_' $grep_file_pattern | grep -vE '\\n|LOG\(' \
        | grep -E '",|"\)'
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo    "- Check for redudant '.' at the end of the logs"
        grep -rn 'LOG_' $grep_file_pattern | grep -E '\.\\n' | grep -v '\.\.\.'
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "- Check assignments inside conditions"
        grep -rn 'if (' $grep_file_pattern | grep -E ' = '
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "- Check whitespace after if|while|for"
        grep -rnE 'if\(|while\(|for\(' $grep_file_pattern
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "- Check for \` apostrophe (replace with ')"
        grep -rnE 'n`t' $grep_file_pattern
echo -e "------------------------------------------------------------\n"

echo -e "------------------------------------------------------------"
echo -e "Not automated yet: (nice to check yourself)"
echo -e "- Add logs to single line if statements"
echo -e "- Check rvalue constants comparison (change them to lvalue)"
echo -e "------------------------------------------------------------\n"
