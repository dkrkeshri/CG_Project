/**
 * @file       owfd-ctrl-log.h
 * @brief      Logging API
 *
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_LOG_H__
#define __OWFD_CTRL_LOG_H__

#include <cstdarg>
#include <cstring>
#include <exception>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/slog2.h>

#ifdef __cplusplus
}
#endif

#include "owfd-ctrl-error.h"

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
#define LOG(logLevel, msg, fmt, ...)                                            \
        do {                                                                    \
                try {                                                           \
                        OwfdCtrlLog::getLogger().logging(logLevel, "[%s:%d:%s] "\
                                "%s" fmt, fileNameToPath(__FILE__).c_str(),     \
                                __LINE__, __func__, msg, ## __VA_ARGS__);       \
                } catch (std::exception &e) {                                   \
                        OwfdCtrlLog::oc_printf("Got exception in the "          \
                                               "OwfdCtrlLog logger: %s\n",      \
                                               e.what());                       \
                }                                                               \
        } while (0)                                                             \
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

enum VerboseLevel {
        VERBOSE_LEVEL_0,
        VERBOSE_LEVEL_1,
        VERBOSE_LEVEL_2,
        VERBOSE_LEVEL_3
};

#define LOG_E(fmt, ...)           LOG(VERBOSE_LEVEL_1, "Err:", fmt,             \
                                      ## __VA_ARGS__)
#define LOG_I(fmt, ...)           LOG(VERBOSE_LEVEL_2, "Info:", fmt,            \
                                      ## __VA_ARGS__)
#define LOG_D(fmt, ...)           LOG(VERBOSE_LEVEL_3, "Dbg:", fmt,             \
                                      ## __VA_ARGS__)

inline
std::string fileNameToPath(std::string filePath)
{
        return (std::string::npos == filePath.find('/')) ? filePath :
                filePath.substr(filePath.find_last_of('/') + 1);
}

class OwfdCtrlLog
{
public:
        static OwfdCtrlLog &getLogger();
        static void oc_printf(const char *fmt, ...);
        oc_err_t init(std::string buffName = DEFAULT_BUFF_NAME);
        void logging(VerboseLevel verbosity, const char *fmt, ...);

        OwfdCtrlLog(const OwfdCtrlLog &) = delete;
        OwfdCtrlLog &operator=(const OwfdCtrlLog &) = delete;

private:
        slog2_buffer_t slog2BuffHandler;
        static constexpr auto DEFAULT_BUFF_NAME = "owfd_ctrl";
        static constexpr int SLOG2_DEFAULT_NUM_PAGES = 2;

        OwfdCtrlLog();
        ~OwfdCtrlLog()
        {

        }

        unsigned getLogLevel(VerboseLevel confLogLevel);
};

#endif /* __OWFD_CTRL_LOG_H__ */

