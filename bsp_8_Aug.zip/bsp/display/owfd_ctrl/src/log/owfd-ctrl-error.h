/**
 * @file       owfd-ctrl-error.h
 * @brief      Definition of errors, that are used to control/inform
 *             the result of OWFD control component functions
 *
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_ERROR_H__
#define __OWFD_CTRL_ERROR_H__

#include <cstdint>
#include <string>

#define OC_ERROR_PREFIX        0xFFFF0000

typedef int32_t oc_err_t;

namespace oc_retcode_str {

constexpr auto SUCCESS =
        "Operation/request was successful\t";
constexpr auto EXCEPTION =
        "Exception occurred\t";
constexpr auto OOM =
        "Out of memory error\t";
constexpr auto INVALID_PARAMETER =
        "Invalid parameter specified\t";
constexpr auto INIT_FAILED =
        "Initialization failed\t";
constexpr auto CONFIG_ERROR =
        "Configuration parsing error\t";
constexpr auto DEVICE_FAILURE =
        "Device failure\t";
constexpr auto DEVICE_OFFLINE =
        "Device is offline. Device API is not available in this mode\t";
constexpr auto SCREEN_FAILURE =
        "Screen API operation or wrapper failure\t";
constexpr auto RES_MGR_FAILURE =
        "Resource manager failure\t";

} /* namespace oc_retcode_str */

constexpr int32_t toRetCode(int x)
{
        return (int32_t)(OC_ERROR_PREFIX | (1 << x));
}

typedef enum {
        OC_SUCCESS           = 0x00000000,
        OC_EXCEPTION         = toRetCode(0),
        OC_OOM               = toRetCode(1),
        OC_INVALID_PARAMETER = toRetCode(2),
        OC_INIT_FAILED       = toRetCode(3),
        OC_CONFIG_ERROR      = toRetCode(4),
        OC_DEVICE_FAILURE    = toRetCode(5),
        OC_DEVICE_OFFLINE    = toRetCode(6),
        OC_SCREEN_FAILURE    = toRetCode(7),
        OC_RES_MGR_FAILURE   = toRetCode(8),
} oc_retcode_t;

inline
bool isErrorPresent(oc_err_t error, oc_retcode_t code)
{
        return error & code & (~OC_ERROR_PREFIX);
}

std::string errorToString(oc_err_t error);

#endif /* __OWFD_CTRL_ERROR_H__ */

