/**
 * @file       owfd-ctrl-error.cpp
 * @brief      Error processing functions (convert error code to string, etc)
 *
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include "owfd-ctrl-error.h"

std::string errorToString(oc_err_t error)
{
        std::string errorString;

        if (OC_SUCCESS == error) {
                return oc_retcode_str::SUCCESS;
        }

        if (isErrorPresent(error, OC_EXCEPTION)) {
                errorString += oc_retcode_str::EXCEPTION;
        }

        if (isErrorPresent(error, OC_OOM)) {
                errorString += oc_retcode_str::OOM;
        }

        if (isErrorPresent(error, OC_INVALID_PARAMETER)) {
                errorString += oc_retcode_str::INVALID_PARAMETER;
        }

        if (isErrorPresent(error, OC_INIT_FAILED)) {
                errorString += oc_retcode_str::INIT_FAILED;
        }

        if (isErrorPresent(error, OC_CONFIG_ERROR)) {
                errorString += oc_retcode_str::CONFIG_ERROR;
        }

        if (isErrorPresent(error, OC_DEVICE_FAILURE)) {
                errorString += oc_retcode_str::DEVICE_FAILURE;
        }

        if (isErrorPresent(error, OC_DEVICE_OFFLINE)) {
                errorString += oc_retcode_str::DEVICE_OFFLINE;
        }

        if (isErrorPresent(error, OC_SCREEN_FAILURE)) {
                errorString += oc_retcode_str::SCREEN_FAILURE;
        }

        if (isErrorPresent(error, OC_RES_MGR_FAILURE)) {
                errorString += oc_retcode_str::RES_MGR_FAILURE;
        }

        return errorString;
}

