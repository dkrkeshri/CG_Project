/**
 * @file       owfd-ctrl-log.cpp
 * @brief      Logging API
 *
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include "owfd-ctrl-log.h"

OwfdCtrlLog::OwfdCtrlLog()
{
        init();
}

OwfdCtrlLog &OwfdCtrlLog::getLogger()
{
        static OwfdCtrlLog logger;

        return logger;
}

void OwfdCtrlLog::oc_printf(const char *fmt, ...)
{
#if defined(CONFIG_OC_PRINT_STDOUT) && CONFIG_OC_PRINT_STDOUT == 1
        va_list args;
        va_start(args, fmt);

        vprintf(fmt, args);

        va_end(args);
#endif
}

unsigned OwfdCtrlLog::getLogLevel(VerboseLevel confLogLevel)
{
        unsigned slog2LogLevel = SLOG2_SHUTDOWN;

        switch (confLogLevel) {
        case VERBOSE_LEVEL_0:
                slog2LogLevel = SLOG2_SHUTDOWN;

                break;
        case VERBOSE_LEVEL_1:
                slog2LogLevel = SLOG2_ERROR;

                break;
        case VERBOSE_LEVEL_2:
                slog2LogLevel = SLOG2_INFO;

                break;
        case VERBOSE_LEVEL_3:
        default:
                slog2LogLevel = SLOG2_DEBUG1;
        }

        return slog2LogLevel;
}

oc_err_t OwfdCtrlLog::init(std::string buffName)
{
#if defined(CONFIG_DEBUG_SLOGGER2) && CONFIG_DEBUG_SLOGGER2 == 1
        slog2_buffer_t tmpBuffHandler = nullptr;
        slog2_buffer_set_config_t buffConfig = {0};

        tmpBuffHandler = slog2_find_buffer(buffName.c_str(), nullptr);
        if (nullptr != tmpBuffHandler) {
                slog2BuffHandler = tmpBuffHandler;

                return OC_SUCCESS;
        }

        buffConfig.buffer_set_name = buffName.c_str();
        buffConfig.num_buffers = 1;
#if defined(CONFIG_VERBOSE_LEVEL)
        buffConfig.verbosity_level =
                getLogLevel((VerboseLevel)CONFIG_VERBOSE_LEVEL);
#else
        buffConfig.verbosity_level = SLOG2_SHUTDOWN;
#endif
        buffConfig.buffer_config[0].buffer_name = buffName.c_str();
#if defined(CONFIG_SLOG2_NUM_PAGES) && CONFIG_SLOG2_NUM_PAGES != 0
        buffConfig.buffer_config[0].num_pages = CONFIG_SLOG2_NUM_PAGES;
#else
        buffConfig.buffer_config[0].num_pages = SLOG2_DEFAULT_NUM_PAGES;
#endif

        if (-1 == slog2_register(&buffConfig, &slog2BuffHandler, 0)) {
                return OC_INIT_FAILED;
        }
#endif

        return OC_SUCCESS;
}

void OwfdCtrlLog::logging(VerboseLevel verbosity, const char *fmt, ...)
{
        if (nullptr == fmt) {
                LOG_E("Invalid input: fmt = %p\n", fmt);

                return;
        }

#if defined(CONFIG_VERBOSE_LEVEL)
#if defined(CONFIG_DEBUG_SLOGGER2) && CONFIG_DEBUG_SLOGGER2 == 1
        va_list args;
        va_start(args, fmt);

        vslog2f(slog2BuffHandler, 0, getLogLevel(verbosity), fmt, args);

        va_end(args);
#endif
#endif
}

