/**
 * @file       owfd-ctrl-parser.cpp
 * @brief      ConfData class implementation
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <new>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#include "owfd-ctrl-common.h"
#include "owfd-ctrl-core.h"
#include "owfd-ctrl-log.h"
#include "owfd-ctrl-parser.h"
#include "smalljs.h"

ConfData::~ConfData()
{
        std::vector<class DevData *>::iterator it;

        LOG_D("Called\n");

        for (it = devs.begin(); it != devs.end(); ++it) {
                delete (*it);
        }

        devs.clear();
}

/**
 * Load and parse a config file, create the ConfData item,
 * and place all usable values from the config inside of it.
 */
ConfData *ConfData::parse_config(const char *filename)
{
        char *buff = nullptr;
        int err = EOK;
        JSDataNode *js_data = nullptr;
        std::string err_msg;
        ConfData *cfg_data = nullptr;
        oc_err_t rc = OC_SUCCESS;
        bool is_loaded = false;

        if (nullptr == filename) {
                LOG_E("Invalid input: filename = %p\n", filename);

                goto parse_cfg_failed;
        }

        LOG_D("Loading and parsing configuration file: %s\n", filename);

        buff = load_textfile(filename, &err);
        if (nullptr == buff) {
                LOG_E("Failed to load configuration file: %s. Error: %s\n",
                      filename, strerror(err));

                goto parse_cfg_failed;
        }

        js_data = parse_json(buff, &err_msg);
        if (nullptr == js_data) {
                LOG_E("Failed to parse JSON config data. Error: %s\n",
                      err_msg.c_str());

                goto parse_cfg_failed;
        }

        if (JSTYPE_object != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("JSON config top level must be an object (type = %d)\n",
                      (int)JSTYPE_object);

                goto parse_cfg_failed;
        }

        cfg_data = new (std::nothrow) ConfData();
        if (nullptr == cfg_data) {
                LOG_E("Failed to allocate ConfData object\n");

                goto parse_cfg_failed;
        }

        /* Peel out parts we need */
        rc = cfg_data->extract_data_from_json((JSDataNodeObject *)js_data);
        if (OC_SUCCESS != rc) {
                LOG_E("Failed to parse config file. Error: %s\n",
                      errorToString(rc).c_str());

                goto parse_cfg_failed;
        }

        is_loaded = true;

        LOG_D("Config loaded and parsed\n");

parse_cfg_failed:
        if (nullptr != buff) {
                free(buff);
                buff = nullptr;
        }

        if (nullptr != js_data) {
                delete js_data;
                js_data = nullptr;
        }

        if (nullptr != cfg_data && false == is_loaded) {
                delete cfg_data;
                cfg_data = nullptr;

                return nullptr;
        }

        return cfg_data;
}

void ConfData::print_cfg_data(void)
{
        std::vector<class DevData *>::const_iterator it;

        LOG_I("Configuration file data:\n");
        LOG_I("Logfile path        : %s\n", logfile.c_str());
        LOG_I("Debuglevel          : %d\n", (int)debuglevel);
        LOG_I("Allow 'quit' command: %s\n", OC_BOOL_TO_STR(allow_quit));

        for (it = devs.begin(); it != devs.end(); ++it) {
                LOG_I("Device name    :  %s\n", (*it)->name.c_str());
                LOG_I("Status devpath :  %s\n", (*it)->status_path.c_str());
                LOG_I("Control devpath:  %s\n", (*it)->control_path.c_str());
        }
}

ConfData::ConfData()
{
        LOG_D("Called\n");

        logfile = OC_LOGFILENAME_DEFAULT_STR;
        use_slog2 = OC_USE_SLOG2_DEFAULT;
        debuglevel = OC_DEBUGLEVEL_DEFAULT;
        allow_quit = OC_ALLOW_CMD_QUIT_DEFAULT;
        highest_index = 0;
}

/**
 * Process the parsed JSON data from the config file.
 * All usable values found are placed into the fields in the class' instance.
 */
oc_err_t ConfData::extract_data_from_json(class JSDataNodeObject *js)
{
        JSDataNode *js_data = nullptr;
        JSDataNodeArray *js_data_arr = nullptr;
        unsigned int i = 0;
        JSDataNodeObject *js_data_obj = nullptr;
        DevData *dev_data = nullptr;

        if (nullptr == js) {
                LOG_E("Invalid input: js = %p\n", js);

                return OC_INVALID_PARAMETER;
        }

        js_data = js->get("logfile");
        if (nullptr != js_data) {
                if (JSTYPE_string != js_data->type) {
                        LOG_E("Invalid JSON data type: type = %d\n",
                              (int)js_data->type);
                        LOG_E("Optional path to logfile must be a string (type "
                              "= %d)\n", (int)JSTYPE_string);

                        return OC_CONFIG_ERROR;
                }

                logfile = ((JSDataNodeString *)js_data)->text;

                LOG_D("Got path to logfile: logfile = %s\n", logfile.c_str());
        }

        js_data = js->get("slog2");
        if (nullptr != js_data) {
                if (JSTYPE_bool != js_data->type) {
                        LOG_E("Invalid JSON data type: type = %d\n",
                              (int)js_data->type);
                        LOG_E("Optional slog2 usage specifying value must be a "
                              "bool (type = %d)\n", (int)JSTYPE_bool);

                        return OC_CONFIG_ERROR;
                }

                use_slog2 = ((JSDataNodeBool *)js_data)->flag;

                LOG_D("Got slog2 usage: use_slog2 = %s\n",
                      OC_BOOL_TO_STR(use_slog2));
        }

        js_data = js->get("devices");
        if (nullptr == js_data) {
                LOG_E("Failed to parse devices, config needs it on the top "
                      "level\n");

                return OC_CONFIG_ERROR;
        }

        if (JSTYPE_array != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Devices must be an array (type = %d)\n",
                      (int)JSTYPE_array);

                return OC_CONFIG_ERROR;
        }

        js_data_arr = (JSDataNodeArray *)js_data;

        highest_index = 0;

        for (i = 0; i < js_data_arr->count(); i++) {
                js_data = js_data_arr->get(i);
                if (nullptr == js_data) {
                        LOG_E("Failed to parse item [%d] under devices\n", i);

                        return OC_CONFIG_ERROR;
                }

                if (JSTYPE_object != js_data->type) {
                        LOG_E("Invalid JSON data type: type = %d\n",
                              (int)js_data->type);
                        LOG_E("Item [%d] under devices must be an object (type "
                              "= %d)\n", i, (int)JSTYPE_object);

                        return OC_CONFIG_ERROR;
                }

                js_data_obj = (JSDataNodeObject *)js_data;

                dev_data = extract_devicedata_from_json(js_data_obj);
                if (nullptr == dev_data) {
                        LOG_E("Failed to extract device [%d] data from JSON "
                              "config\n", i);

                        return OC_CONFIG_ERROR;
                }

                try {
                        devs.push_back(dev_data);
                } catch (std::exception &e) {
                        LOG_E("Got an exception while adding device data into "
                              "a vector: %s\n", e.what());

                        return OC_EXCEPTION;
                }
        }

        LOG_D("Config data extracted\n");

        return OC_SUCCESS;
}

ConfData::DevData *ConfData::extract_devicedata_from_json(
        class JSDataNodeObject *js)
{
        DevData *dev_data = nullptr;
        JSDataNode *js_data = nullptr;
        JSDataNodeArray *js_data_arr = nullptr;
        JSDataNodeObject *js_data_obj = nullptr;
        unsigned int i = 0;
        DisplData *disp_data = nullptr;
        bool is_extracted = false;

        if (nullptr == js) {
                LOG_E("Invalid input: js = %p\n", js);

                return nullptr;
        }

        dev_data = new (std::nothrow) DevData();
        if (nullptr == dev_data) {
                LOG_E("Failed to allocate DevData object\n");

                return nullptr;
        }

        dev_data->up = this;

        js_data = js->get("name");
        if (nullptr == js_data) {
                LOG_E("Failed to parse device name\n");

                goto extract_data_failed;
        }

        if (JSTYPE_string != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Device name must be a string (type = %d)\n",
                      (int)JSTYPE_string);

                goto extract_data_failed;
        }

        dev_data->name = ((JSDataNodeString *)js_data)->text;

        LOG_D("Got device name: name = %s\n", dev_data->name.c_str());

        /* Get resource manager paths for status and control nodes */
        js_data = js->get("device-nodes");
        if (nullptr == js_data) {
                LOG_E("Failed to parse device nodes\n");

                goto extract_data_failed;
        }

        if (JSTYPE_object != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Device nodes must be an object (type = %d)\n",
                      (int)JSTYPE_object);

                goto extract_data_failed;
        }

        js_data_obj = (JSDataNodeObject *)js_data;

        js_data = js_data_obj->get("status");
        if (nullptr == js_data) {
                LOG_E("Failed to parse device status node path\n");

                goto extract_data_failed;
        }

        if (JSTYPE_string != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Device status node path must be a string (type = %d)\n",
                      (int)JSTYPE_string);

                goto extract_data_failed;
        }

        dev_data->status_path = ((JSDataNodeString *)js_data)->text;

        LOG_D("Got device status node path: status_path = %s\n",
              dev_data->status_path.c_str());

        js_data = js_data_obj->get("control");
        if (nullptr == js_data) {
                LOG_E("Failed to parse device control node path\n");

                goto extract_data_failed;
        }

        if (JSTYPE_string != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Device control node path must be a string (type = %d)\n",
                      (int)JSTYPE_string);

                goto extract_data_failed;
        }

        dev_data->control_path = ((JSDataNodeString *)js_data)->text;

        LOG_D("Got device control node path: control_path = %s\n",
              dev_data->control_path.c_str());

        /* Get displays list */
        js_data = js->get("displays");
        if (nullptr == js_data) {
                LOG_E("Failed to parse displays\n");

                goto extract_data_failed;
        }

        if (JSTYPE_array != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Displays must be an array (type = %d)\n",
                      (int)JSTYPE_array);

                goto extract_data_failed;
        }

        js_data_arr = (JSDataNodeArray *)js_data;

        for (i = 0; i < js_data_arr->count(); i++) {
                js_data = js_data_arr->get(i);
                if (nullptr == js_data) {
                        LOG_E("Failed to parse item [%d] under displays\n", i);

                        goto extract_data_failed;
                }

                if (JSTYPE_object != js_data->type) {
                        LOG_E("Invalid JSON data type: type = %d\n",
                              (int)js_data->type);
                        LOG_E("Item [%d] under displays must be an object "
                              "(type = %d)\n", i, (int)JSTYPE_object);

                        goto extract_data_failed;
                }

                js_data_obj = (JSDataNodeObject *)js_data;

                disp_data = extract_displaydata_from_json(js_data_obj);
                if (nullptr == disp_data) {
                        LOG_E("Failed to extract display [%d] data from JSON "
                              "config\n", i);

                        goto extract_data_failed;
                }

                try {
                        dev_data->displays.push_back(disp_data);
                } catch (std::exception &e) {
                        LOG_E("Got an exception while adding display data into "
                              "a vector: %s\n", e.what());

                        goto extract_data_failed;
                }
        }

        is_extracted = true;

        LOG_D("Device data extracted\n");

extract_data_failed:
        if (false == is_extracted) {
                delete dev_data;
                dev_data = nullptr;

                return nullptr;
        }

        return dev_data;
}

ConfData::DisplData *ConfData::extract_displaydata_from_json(
        class JSDataNodeObject *js)
{
        DisplData *disp_data = nullptr;
        JSDataNode *js_data = nullptr;
        bool is_extracted = false;

        if (nullptr == js) {
                LOG_E("Invalid input: js = %p\n", js);

                return nullptr;
        }

        disp_data = new (std::nothrow) DisplData();
        if (nullptr == disp_data) {
                LOG_E("Failed to allocate DisplData object\n");

                return nullptr;
        }

        js_data = js->get("name");
        if (nullptr == js_data) {
                LOG_E("Failed to parse display name\n");

                goto extract_data_failed;
        }

        if (JSTYPE_string != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Display name must be a string (type = %d)\n",
                      (int)JSTYPE_string);

                goto extract_data_failed;
        }

        disp_data->name = ((JSDataNodeString *)js_data)->text;

        LOG_D("Got display name: name = %s\n", disp_data->name.c_str());

        js_data = js->get("screen-index");
        if (nullptr == js_data) {
                LOG_E("Failed to parse display screen index\n");

                goto extract_data_failed;
        }

        if (JSTYPE_number != js_data->type) {
                LOG_E("Invalid JSON data type: type = %d\n",
                      (int)js_data->type);
                LOG_E("Display screen index must be a number (type = %d)\n",
                      (int)JSTYPE_number);

                goto extract_data_failed;
        }

        disp_data->index = (int)(((JSDataNodeNumber *)js_data)->number);

        LOG_D("Got display screen index: index = %d\n", disp_data->index);

        if (disp_data->index < OC_DISP_DATA_INDEX_MIN ||
            disp_data->index > OC_DISP_DATA_INDEX_MAX) {
                LOG_E("Got invalid display screen index: index = %d\n",
                      disp_data->index);
                LOG_E("Index must be in range [%d, %d]\n",
                      OC_DISP_DATA_INDEX_MIN, OC_DISP_DATA_INDEX_MAX);

                goto extract_data_failed;
        }

        if (disp_data->index > highest_index) {
                highest_index = disp_data->index;

                LOG_D("Got display screen index currently is the highest: "
                      "highest_index = %d\n", highest_index);
        }

        is_extracted = true;

        LOG_D("Display data extracted\n");

extract_data_failed:
        if (false == is_extracted) {
                delete disp_data;
                disp_data = nullptr;

                return nullptr;
        }

        return disp_data;
}

ConfData::DevData::~DevData()
{
        std::vector<DisplData *>::iterator it;

        LOG_D("Called\n");

        for (it = displays.begin(); it != displays.end(); ++it) {
                delete (*it);
        }

        displays.clear();
}

char *load_textfile(const char *filename, int *out_errno)
{
        int fh = -1;
        off_t fsize = -1;
        bool ret_null = false;
        off_t set_rc = -1;
        char *res = nullptr;
        off_t left_to_read = 0;
        int tmp_err = EOK;
        int rc = EOK;

        if (nullptr == filename) {
                LOG_E("Invalid input: filename = %p\n", filename);

                return nullptr;
        }

        LOG_D("Loading text file: filename = %s\n", filename);

        fh = open(filename, O_RDONLY);
        if (fh < 0) {
                LOG_E("Failed to open a filehandle: filename = %s. Error: %s\n",
                      filename, strerror(errno));

                *out_errno = errno;

                return nullptr;
        }

        fsize = lseek(fh, 0, SEEK_END);
        if (-1 == fsize) {
                LOG_E("Failed to get a filesize. Error: %s\n", strerror(errno));

                *out_errno = errno;
                ret_null = true;

                goto close_fh;
        }

        left_to_read = fsize;

        set_rc = lseek(fh, 0, SEEK_SET);
        if (-1 == set_rc) {
                LOG_E("Failed to set the file offset to the beginning. Error: "
                      "%s\n", strerror(errno));

                *out_errno = errno;
                ret_null = true;

                goto close_fh;
        }

        if (fsize < OC_TEXTFILE_SIZE_MIN || fsize > OC_TEXTFILE_SIZE_MAX) {
                LOG_E("Got invalid filesize: fsize = %ld. Error: %s\n",
                      fsize, strerror(EINVAL));
                LOG_E("Filesize must be in range [%d, %d]\n",
                      OC_TEXTFILE_SIZE_MIN, OC_TEXTFILE_SIZE_MAX);

                *out_errno = EINVAL;
                ret_null = true;

                goto close_fh;
        }

        res = (char *)calloc(fsize + OC_TEXTFILE_NULL_BYTES_ADD_NUM,
                             sizeof(char));
        if (nullptr == res) {
                LOG_E("Failed to allocate space for data read buffer. Error: "
                      "%s\n", strerror(ENOMEM));

                *out_errno = ENOMEM;
                ret_null = true;

                goto close_fh;
        }

        left_to_read -= read(fh, res, fsize);

        tmp_err = errno;

close_fh:
        rc = close(fh);
        if (-1 == rc) {
                LOG_E("Failed to close the file. Error: %s\n", strerror(errno));

                *out_errno = errno;

                goto load_failed;
        }

        fh = 0;

        if (true == ret_null) {
                goto load_failed;
        }

        if (0 != left_to_read) {
                *out_errno = tmp_err;
                if (EOK != tmp_err) {
                        *out_errno = EIO;
                }

                LOG_E("Failed to load file data: left_to_read = %ld. Error: "
                      "%s\n", left_to_read, strerror(*out_errno));

                goto load_failed;
        }

        res[fsize] = '\0';

        LOG_D("File loaded\n");

        return res;

load_failed:
        if (nullptr != res) {
                free(res);
                res = nullptr;
        }

        return nullptr;
}

