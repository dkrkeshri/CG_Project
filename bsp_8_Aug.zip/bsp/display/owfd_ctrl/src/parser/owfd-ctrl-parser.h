/**
 * @file       owfd-ctrl-parser.h
 * @brief      Header for ConfData class, with nested DisplData and DevData
 *             classes
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_PARSER_H__
#define __OWFD_CTRL_PARSER_H__

#include <string>
#include <vector>

#include "owfd-ctrl-error.h"
#include "txt_resmgr_base.h"

#define OC_DISP_DATA_INDEX_MIN          0
#define OC_DISP_DATA_INDEX_MAX          0xFFFF

#define OC_TEXTFILE_SIZE_MIN            1
#define OC_TEXTFILE_SIZE_MAX            0x100000
#define OC_TEXTFILE_NULL_BYTES_ADD_NUM  1

class ConfData
{
public:
        ~ConfData();

        std::string logfile;
        bool use_slog2;
        unsigned char debuglevel;
        bool allow_quit;

        class DisplData
        {
        public:
                std::string name;
                int index;
        };

        class DevData
        {
        public:
                ~DevData();

                std::string name;
                std::string control_path;
                std::string status_path;
                ConfData *up;
                std::vector<DisplData *> displays;
        };

        std::vector<class DevData *> devs;
        int highest_index;

        static ConfData *parse_config(const char *filename);

        void print_cfg_data();

private:
        ConfData();

        oc_err_t extract_data_from_json(class JSDataNodeObject *js);
        DevData *extract_devicedata_from_json(class JSDataNodeObject *js);
        DisplData *extract_displaydata_from_json(class JSDataNodeObject *js);
};

#endif /* __OWFD_CTRL_PARSER_H__ */

