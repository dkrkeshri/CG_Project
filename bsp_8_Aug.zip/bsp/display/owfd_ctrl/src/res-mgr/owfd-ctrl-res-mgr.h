/**
 * @file       owfd-ctrl-res-mgr.h
 * @brief      ResMgrOwfdC class declaration
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_RES_MGR_H__
#define __OWFD_CTRL_RES_MGR_H__

#include "owfd-ctrl-error.h"
#include "txt_resmgr_base.h"

#define OC_RES_MGR_TYPE_ID_STR          "type_owfd_ctrl"

#define OC_CMD_WORD_BUFF_LEN            16

#define OC_CONTROL_STR                  "control"
#define OC_STATUS_STR                   "status"

#define OC_CMD_WORD_LIST_STR            "list"
#define OC_CMD_WORD_CTRL_STR            "ctrl"
#define OC_CMD_WORD_VERSION_STR         "version"
#define OC_CMD_WORD_STATUS_STR          "status"
#define OC_CMD_WORD_STATUSGET_STR       "statusget"
#define OC_CMD_WORD_ONLINE_STR          "online"
#define OC_CMD_WORD_OFFLINE_STR         "offline"
#define OC_CMD_WORD_QUIT_STR            "quit"
#define OC_CMD_WORD_LIST_DISPLAYS_STR   "list-displays"

/* The object owning two of these resource manager nodes */
class OCDevice;

class ResMgrOwfdC : public ResMgrBase
{
public:
        ResMgrOwfdC(OCDevice *parent, const char *path, bool is_control);
        virtual ~ResMgrOwfdC();

        virtual bool start(std::string *out_err,
                ResManagerDispatchloop *dispatcher);
        virtual void stop();

protected:
        virtual bool process_command(const char *command);

private:
        oc_err_t process_command_list();
        oc_err_t process_command_ctrl(const char *command);
        oc_err_t process_command_status(const char *command);
        oc_err_t process_command_online();
        oc_err_t process_command_offline();
        void process_command_version();
        oc_err_t process_command_quit();
        oc_err_t switch_power(int screen_idx, bool pwr_on);

        OCDevice *owner;
        bool is_ctrl;
};

#endif /* __OWFD_CTRL_RES_MGR_H__ */

