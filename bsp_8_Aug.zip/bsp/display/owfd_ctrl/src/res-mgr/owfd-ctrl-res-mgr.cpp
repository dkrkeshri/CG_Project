/**
 * @file       owfd-ctrl-res-mgr.cpp
 * @brief      ResMgrOwfdC class implementation
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include <cctype>
#include <errno.h>
#include <vector>

#include "owfd-ctrl-common.h"
#include "owfd-ctrl-core.h"
#include "owfd-ctrl-device.h"
#include "owfd-ctrl-log.h"
#include "owfd-ctrl-res-mgr.h"

ResMgrOwfdC::ResMgrOwfdC(OCDevice *parent, const char *path, bool is_control) :
        ResMgrBase(path, OC_RES_MGR_TYPE_ID_STR)
{
        LOG_D("Called\n");

        owner = parent;
        is_ctrl = is_control;
}

ResMgrOwfdC::~ResMgrOwfdC()
{
        LOG_D("Called\n");
}

bool ResMgrOwfdC::start(std::string *out_err,
        ResManagerDispatchloop *dispatcher)
{
        bool res = false;

        if (nullptr == out_err || nullptr == dispatcher) {
                LOG_E("Invalid input: out_err = %p, dispatcher = %p\n",
                      out_err, dispatcher);

                return false;
        }

        res = ResMgrBase::start(out_err, dispatcher);
        if (false == res) {
                LOG_E("Failed to start ResMgrBase\n");

                return false;
        }

        LOG_D("Started\n");

        return true;
}

void ResMgrOwfdC::stop()
{
        LOG_D("Called\n");

        ResMgrBase::stop();
}

bool ResMgrOwfdC::process_command(const char *command)
{
        const char *dev_name = nullptr;
        std::string dev_node;
        int i = 0;
        char cmd_word[OC_CMD_WORD_BUFF_LEN] = {0};
        const char *cmd_arg = nullptr;
        oc_err_t rc = OC_SUCCESS;
        std::string msg;

        dev_name = owner->get_device_name();

        if (nullptr == command) {
                LOG_E("[%s] Invalid input: command = %p\n", dev_name, command);

                return false;
        }

        dev_node = is_ctrl ? OC_CONTROL_STR : OC_STATUS_STR;

        LOG_I("[%s] %s node, processing a '%s' command\n",
              dev_name, dev_node.c_str(), command);

        /* Skip leading whitespace */
        while (0 != isspace(*command)) {
                command++;
        }

        /* Copy command-word */
        for (i = 0; i + 1 < OC_CMD_WORD_BUFF_LEN; i++) {
                if (0 == command[i] || 0 != isspace(command[i])) {
                        break;
                }

                cmd_word[i] = command[i];
        }

        cmd_word[i] = 0;
        cmd_arg = command + i;

        /* Skip whitespace */
        while (0 != isspace(*cmd_arg)) {
                cmd_arg++;
        }

        /* Check command-word */
        if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_LIST_STR)) {
                rc = process_command_list();
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_CTRL_STR)) {
                rc = process_command_ctrl(cmd_arg);
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_VERSION_STR)) {
                process_command_version();
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_STATUS_STR) ||
                   EQUAL == strcmp(cmd_word, OC_CMD_WORD_STATUSGET_STR)) {
                rc = process_command_status(cmd_arg);
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_ONLINE_STR)) {
                rc = process_command_online();
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_OFFLINE_STR)) {
                rc = process_command_offline();
        } else if (EQUAL == strcmp(cmd_word, OC_CMD_WORD_QUIT_STR)) {
                rc = process_command_quit();
        } else {
                msg = "Unknown command word: cmd_word = ";
                msg += cmd_word;

                printrep("%d\n%s\n", EINVAL, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return false;
        }

        if (OC_SUCCESS != rc) {
                LOG_E("[%s] Failed to process command. Error: %s\n",
                      dev_name, errorToString(rc).c_str());

                return false;
        }

        LOG_I("[%s] Command processed\n", dev_name);

        return true;
}

oc_err_t ResMgrOwfdC::process_command_list()
{
        oc_err_t rc = OC_SUCCESS;
        std::vector<std::string> disp_names;
        std::vector<std::string>::const_iterator it;

        LOG_D("Processing the 'list' command\n");

        rc = owner->get_display_names(&disp_names);
        if (OC_SUCCESS != rc) {
                LOG_E("Failed to get display names. Error: %s\n",
                      errorToString(rc).c_str());

                return rc;
        }

        printrep("%d\n", EOK);

        LOG_I("Got display names:\n");

        for (it = disp_names.begin(); it != disp_names.end(); ++it) {
                printrep("%s\n", it->c_str());
                LOG_I("%s\n", it->c_str());
        }

        return OC_SUCCESS;
}

oc_err_t ResMgrOwfdC::process_command_ctrl(const char *command)
{
        /**
         * Control command. The first arg (control keyword) is the name
         * (quoted), the second arg (value keyword) is the value (quoted).
         */
        const char *cmd = nullptr;
        int ret = EOK;
        std::string ctrl;
        std::string msg;
        const char *ctrl_kword = nullptr;
        std::string value;
        const char *value_kword = nullptr;
        oc_err_t rc = OC_SUCCESS;
        bool is_processed = false;
        int screen_idx = -1;
        bool pwr_state = false;

        if (nullptr == command) {
                LOG_E("Invalid input: command = %p\n", command);

                return OC_INVALID_PARAMETER;
        }

        LOG_D("Processing the 'ctrl' command: command = %s\n", command);

        cmd = command;

        /* Get control keyword */
        ret = get_quot_string(&cmd, &ctrl);
        if (EOK != ret) {
                msg = "Failed to get control keyword, it should be properly "
                      "quoted";

                printrep("%d\n%s\n", ret, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        ctrl_kword = ctrl.c_str();

        /* Get value keyword */
        ret = get_quot_string(&cmd, &value);
        if (EOK != ret) {
                msg = "Failed to get value keyword, it should be properly "
                      "quoted";

                printrep("%d\n%s\n", ret, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        value_kword = value.c_str();

        /* Is the control keyword the word 'online'? */
        if (EQUAL == strcmp(OC_CMD_WORD_ONLINE_STR, ctrl_kword)) {
                if (EQUAL == strncmp(value_kword, OC_ON_STR, OC_ON_STR_SIZE) ||
                    EQUAL == strcmp(value_kword, OC_ONE_STR)) {
                        rc = process_command_online();
                } else if (EQUAL == strcmp(value_kword, OC_ZERO_STR) ||
                           EQUAL == strncmp(value_kword, OC_OFF_STR,
                                            OC_OFF_STR_SIZE)) {
                        rc = process_command_offline();
                } else {
                        msg = "Invalid value keyword for the 'online' control "
                              "keyword: value_kword = ";
                        msg += value_kword;

                        printrep("%d\n%s\n", EINVAL, msg.c_str());
                        LOG_E("%s\n", msg.c_str());

                        return OC_INVALID_PARAMETER;
                }

                is_processed = true;

                goto leave;
        }

        /* Is the control keyword one of our display names? */
        screen_idx = owner->get_dispay_screen_idx(ctrl_kword);

        LOG_D("Got display \"%s\" screen index: screen_idx = %d\n", ctrl_kword,
              screen_idx);

        if (screen_idx >= 0) {
                /**
                 * Yes, the control keyword is one of our display names.
                 * Valid value keywords are 'on' and 'off' for power-switch.
                 */
                if (EQUAL == strcmp(value_kword, OC_ON_STR) ||
                    EQUAL == strcmp(value_kword, OC_OFF_STR)) {
                        pwr_state = false;

                        if (EQUAL == strcmp(value_kword, OC_ON_STR)) {
                                pwr_state = true;
                        }

                        rc = switch_power(screen_idx, pwr_state);
                } else {
                        msg = "Invalid value keyword for the '<displayname>' "
                              "ctrl command: value_kword = ";
                        msg += value_kword;

                        printrep("%d\n%s\n", EINVAL, msg.c_str());
                        LOG_E("%s\n", msg.c_str());

                        return OC_INVALID_PARAMETER;
                }

                is_processed = true;
        }

leave:
        if (false == is_processed) {
                msg = "Invalid ctrl command: ctrl_kword = ";
                msg += ctrl_kword;

                printrep("%d\n%s", EINVAL, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        if (OC_SUCCESS != rc) {
                LOG_E("Failed to process \"%s\" \"%s\" command. Error: %s\n",
                      ctrl_kword, value_kword, errorToString(rc).c_str());

                return rc;
        }

        LOG_D("Control command processed\n");

        return OC_SUCCESS;
}

oc_err_t ResMgrOwfdC::process_command_status(const char *command)
{
        /**
         * Status command. Argument (status keyword) is the value to query
         */
        const char *cmd = nullptr;
        int ret = EOK;
        std::string status;
        std::string msg;
        const char *status_kword = nullptr;
        oc_err_t rc = OC_SUCCESS;
        int screen_idx = -1;
        std::string state;
        bool res = false;
        bool pwr_state = false;

        if (nullptr == command) {
                LOG_E("Invalid input: command = %p\n", command);

                return OC_INVALID_PARAMETER;
        }

        LOG_D("Processing the 'status' command: command = %s\n", command);

        cmd = command;

        /* Get quoted argument, status keyword */
        ret = get_quot_string(&cmd, &status);
        if (EOK != ret) {
                msg = "Failed to get status keyword, it should be properly "
                      "quoted";

                printrep("%d\n%s\n", ret, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        status_kword = status.c_str();

        /* Check which keyword - check 'list-displays' */
        if (EQUAL == strcmp(status_kword, OC_CMD_WORD_LIST_DISPLAYS_STR)) {
                /* Same as list command */
                rc = process_command_list();
                if (OC_SUCCESS != rc) {
                        LOG_E("Failed to process the 'list-displays' command. "
                              "Error: %s\n", errorToString(rc).c_str());

                        return rc;
                }

                return OC_SUCCESS;
        }

        /* Check 'online' */
        if (EQUAL == strcmp(status_kword, OC_CMD_WORD_ONLINE_STR)) {
                state = OC_OFF_STR;

                res = owner->get_online();
                if (true == res) {
                        state = OC_ON_STR;
                }

                msg = "Current 'online' status: state = " + state;

                printrep("%d\n%s\n", EOK, msg.c_str());
                LOG_I("%s\n", msg.c_str());

                return OC_SUCCESS;
        }

        /* Is the status keyword one of our display names? */
        screen_idx = owner->get_dispay_screen_idx(status_kword);

        LOG_D("Got display \"%s\" screen index: screen_idx = %d\n",
              status_kword, screen_idx);

        if (screen_idx >= 0) {
                /**
                 * Yes, the status keyword is one of our display names, so
                 * check the power state.
                 */
                res = owner->get_online();
                if (false == res) {
                        msg = "Device-owner is not online";

                        printrep("%d\n%s", EINVAL, msg.c_str());
                        LOG_E("%s\n", msg.c_str());

                        return OC_DEVICE_FAILURE;
                }

                rc = owner->get_power(screen_idx, &pwr_state);
                if (OC_SUCCESS != rc) {
                        msg = "Failed to get display power state. Error: ";
                        msg += errorToString(rc);

                        printrep("%d\n%s", EIO, msg.c_str());
                        LOG_E("%s\n", msg.c_str());

                        return rc;
                }

                msg = "Current display power state: ";
                msg += (pwr_state ? OC_ON_STR : OC_OFF_STR);

                printrep("%d\n%s\n", EOK, msg.c_str());
                LOG_I("%s\n", msg.c_str());

                return OC_SUCCESS;
        }

        msg = "Invalid status command: status_kword = ";
        msg += status_kword;

        printrep("%d\n%s\n", EINVAL, msg.c_str());
        LOG_E("%s\n", msg.c_str());

        return OC_INVALID_PARAMETER;
}

oc_err_t ResMgrOwfdC::process_command_online()
{
        std::string msg;
        oc_err_t rc = OC_SUCCESS;

        LOG_D("Processing the \"online\" \"on\" command\n");

        if (false == is_ctrl) {
                msg = "Invalid command for the status node";

                printrep("%d\n%s", EPERM, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        rc = owner->set_online();
        if (OC_SUCCESS != rc) {
                msg = "Failed to set online: " + errorToString(rc);

                printrep("%d\n%s\n", EIO, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return rc;
        }

        printrep("%d\n", EOK);
        LOG_I("Setting online done\n");

        return OC_SUCCESS;
}

oc_err_t ResMgrOwfdC::process_command_offline()
{
        std::string msg;

        LOG_D("Processing the \"online\" \"off\" command\n");

        if (false == is_ctrl) {
                msg = "Invalid command for the status node";

                printrep("%d\n%s", EPERM, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        owner->set_offline();

        printrep("%d\n", EOK);
        LOG_I("Setting offline done\n");

        return OC_SUCCESS;
}

void ResMgrOwfdC::process_command_version()
{
        std::string msg;

        LOG_D("Processing the 'version' command\n");

        msg = "OWFD control daemon version: ";
        msg += OC_DAEMON_VERSION_STR;

        printrep("%d\n%s\n", EOK, msg.c_str());
        LOG_I("%s\n", msg.c_str());
}

oc_err_t ResMgrOwfdC::process_command_quit()
{
        std::string msg;

        LOG_D("Processing the 'quit' command\n");

        if (false == is_ctrl) {
                msg = "Invalid command for the status node";

                printrep("%d\n%s", EPERM, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        if (OC_CMD_QUIT_FORBID == allow_commandQuit) {
                msg = "Quit command is forbidden through config: "
                      "allow_commandQuit = ";
                msg += std::to_string(allow_commandQuit);

                printrep("%d\n%s\n", EPERM, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return OC_INVALID_PARAMETER;
        }

        /* The client will not be able to pick this up in time... */
        printrep("%d\n", EOK);
        LOG_I("Client command 'quit' received\n");

        /**
         * Note: the raise() call never fails. But coverity incorrectly
         * complains that the returnvalue is not used which would make this a
         * useless call. CID 3087578.
         */
        if (0 != raise(SIGINT)) {
                LOG_E("Failed to call SIGINT raise\n");
        }

        return OC_SUCCESS;
}

oc_err_t ResMgrOwfdC::switch_power(int screen_idx, bool pwr_on)
{
        oc_err_t rc = OC_SUCCESS;
        std::string msg;

        LOG_D("Processing the display \"%s\" command, display screen_idx: %d\n",
              pwr_on ? OC_ON_STR : OC_OFF_STR, screen_idx);

        rc = owner->set_power(screen_idx, pwr_on);
        if (OC_SUCCESS != rc) {
                msg = "Failed to set power. Error: " + errorToString(rc);

                printrep("%d\n%s", EIO, msg.c_str());
                LOG_E("%s\n", msg.c_str());

                return rc;
        }

        printrep("%d\n", EOK);
        LOG_I("Setting power done\n");

        return OC_SUCCESS;
}

