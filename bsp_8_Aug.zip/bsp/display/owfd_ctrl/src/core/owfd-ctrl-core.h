/**
 * @file       owfd-ctrl-core.h
 * @brief      Core defines and declarations used across the OWFD control
 *             component
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_CORE_H__
#define __OWFD_CTRL_CORE_H__

#include <map>
#include <string>
#include <vector>

#define OC_DAEMON_VERSION_STR                   "0.1"
#define OC_DAEMON_PROGNAME_STR                  "owfd_startup_control"

#define OC_DAEMON_RUN_ON                        1
#define OC_DAEMON_RUN_OFF                       0

#define OC_LOGFILENAME_DEFAULT_STR              ""

#define OC_NO_DAEMONIZE_DEFAULT                 0
#define OC_USE_SLOG2_DEFAULT                    1
#define OC_IS_VERBOSE_DEFAULT                   0

#define OC_DEBUGLEVEL_DEFAULT                   0

#define OC_CMD_QUIT_ALLOW                       1
#define OC_CMD_QUIT_FORBID                      0
#define OC_ALLOW_CMD_QUIT_DEFAULT               (OC_CMD_QUIT_ALLOW)

#define OC_SCR_CNT_MISMATCH_ALLOW               1
#define OC_SCR_CNT_MISMATCH_FORBID              0
#define OC_ALLOW_SCR_CNT_MISMATCH_DEFAULT       (OC_SCR_CNT_MISMATCH_FORBID)

/**
 * Choose if all commands shall be sent to the LogOutput logger log.
 * If 0 and debuglevel is 0, they are not logged.
 */
#define DO_LOG_ALL_COMMANDS                     0

class OCDevice;
class QnxScreen;

/* Properties taken from config file */
extern class ConfData *cfg_data;

extern std::vector<OCDevice *> oc_devices;
extern char allow_screencount_mismatch;
extern class QnxScreen *qnx_scr;

#endif /* __OWFD_CTRL_CORE_H__ */

