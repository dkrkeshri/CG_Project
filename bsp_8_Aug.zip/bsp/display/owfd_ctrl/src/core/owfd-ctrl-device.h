/**
 * @file       owfd-ctrl-device.h
 * @brief      OCDevice class declaration
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_DEVICE_H__
#define __OWFD_CTRL_DEVICE_H__

#include <string>

#include "owfd-ctrl-error.h"
#include "owfd-ctrl-parser.h"
#include "owfd-ctrl-res-mgr.h"

#define OC_INVALID_DISPLAY_SCREEN_IDX   -1

/**
 * Represents one 'device', which represents one item of the 'devices' section
 * in the config file. It has its own status- and control- nodes.
 */
class OCDevice
{
public:
        OCDevice(const ConfData::DevData *conf);
        ~OCDevice();

        oc_err_t start(class ResManagerDispatchloop *dispatcher);
        void stop();

        bool get_online() const;

        oc_err_t set_online();
        void set_offline();

        oc_err_t set_power(int screen_idx, bool pwrmd);
        oc_err_t get_power(int screen_idx, bool *out_pwrmd);

        int get_dispay_screen_idx(const char *disp_name) const;
        oc_err_t get_display_names(std::vector<std::string> *out_res) const;
        const char *get_device_name() const;

private:
        /* Do not allow copy constructor */
        OCDevice(OCDevice &org)
        {
                throw;
        }

        /* Do not allow copy assignment */
        void operator=(OCDevice &org)
        {
                throw;
        }

        bool is_our_screen_idx(int screen_idx);

        /* Device nodes */
        ResMgrOwfdC *dn_status;
        ResMgrOwfdC *dn_ctrl;

        const ConfData::DevData *confdata;

        /* Is in the 'online' state as seen from the calling client */
        bool is_online;

        class ResManagerDispatchloop *dispatch;
};

#endif /* __OWFD_CTRL_DEVICE_H__ */

