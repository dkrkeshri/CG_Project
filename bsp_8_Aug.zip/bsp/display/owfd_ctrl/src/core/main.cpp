/**
 * @file       main.cpp
 * @brief      OWFD control component main routines
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Weller Huang <Weller.Huang@cn.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include <errno.h>
#include <login.h>
#include <new>
#include <stdio.h>
#include <stdlib.h>
#include <sys/procmgr.h>

#include "logoutput.h"
#include "owfd-ctrl-common.h"
#include "owfd-ctrl-core.h"
#include "owfd-ctrl-device.h"
#include "owfd-ctrl-error.h"
#include "owfd-ctrl-log.h"
#include "owfd-ctrl-parser.h"
#include "owfd-ctrl-res-mgr.h"
#include "owfd-ctrl-screen.h"

#define OC_GETENV_SECPOL_ENABLED        '1'

extern "C" {
static void sigINTHandler(int dummy);
static void sigUSR1Handler(int dummy);

static volatile char run;
}

class ConfData *cfg_data = nullptr;
std::vector<OCDevice *> oc_devices;
class QnxScreen *qnx_scr = nullptr;

ResManagerDispatchloop *qnx_dispatcher = nullptr;

static inline
void print_help(void)
{
        printf("Valid options:\n");
        printf(" -c <filename>     specify config file\n");
        printf(" -d                do not daemonize\n");
        printf(" -v                verbose log output (reserved)\n");
        printf(" -h                show list of options\n");
        printf(" -X                ignore screen-indices higher than number of"
               "screens found on QNX 'screen' API\n");
        printf(" -U <argument>     set UID/GID (enabled SECPOL is required)\n");
}

static inline
bool _secpol_in_use(void)
{
        char *env = nullptr;

        env = getenv("SECPOL_ENABLE");
        if (nullptr != env) {
                return (OC_GETENV_SECPOL_ENABLED == env[0]);
        }

        return false;
}

int main(int argc, char *argv[])
{
        oc_err_t rc = OC_SUCCESS;
        int opt = 0;
        const char *cfg_file = nullptr;
        bool is_verbose = OC_IS_VERBOSE_DEFAULT;
        bool res = false;
        int ret = 0;
        std::string err_msg;
        const char *logfilename = nullptr;
        bool use_slog2 = OC_USE_SLOG2_DEFAULT;
        std::vector<class ConfData::DevData *>::iterator it;
        const char *dev_name = nullptr;
        OCDevice *dev = nullptr;
        int i = 0;

        cfg_data = nullptr;
        bNoDaemonize = OC_NO_DAEMONIZE_DEFAULT;
        allow_screencount_mismatch = OC_ALLOW_SCR_CNT_MISMATCH_DEFAULT;
        debuglevel = OC_DEBUGLEVEL_DEFAULT;
        allow_commandQuit = OC_ALLOW_CMD_QUIT_DEFAULT;
        qnx_dispatcher = nullptr;

        LOG_I("OWFD control component started: version = %s\n",
              OC_DAEMON_VERSION_STR);

        while (-1 != (opt = getopt(argc, argv, "dvc:U:hX"))) {
                switch (opt) {
                case 'c':
                        cfg_file = optarg;

                        LOG_I("Configuration file: %s\n", cfg_file);

                        break;
                case 'd':
                        bNoDaemonize = true;

                        LOG_I("No daemonize: %s\n",
                              OC_BOOL_TO_STR(bNoDaemonize));

                        break;
                case 'v':
                        is_verbose = true;

                        LOG_I("Verbose log output: %s\n",
                              OC_BOOL_TO_STR(is_verbose));

                        break;
                case 'X':
                        allow_screencount_mismatch = OC_SCR_CNT_MISMATCH_ALLOW;

                        LOG_I("Allow screen count mismatch: %d\n",
                              (int)allow_screencount_mismatch);

                        break;
                case 'U':
                        LOG_I("UID/GID to set: %s\n", optarg);

                        res = _secpol_in_use();
                        if (false == res) {
                                LOG_E("Secpol is not in use\n");

                                break;
                        }

                        ret = set_ids_from_arg(optarg);
                        if (-1 == ret) {
                                LOG_E("Failed to set UID/GID to [%s]. Error: "
                                      "%s\n", optarg, strerror(errno));

                                rc = OC_INIT_FAILED;

                                goto exit_owfd_ctrl;
                        }

                        LOG_I("UID/GID set\n");

                        break;
                case 'h':
                        LOG_D("Option -h used\n");
                        print_help();

                        goto exit_owfd_ctrl;
                default:
                        LOG_E("Invalid options specified\n");
                        printf("For list of valid options, use -h option\n");

                        rc = OC_INVALID_PARAMETER;

                        goto exit_owfd_ctrl;
                }
        }

        LOG_D("Command line arguments parsed\n");

        if (nullptr == cfg_file) {
                LOG_E("Configuration file is not specified\n");

                rc = OC_INVALID_PARAMETER;

                goto exit_owfd_ctrl;
        }
        try {
                cfg_data = ConfData::parse_config(cfg_file);
        } catch(std::length_error f) {
                LOG_E("Load and parse configuration file caught std::length_error\n");
                rc = OC_INIT_FAILED;
                goto exit_owfd_ctrl;
        }
        if (nullptr == cfg_data) {
                LOG_E("Failed to load and parse configuration file\n");

                rc = OC_INIT_FAILED;

                goto exit_owfd_ctrl;
        }

        LOG_D("Configuration file loaded and parsed\n");

        cfg_data->print_cfg_data();

        LOG_I("Debug level: %d\n", debuglevel);

        allow_commandQuit =
                (cfg_data->allow_quit ? OC_CMD_QUIT_ALLOW : OC_CMD_QUIT_FORBID);

        LOG_I("Allow 'quit' command: %d\n", (int)allow_commandQuit);

        if (false == bNoDaemonize) {
                ret = procmgr_daemon(0, (PROCMGR_DAEMON_NOCHDIR |
                                         PROCMGR_DAEMON_NODEVNULL));
                if (-1 == ret) {
                        LOG_E("Failed to daemonize. Error: %s\n",
                              strerror(errno));

                        rc = OC_INIT_FAILED;

                        goto exit_owfd_ctrl;
                }

                LOG_D("Daemonized\n");
        }

        signal(SIGINT, sigINTHandler);
        signal(SIGUSR1, sigUSR1Handler);

        LOG_D("SIGINT and SIGUSR1 handlers registered\n");

        logfile = new (std::nothrow) LogOutput(OC_DAEMON_PROGNAME_STR);
        if (nullptr == logfile) {
                LOG_E("Failed to allocate LogOutput object: name = %s\n",
                      OC_DAEMON_PROGNAME_STR);

                rc = OC_OOM;

                goto exit_owfd_ctrl;
        }

        LOG_D("LogOutput object allocated: name = %s\n",
              OC_DAEMON_PROGNAME_STR);

        /**
         * LogOutput logger is used only for backward compability with other
         * components that need it in the initialized state. Logfilename isn't
         * used here (nullptr default value is assigned), slog2 only.
         */
        res = logfile->init(logfilename, use_slog2);
        if (false == res) {
                LOG_E("Failed to initialize LogOutput logger: logfilename = %p,"
                      " use_slog2 = %s\n",
                      logfilename, OC_BOOL_TO_STR(use_slog2));

                rc = OC_INIT_FAILED;

                goto exit_owfd_ctrl;
        }

        LOG_D("LogOutput logger initialized: logfilename = %p, use_slog2 = "
              "%s\n", logfilename, OC_BOOL_TO_STR(use_slog2));

        qnx_dispatcher = new (std::nothrow) ResManagerDispatchloop();
        if (nullptr == qnx_dispatcher) {
                LOG_E("Failed to allocate ResManagerDispatchloop object\n");

                rc = OC_OOM;

                goto exit_owfd_ctrl;
        }

        LOG_D("ResManagerDispatchloop object allocated\n");

        for (it = cfg_data->devs.begin(); it != cfg_data->devs.end(); ++it) {
                dev_name = (*it)->name.c_str();

                dev = new (std::nothrow) OCDevice(*it);
                if (nullptr == dev) {
                        LOG_E("[%s] Failed to allocate OCDevice object\n",
                              dev_name);

                        rc = OC_OOM;

                        goto exit_owfd_ctrl;
                }

                LOG_D("[%s] OCDevice object allocated\n", dev_name);

                rc = dev->start(qnx_dispatcher);
                if (OC_SUCCESS != rc) {
                        LOG_E("[%s] Failed to start a device. Error: %s\n",
                              dev_name, errorToString(rc).c_str());

                        goto exit_owfd_ctrl;
                }

                LOG_D("[%s] Device started\n", dev_name);

                try {
                        oc_devices.push_back(dev);
                } catch (std::exception &e) {
                        LOG_E("[%s] Got an exception while adding device into "
                              "a vector: %s\n", dev_name, e.what());

                        rc = OC_EXCEPTION;

                        goto exit_owfd_ctrl;
                }
        }

        LOG_D("OCDevice objects created and devices started\n");

        run = OC_DAEMON_RUN_ON;

        LOG_I("Starting the daemon, send SIGINT (2) to exit\n");

        res = qnx_dispatcher->run_messagepump(&err_msg);
        if (false == res) {
                LOG_E("Failed to run the message-loop. Error: %s\n",
                      err_msg.c_str());

                rc = OC_INIT_FAILED;

                goto exit_owfd_ctrl;
        }

        LOG_I("Exiting the daemon\n");

exit_owfd_ctrl:
        for (i = 0; i < (int)oc_devices.size(); i++) {
                oc_devices[i]->set_offline();
        }

        if (nullptr != dev) {
                delete dev;
                dev = nullptr;
        }

        for (auto dev : oc_devices) {
                delete dev;
        }

        oc_devices.clear();

        if (nullptr != qnx_dispatcher) {
                delete qnx_dispatcher;
                qnx_dispatcher = nullptr;
        }

        if (nullptr != cfg_data) {
                delete cfg_data;
                cfg_data = nullptr;
        }

        if (nullptr != qnx_scr) {
                delete qnx_scr;
                qnx_scr = nullptr;
        }

        if (nullptr != logfile) {
                delete logfile;
                logfile = nullptr;
        }

        return rc;
}

static
void sigINTHandler(int dummy)
{
        LOG_D("Called\n");

        run = OC_DAEMON_RUN_OFF;

        if (nullptr != qnx_dispatcher) {
                qnx_dispatcher->async_hint_stop();
        }
}

static
void sigUSR1Handler(int dummy)
{
        LOG_D("Called\n");
}

