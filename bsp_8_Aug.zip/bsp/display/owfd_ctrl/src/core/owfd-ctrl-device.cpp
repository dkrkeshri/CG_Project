/**
 * @file       owfd-ctrl-device.cpp
 * @brief      OCDevice class implementation
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include "owfd-ctrl-common.h"
#include "owfd-ctrl-core.h"
#include "owfd-ctrl-device.h"
#include "owfd-ctrl-log.h"
#include "owfd-ctrl-res-mgr.h"
#include "owfd-ctrl-screen.h"

OCDevice::OCDevice(const ConfData::DevData *conf)
{
        LOG_D("Called\n");

        dn_status = nullptr;
        dn_ctrl = nullptr;
        dispatch = nullptr;
        is_online = false;

        confdata = conf;
}

OCDevice::~OCDevice()
{
        LOG_D("Called\n");

        stop();
}

oc_err_t OCDevice::start(ResManagerDispatchloop *dispatcher)
{
        const char *dev_name = nullptr;
        oc_err_t rc = OC_SUCCESS;
        const char *path = nullptr;
        bool is_control = false;
        bool res = false;
        std::string err_msg;

        dev_name = get_device_name();

        LOG_D("[%s] Starting\n", dev_name);

        if (nullptr == dispatcher) {
                LOG_E("[%s] Invalid input: dispatcher = %p\n",
                      dev_name, dispatcher);

                return OC_INVALID_PARAMETER;
        }

        dispatch = dispatcher;

        path = confdata->control_path.c_str();
        is_control = true;

        dn_ctrl = new (std::nothrow) ResMgrOwfdC(this, path, is_control);
        if (nullptr == dn_ctrl) {
                LOG_E("[%s] Failed to allocate ResMgrOwfdC object: path = %s, "
                      "is_control = %s\n", dev_name, path,
                      OC_BOOL_TO_STR(is_control));

                rc = OC_OOM;

                goto dev_start_failed;
        }

        res = dn_ctrl->start(&err_msg, dispatch);
        if (false == res) {
                LOG_E("[%s] Failed to start a control node resource manager: "
                      "%s. Error: %s\n", dev_name, path, err_msg.c_str());

                rc = OC_INIT_FAILED;

                goto dev_start_failed;
        }

        LOG_D("[%s] Control node created: %s\n", dev_name, path);

        path = confdata->status_path.c_str();
        is_control = false;

        dn_status = new (std::nothrow) ResMgrOwfdC(this, path, is_control);
        if (nullptr == dn_status) {
                LOG_E("[%s] Failed to allocate ResMgrOwfdC object: path = %s, "
                      "is_control = %s\n", dev_name, path,
                      OC_BOOL_TO_STR(is_control));

                rc = OC_OOM;

                goto dev_start_failed;
        }

        res = dn_status->start(&err_msg, dispatch);
        if (false == res) {
                LOG_E("[%s] Failed to start a status node resource manager: "
                      "%s. Error: %s\n", dev_name, path, err_msg.c_str());

                rc = OC_INIT_FAILED;

                goto dev_start_failed;
        }

        LOG_D("[%s] Status node created: %s\n", dev_name, path);

        LOG_D("[%s] Started\n", dev_name);

        return OC_SUCCESS;

dev_start_failed:
        stop();

        return rc;
}

void OCDevice::stop()
{
        LOG_D("Called\n");

        set_offline();

        if (nullptr != dn_status) {
                delete dn_status;
                dn_status = nullptr;
        }

        if (nullptr != dn_ctrl) {
                delete dn_ctrl;
                dn_ctrl = nullptr;
        }

        dispatch = nullptr;
}

bool OCDevice::get_online() const
{
        return is_online;
}

oc_err_t OCDevice::set_online()
{
        const char *dev_name = nullptr;
        oc_err_t rc = OC_SUCCESS;
        int disp_cnt = 0;

        dev_name = get_device_name();

        LOG_D("[%s] Setting device online\n", dev_name);

        if (nullptr != qnx_scr) {
                LOG_D("[%s] QNX screen API is already connected\n", dev_name);

                goto setting_online_done;
        }

        /* If QNX screen API is not yet connected, do that here */
        qnx_scr = new (std::nothrow) QnxScreen();
        if (nullptr == qnx_scr) {
                LOG_E("[%s] Failed to allocate QnxScreen object\n", dev_name);

                return OC_OOM;
        }

        rc = qnx_scr->init();
        if (OC_SUCCESS != rc) {
                LOG_E("[%s] Failed to init a screen API connection. Error: "
                      "%s\n", dev_name, errorToString(rc).c_str());

                goto setting_online_failed;
        }

        /**
         * Check if the number of displays found there matches the number
         * found on the config.
         */
        disp_cnt = qnx_scr->get_display_count();
        if (disp_cnt < 0) {
                LOG_E("[%s] Got invalid screen display count: disp_cnt = %d\n",
                      dev_name, disp_cnt);

                rc = OC_INVALID_PARAMETER;

                goto setting_online_failed;
        }

        if (disp_cnt > cfg_data->highest_index) {
                LOG_D("[%s] Got valid screen display count: disp_cnt = %d\n",
                      dev_name, disp_cnt);

                goto setting_online_done;
        }

        LOG_D("[%s] Display number mismatch occurred\n", dev_name);
        LOG_D("[%s] QNX screen has %d displays, config highest display index "
              "is #%d\n", dev_name, disp_cnt, cfg_data->highest_index);

        if (OC_SCR_CNT_MISMATCH_FORBID == allow_screencount_mismatch) {
                LOG_E("[%s] Occurred display number mismatch is forbidden: "
                      "allow_screencount_mismatch = %d\n", dev_name,
                      (int)allow_screencount_mismatch);

                rc = OC_INVALID_PARAMETER;

                goto setting_online_failed;
        }

        LOG_D("[%s] Display number mismatch is allowed: "
              "allow_screencount_mismatch = %d\n", dev_name,
              (int)allow_screencount_mismatch);

setting_online_done:
        is_online = true;

        LOG_D("[%s] Device set online\n", dev_name);

        return OC_SUCCESS;

setting_online_failed:
        delete qnx_scr;
        qnx_scr = nullptr;

        return rc;
}

void OCDevice::set_offline()
{
        const char *dev_name = nullptr;
        std::vector<OCDevice *>::iterator it;
        bool res = false;

        dev_name = get_device_name();

        LOG_D("[%s] Setting device offline\n", dev_name);

        is_online = false;

        LOG_D("[%s] Device set offline\n", dev_name);

        if (nullptr == qnx_scr) {
                LOG_D("[%s] Screen API is not connected\n", dev_name);

                return;
        }

        /**
         * If now all instances are 'offline' and the API handle is still there,
         * close down the QNX screen API connection.
         */
        for (it = oc_devices.begin(); it != oc_devices.end(); ++it) {
                if (nullptr == (*it)) {
                        continue;
                }

                res = (*it)->get_online();
                if (true == res) {
                        dev_name = (*it)->get_device_name();

                        LOG_D("Device \"%s\" is still online, keep the screen "
                              "API handle opened\n", dev_name);

                        return;
                }
        }

        delete qnx_scr;
        qnx_scr = nullptr;

        LOG_D("All devices are offline, screen API connection closed\n");
}

oc_err_t OCDevice::set_power(int screen_idx, bool pwrmd)
{
        const char *dev_name = nullptr;
        bool res = false;
        QnxScreen::DisplayData::PwrMd mode;
        oc_err_t rc = OC_SUCCESS;

        dev_name = get_device_name();

        LOG_D("[%s] Setting display power mode: screen_idx = %d, pwrmd = %s\n",
              dev_name, screen_idx, pwrmd ? OC_ON_STR : OC_OFF_STR);

        res = is_our_screen_idx(screen_idx);
        if (false == res) {
                LOG_E("[%s] Got screen index is not one of this device node "
                      "indices: screen_idx = %d\n", dev_name, screen_idx);

                return OC_INVALID_PARAMETER;
        }

        if (false == is_online) {
                LOG_E("[%s] Device is offline\n", dev_name);

                return OC_DEVICE_OFFLINE;
        }

        if (nullptr == qnx_scr) {
                LOG_E("[%s] QNX screen API is not connected\n", dev_name);

                return OC_SCREEN_FAILURE;
        }

        mode = QnxScreen::DisplayData::PwrMd::DD_PWRMD_OFF;
        if (true == pwrmd) {
                mode = QnxScreen::DisplayData::PwrMd::DD_PWRMD_ON;
        }

        rc = qnx_scr->set_powermode(screen_idx, mode);
        if (OC_SUCCESS != rc) {
                LOG_E("[%s] Failed to set power mode. Error: %s\n",
                      dev_name, errorToString(rc).c_str());

                return rc;
        }

        LOG_D("[%s] Display power mode set\n", dev_name);

        return OC_SUCCESS;
}

oc_err_t OCDevice::get_power(int screen_idx, bool *out_pwrmd)
{
        const char *dev_name = nullptr;
        bool res = false;
        oc_err_t rc = OC_SUCCESS;
        QnxScreen::DisplayData::PwrMd mode;

        dev_name = get_device_name();

        LOG_D("[%s] Getting display power mode: screen_idx = %d\n",
              dev_name, screen_idx);

        if (nullptr == out_pwrmd) {
                LOG_E("[%s] Invalid input: out_pwrmd = %p\n",
                      dev_name, out_pwrmd);

                return OC_INVALID_PARAMETER;
        }

        res = is_our_screen_idx(screen_idx);
        if (false == res) {
                LOG_E("[%s] Got screen index is not one of this device node "
                      "indices: screen_idx = %d\n", dev_name, screen_idx);

                return OC_INVALID_PARAMETER;
        }

        if (false == is_online) {
                LOG_E("[%s] Device is offline\n", dev_name);

                return OC_DEVICE_OFFLINE;
        }

        if (nullptr == qnx_scr) {
                LOG_E("[%s] Screen API is not connected\n", dev_name);

                return OC_SCREEN_FAILURE;
        }

        rc = qnx_scr->get_powermode(screen_idx, &mode, false);
        if (OC_SUCCESS != rc) {
                LOG_E("[%s] Failed to get power mode. Error: %s\n",
                      dev_name, errorToString(rc).c_str());

                return rc;
        }

        if (QnxScreen::DisplayData::PwrMd::DD_PWRMD_ON == mode) {
                *out_pwrmd = true;
        } else if (QnxScreen::DisplayData::PwrMd::DD_PWRMD_OFF == mode) {
                *out_pwrmd = false;
        } else {
                LOG_E("[%s] Got invalid power mode: mode = %d\n",
                      dev_name, mode);

                return OC_INVALID_PARAMETER;
        }

        LOG_D("[%s] Got power mode: %s\n",
              dev_name, (*out_pwrmd) ? OC_ON_STR : OC_OFF_STR);

        return OC_SUCCESS;
}

int OCDevice::get_dispay_screen_idx(const char *disp_name) const
{
        const char *dev_name = nullptr;
        int i = 0;
        int cmp_ret = 0;

        if (nullptr == confdata) {
                LOG_E("Invalid OCDevice member value: confdata = %p\n",
                      confdata);

                return OC_INVALID_DISPLAY_SCREEN_IDX;
        }

        dev_name = get_device_name();

        if (nullptr == disp_name) {
                LOG_E("[%s] Invalid input: disp_name = %p\n",
                      dev_name, disp_name);

                return OC_INVALID_DISPLAY_SCREEN_IDX;
        }

        for (i = 0; i < (int)confdata->displays.size(); ++i) {
                cmp_ret =
                        strcmp(disp_name, confdata->displays[i]->name.c_str());
                if (EQUAL == cmp_ret) {
                        return confdata->displays[i]->index;
                }
        }

        LOG_E("[%s] Display \"%s\" screen index not found\n",
              dev_name, disp_name);

        return OC_INVALID_DISPLAY_SCREEN_IDX;
}

oc_err_t OCDevice::get_display_names(std::vector<std::string> *out_res) const
{
        const char *dev_name = nullptr;
        int i = 0;
        std::string disp_name;

        if (nullptr == confdata) {
                LOG_E("Invalid OCDevice member value: confdata = %p\n",
                      confdata);

                return OC_INVALID_PARAMETER;
        }

        dev_name = get_device_name();

        if (nullptr == out_res) {
                LOG_E("[%s] Invalid input: out_res = %p\n", dev_name, out_res);

                return OC_INVALID_PARAMETER;
        }

        out_res->clear();

        for (i = 0; i < (int)confdata->displays.size(); ++i) {
                disp_name = confdata->displays[i]->name;

                try {
                        out_res->push_back(disp_name);
                } catch (std::exception &e) {
                        LOG_E("[%s] Got an exception while adding display name "
                              "\"%s\" into a vector: %s\n", dev_name, disp_name,
                              e.what());

                        return OC_EXCEPTION;
                }
        }

        return OC_SUCCESS;
}

bool OCDevice::is_our_screen_idx(int screen_idx)
{
        int i = 0;

        if (nullptr == confdata) {
                LOG_E("Invalid OCDevice member value: confdata = %p\n",
                      confdata);

                return false;
        }

        for (i = 0; i < (int)confdata->displays.size(); ++i) {
                if (screen_idx == confdata->displays[i]->index) {
                        return true;
                }
        }

        return false;
}

const char *OCDevice::get_device_name(void) const
{
        if (nullptr == confdata) {
                LOG_E("Invalid OCDevice member value: confdata = %p\n",
                      confdata);

                return OC_EMPTY_STR;
        }

        return confdata->name.c_str();
}

