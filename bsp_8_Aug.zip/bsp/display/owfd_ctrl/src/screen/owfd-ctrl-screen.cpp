/**
 * @file       owfd-ctrl-screen.cpp
 * @brief      QnxScreen class implementation
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#include <errno.h>
#include <new>
#include <screen/screen.h>
#include <stdlib.h>

#include "owfd-ctrl-common.h"
#include "owfd-ctrl-core.h"
#include "owfd-ctrl-log.h"
#include "owfd-ctrl-screen.h"
#include "txt_resmgr_base.h"

struct QnxScreen::PD {
        screen_context_t scr_ctx;
        int              scr_cnt;
        screen_display_t *scr_data;
};

/* Constructor, just zero all fields, the real initialization is in init() */
QnxScreen::QnxScreen()
{
        LOG_D("Called\n");

        pr_data = new (std::nothrow) PD();
        if (nullptr == pr_data) {
                LOG_E("Failed to allocate QnxScreen PD\n");

                return;
        }

        memset(pr_data, 0, sizeof(*pr_data));
}

QnxScreen::~QnxScreen()
{
        LOG_D("Called\n");

        deinit();

        delete pr_data;
        pr_data = nullptr;
}

/**
 * init() is the 'real' initialization. The constructor just zeroes all fields.
 * The API handles is retrieved, and some data is pulled from it.
 * This includes the number of displays, the handles of the displays,
 * and for each display the powerstate.
 *
 * If any of this init fails, init() will fail and report an error.
 */
oc_err_t QnxScreen::init()
{
        int ret = EOK;
        int disp_cnt = -1;
        int i = 0;
        char disp_name[OC_DISP_NAME_BUFF_LEN] = {0};
        DisplayData *disp_data = nullptr;
        int disp_size[OC_DISP_SIZE_BUFF_LEN] = {0};
        oc_err_t rc = OC_SUCCESS;

        static const char *pwr_modes[] = {
                OC_DISP_PWRMD_OFF_STR,
                OC_DISP_PWRMD_ON_STR,
                OC_DISP_PWRMD_SUSPEND_STR,
                OC_DISP_PWRMD_OTHER_STR,
                OC_DISP_PWRMD_UNKNOWN_STR
        };

        LOG_D("Initializing QNX screen\n");

        /* Safe for double call. Might also fail... */
        deinit();

        LOG_D("Creating screen context\n");

        ret = screen_create_context(&(pr_data->scr_ctx),
                                    (SCREEN_POWER_MANAGER_CONTEXT |
                                     SCREEN_APPLICATION_CONTEXT));
        if (-1 == ret) {
                LOG_E("Failed to create screen context. Error: %s\n",
                      strerror(errno));

                pr_data->scr_ctx = 0;

                return OC_SCREEN_FAILURE;
        }

        LOG_D("Screen context created\n");

        ret = screen_get_context_property_iv(pr_data->scr_ctx,
                                             SCREEN_PROPERTY_DISPLAY_COUNT,
                                             &disp_cnt);
        if (-1 == ret) {
                LOG_E("Failed to query the number of screens. Error: %s\n",
                      strerror(errno));

                rc = OC_SCREEN_FAILURE;

                goto init_failed;
        }

        pr_data->scr_cnt = disp_cnt;
        if (pr_data->scr_cnt < 1) {
                LOG_E("Got invalid number of screens: scr_cnt = %d\n",
                      pr_data->scr_cnt);

                rc = OC_INVALID_PARAMETER;

                goto init_failed;
        }

        LOG_D("Got the number of screens: %d\n", pr_data->scr_cnt);

        pr_data->scr_data =
                (screen_display_t *)calloc(pr_data->scr_cnt,
                                           sizeof(screen_context_t));
        if (nullptr == pr_data->scr_data) {
                LOG_E("Failed to allocate scr_data\n");

                rc = OC_OOM;

                goto init_failed;
        }

        ret = screen_get_context_property_pv(pr_data->scr_ctx,
                                             SCREEN_PROPERTY_DISPLAYS,
                                             (void **)pr_data->scr_data);
        if (-1 == ret) {
                LOG_E("Failed to get handles to displays. Error: %s\n",
                      strerror(errno));

                rc = OC_SCREEN_FAILURE;

                goto init_failed;
        }

        LOG_D("Got handles to displays\n");

        for (i = 0; i < pr_data->scr_cnt; i++) {
                memset(disp_name, 0, sizeof(disp_name));

                LOG_D("Getting display #%d ID_STRING screen property\n", i);

                ret = screen_get_display_property_cv(pr_data->scr_data[i],
                                                     SCREEN_PROPERTY_ID_STRING,
                                                     OC_SCR_PROP_ID_STRING_LEN,
                                                     disp_name);
                if (-1 == ret) {
                        LOG_E("Failed to query display #%d ID_STRING screen "
                              "property. Error: %s\n", i, strerror(errno));

                        rc = OC_SCREEN_FAILURE;

                        goto init_failed;
                }

                if (0 == disp_name[0]) {
                        LOG_E("Got invalid display #%d ID_STRING value, the "
                              "string is empty\n", i);

                        rc = OC_INVALID_PARAMETER;

                        goto init_failed;
                }

                LOG_D("QNX display #%d, ID_STRING = \"%s\"\n", i, disp_name);

                disp_data = new (std::nothrow) DisplayData(disp_name);
                if (nullptr == disp_data) {
                        LOG_E("Failed to allocate DisplayData object\n");

                        rc = OC_OOM;

                        goto init_failed;
                }

                try {
                        displays.push_back(disp_data);
                } catch (std::exception &e) {
                        LOG_E("Got an exception while adding display \"%s\" "
                              "data into a vector: %s\n", disp_name, e.what());

                        rc = OC_EXCEPTION;

                        goto init_failed;
                }

                ret = screen_get_display_property_iv(pr_data->scr_data[i],
                                                     SCREEN_PROPERTY_SIZE,
                                                     disp_size);
                if (0 == ret) {
                        disp_data->resolution_w = disp_size[0];
                        disp_data->resolution_h = disp_size[1];

                        LOG_D("Size = %d*%d\n", disp_data->resolution_w,
                              disp_data->resolution_h);
                } else {
                        LOG_D("Failed to query display SIZE. This may fail, no "
                              "reason to exit. Error: %s\n", strerror(errno));
                }

                rc = get_powermode(i, nullptr, true);
                if (OC_SUCCESS != rc) {
                        LOG_E("Failed to get display #%d power mode. Error: "
                              "%s\n", i, errorToString(rc).c_str());

                        goto init_failed;
                }

                LOG_D("Power mode: %s\n", pwr_modes[(int)disp_data->powermode]);
        }

        LOG_D("QnxScreen initialized\n");

        return OC_SUCCESS;

init_failed:
        deinit();

        return rc;
}

int QnxScreen::get_display_count() const
{
        if (nullptr == pr_data) {
                LOG_E("Invalid QnxScreen member value: pr_data = %p\n",
                      pr_data);

                return OC_INVALID_DISP_CNT;
        }

        return pr_data->scr_cnt;
}

std::string QnxScreen::get_display_name(int disp_num)
{
        if (disp_num < 0 || disp_num >= (int)displays.size()) {
                LOG_E("Invalid input: disp_num = %d\n", disp_num);

                return std::string("");
        }

        return displays[disp_num]->id;
}

/**
 * Asks this object for the power state of a display.
 * If retest_api is set to false, the last known state is returned.
 * This can be from the query during init(), or the buffered value from
 * set_powermode().
 * If retest_api is true, the QNX screen API will be queried again.
 * NOTE: it was observed, that this may fail after a set power command.
 */
oc_err_t QnxScreen::get_powermode(int disp_num, DisplayData::PwrMd *out_mode,
        bool retest_api)
{
        int ret = EOK;
        screen_display_t disp = nullptr;
        int pwr_mode_val = 0;
        DisplayData::PwrMd mode = DisplayData::PwrMd::DD_PWRMD_UNKNOWN;

        LOG_D("Getting display power mode: disp_num = %d, out_mode = %p, "
              "retest_api = %s\n", disp_num, out_mode,
              OC_BOOL_TO_STR(retest_api));

        if (0 == pr_data->scr_ctx) {
                LOG_E("QnxScreen instance is not initialized\n");

                return OC_SCREEN_FAILURE;
        }

        if (disp_num < 0 || disp_num >= (int)displays.size()) {
                LOG_E("Invalid input: disp_num = %d\n", disp_num);

                return OC_INVALID_PARAMETER;
        }

        if (true == retest_api) {
                disp = pr_data->scr_data[disp_num];

                ret = screen_get_display_property_iv(disp,
                                                     SCREEN_PROPERTY_POWER_MODE,
                                                     &pwr_mode_val);
                if (-1 == ret) {
                        LOG_E("Failed to query display #%d POWER_MODE screen "
                              "property. Error: %s\n", disp_num,
                              strerror(errno));

                        return OC_SCREEN_FAILURE;
                }

                LOG_D("Got POWER_MODE property value: pwr_mode_val = 0x%x\n",
                      pwr_mode_val);

                /* Translate to appropriate enum value */
                switch (pwr_mode_val) {
                case SCREEN_POWER_MODE_OFF:
                        mode = DisplayData::PwrMd::DD_PWRMD_OFF;

                        break;
                case SCREEN_POWER_MODE_SUSPEND:
                        mode = DisplayData::PwrMd::DD_PWRMD_SUSPEND;

                        break;
                case SCREEN_POWER_MODE_ON:
                        mode = DisplayData::PwrMd::DD_PWRMD_ON;

                        break;
                default:
                        mode = DisplayData::PwrMd::DD_PWRMD_OTHER;
                }

                displays[disp_num]->powermode = mode;
        }

        /* Output pointer might be null, so just test and keep internally */
        if (nullptr != out_mode) {
                *out_mode = displays[disp_num]->powermode;
        }

        LOG_D("Display power mode got\n");

        return OC_SUCCESS;
}

oc_err_t QnxScreen::set_powermode(int disp_num, DisplayData::PwrMd mode)
{
        int ret = EOK;
        int pwr_mode_val = 0;

        LOG_D("Setting display power mode: disp_num = %d, mode = %d\n",
              disp_num, (int)mode);

        if (0 == pr_data->scr_ctx) {
                LOG_E("QnxScreen instance is not initialized\n");

                return OC_SCREEN_FAILURE;
        }

        if (disp_num < 0 || disp_num >= (int)displays.size()) {
                LOG_E("Invalid input: disp_num = %d\n", disp_num);

                return OC_INVALID_PARAMETER;
        }

        /* Translate to QNX power mode enum */
        switch (mode) {
        case DisplayData::PwrMd::DD_PWRMD_OFF:
                pwr_mode_val = SCREEN_POWER_MODE_OFF;

                break;
        case DisplayData::PwrMd::DD_PWRMD_ON:
                pwr_mode_val = SCREEN_POWER_MODE_ON;

                break;
        case DisplayData::PwrMd::DD_PWRMD_SUSPEND:
                pwr_mode_val = SCREEN_POWER_MODE_SUSPEND;

                break;
        default:
                LOG_E("Invalid input: mode = %d\n", (int)mode);

                return OC_INVALID_PARAMETER;
        }

        ret = screen_set_display_property_iv(pr_data->scr_data[disp_num],
                                             SCREEN_PROPERTY_POWER_MODE,
                                             &pwr_mode_val);
        if (-1 == ret) {
                LOG_E("Failed to set POWER_MODE display #%d screen property. "
                      "Error: %s\n", disp_num, strerror(errno));

                return OC_SCREEN_FAILURE;
        }

        LOG_D("POWER_MODE display screen property set\n");

        /* Succeeded, keep value */
        displays[disp_num]->powermode = mode;

        ret = screen_flush_context(pr_data->scr_ctx, SCREEN_WAIT_IDLE);
        if (-1 == ret) {
                LOG_E("Failed to flush a screen context. Error: %s\n",
                      strerror(errno));

                return OC_SCREEN_FAILURE;
        }

        LOG_D("Screen context flushed and display power mode set\n");

        return OC_SUCCESS;
}

/**
 * Close down the QNX screen API, that is, release the handle.
 * All stored information is dropped.
 */
void QnxScreen::deinit()
{
        std::vector<DisplayData *>::iterator it;

        LOG_D("Called\n");

        if (0 != pr_data->scr_ctx) {
                LOG_D("Destroying screen context\n");

                screen_destroy_context(pr_data->scr_ctx);

                pr_data->scr_ctx = 0;

                LOG_D("Screen context destroyed\n");
        }

        if (nullptr != pr_data->scr_data) {
                free(pr_data->scr_data);
                pr_data->scr_data = nullptr;
        }

        for (it = displays.begin(); it != displays.end(); ++it) {
                delete (*it);
        }

        displays.clear();
}

QnxScreen::DisplayData::DisplayData(const char *qnx_id)
{
        LOG_D("Called\n");

        id = qnx_id;
        resolution_w = 0;
        resolution_h = 0;
        powermode = PwrMd::DD_PWRMD_UNKNOWN;
}

