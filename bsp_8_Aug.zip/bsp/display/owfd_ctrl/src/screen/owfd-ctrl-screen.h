/**
 * @file       owfd-ctrl-screen.h
 * @brief      Header for QnxScreen class, with nested DisplayData class.
 *             QNX 'screen' API wrapper
 *
 * @author     Achim Dahlhoff <Achim.Dahlhoff@de.bosch.com>
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_SCREEN_H__
#define __OWFD_CTRL_SCREEN_H__

#include <string>
#include <vector>

#include "owfd-ctrl-error.h"

#define OC_SCR_PROP_ID_STRING_LEN       64
#define OC_DISP_NAME_BUFF_LEN           OC_SCR_PROP_ID_STRING_LEN
#define OC_DISP_SIZE_BUFF_LEN           4

#define OC_DISP_PWRMD_OFF_STR           "off"
#define OC_DISP_PWRMD_ON_STR            "on"
#define OC_DISP_PWRMD_SUSPEND_STR       "suspend"
#define OC_DISP_PWRMD_OTHER_STR         "other"
#define OC_DISP_PWRMD_UNKNOWN_STR       "unknown"

#define OC_INVALID_DISP_CNT             -1

class QnxScreen
{
public:
        QnxScreen();
        ~QnxScreen();

        oc_err_t init();

        class DisplayData
        {
        public:
                DisplayData(const char *qnx_id);

                enum PwrMd {
                        DD_PWRMD_OFF     = 0,
                        DD_PWRMD_ON      = 1,
                        DD_PWRMD_SUSPEND = 2,
                        DD_PWRMD_OTHER   = 3,
                        DD_PWRMD_UNKNOWN = 4
                };

                /* ID_STRING retrieved from QNX screen API */
                std::string id;

                int resolution_w;
                int resolution_h;

                PwrMd powermode;
        };

        int get_display_count() const;

        std::string get_display_name(int disp_num);

        oc_err_t get_powermode(int disp_num, DisplayData::PwrMd *out_mode,
                bool retest_api);
        oc_err_t set_powermode(int disp_num, DisplayData::PwrMd mode);

private:
        /* Do not allow copy constructor */
        QnxScreen(QnxScreen &org)
        {
                throw;
        }

        /* Do not allow copy assignment */
        void operator=(QnxScreen &org)
        {
                throw;
        }

        void deinit();

        /**
         * Private data struct, to keep QNX screen headers away from this
         * header file.
         */
        struct PD;

        struct PD *pr_data;

        std::vector<DisplayData *> displays;
};

#endif /* __OWFD_CTRL_SCREEN_H__ */

