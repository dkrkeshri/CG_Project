/**
 * @file       owfd-ctrl-common.h
 * @brief      Common functions and macro definitions
 *
 * @author     Vitalii Silchuk <external.Vitalii.Silchuk@de.bosch.com>
 *
 * @copyright  (c) 2022 Robert Bosch GmbH, Hildesheim
 */

#ifndef __OWFD_CTRL_COMMON_H__
#define __OWFD_CTRL_COMMON_H__

#define EQUAL                   0

#define OC_ON_STR               "on"
#define OC_ON_STR_SIZE          (sizeof(OC_ON_STR) - 1)

#define OC_OFF_STR              "off"
#define OC_OFF_STR_SIZE         (sizeof(OC_OFF_STR) - 1)

#define OC_ONE_STR              "1"
#define OC_ZERO_STR             "0"

#define OC_TRUE_STR             "true"
#define OC_FALSE_STR            "false"

#define OC_EMPTY_STR            ""

#define OC_BOOL_TO_STR(val)     ((val) ? (OC_TRUE_STR) : (OC_FALSE_STR))

#endif /* __OWFD_CTRL_COMMON_H__ */

