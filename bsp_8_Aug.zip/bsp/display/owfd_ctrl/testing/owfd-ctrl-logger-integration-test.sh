#! /bin/ksh

configuration="/dev/provider/openwfd-commander.json"

if [[ $1 == "-h" ]]
then
        echo ""
        echo "OWFD control component logger integration and logs update test"
        echo -e "\tUsage: $0  \${config}"
        echo ""
        echo "If no configuration file specified using default:"
        echo -e "\t$configuration"
        echo ""

        exit
fi

echo ""

if [ -z "$1" ]
then
        echo "No configuration file specified, using default:"
        echo -e "\t$configuration"
else
        configuration="$2"
        echo "Specified configuration file: $configuration"
fi

echo ""

# Uncommented, this command enables the xtrace mode and then prints out each
# command it executes before outputting the result
# set -o xtrace

execute_command()
{
        echo $1

        echo ""

        $2 &

        sleep $3

        echo -e "\n\n"
}

send_owfd_ctrl_command()
{
        echo $1

        echo ""

        slog2info -c

        echo $2 > $3 &

        slog2info | grep owfd_ctrl

        sleep $4

        echo -e "\n\n"
}

slay -f owfd_ctrl
slog2info -c


execute_command "Show configuration file"                                       \
                "cat $configuration"                                            \
                3


echo -e "---\n\n\n"


echo -e "Test 1. Start the OWFD control component with no configuration file "`
        `"specified\n"

slog2info -c

owfd_ctrl

slog2info | grep owfd_ctrl
sleep 3

echo -e "\n\n"


echo -e "Test 2. Start the OWFD control component with the wrong "`
        `"configuration file\n"

slog2info -c

owfd_ctrl -c /dev/provider/ds90ux9xx.json

slog2info | grep owfd_ctrl
sleep 3

echo -e "\n\n\n---\n\n\n"


echo -e "Test 3. Start the OWFD control component with the valid "`
        `"configuration file\n"

slog2info -c

owfd_ctrl -c $configuration

slog2info | grep owfd_ctrl
sleep 3

echo -e "\n\n\n---\n\n\n"


send_owfd_ctrl_command "Test 4. Get the OWFD control component version"         \
                       'version'                                                \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 5. Get the IPD device list of displays by using "`
                       `"the 'list' command"                                    \
                       'list'                                                   \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 6. Get the VCD device list of displays by using "`
                       `"the 'list-displays' status command"                    \
                       'status "list-displays"'                                 \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 7. Get the IPD display status when the IPD "`
                       `"device is OFFLINE"                                     \
                       'status "ipd"'                                           \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 8. Get the VCD display status when the VCD "`
                       `"device is OFFLINE"                                     \
                       'status "vcd"'                                           \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 9. Set the IPD display OFF when the IPD "`
                       `"device is OFFLINE"                                     \
                       'ctrl "ipd" "off"'                                       \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 10. Set the VCD display OFF when the VCD "`
                       `"device is OFFLINE"                                     \
                       'ctrl "vcd" "off"'                                       \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 11. Set the IPD display ON when the IPD "`
                       `"device is OFFLINE"                                     \
                       'ctrl "ipd" "on"'                                        \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 12. Set the VCD display ON when the VCD "`
                       `"device is OFFLINE"                                     \
                       'ctrl "vcd" "on"'                                        \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 13. Get the IPD device ONLINE status when it is "`
                       `"OFFLINE"                                               \
                       'status "online"'                                        \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 14. Get the VCD device ONLINE status when it is "`
                       `"OFFLINE"                                               \
                       'status "online"'                                        \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 15. Set the IPD device ONLINE when it is OFFLINE"  \
                       'ctrl "online" "on"'                                     \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 16. Set the VCD device ONLINE when it is OFFLINE"  \
                       'ctrl "online" "on"'                                     \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 17. Get the IPD device ONLINE status after it "`
                       `"was set ONLINE"                                        \
                       'status "online"'                                        \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 18. Get the VCD device ONLINE status after it "`
                       `"was set ONLINE"                                        \
                       'status "online"'                                        \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 19. Get the IPD display status after the IPD "`
                       `"device was set ONLINE"                                 \
                       'status "ipd"'                                           \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 20. Get the VCD display status after the VCD "`
                       `"device was set ONLINE"                                 \
                       'status "vcd"'                                           \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 21. Set the IPD display OFF when the IPD device "`
                       `"is ONLINE"                                             \
                       'ctrl "ipd" "off"'                                       \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 22. Set the VCD display OFF when the VCD device "`
                       `"is ONLINE"                                             \
                       'ctrl "vcd" "off"'                                       \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 23. Get the IPD display status after the display "`
                       `"was set OFF"                                           \
                       'status "ipd"'                                           \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 24. Get the VCD display status after the display "`
                       `"was set OFF"                                           \
                       'status "vcd"'                                           \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 25. Set the IPD display ON when the IPD device "`
                       `"is ONLINE"                                             \
                       'ctrl "ipd" "on"'                                        \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 26. Set the VCD display ON when the VCD device "`
                       `"is ONLINE"                                             \
                       'ctrl "vcd" "on"'                                        \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 27. Get the IPD display status after the display "`
                       `"was set ON"                                            \
                       'status "ipd"'                                           \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 28. Get the VCD display status after the display "`
                       `"was set ON"                                            \
                       'status "vcd"'                                           \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 29. Set the IPD device OFFLINE"                    \
                       'ctrl "online" "off"'                                    \
                       "/dev/ipd/openwfd-commander/control"                     \
                       3


send_owfd_ctrl_command "Test 30. Set the VCD device OFFLINE"                    \
                       'ctrl "online" "off"'                                    \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 31. Get the IPD device ONLINE status after the "`
                       `"device was set OFFLINE"                                \
                       'status "online"'                                        \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 32. Get the VCD device ONLINE status after the "`
                       `"device was set OFFLINE"                                \
                       'status "online"'                                        \
                       "/dev/vcd/openwfd-commander/status"                      \
                       3


echo -e "---\n\n\n"


send_owfd_ctrl_command "Test 33. Set the IPD device ONLINE by sending a "`
                       `"control command to the status node"                    \
                       'ctrl "online" "on"'                                     \
                       "/dev/ipd/openwfd-commander/status"                      \
                       3


send_owfd_ctrl_command "Test 34. Get the VCD device ONLINE by sending a "`
                       `"status command to the control node"                    \
                       'status "online"'                                        \
                       "/dev/vcd/openwfd-commander/control"                     \
                       3


echo -e "---\n\n\n"


slay -f owfd_ctrl
slog2info -c

