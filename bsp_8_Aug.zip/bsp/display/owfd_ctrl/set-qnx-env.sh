######################################################################
#FILE: set-qnx-env.sh
#SW-COMPONENT: Tooling
#DESCRIPTION: Setup environment for the QNX build
#COPYRIGHT: (C) 2022 Robert Bosch GmbH
#Author: Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
######################################################################

path_to_hqx=$1

if [[ $0 != *"bash" ]]; then
        echo -e "\n\tPlease use \"source\" comand before script name\n"
else
        if [[ -z $path_to_hqx ]]; then
                echo -e "\n\tPlease specify path to HQX root"

                echo "---------------------------------------------------"
                echo -e "\tUsage: source set-qnx-env.sh /path/to/hqx/"
                echo "---------------------------------------------------"
                exit -1
        elif [[ $path_to_hqx == '-a' ]]; then
                echo -e "\n\tUsing own QNX path\n"
                path_to_hqx="../../../../../../"
        else
                echo -e "\n\tUsing QNX path: $path_to_hqx"
        fi

        cd $path_to_hqx/vcu/qnx/qcom/qcom_qnx/apps/qnx_ap
        source setenv_64.sh -ex $(readlink -e ../../../../qnx-sdp)
        cd -
fi

