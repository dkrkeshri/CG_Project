#!/bin/bash

uncrustify -c .uncrustify --replace --no-backup screen-config-provider/src/*.c
uncrustify -c .uncrustify --replace --no-backup screen-config-provider/inc/*.h
uncrustify -c .uncrustify --replace --no-backup openwfd-config-provider/src/*.c
uncrustify -c .uncrustify --replace --no-backup openwfd-config-provider/inc/*.h
clang-format -i --style=file ./screen-config-provider/src/*.c
clang-format -i --style=file ./screen-config-provider/inc/*.h
clang-format -i --style=file ./openwfd-config-provider/src/*.c
clang-format -i --style=file ./openwfd-config-provider/inc/*.h
