/**
* @swcomponent Top Level HVAC API CONFIG PROVIDER
* @{
* @file top-level-hvac-api-config-provider
* @brief Generate dynamic configuration file for Top Level FIDM API
* @copyright (C) 2020 Robert Bosch GmbH.
*                The reproduction, distribution and utilization of this file as
*                well as the communication of its contents to others without express
*                authorization is prohibited. Offenders will be held liable for the
*                payment of damages. All rights reserved in the event of the grant
*                of a patent, utility model or design.
* @}
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/slog2.h>

#include "hvac-cp-log.h"
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

//#define DEBUG
#define DEFAULT_CONFIG_PATH_NAME "/dev/hvac-config-provider/hvac.json"
#define PREDEFINED_QCCONFIG_PROP \
    "/display-infrastructure/exports/hvac-config-source"

typedef struct hvac_cp_data{
    cphandle_t                    cp;
    fidmParaApiHdl                pp_hdl;
    char                          config_source_path[PATH_MAX];
    void*                         file_data;
    int                           file_size;
    pthread_t                     thread;
}hvac_cp_data_t;

/*Unnamed semaphore to be used by the signal handler*/
static sem_t sem;

/**
 *@brief Signal handler posts a semaphore when SIGINT is received
 *
 *@param[in] signo signal number not used
 */
void signal_handler(int signo)
{
    CP_PRINT_DEBUG("signal handler called\n");
    if(-1 == sem_post(&sem))
    {
        CP_PRINT_ERROR("sem_post FAILED %s", strerror(errno));
    }
}

/**
 * @brief  Request for stopping the resource manager from
 *         handling client requests once SIGINT is received
 *         by the process
 *
 * @param[in] arg cp_handle_t cast to void pointer
 */
static void* stop_handling_request(void *arg)
{
    cphandle_t cp = (cphandle_t)arg;

    /*wait for signal*/
    if(-1 == sem_wait(&sem))
    {
        CP_PRINT_ERROR("sem_wait FAILED %s", strerror(errno));
        goto exit;
    }
    CP_PRINT_DEBUG("Requesting to quit\n");
    libcp_stop_request(cp);

    if(-1 == sem_destroy(&sem))
    {
        CP_PRINT_ERROR("sem_destroy FAILED %s", strerror(errno));
        goto exit;
    }

exit:
    return (void*)NULL;
}

/**
 * @brief  register to use slog2
 */
static int slogger2_init(void)
{
    slog2_buffer_set_config_t buffer_config;
    buffer_config.buffer_set_name = __progname;
    buffer_config.num_buffers = 1;
    buffer_config.verbosity_level = SLOG2_INFO;
    buffer_config.buffer_config[0].buffer_name = "hvac_api_cp";
    buffer_config.buffer_config[0].num_pages = 8;

    if (slog2_register(&buffer_config, &buffer_handle, 0)){
        return -1;
    }
    return 0;
}
/**
 * @brief  sets log level for slogger2
 */

static void set_slog_level(void)
{
    int ret = -1;
    switch(g_log_level)
    {
        case LOG_ERROR:
            ret = slog2_set_verbosity(buffer_handle, SLOG2_ERROR);
            break;

        case LOG_INFO:
            ret = slog2_set_verbosity(buffer_handle, SLOG2_INFO);
            break;

        case LOG_DEBUG:
            ret = slog2_set_verbosity(buffer_handle, SLOG2_DEBUG1);
            break;

        default:
            CP_PRINT_ERROR("Trying to set wrong log level %d\n",
                    g_log_level);
    }

    if(-1 == ret){
        CP_PRINT_ERROR("Setting log_level %d failed\n", g_log_level);
    }
}

/** @brief  Reads configuration file collected from parameter
 *         provider and stores the file content in a buffer.
 *         To be called only once.
 *
 *  @param[in]  cp_data Pointer to the config provider data
 *  @return 0 for success and -1 for failure
 */

static int get_configuration_file_data(hvac_cp_data_t* cp_data)
{
    FILE *fp = NULL;
    int ret = 0;

    if(NULL == cp_data){
        return -1;
    }

    fp = fopen(cp_data->config_source_path, "r");
    if(NULL == fp){
        CP_PRINT_ERROR("fopen FAILED: %s", strerror(errno));
        goto fail;
    }

    /*get the size of the file*/
    ret = fseek(fp, 0L, SEEK_END);
    if(-1 == ret){
        CP_PRINT_ERROR("fseek to end FAILED: %s", strerror(errno));
        goto fail;
    }

    cp_data->file_size = ftell(fp);

    if(-1 == cp_data->file_size)
    {
        CP_PRINT_ERROR("ftell FAILED: %s", strerror(errno));
        goto fail;
    }
    /*reset stream position to begining of file*/
    ret = fseek(fp, 0L, SEEK_SET);
    if(ret)
    {
        CP_PRINT_ERROR("fseek to beginning FAILED: %s",
                    strerror(errno));
        goto fail;
    }

    /*copy the file content*/
    cp_data->file_data = (char*)calloc(1,cp_data->file_size);
    if(NULL == cp_data->file_data)
    {
        CP_PRINT_ERROR("could not allocate memory for file_data: %s",
                strerror(errno));
        goto fail;
    }

    ret = fread(cp_data->file_data, 1, cp_data->file_size, fp);
    CP_PRINT_DEBUG("%u of %u were read\n",ret, cp_data->file_size);

    fclose(fp);
    return 0;
fail:
    if(fp)
    {
        fclose(fp);
    }

    if(cp_data->file_data)
    {
        free(cp_data->file_data);
        cp_data->file_data = NULL;
        cp_data->file_size = 0;
    }
    return -1;

}
int main(int argc, char **argv)
{
    hvac_cp_data_t* cp_data = NULL;
    int ret = 0;
    int thread_err = EOK;
    g_use_slog2 = 1;
    g_log_level = LOG_ERROR;

    if(g_use_slog2){
        ret = slogger2_init();
        if(-1 == ret){
            g_use_slog2 = 0;
            CP_PRINT_ERROR(
            "slogger2_init failed fallback to console output\n");
        }
        else{
            set_slog_level();
            CP_PRINT_INFO("slogger2 will be used for logging\n");
        }
    }

    CP_PRINT_INFO("log level set to %d\n", g_log_level);

    cp_data = calloc(1, sizeof(hvac_cp_data_t));
    if(NULL == cp_data){
        CP_PRINT_ERROR("Unable to allocate memory for cp_data: %s",
                            strerror(errno));
        return EXIT_FAILURE;
    }

    /*get configurtion file path from FIDM parameter provider*/
    cp_data->pp_hdl = fidm_parameter_api_open();
    if(NULL == cp_data->pp_hdl){
        CP_PRINT_ERROR("fidm_parameter_api_open FAILED\n");
        return EXIT_FAILURE;
    }

    /*check if property exists*/
    ret = fidm_parameter_api_path_exists(cp_data->pp_hdl,
                    PREDEFINED_QCCONFIG_PROP);
    if(ret < 1){
        CP_PRINT_ERROR("%s property not defined\n",
                    PREDEFINED_QCCONFIG_PROP);
        fidm_parameter_api_close(cp_data->pp_hdl);
        return EXIT_FAILURE;
    }

    /*read value of the property*/
    ret = fidm_parameter_api_string(cp_data->pp_hdl,
            PREDEFINED_QCCONFIG_PROP, cp_data->config_source_path,
            sizeof(cp_data->config_source_path));
    if(ret){
        CP_PRINT_ERROR("Failed to get source name\n");
        fidm_parameter_api_close(cp_data->pp_hdl);
        return EXIT_FAILURE;
    }else{
        CP_PRINT_DEBUG("source configuration path: %s\n",
                cp_data->config_source_path);
    }
    /*close handle*/
    fidm_parameter_api_close(cp_data->pp_hdl);

    /*fill configuration file data*/
    ret = get_configuration_file_data(cp_data);

    if(ret)
    {
        printf("Failed to get configuration file data\n");
        goto exit;
    }

#ifdef DEBUG
    if(cp_data && cp_data->file_data)
    {
        fwrite(cp_data->file_data, 1, cp_data->file_size, stdout);
    }
#endif

    /*create an instance of config provider resource manager*/
    cp_data->cp = libcp_create(DEFAULT_CONFIG_PATH_NAME);
    if(NULL == cp_data->cp){
        CP_PRINT_ERROR("libcp_create FAILED\n");
        ret = -1;
        goto exit;
    }

    /*provide data to fill up the configuration file*/
    ret = libcp_set_data(cp_data->cp, cp_data->file_data,
            cp_data->file_size);

    /*free file data irrespective of success or failure*/
    free(cp_data->file_data);
    cp_data->file_data = NULL;
    cp_data->file_size = 0;
    if(ret != 0){
        CP_PRINT_ERROR("libcp_set_data FAILED\n");
        goto destroy;
    }

    /*create the configuration file node*/
    ret = libcp_create_node(cp_data->cp);
    if(ret != 0){
        CP_PRINT_ERROR("libcp_create_node FAILED\n");
        goto destroy;
    }

    /*Block SIGINT*/
    thread_err = sem_init(&sem, 0, 0);
    if(thread_err != 0){
        CP_PRINT_ERROR("sem_init FAILED with %s",strerror(errno));
    }else{
        thread_err = EOK;
        signal(SIGINT, signal_handler);
    }
    /*create thread to quit*/
    if(EOK == thread_err){
        thread_err = pthread_create(&cp_data->thread, NULL,
            stop_handling_request, cp_data->cp);
        if(thread_err != EOK){
            CP_PRINT_ERROR("pthread_create FAILED with %d\n", thread_err);
        }
    }

    /*handle read request made to the configuration file*/
    ret = libcp_handle_req(cp_data->cp);
    if(ret != 0){
        CP_PRINT_ERROR("libcp_handle_req FAILED\n");
    }

    if(EOK == thread_err){
        thread_err = pthread_join(cp_data->thread, NULL);
        CP_PRINT_INFO("pthread_joined returned with %d\n", thread_err);
    }

    /*remove the configuration file node*/
    ret = libcp_remove_node(cp_data->cp);

    if(-1 == ret){
        CP_PRINT_ERROR("libcp_remove_node FAILED\n");
    }

destroy:
    /*free config provider resource manager data*/
    libcp_destroy(cp_data->cp);

exit:
    if(cp_data){
        free(cp_data->file_data);
        free(cp_data);
    }

    if(ret){
        return EXIT_FAILURE;
    }else{
        return EXIT_SUCCESS;
    }
}
