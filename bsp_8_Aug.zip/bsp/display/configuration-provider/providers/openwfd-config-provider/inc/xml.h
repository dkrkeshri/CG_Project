#ifndef __XML_H__
#define __XML_H__

#ifdef __cplusplus
extern "C" { /* Keep header compatible with being used from C++ code. */
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xmlmemory.h>

#define WFD_MAX_PORTS 4
#define WFD_MAX_BINDABLE_PIPELINES 4

#define WFD_MAX_CLIENTS 10

typedef struct _WFDPipeConfigType {
    unsigned char eQdiDisplayId;
    unsigned char eQdiLayerId;
    unsigned char eZOrder;
} WFDPipeConfigType;

typedef struct _WFDPortConfigType {
    unsigned char eQdiDisplayId;
    unsigned char uWfdPortId;
    unsigned char uDisplayNode;
    unsigned char uPortType;
    unsigned char eZOrderRange;
    unsigned char uNumOfEnumeratedPipes;
    WFDPipeConfigType sBindablePipes[WFD_MAX_BINDABLE_PIPELINES];
} WFDPortConfigType;

typedef struct _WFDClientConfigType {
    unsigned char uClientID;
    unsigned char uClientType;
    unsigned char uNumOfEnumeratedPorts;
    WFDPortConfigType sPortInfo[WFD_MAX_PORTS];
    bool bMultiRectSupport;
} WFDClientConfigType;

typedef struct _WFDDrvConfigType {
    unsigned char uNumOfEnumeratedClients;
    WFDClientConfigType sClientInfo[WFD_MAX_CLIENTS];
} WFDDrvConfigType;

static inline void set_PortAttribs_item(WFDPortConfigType *pPortInfo)
{
    // here is only for testing. the paras should get from fidm parameter
    // provider
    pPortInfo->eQdiDisplayId = '1';
    pPortInfo->uDisplayNode = '1';
    pPortInfo->uPortType = '1';
    pPortInfo->eZOrderRange = '1';
}

static inline void set_WFDPipeline_item(WFDPipeConfigType *pPipeInfo)
{
    // here is only for testing. the paras should get from fidm parameter
    // provider
    pPipeInfo->eQdiLayerId = '1';
    pPipeInfo->eZOrder = '1';
}

static inline void set_WFDPort_item(WFDClientConfigType *psClientInfo)
{
    // here is only for testing. the paras should get from fidm parameter
    // provider
    psClientInfo->uNumOfEnumeratedPorts = '1';
}

static inline void set_WFDClient_item(WFDClientConfigType *psClientInfo)
{
    // here is only for testing. the paras should get from API
    psClientInfo->uClientID = '1';
    psClientInfo->uClientType = '1';
}

static inline void set_WFDConfig_item(WFDDrvConfigType *pWFDConfigInfo)
{
    // here is only for testing. the paras should get from fidm parameter
    // provider
    pWFDConfigInfo->uNumOfEnumeratedClients = '2';
}

/** @brief  Create the PortAttribs xml node
 *
 *  @param[in]  root_node add to parent xml node
 *  @param[in]  pPortInfo Pointer to the structure WFDPortConfigType
 *  @return xml node
 */
static inline xmlNodePtr xml_PortAttribs(xmlNodePtr root_node,
                                         const WFDPortConfigType *pPortInfo)
{
    xmlNodePtr node = xmlNewNode(NULL, BAD_CAST "PortAttribs");
    xmlNodePtr content = xmlNewText(BAD_CAST "");
    xmlAddChild(root_node, node);
    xmlAddChild(node, content);
    xmlNewProp(node, BAD_CAST "eQDIDisplayID",
               BAD_CAST(xmlChar *) & (pPortInfo->eQdiDisplayId));
    xmlNewProp(node, BAD_CAST "uDisplayNode",
               BAD_CAST(xmlChar *) & (pPortInfo->uDisplayNode));
    xmlNewProp(node, BAD_CAST "ePortType",
               BAD_CAST(xmlChar *) & (pPortInfo->uPortType));
    xmlNewProp(node, BAD_CAST "eZOrderBase",
               BAD_CAST(xmlChar *) & (pPortInfo->eZOrderRange));
    xmlKeepBlanksDefault(0);
    return node;
}

/** @brief  Create the WFDPipeline xml node
 *
 *  @param[in]  root_node add to parent xml node
 *  @param[in]  pPipeInfo Pointer to the structure PortAttribs
 *  @return xml node
 */
static inline xmlNodePtr xml_WFDPipeline(xmlNodePtr root_node,
                                         const WFDPipeConfigType *pPipeInfo)
{
    xmlNodePtr node = xmlNewNode(NULL, BAD_CAST "WFDPipeline");
    xmlNodePtr content = xmlNewText(BAD_CAST "");
    xmlAddChild(root_node, node);
    xmlAddChild(node, content);
    xmlNewProp(node, BAD_CAST "eQDILayerID",
               BAD_CAST(xmlChar *) & (pPipeInfo->eQdiLayerId));
    xmlNewProp(node, BAD_CAST "eZOrder",
               BAD_CAST(xmlChar *) & (pPipeInfo->eZOrder));
    xmlKeepBlanksDefault(0);
    return node;
}

static inline xmlNodePtr xml_WFDPort(xmlNodePtr root_node,
                                     WFDClientConfigType *psClientInfo)
{
    xmlNodePtr node = xmlNewNode(NULL, BAD_CAST "WFDPort");
    xmlAddChild(root_node, node);
    xmlNewProp(node, BAD_CAST "ID",
               BAD_CAST(xmlChar *) & (psClientInfo->uNumOfEnumeratedPorts));
    xmlKeepBlanksDefault(0);

    return node;
}

static inline xmlNodePtr xml_WFDClient(xmlNodePtr root_node,
                                       WFDClientConfigType *psClientInfo)
{
    xmlNodePtr node = xmlNewNode(NULL, BAD_CAST "WFDClient");
    xmlAddChild(root_node, node);
    xmlNewProp(node, BAD_CAST "ID",
               BAD_CAST(xmlChar *) & (psClientInfo->uClientID));
    xmlNewProp(node, BAD_CAST "eWFDClientType",
               BAD_CAST(xmlChar *) & (psClientInfo->uClientType));
    xmlKeepBlanksDefault(0);
    return node;
}

static inline xmlNodePtr xml_WFDConfig(xmlNodePtr root_node)
{
    xmlNodePtr node = xmlNewNode(NULL, BAD_CAST "WFDConfig");
    xmlNodePtr content = xmlNewText(BAD_CAST "");
    xmlAddChild(node, content);
    xmlAddChild(root_node, node);
    xmlKeepBlanksDefault(0);
    return node;
}

/*=========================test sample=================================*/
static inline void creat_wfdconfig_node()
{
    WFDPortConfigType *pPortInfo = NULL;
    WFDPipeConfigType *pPipeInfo = NULL;
    WFDClientConfigType *psClientInfo = NULL;
    WFDDrvConfigType *pWFDConfigInfo = NULL;
    pPortInfo = (WFDPortConfigType *) malloc(sizeof(WFDPortConfigType));
    pPipeInfo = (WFDPipeConfigType *) malloc(sizeof(WFDPipeConfigType));
    psClientInfo = (WFDClientConfigType *) malloc(sizeof(WFDClientConfigType));
    pWFDConfigInfo = (WFDDrvConfigType *) malloc(sizeof(WFDDrvConfigType));
    set_PortAttribs_item(pPortInfo); // the info should get from fidm api.
    set_WFDPipeline_item(pPipeInfo);
    set_WFDPort_item(psClientInfo);
    set_WFDClient_item(psClientInfo);
    set_WFDConfig_item(pWFDConfigInfo);

    xmlDocPtr doc = xmlNewDoc(BAD_CAST "1.0"); // define doc and node pointer

    xmlNodePtr root_node = xmlNewNode(NULL, BAD_CAST "MDSSDrvCfg");

    xmlDocSetRootElement(doc, root_node);
    xmlNodePtr node = xml_WFDConfig(root_node);
    xmlNodePtr cNode = xml_WFDClient(node, psClientInfo);
    xmlNodePtr pNode = xml_WFDPort(cNode, psClientInfo);
    xml_PortAttribs(pNode, pPortInfo);
    xml_WFDPipeline(pNode, pPipeInfo);
    xmlKeepBlanksDefault(0);

    int nRel = xmlSaveFile("/tmp/CreateXml.xml", doc);
    if (nRel != -1) {
        printf("one xml created,writing %d bytes\n", nRel);
    }

    xmlFreeDoc(doc);
}

#ifdef __cplusplus
}
#endif

#endif
