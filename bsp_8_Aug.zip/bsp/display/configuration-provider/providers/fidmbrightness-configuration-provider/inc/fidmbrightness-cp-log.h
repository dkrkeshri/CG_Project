/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libcp_log.h
 *  @brief contains macros defined to log into slog or stderr
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 */

#ifndef  FIDMBRIGHTNESS_API_LOG_H
#define  FIDMBRIGHTNESS_API_LOG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/slog2.h>

extern char *__progname;
slog2_buffer_t buffer_handle;
int g_use_slog2;
/*
 * internal log level for the configuration provider
 * LOG_ERROR(0) equivalent to SLOG2_ERROR
 * LOG_INFO(1) equivalent to SLOG2_INFO
 * LOG_DEBUG(2) equivalent to SLOG2_DEBUG1
 **/
typedef enum{
    LEVEL_LOWER_LIMIT=-1,
    LOG_ERROR,
    LOG_INFO,
    LOG_DEBUG,
    LEVEL_UPPER_LIMIT
}log_level_t;

log_level_t g_log_level;

static int slogger2_init(void);

#define CP_PRINT_INFO(_str_, ...) \
    do { \
        if(g_log_level < LOG_INFO){\
            continue;\
        }\
        if (g_use_slog2) { \
            slog2f(buffer_handle, 0, SLOG2_INFO, \
                    "%s:%d: "_str_, __func__, __LINE__, ##__VA_ARGS__); \
        } else { \
            fprintf(stderr, "fidmbrightness-api-cp: %s:%d: "\
                    _str_ , __func__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)

#define CP_PRINT_ERROR(_str_, ...) \
    do { \
        if (g_use_slog2) { \
            slog2f(buffer_handle, 0, SLOG2_ERROR, \
                    " %s:%d: "_str_, __func__, __LINE__, ##__VA_ARGS__); \
        } else { \
            fprintf(stderr, "fidmbrightness-api-cp: %s:%d: "\
                    _str_ , __func__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)


#define CP_PRINT_DEBUG(_str_, ...) \
    do { \
        if(g_log_level < LOG_DEBUG){\
            continue;\
        }\
        if (g_use_slog2) { \
            slog2f(buffer_handle, 0,  SLOG2_DEBUG1, \
                    " %s:%d: "_str_, __func__, __LINE__, ##__VA_ARGS__); \
        } else { \
            fprintf(stderr, "fidmbrightness-api-cp: %s:%d: "\
                    _str_ , __func__, __LINE__, ##__VA_ARGS__); \
        } \
    } while(0)


#ifdef __cplusplus
}
#endif

#endif

