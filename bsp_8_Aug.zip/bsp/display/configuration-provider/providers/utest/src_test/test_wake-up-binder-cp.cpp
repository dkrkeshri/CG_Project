#include <fcntl.h>
#include <gmock/gmock.h>
#include "UT-unistd-mock.h"
#include "UT-semaphore-mock.h"
#include "wake-up-binder-cp-log.h"
#include "libconfig_provider_api.h"
#include "fidm-parameter-api.h"

class wake_up_binder_TEST: public ::testing::Test {
protected:
    UT_unistd_mock ut_unistd_mock_obj;
	UT_semaphore_mock ut_semaphore_mock_obj;
    void SetUp() override {
       ut_unistd_mock_ptr= &ut_unistd_mock_obj;
	   ut_semaphore_mock_ptr = &ut_semaphore_mock_obj;
       }
    void TearDown() override {
       ut_unistd_mock_ptr = NULL;
	   ut_semaphore_mock_ptr=NULL;
    }
};

TEST(wake_up_binder_cp, get_configuration_file_data_pass){
	int signo = 10;
	EXPECT_NE(0,get_configuration_file_data6(NULL));
}

TEST_F(wake_up_binder_TEST, signal_handler_pass){
	int signo = 1;
	EXPECT_CALL(ut_semaphore_mock_obj, mocked_sem_wait(_)).WillRepeatedly(Return(0));
	signal_handler6(signo);
	EXPECT_EQ(0,0); 
}

TEST(wake_up_binder_cp, display_help_pass){
	char array[32]={0x00};
	int signo = 10;
	display_help6(&array[0]);
	EXPECT_EQ(0,0);
}

TEST(wake_up_binder_cp, slogger2_init_pass){
	EXPECT_EQ(0,slogger2_init6());
}

TEST(wake_up_binder_cp, set_slog_level_pass){
	set_slog_level6();
	EXPECT_EQ(0,0);
}
TEST_F(wake_up_binder_TEST,stop_handling_request_pass){
	cphandle_t cp;
	stop_handling_request6((void*)&cp);
	EXPECT_EQ(0,0);
}

TEST_F(wake_up_binder_TEST,main_pass){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-f");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass1){
	char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-t");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass2){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-v");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass3){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-h");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass4){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-:");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass5){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-?");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}

TEST_F(wake_up_binder_TEST,main_pass6){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-?");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main6(argc, &argv[0]));
}
