#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#include <iostream>
#include <gmock/gmock.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#ifndef UNIT_TEST
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/slog2.h>
#include <sys/types.h>
#include <sys/stat.h>
#else
#include "slog2_header.h"
#include "ipc_mock.h"
#include "ipc_header.h"
#endif

#include <iostream>
#include <gmock/gmock.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


using ::testing::_;
using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

TxtDaemonIf  *hdl;

TEST(txtdaemon_common, tdi__close_pass){
	tdi__close(hdl);
	EXPECT_EQ(0,0);
}

TEST(txtdaemon_common, tdi__send_command_pass){
	char bUseStatusHdl;
	EXPECT_NE(0,tdi__send_command(hdl, bUseStatusHdl));
}

TEST(txtdaemon_common,tdi__reply_to_buf_pass){
	char *buffer;
	int buffersize;
	char bFirstLineOnly;
	EXPECT_NE(0,tdi__reply_to_buf(hdl, buffer, buffersize, bFirstLineOnly));
}

TEST(txtdaemon_common, tdi__notifier_register_pass){
	const char *maskmatch;
	int chan_id;
	EXPECT_NE(0,tdi__notifier_register(maskmatch,buffer, chan_id));
}

TEST(txtdaemon_common,tdi__notifier_unregister_pass){
	EXPECT_NE(0,tdi__notifier_unregister(hdl));
}

TEST(txtdaemon_common, tdi__notifier_get_msg_pass){
	unsigned int key;
	char *out_buffer;
	int buffermax;
	EXPECT_NE(0,tdi__notifier_get_msg(hdl,key,out_buffer, buffermax));
}

TEST(txtdaemon_common, tdi_load_textfile_pass){
	const char *filename;
	int *out_errno;
	EXPECT_NE(0, tdi_load_textfile(filename, out_errno));
}

TEST(txtdaemon_common, tdi__quote_string_pass){
	const char *string;
	char *buffer;
	unsigned int buffersize;
	EXPECT_NE(0,tdi__quote_string(string,buffer, buffersize));
}

TEST(txtdaemon_common, tdi__unquote_string_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	const char *ptr2string = &a;
	char *buffer;
	unsigned int buffersize;
	EXPECT_NE(0,tdi__unquote_string(&ptr2string,buffer, buffersize));
	free(a);
}