#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#ifndef UNIT_TEST
/*#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/slog2.h>
#include <sys/types.h>
#include <sys/stat.h>*/
#else
#include "slog2_header.h"
#include "ipc_mock.h"
#include "ipc_header.h"
#include "fidm_binder_cp_log.h"
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"
#endif


using namespace std;
class Gtest :public ::testing::Test
{
	public:
			const char *msg = "Testmsg";
			const std::string str = "Testmsg";
			const char *online = "online";
			void *ptr_to_log = "";
			const char *get_arg = NULL;
			const char *cmd = "-h";
			va_list args = "testcode to be tested";
	  fidm_binder_cpobj;
	Gtest(){

	}
	~Gtest(){
	}
};

Test(fidm_binder_cpobj,signal_handler){
	int signo = 1;
	fidm_binder_cpobj.signal_handler(signo);
	EXPECT_EQ(0,0);  
}
Test(fidm_binder_cpobj,slogger2_init){
	int ret = fidm_binder_cpobj.slogger2_init(void);
	EXPECT_EQ(0,ret);  
}
Test(fidm_binder_cpobj,set_slog_level){
	fidm_binder_cpobj.set_slog_level(void);
	EXPECT_EQ(0,0);  
}
Test(fidm_binder_cpobj,display_help){
	const char* self = "";
	fidm_binder_cpobj.display_help(self);
	EXPECT_EQ(0,0);  
}
Test(fidm_binder_cpobj,get_configuration_file_data){
	int ret = fidm_binder_cpobj.get_configuration_file_data(NULL);
	EXPECT_EQ(0,ret);  
}



