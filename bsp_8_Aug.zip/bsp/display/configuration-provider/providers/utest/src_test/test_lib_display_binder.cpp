#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#include <iostream>
#include <gmock/gmock.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#ifndef UNIT_TEST
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/slog2.h>
#include <sys/types.h>
#include <sys/stat.h>
#else
#include "slog2_header.h"
#include "ipc_mock.h"
#include "ipc_header.h"
#endif

TEST(lib_display_binder, displaybinder_ctrl_open_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	EXPECT_EQ(0,displaybinder_ctrl_open(a));
	free(a);
}

TEST(lib_display_binder, displaybinder_ctrl_close_pass){
	int handle;
	displaybinder_ctrl_close(handle);
	EXPECT_EQ(0,0);
}

TEST(lib_display_binder, displaybinder_ctrl_set_online_pass){
	int handle;
	EXPECT_EQ(0, displaybinder_ctrl_set_online(handle));
}

TEST(lib_display_binder, displaybinder_ctrl_set_offline_pass){
	int handle;
	EXPECT_EQ(0, displaybinder_ctrl_set_offline(handle));
}

TEST(lib_display_binder,displaybinder_ctrl_set_pass){
	int handle;
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	char *b =(char*) malloc(0x401);
	memset(b,0x00,0x401);
	memset(b,0x1,0x400);
	EXPECT_EQ(0, displaybinder_ctrl_set(handle, a,b);
	free(a);
	free(b);
}

TEST(lib_display_binder, displaybinder_ctrl_sw_update_pass){
	int handle;
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	unsigned int datasize;
	EXPECT_EQ(0, displaybinder_ctrl_sw_update(handle,a,datasize));
	free(a);
}

TEST(lib_display_binder, displaybinder_ctrl_sw_update_fh_pass){
	int handle;
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	int filehandle;
	EXPECT_EQ(0, displaybinder_ctrl_sw_update_fh(handle,a,filehandle));
	free(a);
}

TEST(lib_display_binder, displaybinder_ctrl_set_progressfunc_pass){
	int handle;
	void (*callback)(float progr_percent,void *ctx);
	vois *ctx;
	EXPECT_EQ(0, displaybinder_ctrl_set_progressfunc(handle,callback,ctx));
}

TEST(lib_display_binder, displaybinder_status_open_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	EXPECT_EQ(0, displaybinder_status_open(a));
	free(a);
}

TEST(lib_display_binder, displaybinder_status_close_pass){
	int handle;
	displaybinder_status_close(handle);
	EXPECT_EQ(0, 0);
}

TEST(lib_display_binder, displaybinder_status_get_pass){
	int handle;
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	char **status;
	EXPECT_EQ(0, displaybinder_ctrl_sw_update_fh(handle,a,&status));
	free(a);
}