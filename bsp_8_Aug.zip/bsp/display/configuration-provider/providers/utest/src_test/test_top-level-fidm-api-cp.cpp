#include <fcntl.h>
#include <gmock/gmock.h>
#include "UT-unistd-mock.h"
#include "UT-semaphore-mock.h"
#include "top-fidm-api-cp-log.h"
#include "libconfig_provider_api.h"
#include "fidm-parameter-api.h"

class top_fidm_api_TEST: public ::testing::Test {
protected:
    UT_unistd_mock ut_unistd_mock_obj;
	UT_semaphore_mock ut_semaphore_mock_obj;
    void SetUp() override {
       ut_unistd_mock_ptr= &ut_unistd_mock_obj;
	   ut_semaphore_mock_ptr = &ut_semaphore_mock_obj;
       }
    void TearDown() override {
       ut_unistd_mock_ptr = NULL;
	   ut_semaphore_mock_ptr=NULL;
    }
};

TEST(top_fidm_api_cp, get_configuration_file_data_pass){
	int signo = 10;
	EXPECT_NE(0,get_configuration_file_data7(NULL));
}

TEST_F(top_fidm_api_TEST, signal_handler_pass){
	int signo = 1;
	EXPECT_CALL(ut_semaphore_mock_obj, mocked_sem_wait(_)).WillRepeatedly(Return(0));
	signal_handler7(signo);
	EXPECT_EQ(0,0); 
}

TEST(top_fidm_api_cp, display_help_pass){
	char array[32]={0x00};
	int signo = 10;
	display_help7();
	EXPECT_EQ(0,0);
}

TEST(top_fidm_api_cp, slogger2_init_pass){
	EXPECT_EQ(0,slogger2_init7());
}

TEST(top_fidm_api_cp, set_slog_level_pass){
	set_slog_level7();
	EXPECT_EQ(0,0);
}

TEST_F(top_fidm_api_TEST,stop_handling_request_pass){
	cphandle_t cp;
	stop_handling_request7((void*)&cp);
	EXPECT_EQ(0,0);
}

TEST_F(top_fidm_api_TEST,main_pass){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-f");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass1){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-t");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass2){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-v");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass3){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-h");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass4){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-:");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass5){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-?");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}

TEST_F(top_fidm_api_TEST,main_pass6){
	 char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-?");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main7(argc, &argv[0]));
}
