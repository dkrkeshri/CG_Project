#include <fcntl.h>
#include <gmock/gmock.h>
#include <unistd.h>
#include "UT-unistd-mock.h"
#include "UT-semaphore-mock.h"
#include "screen-cp-log.h"
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

class screen_cp_TEST: public ::testing::Test {
protected:
    UT_unistd_mock ut_unistd_mock_obj;
	UT_semaphore_mock ut_semaphore_mock_obj;
    void SetUp() override {
       ut_unistd_mock_ptr= &ut_unistd_mock_obj;
	   ut_semaphore_mock_ptr = &ut_semaphore_mock_obj;
       }
    void TearDown() override {
       ut_unistd_mock_ptr = NULL;
	   ut_semaphore_mock_ptr=NULL;
    }
};

TEST(screen_cp, get_configuration_file_data_pass){
	screen_cp_data_t cp_data;
	int signo = 10;
	
	EXPECT_NE(0,get_configuration_file_data13(&cp_data));
}

TEST_F(screen_cp_TEST, signal_handler_pass){
	int signo = 1;
	EXPECT_CALL(ut_semaphore_mock_obj, mocked_sem_post(_)).WillRepeatedly(Return(0));
	signal_handler13(signo);
	EXPECT_EQ(0,0); 
}

TEST_F(screen_cp_TEST,stop_handling_request_pass){
	cphandle_t cp;
	EXPECT_CALL(ut_semaphore_mock_obj, mocked_sem_wait(_)).WillRepeatedly(Return(0));
	EXPECT_CALL(ut_semaphore_mock_obj, mocked_sem_destroy(_)).WillRepeatedly(Return(0));
	stop_handling_request13((void*)&cp);
	EXPECT_EQ(0,0);
}

TEST(screen_cp, fill_header_pass){
	char *mem = (char*)malloc(0x401);
	size_t mem_size;
	EXPECT_NE(0,fill_header13(mem,mem_size));
	free(mem);
}

TEST(screen_cp, fill_display_pass){
	char *mem = (char*)malloc(0x401);
	size_t mem_size;
	struct display_info d_info;
	EXPECT_NE(0,fill_display13(mem,mem_size,&d_info));
	free(mem);
}

TEST(screen_cp, gather_display_pass){
	fidm_parameter_api_io_state *obj2 = (fidm_parameter_api_io_state *)malloc(sizeof(fidm_parameter_api_io_state));
	obj2->command[0] = 0;
	int index=0;
	struct display_info d_info;
	EXPECT_NE(0,gather_display_info13(obj2,index,&d_info));
	free(obj2);
}

TEST(screen_cp, prepare_parametrized_pass){
	fidm_parameter_api_io_state *obj2 = (fidm_parameter_api_io_state *)malloc(sizeof(fidm_parameter_api_io_state));
	obj2->command[0] = 0;	
	char *mem= (char*)malloc(0x401);
	size_t mem_size = 0;
  usleep(100);
	EXPECT_NE(0,prepare_parametrized_config13(obj2,mem,mem_size));
	free(mem);
	free(obj2);
}

TEST(screen_cp, configuration_file_pass){
	screen_cp_data_t *cp_data = NULL ;
	EXPECT_NE(0,configuration_file_read13(cp_data));
}


TEST(screen_cp, get_configuration_file_pass){
	screen_cp_data_t *cp_data =NULL;
	EXPECT_NE(0,get_configuration_file_data13(cp_data));
}

TEST_F(screen_cp_TEST,main_pass){
	char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-f");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_NE(0,main13(argc, &argv[0]));
}