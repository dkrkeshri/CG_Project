/**
*  @swcomponent Config provider Library
*  @{
*  @file libcp_log.h
*  @brief contains macros defined to log into slog or stderr
*  @copyright (C) 2020 Robert Bosch GmbH.
*           The reproduction, distribution and utilization of this file as
*           well as the communication of its contents to others without express
*           authorization is prohibited. Offenders will be held liable for the
*           payment of damages. All rights reserved in the event of the grant
*           of a patent, utility model or design.
* @}
*/

#ifndef SCREEN_API_CP_LOG_H
#define SCREEN_API_CP_LOG_H

#ifdef __cplusplus
extern "C" {
#endif
#ifndef UNIT_TEST
#include <sys/slogcodes.h>
#else
#include "slog2_header.h"
#include "ipc_mock.h"
#include "ipc_header.h"
#endif
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

/**
 * By default slog is used define USE_SLOG_DEBUG as 0
 * to output logs into stderr
 */
#define USE_SLOG_DEBUG 0

typedef struct screen_cp_data {
    cphandle_t cp;
    char config_source_path[PATH_MAX];
    void *file_data;
    int file_size;
    pthread_t thread;
} screen_cp_data_t;

struct display_info {
    unsigned int index;
    unsigned int pixel_height;
    unsigned int pixel_width;
    unsigned int frame_rate;
};

/**
 * Following macro is used to create an opcode for the slogger.
 * This should be already defined in slogger_opcode.h found in
 * <GM VCU ROOT>/vcu/qnx/bosch/common/headers
 *
 */

#ifndef _SLOGC_SCREEN_CP
#define _SLOGC_SCREEN_CP _SLOGC_PRIVATE_START + 4002
#endif
#ifdef UNIT_TEST
int main13(int argc, char **argv);
int get_configuration_file_data13(screen_cp_data_t* cp_data);
void* stop_handling_request13(void *arg);
void signal_handler13(int signo);
int fill_header13(char *mem, size_t mem_size);
int fill_display13(char *mem, size_t mem_size, struct display_info *d_info);
int gather_display_info13(fidmParaApiHdl handle, int index,struct display_info *d_info);
int prepare_parametrized_config13(fidmParaApiHdl pp_hdl, char *mem, size_t mem_size);
int configuration_file_read13(screen_cp_data_t *cp_data);
#endif
#define CP_PRINT_INFO(_str_, ...)                                              \
    do {                                                                       \
        if (USE_SLOG_DEBUG) {                                                  \
            slogf(_SLOG_SETCODE(_SLOGC_SCREEN_CP, 0), _SLOG_INFO,              \
                  "libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__);   \
        } else {                                                               \
            fprintf(stderr, "libcp: %s:%d: ",_str_, __func__, __LINE__,         \
                    ##__VA_ARGS__);                                            \
        }                                                                      \
    } while (0)

#define CP_PRINT_ERROR(_str_, ...)                                             \
    do {                                                                       \
        if (USE_SLOG_DEBUG) {                                                  \
            slogf(_SLOG_SETCODE(_SLOGC_SCREEN_CP, 0), _SLOG_ERROR,             \
                  "libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__);   \
        } else {                                                               \
            fprintf(stderr, "libcp: %s:%d: ",_str_, __func__, __LINE__,         \
                    ##__VA_ARGS__);                                            \
        }                                                                      \
    } while (0)

#define CP_PRINT_DEBUG(_str_, ...)                                             \
    do {                                                                       \
        if (0) {                                                               \
            slogf(_SLOG_SETCODE(_SLOGC_SCREEN_CP, 0), _SLOG_DEBUG1,            \
                  "libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__);   \
        } else {                                                               \
            fprintf(stderr, "libcp %s:%d: ",_str_, __func__, __LINE__,          \
                    ##__VA_ARGS__);                                            \
        }                                                                      \
    } while (0)

#ifdef __cplusplus
}
#endif

#endif
