/**
* @swcomponent SCREEN CONFIG PROVIDER
* @{
* @file screen-config-provider
* @brief Generate dynamic configuration file for SCREEN
* @copyright (C) 2020 Robert Bosch GmbH.
*           The reproduction, distribution and utilization of this file as
*           well as the communication of its contents to others without express
*           authorization is prohibited. Offenders will be held liable for the
*           payment of damages. All rights reserved in the event of the grant
*           of a patent, utility model or design.
* @}
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#ifndef UNIT_TEST
#include <semaphore.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#else
#include "UT-unistd-mock.h"
#include "UT-semaphore-mock.h"
#endif
#include "screen-cp-log.h"
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

//#define DEBUG
#define DEFAULT_GENERATED_CONFIG_SIZE 4096
#define SCREEN_DEFAULT_CONFIG_PATH_NAME "/dev/provider/graphics.conf"
#define PREDEFINED_QCCONFIG_PROP                                               \
    "/display-infrastructure/exports/screen-config-source"

/*Unnamed semaphore to be used by the signal handler*/
static sem_t sem;

/**
 *@brief Signal handler posts a semaphore when SIGINT is received
 *
 *@param[in] signo signal number not used
 */
#ifdef UNIT_TEST
void signal_handler13(int signo)
#else
void signal_handler(int signo)
#endif
{
    CP_PRINT_DEBUG("signal handler called\n");
    if (-1 == sem_post(&sem)) {
        CP_PRINT_ERROR("sem_post FAILED %s", strerror(errno));
    }
}
/**
 * @brief  Request for stopping the resource manager from
 *         handling client requests once SIGINT is received
 *         by the process
 *
 * @param[in] arg cp_handle_t cast to void pointer
 */
#ifdef UNIT_TEST
void* stop_handling_request13(void *arg)
#else
static void *stop_handling_request(void *arg)
#endif
{
    cphandle_t cp = (cphandle_t) arg;

    /*wait for signal*/
    #ifdef UNIT_TEST
    if (-1 == mocked_sem_wait(&sem)) {
    #else
    if (-1 == sem_wait(&sem)) {
    #endif
        CP_PRINT_ERROR("sem_wait FAILED %s", strerror(errno));
        goto exit;
    }
    CP_PRINT_DEBUG("Requesting to quit\n");
    libcp_stop_request(cp);
    #ifdef UNIT_TEST
    if (-1 == mocked_sem_destroy(&sem)) {
    #else
    if (-1 == sem_destroy(&sem)) {
    #endif
        CP_PRINT_ERROR("sem_destroy FAILED %s", strerror(errno));
        goto exit;
    }

exit:
    return (void *) NULL;
}

/** @brief  stores the head of qcddisplaycfg in a buffer
 *      To be called only once.
 *
 *  @param[in]  mem Pointer to the config provider data
 *  @param[in]  mem_size Maximum number of bytes to be used in the buffer
 *  @return Upon successful return, these functions return the number of
 *      characters printed
 */
#ifdef UNIT_TEST
int fill_header13(char *mem, size_t mem_size)
#else
static int fill_header(char *mem, size_t mem_size)
#endif
{
    char *str = "begin khronos\n \
  begin egl display 1\n \
    egl-dlls = libESXEGL_Adreno.so\n \
    glesv2-dlls = libESXGLESv2_Adreno.so\n \
    glesv1-dlls = libESXGLESv1_CM_Adreno.so\n \
    eglsub-dlls = libscreen.so.1 libeglSubDriverQnx.so\n \
    c2d-dlls = c2d30.so\n \
    gralloc-module = Adreno\n \
  end egl display\n \
                  \n \
  begin wfd device 1\n \
    wfd-dlls = libopenwfd_qnx.so\n \
  end wfd device\n \
end khronos\n \
  \n \
begin winmgr\n \
  begin globals\n \
    blit-config = sw\n \
    input = keyboard,mouse\n \
    default-display = 1\n \
  end globals\n \
  \n";

    return snprintf(mem, mem_size, str);
}

/** @brief file display information from parameter
 *      provider and stores the file content in a buffer.
 *      To be called only once.
 *
 *  @param[in]  mem Pointer to store the display config
 *  @param[in]  mem_size Maximum number of bytes to be used in the buffer
 *  @param[in]  d_info display information from parameter provider
 *  @return Upon successful return, these functions return the number of
 *          characters printed
 */
#ifdef UNIT_TEST
int fill_display13(char *mem, size_t mem_size, struct display_info *d_info)
#else
static int fill_display(char *mem, size_t mem_size, struct display_info *d_info)
#endif
{
    char *str = "  begin display %d\n \
    video-mode = %d x %d @ %d\n \
    cursor = auto\n \
  end display\n \
        \n\
  begin class framebuffer%d\n \
    display = %d\n \
    format = rgba8888\n \
    usage = gles2\n \
  end class\n \
  \n";
    return snprintf(mem, mem_size, str, d_info->index, d_info->pixel_width,
                    d_info->pixel_height, d_info->frame_rate, d_info->index,
                    d_info->index);
}

/** @brief  gather display information from parameter
 *      provider and stores the file content in a buffer.
 *      To be called only once.
 *
 *  @param[in]  handle from the parameter provider
 *  @param[in]  index to the display
 *  @param[in]  d_info display information from parameter provider
 *  @return return 0 for success and -1 for failure
 */
#ifdef UNIT_TEST
int gather_display_info13(fidmParaApiHdl handle, int index,
                               struct display_info *d_info)
#else
static int gather_display_info(fidmParaApiHdl handle, int index,
                               struct display_info *d_info)
#endif
{
    int ret = 0;
    char tmp[1024];
    snprintf(tmp, sizeof(tmp),
             "/display-infrastructure/displays/%u/screen-params/display-index",
             index);
    ret = fidm_parameter_api_unsigned(handle, tmp, &d_info->index);
    if (ret) {
        CP_PRINT_ERROR("index not found for the display %u, skipping entry\n",
                       index);
        return ret;
    }
    snprintf(tmp, sizeof(tmp),
             "/display-infrastructure/displays/%u/panel/timings/active-width",
             index);
    ret = fidm_parameter_api_unsigned(handle, tmp, &d_info->pixel_width);
    if (ret) {
        CP_PRINT_ERROR("Width not found for the display %u, skipping entry\n",
                       index);
        return ret;
    }
    snprintf(tmp, sizeof(tmp),
             "/display-infrastructure/displays/%u/panel/timings/active-height",
             index);
    ret = fidm_parameter_api_unsigned(handle, tmp, &d_info->pixel_height);
    if (ret) {
        CP_PRINT_ERROR("height not found for the display %u, skipping entry\n",
                       index);
        return ret;
    }
    snprintf(tmp, sizeof(tmp),
             "/display-infrastructure/displays/%u/panel/timings/framerate",
             index);
    ret = fidm_parameter_api_unsigned(handle, tmp, &d_info->frame_rate);
    if (ret) {
        CP_PRINT_ERROR(
            "framerate not found for the display %u, skipping entry\n", index);
        return ret;
    }
    return ret;
}

/** @brief  Prepare the parametrized config and stores in a buffer.
 *      To be called only once.
 *
 *  @param[in]   fidmParaApiHdl from the parameter provider
 *  @param[in]   mem Pointer to store the display config
 *  @param[in]   mem_size Maximum number of bytes to be used in the buffer
 *  @return return buffer size for success and -1 for failure
 */
#ifdef UNIT_TEST
int prepare_parametrized_config13(fidmParaApiHdl pp_hdl, char *mem,
                                       size_t mem_size)
#else
static int prepare_parametrized_config(fidmParaApiHdl pp_hdl, char *mem,
                                       size_t mem_size)
#endif
{
    struct display_info d_info;
    int display_count;
    int cnt;
    int ret = 0;
    int offset = 0;

    if (fidm_parameter_api_path_exists(
            pp_hdl, "/display-infrastructure/displays") < 1) {
        CP_PRINT_ERROR("No displays node given\n");
        return -1;
    }
    #ifdef UNIT_TEST
    offset += fill_header13(mem, mem_size);
    #else
    offset += fill_header(mem, mem_size);
    #endif

    display_count = fidm_parameter_api_list_length(
        pp_hdl, "/display-infrastructure/displays");
    for (cnt = 0; cnt < display_count; cnt++) {
        if (mem_size < offset)
            return -1;

        #ifdef UNIT_TEST
        ret = gather_display_info13(pp_hdl, cnt, &d_info);
        #else
        ret = gather_display_info(pp_hdl, cnt, &d_info);
        #endif

        if (ret) {
            CP_PRINT_ERROR("gather display info FAILED: %d", ret);
            return ret;
        }
        #ifdef UNIT_TEST
        ret = fill_display13(mem + offset, mem_size - offset, &d_info);
        #else
        ret = fill_display(mem + offset, mem_size - offset, &d_info);
        #endif

        if (ret < 0) {
            CP_PRINT_ERROR("fill display FAILED: %d", ret);
            return ret;
        }

        offset += ret;
    }
    // Add closing statements for the file
    offset += snprintf(mem + offset, mem_size - offset, "end winmgr");
    ret = offset;
    return ret;
}

/** @brief  Reads configuration file collected from parameter
 *      provider and stores the file content in a buffer.
 *      To be called only once.
 *
 *  @param[in]  cp_data Pointer to the config provider data
 *  @return return buffer size for success and -1 for failure
 */
#ifdef UNIT_TEST
int configuration_file_read13(screen_cp_data_t *cp_data)
#else
static int configuration_file_read(screen_cp_data_t *cp_data)
#endif
{
    FILE *fp;
    int ret = 0;
    int file_size;

    CP_PRINT_DEBUG("source configuration path: %s\n",
                   cp_data->config_source_path);
    fp = fopen(cp_data->config_source_path, "r");
    if (NULL == fp) {
        CP_PRINT_ERROR("fopen FAILED: %s", strerror(errno));
        ret = -1;
        goto exit;
    }

    /*get the size of the file*/
    ret = fseek(fp, 0L, SEEK_END);
    if (-1 == ret) {
        CP_PRINT_ERROR("fseek to end FAILED: %d", ret);
        goto exit;
    }

    file_size = ftell(fp);

    if (cp_data->file_size < file_size) {
        CP_PRINT_ERROR("Actual file size exceeds pre-allocated memory");
        ret = -1;
        goto exit;
    }

    if (-1 == file_size) {
        CP_PRINT_ERROR("ftell FAILED: %s", strerror(errno));
        ret = -1;
        goto exit;
    }

    cp_data->file_size = file_size;

    /*reset stream position to begining of file*/
    ret = fseek(fp, 0L, SEEK_SET);
    if (ret) {
        CP_PRINT_ERROR("fseek to beginning FAILED: %d", ret);
        goto exit;
    }

    ret = fread(cp_data->file_data, 1, cp_data->file_size, fp);
    CP_PRINT_DEBUG("%u of %u were read\n", ret, cp_data->file_size);

exit:
    if (fp) {
        fclose(fp);
    }
    return ret;
}

/** @brief  Reads configuration file collected from parameter
 *      provider and stores the file content in a buffer.
 *      To be called only once.
 *
 *  @param[in]  cp_data Pointer to the config provider data
 *  @return return size of resulting configuration and -1 for failure
 */
#ifdef UNIT_TEST
int get_configuration_file_data13(screen_cp_data_t *cp_data)
#else
static int get_configuration_file_data(screen_cp_data_t *cp_data)
#endif
{
    fidmParaApiHdl pp_hdl;
    int ret = 0;

    /*get configurtion file path from FIDM parameter provider*/
    pp_hdl = fidm_parameter_api_open();
    if (NULL == pp_hdl) {
        CP_PRINT_ERROR("fidm_parameter_api_open FAILED\n");
        ret = -1;
        goto exit;
    }

    /*check if property exists*/
    ret = fidm_parameter_api_string(pp_hdl, PREDEFINED_QCCONFIG_PROP,
                                    cp_data->config_source_path,
                                    sizeof(cp_data->config_source_path));
    if (ret) {
        // Parameter doesn't exist
        // We can try to gather parameters and generate the file on the
        // flight
        CP_PRINT_ERROR("Failed to get source name\n");
        #ifdef UNIT_TEST
        ret = prepare_parametrized_config13(pp_hdl, (char*)cp_data->file_data,
                                          cp_data->file_size);
        #else
        ret = prepare_parametrized_config(pp_hdl, cp_data->file_data,
                                          cp_data->file_size);
        #endif
        if (ret < 1) {
            CP_PRINT_ERROR("prepare config FAILED: %d", ret);
            goto exit;
        }
    } else {
        #ifdef UNIT_TEST
        ret = configuration_file_read13(cp_data);
        #else
        ret = configuration_file_read(cp_data);
        #endif
        if (ret < 1) {
            CP_PRINT_ERROR("config file read FAILED: %d", ret);
            goto exit;
        }
    }

exit:
    if (pp_hdl) {
        fidm_parameter_api_close(pp_hdl);
    }

    return ret;
}
#ifdef UNIT_TEST
int main13(int argc, char **argv)
#else
int main(int argc, char **argv)
#endif
{
    screen_cp_data_t *cp_data;
    int thread_err = EOK;
    int ret = 0;

    cp_data = (screen_cp_data_t*)calloc(1, sizeof(screen_cp_data_t));
    if (NULL == cp_data) {
        CP_PRINT_ERROR("Unable to allocate memory for cp_data: %s",
                       strerror(errno));
        ret = -1;
        goto exit;
    }
    cp_data->file_size = DEFAULT_GENERATED_CONFIG_SIZE;
    cp_data->file_data = (char *) calloc(1, cp_data->file_size);
    if (NULL == cp_data->file_data) {
        CP_PRINT_ERROR("could not allocate memory for file_data: %s",
                       strerror(errno));
        ret = -1;
        goto exit;
    }

    /*fill configuration file data*/
    #ifdef UNIT_TEST
    cp_data->file_size = get_configuration_file_data13(cp_data);
    #else
    cp_data->file_size = get_configuration_file_data(cp_data);
    #endif

    if (cp_data->file_size < 1) {
        CP_PRINT_ERROR("Failed to get configuration file data\n");
        ret = -1;
        goto exit;
    }

#ifdef DEBUG
    if (cp_data && cp_data->file_data) {
        fwrite(cp_data->file_data, 1, cp_data->file_size, stdout);
    }
#endif
    /*create an instance of config provider resource manager*/
    cp_data->cp = libcp_create(SCREEN_DEFAULT_CONFIG_PATH_NAME);
    if (NULL == cp_data->cp) {
        CP_PRINT_ERROR("libcp_create FAILED\n");
        ret = -1;
        goto exit;
    }

    /*provide data to fill up the configuration file*/
    ret = libcp_set_data(cp_data->cp, (const char*)cp_data->file_data, cp_data->file_size);

    /*free file data irrespective of success or failure*/
    free(cp_data->file_data);
    cp_data->file_data = NULL;
    cp_data->file_size = 0;
    if (ret != 0) {
        CP_PRINT_ERROR("libcp_set_data FAILED\n");
        goto destroy;
    }

    /*create the configuration file node*/
    ret = libcp_create_node(cp_data->cp);
    if (ret != 0) {
        CP_PRINT_ERROR("libcp_create_node FAILED\n");
        goto destroy;
    }

    /*Block SIGINT*/
    thread_err = sem_init(&sem, 0, 0);
    if (thread_err != 0) {
        CP_PRINT_ERROR("sem_init FAILED with %s", strerror(errno));
    } else {
        thread_err = EOK;
#ifndef UNIT_TEST
        signal(SIGINT, signal_handler);
        signal(SIGABRT, signal_handler);
#endif
    }
    /*create thread to quit*/
    if (EOK == thread_err) {
        #ifdef UNIT_TEST
        thread_err = pthread_create(&cp_data->thread, NULL,
                                    stop_handling_request13, cp_data->cp);
        #else
        thread_err = pthread_create(&cp_data->thread, NULL,
                                    stop_handling_request, cp_data->cp);
        #endif
        if (thread_err != EOK) {
            CP_PRINT_ERROR("pthread_create FAILED with %d\n", thread_err);
        }
    }

    /*handle read request made to the configuration file*/
    ret = libcp_handle_req(cp_data->cp);
    if (ret != 0) {
        CP_PRINT_ERROR("libcp_handle_req FAILED\n");
    }

    if (EOK == thread_err) {
        thread_err = pthread_join(cp_data->thread, NULL);
        CP_PRINT_INFO("pthread_joined returned with %d\n", thread_err);
    }

    /*remove the configuration file node*/
    ret = libcp_remove_node(cp_data->cp);

    if (-1 == ret) {
        CP_PRINT_ERROR("libcp_remove_node FAILED\n");
    }

destroy:
    /*free config provider resource manager data*/
    libcp_destroy(cp_data->cp);
exit:
    if (cp_data) {
        free(cp_data->file_data);
        free(cp_data);
    }

    if (ret) {
        return -1;
    } else {
        return 0;
    }
}
