/**
* @swcomponent serializer access layer configuration provider
* @file sal_cp.c
* @brief Generate configuration provider for serializer access layer
* @copyright (C) 2020 Robert Bosch GmbH.
*                The reproduction, distribution and utilization of this file as
*                well as the communication of its contents to others without express
*                authorization is prohibited. Offenders will be held liable for the
*                payment of damages. All rights reserved in the event of the grant
*                of a patent, utility model or design.
* @}
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#ifndef UNIT_TEST
#include <semaphore.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/slog2.h>
#include <sys/types.h>
#include <sys/stat.h>
#else
#include "UT-unistd-mock.h"
#include "UT-semaphore-mock.h"
#endif
#include "sal_cp_log.h"
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

//#define DEBUG
#define DEFAULT_CONFIG_PATH_NAME "/dev/provider/serializer-access-layer.json"
#define PREDEFINED_QCCONFIG_PROP \
	"/display-infrastructure/exports/serializer-access-layer-config-source"


/*Unnamed semaphore to be used by the signal handler*/
static sem_t sem;

/**
 *@brief Signal handler posts a semaphore when SIGINT is received
 *
 *@param[in] signo signal number not used
 */
#ifdef UNIT_TEST
void signal_handler0(int signo)
#else
void signal_handler(int signo)
#endif
{
	CP_PRINT_DEBUG("signal handler called\n");
	if(-1 == sem_post(&sem))
	{
		CP_PRINT_ERROR("sem_post FAILED %s", strerror(errno));
	}
}
/**
 * @brief  Request for stopping the resource manager from
 *         handling client requests once SIGINT is received
 *         by the process
 *
 * @param[in] arg cp_handle_t cast to void pointer
 */
#ifdef UNIT_TEST
void* stop_handling_request0(void *arg)
#else
static void* stop_handling_request(void *arg)
#endif
{
	cphandle_t cp = (cphandle_t)arg;

	/*wait for signal*/
	if(-1 == sem_wait(&sem))
	{
		CP_PRINT_ERROR("sem_wait FAILED %s", strerror(errno));
		goto exit;
	}
	CP_PRINT_DEBUG("Requesting to quit\n");
	libcp_stop_request(cp);

	if(-1 == sem_destroy(&sem))
	{
		CP_PRINT_ERROR("sem_destroy FAILED %s", strerror(errno));
		goto exit;
	}

exit:
	return (void*)NULL;
}

/**
 * @brief  register to use slog2
 */
#ifdef UNIT_TEST
int slogger2_init0(void)
#else
static int slogger2_init(void)
#endif
{
	slog2_buffer_set_config_t buffer_config;
	buffer_config.buffer_set_name = __progname;
	buffer_config.num_buffers = 1;
	buffer_config.verbosity_level = SLOG2_INFO;
	buffer_config.buffer_config[0].buffer_name = "sal_cp";
	buffer_config.buffer_config[0].num_pages = 8;

	if (slog2_register(&buffer_config, &buffer_handle, 0)){
		return -1;
	}
	return 0;
}
/**
 * @brief  sets log level for slogger2
 */

#ifdef UNIT_TEST
void set_slog_level0(void)
#else
static void set_slog_level(void)
#endif
{
	int ret = -1;
	switch(g_log_level)
	{
		case LOG_ERROR:
			ret = slog2_set_verbosity(buffer_handle, SLOG2_ERROR);
			break;

		case LOG_INFO:
			ret = slog2_set_verbosity(buffer_handle, SLOG2_INFO);
			break;

		case LOG_DEBUG:
			ret = slog2_set_verbosity(buffer_handle, SLOG2_DEBUG1);
			break;

		default:
			CP_PRINT_ERROR("Trying to set wrong log level %d\n",
					g_log_level);
	}

	if(-1 == ret){
		CP_PRINT_ERROR("Setting log_level %d failed\n", g_log_level);
	}
}

/**
 * @brief  displays usage information
 */
#ifdef UNIT_TEST
void display_help0(const char* self)
#else
static void display_help(const char* self)
#endif
{
	printf( "%s - configuration provider for serializer access layer\n\n"
			"Usage: %s [OPTIONS]\n\n"
			"Options:\n"
			"-f [DEVICE NODE] - Over-ride the default device node path with [DEVICE NODE]\n"
			"-t               - Display logs in console(tty) instead of slog2\n"
			"                   By default slog2 is used\n"
			"-v [LOG LEVEL]   - Set log level. By default set to 0\n"
			"                   [LOG LEVEL] and their corresponding slog2 levels are:\n"
			"                   | LOG LEVEL | SLOG2_LOG_LEVEL |\n"
			"                   |-----------|-----------------|\n"
			"                   |     0     |    SLOG2_ERROR  |\n"
			"                   |     1     |    SLOG2_INFO   |\n"
			"                   |     2     |    SLOG2_DEBUG1 |\n"
			"-h               - Print Usage message\n\n"
			,self,self
                        );
}

/** @brief  Reads configuration file collected from parameter
 * 	    provider and stores the file content in a buffer.
 * 	    To be called only once.
 *
 *  @param[in]  cp_data Pointer to the config provider data
 *  @return 0 for success and -1 for failure
 */
#ifdef UNIT_TEST
int get_configuration_file_data0(sal_cp_data_t* cp_data)
#else
static int get_configuration_file_data(sal_cp_data_t* cp_data)
#endif
{
	FILE *fp = NULL;
	int ret = 0;
	int fd = -1;
	struct stat stbuf = {0};

	if(NULL == cp_data){
		return -1;
	}

	fp = fopen(cp_data->config_source_path, "r");
	if(NULL == fp){
		CP_PRINT_ERROR("fopen FAILED: %s", strerror(errno));
		goto fail;
	}
	fd = fileno(fp);

	/*get the size of the file*/
	ret = fstat(fd,&stbuf);
	if(-1 == ret){
		CP_PRINT_ERROR("fstat FAILED: %s", strerror(errno));
		goto fail;
	}

	cp_data->file_size = stbuf.st_size;

	/*copy the file content*/
	cp_data->file_data = (char*)calloc(1,cp_data->file_size);
	if(NULL == cp_data->file_data)
	{
		CP_PRINT_ERROR("could not allocate memory for file_data: %s",
				strerror(errno));
		goto fail;
	}

	ret = fread(cp_data->file_data, 1, cp_data->file_size, fp);
	CP_PRINT_DEBUG("%u of %u were read\n",ret, cp_data->file_size);

	fclose(fp);
	return 0;
fail:
	if(fp)
	{
		fclose(fp);
	}

	if(cp_data->file_data)
	{
		free(cp_data->file_data);
		cp_data->file_data = NULL;
		cp_data->file_size = 0;
	}
	return -1;

}
#ifdef UNIT_TEST
int main0(int argc, char **argv)
#else
int main(int argc, char **argv)
#endif
{
	sal_cp_data_t* cp_data = NULL;
	int ret = 0;
	int opt;
	char resmgr_path[PATH_MAX] = DEFAULT_CONFIG_PATH_NAME;
	int log_level = 0;
	int thread_err = EOK;
	g_use_slog2 = 1;
	g_log_level = LOG_ERROR;
#ifdef UNIT_TEST
	if((opt = mock1_getopt(argc, argv, ":f:v:th")) != -1) {
	#else
	while ((opt = getopt(argc, argv, ":f:v:th")) != -1) {
	#endif
		switch (opt) {
			case 'f':
				/*TODO: Add check for valid file path*/
				memset(resmgr_path, 0, PATH_MAX);
				strncpy(resmgr_path, optarg, PATH_MAX);
				resmgr_path[PATH_MAX-1] = '\0';
				break;

			case 't':
				g_use_slog2 = 0;
				break;

			case 'v':
				log_level = atoi(optarg);
				if(log_level > LEVEL_LOWER_LIMIT
						&& log_level < LEVEL_UPPER_LIMIT){
					g_log_level = (log_level_t) log_level;
				}else{
					#ifdef UNIT_TEST
					display_help0(argv[0]);
					#else
					display_help(argv[0]);
					#endif
					return EXIT_FAILURE;
				}

				break;

			case 'h':
				#ifdef UNIT_TEST
				display_help0(argv[0]);
				#else
				display_help(argv[0]);
				#endif
				return EXIT_SUCCESS;
				break;

			case ':':
				printf("please provide path after -%c\n", optopt);
				#ifdef UNIT_TEST
				display_help0(argv[0]);
				#else
				display_help(argv[0]);
				#endif
				return EXIT_FAILURE;
				break;

			case '?':
				printf("unknown option: %c\n", optopt);
				#ifdef UNIT_TEST
				display_help0(argv[0]);
				#else
				display_help(argv[0]);
				#endif
				return EXIT_FAILURE;
				break;

			default:
				printf("unknown argument: %c\n", optopt);
				#ifdef UNIT_TEST
				display_help0(argv[0]);
				#else
				display_help(argv[0]);
				#endif
				return EXIT_FAILURE;
				break;
		}
    }

	if(g_use_slog2){
		#ifdef UNIT_TEST
		ret = slogger2_init0();
		#else
		ret = slogger2_init();
		#endif
		if(-1 == ret){
			g_use_slog2 = 0;
			CP_PRINT_ERROR(
			"slogger2_init failed fallback to console output\n");
		}
		else{
			#ifdef UNIT_TEST
			set_slog_level0();
			#else
			set_slog_level();
			#endif
			CP_PRINT_INFO("slogger2 will be used for logging\n");
		}
	}

	CP_PRINT_INFO("log level set to %d\n", g_log_level);

	cp_data = (sal_cp_data*)calloc(1, sizeof(sal_cp_data_t));
	if(NULL == cp_data){
		CP_PRINT_ERROR("Unable to allocate memory for cp_data: %s",
							strerror(errno));
		return EXIT_FAILURE;
	}

	/*get configurtion file path from FIDM parameter provider*/
	cp_data->pp_hdl = fidm_parameter_api_open();
	if(NULL == cp_data->pp_hdl){
		CP_PRINT_ERROR("fidm_parameter_api_open FAILED\n");
		return EXIT_FAILURE;
	}

	/*check if property exists*/
	ret = fidm_parameter_api_path_exists(cp_data->pp_hdl,
					PREDEFINED_QCCONFIG_PROP);
	if(ret < 1){
		CP_PRINT_ERROR("%s property not defined\n",
					PREDEFINED_QCCONFIG_PROP);
		fidm_parameter_api_close(cp_data->pp_hdl);
		return EXIT_FAILURE;
	}

	/*read value of the property*/
	ret = fidm_parameter_api_string(cp_data->pp_hdl,
			PREDEFINED_QCCONFIG_PROP, cp_data->config_source_path,
			sizeof(cp_data->config_source_path));
	if(ret){
		CP_PRINT_ERROR("Failed to get source name\n");
		fidm_parameter_api_close(cp_data->pp_hdl);
		return EXIT_FAILURE;
	}else{
		CP_PRINT_DEBUG("source configuration path: %s\n",
				cp_data->config_source_path);
	}
	/*close handle*/
	fidm_parameter_api_close(cp_data->pp_hdl);

	/*fill configuration file data*/
	#ifdef UNIT_TEST
	ret = get_configuration_file_data0(cp_data);
	#else
	ret = get_configuration_file_data(cp_data);
	#endif

	if(ret)
	{
		printf("Failed to get configuration file data\n");
		goto exit;
	}

#ifdef DEBUG
	if(cp_data && cp_data->file_data)
	{
		fwrite(cp_data->file_data, 1, cp_data->file_size, stdout);
	}
#endif

	/*create an instance of config provider resource manager*/
	cp_data->cp = libcp_create(resmgr_path);
	if(NULL == cp_data->cp){
		CP_PRINT_ERROR("libcp_create FAILED\n");
		ret = -1;
		goto exit;
	}

	/*provide data to fill up the configuration file*/
	ret = libcp_set_data(cp_data->cp, (const char*)cp_data->file_data,
			cp_data->file_size);

	/*free file data irrespective of success or failure*/
	free(cp_data->file_data);
	cp_data->file_data = NULL;
	cp_data->file_size = 0;
	if(ret != 0){
		CP_PRINT_ERROR("libcp_set_data FAILED\n");
		goto destroy;
	}

	/*create the configuration file node*/
	ret = libcp_create_node(cp_data->cp);
	if(ret != 0){
		CP_PRINT_ERROR("libcp_create_node FAILED\n");
		goto destroy;
	}

	/*Block SIGINT*/
	thread_err = sem_init(&sem, 0, 0);
	if(thread_err != 0){
		CP_PRINT_ERROR("sem_init FAILED with %s",strerror(errno));
	}else{
		thread_err = EOK;
#ifndef UNIT_TEST
		signal(SIGINT, signal_handler);
#endif
	}
	/*create thread to quit*/
	if(EOK == thread_err){
		#ifdef UNIT_TEST
		thread_err = pthread_create(&cp_data->thread, NULL,
			stop_handling_request0, cp_data->cp);
		#else
		thread_err = pthread_create(&cp_data->thread, NULL,
			stop_handling_request, cp_data->cp);
		#endif
		if(thread_err != EOK){
			CP_PRINT_ERROR("pthread_create FAILED with %d\n", thread_err);
		}
	}

	/*handle read request made to the configuration file*/
	ret = libcp_handle_req(cp_data->cp);
	if(ret != 0){
		CP_PRINT_ERROR("libcp_handle_req FAILED\n");
	}

	if(EOK == thread_err){
		thread_err = pthread_join(cp_data->thread, NULL);
		CP_PRINT_INFO("pthread_joined returned with %d\n", thread_err);
	}

	/*remove the configuration file node*/
	ret = libcp_remove_node(cp_data->cp);

	if(-1 == ret){
		CP_PRINT_ERROR("libcp_remove_node FAILED\n");
	}

destroy:
	/*free config provider resource manager data*/
	libcp_destroy(cp_data->cp);

exit:
	if(cp_data){
		free(cp_data->file_data);
		free(cp_data);
	}

	if(ret){
		return EXIT_FAILURE;
	}else{
		return EXIT_SUCCESS;
	}
}
