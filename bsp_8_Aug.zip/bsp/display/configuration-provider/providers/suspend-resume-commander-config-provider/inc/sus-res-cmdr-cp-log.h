/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libcp_log.h
 *  @brief contains macros defined to log into slog or stderr
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 */

#ifndef  SUS_RES_CMD_API_LOG_H
#define  SUS_RES_CMD_API_LOG_H

#ifdef __cplusplus
extern "C" {
#endif
#ifndef UNIT_TEST
#include <sys/slog2.h>
#else
#include "slog2_header.h"
#include "ipc_mock.h"
#include "ipc_header.h"
#endif
#include "fidm-parameter-api.h"
#include "libconfig_provider_api.h"

extern char *__progname;
#ifdef UNIT_TEST
static slog2_buffer_t buffer_handle;
static int g_use_slog2;
#else
slog2_buffer_t buffer_handle;
int g_use_slog2;
#endif
/*
 * internal log level for the configuration provider
 * LOG_ERROR(0) equivalent to SLOG2_ERROR
 * LOG_INFO(1) equivalent to SLOG2_INFO
 * LOG_DEBUG(2) equivalent to SLOG2_DEBUG1
 **/
typedef struct sus_res_cmdr_cp_data{
	cphandle_t                    cp;
	fidmParaApiHdl                pp_hdl;
	char                          config_source_path[PATH_MAX];
	void*                         file_data;
	int                           file_size;
	pthread_t                     thread;
}sus_res_cmdr_cp_data_t;
typedef enum{
	LEVEL_LOWER_LIMIT=-1,
	LOG_ERROR,
	LOG_INFO,
	LOG_DEBUG,
	LEVEL_UPPER_LIMIT
}log_level_t;

#ifndef UNIT_TEST
log_level_t g_log_level;
#else
static log_level_t g_log_level;
#endif

#ifndef UNIT_TEST
static int slogger2_init(void);
#else
int main8(int argc, char **argv);
void signal_handler8(int signo);
int get_configuration_file_data8(sus_res_cmdr_cp_data_t* cp_data);
void display_help8(const char* self);
void* stop_handling_request8(void *arg);
void signal_handler8(int signo);
int slogger2_init8(void);
void set_slog_level8(void);
#endif

#define CP_PRINT_INFO(_str_, ...) \
	do { \
		if(g_log_level < LOG_INFO){\
			continue;\
		}\
		if (g_use_slog2) { \
			slog2f(buffer_handle, 0, SLOG2_INFO, \
					"%s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "sus-res-cmdr-cp: %s:%d: "\
					,_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)

#define CP_PRINT_ERROR(_str_, ...) \
	do { \
		if (g_use_slog2) { \
			slog2f(buffer_handle, 0, SLOG2_ERROR, \
					" %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "sus-res-cmdr-cp: %s:%d: "\
					,_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)


#define CP_PRINT_DEBUG(_str_, ...) \
	do { \
		if(g_log_level < LOG_DEBUG){\
			continue;\
		}\
		if (g_use_slog2) { \
			slog2f(buffer_handle, 0,  SLOG2_DEBUG1, \
					" %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "sus-res-cmdr-cp: %s:%d: "\
					,_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)


#ifdef __cplusplus
}
#endif

#endif
