/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libcp-resmgr.h
 *  @brief overrides default IO attribute structure and includes resource
 *         manager and dispatch library header files
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 */

#ifndef  LIBCP_RESMGR_H
#define  LIBCP_RESMGR_H

#ifdef __cplusplus
extern "C" {
#endif

struct config_provider;
/*overide default IO attribute structure*/
#define IOFUNC_ATTR_T struct config_provider
#ifndef UNIT_TEST
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#endif
#ifdef __cplusplus
}
#endif

#endif
