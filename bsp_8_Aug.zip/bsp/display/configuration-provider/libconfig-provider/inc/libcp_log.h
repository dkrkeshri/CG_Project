/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libcp_log.h
 *  @brief contains macros defined to log into slog or stderr
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 */

#ifndef  LIBCP_LOG_H
#define  LIBCP_LOG_H
#ifdef __cplusplus
extern "C" {
#endif
#ifndef UNIT_TEST
#include <sys/slogcodes.h>
#else
#include "ipc_header.h"
#endif
/**
 * By default slog is used define USE_SLOG_DEBUG as 0
 * to output logs into stderr
 */
#define USE_SLOG_DEBUG 1

/**
 * Following macro is used to create an opcode for the slogger.
 * This should be already defined in slogger_opcode.h found in
 * <GM VCU ROOT>/vcu/qnx/bosch/common/headers
 *
 */
#ifdef UNIT_TEST
int io_read(resmgr_context_t *ctp, io_read_t *msg, RESMGR_OCB_T *ocb);
#endif
#ifndef _SLOGC_LIB_CONFIG_PROVIDER
#define _SLOGC_LIB_CONFIG_PROVIDER          _SLOGC_PRIVATE_START + 4000
#endif

#define LIBCP_PRINT_INFO(_str_, ...) \
	do { \
		if (USE_SLOG_DEBUG) { \
			slogf(_SLOG_SETCODE(_SLOGC_LIB_CONFIG_PROVIDER,0), _SLOG_INFO, \
					"libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "libcp: %s:%d: ",_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)

#define LIBCP_PRINT_ERROR(_str_, ...) \
	do { \
		if (USE_SLOG_DEBUG) { \
			slogf(_SLOG_SETCODE(_SLOGC_LIB_CONFIG_PROVIDER,0), _SLOG_ERROR, \
					"libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "libcp: %s:%d: ",_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)


#define LIBCP_PRINT_DEBUG(_str_, ...) \
	do { \
		if (USE_SLOG_DEBUG) { \
			slogf(_SLOG_SETCODE(_SLOGC_LIB_CONFIG_PROVIDER,0), _SLOG_DEBUG1, \
					"libcp: %s:%d: ",_str_, __func__, __LINE__, ##__VA_ARGS__); \
		} else { \
			fprintf(stderr, "libcp %s:%d: ",_str_ , __func__, __LINE__, ##__VA_ARGS__); \
		} \
	} while(0)


#ifdef __cplusplus
}
#endif

#endif
