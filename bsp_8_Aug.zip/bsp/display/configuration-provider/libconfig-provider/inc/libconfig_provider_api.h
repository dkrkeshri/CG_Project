/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libconfig-provider.h
 *  @brief Dynamic library to create resource manager for configuration provider
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 * */

#ifndef  LIBCONFIG_PROVIDER_H
#define LIBCONFIG_PROVIDER_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * structure to hold config provider resource manager data
 */
struct config_provider;
/*
 * opaque handle to be returned by libconfig_provider_create()
 */
typedef struct config_provider* cphandle_t;

/**
 * APIs to be used to call config provider library
 */

/**
 * @brief Creates and opens an instance of config provider library
 *
 * @param[in] pathname of configuration file to be created
 *
 * @return A handle to the config provider library on Success. NULL in case of
 *          failure
 */
cphandle_t libcp_create(const char* nodename);

/**
 * @brief sets data which will be the content of the configuration file created
 *
 * @param[in] cp handle to an open instance of config provider library
 * @param[in] data pointer to data that will appear as configuration file content
 * @param[in] data_size size of data
 * @return EOK on success and a negative number in case of failure
 */
int libcp_set_data(cphandle_t cp, const char* data, size_t data_size);

/**
 * @brief create the configuration file at given path
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and a negative number in case of failure
 */
int libcp_create_node(cphandle_t cp);

/**
 * @brief handles request(messages) made to the pathname
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and a negative number in case of failure
 */
int libcp_handle_req(cphandle_t cp);

/**
 * @brief remove the configuration file at given path
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and a negative number in case of failure
 */
int libcp_remove_node(cphandle_t cp);

/**
 * @brief frees an open instance of config provider library
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and a negative number in case of failure
 */
int libcp_destroy(cphandle_t cp);

/**
* @brief stops message handling by the resource manager.
*        Limitation!!! Intended to be used in a signal handler.
*        Can be used by the client only when it creates
*        a global handle to libconfig_provider
*
* @param[in] cp handle to an open instance of config provider library
*/
 void libcp_stop_request(cphandle_t cp);


#ifdef __cplusplus
}
#endif
#endif
