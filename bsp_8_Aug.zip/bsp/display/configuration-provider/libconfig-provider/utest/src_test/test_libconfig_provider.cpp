#include <iostream>
#include <gmock/gmock.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include "libconfig_provider_api.h"
#include "libcp_resmgr.h"
#include "libcp_log.h"
#include "ipc_header.h"

using ::testing::_;
using namespace std;
using namespace testing;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;
cphandle_t cp;

TEST(libconfig_provider_api, libcp_create_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	libcp_create(a);
	EXPECT_EQ(0,0);
	free(a);
}

TEST(libconfig_provider_api, libcp_set_data_pass){
	cphandle_t cp;
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	size_t data_size;
	EXPECT_NE(0,libcp_set_data(NULL,a,32));
	free(a);
}

TEST(libconfig_provider_api,libcp_create_node_pass){
	EXPECT_NE(0,libcp_create_node(cp));
}

TEST(libconfig_provider_api, libcp_handle_req_pass){
	EXPECT_NE(0,libcp_handle_req(cp));
}

TEST(libconfig_provider_api, libcp_remove_node_pass){
	EXPECT_NE(0, libcp_remove_node(cp));
}

TEST(libconfig_provider_api, libcp_destroy_pass){
	EXPECT_NE(0, libcp_destroy(cp));
}

TEST(libconfig_provider_api, libcp_stop_request_pass){
	libcp_stop_request(cp);
	EXPECT_EQ(0,0);
}


TEST(libconfig_provider_api, io_read_pass){
	resmgr_context_t ctp ;
	io_read_t msg;
	RESMGR_OCB_T ocb;
	//libcp_stop_request(cp);
	EXPECT_NE(0,io_read(&ctp,&msg,&ocb));
}