#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "libconfig_provider_api.h"

#define DYNAMIC_CONFIG_PATH "/dev/test.conf"
char data[]="config provider works!\n";

cphandle_t cp;

void signal_handler(int dummy)
{
	printf("signal_handler called\n");
	if(cp){
		libcp_stop_request(cp);
	}
}
int main()
{
	int ret = 0;
	printf("MAIN\n");

	signal(SIGINT, signal_handler);

	/*create config provider*/
	cp = libcp_create(DYNAMIC_CONFIG_PATH);
	if(NULL == cp){
		printf("libcp_create: failed\n");
		return EXIT_FAILURE;
	}
	else{
		printf("libcp_create: passed\n");
	}

	/*set data to fill up configuration file*/
	ret = libcp_set_data(cp, data, sizeof(data));
	if(ret != 0){
		printf("set data failed");
		goto destroy;
	}

	/*register configuration file path in pathname space*/
	ret = libcp_create_node(cp);
	if(ret != 0){
		printf("create node failed");
		goto destroy;
	}

	/*handle read request made to the configuration file*/
	ret = libcp_handle_req(cp);
	if(ret != 0){
		printf("handle_req  returned");
	}
	/*remove path from pathname space, cleans resourcemanager resources*/
	ret = libcp_remove_node(cp);

	if(ret){
		printf("create remove node failed");
	}
destroy:
	/*frees config provider data*/
	libcp_destroy(cp);
	if(ret){
		return EXIT_FAILURE;
	}
	else{
		return 0;
	}
}
