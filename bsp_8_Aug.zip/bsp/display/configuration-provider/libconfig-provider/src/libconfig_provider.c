/**
 *  @swcomponent Config provider Library
 *  @{
 *  @file libconfig_provider.c
 *  @brief Defines API for config provider library
 *  @copyright (C) 2020 Robert Bosch GmbH.
 *                 The reproduction, distribution and utilization of this file as
 *                 well as the communication of its contents to others without express
 *                 authorization is prohibited. Offenders will be held liable for the
 *                 payment of damages. All rights reserved in the event of the grant
 *                 of a patent, utility model or design.
 *  @}
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#ifdef UNIT_TEST
#include "slog2_header.h"
#include "ipc_mock.h"
#define static /**/
#endif
#include "libconfig_provider_api.h"
#include "libcp_resmgr.h"
#include "libcp_log.h"
/**
 * structure containing all config provider data
 */

typedef struct config_provider{
	iofunc_attr_t             io_attr;         /*!< The first member must be the default io attribute */
	dispatch_t                *dp;
	dispatch_context_t        *ctp;
	int                       resmgr_id;
	resmgr_attr_t             resmgr_attr;
	resmgr_connect_funcs_t    connect_funcs;
	resmgr_io_funcs_t         io_funcs;
	char                      path[PATH_MAX];  /*!< stores the path to create resource manager node */
	char*                     pdata;           /*!< buffer to store data to fill resource manager node*/
	size_t                    data_size;       /*!< size pdata */
	int                       quit;            /*!< flag to stop handling messages. modified by libcp_stop_request*/
}config_provider_t;


/**
 *  @brief  io_read function to override default POSIX function
 *   	    This function is responsible to send data to client
 *   	    when the client tries to read data from the dynamic
 *   	    configuration file.
 *
 *  @param[in]  ctp Pointer to resource manager context
 *  @param[in]  msg Pointer to message received from client
 *  @param[in]  ocb Pointer to an Open Context Block
 *  @return returns an ERROR or number of parts of ctp->iov structure
 *          to return to the client  that is _RESMGR_NPARTS()
 */

static int io_read(resmgr_context_t *ctp, io_read_t *msg, RESMGR_OCB_T *ocb)
{
	int               ret;
	int               nbytes;
	int               nleft;
	int               nparts;
	char              *buffer;
	config_provider_t *cp;
	cp = (config_provider_t*)ocb->attr;

	LIBCP_PRINT_DEBUG("Entry\n");

	/*check if client has permission to read*/
	if((ret = iofunc_read_verify(ctp, msg, ocb, NULL)) != EOK)
	{
		return ret;
	}

	if(NULL == cp->pdata)
	{
		LIBCP_PRINT_INFO("No data available, ctp->id: %d\n",ctp->id);
		return (_RESMGR_NPARTS(0));
	}
	else
	{
		buffer = cp->pdata;
	}

	if((msg->i.xtype & _IO_XTYPE_MASK) != _IO_XTYPE_NONE)
	{
		return ENOSYS;
	}
	nleft = cp->io_attr.nbytes - ocb->offset;
	nbytes = min(msg->i.nbytes, nleft);

	LIBCP_PRINT_DEBUG("id: %d nbytes: %d\n", ctp->id, nbytes);

	if(nbytes > 0)
	{
		SETIOV(ctp->iov, buffer + ocb->offset, nbytes);
		_IO_SET_READ_NBYTES(ctp, nbytes);
		ocb->offset += nbytes;
		nparts = 1;
	}
	else
	{
		_IO_SET_READ_NBYTES(ctp,0);
		nparts = 0;
	}

	if(msg->i.nbytes > 0)
	{
		cp->io_attr.flags |= IOFUNC_ATTR_ATIME |
			IOFUNC_ATTR_DIRTY_TIME;
	}

	return (_RESMGR_NPARTS(nparts));
}


/**
 * @brief creates and opens an instance of config provider library
 *
 * @param[in] pathname of configuration file to be created
 *
 * @return A handle to the config provider library on Success. NULL in case of
 *         failure
 */
cphandle_t libcp_create(const char* nodename)
{
	config_provider_t* cp;

	cp = (config_provider_t*)calloc(1,sizeof(config_provider_t));
	if(NULL == cp){
		LIBCP_PRINT_ERROR("could not allocate memory for handle: %s\n"
					,strerror(errno));
		goto fail;
	}

	strncpy(cp->path, nodename, PATH_MAX);
	/*make sure path is null terminated*/
	cp->path[PATH_MAX-1] = '\0';

	LIBCP_PRINT_DEBUG("path %s\n",cp->path);

	return cp;
fail:
	return NULL;
}

/**
 * @brief sets data which will be the content of the configuration file created
 *
 * @param[in] cp handle to an open instance of config provider library
 * @param[in] data pointer to data that will appear as configuration file content
 * @param[in] data_size size of data
 * @return 0 on success and -1 in case of failure
 */
int libcp_set_data(cphandle_t cp, const char* data, size_t data_size)
{
#ifdef DEBUG
	char *filedata
	filedata = calloc(1, data_size + 1);
#endif
	if(NULL == cp){
		LIBCP_PRINT_ERROR("Bad handle\n");
		goto fail;
	}
	if(NULL == data){
		LIBCP_PRINT_ERROR("Null pointer passed\n");
		goto fail;
	}
	cp->pdata = (char*)calloc(1,data_size);
	cp->data_size = data_size;

	if(NULL == cp->pdata){
		LIBCP_PRINT_ERROR("Could not allocate memory: %s\n",
				strerror(errno));
		goto fail;
	}
	memcpy(cp->pdata, data, data_size);

#ifdef DEBUG
	memcpy(filedata, data, data_size);
	/*ensure NULL termination*/
	filedata[data_size] = '\0'
	LIBCP_PRINT_DEBUG("%s\n", filedata);
	free(filedata);
#endif

	return 0;
fail:
	return -1;
}


/**
 * @brief create the configuration file at given path
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and -1 in case of failure. The function cleans up
 *         resources if there is a failure
 */
 int libcp_create_node(cphandle_t cp)
{
	int ret;
	/*local variable to store global errno*/
	LIBCP_PRINT_INFO("ENTRY\n");
	if(NULL == cp)
	{
		LIBCP_PRINT_ERROR("Bad handle\n");
		goto fail;
	}

	/*create dispatch structure*/
	cp->dp = dispatch_create();

	if(NULL == cp->dp){
		LIBCP_PRINT_ERROR("Unable to dispatch_create: %s\n",
					strerror(errno));
		goto fail;
	}

	/*initialize data structures*/
	memset(&cp->resmgr_attr, 0, sizeof(resmgr_attr_t));
	cp->resmgr_attr.nparts_max = 1;
	cp->resmgr_attr.msg_max_size = 2048;

	/*bind default functions into the function table*/
	iofunc_func_init(_RESMGR_CONNECT_NFUNCS, &cp->connect_funcs,
			_RESMGR_IO_NFUNCS, &cp->io_funcs);
	iofunc_attr_init(&cp->io_attr, S_IRUSR | S_IRGRP |S_IRGRP, NULL, NULL);

	/*set file size in attributes*/
	cp->io_attr.nbytes = cp->data_size;

	/*overwrite default functions*/
	cp->io_funcs.read = io_read;

	/*register pathname in pathname space*/
	cp->resmgr_id = resmgr_attach(cp->dp, &cp->resmgr_attr,cp->path,
			_FTYPE_ANY, 0, &cp->connect_funcs, &cp->io_funcs,
			(RESMGR_HANDLE_T*)cp);

	if(-1 == cp->resmgr_id){
		LIBCP_PRINT_ERROR("resmgr_attach failed: %s\n",
					strerror(errno));
		goto fail;
	}
	cp->ctp = dispatch_context_alloc(cp->dp);

	if(NULL == cp->ctp){
		LIBCP_PRINT_ERROR("unable to allocate dp context: %s\n",
				strerror(errno));
		goto fail;
	}

	return 0;

fail:
	ret = libcp_remove_node(cp);
	if(-1 == ret ){
		LIBCP_PRINT_ERROR("libcp_remove_node failed\n");
	}
	return -1;
}

/**
 * @brief handles request(messages) made to the pathname. libcp_remove_node
 *        should be called if this function returns
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 if it quit was requested or -1 in case of failure
 */
int libcp_handle_req(cphandle_t cp)
{
	if(NULL == cp)
	{
		LIBCP_PRINT_ERROR("Bad handle\n");
		return -1;
	}
	while(0 == cp->quit){
		cp->ctp = dispatch_block(cp->ctp);
		if(NULL == cp->ctp)
		{
			LIBCP_PRINT_ERROR("dispatch block failed: %s\n",
					strerror(errno));
			return -1;
		}
		dispatch_handler(cp->ctp);
	}
	return -1;
}

/**
 * @brief remove pathname from pathspace and cleans resource manager resources
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and -1 in case of failure
 */
int libcp_remove_node(cphandle_t cp){
	int ret = 0;

	if(NULL == cp){
		LIBCP_PRINT_ERROR("Bad handle\n");
		return -1;
	}
	if(-1 != cp->resmgr_id){
		ret = resmgr_detach(cp->dp, cp->resmgr_id, 0);
	}

	if(-1 == ret){
		LIBCP_PRINT_ERROR("Failed to detach pathname: %s\n",
				strerror(errno));
	}else{
		cp->resmgr_id = -1;
	}


	if(cp->ctp){
		dispatch_context_free(cp->ctp);
		cp->ctp = NULL;
	}

	if(cp->dp){
		ret = dispatch_destroy(cp->dp);
		if(-1 == ret){
			LIBCP_PRINT_ERROR("Failed to dispatch_destroy: %s\n",
					strerror(errno));
		}
		else{
			cp->dp = NULL;
		}
	}

	return 0;
}

/**
 * @brief frees an open instance of config provider library
 *
 * @param[in] cp handle to an open instance of config provider library
 * @return 0 on success and -1 in case of failure
 */
int libcp_destroy(cphandle_t cp){
	if(cp){
		if(cp->pdata){
			free(cp->pdata);
		}
		free(cp);
		return 0;
	}
	else{
		LIBCP_PRINT_ERROR("Bad handle\n");
		return -1;
	}
}

/**
 * @brief stops message handling by the resource manager. It can be called
 *        from a thread or a signal handler.
 *        Limitation: Can be used by the client in a signal handler only when
 *        it creates a global handle to libconfig_provider
 *
 * @param[in] cp handle to an open instance of config provider library
 */
void libcp_stop_request(cphandle_t cp)
{
	LIBCP_PRINT_DEBUG("ENTRY\n");
	if(cp){
		cp->quit = 1;
	}
}
