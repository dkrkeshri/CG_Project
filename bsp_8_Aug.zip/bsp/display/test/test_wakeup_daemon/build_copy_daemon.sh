#!/bin/bash

# compile the daemon process and copy it to the target.

DR=`pwd`
DR=`realpath ${DR}`

#build the library
cd ../../api/lib_tdaemon/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of library failed. 1>&2
  exit 1
fi
cd ../../api/lib_tdaemon/
make install
cd ${DR}

# build the daemon
cd ../../wakeup_daemon/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of daemon failed. 1>&2
  exit 1
fi

# copy to the target

scp ../../wakeup_daemon/nto-aarch64-o.le/wakeup_daemon display*json* root@192.168.211.100:/tmp/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(first).' 1>&2
  exit 1
fi
scp ../../../../../qcom/qcom_qnx/apps/qnx_ap/install/aarch64le/lib/liblib_tdaemon.so.1 root@192.168.211.100:/lib64/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(second).' 1>&2
  exit 1
fi

echo -e '\n'
echo on the Target, start with:
echo -e "cd /tmp/;./wakeup_daemon -dc displaywakeup.json.txt"

