#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <getopt.h>

#include "libdisplaywakeup.h"

#define DEVNODE_NAME_STATUS "/dev/wakeup-binder/status"
#define DEVNODE_NAME_CONTROL "/dev/wakeup-binder/control"

static void show_help()
{
	printf("displaywakeup-ctl - Control wake-up signals for displays\n");
	printf("-h  - show this message\n");
	printf("-l  - list chains to control\n");
	printf("-q - query service online / offline status\n");
	printf("-o <online | offline> - move service to online / offline\n");
	printf("\n");
	printf("Chain-specific operations\n");
	printf("-c <chain-name> - Name of the chain\n");
	printf("-s <on/off>     - Set chain wake-up\n");
	printf("-g              - Get chain wake-up status\n");
	printf("Examples:\n");
	printf("  displaywakeup-ctl -c wakeup-chain-0 -s on\n");
	printf("  displaywakeup-ctl -c wakeup-chain-0 -g\n");
	printf("\n");
}

static void example_list_chains()
{
	char *info;
	int handle;
	int ret;

	handle = displaywakeup_status_open(DEVNODE_NAME_STATUS);
	if (handle < 0) {
		printf("Could get access to status devnode\n");
		return;
	}

	ret = displaywakeup_status_get(handle, "list-chains", &info);
	if (ret) {
		printf("Couldn't request list of chains\n");
		return;
	}

	printf("%s\n", info);

	free(info);
}

static void example_set_chain_state(const char *chain, char *state)
{
	int status_handle;
	int ctrl_handle;
	char *online;
	int ret;

	status_handle = displaywakeup_status_open(DEVNODE_NAME_STATUS);
	if (status_handle < 0) {
		printf("Could get access to status devnode\n");
		return;
	}


	ret = displaywakeup_status_get(status_handle, "online", &online);
	if (ret) {
		printf("Couldn't request status of the service\n");
		return;
	}

	if(strncmp(online,"on",2))
	{
		free(online);
		printf("Service is offline. Setting state is impossible. Use  -o online  to change.\n");
		return;
	}
	free(online);

	ctrl_handle = displaywakeup_ctrl_open(DEVNODE_NAME_CONTROL);
	if (ctrl_handle < 0) {
		printf("Could get access to control devnode\n");
		return;
	}

	ret = displaywakeup_ctrl_set(ctrl_handle, chain, state);
	if (ret) {
		printf("Couldn't set chain <%s> state to %s\n", chain, state);
		return;
	}
}

static void example_query_online_mode()
{
	char *online;
	int handle;
	int ret;

	handle = displaywakeup_status_open(DEVNODE_NAME_STATUS);
	if (handle < 0) {
		printf("Could get access to status devnode\n");
		return;
	}


	ret = displaywakeup_status_get(handle, "online", &online);
	if (ret) {
		printf("Couldn't request status of the service\n");
		return;
	}

	printf("%s\n", online);

	free(online);
}

static void example_set_online(char *online)
{
	char *cmd_value;
	int ctrl_handle;
	int ret;

	if (!strcmp(online, "online")) {
		cmd_value = "1";
	} else if (!strcmp(online, "offline")) {
		cmd_value = "0";
	} else {
		printf("Unknown online/offline mode <%s>\n", online);
		return;
	}

	ctrl_handle = displaywakeup_ctrl_open(DEVNODE_NAME_CONTROL);
	if (ctrl_handle < 0) {
		printf("Could get access to control devnode\n");
		return;
	}

	ret = displaywakeup_ctrl_set(ctrl_handle, "online", cmd_value);
	if (ret) {
		printf("Couldn't switch to %s\n", online);
		return;
	}
}

static void example_get_chain_state(const char *chain)
{
	char *status;
	char *online;
	int handle;
	int ret;

	handle = displaywakeup_status_open(DEVNODE_NAME_STATUS);
	if (handle < 0) {
		printf("Could get access to status devnode\n");
		return;
	}

	ret = displaywakeup_status_get(handle, "online", &online);
	if (ret) {
		printf("Couldn't request status of the service\n");
		return;
	}

	if(strncmp(online,"on",2))
	{
		free(online);
		printf("Service is ion offline. Query is impossible. Use  -o online  to change.\n");
		return;
	}

	free(online);

	ret = displaywakeup_status_get(handle, chain, &status);
	if (ret) {
		printf("Couldn't request chain <%s> status\n", chain);
		return;
	}

	printf("%s\n", status);

	free(status);
}

int main (int argc, char *const * argv)
{
	bool do_get_status = false;
	bool do_set_chain = false;
	bool do_set_online = false;
	const char *chain = NULL;
	char *new_online = NULL;
	char *new_state = NULL;
	int opt;

	while (true) {
		opt = getopt(argc, argv, "hlc:s:gqo:");
		if (opt < 0)
			break;
		switch (opt) {
			case 'h':
				show_help();
				return 0;

			case 'l':
				example_list_chains();
				return 0;

			case 'g':
				do_get_status = true;
				break;

			case 's':
				do_set_chain = true;
				new_state = optarg;
				break;

			case 'c':
				chain = optarg;
				break;

			case 'q':
				example_query_online_mode();
				return 0;

			case 'o':
				do_set_online = true;
				new_online = optarg;
				break;

			default:
				break;
		}
	}

	if (1 < do_get_status + do_set_chain + do_set_online) {
		printf("Only one option of -s or -g or -o is allowed\n");
		return 1;
	}

	if (0 == do_get_status + do_set_chain + do_set_online) {
		printf("None of -s or -g or -o is set. Doing nothing.\n");
		return 0;
	}

	if (do_set_online) {
		if (!new_online) {
			printf("Online mode value required\n");
			return 1;
		}
		example_set_online(new_online);
		return 0;
	}

	if (!chain) {
		printf("-c option is mandatory\n");
		return 1;
	}

	if (do_set_chain) {
		if (!new_state) {
			printf("Chain state is mandatory\n");
			return 1;
		}

		example_set_chain_state(chain, new_state);
	}

	if (do_get_status) {
		example_get_chain_state(chain);
	}

	return 0;
}
