#!/bin/bash

# compile the testprogram, copy it to the target and run it.

DR=`pwd`
DR=`realpath ${DR}`

#build the library
cd ../../api/public/fidm_parameter_provider_lib/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of static library failed. 1>&2
  exit 1
fi

#build the cli tool
cd ../../fidm_parameter_provider_cli/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of cli program failed. 1>&2
  exit 1
fi

# copy to the target

scp ../../fidm_parameter_provider_cli/nto-aarch64-o.le/fidm_parameter_provider_cli root@192.168.0.1:/tmp/cli
if [ $? -ne 0 ] ; then
  echo scp to target failed. 1>&2
  exit 1
fi

ssh root@192.168.0.1 'cd /tmp/;echo RUN;./cli -l /data;echo;echo;sleep 0.25'

