#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fidm-parameter-api.h"

#define MAX_DISPLAY_NAME_LEN 192

int main()
{
	char name[MAX_DISPLAY_NAME_LEN];
	unsigned int display_pixel_height;
	unsigned int display_pixel_width;
	char config_path[1024];
	int display_count;
	int cnt;
	fidmParaApiHdl hdl;

	int ret;

	// open the api handle. This will establish the connection (open a filehandle on daemon)
	hdl = fidm_parameter_api_open();
	if(!hdl)
	{
		fprintf(stderr,"Cannot open fidm parameter provider.\n");
		return 1;
	}

	if (fidm_parameter_api_path_exists(hdl, "/display-infrastructure/displays")<1) {
		printf("No displays node given\n");
		fidm_parameter_api_close(hdl);
		return 1;
	}
	
	display_count = fidm_parameter_api_list_length(hdl, "/display-infrastructure/displays");
	for (cnt = 0; cnt < display_count; cnt++) {
		snprintf(config_path, sizeof(config_path), "/display-infrastructure/displays/%u/static-info/common-name", (unsigned int)cnt);
		ret = fidm_parameter_api_string(hdl, config_path, name, sizeof(name));
		if (ret) {
			printf("Name not found for the display %u, skipping entry\n", (unsigned int)cnt);
			continue;
		}
		
		snprintf(config_path, sizeof(config_path), "/display-infrastructure/displays/%u/panel/properties/pixel-width", (unsigned int)cnt);
		ret = fidm_parameter_api_unsigned(hdl, config_path, &display_pixel_width);
		if (ret) {
			printf("Width not found for the display %u, skipping entry\n", (unsigned int)cnt);
			continue;
		}
		
		snprintf(config_path, sizeof(config_path), "/display-infrastructure/displays/%u/panel/properties/pixel-height", (unsigned int)cnt);
		ret = fidm_parameter_api_unsigned(hdl, config_path, &display_pixel_height);
		if (ret) {
			printf("Height not found for the display %u, skipping entry\n", (unsigned int)cnt);
			continue;
		}
		
		printf("Display %u: %s <%ux%u>\n", (unsigned int)cnt, name, display_pixel_width, display_pixel_height);
	}
	fidm_parameter_api_close(hdl);
	return 0;
}
