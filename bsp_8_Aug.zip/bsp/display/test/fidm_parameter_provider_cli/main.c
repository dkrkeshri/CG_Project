#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//##include <unistd.h>
#include "fidm-parameter-api.h"

/**
 * Command-line interface (CLI) tool for fidm-parameter provider.
 *
 * This command-line tool uses the fidm_parameter_provider lib to do queries
 * against the fidm parameter provider. It can be used to query the daemon
 * from scripts for for testing purposes.
 *
 * This code in this single source file is mostly wrapper stuff and getopt.
 *
 * Achim Dahlhoff CM/ESO
 */

#define MAX_DISPLAY_NAME_LEN 192

#define BUFFER_SIZE 0x00080000

// options for getopt():
static const struct option long_opts[] = {
	{"check-path",1,NULL,'c'},
	{"get-type",1,NULL,'t'},
	{"get-value",1,NULL,'g'},
	{"get-array-length",1,NULL,'n'},
	{"list-dictionary",2,NULL,'l'},
	{"reload",0,NULL,'r'},
	{"help",0,NULL,'h'},
	{NULL,0,NULL,0}
};

int main(int argc,char *const argv[])
{
	const char *errtxt;
	int opt;
	const char *opath; // option path
	char *buffer;
	const char *rd;
	int command;	// command chosen from cmd-line.
	char command_r;	// reload selected
	fidmParaApiHdl hdl;

	int ret;

	errtxt=0;
	hdl = NULL;
	buffer = 0;

	// options
	opterr=0;
//	optind=1;
	command=-1;
	command_r=0;
	opath=NULL;

	while((opt=getopt_long(argc,argv,"c:t:g:n:l:rh",long_opts,NULL))>=0)
	{
		switch(opt)
		{
		case 'c':
		case 't':
		case 'g':
		case 'n':
		case 'l':
			if(command!=-1)
				{errtxt="multiple commands specified. Use only one of possible commands c,t,g,n,l.";goto leave;}
			command=opt;
			opath = optarg;
			break;
		case 'r':
			command_r=1;
			break;
		case 'h':
			printf("Usage:\n");
			printf("fidm_parameter_provider_cli  <options>\n");
			printf("\n");
			printf("valid options:\n");
			printf("-c  --check-path <path>        check if a path exists.\n");
			printf("-t  --get-type <path>          Check type of an item.\n");
			printf("-g  --get-value <path>         get a value (generic, outputs json).\n");
			printf("-n  --get-array-length <path>  Get count of sub-items of list.\n");
			printf("-l  --list-dictionary <path>   list all sub-items of an object.\n");
			printf("-r  --reload                   Trigger a reload of data by daemon.\n");
			printf("-h  --help                     display this help.\n\n");
			goto leave;
		default:
			errtxt = "unknown option switch. use -h for help.";
			goto leave;
		}
	}

	if(optind<argc)
	{
		errtxt="Use only options, not positional arguments. Use -h to shop options.";
		goto leave;
	}

	// verify that a command is selected.
	if( command==-1 && command_r==0 )
	{
		errtxt="no command selected. Use -h to show options.";
		goto leave;
	}
	if(opath==NULL)
		opath="";
	if( command!='l' && command!=-1 && (opath[0]==0) )
	{
		errtxt="Need path for command.";
		goto leave;
	}

	buffer = (char*)malloc(BUFFER_SIZE);
	if(!buffer)
	{
		errtxt="";
	}


	// open the api handle. This will establish the connection (open a filehandle on daemon)
	hdl = fidm_parameter_api_open();
	if(!hdl)
	{
		fprintf(stderr,"Cannot open fidm parameter provider.\n");
		return 1;
	}

	if(command_r)
	{
		// request to trigger a reload
		ret = fidm_parameter_api_trigger_reload_data(hdl);
		if(ret<0)
		{
			snprintf(buffer,BUFFER_SIZE,"Reload-data command failed: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		printf("reload command sent.\n");
	}

	switch(command)
	{
	case 'c':	// --check-path
		ret = fidm_parameter_api_path_exists(hdl,opath);
		if(ret<0)
		{
			snprintf(buffer,BUFFER_SIZE,"Error checking path: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		printf((ret?"OK\n":"does not exist\n"));
		break;
	case 't':	// --get-type
		ret = fidm_parameter_api_get_type(hdl,opath);
		if(ret<0)
		{
			snprintf(buffer,BUFFER_SIZE,"Error checking type of item: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		switch(ret)
		{
		case FIDM_PARAMETER_API_TYPE_STRING : rd="string";break;
		case FIDM_PARAMETER_API_TYPE_NUMBER : rd="number";break;
		case FIDM_PARAMETER_API_TYPE_ARRAY  : rd="list";break;
		case FIDM_PARAMETER_API_TYPE_OBJECT : rd="object";break;
		case FIDM_PARAMETER_API_TYPE_BOOLEAN: rd="bool";break;
		default: rd="<bad type>";return -1;	// lib incompatible
		}
		printf("%s\n",rd);
		break;
	case 'g':	// --get-value
		ret = fidm_parameter_api_get_any(hdl,opath,buffer,BUFFER_SIZE);
		if(ret)
		{
			snprintf(buffer,BUFFER_SIZE,"Error getting item: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		buffer[BUFFER_SIZE-1]=0;
		printf("%s\n",buffer);
		break;
	case 'n':	// --get-array-length
		ret = fidm_parameter_api_list_length(hdl,opath);
		if(ret<0)
		{
			snprintf(buffer,BUFFER_SIZE,"Error getting list-length: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		printf("%d\n",ret);
		break;
	case 'l':	// --list-dictionary
		ret = fidm_parameter_api_objectkeys(hdl,opath,buffer,BUFFER_SIZE);
		if(ret<0)
		{
			snprintf(buffer,BUFFER_SIZE,"Error getting object keys: %d",ret);
			errtxt=buffer;
			goto leave;
		}
		rd = buffer;
		buffer[BUFFER_SIZE-1]=0;
		while(ret>0)
		{
			printf("%s\n",rd);
			// skip this key
			while( *rd && rd<buffer+BUFFER_SIZE-1 )rd++;
			rd++;	// and skip the nullbyte.
			ret--;
		}
		break;
	}

	if (fidm_parameter_api_path_exists(hdl, "/display-infrastructure/displays")<1) {
		printf("No displays node given\n");
		fidm_parameter_api_close(hdl);
		return 1;
	}
	
leave:
	if(errtxt)
		fprintf(stderr,"Error: %s\n",errtxt);

	if(hdl)
		fidm_parameter_api_close(hdl);
	hdl = NULL;

	if(buffer)
		free(buffer);
	buffer=NULL;

	return (errtxt?1:0);
}
