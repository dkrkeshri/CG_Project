#!/bin/sh

# This is the script copied onto target by the parent script 'run_target_test.sh'.


RNODE=/dev/testdaemon/node1
CLIPATH=/tmp/
CLIPRG=testprog

GOODCOUNT=0
FAILCOUNT=0

fn_testok()
{
  if [ $1 -ne 0 ] ; then
    echo failed. 1>&2
    FAILCOUNT=$(( ${FAILCOUNT} + 1 ))
  else
    GOODCOUNT=$(( ${GOODCOUNT} + 1 ))
  fi
}

# This script shall run on the target.

# Test if on target.
use slay > /dev/null 2>&1
if [ $? -ne 0 ] ; then
  echo This script is for use on the target. It is copied and started by run_target_test.sh 1>&2
  exit 1
fi

# test if res-mgr node exists. If not, the daemon is not up or misconfigured.
if [[ -c "$RNODE" ]];then
  echo is there > /dev/null
else
  echo res-mgr node $RNODE not available. 1>&2
  exit 1
fi

cd -- "$CLIPATH"

ls -l "$CLIPRG"
if [[ -f "$CLIPRG" ]];then
  echo is there > /dev/null
else
  echo client testprogram $CLIPRG not available. 1>&2
  exit 1
fi

echo - test small resmgr command -
./testprog -w 34 42
fn_testok $?

echo - test small resmgr command with response -
./testprog -r 34
fn_testok $?

./testprog -m 'ab' 'ab'
fn_testok $?

./testprog -m 'a*' 'abcd'
fn_testok $?

./testprog -m 'a*d' 'abcde'
fn_testok $?

R=`./testprog -c ./rnddata.bin`          
if [ $? -eq 0 ] ; then
  R=`echo $R | awk '{split($0,a);$0=a[3];gsub(/^0x/,"");print $0}'`
  if [ $? -eq 0 ] ; then
    print "CRC calc'd by test-daemon: ${R}"
  	# get reference value for crc, convert both to lower case
    CRCREF=`cat ./rnddata_crc.txt`
    R=`echo $R | tr '[:upper:]' '[:lower:]'`
    CRCREF=`echo $CRCREF | tr '[:upper:]' '[:lower:]'`
    # compare
    if [[ $R == $CRCREF ]] ; then
      fn_testok 0
    else
      print "CRC result mismatch. Got x${R}x, expected x${CRCREF}x"
      fn_testok 1
    fi
  else
    fn_testok 1
  fi
else
  fn_testok 1
fi


# delay shorter than 1 sec tests synchronous blocked long-io
./testprog -d 0.5
fn_testok $?

# delay longer than 1 sec tests non-blocked long-io with progress-notifications
echo - test blocked IO with delay function in testdaemon -
./testprog -d 1.5
fn_testok $?


echo test-calls: ${GOODCOUNT} good, ${FAILCOUNT} bad.

if [ $FAILCOUNT -ne 0 ] ; then
  echo test tests failed. 1>&2
  exit 1
fi
exit 0
