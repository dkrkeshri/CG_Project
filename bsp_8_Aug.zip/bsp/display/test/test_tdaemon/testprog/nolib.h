#ifndef __LIBDISPLAYWAKEUP_GPIO_H_
#define __LIBDISPLAYWAKEUP_GPIO_H_


#define TEST_TLIB_DAEMON_DEFAULT_RESMGR_PATH "/dev/test_tldm/control"


/* This API gives a way to control Display Wake Up GPIOs.
 * The API consists of two parts:
 *   - Control interface
 *     Provides methods to toogle the displays on or off
 *     In the production environment demands administrative
 *     permissions for the caller
 *   - Status request interface
 *     Allows to read current wake-up status
 */

/**
 * @brief A function to open control interface of the library
 *
 * @param devnode Device node path of the daemon providing the service.
 * @return A handle that could be passed to other testtlib_ctrl_*
 *         functions. Negative value indicates a failure.
 */
int testtlib_open(const char *devnode);

/**
 * @brief A function to close the control interface
 *
 * @param handle A handle to the control interface to close
 */
void testtlib_close(int handle);

int testtlib_read(int handle,unsigned int adr,unsigned short *out_data);
int testtlib_write(int handle,unsigned int adr,unsigned short data);

/**
 * @brief A function to move the wake up daemon to the offline state. Once
 *        called the daemon shall bring hardware to a safe state and close any
 *        outcomming connections.
 *
 * @param handle A handle to the control interface of the daemon
 * @return The result of the operation. Zero indicates success, non-zero values
 *         indicate failures.
 */
int testtlib_ctrl_set_offline(int handle);


/**
 * @brief A function to manipulate controls in the daemon. Following controls
 *        shall be available:
 *          - online - the same as testtlib_gpio_ctrl_set_online/offline
 *            acceptable values: "0" for "offline mode", "1" for "inline mode"
 *            as strings.
 *          - wakeup-chain-0 - Controls the "0" display chain
 *            acceptable values: "0" for "turn off", "1" for "turn on"
 *            as strings.
 *          - wakeup-chain-1 - controls the "1" display chain
 *            acceptable values: "0" for "turn off", "1" for "turn on"
 *            as strings.
 *
 * @param handle A handle to the control interface of the daemon
 * @param control_name Name of the control as described above
 * @param control_data Value for the control as described above
 * @return The result of the operation. Zero indicates success, non-zero values
 *         indicate failures.
 */
int testtlib_set(int handle, const char *control_name,
                           char *control_data);


/// a function to test the pattern-matching for notifications.
int testtlib_testpat(int handle, const char *pattern, const char *item);

/**
 * @brief A function to retrive status/value of the controls and parameters in
 *        the daemon. Following nodes to retrieve status shall be available:
 *          - online - the value of the online control
 *          - wakeup-chain-0, wakeup-chain-1 - the values of those controls
 *          - list-chains - shall return a JSON with list of controllable chains
 *
 * @param handle A handle to the status interface of the daemon
 * @param control_name The name of the control or parameter to get status for
 * @param status Value of the control or of the parameter. The caller shall
 *               free the value after usage.
 * @return The result of the operation. Zero indicates success, non-zero values
 *         indicate failures.
 */
int testtlib_get(int handle, const char *control_name,
                             char **status);


int testtlib_crc(
			int handle ,
			unsigned int size ,
			unsigned int *out_crc ,
			int (*getmoredata)(void *ctx,char *buffer,int buffersize) ,
			void (*progress)(void *ctx,float progress_0_1) ,
			void *ctx );

int testlib_delay(int handle,float deltime);

int testlib_notifier_register_cb(int handle,const char *maskmatch,void (*cb)(const char*,int,void*),void *ctx);
int testlib_notifier_unregister(int handle);


#endif
