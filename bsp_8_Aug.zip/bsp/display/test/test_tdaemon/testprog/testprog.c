#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <getopt.h>
#include "nolib.h"


#define DEVNODE_NAME "/dev/testdaemon/node1"

static void show_help()
{
	printf("testprog - Program to run the test daemon for lib_tdaemon\n");
	printf("-h             - show this message\n");
	printf("-r <adr>       - read value from storage (test simple IO).\n");
	printf("-w <adr> <val> - show this message (test persistence).\n");
	printf("-c <crc_file>  - calc a CRC over a file (test binary-interface)\n");
	printf("-d <seconds>   - delay some time. (Test blocking IO).\n");
	printf("-m <matchpat> <matchitem>  - test the mask stringmatching.\n");
	printf("\n");
}

int nodehandle=-1;

static int try_run_crc_on_daemon(const char *crc_filename);
static int f_getmoredata(void *ctx,char *buffer,int buffersize);
static void f_progress(void *ctx,float progress_0_1);

int main(int argc, char *const * argv)
{
	int rd_adr = -1;
	int wr_adr = -1;
	unsigned short wr_val = 0;
	long int tmpval;
	char *ep;
	const char *crc_filename = NULL;
	const char *pat_match = NULL;
	const char *pat_item = NULL;
	float delay_time = -1.0f;
	int opt;
	int ret;
	int retval=0;

	while( (opt=getopt(argc,argv,"hr:w:d:c:m:")) >= 0 )
	{
		switch(opt)
		{
		case 'h':
			show_help();
			return 0;
		case 'r':
			errno=0;ep=0;
			tmpval = (int)strtol(optarg,&ep,0);
			if( errno || *ep || tmpval<0 || tmpval>=0x1000000 )
				{fprintf(stderr,"invalid read address.\n");return 1;}
			rd_adr = (int)tmpval;
			break;
		case 'w':
			errno=0;ep=0;
			tmpval = (int)strtol(optarg,&ep,0);
			if( errno || *ep || tmpval<0 || tmpval>=0x1000000 )
				{fprintf(stderr,"invalid store address.\n");return 1;}
			wr_adr = (int)tmpval;
			if(optind>=argc)
			{
				fprintf(stderr,"option -w needs two arguments: store-address and a value.\n");
				return 1;
			}
			tmpval = (int)strtol(argv[optind++],&ep,0);
			if( errno || *ep || tmpval<0 || tmpval>=0x10000 )
				{fprintf(stderr,"invalid store value.\n");return 1;}
			wr_val = (unsigned short)tmpval;
			break;
		case 'c':
			crc_filename = optarg;
			break;
		case 'd':
			errno=0;ep=0;
			double dbtim;
			dbtim = strtod(optarg,&ep);
			if( errno || *ep || !(dbtim>0.0) || !(dbtim<=600.0) )
				{fprintf(stderr,"invalid value for delay time '%s'.\n",optarg);return 1;}
			delay_time = (float)dbtim;
			break;
		case 'm':
			pat_match = optarg;
			if(optind>=argc)
			{
				fprintf(stderr,"option -m needs two arguments: pattern and itemname.\n");
				return 1;
			}
			pat_item = argv[optind++];
			break;
		default:
			fprintf(stderr,"unknown options, exiting.\n");
			return 1;
		}
	}

	if( wr_adr<0 && rd_adr<0 && !crc_filename && delay_time<=0.0 && !pat_match )
	{
		printf("None of -r, -w, -c or -d is set. Doing nothing.\n");
		return 0;
	}

	// open handle
	nodehandle = testtlib_open(DEVNODE_NAME);
	if(nodehandle<0)
	{
		fprintf(stderr,"error opening '%s'.\n",DEVNODE_NAME);
		return 1;
	}

	// pattern match test
	if(pat_match)
	{
		printf("match '%s' against '%s':\n",pat_match,pat_item);

//		fprintf(stderr,"not implemented. needs linking against lib_tdaemon.\n");
//		return 1;

		ret = testtlib_testpat(nodehandle,pat_match,pat_item);
		if(ret<0)
		{
			fprintf(stderr,"testpat command failed.\n");
			retval=1;
		}else{
			printf("result: %s\n",ret?"no match":"match");
		}

/*
		int res = txt_resmgr_test__notify_q_testpat(pat_match,pat_item);
		if(res<0)
		{
			fprintf(stderr,"test failed with error.\n");
			return 1;
		}
		printf("%s\n",res?"does not match":"matches");
 */
	}

	if(rd_adr>=0)
	{
		unsigned short data=0;
		ret = testtlib_read(nodehandle,rd_adr,&data);
		if(ret!=0)
		{
			fprintf(stderr,"read failed.\n");
			retval=1;
		}else{
			printf("-> data: $%04X\n",(unsigned int)data);
		}
	}

	if(wr_adr>=0)
	{
		ret = testtlib_write(nodehandle,wr_adr,wr_val);
		if(ret!=0)
		{
			fprintf(stderr,"write failed.\n");
			retval=1;
		}
	}

	if(crc_filename)
	{
		ret = try_run_crc_on_daemon(crc_filename);
		if(ret!=0)
		{
			const char *e="calc crc failed";
			switch(ret)
			{
			case ENOENT: e = "file not found"; break;
			case E2BIG: e = "file too large"; break;
			case EIO: e = "IO error reading file"; break;
			}
			fprintf(stderr,"%s.\n",e);
			retval=1;
		}
	}

	if(delay_time>0.0)
	{
		ret = testlib_delay(nodehandle,delay_time);
		if(ret!=0)
		{
			fprintf(stderr,"delay test failed. ret=%d.\n",ret);
			retval=1;
		}
	}

	if(nodehandle>=0)
	{
		testtlib_close(nodehandle);
		nodehandle=-1;
	}

	return retval;
}



static int try_run_crc_on_daemon(const char *crc_filename)
{
	FILE *fh;
	long int siz;
	int ret;
	unsigned int CRC;

	fh = fopen(crc_filename,"rb");
	if(!fh)
		return ENOENT;
	// check filesize
	if(fseek(fh,0,SEEK_END))
		{fclose(fh);return EIO;}
	errno = 0;
	siz = ftell(fh);
	if( errno || fseek(fh,0,SEEK_SET) )
		{fclose(fh);return EIO;}

	if( siz<1 || siz>0xFFFFFFFFl )
		{fclose(fh);return E2BIG;}

	// start crc calc run
	CRC=~0;
	ret = testtlib_crc(nodehandle,(unsigned int)siz,&CRC,f_getmoredata,f_progress,fh);
	fclose(fh);
	if(ret==0)
		printf("CRC = 0x%08X\n",CRC);
	return ret;
}

static int f_getmoredata(void *ctx,char *buffer,int buffersize)
{
	FILE *fh = (FILE*)ctx;
	int ret;

	if( !fh || !buffer || buffersize<1 )
		return EINVAL;

	ret = fread(buffer,1,buffersize,fh);
	if( ret<0 )
		return ret;
	if( ret>buffersize )
		return -EIO;
	return ret;
}

static void f_progress(void *ctx,float progress_0_1)
{
	static unsigned char sprog=255;
	unsigned char prog;

	prog = (unsigned char)(int)(progress_0_1*100.0f+0.5f);
	if(prog<0)prog=0;
	if(prog>100)prog=100;
	if(prog!=sprog)
	{
		printf(" ... %2d %%\n",(unsigned int)prog);
		sprog=prog;
	}
}


