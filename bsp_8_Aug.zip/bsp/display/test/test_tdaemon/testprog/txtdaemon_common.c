#include "txtdaemon_common.h"
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/neutrino.h>
#include <sys/select.h>
#include <unistd.h>
#ifdef TESTHOOKS
#include "testhook.h"	// defines to mock io functions like open().
#endif

//#define DBG_PRINT(...)   printf("DEBUG(Fpara)  " __VA_ARGS__);
#define DBG_PRINT(...)    do{}while(0)

#define NEG(a) ((a) <= 0 ? (a) : -(a))

static int check_typeid(struct TxtDaemonIf *hdl, const char *typeid_string,
                        char bOnStatus);
static int pick_fh(struct TxtDaemonIf *hdl, char bOnStatus);

#define MAX_NOTIFIERS 4
typedef struct TxtDaemonNotif
{
	int chid;
	void (*cb)(const void*,int,void*);
	void *cb_context;
} TxtDaemonNotif;

static TxtDaemonNotif *alloc_notify(struct TxtDaemonIf *hdl);


/**
 * fidm_parameter_api_open() opens and connects the FIDM parameter provider.
 *
 * A filehandle to the daemon's resource-manager node is opened and held open
 * inside the fidmParaApiHdl handle.
 *
 * A command to retrieve the daemon's version is sent to possibly check the
 * version and to verify that the handle is the dameon and works.
 *
 * returns an opaque pointer as a handle.
 */
struct TxtDaemonIf *tdi__open(const char *dev_control_name,
                              const char *dev_status_name,
                              const char *dev_typeid_string,
                              unsigned int replybuffersize)
{
    struct TxtDaemonIf *d;
    int ret;
    int n;

    /* Must have at least one of the two names */
    if ((!dev_control_name) && (!dev_status_name))
        return 0;

    /* alloc our struct. */
    d = (struct TxtDaemonIf *) malloc(sizeof(*d));
    if (!d) {
        ret = ENOMEM;
        goto leave;
    }
    memset(d, 0, sizeof(*d));
    d->replybuffer_size = replybuffersize;
    d->replybuffer = (char*)malloc(d->replybuffer_size);
    if (!d->replybuffer) {
        ret = ENOMEM;
        goto leave;
    }

    /* open filehandles to the daemon process */
    if (dev_control_name) {
        d->daemon_fh_ctl = open(dev_control_name, O_RDWR);
        if (d->daemon_fh_ctl <= 0) {
            DBG_PRINT("error opening daemon filehandle '%s'\n",
                      dev_control_name);
            ret = (errno ? errno : EIO);
            goto leave;
        }
        ret = check_typeid(d, dev_typeid_string, 0);
        if (ret)
            goto leave;
    }
    if (dev_status_name) {
        d->daemon_fh_sta = open(dev_status_name, O_RDWR);
        if (d->daemon_fh_sta <= 0) {
            DBG_PRINT("error opening daemon filehandle '%s'\n",
                      dev_status_name);
            ret = (errno ? errno : EIO);
            goto leave;
        }
        ret = check_typeid(d, dev_typeid_string, 1);
        if (ret)
            goto leave;
    }

    /* Call version command */
    strncpy(d->command, "version", sizeof(d->command));
    ret = tdi__send_command(d, 0);
    if (ret) {
        DBG_PRINT("error sending 'version' command. ret=%d.\n", ret);
        goto leave;
    }
    for (n = 0; d->replybuffer[n]; n++)
        if (d->replybuffer[n] == '\n')
            break;
    memcpy(d->versionstring, d->replybuffer, n);
    d->versionstring[n] = 0;
    DBG_PRINT("daemon version: '%s'.\n", d->versionstring);

    ret = 0;

leave:
    if (ret || !d) {
        /* This is a fail. Deallocate what we already have and return zero. */
        tdi__close(d);
        errno = ret;
        return 0;
    }
    return d;
}

/**
 * fidm_paramete_api_close() deallocates the handle.
 * This means it closes the filehandle and deallocates
 * any memory held within the handle.
 */
void tdi__close(struct TxtDaemonIf *hdl)
{
    if (!hdl)
        return;
    if (hdl->daemon_fh_ctl > 0)
        close(hdl->daemon_fh_ctl);
    hdl->daemon_fh_ctl = -1;
    if (hdl->daemon_fh_sta > 0)
        close(hdl->daemon_fh_sta);
    hdl->daemon_fh_sta = -1;
    if (hdl->replybuffer)
        free(hdl->replybuffer);
    hdl->replybuffer = 0;

    free(hdl);
}

/**
 * tdi__send_command()
 *
 * This function sends a string command to the daemon and waits
 * for a reply.
 *
 * All other queries in this lib use this function to contact the daemon.
 *
 * The command is in the handle's command[] array.
 * The protocol of determining that a command or the reply is done
 * is similar to http. A double newline indicates the end of a command or reply.
 *
 * The function insures that the command ends with two newlines,
 * sends that using write(), then reads from the filehandle until
 * the data received includes two newlines.
 *
 * The first line of the response is an errorcode from the command
 * processing of the daemon. A zero indicates success.
 * This function evaluates this line, strips it off, and returns
 * the error as return value.
 *
 * returns an errno in read() or write() failed, otherwise the status
 * from the reply. zero means a successful command.
 *
 * If the daemon stalls for some reason the call can time-out.
 */
#define TIMEOUT_MSEC 5000
int tdi__send_command(struct TxtDaemonIf *hdl, char bUseStatusHdl)
{
    int fh;
    int ret;
    int num;
    int i;
    int blk;
    fd_set fhset;
    struct timeval tv;
    char *result;
    const char *replybody;

    if (!hdl)
        return EIO;
    fh = pick_fh(hdl, bUseStatusHdl);
    if (fh < 0)
        return EIO; // for some strange reason it's not open.

    result = hdl->replybuffer;

    DBG_PRINT("sending '%s'\n", hdl->command);
    /* send command. */
    blk = strlen(hdl->command);
    /* insure it ends with a newline. The daemon uses that to see that a command
     * is ended. */
    while (blk > 1 && hdl->command[blk - 2] == '\n' &&
           hdl->command[blk - 1] == '\n')
        hdl->command[--blk] = 0;
    if (blk < 1 || hdl->command[blk - 1] != '\n')
        hdl->command[blk++] = '\n'; // if this overwrites the null-terminator,
                                    // it is ok. Not needing it anymore.

    ret = write(fh, hdl->command, blk);
    if (ret != blk) {
        DBG_PRINT("write() failed. %d\n", ret);
        return (ret < 0 ? -ret : EIO);
    }

    /* now read until having data with two newlines at the end. */
    num = 0;
    FD_ZERO(&fhset);
    FD_SET(fh, &fhset);
    tv.tv_sec = (TIMEOUT_MSEC / 1000);
    tv.tv_usec = (TIMEOUT_MSEC % 1000) * 1000;
    while (num < 1 || result[num - 1]) {
        int blk;
        char *crcr;
        blk = hdl->replybuffer_size - 1 - num;
        if (blk <= 0)
            return EMSGSIZE; /* buffer provided is too small. */

        /* wait for the filehandle to become ready to read. */
        ret = select(fh + 1, &fhset, 0, 0, &tv);
        if (ret == -EINTR) /* interrupted by signal? */
            continue;
        if (ret < 0) {
            DBG_PRINT("select() failed. %d\n", ret);
            return -ret; /* failed */
        }
        if (ret == 0) {
            DBG_PRINT("select() timed out.\n");
            return ETIMEDOUT;
        }

        /* have data. can read. */
        ret = read(fh, result + num, blk);
        if (ret <= 0 || ret > blk) {
            DBG_PRINT("read() failed. res=%d blk=%d\n", ret, blk);
            return (ret < 0 ? -ret : EIO);
        }
        num += blk;
        /* if having the two CRs, we are done. */
        result[num] = 0;
        crcr = strstr(result, "\n\n");
        if (crcr) {
            // overwrite the second CR with a nullbyte and exit while loop.
            crcr++;
            num = crcr - result;
            result[num] = 0;
            DBG_PRINT("have complete reply with \\n\\n. %d bytes.\n", num);
            break;
        }
    }
    /* having a result.
     *first line shall be nothing but a number, with the errorcode.
     */
    replybody = 0;
    for (i = 0; result[i]; i++)
        if (result[i] == '\n') {
            replybody = result + i + 1;
            result[i] = 0;
            break;
        }

    if (!i) {
        /* not a proper response. */
        return EBADE;
    }
    i = (int) atoi(result);
    DBG_PRINT("statuscode from reply: %d.\n", i);
    /* move remainder up in buffer */
    if (replybody)
        memmove(result, replybody, strlen(replybody) + 1);
    else
        result[0] = 0;

    /* and return errorcode from response header */
    return i;
}

int tdi__reply_to_buf(struct TxtDaemonIf *hdl, char *buffer, int buffersize,
                      char bFirstLineOnly)
{
    int l;
    int ret;
    const char *rb = hdl->replybuffer;

    if (!buffer || buffersize < 2)
        return EINVAL;

    // size to copy
    if (bFirstLineOnly) {
        for (l = 0; l < (int) hdl->replybuffer_size; l++)
            if (rb[l] == 0 || rb[l] == '\n')
                break;
    } else {
        l = strlen(rb);
        if (l > (int) hdl->replybuffer_size)
            l = hdl->replybuffer_size;
    }

    ret = 0;
    if (l >= buffersize) {
        l = buffersize - 1;
        ret = EOVERFLOW;
    }

    memcpy(buffer, rb, l);
    buffer[l] = 0;

    return ret;
}

int tdi__notifier_register(struct TxtDaemonIf *hdl, const char *maskmatch, int chan_id)
{
	int ret;
	static TxtDaemonNotif *noti;

	// parameter sanity check
	if(!hdl||chan_id<0)
		return EINVAL;

	if(!maskmatch)
		maskmatch="*";

	// alloc a slot in the notifiers
	noti = alloc_notify(hdl);
	if(!noti)
		return EINVAL;	// too many notifiers on this handle
	noti->chid = chan_id;
	noti->cb = 0;
	noti->cb_context = 0;

	// build and send command.
	snprintf(hdl->command,TDI_COMMANDBUFFERSIZE,"notify_reg %d %d %s",(int)getpid(),chan_id,maskmatch);
	ret = tdi__send_command(hdl,1);

	if(ret)
	{
		// command to resmgr failed?
		noti->chid=-1;	// free notify struct.
		return ret;
	}


	return ret;
}

int tdi__notifier_unregister(struct TxtDaemonIf *hdl)
{
	char did_unreg=0;

	/* parameter sanity check */
	if(!hdl)
		return EINVAL;

	if(!hdl->notifies)
		return 0;	// nothing registered

	for(int i=0;i<MAX_NOTIFIERS;i++)
	{
		TxtDaemonNotif *noti = hdl->notifies + i;

		/* it not in use, skip */
		if(noti->chid<0)
			continue;

		/* build and send command for our daemon. */
		snprintf(hdl->command,TDI_COMMANDBUFFERSIZE,"notify_unreg %d %d",(int)getpid(),noti->chid);
		tdi__send_command(hdl,1);
		/* Ignoring result. Unregister shall always work. */
		did_unreg++;

		/* Mark as free */
		noti->chid = -1;


	}

	return ( did_unreg>0 ? 0 : EINVAL );
}

int tdi__notifier_get_msg(struct TxtDaemonIf *hdl,unsigned int key, char *out_buffer, int buffermax)
{
	int ret;

	snprintf(hdl->command,TDI_COMMANDBUFFERSIZE,"notify_pickup %u",key);
	ret = tdi__send_command(hdl,1);
	if(ret)
		return ret;

	// ...... message in replybuffer.
	return 0;
}

int tdi__quote_string(const char *string, char *buffer, unsigned int buffersize)
{
    char *bend;
    static const char *hexes = "0123456789ABCDEF";

    if (buffersize < 4)
        return -1;

    bend = buffer + buffersize;
    *(buffer++) = '\"';
    while (*string && buffer + 2 <= bend) {
        char b = *(string++);
        if (b == '\n') {
            *(buffer++) = '\\';
            *(buffer++) = 'n';
            continue;
        }
        if (b == '\t') {
            *(buffer++) = '\\';
            *(buffer++) = 't';
            continue;
        }
        if (b == '\"') {
            *(buffer++) = '\\';
            *(buffer++) = '\"';
            continue;
        }
        if (b == '\\') {
            *(buffer++) = '\\';
            *(buffer++) = '\\';
            continue;
        }
        if (b < 32 || b >= 127) {
            if (buffer + 4 >= bend)
                return -1;
            *(buffer++) = '\\';
            *(buffer++) = 'x';
            *(buffer++) = hexes[(b >> 4) & 15];
            *(buffer++) = hexes[b & 15];
            continue;
        }
        *(buffer++) = b;
    }
    if (*string || buffer + 2 >= bend)
        return -1;
    *(buffer++) = '\"';
    *buffer = 0;

    return 0;
}

int tdi__unquote_string(const char **ptr2string, char *buffer, unsigned int buffersize)
{
	const char *rd = *ptr2string;
	char *wr = buffer;
	if(buffersize<2)
		return -1;
	// skip whitespace before the opening quote
	while(*rd==' '||*rd=='\t')rd++;
	if(*rd!='\"')
		return -EINVAL;
	rd++;
	// loop characters until hitting end quote
	while(*rd!='\"')
	{
		if(!*rd)  /* string ends here while still looking for end quote? */
			return -EINVAL;
		if(buffersize<2)	/* out of buffer space for output? */
			return -1;
		buffersize--;
		if(*rd=='\\')	/* something which is escaped */
		{
			rd++;
			if(*rd=='\\')
			{
				*(wr++)='\\';
				rd++;
				continue;
			}
			if(*rd=='\"')
			{
				*(wr++)='\"';
				rd++;
				continue;
			}
			if(*rd=='n')
			{
				*(wr++)='\n';
				rd++;
				continue;
			}
			if(*rd=='r')
			{
				*(wr++)='\r';
				rd++;
				continue;
			}
			if(*rd=='t')
			{
				*(wr++)='\t';
				rd++;
				continue;
			}
			if(*rd=='x'||*rd=='X')
			{
				char h,l;
				rd++;
				h=*(rd++);
				if(h>='0'&&h<='9')h=h-'0';
				else if(h>='a'&&h<='f')h=h+10-'a';
				else if(h>='A'&&h<='F')h=h+10-'A';
				else return -EINVAL;
				l=*(rd++);
				if(l>='0'&&l<='9')l=l-'0';
				else if(l>='a'&&l<='f')l=l+10-'a';
				else if(l>='A'&&l<='F')l=l+10-'A';
				else return -EINVAL;
				h = (h<<4)+(l&15);
				if(!h)return -EINVAL;	/* don't allow null bytes in string. */
				*(wr++)=h;
				continue;
			}
			return -EINVAL;		/* Unknown symbol after backslash. Tolerand decoders would ignore it? */
		}
		*(wr++) = *rd;
		rd++;
	}
	/* if getting out here, *rd is the closing quote. */
	rd++;
	*ptr2string = rd;

	return 0;
}

char* tdi_load_textfile(const char *filename,int *out_errno)
{
	int fh;
	int tmp;
	off_t fsize;
	char *res = NULL;

	// open filehandle.
	fh = open(filename,O_RDONLY);
	if(fh<0)
	{
		*out_errno = errno;
		if(!*out_errno)
			*out_errno = EINVAL;
		DBG_PRINT("failed to open file '%s'\n",filename);
		return 0;
	}
	// get filesize
	fsize = lseek(fh,0,SEEK_END);
	if( fsize==-1 && errno!=0 )
	{
		*out_errno = errno;
		DBG_PRINT("failed to seek to fileend\n");
		goto leave;
	}
	lseek(fh,0,SEEK_SET);

	if( fsize>0x100000 || fsize<1 )
	{
		*out_errno = -EINVAL;
		DBG_PRINT("file size (%d) invalid.\n",(int)fsize);
		goto leave;
	}

	/* alloc space for data. */
	res = (char*)malloc(fsize+3);
	if(!res)
	{
		*out_errno = ENOMEM;
		DBG_PRINT("malloc fail\n");
		goto leave;
	}
	memset( res+fsize , 0 , 3 ); /* append 3 null bytes */

	/* load file data */
	fsize -= read(fh,res,fsize);
	tmp = errno;
	close(fh);fh=0;

	if(fsize)
	{
		free(res);
		res=NULL;
		*out_errno = tmp;
		DBG_PRINT("file read() failed. errno=%d\n",(int)tmp);
	}

leave:
	if(!res)
	{
		if(fh>=0)
		{
			while( close(fh)==-1 && errno==EINTR )
				{}
		}
	}

	return res;
}

static int check_typeid(struct TxtDaemonIf *hdl, const char *typeid_string,
                        char bOnStatus)
{
    int ret;
    int n;

    if (!typeid_string || !*typeid_string)
        return 0;

    strncpy(hdl->command, "<resmgrID>", sizeof(hdl->command));
    ret = tdi__send_command(hdl, bOnStatus);
    if (ret) {
        DBG_PRINT("error sending '<resmgrID>' command. ret=%d.\n", ret);
        return ret;
    }
    for (n = 0; hdl->replybuffer[n]; n++)
        if (hdl->replybuffer[n] == '\n')
            break;
    hdl->replybuffer[n] = 0;
    if (strcmp(hdl->replybuffer, typeid_string)) {
        DBG_PRINT("daemon type string mismatch. Found '%s', expected '%s'\n",
                  hdl->replybuffer, typeid_string);
        return EINVAL;
    }
    return 0;
}

static int pick_fh(struct TxtDaemonIf *hdl, char bOnStatus)
{
    /* If one of the filehandles is NULL, use the other */
    if (!hdl->daemon_fh_ctl)
        return hdl->daemon_fh_sta;
    if (!hdl->daemon_fh_sta)
        return hdl->daemon_fh_ctl;
    /* Have both. If choosing status, use that. */
    if (bOnStatus)
        return hdl->daemon_fh_sta;
    /* control-handle otherwise */
    return hdl->daemon_fh_ctl;
}

static TxtDaemonNotif *alloc_notify(struct TxtDaemonIf *hdl)
{
	if(!hdl)return 0;
	if(!hdl->notifies)
	{
		hdl->notifies = (TxtDaemonNotif*)malloc(sizeof(TxtDaemonNotif)*MAX_NOTIFIERS);
		if(!hdl->notifies)return 0;
		for(int i=0;i<MAX_NOTIFIERS;i++)
		{
			hdl->notifies[i].chid = -1;
			hdl->notifies[i].cb = 0;
		}
	}
	for(int i=0;i<MAX_NOTIFIERS;i++)
	{
		TxtDaemonNotif *res = hdl->notifies + i;
		if(res->chid<0)
		{
			// this one is free.
			res->chid = 0x7FFFFFFF;	// dummy value overwritten by caller. Marks as used.
			return res;
		}
	}
	return 0;
}

