#include "nolib.h"
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/neutrino.h>
#include <sys/select.h>
#include "txtdaemon_common.h"


#define HANDLE_OFFSET 0x0003FE00

#define DBG_PRINT(...) do{}while(0)
//#define DBG_PRINT(...) printf("DEBUGG: " __VA_ARGS__)

#define NEG(a) ((a)<=0?(a):-(a))

#define COMMANDBUFFERSIZE 1024
#define REPLYBUFFERSIZE 4096
struct testtlib_state
{
	struct TxtDaemonIf *dif;
	unsigned int index;
	int noti_chan;
};

typedef struct NotiCbStr
{
	struct testtlib_state *tlhdl;
	void (*cb)(const char*,int,void*);
	void *ctx;
} NotiCbStr;

/* global instance list to track our integer IDs. */
#define MAX_INST 8
static struct testtlib_state *instlist[MAX_INST];
static char instlist_isinit=0;
static pthread_mutex_t instlist_mutex = PTHREAD_MUTEX_INITIALIZER;

static void notify_callback(const char *msg,int size,void *ctx);




int testtlib_open(const char *devnode)
{
	struct testtlib_state *d;
	int ret,t;

	/* alloc our struct. */
	d = (struct testtlib_state*)malloc(sizeof(*d));
	if(!d)
		return -ENOMEM;
	memset( d , 0 , sizeof(*d) );
	d->noti_chan = -1;

	/* Find a slot in the list of instances */
	pthread_mutex_lock(&instlist_mutex);
	if(!instlist_isinit)
	{
		memset( instlist , 0 , sizeof(instlist) );
		instlist_isinit=1;
	}
	for(t=0;t<MAX_INST;t++)
	{
		if(!instlist[t])
			break;
	}
	if(t>=MAX_INST)
	{
		/* No slot free, return ENOMEM */
		free(d);
		pthread_mutex_unlock(&instlist_mutex);
		return -ENOMEM;
	}
	/* Link in this slot, continue to opening the resmgr-node */
	instlist[t] = d;
	d->index = t;
	pthread_mutex_unlock(&instlist_mutex);


	/* Most part is in shared base, call open on base. */
	d->dif = tdi__open(devnode,0,"type_test_tlib_daemon",1024);
	if (!d->dif)
	{
		ret = errno;
		testtlib_close(d->index+HANDLE_OFFSET);
		if (ret > 0)
			ret = -ret;
		else if (ret == 0)
			ret = -1;
		return ret;
	}

	return d->index+HANDLE_OFFSET;
}

void testtlib_close(int handle)
{
	struct testtlib_state *d;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return;

	d=instlist[handle-HANDLE_OFFSET];

	if(d->dif)
		tdi__close(d->dif);
	d->dif=0;
	instlist[handle-HANDLE_OFFSET] = 0;

	free(d);
}

int testtlib_read(int handle,unsigned int adr,unsigned short *out_data)
{
	struct testtlib_state *d;
	int ret;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	sprintf(d->dif->command,"load 0x%04X",adr);
	ret = tdi__send_command(d->dif,0);
	if(ret)
		return ret;

	char *ed=0;
	errno=0;
	long int val = strtol(d->dif->replybuffer,&ed,0);
	if( errno )
		return errno;
	if( (*ed!=' '&&*ed!='\n'&&*ed!='\r'&&*ed!=0) || val<0 || val>=0x10000 )
		return EINVAL;

	*out_data = (unsigned short)val;

	return 0;
}

int testtlib_write(int handle,unsigned int adr,unsigned short data)
{
	struct testtlib_state *d;
	int ret;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	sprintf(d->dif->command,"store 0x%04X 0x%04X",adr,(unsigned int)data);
	ret = tdi__send_command(d->dif,0);

	return ret;
}

int testtlib_set(int handle, const char *control_name, char *control_data)
{
	struct testtlib_state *d;
	int ret;
	char *wr,*wre;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	/* Put both strings, quoted */
	wr = d->dif->command;
	wre = wr+TDI_COMMANDBUFFERSIZE;
	wr += snprintf(wr,wre-wr,"ctrl ");

	tdi__quote_string(control_name,wr,wre-wr);
	wr += strlen(wr);
	if(wr+1<wre)
		*(wr++)=' ';
	*wr=0;
	tdi__quote_string(control_data,wr,wre-wr);
	wr += strlen(wr);

	/* And send it */
	ret = tdi__send_command(d->dif,0);

	return ret;
}

int testtlib_testpat(int handle, const char *pattern, const char *item)
{
	struct testtlib_state *d;
	int ret;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	snprintf(d->dif->command,TDI_COMMANDBUFFERSIZE,"testpat %s %s",pattern,item);
	ret = tdi__send_command(d->dif,1);

	if(ret)
	{
		if(ret>0)ret=-ret;
		return ret;
	}
	if( d->dif->replybuffer[0]!='m' )
		return 1;	// does not match
	return 0;	// match.
}

int testtlib_get(int handle, const char *control_name, char **status)
{
	struct testtlib_state *d;
	char *wr,*wre;
	int ret;
	int l;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	if(!status)
		return -EINVAL;

	wr = d->dif->command;
	wre = wr+TDI_COMMANDBUFFERSIZE;
	wr += snprintf(wr,wre-wr,"statusget ");
	d->dif->command[COMMANDBUFFERSIZE-1]=0;
	tdi__quote_string(control_name,wr,wre-wr);

	ret = tdi__send_command(d->dif,1);

	// get reply to *status.
	l = strlen(d->dif->replybuffer);
	while( l>0 && d->dif->replybuffer[l-1]=='\n' )
		l--;
	*status = (char*)malloc(l+1);
	if(!*status)
		return ENOMEM;
	memcpy(*status,d->dif->replybuffer,l);
	(*status)[l]=0;

	return ret;
}

#define CRC_RUN_BUFFERSIZE 0x1000

int testtlib_crc(
			int handle ,
			unsigned int size ,
			unsigned int *out_crc ,
			int (*getmoredata)(void *ctx,char *buffer,int buffersize) ,
			void (*progress)(void *ctx,float progress_0_1) ,
			void *ctx
)
{
	struct testtlib_state *d;
	int rfh;
	char *buffer=0;
	int ret;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	// our work-buffer here
	buffer = (char*)malloc(CRC_RUN_BUFFERSIZE);
	if(!buffer)
		{ret=ENOMEM;goto leave;}

	// send command to start transfer
	sprintf(d->dif->command,"crc start %u",size);
	ret = tdi__send_command(d->dif,0);

	// ok?
	if(ret)
		goto leave;

	// when ok, we need to send the announced amount of binary data now.
	// we pick the filehandle from the res-mgr and write() directly to it.
	// for the duration of the binary-transfer, the text-processing layer is out.
	rfh = d->dif->daemon_fh_ctl;
	if(!rfh)
		{ret=EINVAL;goto leave;}

	// send all
	while(size>0)
	{
		unsigned int blk;

		// how many to transfer now?
		blk = CRC_RUN_BUFFERSIZE;
		if(blk>size)
			blk=size;
		// get from our source
		ret = getmoredata(ctx,buffer,blk);
		if( ret<=0 || ret>blk )
		{
			ret=EIO;
			goto leave;
		}
		blk = ret;
		// now send to res-mgr
		ret = write(rfh,buffer,blk);
		if(ret!=blk)
		{
			ret=errno;
			if(!ret)ret=EIO;
			goto leave;
		}
		size -= blk;
	}

	// after the binary data, send the command to check and pick up the result.
	sprintf(d->dif->command,"crc stop");
	ret = tdi__send_command(d->dif,0);
	if(ret)
		goto leave;

	ret = 0;

	// have CRC in replybuffer now.
	// interpret as integer
	if(1)
	{
		long int val;
		char *ep;
		errno=0;
		val = strtol(d->dif->replybuffer,&ep,0);
		if( *ep && *ep!=' ' && *ep!='\n' && *ep!='\r' )
			ret=EINVAL;
		else if( val>0xFFFFFFFFull || val<-0x80000000ll ) // these 'll' are really needed. Else, gcc f*cks this up.
			ret=EINVAL;
		else
			*out_crc = (unsigned int)val;
	}


leave:
	if(buffer)
		free(buffer);
	return ret;
}

int testlib_delay(int handle,float deltime)
{
	struct testtlib_state *d;
	int ret;
	int progr;
	unsigned int time_ms;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	/* Add a notifier on daemon */

	ret = testlib_notifier_register_cb(handle,"prog* , blah",notify_callback,d);
	if (ret)
		goto leave;

	/* Now build the delay command */
	time_ms = (unsigned int)(1000.0f*deltime+0.5f);
	if(time_ms==0)
		time_ms=1;
	sprintf(d->dif->command,"delay %.3f",deltime);
	ret = tdi__send_command(d->dif,0);
	if(ret!=0)
		goto leave;
	// check progress value.
	progr = atoi(d->dif->replybuffer);
	if(progr<100)
	{
		// was not done synchronously. We will need to poll and wait.
		printf(" ... takes some longer. Using delaystatus to observe status.\n");
		while(progr<100)
		{
			// totally ugly poll loop. Nicer code will use our progress notification callback to know when to poll.
			usleep(100000);
			sprintf(d->dif->command,"delaystatus");
			ret = tdi__send_command(d->dif,0);
			if(ret!=0)
				goto leave;
			progr = atoi(d->dif->replybuffer);
		}
		printf(" ... delaystatus reported it is done.\n");
	}


	ret = 0;
leave:
	tdi__notifier_unregister(d->dif);
	return ret;
}


#define TDI_PULSE_CODE_NOTIFIER (120)
#define TDI_PULSE_CODE_NOTIFIER_UNREG (121)

static void *notify_thr(void *ctx);


int testlib_notifier_register_cb(int handle,const char *maskmatch,void (*cb)(const char*,int,void*),void *ctx)
{
	struct testtlib_state *d;
	int ret;
	int res=EIO;
	NotiCbStr *def_noti = 0;
	pthread_t thrid=0;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit || !cb )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	if(d->noti_chan>=0)
		return -EINVAL;	// this stub supports only one notifier.

	def_noti = (NotiCbStr*)malloc(sizeof(*def_noti));
	if(!def_noti)
		{res=ENOMEM;goto leave;}
	def_noti->tlhdl = d;
	def_noti->cb = cb;
	def_noti->ctx = ctx;

	/* Need a QNX channel to receive a notifiction */
	ret = ChannelCreate_r(_NTO_CHF_DISCONNECT|_NTO_CHF_UNBLOCK);
	if(ret<0)	// failed?
		goto leave;
	d->noti_chan = ret;

	/* launch a pthread to listen on the channel */
	ret = pthread_create( &thrid , 0 , notify_thr , def_noti );
	if(ret)
	{
		/* could not create thread */
		res=ret;
		goto leave;
	}
	def_noti = 0; /* Responsibility for this is now with thread. Do not dealloc, even if error. */

	/* Add a notifier on daemon using lower-level function on this stub. */
	ret = tdi__notifier_register( d->dif , maskmatch , d->noti_chan );
	if (ret)
	{
		int coid = ConnectAttach(0,(int)getpid(),d->noti_chan,2,0);
		if(coid>=0)
		{
			MsgSendPulse(coid,-1,TDI_PULSE_CODE_NOTIFIER_UNREG,0);
			ConnectDetach(coid);
		}
		goto leave;
	}

	res = 0;

leave:
	if(def_noti)
		free(def_noti);
	if( res && d->noti_chan>=0 )
	{
		ChannelDestroy(d->noti_chan);
		d->noti_chan = -1;
	}

	return res;
}

int testlib_notifier_unregister(int handle)
{
	struct testtlib_state *d;

	if( handle<HANDLE_OFFSET || handle>=HANDLE_OFFSET+MAX_INST || !instlist_isinit )
		return -EINVAL;

	d=instlist[handle-HANDLE_OFFSET];

	/* ping our thread to stop */
	if(d->noti_chan>=0)
	{
		int coid = ConnectAttach(0,(int)getpid(),d->noti_chan,2,0);
		if(coid>=0)
		{
			MsgSendPulse(coid,-1,TDI_PULSE_CODE_NOTIFIER_UNREG,0);
			ConnectDetach(coid);
		}
		d->noti_chan = -1;
		// not calling ChannelDestroy() here, that is done by the thread on exit.
	}

	/* unreg in tdi layer */
	return tdi__notifier_unregister(d->dif);
}

#define CB_THR_BUFSIZE 0x8000
static void *notify_thr(void *ctx)
{
	struct testtlib_state *d;
	NotiCbStr *def_noti;
	int ret;
	int qnx_chan;
	char *msgbuf;

	def_noti = (NotiCbStr*)ctx;
	d = def_noti->tlhdl;
	qnx_chan = d->noti_chan;

	msgbuf = (char*)malloc(CB_THR_BUFSIZE);

	/* Now wait */
	while(1)
	{
		struct _msg_info minf;
		ret = MsgReceive_r(qnx_chan,msgbuf,CB_THR_BUFSIZE,&minf);
		if(ret<0)
			break;	/* error. */
		if(ret==0)
		{
			if( ((struct _pulse*)msgbuf)->code == TDI_PULSE_CODE_NOTIFIER )
			{
				continue;	/* not currently using this */
			}
			if( ((struct _pulse*)msgbuf)->code == TDI_PULSE_CODE_NOTIFIER_UNREG )
			{
				/* Unregistering this callback. Just exit loop and deallocate this. */
				break;
			}
			continue;	/* some other pulse? not expecting one. */
		}
		/* have a message */
		int rcvid = ret;

		/* Is already in our buffer, so ack to QNX now. */
		MsgReply_r(rcvid,0,0,0);

		int msglen = minf.msglen;
		if(msglen>=CB_THR_BUFSIZE)
			msglen = CB_THR_BUFSIZE-1;
		msgbuf[msglen]=0;

		/* Call the registered callback */
		def_noti->cb(msgbuf,msglen,def_noti->ctx);

	}

	/* Exiting thread */
	ChannelDestroy(qnx_chan);
	free(def_noti);
	free(msgbuf);

	return 0;
}

static void notify_callback(const char *msg,int size,void *ctx)
{
//	struct testtlib_state *d;

//	d = (struct testtlib_state*)ctx;

	printf(" .... progress: %s\n",msg);
}



