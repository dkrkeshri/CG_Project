#pragma once

/**
 * A number of daemons use a similar protocol to communicate,
 * using a method similar to html.
 *
 * This file provides a basis to clients or client-libs to
 * communicate easily with this.
 *
 * CM/ESO2 Achim Dahlhoff
 */

#ifdef __cplusplus
extern "C" { /* Keep header compatible with being used from C++ code. */
#endif

#define TDI_COMMANDBUFFERSIZE 1024


struct TxtDaemonIf {
    int daemon_fh_ctl;
    int daemon_fh_sta;
    char command[TDI_COMMANDBUFFERSIZE]; // buffer for commands to send.
    char *replybuffer; // char buffer for replies, size REPLYBUFFERSIZE
    unsigned int replybuffer_size;
    char versionstring[32];
    struct TxtDaemonNotif *notifies;
};

/**
 * Open the device handle. Status name can be null if this daemon does not use a
 * status handle.
 * Will open the devices, check the type-id and call the 'version' command.
 */
struct TxtDaemonIf *tdi__open(const char *dev_control_name,
                              const char *dev_status_name,
                              const char *dev_typeid_string,
                              unsigned int replybuffersize);
void tdi__close(struct TxtDaemonIf *hdl);
// send command prepared in 'command'. Result will be in replybuffer. eno is
// stripped off.
int tdi__send_command(struct TxtDaemonIf *hdl, char bUseStatusHdl);
// copy a result from the 'replybuffer' to some user buffer, checking size.
int tdi__reply_to_buf(struct TxtDaemonIf *hdl, char *buffer, int buffersize,
                      char bFirstLineOnly);

int tdi__notifier_register(struct TxtDaemonIf *hdl, const char *maskmatch, int chan_id);
int tdi__notifier_unregister(struct TxtDaemonIf *hdl);
int tdi__notifier_get_msg(struct TxtDaemonIf *hdl,unsigned int key, char *out_buffer, int buffermax);

/// helper function. Load a textfile, malloc() a buffer and return it.
char* tdi_load_textfile(const char *filename,int *out_errno);


/// helper function to quote a string, whith escapes.
int tdi__quote_string(const char *string, char *buffer,
                      unsigned int buffersize);

/// helper function to undo quoting.
int tdi__unquote_string(const char **ptr2string, char *buffer, unsigned int buffersize);

#ifdef __cplusplus
}
#endif
