/*
 *  File: LFSR.h
 *
 *  This file is part of the Win32 testframework for Reliance/FlashFX.
 *
 *  <see c file for details>
 *
 *  CM-DI/CF3 Achim Dahlhoff
 */

#ifndef LFSH_H
#define LFSH_H

#include <stdint.h>

/*! \file CRandom.h
    \brief Contains the definition for the linear-feedback-register classes 'LFSR64', 'LFSR32' and 'LFSR16'.

    \author Achim Dahlhoff

    \version 1.0
    \date 2006-06-04
 */


/// maximum-period 64 bit linear-feedback-register.
//typedef struct _LFSR64 LFSR64;
/// maximum-period 32 bit linear-feedback-register.
//typedef struct _LFSR32 LFSR32;
/// maximum-period 16 bit linear-feedback-register.
//typedef struct _LFSR16 LFSR16;

#ifdef __cplusplus
extern "C" {
#endif

#define LFSR_CLS_DEC(nam,typ)						\
typedef struct _##nam								\
{													\
	typ m_state;									\
} nam;												\
													\
void nam##_init(nam *self);							\
void nam##_uninit(nam *self);						\
void nam##_set_state(nam *self,typ value);			\
typ nam##_get_state(nam *self);						\
													\
void nam##_process(nam *self,const unsigned char *in_data,unsigned char *out_data,unsigned int dataSize);	\
													\
void nam##_initTab(void);							\
extern const typ nam##_sm_poly;						\
extern char nam##_sm_isInit;						\
extern typ nam##_sm_loopTable[256];					\
extern uint8_t nam##_sm_outputTable[256];




LFSR_CLS_DEC(LFSR64,uint64_t)		//declare LFSR64
LFSR_CLS_DEC(LFSR32,uint32_t)		//declare LFSR32
LFSR_CLS_DEC(LFSR16,uint16_t)		//declare LFSR16

#ifdef __cplusplus
}
#endif


#endif
