#include <getopt.h>
#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include "LFSR.h"

#define BUFFERSIZE 0x10000

int main(int numargs,char *const*args)
{
	FILE *fh = 0;
	LFSR32 sreg;
	unsigned char *buffer = 0;
	int ret;
	int opt;
	uint32_t init_value = ~(uint32_t)0;
	const char *filename=0;

	buffer = (unsigned char*)malloc(BUFFERSIZE);
	if(!buffer)
		{ret=1;fprintf(stderr,"Malloc fail on 0x%06X bytes.\n",(unsigned int)BUFFERSIZE);goto leave;}

	while( (opt=getopt(numargs,args,"hn")) >= 0 )
	{
		switch(opt)
		{
		case 'h':
			printf("Usage:\n");
			printf("%s  <options> [inputfile]\n",args[0]);
			printf("options:\n");
			printf(" -h     show this hint.\n");
			printf(" -n     Init shift-reg to null, instead of $FFFFFFFF\n");
			return 0;
		case 'n':
			init_value = 0;
			break;
		default:
			fprintf(stderr,"unknown options, exiting. (use -h for options)\n");
			return 1;
		}
	}

	filename=0;
	if(optind<numargs)
		filename = args[optind++];

	if(optind<numargs)
		{ret=1;fprintf(stderr,"Need one arg for filename, or none for stdin. Not two or more.\n");goto leave;}

	// get file
	if(!filename)
		fh = stdin;
	else
	{
		fh = fopen(filename,"rb");
		if(!fh)
			{ret=1;fprintf(stderr,"Cannot open input file '%s'\n",filename);goto leave;}
	}

	LFSR32_init(&sreg);
	LFSR32_set_state(&sreg,init_value);

	// read until the end
	while(1)
	{
		ret = fread(buffer,1,BUFFERSIZE,fh);
		if( ret<0 || ret>BUFFERSIZE )
			{ret=1;fprintf(stderr,"Read error on file '%s'\n",filename);goto leave;}
		if(ret==0)
			break;	// EOF
		LFSR32_process(&sreg,buffer,0,ret);
	}

	printf("%08X\n",(unsigned int)LFSR32_get_state(&sreg));

	ret = 0;

leave:
	if( fh && filename )
		fclose(fh);
	if(buffer)
		free(buffer);
	return ret;
}
