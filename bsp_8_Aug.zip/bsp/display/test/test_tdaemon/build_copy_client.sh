#!/bin/bash

# compile the testprogram, copy it to the target and run it.

DR=`pwd`
DR=`realpath ${DR}`

# default IP if none passed as arg.
IP=192.168.211.100

if [[ "$1" != "" ]]; then
  IP=$1
fi
echo using target IP ${IP}

#build the testprogram
cd ./testprog/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of testprogram. 1>&2
  exit 1
fi

#check if target is reachable
ping -c 2 -i 0.25 -W 0.2 -w 1 ${IP}
RES=$?
if [ $RES -ne 0 ] ; then
  echo ${IP} not reachable
    exit 1
fi

# copy to the target

scp ./testprog/nto-aarch64-o.le/testprog root@${IP}:/tmp/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed.' 1>&2
  exit 1
fi

ssh root@${IP} 'cd /tmp/;echo RUN;./testprog -o online;echo;echo;sleep 0.25'

