#!/bin/bash

# Try to run a test on target with this daemon.

# calling the 2 ./build_copy* scripts might fail if header files were touched. The makefiles do not notice the changes.
# If running from clean folder or already after make, or any C file changes, it is ok.
#
# The ./build_copy* scripts have a target reachability check. They fail if the target is not there.

IP=192.168.211.100

# some helper functions
fn_kill_daemon()
{
	ssh root@${IP} 'slay -fQ testdaemon;sleep 0.25;slay -fQs 9 testdaemon'
}

fn_target_cleanup()
{
	fn_kill_daemon
#	ssh root@${IP} 'cd /tmp/;rm ./testdaemon ./testprog ./testlib_config.json'
}

# Function to check if target is reachable
fn_test_target_reachable()
{
	ping -c 2 -i 0.25 -W 0.2 -w 1 ${IP}
	RES=$?
	if [ $RES -ne 0 ] ; then
	  echo ${IP} not reachable
	    exit 1
	fi
}

# on remote end. kill daemon process if it exists
fn_test_target_reachable
if [ $? -ne 0 ] ; then    exit 1; fi

fn_kill_daemon

# build and upload binaries
./build_copy_client.sh ${IP}
if [ $? -ne 0 ] ; then
  echo build/upload of client tool failed. 1>&2
  exit 1
fi

./build_copy_daemon.sh ${IP}
if [ $? -ne 0 ] ; then
  echo build/upload of test daemon failed. 1>&2
  exit 1
fi

# build crc tool (not using crc32 from Ubuntu, because did not find the polynomial to match it)
(cd LFSR;make LFSR)
if [ $? -ne 0 ] ; then
  echo Error building crc utility 'LFSR'. 1>&2
  exit 1
fi


# create random file for the binary-transfer test
dd if=/dev/urandom of=./rnddata.bin bs=4k count=384
./LFSR/LFSR ./rnddata.bin > ./rnddata_crc.txt

scp ./on_target_testscript.sh ./rnddata.bin ./rnddata_crc.txt root@${IP}:/tmp/
if [ $? -ne 0 ] ; then
  echo upload of test script and random-data failed. 1>&2
  exit 1
fi

# on remote end, launch the daemon process, keep a shell on it open and keep the local PID
ssh root@${IP} 'cd /tmp/;./testdaemon -ddc testlib_config.json >/tmp/tdaemon_output.txt 2>&1' &
DPID=$!

# ugly: to check if the daemon properly starts up, wait one second.
# Then check if the resource-manager-node is there.
sleep 1.0
ssh root@${IP} 'ls -l /dev/testdaemon/node1'
if [ $? -ne 0 ] ; then
  echo starting of daemon process on target failed. 1>&2
  fn_target_cleanup
  exit 1
fi

# daemon is up and running.

echo === daemon on target and ready for test ===

ssh root@${IP} 'cd /tmp/;./on_target_testscript.sh'
RES=$?



# send quit signal to the daemon process
ssh root@${IP} 'slay -fQs SIGTERM testdaemon'
sleep 0.25
fn_target_cleanup

if [ $RES -ne 0 ] ; then
  echo on-target test failed. 1>&2
  echo output of daemon process on target is in /tmp/tdaemon_output.txt
  exit 1
fi
