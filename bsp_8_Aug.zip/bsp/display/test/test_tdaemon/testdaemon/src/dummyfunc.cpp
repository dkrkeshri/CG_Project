#include "dummyfunc.h"
#include <memory>
#include "LFSR.h"



struct DummyFunc::CrcRun
{
	unsigned int sum;	// current checksum
	unsigned int num;	// total number of bytes expected
	unsigned int i;		// current input point
	LFSR32 sreg;
};


DummyFunc::DummyFunc()
{
}

DummyFunc::~DummyFunc()
{
}

bool DummyFunc::store(unsigned short adr,unsigned short b)
{
	if( (adr&1) )
		return false;
	adr=adr>>1;
	if(adr>=DUMMY_STORE_SIZE)
		return false;
	stash[adr] = b;
	return true;
}

bool DummyFunc::load(unsigned short adr,unsigned short *out_b)
{
	if( (adr&1) )
		return false;
	adr=adr>>1;
	if(adr>=DUMMY_STORE_SIZE)
		return false;
	*out_b = stash[adr];
	return true;
}

DummyFunc::CrcRun *DummyFunc::crc_start(unsigned int count)
{
	CrcRun *res = new (std::nothrow) CrcRun();
	if(!res)
		return 0;
	res->sum = ~0u;
	res->num = count;
	res->i = 0u;
	LFSR32_init(&(res->sreg));
	return res;
}

void DummyFunc::crc_progress(CrcRun *run,const unsigned char *data,unsigned int count)
{
	if(!run)
		return;
	LFSR32_process(&(run->sreg),data,0,count);
	run->sum = LFSR32_get_state(&(run->sreg));
}

unsigned int DummyFunc::crc_finish(CrcRun *run,bool justdrop)
{
	unsigned int res = ~0u;
	if(!run)
		return res;

	res=run->sum;

	delete run;
	return res;
}



