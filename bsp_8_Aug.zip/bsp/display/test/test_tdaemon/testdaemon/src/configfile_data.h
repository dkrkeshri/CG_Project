#pragma once
#include <vector>
#include <string>
#include "txt_resmgr_base.h"


class ConfData
{
public:
	std::string logfile;
	bool use_slog2;
	unsigned char debuglevel;
	bool allow_quit;
	std::vector<unsigned short> initdata;	// from the 'data' section in the config.

	class Inst
	{
	public:
		std::string name;
		std::string resmgr_name;
	};

	std::vector<Inst> itemdata;


	static ConfData *load_config(const char *filename,errPrintfFunc errfunc);
	void debug_print_data(errPrintfFunc printffunc);
	bool get_item(const char *itemname,std::string *out_result,const char *defaultvalue);
	bool get_item(const char *itemname,char *out_result,int result_buffersize,const char *defaultvalue);

private:
	ConfData();
	bool extract_data_from_json(class JSDataNodeObject *js,std::string *out_err);
	bool extract_nodedata_from_json(class JSDataNodeObject *js,std::string *out_err,Inst *out_inhere);
	bool check_for_initdata(class JSDataNodeObject *js,std::string *out_err);

};



