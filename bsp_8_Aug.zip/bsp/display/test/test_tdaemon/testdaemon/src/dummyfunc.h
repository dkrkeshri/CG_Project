#pragma once

// dummy 'functionality' of the testdaemon.

#define DUMMY_STORE_SIZE 0x800

class DummyFunc
{
public:
	DummyFunc();
	~DummyFunc();

	bool store(unsigned short adr,unsigned short b);
	bool load(unsigned short adr,unsigned short *out_b);

	struct CrcRun;

	CrcRun *crc_start(unsigned int count);
	void crc_progress(CrcRun *run,const unsigned char *data,unsigned int count);
	unsigned int crc_finish(CrcRun *run,bool justdrop);

	unsigned short stash[DUMMY_STORE_SIZE];

	unsigned int crc_loop[0x100];
	unsigned char crc_out[0x100];
};

