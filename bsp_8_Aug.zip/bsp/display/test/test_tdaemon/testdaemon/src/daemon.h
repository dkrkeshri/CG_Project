#ifndef SRC_DAEMON_H
#define SRC_DAEMON_H
/**
 * shared items header file for testdaemon
 *
 * This header declares some functions and global variables used across
 * different source files of the daemon process.
 *
 * CM/ESO2 Achim Dahlhoff.
 */
#include <map>
#include <string>

#define DAEMON_PROGNAME "testdaemon"
// version string.
#define WAKEUP_DAEMON_VERSION "0.2"

#define DO_LOG_ALL_COMMANDS 1	// choose if all commands shall be sent to the log. If 0 and debuglevel is 0, they are not logged.


/**
 * Replybuffers are not pre-filehandle, but global.
 * This setting is only for testing. It breaks threadsafety.
 * It allows using from bash, where it is hard to send a line,
 * keep the filehandle open and read a reply from that filehandle.
 */
#define RESMGR_GLOBAL_STATE 0

class LogOutput;

#define LOGFILE_LINEBUF_SIZE 0x100
extern char *logfile_linebuffer;

/* properties taken from config file. */
extern class ConfData *config;

extern class DummyFunc *dfunc;



#endif
