#include "configfile_data.h"

/**
 * config file parser
 *
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "daemon.h"
#include "smalljs.h"


static void out_to_stdout(const char *msg,...);

/**
 * Load and parse a config file, create the ConfData item,
 * and place all usable values from the config inside it.
 *
 */
ConfData *ConfData::load_config(const char *filename,errPrintfFunc errfunc)
{
	ConfData *res = 0;
	int fh = -1;
	int err;
	bool success = false;
	std::string errtxt;
	JSDataNode *js = 0;
	char *buffer = 0;

	if(!errfunc)
		errfunc = out_to_stdout;

	err = 0;
	buffer = load_textfile(filename,&err);
	if(!buffer)
	{
		errfunc("error loading config file '%s', errno=%d\n",filename,err);
		goto leave;
	}


	// have file. send to json parser.
	js = parse_json(buffer,&errtxt);
	if(!js)
	{
		if(errtxt.size()>0)
			errfunc("error parsing config json data:  %s\n",errtxt.c_str());
		else
			errfunc("error parsing config json data\n");
		goto leave;
	}

	// top level shall be an object
	if(js->type!=JSTYPE_object)
	{
		errfunc("top level of json config file shall be an 'object'.\n");
		goto leave;
	}

	// create res
	res = new ConfData();

	// peel out parts we need.
	errtxt="";
	if(!res->extract_data_from_json((JSDataNodeObject*)js,&errtxt))
	{
		errfunc("failed to parse config file:  %s\n",errtxt.c_str());
		goto leave;
	}



	success = true;


leave:
	if(fh>=0)
		close(fh);
	if(buffer)
		delete[] buffer;
	if(js)
		delete js;
	if( res && !success )
	{
		delete res;
		res=0;
	}

	return res;
}

void ConfData::debug_print_data(errPrintfFunc printffunc)
{
	printffunc("Logfile path: '%s'\n",logfile.c_str());
	printffunc("Debuglevel: '%d'\n",(int)debuglevel);
	printffunc("Allow 'quit' cmd:  %s\n",(allow_quit?"True":"False"));
}

bool ConfData::get_item(const char *itemname,std::string *out_result,const char *defaultvalue)
{
	// todo: .....
	return false;
}

bool ConfData::get_item(const char *itemname,char *out_result,int result_buffersize,const char *defaultvalue)
{
	std::string tmp;
	int ln;
	if(!get_item(itemname,&tmp,defaultvalue))
		return false;
	ln = tmp.size();
	if(ln>=result_buffersize)
		ln = result_buffersize-1;
	if(ln>0)
	{
		memcpy(out_result,tmp.c_str(),ln);
		out_result[ln]=0;
	}
	return true;
}

ConfData::ConfData()
{
	use_slog2 = true;
}

/**
 * Process the parsed json data from the config file.
 * All usable values found are placed into the fields in 
 * the class' instance.
 *
 * In case failure, the string *out_err is filled with 
 * a meaningful error message such as which field is missing.
 *
 * Return true if successful.
 */
bool ConfData::extract_data_from_json(class JSDataNodeObject *js,std::string *out_err)
{
	JSDataNode *ch;
	JSDataNodeArray *cha;

	// get 'logfile'
	ch = js->get("logfile");
	if(ch)
	{
		if( ch->type!=JSTYPE_string )
		{
			*out_err = "config section 'logfile', if present, shall be a string.";
			return false;
		}
		logfile = ((JSDataNodeString*)ch)->text;
	}

	// get 'slog2'
	ch = js->get("slog2");
	if(ch)
	{
		if( ch->type!=JSTYPE_bool )
		{
			*out_err = "config section 'slog2', if present, shall be a boolean.";
			return false;
		}
		use_slog2 = ((JSDataNodeBool*)ch)->flag;
	}

	// get initdata section
	if(!check_for_initdata(js,out_err))
		return false;

	// get and parse data for node instances.
	ch = js->get("nodes");
	if( !ch || ch->type!=JSTYPE_array || ((JSDataNodeArray*)ch)->count()<1 )
	{
		*out_err = "config section 'nodes' shall exist and be an non-empty array.";
		return false;
	}
	itemdata.clear();
	cha = (JSDataNodeArray*)ch;
	for(unsigned int i=0;i<cha->count();i++)
	{
		Inst idata;

		ch = cha->get(i);
		if( !ch || ch->type!=JSTYPE_object )
		{
			*out_err = "config items under 'nodes' shall be objects.";
			return false;
		}

		if(!extract_nodedata_from_json((JSDataNodeObject*)ch,out_err,&idata))
			return false;
		itemdata.push_back(idata);
	}


	return true;
}

bool ConfData::extract_nodedata_from_json(class JSDataNodeObject *js,std::string *out_err,Inst *out_inhere)
{
	JSDataNode *ch;

	// in wakeup-chain, get 'name'
	ch = js->get("name");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section for a wakeup-chain must have a 'name'.";
		return false;
	}
	out_inhere->name = ((JSDataNodeString*)ch)->text;

	ch = js->get("device-node");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section for a wakeup-chain must have a 'device-node'.";
		return false;
	}
	out_inhere->resmgr_name = ((JSDataNodeString*)ch)->text;

	return true;
}

bool ConfData::check_for_initdata(class JSDataNodeObject *js,std::string *out_err)
{
	JSDataNode *ch;

	ch = js->get("data");
	if(!ch)
		return true;
	if( ch->type!=JSTYPE_array )
	{
		*out_err = "config section 'initdata' shall be of type list (if it exists).";
		return false;
	}
	JSDataNodeArray *cha = (JSDataNodeArray*)ch;
	unsigned int num = cha->count();
	initdata.resize(num);
	for(unsigned int i=0;i<num;i++)
	{
		JSDataNode *ch2 = cha->get(i);
		if( ch2->type!=JSTYPE_number )
		{
			*out_err = "config section 'initdata' shall contain only numbers.";
			return false;
		}
		double dv = ((JSDataNodeNumber*)ch2)->number;
		long int iv = (long int)dv;
		if(iv<-32768||iv>=65536)
		{
			*out_err = "config section 'initdata' numbers shall be in 16 bit integer range.";
			return false;
		}
		initdata[i] = (unsigned short)iv;
	}
	return true;
}

char* load_textfile(const char *filename,int *out_errno)
{
	int fh;
	int tmp;
	off_t fsize;
	char *res;

	// open filehandle.
	fh = open(filename,O_RDONLY);
	if(fh<0)
	{
		*out_errno = errno;
		if(!*out_errno)
			*out_errno = EINVAL;
		return 0;
	}
	// get filesize
	fsize = lseek(fh,0,SEEK_END);
	if( fsize==-1 && errno!=0 )
	{
		close(fh);
		*out_errno = errno;
		return 0;
	}
	lseek(fh,0,SEEK_SET);

	if( fsize>0x100000 || fsize<1 )
	{
		close(fh);
		*out_errno = -EINVAL;
		return 0;
	}

	/* alloc space for data. */
	res = (char*)malloc(fsize+3);
	if(!res)
	{
		close(fh);
		*out_errno = ENOMEM;
		return 0;
	}
	memset( res+fsize , 0 , 3 ); /* append 3 null bytes */

	/* load file data */
	fsize -= read(fh,res,fsize);
	tmp = errno;
	close(fh);fh=0;

	if(fsize)
	{
		free(res);
		*out_errno = tmp;
		if(!tmp)
			*out_errno = EIO;
		return 0;
	}

	return res;
}

static void out_to_stdout(const char *msg,...)
{
	va_list val;
	va_start(val,msg);

	vprintf(msg,val);
	printf("\n");

	va_end(val);
}

