#pragma once
#include "txt_resmgr_noti.h"
#include <string>
#include <vector>
#include "dummyfunc.h"


class ResMgrTest : public ResMgrNoti
{
public:
	ResMgrTest(const char *path,bool is_control);
	virtual ~ResMgrTest();

	virtual bool start(std::string *out_err,ResManagerDispatchloop *dispatcher);
	virtual void stop();

protected:
	virtual bool process_command(const char *command);
	virtual bool process_binary_data(const unsigned char *data,unsigned int size,bool is_last_chunk);


private:
	void process_command_version(const std::vector<std::string> *args);
	void process_command_listcommands(const std::vector<std::string> *args);
	void process_command_store(const std::vector<std::string> *args);
	void process_command_load(const std::vector<std::string> *args);
	void process_command_delay(const std::vector<std::string> *args);
	void process_command_delaystatus(const std::vector<std::string> *args);
	void process_command_testpat(const std::vector<std::string> *args);
	void process_command_crc(const std::vector<std::string> *args);
	void process_command_crc_start(unsigned int count);
	void process_command_crc_part(const unsigned char *data,unsigned int count);
	void process_command_crc_stop();
	void process_command_ping(const std::vector<std::string> *args);
	void process_command_quit();
public:
	void cbfunc(int value);
private:

	// ongoing delay command (simulation of sw-update command)
	// if timer = -1 and percent is zero, is free.
	// if timer = -1 and percent is 100, timer is done but status not yet picked up.
	// if timer >= 0 , then timer is still ticking.
	int64_t delay_timer;
	uint8_t delay_percent;
	bool delay_block_client;

	DummyFunc::CrcRun *crcrun=0;
	unsigned int CRCresult;
};


