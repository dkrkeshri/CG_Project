/*
 *  File: LFSR.c
 *
 *  This file is part of the Win32 testframework for Reliance/FlashFX.
 *
 *  LFSR contains three 'linear feedback shift register' classes.
 *  One for each size of 16, 32 or 64 bits.
 *  This is a port of my personal version of LFSR32, the C++ version.
 *  It is used for CRC calculation and for random number generation.
 *
 *
 *  CM-DI/CF3 Achim Dahlhoff
 *  Aug 2010
 */

#include "LFSR.h"


#define LFSR_CLS_IMPL(nam,typ,poly)						\
														\
void nam##_init(nam *self)								\
{														\
	self->m_state=~((typ)0);							\
	if(!nam##_sm_isInit)nam##_initTab();					\
}														\
														\
void nam##_uninit(nam *self)							\
	{}													\
														\
void nam##_set_state(nam *self,typ value)				\
	{self->m_state=value;}								\
typ nam##_get_state(nam *self)							\
	{return self->m_state;}								\
														\
void nam##_process(nam *self,const unsigned char *in_data,unsigned char *out_data,unsigned int dataSize)	\
{														\
  unsigned int t;										\
  uint16 byte;											\
	if(in_data)											\
	{													\
		if(out_data)									\
		{												\
			for(t=0UL;t<dataSize;t++)					\
			{											\
				byte = (uint16)(self->m_state^in_data[t])&0xFF;	\
				out_data[t]=nam##_sm_outputTable[byte];		\
				self->m_state=(self->m_state>>8)^nam##_sm_loopTable[byte];	\
			}											\
		}else{											\
			for(t=0UL;t<dataSize;t++)					\
			{											\
				self->m_state=(self->m_state>>8)^nam##_sm_loopTable[(self->m_state^in_data[t])&0xFF];	\
			}											\
		}												\
	}else{												\
		if(out_data)									\
		{												\
			for(t=0UL;t<dataSize;t++)					\
			{											\
				byte = (uint16)self->m_state&0xFF;			\
				out_data[t]=nam##_sm_outputTable[byte];		\
				self->m_state=(self->m_state>>8)^nam##_sm_loopTable[byte];	\
			}											\
		}else{											\
			for(t=0UL;t<dataSize;t++)					\
			{											\
				self->m_state=(self->m_state>>8)^nam##_sm_loopTable[self->m_state&0xFF];	\
			}											\
		}												\
	}													\
}														\
														\
void nam##_initTab(void)								\
{														\
  unsigned int t,s;										\
  typ sr;												\
  uint8 outVal;											\
	for(t=0UL;t<256;t++)								\
	{													\
		sr=t;outVal=0;									\
		for(s=0UL;s<8;s++)								\
		{												\
			outVal<<=1;									\
			if( sr&1 )									\
				{sr=(sr>>1)^nam##_sm_poly;outVal+=1;}	\
			else										\
				sr=sr>>1;								\
		}												\
		nam##_sm_loopTable[t]=sr;						\
		nam##_sm_outputTable[t]=outVal;					\
	}													\
	nam##_sm_isInit=1;									\
}														\
														\
														\
const typ nam##_sm_poly=poly;							\
char nam##_sm_isInit=0;									\
typ nam##_sm_loopTable[256];							\
uint8 nam##_sm_outputTable[256];

LFSR_CLS_IMPL(LFSR64,uint64,0xC96C5795D7870F42LL)//0xD800000000000000)
LFSR_CLS_IMPL(LFSR32,uint32,0x849F40E0)
LFSR_CLS_IMPL(LFSR16,uint16,0xB400)
