#include "resmgr_test.h"
#include "daemon.h"
#include "dummyfunc.h"
#include <errno.h>
#include <stdlib.h>
#include <txtdaemon_common.h>


static bool split(const char *argstr,std::vector<std::string> *items);



ResMgrTest::ResMgrTest(const char *path,bool is_control)
 : ResMgrNoti(path,"type_test_tlib_daemon")
{
	crcrun=0;
	delay_timer=-1;
	delay_percent = 0;
}

ResMgrTest::~ResMgrTest()
{
	if( crcrun && dfunc )
		dfunc->crc_finish(crcrun,true);
	if(delay_timer!=-1)
		timer_delete((timer_t)delay_timer);
}

bool ResMgrTest::start(std::string *out_err,ResManagerDispatchloop *dispatcher)
{
	if(!ResMgrNoti::start(out_err,dispatcher))
		return false;

	return true;
}

void ResMgrTest::stop()
{
	ResMgrNoti::stop();
}

bool ResMgrTest::process_command(const char *command)
{
	char cmdword[16];
	const char *cmdarg;
	int i;

	// parent class test
	if(ResMgrNoti::process_command(command))
		return true;

	// skip leading whitespace
	while( *command==' ' || *command=='\t' )command++;

	// copy command-word
	for(i=0;i+1<(int)sizeof(cmdword);i++)
	{
		char b = command[i];
		if(b==0||b==' '||b=='\t'||b=='\n'||b=='\r')
			break;
		cmdword[i]=b;
	}
	cmdword[i]=0;
	cmdarg = command+i;
	// skip whitespace
	while( *cmdarg==' ' || *cmdarg=='\t' )cmdarg++;

	// split remainder as list-of-args
	std::vector<std::string> args;

	if(!split(cmdarg,&args))
	{
		printrep("%d\nincorrectly quoted args or argument too long.\n",(int)EINVAL);
		return true;
	}

	// check command.
	if(!strcmp(cmdword,"listcommands"))
	{
		process_command_listcommands(&args);
	}else if(!strcmp(cmdword,"version"))
	{
		process_command_version(&args);
#if RESMGR_GLOBAL_STATE
		printrep("(warning: DEBUGmode. global state enabled!)\n");
#endif
	}else if(!strcmp(cmdword,"store"))
	{
		process_command_store(&args);
	}else if(!strcmp(cmdword,"load"))
	{
		process_command_load(&args);
	}else if(!strcmp(cmdword,"delay"))
	{
		process_command_delay(&args);
	}else if(!strcmp(cmdword,"delaystatus"))
	{
		process_command_delaystatus(&args);
	}else if(!strcmp(cmdword,"testpat"))
	{
		process_command_testpat(&args);
	}else if(!strcmp(cmdword,"crc"))
	{
		process_command_crc(&args);
	}else if(!strcmp(cmdword,"ping"))
	{
		process_command_ping(&args);
	}else if(!strcmp(cmdword,"quit"))
	{
		process_command_quit();
	}else{
		// unknown command.
		printrep("%d\nunknown command '%s'\n",(int)EINVAL,cmdword);
	}

//	printfunc(printfunc_ctx,"0\n");
	return true;
}

bool ResMgrTest::process_binary_data(const unsigned char *data,unsigned int size,bool is_last_chunk)
{
	if( !crcrun || !dfunc )
		return false;
	if( size==0 && !data )
	{
		// we are being notified that the filehandle is closed.
		dfunc->crc_finish(crcrun,true);
		crcrun=0;
	}
	dfunc->crc_progress(crcrun,data,size);
	if(is_last_chunk)
	{
		CRCresult = dfunc->crc_finish(crcrun,false);
		crcrun=0;
	}
	// .... test is_last_chunk in any way?
	return true;
}

void ResMgrTest::process_command_version(const std::vector<std::string> *args)
{
	printrep("0\n%s\n",WAKEUP_DAEMON_VERSION);
}

void ResMgrTest::process_command_listcommands(const std::vector<std::string> *args)
{
	printrep("%d\nnot implemented\n",(int)EINVAL);
}

void ResMgrTest::process_command_store(const std::vector<std::string> *args)
{
	unsigned int num;
	unsigned short vals[1+64];
	num = (unsigned int)args->size();
	if(num<2||num>1+64)
		{printrep("%d\nstore need 2 to 65 args. location and values. Found %u args.\n",(int)EINVAL,num);return;}
	// interpret all strings as numbers.
	for(unsigned int i=0;i<num;i++)
	{
		errno=0;
		const char *pn=(*args)[i].c_str();
		char *pe;
		long int d = strtol(pn,&pe,0);
		if( errno || *pe || d<0 || d>=0x10000 )
			{printrep("%d\nInvalid argument '%s'. Need ushort values.\n",(int)EINVAL,pn);return;}
		vals[i]=(unsigned short)d;
	}
	// now assign.
	unsigned int adr=vals[0];
	for(unsigned int i=1;i<num;i++)
	{
		if(!dfunc->store(adr,vals[i]))
			{printrep("%d\nCannot store value. (invalid location %u ?)\n",(int)EINVAL,(unsigned int)adr);return;}
		adr += 2;
	}
	printrep("0\nOK\n");
}

void ResMgrTest::process_command_load(const std::vector<std::string> *args)
{
	unsigned int num;
	unsigned short vals[64];
	num = (unsigned int)args->size();
	if(num<1||num>2)
		{printrep("%d\nload need 1 or 2 args. location and optionally count.\n",(int)EINVAL);return;}
	// interpret all strings as numbers.
	for(unsigned int i=0;i<num;i++)
	{
		errno=0;
		const char *pn=(*args)[i].c_str();
		char *pe;
		long int d = strtol(pn,&pe,0);
		if( errno || *pe || d<0 || d>=0x10000 )
			{printrep("%d\nInvalid argument '%s'. Need ushort values.\n",(int)EINVAL,pn);return;}
		vals[i]=(unsigned short)d;
	}
	// check count?
	if(num>=2)
		num=vals[1];
	else
		num=1;
	if(num<1||num>64)
		{printrep("%d\ncan read 1 to 64 items in one call. not %u.\n",(int)EINVAL,(unsigned int)num);return;}

	// now get
	unsigned int adr=vals[0];
	for(unsigned int i=0;i<num;i++)
	{
		if(!dfunc->load(adr,vals+i))
			{printrep("%d\nCannot get value. (invalid location %u ?)\n",(int)EINVAL,(unsigned int)adr);return;}
		adr += 2;
	}
	// output
	char op[2+8*64];
	int pt=0;
	for(unsigned int i=0;i<num;i++)
	{
		pt+=snprintf(op+pt,sizeof(op)-pt," 0x%02X",(unsigned int)(vals[i]));
	}
	printrep("0\n%s\n",op+1);
}

static void cb_timer_up(union sigval sv)
{
	ResMgrTest *d;
	d = (ResMgrTest*)sv.sival_ptr;
	d->cbfunc(0x07C007EC);
}

void ResMgrTest::process_command_delay(const std::vector<std::string> *args)
{
	double tv;
	int ret;
	if((*args).size()!=1)
		{printrep("%d\ndelay nees 1 arg. A time in seconds.\n",(int)EINVAL);return;}
	const char *pn=(*args)[0].c_str();
	char *pe;
	errno=0;
	tv = strtod(pn,&pe);
	if( errno || *pe || tv<=0.0 || tv>600.0 )
		{printrep("%d\ninvalid argument for delaytime. Need float number from >0.0 to <=600.0\n",(int)EINVAL);return;}

	// already one ongoing?
	if(delay_timer!=-1)
		{printrep("%d\nanother delay command is ongoing.\n",(int)EBUSY);return;}

	// create timer
	timer_t timid=0;
	sigevent evt;
	memset(&evt,0,sizeof(evt));

	evt.sigev_notify = SIGEV_THREAD;
	evt.sigev_notify_function = cb_timer_up;
	evt.sigev_notify_attributes = 0;
	evt.sigev_value.sival_ptr = this;
	ret = timer_create(CLOCK_MONOTONIC,&evt,&timid);
	if(ret)
		{printrep("%d\nError creating a timer.\n",(int)ENOMEM);return;}

	delay_timer = timid;

	delay_percent = 0;

	// start the timer.
	itimerspec ts;
	uint t_usec = (uint)(tv*1000000.0f+0.5f);
	// div 10 for notify intermediates.
	t_usec = (t_usec+5)/10;
	if(t_usec<1)t_usec=1;
	uint t_sec  = t_usec/1000000;
	uint t_frac = t_usec%1000000;
	ts.it_value.tv_sec = t_sec;
	ts.it_value.tv_nsec = t_frac*1000;
	ts.it_interval.tv_sec = t_sec;
	ts.it_interval.tv_nsec = t_frac*1000;
	timer_settime(timid,0,&ts,0);

	// there are two cases simulated here.
	// 1: blocking timer command. A synchronous caller will block until done.
	// 2: non-blocking. A synchronous call is reported that it will take longer.
	delay_block_client = (tv<=1.0);
	if(delay_block_client)
	{
		// mark as takes-some-longer ,
		this->mark_process_cmd_hang();
		// and do not create a reply.
	}else{
		// if longer, finish this call synchronously.
		// 0 for error-value, 0 for progress percentage
		printrep("0\n0\n");
	}
}

void ResMgrTest::process_command_delaystatus(const std::vector<std::string> *args)
{
	if( delay_timer==-1 && delay_percent==0 )
	{
		// no delay was started or it is already finished and result checked.
		printrep("%d\ndelay command not started.",(int)EINVAL);
		return;
	}
	unsigned int pval = delay_percent;
	if( delay_timer!=-1 && pval>=100 )
		pval = 99;

	printrep("0\n%u\n",pval);
}

void ResMgrTest::process_command_testpat(const std::vector<std::string> *args)
{
	if((*args).size()<2)
		{printrep("%d\ntestpat nees 2 args. pattern and itemname.\n",(int)EINVAL);return;}
	const char *pattern = (*args)[0].c_str();
	const char *item = (*args)[1].c_str();

	int res = txt_resmgr_test__testpat(pattern,item);
//	bool res = NotifyMsgQueue::check_mask_match(pattern,item);

	printrep("0\n%s\n\n",res?"does not match":"matches");
}

void ResMgrTest::process_command_crc(const std::vector<std::string> *args)
{
	if((*args).size()<1)
		{printrep("%d\ncrc nees 1 or 2 args. 'start' or 'stop'.\n",(int)EINVAL);return;}
	const char *pn=(*args)[0].c_str();
	if( !strcmp(pn,"start") )
	{
		if((*args).size()!=2)
			{printrep("%d\ncrc start needs an extra size argument.\n",(int)EINVAL);return;}
		long int count;
		errno=0;
		pn=(*args)[1].c_str();
		char *pe;
		count = strtol(pn,&pe,0);
		if( errno || *pe || count<1 || count>=0x100000000ll )
			{printrep("%d\ninvalid size argument for crc start.\n",(int)EINVAL);return;}
		process_command_crc_start((unsigned int)count);
		return;
	}
	if( !strcmp(pn,"stop") )
	{
		process_command_crc_stop();
		return;
	}
	printrep("%d\ninvalid keyword '%s' for crc. Need 'start' or 'stop'.\n",(int)EINVAL,pn);
}

void ResMgrTest::process_command_crc_start(unsigned int count)
{
	if(crcrun)
	{
		printrep("%d\nThere is already a crc run ongoing on another filehandle.\n",(int)EIO);
	}
	crcrun = dfunc->crc_start(count);
	if(!crcrun)
	{
		printrep("%d\nCould not start a crc run.\n",(int)EIO);
		return;
	}
	if(!this->binary_transfer_mode(count))
	{
		printrep("%d\nCould not prepare for transfer of binary data.\n",(int)EIO);
		dfunc->crc_finish(crcrun,true);
		crcrun=0;
		return;
	}
	printrep("0\nOK\n",(int)EINVAL);
}

void ResMgrTest::process_command_crc_part(const unsigned char *data,unsigned int count)
{
	if(!crcrun)return;
	dfunc->crc_progress(crcrun,data,count);
}

void ResMgrTest::process_command_crc_stop()
{
	if(crcrun)
	{
		printrep("%d\nCrc run still not completed.\n",(int)EINVAL);
		return;
	}
	printrep("0\n0x%08X\n",CRCresult);
}

void ResMgrTest::process_command_ping(const std::vector<std::string> *args)
{
	printrep("%d\nnot implemented\n",(int)EINVAL);
}


void ResMgrTest::process_command_quit()
{
	if(!allow_commandQuit)
	{
		printrep("%d\nQuit command forbidden through config.\n",EPERM);
		return;
	}
	printrep("0\n"); // the client will not be able to pick this up in time...
	line_to_logfile("client command 'quit' received.\n");
	raise(SIGINT);
}

// called from timer-callback of the delay command.
void ResMgrTest::cbfunc(int value)
{
	if(value!=0x07C007EC)
		return;
	delay_percent += 10;
	if(delay_percent>=100)
	{
		timer_delete((timer_t)delay_timer);
		delay_timer=-1;
		if(delay_block_client)	// call mark-finished, but only if client was left blocking.
			mark_process_finished("0\n100\n");
		else
			send_notification("progress","100%");
	}else{
		// notify about progress.
		char msg[16];
		snprintf(msg,sizeof(msg),"%u%%",(unsigned int)delay_percent);
		send_notification("progress",msg);
	}
}




static bool split(const char *argstr,std::vector<std::string> *items)
{
	items->clear();
	const char *r = argstr;

	if(!r)return false;

	while(true)
	{
		while( *r==' ' || *r=='\t' || *r=='\n' || *r=='\r' )
			{r++;}	// skip any whitespace
		// get string. quoted or unquoted, whatever.
		if(!*r)break;	// if end of input, exit loop.
		if(*r=='\"')
		{
			char quotstrbuf[0x200];
			if(!tdi__unquote_string(&r,quotstrbuf,sizeof(quotstrbuf)))
				return false;
			items->push_back(quotstrbuf);
		}else{
			const char *r2=r;
			while( *r2 && *r2!=' ' && *r2!='\t' && *r2!='\n' && *r2!='\r' )
				r2++;
			items->push_back(std::string(r,r2-r));
			r=r2;
		}
	}
	return true;
}
