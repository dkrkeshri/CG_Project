from cv2 import VideoCapture,imwrite


def capture_camera_screenshot(build_id):
    cam_port = 0
    cam = VideoCapture(cam_port)

    # reading the input using the camera
    result, image = cam.read()
    result, image = cam.read()
    # If image will detected without any error,
    # show result
    if result:
        # saving image in local storage
        imwrite(f"{build_id}.png", image)
    else:
        print("camera capture failed")
