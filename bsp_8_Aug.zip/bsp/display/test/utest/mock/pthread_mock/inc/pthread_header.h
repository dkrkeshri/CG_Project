#ifndef __H_PTHREAD_HEADER_H__
#define __H_PTHREAD_HEADER_H__
#include "input_utest_header.h"

#ifdef PTHREAD_EXPLICIT_SCHED
#undef PTHREAD_EXPLICIT_SCHED
#endif
#define PTHREAD_EXPLICIT_SCHED 1
#ifdef PTHREAD_CREATE_JOINABLE
#undef PTHREAD_CREATE_JOINABLE
#endif
#define PTHREAD_CREATE_JOINABLE (1)
#define PTHREAD_JOIN_VALUE_FAIL -1
#define pthread_attr_setschedparam setschedparam
#define pthread_getschedparam getschedparam

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
int pthread_create(pthread_t *thr, const pthread_attr_t *attr, void *(*start_routine) (void *), void *arg);
int pthread_join(pthread_t thread, void **retval);
int pthread_cancel(pthread_t thread);
void pthread_exit(void *value_ptr);
int pthread_attr_init(pthread_attr_t * attr);
int getschedparam(pthread_t t, int *policy, sched_param_t *param);
pthread_t pthread_self(void);
int pthread_attr_setinheritsched(pthread_attr_t *attr, int param);
int pthread_attr_setdetachstate(pthread_attr_t * attr, int val);
int setschedparam(pthread_attr_t* thread_attr, sched_param_t *priority);
int pthread_setname_np(pthread_t tid, const char* newname);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_PTHREAD_HEADER_H__*/
