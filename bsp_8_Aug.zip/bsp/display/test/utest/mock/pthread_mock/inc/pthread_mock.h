#ifndef __H_PTHREAD_MOCK_H__
#define __H_PTHREAD_MOCK_H__

#include <gmock/gmock.h>
#include "pthread_header.h"

class UT_pthread_mock
{
    public:
        UT_pthread_mock() {}
        virtual ~UT_pthread_mock() {}
        MOCK_METHOD4(pthread_create, int(pthread_t *, const pthread_attr_t *, void *(*) (void *), void *));
        MOCK_METHOD2(pthread_join, int(pthread_t, void **));
        MOCK_METHOD1(pthread_cancel, int(pthread_t));
        MOCK_METHOD1(pthread_exit, void(void *));
        MOCK_METHOD1(pthread_attr_init, int(pthread_attr_t *));
        MOCK_METHOD3(getschedparam,int(pthread_t,int *,sched_param_t *));
        MOCK_METHOD2(pthread_attr_setinheritsched,int(pthread_attr_t *,int));
        MOCK_METHOD2(pthread_attr_setdetachstate,int(pthread_attr_t *,int));
        MOCK_METHOD2(setschedparam, int(pthread_attr_t*, sched_param_t *));
        MOCK_METHOD2(pthread_setname_np, int(pthread_t,const char*));
};

extern UT_pthread_mock *ut_pthread_mock_ptr;

#endif /*__H_PTHREAD_MOCK_H__*/
