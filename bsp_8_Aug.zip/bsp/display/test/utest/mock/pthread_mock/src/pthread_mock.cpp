#include "pthread_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_pthread_mock *ut_pthread_mock_ptr;

int pthread_create(pthread_t *thr, const pthread_attr_t *attr, void *(*start_routine) (void *), void *arg)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_create(thr, attr, start_routine, arg);
}

int pthread_join(pthread_t thread, void **retval)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_join(thread, retval);
}

int pthread_cancel(pthread_t thread)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_cancel(thread);
}

void pthread_exit(void *value_ptr)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr-> pthread_exit(value_ptr);
}

int pthread_attr_init(pthread_attr_t *attr)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_attr_init(attr);
}

int getschedparam(pthread_t t, int *policy, sched_param_t *param)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->getschedparam(t,policy,param);
}

int pthread_attr_setinheritsched(pthread_attr_t *attr, int inheritsched)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_attr_setinheritsched(attr,inheritsched);
}

int pthread_attr_setdetachstate(pthread_attr_t *attr, int val)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_attr_setdetachstate(attr, val);
}

int setschedparam(pthread_attr_t *attr, sched_param_t *param)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->setschedparam(attr, param);
}

int pthread_setname_np(pthread_t tid, const char* newname)
{
    if (NULL == ut_pthread_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_pthread_mock_ptr->pthread_setname_np(tid, newname);
}
