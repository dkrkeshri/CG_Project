#ifndef __H_IPC_MOCK_H__
#define __H_IPC_MOCK_H__

#include <gmock/gmock.h>
#include "ipc_header.h"

class UT_ipc_mock
{
    public:
        UT_ipc_mock() {}
        virtual ~UT_ipc_mock() {}
        MOCK_METHOD4(MsgReceivePulse, int (int, void *, size_t , _msg_info *));
        MOCK_METHOD1(ChannelCreate, int (unsigned));
        MOCK_METHOD1(ChannelDestroy, int (int));
        MOCK_METHOD5(ConnectAttach, int (unsigned, pid_t, int, unsigned, int));
        MOCK_METHOD1(ConnectDetach, int (int));
        MOCK_METHOD3(name_attach, name_attach_t * (dispatch_t *, const char *, unsigned ));
        MOCK_METHOD2(name_detach, int(name_attach_t * attach,unsigned flags ));
        MOCK_METHOD2(name_open, int (const char *, int));
        MOCK_METHOD1(name_close, int (int));
        MOCK_METHOD4(MsgReceive, int (int, void *, int, struct _msg_info * ));
        MOCK_METHOD4(MsgReply, int (int, int, const void*, int ));
        MOCK_METHOD5(MsgSend,  int (int,const void*,int,void*,int));
        MOCK_METHOD4(MsgSendPulse, int (int, int, int, int));
        MOCK_METHOD4(mq_open, int(const char*, int, int, struct mq_attr*));
        MOCK_METHOD1(mq_close, int(mqd_t));
        MOCK_METHOD1(mq_unlink, int(const char *));
        MOCK_METHOD0(siginit, int());
        MOCK_METHOD2(MsgDeliverEvent, int(int, const struct sigevent*));
        MOCK_METHOD2(MsgError, int(int, int));
        MOCK_METHOD4(mq_send, int(mqd_t, const char *, size_t, unsigned int));
        MOCK_METHOD5(mq_timedsend, int(mqd_t, const char *, size_t, unsigned int, const struct timespec *));
        MOCK_METHOD4(mq_receive, int(mqd_t, char *, size_t, unsigned int*));
        MOCK_METHOD5(mq_timedreceive, int(mqd_t, char *, size_t, unsigned int*, const struct timespec *));
        MOCK_METHOD2(mq_getattr, int(mqd_t, struct mq_attr *));
        MOCK_METHOD5(MsgSendv_r, int(int, const iov_t*, int, const iov_t*, int));
        MOCK_METHOD3(SETIOV, void(iov_t*, void*, size_t));
        MOCK_METHOD4(iofunc_func_init,void(unsigned, resmgr_connect_funcs_t *, unsigned, resmgr_io_funcs_t *));
				MOCK_METHOD2(iofunc_mount_init, int (IOFUNC_MOUNT_T *, const size_t ));
				MOCK_METHOD5(iofunc_attr_init_sized, void(iofunc_attr_t *, mode_t , iofunc_attr_t *, struct _client_info *, size_t ));
				MOCK_METHOD4(iofunc_read_verify, int(resmgr_context_t *, io_read_t *, iofunc_ocb_t *, int *));
				MOCK_METHOD4(iofunc_write_verify, int(resmgr_context_t *, io_write_t *, iofunc_ocb_t *, int *));
				MOCK_METHOD4(iofunc_notify_trigger_strict, void(resmgr_context_t *, iofunc_notify_t *, int , int ));
				MOCK_METHOD6(iofunc_notify, int(resmgr_context_t *, io_notify_t *, iofunc_notify_t *, int , const int *, int *));
				MOCK_METHOD3(iofunc_notify_trigger, void(iofunc_notify_t *, int , int ));
				MOCK_METHOD4(iofunc_open_default, int(resmgr_context_t* , io_open_t* , iofunc_attr_t* , void* ));
				MOCK_METHOD8(resmgr_attach, int(dispatch_t *, resmgr_attr_t *, const char *, const enum _file_type , unsigned ,const resmgr_connect_funcs_t *, const resmgr_io_funcs_t *, RESMGR_HANDLE_T *));
				MOCK_METHOD3(resmgr_detach, int(dispatch_t *, int , unsigned ));
				MOCK_METHOD4(resmgr_msgread, ssize_t(resmgr_context_t *, void *, size_t , size_t ));
				MOCK_METHOD1(resmgr_ocb, void*(resmgr_context_t* ));
				MOCK_METHOD2(iofunc_notify_remove, void(resmgr_context_t *, iofunc_notify_t *));
				MOCK_METHOD3(iofunc_close_dup_default, int(resmgr_context_t *, io_close_t *, iofunc_ocb_t *));
				
				
				MOCK_METHOD1(dispatch_context_alloc, dispatch_context_t *(dispatch_t *));
				MOCK_METHOD1(dispatch_block, dispatch_context_t *(dispatch_context_t *));
				MOCK_METHOD1(dispatch_handler, int(dispatch_context_t *));
				MOCK_METHOD1(dispatch_context_free, void(dispatch_context_t *));
				MOCK_METHOD0(dispatch_create, dispatch_t	*());
				MOCK_METHOD2(message_connect, int(dispatch_t *, int ));
				MOCK_METHOD4(MsgSendPulse_r, int(int , int , int , int  ));
				MOCK_METHOD1(ConnectDetach_r, int(int ));
				MOCK_METHOD5(pulse_attach, int(dispatch_t *, int , int ,int(*), void *));
				MOCK_METHOD3(pulse_detach, int(dispatch_t *, int , int ));
				MOCK_METHOD1(dispatch_destroy, int(dispatch_t *));
				MOCK_METHOD1(ChannelDestroy_r, int(int ));
				MOCK_METHOD1(ChannelCreate_r, int(unsigned ));
				MOCK_METHOD5(ConnectAttach_r, int(unsigned , pid_t , int , unsigned , int ));
				MOCK_METHOD4(MsgReceivePulse_r, int(int , void* , int , _msg_info* ));
				MOCK_METHOD5(MsgSend_r, long(int , const void *, int , void *, int ));
};

extern UT_ipc_mock *ut_ipc_mock_ptr;

#endif /*__H_IPC_MOCK_H__*/
