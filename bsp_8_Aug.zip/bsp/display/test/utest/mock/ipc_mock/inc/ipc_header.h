#ifndef __H_IPC_HEADER_H__
#define __H_IPC_HEADER_H__

#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <sys/mount.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/types.h>
#include <inttypes.h>
#include <sys/stat.h>
#include <limits.h>
//typedef _Sizet int
//typedef int					_Sizet

#ifndef THREAD_POOL_HANDLE_T
# define THREAD_POOL_HANDLE_T	dispatch_t
#endif
#if 0
#define __IOVEC_T \
	struct iovec { \
		void *iov_base; \
		_Sizet iov_len; \
	}
	
#if defined(__IOVEC_T)
typedef __IOVEC_T	iov_t;
# undef __IOVEC_T
#endif
#endif

//#define _S_IFCHR    0x2000              /*  Character special               */
//# define S_IFCHR     _S_IFCHR           /*  Character special            */
//#define INT_MAX 2147483647
#define _NOTIFY_COND_INPUT		0x10000000	/* Data is available */
#define MSG_FLAG_ALLOC_PULSE	0x00000002
#define _NOTIFY_COND_OUTPUT		0x20000000	/* Room for more output */
#define _IO_SET_WRITE_NBYTES(_c, _s)	_RESMGR_STATUS(_c, _s)
#define _RESMGR_NPARTS(_num)	(-(_num))				/* Reply with this many parts from ctp->iov */
#define IOFUNC_ATTR_ATIME         0x00000002  /* File read -- atime invalid */
#define _RESMGR_STATUS(_c,_s)	((_c)->status = (_s))
#define _IO_SET_READ_NBYTES(_c, _s)	_RESMGR_STATUS(_c, _s)
#define _RESMGR_NOREPLY			(int)((~0U ^ (~0U >> 1U)) | 0U)	/* Do not reply to sender (could use _RESMGR_AGAIN later) */
#define _RESMGR_DETACH_ALL		0x0000	/* Detach the name from the namespace and invalidate all open bindings. */
#define _RESMGR_FLAG_BEFORE		0x0001	/* Force path to be resolved before others at the same mountpoint. */
#define ND_LOCAL_NODE 0
#define _NTO_SIDE_CHANNEL 0x40000000
#define _NTO_COF_NOEVENT		0x0800
#define _IO_MAX 0x1FF /* value taken from QNX's sys/iomsg.h */
#define _IO_WRITE_GET_NBYTES(msg) ((msg)->i.nbytes)
#define _IO_READ_GET_NBYTES(msg) ((msg)->i.nbytes)
#define _PULSE_CODE_MINAVAIL 0
#define _PULSE_CODE_MAXAVAIL 127
#define _RESMGR_DEFAULT 1
#define IOFUNC_NOTIFY_INPUT		0
#define IOFUNC_NOTIFY_OUTPUT	1
#define IOFUNC_NOTIFY_OBAND		2

#define GTEST_MODULE_SYSTEM_STATE_INJECTOR "SYSTEM_STATE_INJECTOR"
#define _PULSE_CODE_DISCONNECT (-33) /* Took the value from qnx/neutrino.h */

#define _RESMGR_CONNECT_NFUNCS  1
#define _RESMGR_IO_NFUNCS  1
#define S_IFNAM  0x5000
#define _IOMGR_PRIVATE_BASE  0xf000

#define _IO_MSG  0x113
#define SIGEV_INTR                       6
#define SIGEV_INTR_INIT(__e) \
((__e)->sigev_notify = SIGEV_INTR)

#define IOFUNC_NOTIFY_INPUT_CHECK(__nop, __cnt, __tran)	\
	((__nop)[IOFUNC_NOTIFY_INPUT].cnt <= (__cnt) && ((__nop)[IOFUNC_NOTIFY_INPUT].cnt || (__tran)))
	
enum _file_type
{
   _FTYPE_ANY = 0
};

struct _io_connect
{
   uint16_t path_len;
   uint8_t extra_type;
   uint16_t extra_len;
   char path[1];
};
typedef struct {
    uint32_t addr;   /* I2C address */
    uint32_t fmt;    /* I2C_ADDRFMT_7BIT or I2C_ADDRFMT_10BIT */
} i2c_addr_t;

typedef struct iovec_stub
{
   void *iov_base;
   size_t iov_len;
} iov_t;

typedef struct _msg_info
{
   uint32_t nd;
   uint32_t srcnd;
   int32_t chid;
   int32_t pid;
   int32_t scoid;
   int32_t coid;
   int32_t msglen;
   int32_t srcmsglen;
   int32_t dstmsglen;
   int16_t priority;
   int16_t flags;
   uint32_t reserved;
}_msg_info;

struct _io_connect_link_reply
{
   uint32_t reserved1[2];
   uint8_t eflag;
   uint8_t reserved2[3];
   uint32_t umask;
   uint16_t nentries;
   uint16_t path_len;
};

typedef struct _iofunc_funcs iofunc_funcs_t;

typedef struct _iofunc_mount
{
   uint32_t flags;
   uint32_t conf;
   dev_t dev;
   int32_t blocksize;
   iofunc_funcs_t *funcs;
   void *power;
} iofunc_mount_t;

#define IOFUNC_MOUNT_T iofunc_mount_t

typedef struct _iofunc_attr
{
   IOFUNC_MOUNT_T *mount;
   uint32_t flags;
   int32_t lock_tid;
   uint16_t lock_count;
   uint16_t count;
   uint16_t rcount;
   uint16_t wcount;
   uint16_t rlocks;
   int32_t nbytes;
   uint16_t wlocks;
   struct _iofunc_mmap_list *mmap_list;
   struct _iofunc_lock_list *lock_list;
   void *list;
   uint32_t list_size;
} iofunc_attr_t;

#define IOFUNC_ATTR_T iofunc_attr_t

typedef struct _iofunc_ocb
{
   IOFUNC_ATTR_T *attr;
   int32_t ioflag;
     int32_t nbytes;
   uint16_t sflag;
   uint16_t flags;
   void *reserved;
   int32_t offset;
} iofunc_ocb_t;

#define IOFUNC_OCB_T iofunc_ocb_t

#define IOFUNC_ATTR_T iofunc_attr_t
typedef struct value 
{
	int sival_int;
}value_t;
typedef struct pulse 
{
	value_t value;
	
}pulse_t;
typedef struct msg 
{
	pulse_t pulse;
	
}msg_t;
typedef struct _resmgr_context
{
   int rcvid;
   struct _msg_info info;
   int id;
   int reserved;
   int status;
   int offset;
   int size;
   msg_t *msg;
   //__FLEXARY(iov_t, iov); /* iov_t iov[] */
   iov_t iov[];
} resmgr_context_t;

struct _io_notify {
	uint16_t                    type;
	uint16_t                    combine_len;
	int32_t                     action;
	int32_t                     flags;
	struct sigevent             event;

	/* Following fields only valid if (flags & _NOTIFY_COND_EXTEN) */
	int32_t                     mgr[2];    /* For use by manager */
	int32_t                     flags_extra_mask;
	int32_t                     flags_exten;
	int32_t                     nfds;
	int32_t                     fd_first;
	int32_t                     nfds_ready;
	int64_t                     timo;
	/* struct pollfd            fds[nfds]; */
};

struct _io_notify_reply {
	uint32_t                    zero;
	uint32_t                    flags;   /* action above */
	int32_t                     flags2;  /* flags above */
	struct sigevent             event;

	/* Following fields only updated by new managers (if valid) */
	int32_t                     mgr[2];    /* For use by manager */
	int32_t                     flags_extra_mask;
	int32_t                     flags_exten;
	int32_t                     nfds;
	int32_t                     fd_first;
	int32_t                     nfds_ready;
	int64_t                     timo;
	/* struct pollfd            fds[nfds]; */
};

typedef union {
	struct _io_notify           i;
	struct _io_notify_reply     o;
} io_notify_t;

typedef union _resmgr_iomsgs {
	unsigned short				type;
	io_notify_t					notify;
    #if 0
	//io_pulse_t					pulse;

	//struct _io_connect			connect;
	io_open_t					open;
	io_unlink_t					unlink;
	io_rename_t					rename;
	io_mknod_t					mknod;
	io_readlink_t				readlink;
	io_link_t					link;
	io_mount_t					mount;

	//struct _io_combine			combine;
	io_close_t					close;
	io_write_t					write;
	io_read_t					read;
	io_stat_t					stat;
	io_notify_t					notify;
	io_devctl_t					devctl;
	io_pathconf_t				pathconf;
	io_lseek_t					lseek;
	io_chmod_t					chmod;
	io_chown_t					chown;
	io_utime_t					utime;
	io_openfd_t					openfd;
	io_fdinfo_t					fdinfo;
	io_lock_t					lock;
	io_space_t					space;
	io_shutdown_t				shutdown;
	io_msg_t					msg;
	io_mmap_t					mmap;
	io_dup_t					dup;
	io_sync_t					sync;
	io_power_t					power;
	io_acl_t					acl;
	#endif
} resmgr_iomsgs_t;

typedef struct _select_context	select_context_t;
struct _select_context {
	int							rcvid;
	union {
		struct _msg_info		msginfo;
		siginfo_t				siginfo;
	} info;
	resmgr_iomsgs_t				*msg;
	void						*dpp;
	int							fd;
	unsigned					tid;
	unsigned					reserved;
	int							flags;
	int							reserved2[2];
	//__FLEXARY(iov_t, iov); /* iov_t iov[] */
	iov_t iov[];
};
#define _RESMGR_PTR(_h, _p, _n)         (SETIOV((_h)->iov + 0, (_p), (_n)),     \
                                          _RESMGR_NPARTS(1))
#define _DEVCTL_DATA(msg)			((void *)(sizeof(msg) + (char *)(&msg)))
typedef struct {
    int len;    /* length of data to send/recv, in bytes
                        (not including this header) */
    int stop;   /* send stop when complete? (0=no, 1=yes) */
} i2c_masterhdr_t;
typedef struct {
    i2c_addr_t slave;  /* slave address */
    int   len;    /* length of send data in bytes */
    int   stop;   /* send stop when complete? (0=no, 1=yes) */
} i2c_send_t;
typedef struct {
    i2c_addr_t slave;  /* slave address */
    int   len;    /* length of receive data in bytes */
    int   stop;   /* send stop when complete? (0=no, 1=yes) */
} i2c_recv_t;
typedef struct {
    i2c_addr_t slave;      /* slave address */
    int   send_len;   /* length of send data in bytes */
    int   recv_len;   /* length of receive data in bytes */
    int   stop;       /* set stop when complete? */
} i2c_sendrecv_t;

typedef struct _sigwait_context	sigwait_context_t;

struct _sigwait_context {
	int							signo;
	union {
		struct _msg_info		msginfo;
		siginfo_t				siginfo;
	} info;
	resmgr_iomsgs_t				*msg;
	void 						*dpp;
	int							status;
	unsigned					tid;
	sigset_t					set;
	int							reserved2[2];
	//__FLEXARY(iov_t, iov); /* iov_t iov[] */
	iov_t iov[];
};

struct _iofunc_funcs
{
   unsigned nfuncs;IOFUNC_OCB_T *(*ocb_calloc)(resmgr_context_t *ctp, IOFUNC_ATTR_T *attr);
   void (*ocb_free)(IOFUNC_OCB_T *ocb);
   int (*attr_lock)(IOFUNC_ATTR_T *attr);
   int (*attr_unlock)(IOFUNC_ATTR_T *attr);
   int (*attr_trylock)(IOFUNC_ATTR_T *attr);
};

#define RESMGR_HANDLE_T struct _iofunc_attr
#define RESMGR_OCB_T  struct _iofunc_ocb
#define IOFUNC_ATTR_CTIME 0x00000004
#define IOFUNC_ATTR_MTIME 0x00000001

typedef union
{
   struct _io_connect connect;
   struct _io_connect_link_reply link_reply;
} io_open_t;

struct _io_write
{
   uint16_t type;
   uint16_t combine_len;
   int32_t nbytes;
   uint32_t xtype;
};

typedef union
{
   struct _io_write i;
} io_write_t;

struct _io_read
{
   uint16_t type;
   uint16_t combine_len;
   int32_t nbytes;
   uint32_t xtype;
};

typedef union
{
   struct _io_read i;
} io_read_t;



typedef struct _iofunc_notify_event {
    struct _iofunc_notify_event *next;
    int                         rcvid;
    int                         scoid;
    int                         cnt;
    struct sigevent             event;
} iofunc_notify_event_t;

typedef struct _iofunc_notify {
    int                         cnt;
    struct _iofunc_notify_event *list;
} iofunc_notify_t;

 struct _io_devctl
{
   uint16_t type;
   uint16_t combine_len;
   int32_t dcmd;
   int32_t nbytes;
   int32_t zero;
};

struct _io_devctl_reply
{
   uint32_t zero;
   int32_t ret_val;
   int32_t nbytes;
   int32_t zero2;
};

typedef union
{
   struct _io_devctl i;
   struct _io_devctl_reply o;
} io_devctl_t;

typedef union
{
   struct _io_connect connect;
   struct _io_connect_link_reply link_reply;
} io_type_t;

struct _io_msg
{
   uint16_t type;
   uint16_t combine_len;
   uint16_t mgrid;
   uint16_t subtype;
};

typedef union
{
   struct _io_msg i;
} io_msg_t;

struct _io_close
{
   uint16_t type;
   uint16_t combine_len;
};

typedef union
{
   struct _io_close i;
} io_close_t;

typedef struct _resmgr_attr
{
   uint32_t flags;
   uint32_t nparts_max;
   uint32_t msg_max_size;
   int32_t (*other_func)(resmgr_context_t *ctp, void *msg);
} resmgr_attr_t;

typedef struct _resmgr_connect_funcs
{
   uint32_t nfuncs;
   int32_t (*open)(resmgr_context_t *ctp, io_open_t *msg,
   RESMGR_HANDLE_T *handle, void *extra);
   int32_t (*unlink)(resmgr_context_t *ctp, io_type_t *msg,
   RESMGR_HANDLE_T *handle, void *reserved);
   int32_t (*mknod)(resmgr_context_t *ctp, io_type_t *msg,
   RESMGR_HANDLE_T *handle, void *reserved);
   int32_t (*readlink)(resmgr_context_t *ctp, io_type_t *msg,
   RESMGR_HANDLE_T *handle, void *reserved);
} resmgr_connect_funcs_t;

typedef struct _resmgr_io_funcs
{
   uint32_t nfuncs;
   int32_t (*read)(resmgr_context_t *ctp, io_read_t *msg,
   RESMGR_OCB_T *ocb);
   int (*write)(resmgr_context_t *ctp, io_write_t* msg,
   RESMGR_OCB_T *ocb);
   int (*write64)(resmgr_context_t *ctp, io_write_t* msg,
   RESMGR_OCB_T *ocb);
   int32_t (*devctl)(resmgr_context_t *ctp, io_devctl_t *msg,
   RESMGR_OCB_T *ocb);
   int32_t (*close_ocb)(resmgr_context_t *ctp, void *reserved,
   RESMGR_OCB_T *ocb);
   int32_t (*openfd)(resmgr_context_t *ctp, void *msg,
   RESMGR_OCB_T *ocb);
   int32_t (*mmap)(resmgr_context_t *ctp, void *msg,
   RESMGR_OCB_T *ocb);
   int32_t (*sync)(resmgr_context_t *ctp, void *msg,
   RESMGR_OCB_T *ocb);
   int32_t (*msg)(resmgr_context_t *ctp, io_msg_t *msg,
   RESMGR_OCB_T *ocb);
   int32_t (*close_dup)(resmgr_context_t *ctp, io_close_t *msg,
   RESMGR_OCB_T *ocb);
   int (*notify)(resmgr_context_t *ctp, io_notify_t *msg, RESMGR_OCB_T *ocb);
} resmgr_io_funcs_t;

struct _dispatch
{
   int (*other_func)(resmgr_context_t *ctp, void *msg);
   unsigned nparts_max;
   unsigned msg_max_size;
   int block_type;
   struct timespec timeout;
   unsigned int flags;
   int chid;
   unsigned int context_size;
};

typedef struct _dispatch dispatch_t;

#define _IOFUNC_NFUNCS ((sizeof(iofunc_funcs_t)-sizeof(unsigned))/sizeof(void*))

typedef int mqd_t;

typedef struct _name_attach
{
   dispatch_t* dpp;
   int chid;
   int mntid;
   int zero[2];
} name_attach_t;
/*
struct _pulse
{
   unsigned int type;
   unsigned int subtype;
   int code;
   unsigned int zero[3];
   union sigval value;
   int scoid;
};*/

typedef struct
{
   uint32_t mode;
   uint32_t clock_rate;
} spi_cfg_t;

typedef struct
{
   uint32_t device; /* Device ID */
   char name[16]; /* Device description */
   spi_cfg_t cfg; /* Device configuration */
} spi_devinfo_t;

typedef struct
{
   uint32_t version;
   char name[16]; /* Driver name */
   uint32_t feature;
} spi_drvinfo_t;

struct mq_attr
{
   __syscall_slong_t mq_flags; /* Message queue flags.  */
   __syscall_slong_t mq_maxmsg; /* Maximum number of messages.  */
   __syscall_slong_t mq_msgsize; /* Maximum message size.  */
   __syscall_slong_t mq_curmsgs; /* Number of messages currently queued.  */
   __syscall_slong_t  __pad [4];
};

/*typedef struct iovec_stub
{
   void *iov_base;
   size_t iov_len;
} iov_t;*/

enum _io__Uint16types
{
   _IO_READ, _IO_WRITE, _IO_RSVD_CLOSE_OCB, _IO_STAT, _IO_NOTIFY, _IO_DEVCTL
};

struct ifdrv
{
   char ifd_name[IFNAMSIZ];
   unsigned long ifd_cmd;
   size_t ifd_len;
   void *ifd_data;
};

#define IOCPARM_MASK 0x3fffu
#define IOCPARM_LEN(x) (((x) >> 16) & IOCPARM_MASK)
#define SIOCSIFGENERIC _IOW('i', 57, struct ifreq)
#define SIOCGIFGENERIC _IOWR('i', 58, struct ifreq)
#define SIOCSETVLAN SIOCSIFGENERIC
#define SIOCGETVLAN SIOCGIFGENERIC
#define SIOCIFCREATE _IOW('i', 122, struct ifreq)
#define SIOCSDRVSPEC _IOW('i', 123, struct ifdrv)
#define SIOCGETVLANPRIO _IOWR('i', 144, struct ifreq)
#define SIOCSETVLANPRIO  _IOW('i', 143, struct ifreq)
#define SIOCDIFADDR_IN6 44
#define _MFLAG_OCB 0x80000000

struct vlanreq
{
   char vlr_parent[IFNAMSIZ];
   unsigned short vlr_tag;
};

struct sockaddr_in_
{
   uint8_t sin_len;
   sa_family_t sin_family;
   in_port_t sin_port;
   struct in_addr sin_addr;
   int8_t sin_zero[8];
};

struct in_aliasreq
{
   char ifra_name[IFNAMSIZ];
   struct sockaddr_in_ ifra_addr;
   struct sockaddr_in_ ifra_dstaddr;
#define ifra_broadaddr ifra_dstaddr
   struct sockaddr_in_ ifra_mask;
};

struct ifaliasreq
{
   char ifra_name[IFNAMSIZ];
   struct sockaddr ifra_addr;
   struct sockaddr ifra_dstaddr;
#define ifra_broadaddr ifra_dstaddr
   struct sockaddr ifra_mask;
};
#define SIOCAIFADDR _IOW('i', 26, struct ifaliasreq)

struct in6_addrlifetime
{
   time_t ia6t_expire;
   time_t ia6t_preferred;
   uint32_t ia6t_vltime;
   uint32_t ia6t_pltime;
};

struct in6_ifstat
{
   uint64_t ifs6_in_receive;
   uint64_t ifs6_in_hdrerr;
   uint64_t ifs6_in_toobig;
   uint64_t ifs6_in_noroute;
   uint64_t ifs6_in_addrerr;
   uint64_t ifs6_in_protounknown;
   uint64_t ifs6_in_truncated;
   uint64_t ifs6_in_discard;
   uint64_t ifs6_in_deliver;
   uint64_t ifs6_out_forward;
   uint64_t ifs6_out_request;
   uint64_t ifs6_out_discard;
   uint64_t ifs6_out_fragok;
   uint64_t ifs6_out_fragfail;
   uint64_t ifs6_out_fragcreat;
   uint64_t ifs6_reass_reqd;
   uint64_t ifs6_reass_ok;
   uint64_t ifs6_reass_fail;
   uint64_t ifs6_in_mcast;
   uint64_t ifs6_out_mcast;
};

struct icmp6_ifstat
{
   uint64_t ifs6_in_msg;
   uint64_t ifs6_in_error;
   uint64_t ifs6_in_dstunreach;
   uint64_t ifs6_in_adminprohib;
   uint64_t ifs6_in_timeexceed;
   uint64_t ifs6_in_paramprob;
   uint64_t ifs6_in_pkttoobig;
   uint64_t ifs6_in_echo;
   uint64_t ifs6_in_echoreply;
   uint64_t ifs6_in_routersolicit;
   uint64_t ifs6_in_routeradvert;
   uint64_t ifs6_in_neighborsolicit;
   uint64_t ifs6_in_neighboradvert;
   uint64_t ifs6_in_redirect;
   uint64_t ifs6_in_mldquery;
   uint64_t ifs6_in_mldreport;
   uint64_t ifs6_in_mlddone;
   uint64_t ifs6_out_msg;
   uint64_t ifs6_out_error;
   uint64_t ifs6_out_dstunreach;
   uint64_t ifs6_out_adminprohib;
   uint64_t ifs6_out_timeexceed;
   uint64_t ifs6_out_paramprob;
   uint64_t ifs6_out_pkttoobig;
   uint64_t ifs6_out_echo;
   uint64_t ifs6_out_echoreply;
   uint64_t ifs6_out_routersolicit;
   uint64_t ifs6_out_routeradvert;
   uint64_t ifs6_out_neighborsolicit;
   uint64_t ifs6_out_neighboradvert;
   uint64_t ifs6_out_redirect;
   uint64_t ifs6_out_mldquery;
   uint64_t ifs6_out_mldreport;
   uint64_t ifs6_out_mlddone;
};

struct in6_ifreq
{
   char ifr_name_[IFNAMSIZ]; /* renamed from ifr_name to ifr_name_ to avoid conflict in declaration */
   union
   {
      struct sockaddr_in6 ifru_addr;
      struct sockaddr_in6 ifru_dstaddr;
      short ifru_flags;
      int ifru_flags6;
      int ifru_metric;
      caddr_t ifru_data;
      struct in6_addrlifetime ifru_lifetime;
      struct in6_ifstat ifru_stat;
      struct icmp6_ifstat ifru_icmp6stat;
   } ifr_ifru;
};

typedef struct _resmgr_context	message_context_t;

typedef union _dispatch_context {
	resmgr_context_t		resmgr_context;
	message_context_t		message_context;
	select_context_t		select_context;
	sigwait_context_t		sigwait_context;
} dispatch_context_t;
dispatch_context_t 		*dispatch_context_alloc(dispatch_t *dpp);

#define IOFUNC_NOTIFY_INIT(__nop) \
	((__nop)[0].cnt = (__nop)[1].cnt = (__nop)[2].cnt = (~0u) >> 1, \
	 (__nop)[0].list = (__nop)[1].list = (__nop)[2].list = NULL)


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int MsgReceivePulse(int chid, void *pulse, size_t bytes, _msg_info *info);
int ChannelCreate(unsigned flags);
int ChannelDestroy(int chid);
int ConnectAttach(unsigned nd, pid_t pid, int chid, unsigned index, int flags);
int ConnectDetach(int coid);
name_attach_t * name_attach ( dispatch_t * dpp,const char * path,unsigned flags );
int name_detach(name_attach_t * attach,unsigned flags );
int name_open(const char * name, int flags);
int MsgReceive( int chid,void * msg,int bytes,_msg_info * info );
int MsgReply( int rcvid,int status,const void* msg,int size );
int MsgSend(int coid,const void* smsg,int sbytes,void* rmsg,int rbytes);
int MsgSendPulse(int coid, int priority, int code, int value);
int mq_open(const char* name,int flag, int permission, struct mq_attr* attr);
int mq_close(mqd_t mqdes);
int mq_unlink(const char *name);
int MsgDeliverEvent(int rcvid, const struct sigevent* event);
int MsgError(int rcvid, int error);
int mq_send(mqd_t mqdes, const char *msg_ptr, size_t msg_len, unsigned int msg_prio);
int mq_timedsend(mqd_t mqdes, const char * msg_ptr, size_t msg_len,
                                unsigned int msg_prio, const struct timespec * abs_timeout);
int mq_receive(mqd_t mqdes, char *msg_ptr, size_t msg_len, unsigned int *msg_prio);
int mq_timedreceive( mqd_t mqdes, char * msg_ptr, size_t msg_len,
                                unsigned int * msg_prio, const struct timespec * abs_timeout);
int mq_getattr(mqd_t mqdes, struct mq_attr *attr);
int name_close(int coid);
int MsgSendv_r(int coid, const iov_t* siov, int sparts, const iov_t* riov, int rparts);
void SETIOV(iov_t* msg, void* addr, size_t len);
void iofunc_func_init(unsigned __nconnect, resmgr_connect_funcs_t *__connect, unsigned __nio, resmgr_io_funcs_t *__io);
int iofunc_mount_init(IOFUNC_MOUNT_T *__mountp, const size_t __size);
int iofunc_read_verify(resmgr_context_t *__ctp, io_read_t *__msg, iofunc_ocb_t *__ocb, int *__nonblock);
int resmgr_attach(dispatch_t *dpp, resmgr_attr_t *attr, const char *path,
				  const enum _file_type file_type, unsigned flags,
				  const resmgr_connect_funcs_t *connect_funcs,
				  const resmgr_io_funcs_t *io_funcs, RESMGR_HANDLE_T *handle);
int resmgr_detach(dispatch_t *dpp, int id, unsigned flags);
void iofunc_attr_init_sized(iofunc_attr_t *__attr, mode_t __mode, iofunc_attr_t *__dattr, struct _client_info *__info, size_t __size);
extern void iofunc_attr_init(iofunc_attr_t *__attr, mode_t __mode, iofunc_attr_t *__dattr, struct _client_info *__info);
#define iofunc_attr_init(__attr, __mode, __dattr, __info)	(iofunc_attr_init_sized((__attr), (__mode), (__dattr), (__info), sizeof(iofunc_attr_t)))
int iofunc_write_verify(resmgr_context_t *__ctp, io_write_t *__msg, iofunc_ocb_t *__ocb, int *__nonblock);
void iofunc_notify_remove(resmgr_context_t *__ctp, iofunc_notify_t *__nop);
int iofunc_close_dup_default(resmgr_context_t *__ctp, io_close_t *__msg, iofunc_ocb_t *__ocb);
dispatch_context_t 		*dispatch_block(dispatch_context_t *ctp);
int 					dispatch_handler(dispatch_context_t *ctp);
void					dispatch_context_free(dispatch_context_t *ctp);
dispatch_t				*dispatch_create(void);
int message_connect(dispatch_t *dpp, int flags);
int MsgSendPulse_r(int __coid, int __priority, int __code, int  __value);
int ConnectDetach_r(int __coid);
int ChannelDestroy_r(int __chid);
long MsgSend_r(int __coid, const void *__smsg, int __sbytes, void *__rmsg, int __rbytes);
int ConnectAttach_r(unsigned nd, pid_t pid, int chid, unsigned index, int flags);
int MsgReceivePulse_r(int chid, void* pulse, int bytes, _msg_info* info);
ssize_t resmgr_msgread(resmgr_context_t *__ctp, void *__msg, size_t __size, size_t __offset);
void iofunc_notify_trigger_strict(resmgr_context_t *__ctp, iofunc_notify_t *__nop, int __cnt, int __index);
int iofunc_notify(resmgr_context_t *__ctp, io_notify_t *__msg, iofunc_notify_t *__nop, int __trig, const int *__notifycnts, int *__armed);
void iofunc_notify_trigger(iofunc_notify_t *__nop, int __cnt, int __index);
int ofunc_open_default(resmgr_context_t* ctp, io_open_t* msg, iofunc_attr_t* attr, void* extra);
int pulse_attach(dispatch_t *dpp, int flags, int code,
				 int (*func)(message_context_t *ctp, int code, unsigned flags, void *handle),
				 void *handle);
int pulse_detach(dispatch_t *dpp, int code, int flags);
int dispatch_destroy(dispatch_t *dpp);
int ChannelCreate_r(unsigned __flags);
void* resmgr_ocb(resmgr_context_t* ctp);
int iofunc_open_default(resmgr_context_t* ctp, io_open_t* msg, iofunc_attr_t* attr, void* extra);
int pulse_attach(dispatch_t *dpp, int flags, int code,
				 int (*func)(message_context_t *ctp, int code, unsigned flags, void *handle),
				 void *handle);
int hvac_resmgr_prepare_pulse_handler_dummy(message_context_t * ctp,int code,unsigned flags, void* handle);
int iofunc_devctl_default(resmgr_context_t *ctp, io_devctl_t *msg,
                          iofunc_ocb_t *ocb);
int slog2_reset( void );
int MsgReceive_r( int chid,
                  void * msg,
                  size_t bytes,
                  struct _msg_info * info );
int MsgReply_r( int rcvid,
                long status,
                const void* msg,
                size_t bytes );
int writeread(int key, uint16_t w_count, const void *w_buffer,uint16_t r_count, void *r_buffer);
int get_own_name(int key, char *out_value, int value_buffersize);
int get_extra_config(int key, const char *configitem_key, char *out_value,int value_buffersize);
//int write(int key, uint16_t count, const void *buffer);
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /*__H_IPC_HEADER_H__*/
