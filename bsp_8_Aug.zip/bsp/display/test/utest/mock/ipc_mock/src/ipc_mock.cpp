#include "ipc_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_ipc_mock *ut_ipc_mock_ptr;

/* wrapper for MsgReceivePulse */
int MsgReceivePulse(int chid, void *pulse, size_t bytes, _msg_info *info) {    
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->MsgReceivePulse(chid, pulse, bytes, info);
}
int slog2_reset( void )
{
    return 0;
}

/* wrapper for ChannelCreate */
int ChannelCreate(unsigned flags) {
    if (NULL == ut_ipc_mock_ptr) {
            //throw std::invalid_argument(NULL_PTR_ERR);
	    return 0;
        }
    return ut_ipc_mock_ptr->ChannelCreate(flags);
}

/* wrapper for ChannelDestroy */
int ChannelDestroy(int chid) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->ChannelDestroy(chid);
}

/* wrapper for ConnectAttach */
int ConnectAttach(unsigned nd, pid_t pid, int chid, unsigned index, int flags) {
    if (NULL == ut_ipc_mock_ptr) {
            //throw std::invalid_argument(NULL_PTR_ERR);
	    return -1;
        }
    return ut_ipc_mock_ptr->ConnectAttach(nd, pid, chid, index, flags);
}

/* wrapper for ConnectDetach */
int ConnectDetach(int coid) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->ConnectDetach(coid);
}

/*wrapper for name_attach*/
name_attach_t * name_attach (dispatch_t * dpp,const char * path,unsigned flags)  {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->name_attach ( dpp,path,flags );
}

/* wrapper for name_detach */
int name_detach(name_attach_t * attach,unsigned flags ){
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->name_detach(attach,flags );
}

/* wrapper for name_open */
int name_open(const char * name, int flags) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->name_open(name, flags);
}

/* wrapper for name_close */
int name_close(int coid) {
     if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->name_close(coid);
}

/*wrapper for MsgReceive*/
int MsgReceive(int chid,void * msg,int bytes,struct _msg_info * info) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->MsgReceive(chid, msg, bytes, info);
}

/*wrapper for MsgReply*/
int MsgReply(int rcvid,int status,const void* msg,int size) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->MsgReply(rcvid,status,msg,size);
}

/*wrapper for Msgsend*/
int MsgSend(int coid,const void* smsg,int sbytes,void* rmsg,int rbytes) {
    if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->MsgSend(coid,smsg,sbytes,rmsg,rbytes);
}

/* wrapper for MsgSendPulse */
int MsgSendPulse(int coid, int priority, int code, int value) {
	if (NULL == ut_ipc_mock_ptr) {
            //throw std::invalid_argument(NULL_PTR_ERR);
	    return 0;
        }
   return ut_ipc_mock_ptr->MsgSendPulse(coid, priority, code, value);
}

/* wrapper for mq_open */
int mq_open(const char* name, int flag, int permission, struct mq_attr* attr)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
   return ut_ipc_mock_ptr->mq_open(name, flag, permission, attr);
}

/* wrapper for mq_close */
int mq_close(mqd_t mqdes)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return mq_close(mqdes);
}

/* wrapper for mq_unlink */
int mq_unlink(const char *name)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_ipc_mock_ptr->mq_unlink(name);
}

/* wrapper for MsgDeliverEvent */
int MsgDeliverEvent(int rcvid, const struct sigevent* event)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->MsgDeliverEvent(rcvid, event);
}

/* wrapper for MsgError */
int MsgError(int rcvid, int error)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->MsgError(rcvid, error);
}

/* wrapper for mq_send */
int mq_send(mqd_t mqdes, const char *msg_ptr, size_t msg_len, unsigned int msg_prio)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->mq_send(mqdes, msg_ptr, msg_len, msg_prio);
}

/* wrapper for mq_timedsend */
int mq_timedsend(mqd_t mqdes, const char * msg_ptr, size_t msg_len, unsigned int msg_prio,
                                                   const struct timespec * abs_timeout)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->mq_timedsend(mqdes, msg_ptr, msg_len, msg_prio, abs_timeout);
}

/* wrapper for mq_receive */
int mq_receive(mqd_t mqdes, char *msg_ptr, size_t msg_len, unsigned int *msg_prio)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->mq_receive(mqdes, msg_ptr, msg_len, msg_prio);
}

/* wrapper for mq_timedreceive */
int mq_timedreceive( mqd_t mqdes, char * msg_ptr, size_t msg_len, unsigned int * msg_prio,
                                                    const struct timespec * abs_timeout)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->mq_timedreceive(mqdes, msg_ptr, msg_len, msg_prio, abs_timeout);
}

/* wrapper for mq_getattr */
int mq_getattr(mqd_t mqdes, struct mq_attr *attr)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->mq_getattr(mqdes, attr);
}

/* wrapper for MsgSendv_r */
int MsgSendv_r(int coid, const iov_t* siov, int sparts, const iov_t* riov, int rparts)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
	return ut_ipc_mock_ptr->MsgSendv_r(coid, siov, sparts, riov, rparts);
}

/* wrapper for SETIOV */
void SETIOV(iov_t* msg, void* addr, size_t len)
{
	if (NULL == ut_ipc_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_ipc_mock_ptr->SETIOV(msg, addr, len);
}

void iofunc_func_init(unsigned __nconnect, resmgr_connect_funcs_t *__connect, unsigned __nio, resmgr_io_funcs_t *__io)
{
    return ut_ipc_mock_ptr->iofunc_func_init(__nconnect, __connect, __nio, __io);
}

int iofunc_mount_init(IOFUNC_MOUNT_T *__mountp, const size_t __size)
{
    return ut_ipc_mock_ptr->iofunc_mount_init(__mountp, __size);
}

void iofunc_attr_init_sized(iofunc_attr_t *__attr, mode_t __mode, iofunc_attr_t *__dattr, struct _client_info *__info, size_t __size)
{
    return ut_ipc_mock_ptr->iofunc_attr_init_sized(__attr, __mode, __dattr, __info, __size);
}

int iofunc_read_verify(resmgr_context_t *__ctp, io_read_t *__msg, iofunc_ocb_t *__ocb, int *__nonblock)
{
    //return ut_ipc_mock_ptr->iofunc_read_verify(__ctp, __msg, __ocb, __nonblock); //changed due to segmentation fault
return 1;	
}

int iofunc_write_verify(resmgr_context_t *__ctp, io_write_t *__msg, iofunc_ocb_t *__ocb, int *__nonblock)
{
  //  return ut_ipc_mock_ptr->iofunc_write_verify(__ctp, __msg, __ocb, __nonblock);//changed due to segmentation fault
return 1;
}

void iofunc_notify_trigger_strict(resmgr_context_t *__ctp, iofunc_notify_t *__nop, int __cnt, int __index)
{
    return ut_ipc_mock_ptr->iofunc_notify_trigger_strict(__ctp, __nop, __cnt, __index);
}
int iofunc_notify(resmgr_context_t *__ctp, io_notify_t *__msg, iofunc_notify_t *__nop, int __trig, const int *__notifycnts, int *__armed)
{
   // return ut_ipc_mock_ptr->iofunc_notify(__ctp, __msg, __nop, __trig, __notifycnts, __armed);//changed due to segmentation fault
return 1;
}
void iofunc_notify_trigger(iofunc_notify_t *__nop, int __cnt, int __index)
{
    return ut_ipc_mock_ptr->iofunc_notify_trigger(__nop, __cnt,  __index);
}

int iofunc_open_default(resmgr_context_t* ctp, io_open_t* msg, iofunc_attr_t* attr, void* extra)
{
    //return ut_ipc_mock_ptr->iofunc_open_default(ctp, msg, attr, extra);
  return 1;
}

void iofunc_notify_remove(resmgr_context_t *__ctp, iofunc_notify_t *__nop)
{
   return ut_ipc_mock_ptr->iofunc_notify_remove(__ctp, __nop);
}

int iofunc_close_dup_default(resmgr_context_t *__ctp, io_close_t *__msg, iofunc_ocb_t *__ocb)
{
    return ut_ipc_mock_ptr->iofunc_close_dup_default(__ctp, __msg, __ocb);
}

int resmgr_attach(dispatch_t *dpp, resmgr_attr_t *attr, const char *path,
				  const enum _file_type file_type, unsigned flags,
				  const resmgr_connect_funcs_t *connect_funcs,
				  const resmgr_io_funcs_t *io_funcs, RESMGR_HANDLE_T *handle)
{
    return ut_ipc_mock_ptr->resmgr_attach(dpp, attr, path, file_type, flags, connect_funcs, io_funcs, handle);
}

int resmgr_detach(dispatch_t *dpp, int id, unsigned flags)
{
    return ut_ipc_mock_ptr->resmgr_detach(dpp, id, flags);
}

ssize_t resmgr_msgread(resmgr_context_t *__ctp, void *__msg, size_t __size, size_t __offset)
{
    return ut_ipc_mock_ptr->resmgr_msgread(__ctp, __msg, __size, __offset);
}

void* resmgr_ocb(resmgr_context_t* ctp)
{
    return ut_ipc_mock_ptr->resmgr_ocb(ctp);
}


dispatch_context_t 		*dispatch_context_alloc(dispatch_t *dpp)
{
    return ut_ipc_mock_ptr->dispatch_context_alloc(dpp);
}

dispatch_context_t 		*dispatch_block(dispatch_context_t *ctp)
{
    return ut_ipc_mock_ptr->dispatch_block(ctp);
}

int dispatch_handler(dispatch_context_t *ctp)
{
    return ut_ipc_mock_ptr->dispatch_handler(ctp);
}

void	dispatch_context_free(dispatch_context_t *ctp)
{
    return ut_ipc_mock_ptr->dispatch_context_free(ctp);
}
dispatch_t	*dispatch_create(void)
{
	dispatch_t dispatch_tobj;
   // return ut_ipc_mock_ptr->dispatch_create(); //returned to NULL bcoz creating object was creating problem
	return &dispatch_tobj;
}


int message_connect(dispatch_t *dpp, int flags)
{
    return ut_ipc_mock_ptr->message_connect(dpp, flags);
}
int MsgSendPulse_r(int __coid, int __priority, int __code, int  __value)
{
    //return ut_ipc_mock_ptr->MsgSendPulse_r(__coid, __priority,  __code, __value);
  return 0;
}
int ConnectDetach_r(int __coid)
{
    return ut_ipc_mock_ptr->ConnectDetach_r(__coid);
}

int hvac_resmgr_prepare_pulse_handler_dummy(message_context_t * ctp,int code,unsigned flags, void* handle)
{
      return 0;
}

int pulse_attach(dispatch_t *dpp, int flags, int code,
				 int (*func)(message_context_t *ctp, int code, unsigned flags, void *handle),
				 void *handle)
{
    //return ut_ipc_mock_ptr->pulse_attach(dpp, flags, code,  &hvac_resmgr_prepare_pulse_handler_dummy, handle);
	return 0;
}

int pulse_detach(dispatch_t *dpp, int code, int flags)
{
    return ut_ipc_mock_ptr->pulse_detach(dpp, code, flags);
}

int dispatch_destroy(dispatch_t *dpp)
{
    return ut_ipc_mock_ptr->dispatch_destroy(dpp); 
}

int ChannelDestroy_r(int __chid)
{
    return ut_ipc_mock_ptr->ChannelDestroy_r(__chid);
}

int ChannelCreate_r(unsigned __flags)
{
   // return ut_ipc_mock_ptr->ChannelCreate_r(__flags);
   return 0;
}

int ConnectAttach_r(unsigned nd, pid_t pid, int chid, unsigned index, int flags)
{
    return ut_ipc_mock_ptr->ConnectAttach_r(nd, pid, chid, index, flags);
}

int MsgReceivePulse_r(int chid, void* pulse, int bytes, _msg_info* info)
{
    //return ut_ipc_mock_ptr->MsgReceivePulse_r(chid,  pulse, bytes, info);
    return 1;
}

long MsgSend_r(int __coid, const void *__smsg, int __sbytes, void *__rmsg, int __rbytes)
{
    return ut_ipc_mock_ptr->MsgSend_r(__coid, __smsg, __sbytes, __rmsg, __rbytes);
}
/*int iofunc_devctl_default(resmgr_context_t *ctp, io_devctl_t *msg,iofunc_ocb_t *ocb)
{
	return 0;
}*/
int MsgReceive_r( int chid,
                  void * msg,
                  size_t bytes,
                  struct _msg_info * info )
{
return 0;
}
int MsgReply_r( int rcvid,
                long status,
                const void* msg,
                size_t bytes )
{
return 0;
}
int writeread(int key, uint16_t w_count, const void *w_buffer,uint16_t r_count, void *r_buffer)
{
return 0;
}	
int get_own_name(int key, char *out_value, int value_buffersize)
{
return 1;
}
int get_extra_config(int key, const char *configitem_key, char *out_value,int value_buffersize)
{
return 1;
}

/*int write(int key, uint16_t count, const void *buffer)
{
return 0;
}*/
