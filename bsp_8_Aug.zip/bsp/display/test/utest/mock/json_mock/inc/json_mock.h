#ifndef __H_JSON_MOCK_H__
#define __H_JSON_MOCK_H__

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "json_header.h"

class UT_json_mock
{
    public:
        UT_json_mock() {}
        virtual ~UT_json_mock() {}

        MOCK_METHOD0(json_decoder_create,
                     json_decoder_t *(void));
        MOCK_METHOD0(json_encoder_create,
                     json_encoder_t *(void));
        MOCK_METHOD1(json_decoder_destroy,
                     void(json_decoder_t *));
        MOCK_METHOD1(json_decoder_length,
                     int(json_decoder_t *));
        MOCK_METHOD1(json_decoder_pop,
                     json_decoder_error_t(json_decoder_t *));
        MOCK_METHOD1(json_encoder_buffer,
                     const char *(const json_encoder_t *));
        MOCK_METHOD1(json_encoder_destroy,
                     void(json_encoder_t *));
        MOCK_METHOD1(json_encoder_end_array,
                     json_encoder_error_t(json_encoder_t *));
        MOCK_METHOD1(json_encoder_end_object,
                     json_encoder_error_t(json_encoder_t *));
        MOCK_METHOD1(json_encoder_get_status,
                     json_encoder_error_t(const json_encoder_t *));
        MOCK_METHOD2(json_decoder_dump_tree,
                     void(json_decoder_t *, FILE *));
        MOCK_METHOD2(json_decoder_get_status,
                     json_decoder_error_t(json_decoder_t *, bool));
        MOCK_METHOD2(json_decoder_parse_json_str,
                     json_decoder_error_t(json_decoder_t *, const char *));
        MOCK_METHOD2(json_decoder_position_index,
                     json_decoder_error_t(json_decoder_t *, int));
        MOCK_METHOD2(json_encoder_start_array,
                     json_encoder_error_t(json_encoder_t *, const char *));
        MOCK_METHOD2(json_encoder_start_object,
                     json_encoder_error_t(json_encoder_t *, const char *));
        MOCK_METHOD3(json_decoder_push_array,
                     json_decoder_error_t(json_decoder_t *, const char *, bool));
        MOCK_METHOD3(json_decoder_push_object,
                     json_decoder_error_t(json_decoder_t *, const char *, bool));
        MOCK_METHOD3(json_encoder_add_bool,
                     json_encoder_error_t(json_encoder_t *, const char *, bool));
        MOCK_METHOD3(json_encoder_add_int,
                     json_encoder_error_t(json_encoder_t *, const char *, int));
        MOCK_METHOD3(json_encoder_add_string,
                     json_encoder_error_t(json_encoder_t *, const char *,
                                          const char *));
        MOCK_METHOD4(json_decoder_get_bool,
                     json_decoder_error_t(json_decoder_t *, const char *,
                                          bool *, bool));
        MOCK_METHOD4(json_decoder_get_int,
                     json_decoder_error_t(json_decoder_t *, const char *,
                                          int *, bool));
        MOCK_METHOD4(json_decoder_get_string,
                     json_decoder_error_t(json_decoder_t *, const char *,
                                          const char **, bool));
};

extern UT_json_mock *ut_json_mock_ptr;

#endif /*__H_JSON_MOCK_H__*/
