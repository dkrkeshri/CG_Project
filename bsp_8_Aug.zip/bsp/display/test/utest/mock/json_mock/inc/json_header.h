#ifndef __H_JSON_HEADER_H__
#define __H_JSON_HEADER_H__

#include <stdbool.h>
#include <stdio.h>

#define EOK                     0

typedef enum {
        JSON_DECODER_OK                = 0,
        JSON_DECODER_NO_MEMORY         = 1,
        JSON_DECODER_BAD_TYPE          = 2,
        JSON_DECODER_NOT_FOUND         = 3,
        JSON_DECODER_PARSE_ERROR       = 4,
        JSON_DECODER_CONVERSION_FAILED = 5,
        JSON_DECODER_POP_AT_ROOT       = 6,
        JSON_DECODER_INVALID_STATE     = 7,
        JSON_DECODER_EXTERNAL_ERROR    = 8,
        JSON_DECODER_ENCODING_ERROR    = 9,
        JSON_DECODER_FILE_READ_ERROR   = 10
} json_decoder_error_t;

typedef enum {
        JSON_DECODER_PARSE_OK                        = 0,
        JSON_DECODER_DOUBLE_QUOTE_EXPECTED           = 1,
        JSON_DECODER_COLON_EXPECTED                  = 2,
        JSON_DECODER_RIGHT_BRACE_OR_COMMA_EXPECTED   = 3,
        JSON_DECODER_RIGHT_BRACKET_OR_COMMA_EXPECTED = 4,
        JSON_DECODER_TRUE_EXPECTED                   = 5,
        JSON_DECODER_FALSE_EXPECTED                  = 6,
        JSON_DECODER_NULL_EXPECTED                   = 7,
        JSON_DECODER_UNEXPECTED_CHARACTER            = 8,
        JSON_DECODER_UNTERMINATED_STRING             = 9,
        JSON_DECODER_INCOMPLETE_ESCAPED_CHARACTER    = 10,
        JSON_DECODER_INVALID_HEXADECIMAL_DIGIT       = 11,
        JSON_DECODER_MISSING_TRAIL_SURROGATE         = 12,
        JSON_DECODER_UNEXPECTED_TRAIL_SURROGATE      = 13,
        JSON_DECODER_UNEXPECTED_COMMA                = 14,
        JSON_DECODER_EXTRA_CHARACTERS                = 15,
        JSON_DECODER_UNEXPECTED_END_OF_STRING        = 16
} json_decoder_parse_error_t;

typedef enum {
        JSON_TYPE_NULL   = 0,
        JSON_TYPE_BOOL   = 1,
        JSON_TYPE_NUMBER = 2,
        JSON_TYPE_STRING = 3,
        JSON_TYPE_ARRAY  = 4,
        JSON_TYPE_OBJECT = 5,
        JSON_TYPE_NONE   = 6
} json_node_type_t;

typedef enum {
        JSON_ENCODER_OK                    = 0,
        JSON_ENCODER_NO_MEMORY             = 1,
        JSON_ENCODER_BAD_NESTING           = 2,
        JSON_ENCODER_INVALID_VALUE         = 3,
        JSON_ENCODER_MISSING_PROPERTY_NAME = 4,
        JSON_ENCODER_NOT_FOUND             = 5,
        JSON_ENCODER_NOT_SUPPORTED         = 6,
        JSON_ENCODER_TOO_MANY_VALUES       = 7,
        JSON_ENCODER_UNEXPECTED_NAME       = 8,
        JSON_ENCODER_MAX_LEVEL_REACHED     = 9,
        JSON_ENCODER_INVALID_STATE         = 10,
        JSON_ENCODER_EXTERNAL_ERROR        = 11
} json_encoder_error_t;

typedef enum {
        JSON_ENCODER_FORMAT_JSON = 0
} json_encoder_format_t;

typedef enum {
        JSON_ENCODER_CLEAR_MEMORY = 1,
        JSON_ENCODER_AUTO_FORMAT  = 2,
        JSON_ENCODER_FILE_FORMAT  = 4
} json_encoder_option_t;

struct _json_decoder;
struct _json_encoder;
struct _json_decoder_state;
struct _json_encoder_state;

typedef struct _json_decoder json_decoder_t;
typedef struct _json_encoder json_encoder_t;
typedef struct _json_decoder_state json_decoder_state_t;
typedef struct _json_encoder_state json_encoder_state_t;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
json_decoder_t *json_decoder_create(void);
void json_decoder_destroy(json_decoder_t *decoder);
json_decoder_error_t json_decoder_parse_json_str(json_decoder_t *decoder,
        const char *str);
json_decoder_error_t json_decoder_get_status(json_decoder_t *decoder,
        bool clear);
json_decoder_error_t json_decoder_push_object(json_decoder_t *decoder,
        const char *name, bool optional);
json_decoder_error_t json_decoder_push_array(json_decoder_t *decoder,
        const char *name, bool optional);
json_decoder_error_t json_decoder_pop(json_decoder_t *decoder);
int json_decoder_length(json_decoder_t *decoder);
json_decoder_error_t json_decoder_position_index(json_decoder_t *decoder,
        int index);
json_decoder_error_t json_decoder_get_bool(json_decoder_t *decoder,
        const char *name, bool *value, bool optional);
json_decoder_error_t json_decoder_get_int(json_decoder_t *decoder,
        const char *name, int *value, bool optional);
json_decoder_error_t json_decoder_get_string(json_decoder_t *decoder,
        const char *name, const char **value, bool optional);
void json_decoder_dump_tree(json_decoder_t *decoder, FILE *fp);
json_encoder_t *json_encoder_create(void);
void json_encoder_destroy(json_encoder_t *encoder);
json_encoder_error_t json_encoder_get_status(const json_encoder_t *encoder);
const char *json_encoder_buffer(const json_encoder_t *encoder);
json_encoder_error_t json_encoder_start_object(json_encoder_t *encoder,
        const char *name);
json_encoder_error_t json_encoder_end_object(json_encoder_t *encoder);
json_encoder_error_t json_encoder_start_array(json_encoder_t *encoder,
        const char *name);
json_encoder_error_t json_encoder_end_array(json_encoder_t *encoder);
json_encoder_error_t json_encoder_add_bool(json_encoder_t *encoder,
        const char *name, bool value);
json_encoder_error_t json_encoder_add_int(json_encoder_t *encoder,
        const char *name, int value);
json_encoder_error_t json_encoder_add_string(json_encoder_t *encoder,
        const char *name, const char *value);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __H_JSON_HEADER_H__ */

