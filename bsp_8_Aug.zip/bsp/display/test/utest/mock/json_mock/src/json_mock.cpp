#include <stdexcept>
#include <string>
#include "json_mock.h"

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_json_mock *ut_json_mock_ptr;

json_decoder_t *json_decoder_create(void)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_create();
}

void json_decoder_destroy(json_decoder_t *decoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_destroy(decoder);
}

json_decoder_error_t json_decoder_parse_json_str(json_decoder_t *decoder,
        const char *str)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_parse_json_str(decoder, str);
}

json_decoder_error_t json_decoder_get_status(json_decoder_t *decoder,
        bool clear)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_get_status(decoder, clear);
}

json_decoder_error_t json_decoder_push_object(json_decoder_t *decoder,
        const char *name, bool optional)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_push_object(decoder, name,
                                                          optional);
}

json_decoder_error_t json_decoder_push_array(json_decoder_t *decoder,
        const char *name, bool optional)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_push_array(decoder, name,
                                                         optional);
}

json_decoder_error_t json_decoder_pop(json_decoder_t *decoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_pop(decoder);
}

int json_decoder_length(json_decoder_t *decoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_length(decoder);
}

json_decoder_error_t json_decoder_position_index(json_decoder_t *decoder,
        int index)
{
       if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_position_index(decoder, index);
}

json_decoder_error_t json_decoder_get_bool(json_decoder_t *decoder,
        const char *name, bool *value, bool optional)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_get_bool(decoder, name, value,
                                                       optional);
}

json_decoder_error_t json_decoder_get_int(json_decoder_t *decoder,
        const char *name, int *value, bool optional)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_get_int(decoder, name, value,
                                                      optional);
}

json_decoder_error_t json_decoder_get_string(json_decoder_t *decoder,
        const char *name, const char **value, bool optional)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_get_string(decoder, name, value,
                                                         optional);
}

void json_decoder_dump_tree(json_decoder_t *decoder, FILE *fp)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_decoder_dump_tree(decoder, fp);
}

json_encoder_t *json_encoder_create(void)
{
       if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_create();
}

void json_encoder_destroy(json_encoder_t *encoder)
{
       if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_destroy(encoder);
}

json_encoder_error_t json_encoder_get_status(const json_encoder_t *encoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_get_status(encoder);
}

const char *json_encoder_buffer(const json_encoder_t *encoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_buffer(encoder);
}

json_encoder_error_t json_encoder_start_object(json_encoder_t *encoder,
        const char *name)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_start_object(encoder, name);
}

json_encoder_error_t json_encoder_end_object(json_encoder_t *encoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_end_object(encoder);
}

json_encoder_error_t json_encoder_start_array(json_encoder_t *encoder,
        const char *name)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_start_array(encoder, name);
}

json_encoder_error_t json_encoder_end_array(json_encoder_t *encoder)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_end_array(encoder);
}

json_encoder_error_t json_encoder_add_bool(json_encoder_t *encoder,
        const char *name, bool value)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_add_bool(encoder, name, value);
}

json_encoder_error_t json_encoder_add_int(json_encoder_t *encoder,
        const char *name, int value)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_add_int(encoder, name, value);
}

json_encoder_error_t json_encoder_add_string(json_encoder_t *encoder,
        const char *name, const char *value)
{
        if (NULL == ut_json_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
        return ut_json_mock_ptr->json_encoder_add_string(encoder, name, value);
}

