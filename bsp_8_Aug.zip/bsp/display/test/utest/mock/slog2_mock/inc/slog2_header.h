#ifndef __H_slog2_HEADER_H__
#define __H_slog2_HEADER_H__

#include <sys/types.h>
#include <inttypes.h>
#include <stdarg.h>
#define SLOG2_MAX_BUFFERS    (4)

/* Severity Levels - SLOG2 */
#define SLOG2_SHUTDOWN  0
#define SLOG2_CRITICAL  1
#define SLOG2_ERROR     2
#define SLOG2_WARNING   3
#define SLOG2_NOTICE    4
#define SLOG2_INFO      5
#define SLOG2_DEBUG1    6
#define SLOG2_DEBUG2    7


#define SCREEN_WAIT_IDLE (1 << 0)
#define SCREEN_POWER_MANAGER_CONTEXT  (1 << 2)
#define PROCMGR_DAEMON_NOCHDIR 2
#define PROCMGR_DAEMON_NODEVNULL 0
#define SCREEN_POWER_MODE_ON  0x7683
#define SCREEN_PROPERTY_POWER_MODE  88
#define _PULSE_CODE_UNBLOCK 1
#define _IO_CONNECT 3
#define _IO_BASE 0x100
#define SCREEN_POWER_MODE_OFF 0x7680

#define _SLOGC_PRIVATE_START 1
#define LIBCP_PRINT_DEBUG 2
#define _SLOG_SETCODE(x,y) 2

#define EOK            0
#define  IOFUNC_ATTR_DIRTY_TIME 1

//#define _IO_XTYPE_NONE 2
//#define _IO_XTYPE_MASK 3
#define _SLOG_SHUTDOWN 0
#define _SLOG_CRITICAL 1
#define _SLOG_ERROR    2
#define _SLOG_WARNING  3
#define _SLOG_NOTICE   4
#define _SLOG_INFO     5
#define _SLOG_DEBUG1   6
#define _SLOG_DEBUG2   7
 
typedef unsigned char _Uint8t;

typedef struct slog2_buffer_meta* slog2_buffer_t;
typedef struct
{
    /** What we want to name the buffer */
    const char    *buffer_name;
    /** The number of 4K pages this buffer contains */
    int            num_pages;
} slog2_buffer_config_t;

typedef struct
{
    /** Number of buffers to configure */
    int                   num_buffers;
    /** Process name, or other descriptor */
    const char           *buffer_set_name;
    /** The minimum severity to log */
    _Uint8t               verbosity_level;
    /** Buffer configuration for num_buffers */
    slog2_buffer_config_t buffer_config[ SLOG2_MAX_BUFFERS ];
} slog2_buffer_set_config_t;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int slog2_register( slog2_buffer_set_config_t*, slog2_buffer_t*, int );
void slog2f(slog2_buffer_t,int,int,const char *fmt,...);
int slog2_set_verbosity(slog2_buffer_t,int);
int slog2_reset( void );
int slog2c( slog2_buffer_t buffer, unsigned short code, unsigned char severity, const char* data );
int vslog2f( slog2_buffer_t buffer,
             uint16_t code,
             uint8_t severity,
             const char* format,
             va_list arglist );

int slogf( int opcode,int severity, const char * fmt,... );
int min(int a,int b);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_slog2_HEADER_H__*/
