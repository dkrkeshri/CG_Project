#include "slog2_header.h"
int slog2_register( slog2_buffer_set_config_t* a, slog2_buffer_t* b, int c)
{
   return 0;
}
void slog2f(slog2_buffer_t, int, int, const char *fmt,...)
{
}
int slog2_set_verbosity(slog2_buffer_t,int)
{
   return 0;
}
/*int slog2_reset( void )
{
    return 0;
}*/
int slog2c( slog2_buffer_t buffer, unsigned short code, unsigned char severity, const char* data )
{
    return 0;
}

int vslog2f( slog2_buffer_t buffer,
             uint16_t code,
             uint8_t severity,
             const char* format,
             va_list arglist )
{
    return 0;
}

int slogf( int opcode,
           int severity,
           const char * fmt,
           ... )
{
return 0;
}
int min(int a,int b)
{
return 0;
}
