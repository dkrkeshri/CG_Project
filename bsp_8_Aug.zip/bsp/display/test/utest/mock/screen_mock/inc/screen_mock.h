#ifndef __H_SCREEN_MOCK_H__
#define __H_SCREEN_MOCK_H__

#include <gmock/gmock.h>
#include "screen_header.h"

class UT_screen_mock
{
    public:
        UT_screen_mock() {}
        virtual ~UT_screen_mock() {}
        MOCK_METHOD2(screen_create_context, int (screen_context_t *, int ));
        MOCK_METHOD3(screen_get_context_property_iv, int (screen_context_t, int, int *));
        MOCK_METHOD3(screen_get_context_property_pv, int (screen_context_t, int, void **));
        MOCK_METHOD1(screen_destroy_context, int (screen_context_t));
        MOCK_METHOD2(screen_create_window, int (screen_window_t *, screen_context_t));
        MOCK_METHOD3(screen_set_window_property_iv, int (screen_window_t, int, const int *));
        MOCK_METHOD3(screen_get_window_property_iv, int (screen_window_t, int, int *));
        MOCK_METHOD3(screen_set_window_property_pv, int (screen_window_t, int, void **));
        MOCK_METHOD3(screen_get_window_property_pv, int (screen_window_t, int, void **));
        MOCK_METHOD1(screen_destroy_window, int (screen_window_t));
        MOCK_METHOD2(screen_create_window_buffers, int (screen_window_t, int));
        MOCK_METHOD3(screen_set_buffer_property_iv, int (screen_buffer_t, int, const int *));
        MOCK_METHOD3(screen_get_buffer_property_pv, int (screen_buffer_t, int, void **));
        MOCK_METHOD1(screen_destroy_window_buffers, int (screen_window_t win));
        MOCK_METHOD3(screen_get_display_property_iv, int (screen_display_t, int, int *));
        MOCK_METHOD2(screen_create_pixmap, int (screen_pixmap_t *, screen_context_t));
        MOCK_METHOD2(screen_attach_pixmap_buffer, int (screen_pixmap_t, screen_buffer_t));
        MOCK_METHOD3(screen_set_pixmap_property_iv, int (screen_pixmap_t, int, const int *));
        MOCK_METHOD3(screen_get_pixmap_property_pv, int (screen_pixmap_t, int, void **));
        MOCK_METHOD1(screen_create_pixmap_buffer, int (screen_pixmap_t));
        MOCK_METHOD4(screen_blit, int (screen_context_t, screen_buffer_t, screen_buffer_t, const int *));
        MOCK_METHOD3(screen_fill, int (screen_context_t, screen_buffer_t, const int *));
        MOCK_METHOD5(screen_post_window, int (screen_window_t, screen_buffer_t, int, const int *, int));
        MOCK_METHOD1(screen_create_event, int(screen_event_t*));
        MOCK_METHOD3(screen_set_event_property_iv, int(screen_event_t, int, const int*));
        MOCK_METHOD2(screen_inject_event, int(screen_display_t, screen_event_t));
        MOCK_METHOD3(screen_send_event, int(screen_context_t, screen_event_t, pid_t));
        MOCK_METHOD3(screen_create_device_type, int(screen_device_t *, screen_context_t, int));
        MOCK_METHOD1(screen_destroy_device, int(screen_device_t));
};

extern UT_screen_mock *ut_screen_mock_ptr;

#endif/*__H_SCREEN_MOCK_H__*/

