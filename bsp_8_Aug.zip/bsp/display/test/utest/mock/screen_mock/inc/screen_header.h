#ifndef __H_SCREEN_HEADER_H__
#define __H_SCREEN_HEADER_H__
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>


#define SCREEN_WAIT_IDLE (1 << 0)
#define SCREEN_POWER_MANAGER_CONTEXT  (1 << 2)
#define PROCMGR_DAEMON_NOCHDIR 2
#define PROCMGR_DAEMON_NODEVNULL 0
#define SCREEN_POWER_MODE_ON  0x7683
#define SCREEN_PROPERTY_POWER_MODE  88
#define _PULSE_CODE_UNBLOCK 1
#define _IO_CONNECT 3
#define _IO_BASE 0x100
#define SCREEN_POWER_MODE_OFF 0x7680

#define _SLOGC_PRIVATE_START 1
#define LIBCP_PRINT_DEBUG 2
#define _SLOG_SETCODE(x,y) 2

#define EOK            0
#define  IOFUNC_ATTR_DIRTY_TIME 1
#define _IO_XTYPE_NONE 2
#define _IO_XTYPE_MASK 3
#define _SLOG_SHUTDOWN 0
#define _SLOG_CRITICAL 1
#define _SLOG_ERROR    2
#define _SLOG_WARNING  3
#define _SLOG_NOTICE   4
#define _SLOG_INFO     5
#define _SLOG_DEBUG1   6
#define _SLOG_DEBUG2   7
typedef struct screen_context{

}*screen_context_t;

struct _screen_window;
typedef struct _screen_window *screen_window_t;

typedef struct screen_buffer{

}*screen_buffer_t;

typedef struct screen_display{

}*screen_display_t;

typedef struct screen_pixmap{

}*screen_pixmap_t;

typedef struct screen_device{

}*screen_device_t;

typedef struct screen_event{

}*screen_event_t;

enum {
    SCREEN_PROPERTY_BUFFER_SIZE = 5,
    SCREEN_PROPERTY_DISPLAY = 11,
    SCREEN_PROPERTY_FORMAT = 14,
    SCREEN_PROPERTY_KEY_CAP = 24,
    SCREEN_PROPERTY_FLAGS = 25,
    SCREEN_PROPERTY_POINTER = 34,
    SCREEN_PROPERTY_RENDER_BUFFERS = 37,
    SCREEN_PROPERTY_SIZE = 40,
    SCREEN_PROPERTY_SWAP_INTERVAL = 45,
    SCREEN_PROPERTY_TYPE = 47,
    SCREEN_PROPERTY_USAGE = 48,
    SCREEN_PROPERTY_VISIBLE = 51,
    SCREEN_PROPERTY_RENDER_BUFFER_COUNT = 53,
    SCREEN_PROPERTY_DISPLAY_COUNT = 59,
    SCREEN_PROPERTY_DISPLAYS = 60,
    SCREEN_PROPERTY_ATTACHED = 64,
    SCREEN_PROPERTY_ID = 87,
};

enum {
	SCREEN_EVENT_KEYBOARD = 7,
};

enum{
    SCREEN_FORMAT_RGB888 = 7,
    SCREEN_FORMAT_RGBA8888 = 8,
    SCREEN_FORMAT_UYVY = 14,
};

enum{
    SCREEN_APPLICATION_CONTEXT = 0,
};

enum{
    SCREEN_BLIT_END = 0,
    SCREEN_BLIT_COLOR = 12,
};

enum {
    SCREEN_USAGE_WRITE = (1 << 2),
    SCREEN_USAGE_NATIVE = (1 << 3),
    SCREEN_USAGE_OPENGL_ES2 = (1 << 5),
    SCREEN_USAGE_OPENGL_ES3 = (1 << 11),
};

enum {
    SCREEN_INPUT_PROVIDER_CONTEXT = (1 << 1),
};

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int screen_create_context(screen_context_t *pctx, int flags);
int screen_get_context_property_iv(screen_context_t ctx, int pname, int *param);
int screen_get_context_property_pv(screen_context_t ctx, int pname, void **param);
int screen_destroy_context(screen_context_t ctx);
int screen_create_window(screen_window_t *pwin, screen_context_t ctx);
int screen_set_window_property_iv(screen_window_t win, int pname, const int *param);
int screen_get_window_property_iv(screen_window_t win, int pname, int *param);
int screen_set_window_property_pv(screen_window_t win, int pname, void **param);
int screen_get_window_property_pv(screen_window_t win, int pname, void **param);
int screen_destroy_window(screen_window_t win);
int screen_create_window_buffers(screen_window_t win, int count);
int screen_set_buffer_property_iv(screen_buffer_t buf, int pname, const int *param);
int screen_get_buffer_property_pv(screen_buffer_t buf, int pname, void **param);
int screen_destroy_window_buffers(screen_window_t win);
int screen_get_display_property_iv(screen_display_t disp, int pname, int *param);
int screen_create_pixmap(screen_pixmap_t *ppix, screen_context_t ctx);
int screen_set_pixmap_property_iv(screen_pixmap_t pix, int pname, const int *param);
int screen_get_pixmap_property_pv(screen_pixmap_t pix, int pname, void **param);
int screen_create_pixmap_buffer(screen_pixmap_t pix);
int screen_attach_pixmap_buffer(screen_pixmap_t pix, screen_buffer_t buf);
int screen_blit(screen_context_t ctx, screen_buffer_t dst, screen_buffer_t src, const int *attribs);
int screen_fill(screen_context_t ctx, screen_buffer_t dst, const int *attribs);
int screen_post_window(screen_window_t win, screen_buffer_t buf, int count, const int *dirty_rects, int flags);
int screen_create_event(screen_event_t *pev);
int screen_set_event_property_iv(screen_event_t ev, int pname, const int *param);
int screen_inject_event(screen_display_t disp, screen_event_t ev);
int screen_send_event(screen_context_t ctx, screen_event_t ev, pid_t pid);
int screen_create_device_type(screen_device_t *pdev, screen_context_t ctx, int type);
int screen_destroy_device(screen_device_t dev);

int set_ids_from_arg( const char *string );
int procmgr_daemon( int status,unsigned flags );
int screen_set_display_property_iv(screen_display_t disp,int pname,const int *param);
int screen_flush_context(screen_context_t ctx,int flags);
int slogf( int opcode,int severity, const char * fmt,... );
int min(int a,int b);
int displaybinder_ctrl_open(const char* path);
int displaybinder_ctrl_set_online(int value);
int displaybinder_ctrl_set_offline(int value);
int displaybinder_ctrl_close(int value);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __H_SCREEN_HEADER_H__ */
