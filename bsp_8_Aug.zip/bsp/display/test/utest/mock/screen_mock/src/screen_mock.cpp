#include "screen_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_screen_mock *ut_screen_mock_ptr;

/* wrapper for screen_create_context */
int screen_create_context(screen_context_t *pctx, int flags)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }

    return ut_screen_mock_ptr->screen_create_context(pctx, flags);
}

/* wrapper for screen_get_context_property_iv */
int screen_get_context_property_iv(screen_context_t ctx, int pname, int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }

    return ut_screen_mock_ptr->screen_get_context_property_iv(ctx, pname, param);
}

/* wrapper for screen_get_context_property_pv */
int screen_get_context_property_pv(screen_context_t ctx, int pname, void **param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }

    return ut_screen_mock_ptr->screen_get_context_property_pv(ctx, pname, param);
}

/* wrapper for screen_destroy_context */
int screen_destroy_context(screen_context_t ctx)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_destroy_context(ctx);
}

/* wrapper for screen_create_window */
int screen_create_window(screen_window_t *pwin, screen_context_t ctx)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_window(pwin, ctx);
}

/* wrapper for screen_set_window_property_iv */
int screen_set_window_property_iv(screen_window_t win, int pname, const int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_set_window_property_iv(win, pname, param);
}

/* wrapper for screen_get_window_property_iv */
int screen_get_window_property_iv(screen_window_t win, int pname, int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_get_window_property_iv(win, pname, param);
}

/* wrapper for screen_set_window_property_pv */
int screen_set_window_property_pv(screen_window_t win, int pname, void **param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_set_window_property_pv(win, pname, param);
}

/* wrapper for screen_get_window_property_pv */
int screen_get_window_property_pv(screen_window_t win, int pname, void **param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_get_window_property_pv(win, pname, param);
}

/* wrapper for screen_destroy_window */
int screen_destroy_window(screen_window_t win)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_destroy_window(win);
}

/* wrapper for screen_create_window_buffers */
int screen_create_window_buffers(screen_window_t win, int count)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_window_buffers(win, count);
}

/* wrapper for screen_set_buffer_property_iv */
int screen_set_buffer_property_iv(screen_buffer_t buf, int pname, const int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_set_buffer_property_iv(buf, pname, param);
}

/* wrapper for screen_get_buffer_property_pv */
int screen_get_buffer_property_pv(screen_buffer_t buf, int pname, void **param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_get_buffer_property_pv(buf, pname, param);
}

/* wrapper for screen_destroy_window_buffers */
int screen_destroy_window_buffers(screen_window_t win)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_destroy_window_buffers(win);
}

/* wrapper for screen_get_display_property_iv */
int screen_get_display_property_iv(screen_display_t disp, int pname, int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_get_display_property_iv(disp, pname, param);
}

/* wrapper for screen_create_pixmap */
int screen_create_pixmap(screen_pixmap_t *ppix, screen_context_t ctx)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_pixmap(ppix, ctx);
}

/* wrapper for screen_set_pixmap_property_iv */
int screen_set_pixmap_property_iv(screen_pixmap_t pix, int pname, const int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_set_pixmap_property_iv(pix, pname, param);
}

/* wrapper for screen_get_pixmap_property_pv */
int screen_get_pixmap_property_pv(screen_pixmap_t pix, int pname, void **param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_get_pixmap_property_pv(pix, pname, param);
}

/* wrapper for screen_create_pixmap_buffer */
int screen_create_pixmap_buffer(screen_pixmap_t pix)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_pixmap_buffer(pix);
}

/* wrapper for screen_attach_pixmap_buffer */
int screen_attach_pixmap_buffer(screen_pixmap_t pix, screen_buffer_t buf)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_attach_pixmap_buffer(pix, buf);
}

/* wrapper for screen_blit */
int screen_blit(screen_context_t ctx, screen_buffer_t dst, screen_buffer_t src, const int *attribs)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_blit(ctx, dst, src, attribs);
}

/* wrapper for screen_fill */
int screen_fill(screen_context_t ctx, screen_buffer_t dst, const int *attribs)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_fill(ctx, dst, attribs);
}

/* wrapper for screen_post_window */
int screen_post_window(screen_window_t win, screen_buffer_t buf, int count, const int *dirty_rects, int flags)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_post_window(win, buf, count, dirty_rects, flags);
}

/*wrapper for screen_create_event*/
int screen_create_event(screen_event_t *pev)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_event(pev);
}

/*wrapper for screen_set_event_property_iv*/
int screen_set_event_property_iv(screen_event_t ev, int pname, const int *param)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_set_event_property_iv(ev, pname, param);
}
/*wrapper for screen_inject_event*/
int screen_inject_event(screen_display_t disp, screen_event_t ev)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_inject_event(disp, ev);

}
/*wrapper for screen_send_event*/
int screen_send_event(screen_context_t ctx, screen_event_t ev, pid_t pid)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_send_event(ctx, ev, pid);
}
/*wrapper for screen_create_device_type*/
int screen_create_device_type(screen_device_t *pdev, screen_context_t ctx, int type)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_create_device_type(pdev, ctx, type);

}
/*wrapper for screen_destroy_device*/
int screen_destroy_device(screen_device_t dev)
{
    if (NULL == ut_screen_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_screen_mock_ptr->screen_destroy_device(dev);

}


int set_ids_from_arg( const char *string )
{
return 0;
}
int procmgr_daemon( int status,
                    unsigned flags )
{
return 0;
}

int screen_set_display_property_iv(screen_display_t disp,int pname,const int *param)
{
return 0;
}
int screen_flush_context(screen_context_t ctx,int flags){
return 0;
}

int displaybinder_ctrl_open(const char* path){
	return 0;
}

int displaybinder_ctrl_set_online(int value){
	return 0;
}

int displaybinder_ctrl_set_offline(int value){
	return 0;
}

int displaybinder_ctrl_close(int value){
	return 0;
}