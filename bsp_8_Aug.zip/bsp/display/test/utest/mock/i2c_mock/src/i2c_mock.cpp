#include "i2c_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_i2c_mock *ut_i2c_mock_ptr;

/* wrapper for i2c_open */
int i2c_open(void* devname)
{
    if (NULL == ut_i2c_mock_ptr) {
        //throw std::invalid_argument(NULL_PTR_ERR);
	return 0;
    }
    //return ut_i2c_mock_ptr->i2c_open(devname);
    return 0;
}

void vWritePrintfErrmem(const char* buf, ...)
{
   /* if (NULL == ut_i2c_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    ut_i2c_mock_ptr->vWritePrintfErrmem(buf);*/
  
}

/* wrapper for i2c_close */
void i2c_close(int fd)
{
    if (NULL == ut_i2c_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_i2c_mock_ptr->i2c_close(fd);
}

/* wrapper for i2c_read */
int i2c_read(int fd, void *buf, uint32_t len)
{
    if (NULL == ut_i2c_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_i2c_mock_ptr->i2c_read(fd, buf, len);
}

/* wrapper for i2c_write */
int i2c_write(int fd, void *buf, uint32_t len)
{
    if (NULL == ut_i2c_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_i2c_mock_ptr->i2c_write(fd, buf, len);
}

/*wrapper for i2c_set_slave_addr */
int i2c_set_slave_addr(int fd, uint32_t addr, uint32_t fmt)
{
    if (NULL == ut_i2c_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_i2c_mock_ptr->i2c_set_slave_addr(fd, addr, fmt);
}

int i2c_combined_writeread(int fd, void *wbuff, uint32_t wlen, void *rbuff, uint32_t rlen)
{
    if (NULL == ut_i2c_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_i2c_mock_ptr->i2c_combined_writeread(fd, wbuff, wlen, rbuff, rlen);
}
int ThreadCreate(
          pid_t pid,
          void* (func)( void* ),
          void* arg,
          const struct _thread_attr* attr )
{
return -1;
}
int ThreadJoin( int tid,
                void** status )
{
return 1;
}
int gettid( void )
{
return 0;
}
int i2c_set_bus_speed(int fd,unsigned int speed,unsigned int *ospeed )
{
return 0;
}
