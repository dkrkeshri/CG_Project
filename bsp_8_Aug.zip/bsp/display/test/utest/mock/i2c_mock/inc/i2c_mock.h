#ifndef __H_I2C_MOCK_H__
#define __H_I2C_MOCK_H__

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "i2c_header.h"

class UT_i2c_mock
{
    public:
        UT_i2c_mock() {}
        virtual ~UT_i2c_mock() {}
        MOCK_METHOD1(i2c_open, int(void *devname));
        MOCK_METHOD1(i2c_close, void(int fd));
        MOCK_METHOD3(i2c_read, int(int fd, void *buf, uint32_t len));
        MOCK_METHOD3(i2c_write, int(int fd, void *buf, uint32_t len));
        MOCK_METHOD3(i2c_set_slave_addr, int(int fd, uint32_t len, uint32_t fmt));
        MOCK_METHOD5(i2c_combined_writeread, int(int, void *, uint32_t, void *, uint32_t));
};

extern UT_i2c_mock *ut_i2c_mock_ptr;

#endif /*__H_I2C_MOCK_H__*/

