#ifndef __H_I2C_HEADER_H__
#define __H_I2C_HEADER_H__

#include <sys/types.h>
#include <inttypes.h>

#define I2C_ADDRFMT_7BIT   0x0002
#define _NTO_CHF_PRIVATE 13
#define _NTO_COF_CLOEXEC 112
#define DCMD_I2C_SET_SLAVE_ADDR 1
#define DCMD_I2C_SET_BUS_SPEED 2
#define DCMD_I2C_MASTER_SEND 3
#define DCMD_I2C_MASTER_RECV 4
#define DCMD_I2C_SEND 5
#define DCMD_I2C_RECV 10
#define DCMD_I2C_SENDRECV 7
#define DCMD_I2C_LOCK 8
#define DCMD_I2C_UNLOCK 9
#define DCMD_I2C_DRIVER_INFO 20
#define DCMD_I2C_STATUS 11
#define DCMD_I2C_BUS_RESET 12
#define I2C_SPEED_FAST 0x0002
struct _pulse {
    uint16_t        type;
    uint16_t        subtype;
    int8_t          code;
    uint8_t         zero [3];
    union sigval    value;
    int32_t         scoid;
};
//struct _pulse pul;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int i2c_open(void* devname);
int gettid( void );
void i2c_close(int fd);
int i2c_set_slave_addr(int fd, uint32_t addr, uint32_t fmt);
int i2c_write(int fd, void *buf, uint32_t len);
int i2c_read(int fd, void *buf, uint32_t len);
int i2c_combined_writeread(int fd, void *wbuff, uint32_t wlen, void *rbuff, uint32_t rlen);
int ThreadCreate(pid_t pid,void* (func)( void* ),void* arg,const struct _thread_attr* attr );
int ThreadJoin( int tid,void** status );
void vWritePrintfErrmem(const char* buf, ...);
int i2c_set_bus_speed(int fd,unsigned int speed,unsigned int *ospeed );
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /*__H_I2C_HEADER_H__*/

