#ifndef __H_TIMER_MOCK_H__
#define __H_TIMER_MOCK_H__

#include <gmock/gmock.h>
#include "timer_header.h"

class UT_timer_mock
{
    public:
        UT_timer_mock() {}
        virtual ~UT_timer_mock() {}
        MOCK_METHOD1(timer_delete, int(timer_t));
        MOCK_METHOD3(mock_timer_create, int(clockid_t , struct ut_sigevent *, timer_t *));
        MOCK_METHOD4(timer_settime, int(timer_t, int, const struct itimerspec *, struct itimerspec *));
};

extern UT_timer_mock *ut_timer_mock_ptr;

#endif /*__H_TIMER_MOCK_H__*/
