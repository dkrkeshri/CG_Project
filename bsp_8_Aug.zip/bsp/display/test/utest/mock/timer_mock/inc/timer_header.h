#ifndef __H_TIMER_HEADER_H__
#define __H_TIMER_HEADER_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int timer_delete(timer_t timerid);
int mock_timer_create(clockid_t clockid, struct ut_sigevent *sevp,
                            timer_t *timerid);
int timer_settime(timer_t timerid, int flags,const struct itimerspec *new_value,struct itimerspec *old_value);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_TIMER_HEADER_H__*/
