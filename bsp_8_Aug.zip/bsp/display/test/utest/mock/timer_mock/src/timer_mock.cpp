#include "timer_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_timer_mock *ut_timer_mock_ptr;

int timer_delete(timer_t timerid)
{
    if (NULL == ut_timer_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_timer_mock_ptr->timer_delete(timerid);

}

int mock_timer_create(clockid_t clockid, struct ut_sigevent *sevp,
                            timer_t *timerid)
 {
    if (NULL == ut_timer_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_timer_mock_ptr->mock_timer_create(clockid,sevp,timerid);

}

int timer_settime(timer_t timerid, int flags,const struct itimerspec *new_value,struct itimerspec *old_value)
{
    if (NULL == ut_timer_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_timer_mock_ptr->timer_settime(timerid,flags,new_value,old_value);

}
