#include "../inc/mock_posix_funcs.h"


MockPosix *glob_mock_posix=nullptr;

MockPosix *pf_instance()
{
	if(!glob_mock_posix)
		glob_mock_posix = new MockPosix();
	return glob_mock_posix;
}

struct datalistitem {
	datalistitem *next;
	int size,fh;
	char data[0];
};

static datalistitem *read_data_list = nullptr;
static datalistitem *write_data_list = nullptr;
static void put_data(datalistitem **to_this_list,const void *data,int size,int fh);
static int get_data(datalistitem **from_this_list,void *data,int buffersize,bool *out_was_cropped,int *intout_fd);

void pf_instance_destroy()
{
	// delete the mock-instance
	delete glob_mock_posix;
	glob_mock_posix=nullptr;
	// verify that the read-list was all picked up
	EXPECT_TRUE(read_data_list==nullptr);
	// drop all items on read- and write-lists
	datalistitem *w;
	while( (w=read_data_list) != nullptr )
		{read_data_list=w->next;delete[] (char*)w;}
	while( (w=write_data_list) != nullptr )
		{write_data_list=w->next;delete[] (char*)w;}
}

static void mockfunc_read_get_data(void *buf,ssize_t bufsize,ssize_t mockretval);


void *mockfunc_dlopen(const char *name,int flags)
	{return pf_instance()->m_dlopen(name,flags);}
int mockfunc_dlclose(void *handle)
	{return pf_instance()->m_dlclose(handle);}
void *mockfunc_dlsym(void *handle,const char *funcname)
	{return pf_instance()->m_dlsym(handle,funcname);}

int mockfunc_open(const char *path,int oflag)
	{return pf_instance()->m_open(path,oflag);}
int mockfunc_close(int fd)
	{return pf_instance()->m_close(fd);}
int mockfunc_lseek(int fd,off_t offset,int whence)
	{return pf_instance()->m_lseek(fd,offset,whence);}
ssize_t mockfunc_read(int fd,void *buf,size_t count)
{
	ssize_t res = pf_instance()->m_read(fd,buf,count);
	mockfunc_read_get_data(buf,count,res);  // pick up some data if provided.
	return res;
}
ssize_t mockfunc_write(int fd,const void *buf,size_t count)
{
	int ret = pf_instance()->m_write(fd,buf,count);
	if(ret>0)
		put_data(&write_data_list,buf,ret,fd);
	return ret;
}
int mockfunc_select(int nfds, fd_set*rdfds, fd_set*wrfds, fd_set*exfds, struct timeval *to)
	{return pf_instance()->m_select(nfds,rdfds,wrfds,exfds,to);}

int mockfunc_i2c_open(void *devname)
	{return pf_instance()->m_i2c_open(devname);}
void mockfunc_i2c_close(int fd)
	{return pf_instance()->m_i2c_close(fd);}
int mockfunc_i2c_set_slave_addr(int fd, uint32_t addr, uint32_t fmt)
	{return pf_instance()->m_i2c_set_slave_addr(fd,addr,fmt);}
int mockfunc_i2c_set_bus_speed(int fd, uint32_t speed, uint32_t *ospeed)
	{return pf_instance()->m_i2c_set_bus_speed(fd,speed,ospeed);}
int mockfunc_i2c_write(int fd, void *buf, uint32_t len)
	{return pf_instance()->m_i2c_write(fd,buf,len);}
int mockfunc_i2c_read(int fd, void *buf, uint32_t len)
	{return pf_instance()->m_i2c_read(fd,buf,len);}
int mockfunc_i2c_combined_writeread(int fd, void *wbuff, uint32_t wlen, void *rbuff, uint32_t rlen)
	{return pf_instance()->m_i2c_combined_writeread(fd,wbuff,wlen,rbuff,rlen);}



void mockfunc_read_provide_data(const void *data,int count,int for_fd)
{
	put_data(&read_data_list,data,count,for_fd);
}

int mockfunc_write_get_data(void *data,int buffersize,int *out_was_for_fd)
{
	bool crop;
	int count;
	// get
	count = get_data(&write_data_list,data,buffersize,&crop,out_was_for_fd);
	return count;
}

/**
 * helper function to put data to a linked list of datalistitem.
 *
 * used for mock write() function and for testcode to send data for read().
 */
static void put_data(datalistitem **to_this_list,const void *data,int size,int fh)
{
	datalistitem *item;
	item = (datalistitem*)new char[sizeof(datalistitem)+size+1];
	item->size = size;
	item->fh = fh;
	memcpy(item->data,data,size);
	item->data[size]=0;
	item->next=nullptr;
	// find end of linked list
	datalistitem **walk = to_this_list;
	while(*walk)
		walk = &((*walk)->next);
	// add here
	*walk = item;
}

/**
 * helper function to get data from a linked list of datalistitem.
 *
 * used for mock read() function and for testcode to get written data.
 */
static int get_data(datalistitem **from_this_list,void *data,int buffersize,bool *out_was_cropped,int *inout_fd)
{
	bool crop=false;
	int copysize;
	int forfh = ( inout_fd!=nullptr ? *inout_fd : -1 );
	datalistitem **walk;
	datalistitem *item;
	// params?
	if( buffersize<=0 || data==nullptr )
		return 0;
	// find first with matching fd
	walk=from_this_list;
	while(*walk)
	{
		if( forfh<0 || (*walk)->fh==forfh )
			break;
		walk=&((*walk)->next);
	}
	if(!*walk)
		return 0;	// have nothing (for this fh)
	item=*walk;
	*walk = item->next;
	copysize = item->size;
	if(copysize>buffersize)
		{copysize=buffersize;crop=true;}
	// copy the data.
	memcpy(data,item->data,copysize);
	if(inout_fd)*inout_fd=item->fh;
	// del the item
	delete[] (char*)item;
	if(out_was_cropped)
		*out_was_cropped = crop;
	return copysize;
}

static void mockfunc_read_get_data(void *buf,ssize_t bufsize,ssize_t mockretval)
{
	bool crop;
	int count;
	// must have enough buffer for the size the mock-read reported as read.
	ASSERT_GE(bufsize,mockretval);
	// get
	count = get_data(&read_data_list,buf,bufsize,&crop,nullptr);
	// must have enough data in the stored read-data item.
	ASSERT_TRUE(!crop);
	return;
}
