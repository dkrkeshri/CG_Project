#pragma once

/**
 * To support logging to stdout, to a file and/or to slogger2 makes logging somewhat complicated.
 *
 * to make supporting this easy, I add a class that encapsulates the sending of logs.
 * the interface is something like printf.
 *
 * CM/ESO2 Achim Dahlhoff
 */

#include <stdarg.h>
#include <string>

#define SLOG2_NAME "wakeup_daemon"

class LogOutput
{
public:
	LogOutput(const char *name);
	virtual ~LogOutput();

	/// init. if passing NULL and false, or init fails, logs go to stderr.
	bool init(const char *logfilename,bool use_slogger2);
	void uninit();

	void enable_additional_stdout(bool do_enable);

	int printf(const char *msg,...);
	int printf(const char *msg,va_list args);
	int print(const char *str);
	int print(const std::string &str);
	static int printf(void *ptr_to_log,const char *msg,...);
	static int printf(void *ptr_to_log,const char *msg,va_list args);

private:
	LogOutput() = delete;
	LogOutput(LogOutput &org) = delete;
	void operator=(LogOutput &org) = delete;

	class PD;
	PD *p;	// hide private data and keep slog2 header away from here.
};
