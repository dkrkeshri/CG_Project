#include "logoutput.h"
#include <new>
#include <stdio.h>
#include <string.h>
#include <vector>


#define BUFFERSIZE 0x1000


class LogOutput::PD
{
public:
	std::string name;
	bool slog2;
	bool additional_stdout;
	char buffer[BUFFERSIZE];
	std::vector<std::string> testmock_lines;
};


LogOutput::LogOutput(const char *name)
{
	p = new (std::nothrow) PD();
	if(!p)
		return;
	p->slog2 = false;
	p->additional_stdout = false;
	p->name = name;
}

LogOutput::~LogOutput()
{
	if(p)
	{
		uninit();
		delete p;
	}
	p = NULL;
}

bool LogOutput::init(const char *logfilename,bool use_slogger2)
{
	if(!p)	// malloc fail in c-tor?
		return false;
	return true;
}

void LogOutput::uninit()
{
	p->additional_stdout = false;
}

void LogOutput::enable_additional_stdout(bool do_enable)
{
	p->additional_stdout = do_enable;
}

int LogOutput::printf(const char *msg,...)
{
	va_list ap;
	int res;
	va_start(ap,msg);
	res = this->printf(msg,ap);
	va_end(ap);
	return res;
}

int LogOutput::printf(const char *msg,va_list args)
{
	int l;
	l = vsnprintf(p->buffer,BUFFERSIZE-1,msg,args);
	if(l<0)return l;
	// is line terminated with NL ?
	if( l+1<BUFFERSIZE && l>0 && p->buffer[l-1]!='\n' )
		p->buffer[l++]='\n';
	p->buffer[l] = 0;
	return this->print(p->buffer);
}

/**
 * The REAL print function. All others call this one.
 *
 */
int LogOutput::print(const char *str)
{
	int l;
	std::string dummy;

	l = strlen(str);
	if( l>0 && str[l-1]!='\n' )
	{
		// is not terminated by a NL. Copy to dummy, use that instead.
		dummy = str;
		dummy += "\n";
		l = dummy.size();
		str = dummy.c_str();
	}
	// append to mock list
	std::string tmp2(str,l);
	p->testmock_lines.push_back(tmp2);
	if(p->additional_stdout)
		::printf("LOGOUTPUT:  %s\n",tmp2.c_str());
	return l;
}

int LogOutput::print(const std::string &str)
{
	return this->print(str.c_str());
}

int LogOutput::printf(void *ptr_to_log,const char *msg,...)
{
	va_list ap;
	int res;
	va_start(ap,msg);
	res = ((LogOutput*)ptr_to_log)->printf(msg,ap);
	va_end(ap);
	return res;
}

int LogOutput::printf(void *ptr_to_log,const char *msg,va_list args)
{
	return ((LogOutput*)ptr_to_log)->printf(msg,args);
}
