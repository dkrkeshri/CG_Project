#pragma once

#include <gmock/gmock.h>
#include <sys/types.h>

// This mock class mocks the dlopen, dlclose and dlsym calls.
class MockPosix
{
public:
	MOCK_METHOD2(m_dlopen,void*(const char *name,int flags));
	MOCK_METHOD1(m_dlclose,int(void *handle));
	MOCK_METHOD2(m_dlsym,void*(void *handle,const char *funcname));
	MOCK_METHOD2(m_open,int(const char *path,int oflag));
//	MOCK_METHOD3(m_open,int(const char *path,int oflag,int createflags));
	MOCK_METHOD1(m_close,int(int fd));
	MOCK_METHOD3(m_lseek,off_t(int fd,off_t offset,int whence));
	MOCK_METHOD3(m_read,ssize_t(int fd,void *buf,size_t count));
	MOCK_METHOD3(m_write,ssize_t(int fd,const void *buf,size_t count));
	MOCK_METHOD5(m_select,int(int nfds, fd_set*rdfds, fd_set*wrfds, fd_set*exfds, struct timeval *to));

	MOCK_METHOD1(m_i2c_close,void(int));
	MOCK_METHOD1(m_i2c_open,int(void *));
	MOCK_METHOD3(m_i2c_read,int(int, void *, uint32_t));
	MOCK_METHOD3(m_i2c_set_bus_speed,int(int, uint32_t, uint32_t *));
	MOCK_METHOD3(m_i2c_set_slave_addr,int(int, uint32_t, uint32_t));
	MOCK_METHOD3(m_i2c_write,int(int, void *, uint32_t));
	MOCK_METHOD5(m_i2c_combined_writeread,int(int, void *, uint32_t, void *, uint32_t));

};

extern MockPosix *glob_mock_posix;

MockPosix *pf_instance();
void pf_instance_destroy();


// And the C-style functions to link
extern "C" {


// functions for lib-load
void *mockfunc_dlopen(const char *name,int flags);
int mockfunc_dlclose(void *handle);
void *mockfunc_dlsym(void *handle,const char *funcname);

// functions for file read/write
int mockfunc_open(const char *path,int oflag);
int mockfunc_close(int fd);
int mockfunc_lseek(int fd,off_t offset,int whence);
ssize_t mockfunc_read(int fd,void *buf,size_t count);
ssize_t mockfunc_write(int fd,const void *buf,size_t count);
int mockfunc_select(int nfds, fd_set*rdfds, fd_set*wrfds, fd_set*exfds, struct timeval *to);

// functions for i2c
int mockfunc_i2c_open(void *devname);
void mockfunc_i2c_close(int fd);
int mockfunc_i2c_set_slave_addr(int fd, uint32_t addr, uint32_t fmt);
int mockfunc_i2c_set_bus_speed(int fd, uint32_t speed, uint32_t *ospeed);
int mockfunc_i2c_write(int fd, void *buf, uint32_t len);
int mockfunc_i2c_read(int fd, void *buf, uint32_t len);
int mockfunc_i2c_combined_writeread(int fd, void *wbuff, uint32_t wlen, void *rbuff, uint32_t rlen);

// for read(), to supply data the mocked calls shall return.
void mockfunc_read_provide_data(const void *data,int count,int for_fd);
// for write(), to get the data that was sent to the mock.
int mockfunc_write_get_data(void *data,int buffersize,int *out_was_for_fd);
}

