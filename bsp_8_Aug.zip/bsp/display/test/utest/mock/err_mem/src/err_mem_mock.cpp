#include "err_mem_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_err_mem_mock *ut_err_mem_mock_ptr;

void vWritePrintfErrmem(const char* buf)
{
    if (NULL == ut_err_mem_mock_ptr) {
            throw std::invalid_argument(NULL_PTR_ERR);
        }
    ut_err_mem_mock_ptr->vWritePrintfErrmem(buf);

}
