#ifndef __H_ERR_MEM_HEADER_H__
#define __H_ERR_MEM_HEADER_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void vWritePrintfErrmem(const char* fmt);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_ERR_MEM_HEADER_H__*/

