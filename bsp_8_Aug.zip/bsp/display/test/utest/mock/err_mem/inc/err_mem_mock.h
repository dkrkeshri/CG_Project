#ifndef __H_ERR_MEM_MOCK_H__
#define __H_ERR_MEM_MOCK_H__

#include <gmock/gmock.h>
#include "err_mem_header.h"

class UT_err_mem_mock
{
    public:
        UT_err_mem_mock() {}
        virtual ~UT_err_mem_mock() {}
        MOCK_METHOD1(vWritePrintfErrmem,void (const char*));
};

extern UT_err_mem_mock *ut_err_mem_mock_ptr;

#endif /*__H_ERR_MEM_MOCK_H__*/


