#ifndef __H_RESMGR_HEADER_H__
#define __H_RESMGR_HEADER_H__

#include<stdint.h>
#include"ipc_header.h"
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#if 0
typedef struct _io_notify {
    uint16_t                    type;
    uint16_t                    combine_len;
    int32_t                     action;
    int32_t                     flags;
    struct ut_sigevent          event;

    /* Following fields only valid if (flags & _NOTIFY_COND_EXTEN) */
    int32_t                     mgr[2];    /* For use by manager */
    int32_t                     flags_extra_mask;
    int32_t                     flags_exten;
    int32_t                     nfds;
    int32_t                     fd_first;
    int32_t                     nfds_ready;
    int64_t                     timo;
    /* struct pollfd            fds[nfds]; */
}io_notify_t;
#endif
/*typedef struct _resmgr_context
{
   int rcvid;
   struct _msg_info info;
   int id;
   int reserved;
   int status;
   int offset;
   int size;
} resmgr_context_t;*/

/*dispatch_t* dispatch_create();
void iofunc_func_init(unsigned nconnect, resmgr_connect_funcs_t* connect, unsigned nio, resmgr_io_funcs_t* io);
void iofunc_attr_init(iofunc_attr_t* attr, mode_t mode, iofunc_attr_t* dattr, struct _client_info* info);
int resmgr_attach(dispatch_t* dpp, resmgr_attr_t* attr, const char* path, enum _file_type file_type,
      unsigned flags, const resmgr_connect_funcs_t* connect_funcs, const resmgr_io_funcs_t* io_funcs,
      RESMGR_HANDLE_T* handle);
dispatch_context_t* dispatch_context_alloc(dispatch_t* dpp);
dispatch_context_t* dispatch_block(dispatch_context_t* ctp);
int dispatch_handler(dispatch_context_t* ctp);
int iofunc_open_default(resmgr_context_t* ctp, io_open_t* msg, iofunc_attr_t* attr, void* extra);
void* resmgr_ocb(resmgr_context_t* ctp);
int iofunc_write_verify(resmgr_context_t* ctp, io_write_t* msg, iofunc_ocb_t* ocb, int* nonblock);
int IO_WRITE_GET_NBYTES(io_write_t* msg);
int IO_SET_WRITE_NBYTES(resmgr_context_t* ctp, int nbytes);
int RESMGR_NPARTS(int nparts);
int resmgr_msgread(resmgr_context_t* ctp, void* msg, int size, int offset);*/



#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif/* __H_RESMGR_HEADER_H__*/


