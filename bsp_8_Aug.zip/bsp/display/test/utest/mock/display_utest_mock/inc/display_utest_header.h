#ifndef __H_DISPLAY_UTEST_HEADER_H__
#define __H_DISPLAY_UTEST_HEADER_H__

#include <sys/types.h>
#include <inttypes.h>
#define EINVAL 22
#define ENOMEM 12
/*************************PM_STATES(dcmd_pm.h)***********************************************/
#define _DCMD_MISC                   0x05 //from devctl.h
#ifndef __DIOT
#define __DIOT(class, cmd, data)    (int)((sizeof(data)<<16) + ((class)<<8) + (cmd) + _POSIX_DEVDIR_TO)
#endif
#define DCMD_PM_REGISTER        __DIOT (_DCMD_MISC, 0, struct pm_register_s )
#define DCMD_PM_ACK             __DIOT (_DCMD_MISC, 1, struct pm_ack_s )
#define PM_MAX_NAME_LEN (64)
//Helper macro to properly initialize the pm_register_s structure
#define INIT_PM_REGISTER_STRUCT(__init) \
        (__init)->pulse_codes[PM_STATE_PREPARE] = -1;\
        (__init)->pulse_codes[PM_STATE_SUSPEND] = -1;\
        (__init)->pulse_codes[PM_STATE_RESUME] = -1;\
        (__init)->pulse_codes[PM_STATE_COMPLETE] = -1;\
        (__init)->pulse_codes[PM_STATE_VOLT_NOK] = -1;\
        (__init)->pulse_codes[PM_STATE_VOLT_OK] = -1;\
        (__init)->priority = (enum pm_prio_level)-1;\
        (__init)->chid = -1;\
        (__init)->flags = 0;\
        (__init)->name[0] = '\0';
#define _POSIX_DEVDIR_TO        0x80000000

enum pm_prio_level {
    PM_PRIO_LEVEL_0,
    PM_PRIO_LEVEL_1,
    PM_PRIO_LEVEL_2,
    PM_PRIO_LEVEL_3,
    PM_PRIO_LEVEL_4,
    PM_PRIO_LEVEL_5,
    PM_PRIO_LEVEL_6,
    PM_PRIO_LEVEL_7,
    PM_PRIO_LEVEL_8,
    PM_PRIO_LEVEL_9,
    PM_PRIO_LEVEL_MAX,
};

enum pm_state {
    PM_STATE_PREPARE,
    PM_STATE_SUSPEND,
    PM_STATE_RESUME,
    PM_STATE_COMPLETE,
    PM_STATE_VOLT_NOK,
    PM_STATE_VOLT_OK,
    PM_STATE_MAX,
};

struct pm_register_s {
    char name [PM_MAX_NAME_LEN];
    int8_t pulse_codes [ PM_STATE_MAX ];
    enum pm_prio_level priority;
    int chid;
#define PM_FLAG_NO_SUSPEND       (0x00000001)
    int flags ;
};

struct pm_ack_s {
    int rc;
    enum pm_state state;
};
/**************************PM_STATES*********************************************/

/******************************neutrino.h************************************************/
/*
 * Thread Control commands
 */
#define _NTO_TCTL_IO                                    14
#define _NTO_TCTL_ONE_THREAD_HOLD   8
#define _NTO_TCTL_ONE_THREAD_CONT   9
#define _NTO_INTR_FLAGS_PROCESS 0x04u
#define _NTO_INTR_FLAGS_TRK_MSK 0x08u
#define _NTO_CHF_UNBLOCK 0x0002u

typedef struct ut_sched_param
{
    int32_t
        sched_priority;
    int32_t sched_curpriority;
}sched_param_t;

/*********************************neutrino.h*************************************************/

/**********************************procmgr.h*************************************************/
#define PROCMGR_ADN_ROOT        0x10000000u
#define PROCMGR_AOP_ALLOW       0x00020000u
#define PROCMGR_AID_INTERRUPT   29u /* SR: interrupt */
#define PROCMGR_AID_MASK        0xffffu
#define PROCMGR_AID_EOL         PROCMGR_AID_MASK
/**********************************procmgr.h************************************************/

/*************************************list.h***********************************************/

#define LIST_INITIAL_VALUE(list) { &(list), &(list) }
typedef uintptr_t addr_t;
#define containerof(ptr, type, member) \
    ((type *)((addr_t)(ptr) - offsetof(type, member)))
#define list_for_every_entry(list, entry, type, member) \
    for((entry) = containerof((list)->next, type, member);\
        &(entry)->member != (list);\
        (entry) = containerof((entry)->member.next, type, member))

struct list_node {
        struct list_node *prev;
        struct list_node *next;
};

/************************************list.h**********************************************/

/**********************************common***********************************************/
#define uint32 uint32_t
#define uint8 uint8_t
#define FALSE  0
#define TRUE    1
#define EOK                     0
#define boolean bool
/**********************************common********************************************/
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int ThreadCtl(int cmd, void* data);
int devctl( int filedes, int dcmd, void * dev_data_ptr, size_t n_bytes, int * dev_info_ptr );
size_t strlcpy(char *dst, const char *src, size_t size);//need to add string.h
void list_add_tail(struct list_node *list, struct list_node *item);//list.h
int procmgr_ability(pid_t __pid, unsigned __ability, ...);
int SchedGet( pid_t pid,int tid,struct ut_sched_param *param );
int mock_getopt(int argc, char  **argv, const char *optstring);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_DISPLAY_UTEST_HEADER_H__*/
