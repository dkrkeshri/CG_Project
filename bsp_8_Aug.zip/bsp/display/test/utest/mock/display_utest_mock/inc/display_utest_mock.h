#ifndef __H_DISPLAY_UTEST_MOCK_H__
#define __H_DISPLAY_UTEST_MOCK_H__

#include <gmock/gmock.h>
#include "display_utest_header.h"

class UT_display_utest_mock
{
    public:
        UT_display_utest_mock() {}
        virtual ~UT_display_utest_mock() {}
        MOCK_METHOD2(ThreadCtl,int(int, void*));
        MOCK_METHOD5(devctl, int( int, int, void *, size_t, int * ));
        MOCK_METHOD3(strlcpy, size_t(char *, const char *, size_t));
        MOCK_METHOD2(list_add_tail, void(struct list_node *, struct list_node *));
        MOCK_METHOD3(SchedGet, int ( pid_t, int, struct ut_sched_param *));
        MOCK_METHOD3(mock_getopt, int(int, char  **, const char *));
};

extern UT_display_utest_mock *ut_display_utest_mock_ptr;

#endif /*__H_DISPLAY_UTEST_MOCK_H__*/
