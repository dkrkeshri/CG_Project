#include "display_utest_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_display_utest_mock *ut_display_utest_mock_ptr;

int ThreadCtl(int cmd, void *data)
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->ThreadCtl(cmd, data);
}

int devctl( int filedes, int dcmd, void * dev_data_ptr, size_t n_bytes, int * dev_info_ptr )
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->devctl( filedes, dcmd, dev_data_ptr, n_bytes, dev_info_ptr );
 }

size_t strlcpy(char *dst, const char *src, size_t size)
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->strlcpy(dst, src, size);
}

void list_add_tail(struct list_node *list, struct list_node *item)
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->list_add_tail(list, item);
}

int procmgr_ability(pid_t __pid, unsigned __ability, ...)
{
    return 0;
}

int SchedGet( pid_t pid,int tid,struct ut_sched_param *param )
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->SchedGet(pid, tid, param);
}

int mock_getopt(int argc, char  **argv, const char *optstring)
{
    if (NULL == ut_display_utest_mock_ptr) {
                throw std::invalid_argument(NULL_PTR_ERR);
        }
    return ut_display_utest_mock_ptr->mock_getopt(argc, argv, optstring);
}
