#include "interrupt_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_interrupt_mock *ut_interrupt_mock_ptr;

int InterruptAttachEvent(int intr, const struct sigevent *event, unsigned flags)
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptAttachEvent(intr, event, flags);
}

int InterruptWait(int flags, const uint64_t * timeout )
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptWait(flags,timeout);
}

int InterruptUnmask(int intr, int id)
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptUnmask(intr, id);
}

int InterruptMask(int intr, int id)
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptMask(intr, id);
}

void InterruptLock( intrspin_t* spinlock )
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptLock(spinlock);
}

void InterruptUnlock( intrspin_t* spinlock )
{
    if (NULL == ut_interrupt_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_interrupt_mock_ptr->InterruptUnlock(spinlock);
}
