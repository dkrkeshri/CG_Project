#ifndef __H_INTERRUPT_HEADER_H__
#define __H_INTERRUPT_HEADER_H__

typedef struct intrspin {
	volatile unsigned	value;
} intrspin_t;

#ifdef __cplusplus
extern "C" {
    #endif /* __cplusplus */

    int InterruptAttachEvent(int intr, const struct sigevent *event, unsigned flags);
    int InterruptWait( int flags, const uint64_t * timeout );
    int InterruptUnmask(int intr, int id);
    int InterruptMask(int intr, int id);
    void InterruptLock( intrspin_t* spinlock );//sys/neutrino.h
    void InterruptUnlock( intrspin_t* spinlock );//sys/neutrino.h

    #ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /*__H_INTERRUPT_HEADER_H__*/
