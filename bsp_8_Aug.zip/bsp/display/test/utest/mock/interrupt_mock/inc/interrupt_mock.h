#ifndef __H_INTERRUPT_MOCK_H__
#define __H_INTERRUPT_MOCK_H__

#include <gmock/gmock.h>
#include "interrupt_header.h"

class UT_interrupt_mock
{
    public:
        UT_interrupt_mock() {}
        virtual ~UT_interrupt_mock() {}
        MOCK_METHOD3(InterruptAttachEvent, int (int, const struct sigevent*, unsigned));
        MOCK_METHOD2(InterruptWait,int( int, const uint64_t*));
        MOCK_METHOD2(InterruptUnmask, int(int, int));
        MOCK_METHOD2(InterruptMask, int(int,int));
        MOCK_METHOD1(InterruptLock, void(intrspin_t*));
        MOCK_METHOD1(InterruptUnlock, void(intrspin_t*));
};

extern UT_interrupt_mock *ut_interrupt_mock_ptr;

#endif /*__H_INTERRUPT_MOCK_H__*/
