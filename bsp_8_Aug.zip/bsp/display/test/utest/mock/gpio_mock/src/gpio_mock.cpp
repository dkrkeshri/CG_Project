#include "gpio_mock.h"
#include <stdexcept>
#include <string>

#define NULL_PTR_ERR std::string(__func__) + ": pointer to the class is NULL"

UT_gpio_mock *ut_gpio_mock_ptr;

int gpio_open(const char *dev_name)
{
    if (NULL == ut_gpio_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_gpio_mock_ptr->gpio_open(dev_name);
}

int32_t gpio_set_config(int32_t fd, uint32_t gpio, uint32_t cfg_mask, uint32_t cfg) {
    if (NULL == ut_gpio_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_gpio_mock_ptr->gpio_set_config(fd, gpio, cfg_mask, cfg);
}

int gpio_set_pin(int fd, uint32_t gpio, uint32_t val)
{
    if (NULL == ut_gpio_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_gpio_mock_ptr->gpio_set_pin(fd, gpio, val);
}

int gpio_set_interrupt_cfg (int fd,  uint32_t gpio, uint32_t trigger,void *event)
{
    if (NULL == ut_gpio_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_gpio_mock_ptr->gpio_set_interrupt_cfg (fd,  gpio, trigger, event);
}

int gpio_get_interrupt_cfg (int fd,  uint32_t gpio, uint32_t *irq_number)
{
    if (NULL == ut_gpio_mock_ptr) {
        throw std::invalid_argument(NULL_PTR_ERR);
    }
    return ut_gpio_mock_ptr->gpio_get_interrupt_cfg (fd, gpio, irq_number);
}
