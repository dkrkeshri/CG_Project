#ifndef __H_GPIO_MOCK_H__
#define __H_GPIO_MOCK_H__

#include <gmock/gmock.h>
#include "gpio_header.h"

class UT_gpio_mock
{
    public:
        UT_gpio_mock() {}
        virtual ~UT_gpio_mock() {}
        MOCK_METHOD1(gpio_open, int(const char *));
        MOCK_METHOD4(gpio_set_config, int32_t(int, uint32_t, uint32_t, uint32_t));
        MOCK_METHOD3(gpio_set_pin, int(int, uint32_t, uint32_t));
        MOCK_METHOD4(gpio_set_interrupt_cfg, int(int,  uint32_t, uint32_t, void *));
        MOCK_METHOD3(gpio_get_interrupt_cfg, int(int,  uint32_t, uint32_t *));
};

extern UT_gpio_mock *ut_gpio_mock_ptr;

#endif/*__H_GPIO_MOCK_H__*/

