#ifndef __H_GPIO_HEADER_H__
#define __H_GPIO_HEADER_H__

#include "input_utest_header.h"

#define GPIO_INTERRUPT_TRIGGER_FALLING   0x4
#define GPIO_INTERRUPT_TRIGGER_HIGH        0x1
#define GPIO_SUCCESS                0
#define GPIO_FAIL                   -1
#define GPIO_INPUT                  0
#define GPIO_PULL_UP                0x00000030
#define GPIO_STRENGTH_2MA           0x00000001
#define GPIO_FUNC_MASK              0x000F0000
#define GPIO_FUNC(func)             (GPIO_FUNC_MASK & ((func) << 0x10))
#define GPIO_PIN_CFG(dir,pull,drive,func) (dir | pull | drive | GPIO_FUNC(func))

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int gpio_open(const char *dev_name);
int32_t gpio_set_config(int32_t fd, uint32_t gpio,uint32_t cfg_mask, uint32_t cfg);
int gpio_set_pin(int fd, uint32_t gpio, uint32_t val);
int gpio_set_interrupt_cfg (int fd,  uint32_t gpio, uint32_t trigger,void *event);
int gpio_get_interrupt_cfg (int fd,  uint32_t gpio, uint32_t *irq_number);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*__H_GPIO_HEADER_H__*/

