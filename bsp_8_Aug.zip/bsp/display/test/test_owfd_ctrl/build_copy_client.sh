#!/bin/bash

# compile the testprogram, copy it to the target and run it.

DR=`pwd`
DR=`realpath ${DR}`

#build the library
cd ../../api/public/owfd_ctrl_lib/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of library failed. 1>&2
  exit 1
fi
cd ../../api/public/owfd_ctrl_lib/
make install
cd ${DR}

#build the testprogram
cd ./testprog/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of testprogram. 1>&2
  exit 1
fi

#check if target is reachable
ping -c 2 -i 0.25 -W 0.2 -w 1 192.168.211.100
RES=$?
if [ $RES -ne 0 ] ; then
  echo 192.168.211.100 not reachable
    exit 1
fi

# copy to the target

scp ./testprog/nto-aarch64-o.le/openwfdcmd-ctl root@192.168.211.100:/tmp/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(first).' 1>&2
  exit 1
fi
scp ../../../../../qcom/qcom_qnx/apps/qnx_ap/install/aarch64le/lib/libowfd_ctrl_lib.so.1 root@192.168.211.100:/lib64/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(second).' 1>&2
  exit 1
fi

ssh root@192.168.211.100 'cd /tmp/;echo RUN;./openwfdcmd-ctl -o online;echo;echo;sleep 0.25'

