#!/bin/bash

# compile the daemon process and copy it to the target.

DR=`pwd`
DR=`realpath ${DR}`

#build the library
cd ../../api/lib_tdaemon/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of library failed. 1>&2
  exit 1
fi
cd ../../api/lib_tdaemon/
make install
cd ${DR}

# build the daemon
cd ../../owfd_ctrl/
make
RES=$?
cd ${DR}
if [ $RES -ne 0 ] ; then
  echo make of daemon failed. 1>&2
  exit 1
fi

#check if target is reachable
ping -c 2 -i 0.25 -W 0.2 -w 1 192.168.211.100
RES=$?
if [ $RES -ne 0 ] ; then
  echo 192.168.211.100 not reachable
    exit 1
fi

# copy to the target

scp ../../owfd_ctrl/nto-aarch64-o.le/owfd_ctrl ./sample_config_owfd_ctrl.json root@192.168.211.100:/tmp/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(first).' 1>&2
  exit 1
fi
scp ../../../../../qcom/qcom_qnx/apps/qnx_ap/install/aarch64le/lib/liblib_tdaemon.so.1 root@192.168.211.100:/lib64/
if [ $? -ne 0 ] ; then
  echo 'scp to target failed(second).' 1>&2
  exit 1
fi

echo -e '\n'
echo on the Target, start with:
echo -e "cd /tmp/;./owfd_ctrl -ddc sample_config_owfd_ctrl.json"

