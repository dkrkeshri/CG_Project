#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libowfdctrl.h"

#define DEF_DEVNODE_NAME_STATUS "/dev/vcd/openwfd-commander/status"
#define DEF_DEVNODE_NAME_CONTROL "/dev/vcd/openwfd-commander/control"


char ctrl_node_name[256] = {0};
char stat_node_name[256] = {0};


static void show_help()
{
	printf("test_owfd_ctrl - Control wake-up signals for owfd units\n");
	printf(" -h  - show this message\n");
	printf(" -c <ctrl-node>  - select resmgr control node to use.\n");
	printf(" -l  - list displays to control\n");
	printf(" -d  - display to control.\n");
	printf(" -q  - check online/offline status\n");
	printf(" -o <online | offline> - move service to online / offline\n");
	printf(" -p  <on | off> - set the power of display (chosen -p)\n");
	printf(" -v  - enable verbose output\n");
	printf("\n");
}

static int example_list_displays()
{
	char *info;
	int handle;
	int ret;

	handle = owfdctrl_status_open(stat_node_name);
	if(handle<0)
	{
		fprintf(stderr,"Could get access to status devnode. err=%d\n",(int)handle);
		return 1;
	}

	ret = owfdctrl_status_get(handle,"list-displays",&info);
	if(ret)
	{
		fprintf(stderr,"Couldn't request list of displays\n");
		return 1;
	}

	printf("%s\n", info);

	free(info);
	return 0;
}

static int example_query_online_mode()
{
	char *online;
	int handle;
	int ret;

	handle = owfdctrl_status_open(stat_node_name);
	if(handle<0)
	{
		fprintf(stderr,"Could get access to status devnode. ret=%d.\n",(int)handle);
		return 1;
	}


	ret = owfdctrl_status_get(handle, "online", &online);
	if(ret)
	{
		fprintf(stderr,"Couldn't request status of the service. retcode = %d.\n",ret);
		return 1;
	}

	printf("%s\n",online);

	free(online);
	return 0;
}

static int example_set_online(char onlinestate)
{
	char *cmd_value;
	int ctrl_handle;
	int ret;

	cmd_value = ( onlinestate ? "1" : "0" );

	ctrl_handle = owfdctrl_ctrl_open(ctrl_node_name);
	if(ctrl_handle<0)
	{
		fprintf(stderr,"Could get access to control devnode, errno=%d.\n",(int)errno);
		return 1;
	}

	ret = owfdctrl_ctrl_set(ctrl_handle, "online", cmd_value);
	if(ret)
	{
		fprintf( stderr , "Couldn't switch to %s\n" , onlinestate?"online":"offline" );
		return 1;
	}
	return 0;
}

static int example_set_power(const char *displayname,char powerstate)
{
	char *cmd_value;
	int ctrl_handle;
	int ret;

	cmd_value = ( powerstate ? "on" : "off" );

	ctrl_handle = owfdctrl_ctrl_open(ctrl_node_name);
	if(ctrl_handle<0)
	{
		fprintf(stderr,"Could get access to control devnode, errno=%d.\n",(int)errno);
		return 1;
	}

	ret = owfdctrl_ctrl_set_power(ctrl_handle,displayname,powerstate);
	if(ret)
	{
		fprintf( stderr , "Couldn't set powerstate of display '%s' to %s\n" , displayname , cmd_value );
		return 1;
	}
	return 0;
}

static char opt_process_nodename(const char *nam)
{
	const char *e;

	// empty?
	if( !nam || *nam!='/' )
	{
		fprintf(stderr,"nodename shall start with a slash.\n");
		return 0;
	}
	// find end.
	for(e=nam;*e;e++){}

	// if the name ends with '/status' or with '/control', remove that, it will be added again.
	if( (e-nam)>=8 && !strcmp(e-7,"/status") )
		e-=6;
	else if( (e-nam)>=9 && !strcmp(e-8,"/control") )
		e-=7;
	else if( e[-1]=='/' )
		e-=0;
	else{
		fprintf(stderr,"nodename shall end with /status or /control, or a slash. They will be added.\n");
		return 0;
	}

	if( (e-nam)+10 >= sizeof(ctrl_node_name) )
	{
		fprintf(stderr,"nodename too long\n");
		return 0;
	}

	memcpy(ctrl_node_name,nam,e-nam);
	memcpy(stat_node_name,nam,e-nam);
	strcpy(ctrl_node_name+(e-nam),"control");
	strcpy(stat_node_name+(e-nam),"status");

	return 1;
}


int main (int argc, char *const * argv)
{
	char do_set_online = 0;
	char do_query_online = 0;
	char do_set_power = 0;
	char powerstate = 0;
	const char *displayname = NULL;
	char *new_online = NULL;
	int opt;
	int ret;

	while(1)
	{
		opt = getopt(argc, argv, "hc:ls:qo:d:p:");
		if (opt < 0)
			break;
		switch (opt)
		{
		case 'h':
			show_help();
			return 0;

		case 'l':
			example_list_displays();
			return 0;

		case 'c':
			if(!opt_process_nodename(optarg))
				return 1;
			break;

		case 'q':
			do_query_online = 1;
			break;

		case 'o':
			do_set_online = 1;
			new_online = optarg;
			if( strncmp(new_online,"on",2) && strncmp(new_online,"off",3) )
			{
				fprintf(stderr,"invalid word for online-mode. Use 'online' or 'offline'.\n");
				return 1;
			}
			break;

		case 'p':
			do_set_power = 1;
			powerstate = 0;
			if( strncmp(optarg,"on",2) && strncmp(optarg,"off",3) )
			{
				fprintf(stderr,"invalid word for power-mode. Use 'on' or 'off'.\n");
				return 1;
			}
			if( !strncmp(optarg,"on",2) )
				powerstate = 1;
			break;

		case 'd':
			displayname = optarg;
			break;

		default:
			break;
		}
	}

	if(!ctrl_node_name[0])
	{
		fprintf(stderr,"no device node given. Specify using -c.\n");
		return 1;
	}

	if( do_set_online )
	{
		ret = example_set_online( strncmp(new_online,"on",2)==0 );
		if(ret)return ret;
	}

	if( do_set_power )
	{
		if(!displayname)
		{
			fprintf(stderr,"need to name a display to set online status (option -d)\n");
			return 1;
		}
		ret = example_set_power( displayname , powerstate );
		if(ret)return ret;
	}


	if( do_query_online )
	{
		ret = example_query_online_mode();
		if(ret)return ret;
	}

	// ..... todo: all of it.

	return 0;
}
