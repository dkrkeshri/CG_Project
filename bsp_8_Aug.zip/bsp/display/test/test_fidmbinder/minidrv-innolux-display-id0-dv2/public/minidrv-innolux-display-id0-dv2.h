/* FILE: minidrv-innolux-display-id0-dv2.h
 *  SW-COMPONENT: minidriver component for Innolux 11.34"

 * DESCRIPTION: Deliver a minimal library that is compatible to 11.34" display
 * provides the following functionality
 * ability to link against FIDM Binder's Private API
 * ability to go online
 * ability to go offline
 * ability to return Display-ID

 * COPYRIGHT: © 2021 Robert Bosch GmbH
 *  The reproduction, distribution and utilization of this file as
 *  well as the communication of its contents to others without express
 *  authorization is prohibited. Offenders will be held liable for the
 *  payment of damages. All rights reserved in the event of the grant
 *  of a patent, utility model or design.
*/

#pragma once
/**
 * A test stub for the 'minidriver' feature of the fidm-binder
 *
 * trying out if the lib-loading works.
 *
 * The header is a copy of the template in the fidm binder's folder
 * Only this comment block is changed.
 *
 */
#include <stdint.h>

#ifdef  __cplusplus
extern "C" {
#endif


/**
 * @struct minidrv_i2c_access.
 * @brief This struct is passed in to the open() function
 * to allow the minidriver to do I2C IO.
 * @return all functions return 0 on success.
 */
typedef struct minidrv_i2c_access
{
    int key; // use as key in other functions.
    int (*read)(int key, uint16_t count, void *buffer);
    int (*write)(int key, uint16_t count, const void *buffer);
    int (*writeread)(int key, uint16_t w_count, const void *w_buffer,
         uint16_t r_count, void *r_buffer);
} minidrv_i2c_access;

/**
 * @struct minidrv_cfg_access
 * @brief This struct is passed in to the open() function to allow the
 * minidriver to get extra config data.
 * The config is a string:string storage found in the display config section
 * named 'extra' of the FIDM-binder configuration of the display.
 * @return The function returns 0 on success.
 */
typedef struct minidrv_cfg_access
{
    int key; /* use as key in other functions */
    int (*get_own_name)(int key, char *out_value, int value_buffersize);
    int (*get_extra_config)(int key, const char *configitem_key, char *out_value,
         int value_buffersize);
} minidrv_cfg_access;

/* functions */

/**
 * @fn minidriver_iface_open
 * @brief This is called to open one instance of a display.
 * @param pointer of type minidrv_cfg_access as first argument.
 * @param pointer of type minidrv_i2c_access as second argument.
 * @return Return some void* as handle to the other functions.
 * Returning NULL indicates failure to open.
 * Note, that display minidrivers shall open in 'offline'
 * mode, and not yet attempt to talk to the display.
 */
void *minidriver_iface_open(const minidrv_cfg_access *conf_accessor,
                            const minidrv_i2c_access *i2c_accessor);

/**
 * @fn minidriver_iface_close.
 * @brief This is called to close a display instance.
 * @return None.
 */
void minidriver_iface_close(void *hdl);

/**
 * @fn minidriver_iface_get_display_id
 * @brief This is called to get the display_id.
 * @return OnSucess returns 0
 *         OnFailure the function shall return non-zero and also fill in
 *         some errorstring in the reply.
 */
int minidriver_iface_get_display_id(void *hdl, int *display_id);

/**
 * @fn minidriver_iface_command
 * @brief this is a generic 'command' function. The functions might come from
 * the config of an instance manager talking through the FIDM binder.
 * @param *hdl of type void.
 * @param *command as of type char.
 * @param *arg as of type const char.
 * @param *replybuffer of type char.
 * @param buffersize of type int.
 * @return interger value.
 */
int minidriver_iface_command(void *hdl, const char *command,const char *arg,
                             char *replybuffer, int buffersize);

/**
 * @fn minidriver_iface_get
 * @brief This is a generic get-some-variable call.
 * @param *hdl of type void.
 * @param *arg as of type const char.
 * @param *buffer as of type const char.
 * @param buffersize of type int.
 * @return interger value.
 */
int minidriver_iface_get(void *hdl, const char *arg, char *buffer,
                         int buffersize);

/**
 * @fn  minidriver_iface_to_online
 * @brief Try to change the display to online state.
 * @param *hdl of type void.
 * @param *replybuffer as of type char.
 * @param buffersize of type int.
 * @return OnSucess returns 0
 *         OnFailure the function shall return non-zero and also fill
 *         in some errorstring in the reply.
 */
int minidriver_iface_to_online(void *hdl, char *replybuffer, int buffersize);

/**
 * @fn minidriver_iface_to_offline
 * @brief Try to change the display to offline state.
 * @param *hdl of type void.
 * @param *replybuffer as of type char.
 * @param buffersize of type int.
 * @return OnSucess returns 0
 *         OnFailure the function shall return non-zero and also fill in some
 *         errorstring in the reply.
 */
int minidriver_iface_to_offline(void *hdl, char *replybuffer, int buffersize);

/**
 * @fn minidriver_get_last_error
 * @brief optional function: Get a clear reason of why the last call failed.
 * @param *hdl of type void.
 * @param *replybuffer as of type char.
 * @param buffersize of type int.
 * @return OnSucess returns 0
 *         OnFailure the function shall return non-zero and also fill in some
 *         errorstring in the reply.
 */
int minidriver_get_last_error(void *hdl, char *replybuffer, int buffersize);

/**
 * @fn minidriver_lib_init
 * @brief This function is optional.
 * If it is there, it is called once when loading the lib.
 *  it is not called on each display instance.
 * @return integer value.
 */
int minidriver_lib_init();

/**
 * @fn minidriver_lib_init
 * @brief This function, if exported, is called before unloading the lib.
 * @return None.
 */
void minidriver_lib_close();


#ifdef  __cplusplus
}
#endif

