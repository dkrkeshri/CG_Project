/* FILE: libmain.c
 *  SW-COMPONENT: minidriver component for Innolux 11.34"
 *
 * DESCRIPTION: Deliver a minimal library that is compatible to 11.34" display.
 * provides the following functionality.
 * ability to link against FIDM Binder's Private API
 * ability to go online
 * ability to go offline
 * ability to return Display-ID
 *
 * COPYRIGHT: © 2021 Robert Bosch GmbH
 *  The reproduction, distribution and utilization of this file as
 *  well as the communication of its contents to others without express
 *  authorization is prohibited. Offenders will be held liable for the
 *  payment of damages. All rights reserved in the event of the grant
 *  of a patent, utility model or design.
 */

#include <errno.h>
#include <inttypes.h>
#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "minidrv-innolux-display-id0-dv2.h"

#define DISPLAY_ID_ADDR 0x5

static int globalvar = 0;

typedef struct tmini
{
    minidrv_i2c_access c_i2c;
    minidrv_cfg_access c_cfg;
    char is_online;
    char our_conf_name[64];
    char error_reason[256];
    int expected_display_id;
} tmini;

static int minidriver_iface_read_display_id(struct tmini *s,
                                            int *display_id);

void *minidriver_iface_open(const minidrv_cfg_access *conf_accessor,
                            const minidrv_i2c_access *i2c_accessor)
{
    struct tmini *s;
    char valbuf[64];
    int ret;

    s = (struct tmini*)calloc(1, sizeof(*s));
    if(!s)
    {
        return NULL;
    }

    s->c_i2c = *i2c_accessor;
    s->c_cfg = *conf_accessor;
    s->our_conf_name[0] = 0;
    s->c_cfg.get_own_name(s->c_cfg.key, s->our_conf_name,
                          sizeof(s->our_conf_name));
    printf("minidriver for innolux 11.34, display-name '%s'\n",
           s->our_conf_name);

    ret = s->c_cfg.get_extra_config(s->c_cfg.key, "display-id", valbuf,
                                    sizeof(valbuf));
    if(!ret)
    {
        printf("Display ID: '%s'\n", valbuf);

    }

    s->expected_display_id = strtol(valbuf, NULL, 10);
    if(s->expected_display_id < 0 || s->expected_display_id > 255)
    {
            free(s);
            return NULL;
    }

    return s;
}

void minidriver_iface_close(void *hdl)
{
    struct tmini *s = (struct tmini*)hdl;

    if(!s)
    {
        return;
    }
    memset(s, 0xFE, sizeof(*s));
    free(s);
}

static int minidriver_iface_read_display_id(struct tmini *s, int *display_id)
{
    int ret;
    uint8_t bytes[2] = {DISPLAY_ID_ADDR, 0}; /* register number for
                                                reading Display ID */

    s->error_reason[0] = 0;

    ret = s->c_i2c.writeread(s->c_i2c.key, 1, bytes+0, 1, bytes+1);
    if(ret)
    {
        snprintf(s->error_reason, sizeof(s->error_reason),
                 "Read display id from i2c failed");
        return -EIO;
    }

    *display_id = *(bytes+1);

    return 0;
}


int minidriver_iface_get_display_id(void *hdl, int *display_id)
{
    struct tmini *s = (struct tmini*)hdl;
    int ret;

    s->error_reason[0] = 0;

    if(!s->is_online)
    {
        snprintf(s->error_reason, sizeof(s->error_reason),
                 "display is offline");
        return -ENODEV;
    }

    ret = minidriver_iface_read_display_id(s, display_id);
    if(ret != 0)
    {
        snprintf(s->error_reason, sizeof(s->error_reason),
                 "Error Reading display id,ret=%d", ret);
        return -EIO;
    }

    return 0;
}


int minidriver_iface_command(void *hdl, const char *command, const char *arg,
                             char *replybuffer, int buffersize)
{
   return -EINVAL;
}

int minidriver_iface_get(void *hdl, const char *arg, char *buffer,
                         int buffersize)
{
   return -EINVAL;
}

int minidriver_iface_to_online(void *hdl, char *replybuffer, int buffersize)
{
    struct tmini *s = (struct tmini*)hdl;
    int ret;
    int displayid;

    if(replybuffer)
    {
        replybuffer[0] = 0;
    }
    if(!s)
    {
        return EINVAL;
    }

    ret = minidriver_iface_read_display_id(hdl, &displayid);
    if(ret)
    {
        snprintf(s->error_reason, sizeof(s->error_reason),
                 "Error getting display id");
        return -EINVAL;
    }
    if(displayid != s->expected_display_id)
    {
        snprintf(s->error_reason, sizeof(s->error_reason),
                 "Expected display-id = %d and discovered display-id = %d doesn't match",
                 s->expected_display_id,displayid);
        return -ENOSTR;
    }

    printf("switching to online.\n");

    s->is_online = 1;
    /* answer with empty replystring and success */
    if( replybuffer && buffersize >= 1 )
    {
        replybuffer[0] = 0;
    }

    return 0;
}

int minidriver_iface_to_offline(void *hdl, char *replybuffer, int buffersize)
{
    struct tmini *s = (struct tmini*)hdl;

    if(replybuffer)
    {
        replybuffer[0] = 0;
    }
    if(!s)
    {
        return EINVAL;
    }

    s->is_online = 0;
    return 0;
}

int minidriver_get_last_error(void *hdl, char *replybuffer, int buffersize)
{
    struct tmini *s = (struct tmini*)hdl;

    if( !s || !replybuffer || buffersize < 2 )
    {
        return EINVAL;
    }
    if( s->error_reason[0] )
    {
        return EBADF;       /* no data here */
    }

    s->error_reason[sizeof(s->error_reason)-1] = 0;
    int len = strlen(s->error_reason);
    if(len >= buffersize)
    {
        len = buffersize-1;
    }

    memcpy(replybuffer, s->error_reason, len);
    replybuffer[len] = 0;

    s->error_reason[0] = 0; /* is picked up. drop data*/

    return 0;
}

int minidriver_lib_init()
{
    globalvar++;
    return 0;
}

void minidriver_lib_close()
{
    globalvar--;
}



