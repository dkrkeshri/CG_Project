#pragma once
/**
 * A test stub for the 'minidriver' feature of the fidm-binder.
 *
 * trying out if the lib-loading works.
 *
 * The header is a copy of the template in the fidm binder's folder.
 * Only this comment block is changed.
 *
 */
#include <stdint.h>

#ifdef  __cplusplus
extern "C" {
#endif


// This struct is passed in to the open() function to allow the minidriver to do I2C IO.
// all functions return 0 on success.
typedef struct minidrv_i2c_access
{
	int key; // use as key in other functions.
	int (*read)(int key,uint16_t count,void *buffer);
	int (*write)(int key,uint16_t count,const void *buffer);
	int (*writeread)(int key,uint16_t w_count,const void *w_buffer,uint16_t r_count,void *r_buffer);
} minidrv_i2c_access;

// This struct is passed in to the open() function to allow the minidriver to get extra config data.
// The config is a string:string storage found in the display config section
// named 'extra' of the FIDM-binder configuration of the display.
// The function returns 0 on success.
typedef struct minidrv_cfg_access
{
	int key; // use as key in other functions.
	int (*get_own_name)(int key,char *out_value,int value_buffersize);
	int (*get_extra_config)(int key,const char *configitem_key,char *out_value,int value_buffersize);
} minidrv_cfg_access;

// functions

// This is called to open one instance of a display.
// Return some void* as handle to the other functions.
// Returning NULL indicates failure to open.
// Note, that display minidrivers shall open in 'offline'
// mode, and not yet attempt to talk to the display.
void *minidriver_iface_open(const minidrv_cfg_access *conf_accessor,const minidrv_i2c_access *i2c_accessor);

// This is called to close a display instance.
void minidriver_iface_close(void *hdl);

// This is called to get the display_id
int minidriver_iface_get_display_id(void *hdl,int *display_id);

// this is a generic 'command' function. The functions might come from
// the config of an instance manager talking through the FIDM binder.
int minidriver_iface_command(void *hdl,const char *command,const char *arg,char *replybuffer,int buffersize);

// This is a generic get-some-variable call.
int minidriver_iface_get(void *hdl,const char *arg,char *buffer,int buffersize);

// Try to change the display to online state.
// If this fails, the function shall return non-zero and also fill in some errorstring in the reply.
int minidriver_iface_to_online(void *hdl,char *replybuffer,int buffersize);

// Try to change the display to offline state.
int minidriver_iface_to_offline(void *hdl,char *replybuffer,int buffersize);

// optional function: Get a clear reason of why the last call failed.
int minidriver_get_last_error(void *hdl,char *replybuffer,int buffersize);

// optional function: Performa a software-update
int minidriver_sw_update(void *hdl,const char *param,const unsigned char *data,unsigned int datasize,void (*cb_progress)(unsigned int,void*),void *cb_ctx);


// This function is optional.
// If it is there, it is called once when loading the lib.
// it is not called on each display instance.
int minidriver_lib_init();

// This function, if exported, is called before unloading the lib.
void minidriver_lib_close();


#ifdef  __cplusplus
}
#endif

