#include "test_minidrv_if.h"
#include <errno.h>
#include <inttypes.h>
#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>


static int globalvar=0;

typedef struct tmini
{
	int dummy;
	minidrv_i2c_access c_i2c;
	minidrv_cfg_access c_cfg;
	int idlen;
	char is_online;
	char our_conf_name[64];
	char backlight_is_on;	// values 0=off, 1=on, 2=unknown
	char touch_is_on;
	char error_reason[256];
	char bIsClosing;	// hint from close() call toward the sw_update to abort. 1=close-call pending
	char bIsUpdating;	// hint to close() call that sw-update call is busy.
} tmini;

static int read_deserialzer_id(struct tmini *s,uint16_t *out_id);
static int set_backlight_enable(tmini *s,char flag);
static int set_touch_enable(tmini *s,char flag);
static int read_address_range(tmini *s,uint8_t reg_addr,int count,char *out_buffer,int buffersize);

void *minidriver_iface_open(const minidrv_cfg_access *conf_accessor,const minidrv_i2c_access *i2c_accessor)
{
	struct tmini *s;
	s = (struct tmini*)malloc(sizeof(*s));
	if(!s)
		return 0;
	memset(s,0,sizeof(*s));
	s->c_i2c = *i2c_accessor;
	s->c_cfg = *conf_accessor;
	// some dummy my-ID value, just some meddling of our memory-location.
	s->dummy = 42;
	s->our_conf_name[0]=0;
	s->c_cfg.get_own_name(s->c_cfg.key,s->our_conf_name,sizeof(s->our_conf_name));
	printf("test minidriver, display-name '%s'\n",s->our_conf_name);

	s->backlight_is_on = 2;
	s->touch_is_on = 2;

	return s;
}

void minidriver_iface_close(void *hdl)
{
	struct tmini *s = (struct tmini*)hdl;
	if(!s)
		return;
	s->bIsClosing = 1;
	// wait for sw_update to finish ?
	while(s->bIsUpdating)
		usleep(50000);	// a little ugly. Real minidriver shall set up a signal for communicating with the sw-update.

	memset(s,0xFE,sizeof(*s));
	free(s);
}

int minidriver_iface_get_display_id(void *hdl,int *display_id)
{
	struct tmini *s = (struct tmini*)hdl;

	if(!s)return EINVAL;

	s->error_reason[0] = 0;

	if(!display_id)
		return -1;

	*display_id = 221;
	return 0;
}

/**
 * @brief Minidriver's function to execute a generic command.
 *
 * This one checks for the commands 'backlight' and 'touch', to enable/disable them.
 *
 */
int minidriver_iface_command(void *hdl,const char *command,const char *arg,char *replybuffer,int buffersize)
{
	struct tmini *s = (struct tmini*)hdl;
	int l;
	printf("Minidriver DEBUG: Got command  '%s'  '%s'\n",command,arg);

	s->error_reason[0] = 0;
	// test for keyword 'backlight'
	if(!strcasecmp(command,"backlight"))
	{
		char flag = 0;
		if(!strcasecmp(arg,"on"))
			{flag = 1;}
		else if(!strcasecmp(arg,"off"))
			{flag = 0;}
		else{
			snprintf(s->error_reason,sizeof(s->error_reason),"invalid value '%s' for backlight state. Use 'on' or 'off'.",arg);
			snprintf(replybuffer,buffersize,"%s",s->error_reason);
			return EINVAL;
		}
		if(set_backlight_enable(s,flag))
		{
			snprintf(replybuffer,buffersize,"%s",s->error_reason);
			return EIO;
		}
		replybuffer[0]=0;
		return 0;
	}

	// test for keyword 'backlight'
	if(!strcasecmp(command,"touch"))
	{
		char flag = 0;
		if(!strcasecmp(arg,"enable"))
			{flag = 1;}
		else if(!strcasecmp(arg,"disable"))
			{flag = 0;}
		else{
			snprintf(s->error_reason,sizeof(s->error_reason),"invalid value '%s' for backlight state. Use 'enable' or 'disable'.",arg);
			snprintf(replybuffer,buffersize,"%s",s->error_reason);
			return EINVAL;
		}
		if(set_touch_enable(s,flag))
		{
			snprintf(replybuffer,buffersize,"%s",s->error_reason);
			return EIO;
		}
		replybuffer[0]=0;
		return 0;
	}

	// test dummy command for debugging
	if(!strncmp(command,"ping",4))
	{
		l = snprintf(replybuffer,buffersize,"pong");
		return ( (l>0&&l<buffersize) ? 0 : -1 );
	}
	return -1;
}

/**
 * @brief Minidriver's generic get-a-parameter function.
 *
 * This one implements getting values for 'backlight' and 'touch', indicating on or off.
 *
 */
int minidriver_iface_get(void *hdl,const char *arg,char *buffer,int buffersize)
{
	struct tmini *s = (struct tmini*)hdl;
	const char *val;
	printf("Minidriver DEBUG: Got get query for  '%s'\n",arg);
	if(buffersize<32)
		return EINVAL;

	// test for keyword 'backlight'
	if(!strcasecmp(arg,"backlight"))
	{
		switch(s->backlight_is_on)
		{
		case 0: val="off";break;
		case 1: val="on";break;
		default: val="unknown";break;
		}
		snprintf(buffer,buffersize,val);
		return 0;
	}

	// test for keyword 'touch'
	if(!strcasecmp(arg,"touch"))
	{
		switch(s->touch_is_on)
		{
		case 0: val="enable";break;
		case 1: val="disable";break;
		default: val="unknown";break;
		}
		snprintf(buffer,buffersize,val);
		return 0;
	}

	// field "chip-id". Reads a value using I2C and serves as sample code for other minidrivers.
	if(!strcasecmp(arg,"chip-id"))
	{
		int ret;
		ret = read_address_range(s,0xF0,6,buffer,buffersize);
		if(ret)
			return ret;
		return 0;
	}

	// dummy values, to be able to test some calls from client-lib.
	if(!strcasecmp(arg,"a"))
	{
		snprintf(buffer,buffersize,"valueA");
		return 0;
	}
	if(!strcasecmp(arg,"b"))
	{
		snprintf(buffer,buffersize,"valueB");
		return 0;
	}
	if(!strcasecmp(arg,"c"))
	{
		snprintf(buffer,buffersize,"valueC");
		return 0;
	}

	snprintf(s->error_reason,sizeof(s->error_reason),"unknown minidriver command '%s'",arg);
	snprintf(buffer,buffersize,"%s",s->error_reason);
	return EINVAL;
}

int minidriver_iface_to_online(void *hdl,char *replybuffer,int buffersize)
{
	struct tmini *s = (struct tmini*)hdl;
	int ret;
	uint16_t id;
	char valbuf[64];
	if(replybuffer)
		replybuffer[0]=0;
	if(!s)
		return EINVAL;

	// try to read the deserializer ID from the i2c bus.
	id=0;
	ret = read_deserialzer_id(s,&id);
	int len = 0;	// length of errormessage
	if(ret)
	{
		// reading of the registers failed or the values were bogus (not ascii digits)
		len = snprintf(s->error_reason,sizeof(s->error_reason),"reading device-ID on i2c failed. ret=%d.\n",ret);
	}else if(id!=928)
	{
		// reading of regs was good, but did not return not the expected value.
		len = snprintf(s->error_reason,sizeof(s->error_reason),"expecting device-ID of 928. Found %d.\n",(int)id);
		ret = EIO;
	}
	if(ret)
	{
		// failed. place errormessage in caller's buffer and exit.
		if( buffersize>0 && replybuffer )
		{
			if(len>=buffersize)len=buffersize-1;
			memcpy(replybuffer,s->error_reason,len);
			replybuffer[len]=0;
		}
		return ret;
	}
	printf("switching to online.\n");

	// testcode: try to get one of the 'extra' parameters from the config
	ret=s->c_cfg.get_extra_config(s->c_cfg.key,"testparam",valbuf,sizeof(valbuf));
	if(!ret)
	{
		printf("test: debug-extra parameter: '%s'\n",valbuf);
	}else{
		printf("test: getting extra parameter failed.\n");
	}

	s->is_online = 1;
	// answer with empty replystring and success.
	if( replybuffer && buffersize>=1 )
		replybuffer[0]=0;
	return 0;
}

int minidriver_iface_to_offline(void *hdl,char *replybuffer,int buffersize)
{
	struct tmini *s = (struct tmini*)hdl;
	if(replybuffer)
		replybuffer[0]=0;
	if(!s)
		return EINVAL;
	s->is_online = 0;
	return 0;
}

int minidriver_get_last_error(void *hdl,char *replybuffer,int buffersize)
{
	struct tmini *s = (struct tmini*)hdl;

	if( !s || !replybuffer || buffersize<2 )
		return EINVAL;

	if( s->error_reason[0] )
		return EBADF;		// no data here.

	s->error_reason[sizeof(s->error_reason)-1] = 0;
	int len = strlen(s->error_reason);
	if(len>=buffersize)
		len=buffersize-1;

	memcpy(replybuffer,s->error_reason,len);
	replybuffer[len]=0;

	s->error_reason[0] = 0;	// is picked up. drop data.

	return 0;
}

int minidriver_sw_update(void *hdl,const char *param,const unsigned char *data,unsigned int datasize,void (*cb_progress)(unsigned int,void*),void *cb_ctx)
{
	struct tmini *s = (struct tmini*)hdl;
	int ret;

	if( !s || s->bIsClosing )
		return EINVAL;

	s->bIsUpdating=1;

	if( s->bIsClosing )
		{s->bIsUpdating=0;return EINVAL;}

	printf("minidriver simulated SW-update procress.\n");
	printf("  datasize: %u kiB\n",(unsigned int)((datasize+512)>>10));
	printf("  parameter: '%s'\n",param);
	ret = 0;
	for(unsigned int i=0;i<20;i++)
	{
		if(s->bIsClosing)
			{ret=ECANCELED;break;}	// abort the update.
		usleep(9000000/20);
		unsigned int progress = (i*datasize+10)/20;
		if(cb_progress)
			cb_progress(progress,cb_ctx);
	}

	s->bIsUpdating = 0;

	return ret;
}

int minidriver_lib_init()
{
	globalvar++;
	return 0;
}

void minidriver_lib_close()
{
	globalvar--;
}


static int read_deserialzer_id(struct tmini *s,uint16_t *out_id)
{
	// get the 6 bytes of id.
	int ret,i;
	uint8_t bytes[16];
	uint16_t id;
	bytes[0] = 0xF0;	// register number for reading ID on a deserializer.
	ret = s->c_i2c.writeread(s->c_i2c.key,1,bytes+0,6,bytes+0);
	if(ret)
		return ret;
	// got 6 bytes.
	printf("got 6 bytes ID from 0xF0:  ");
	for(i=0;i<6;i++)
		printf(" 0x%02X",(unsigned int)(bytes[i]));
	printf("\n");
	// bytes 3..5 shall be in range 0x30..0x39 (ascii digits).
	id = 0xFFFF;
	// check, and if they are, convert value as int.
	for(int i=3;i<6;i++)
		if( bytes[i]<'0' || bytes[i]>'9' )
			break;
	if(i<6)
	{
		printf("..does not look like a valid ID from a deserializer.\n");
	}else{
		id = (bytes[3]-'0');
		id = id*10+(bytes[4]-'0');
		id = id*10+(bytes[5]-'0');
		printf("..looks like deser-ID %03u.\n",(unsigned int)id);
	}
	if(out_id)
		*out_id = id;
	printf("\n");
	return 0;
}

static int set_backlight_enable(tmini *s,char flag)
{
	unsigned char data[4];
	int ret;
	unsigned char reg_value;

	if( !s )
		return EINVAL;
	if( !s->is_online )
	{
		snprintf(s->error_reason,sizeof(s->error_reason),"cannot set backlight when not online");
		return EINVAL;
	}

	// on our I2C, send to register 0x1E.
	// to turn on, send 0x99, to turn off, send 0.
	reg_value = ( flag ? 0x99 : 0 );

	data[0] = 0x1E;
	data[1] = reg_value;
	ret = s->c_i2c.write(s->c_i2c.key,2,data);

	if(ret)
	{
		snprintf(s->error_reason,sizeof(s->error_reason),"Sending I2C write failed. ret=%d",ret);
		return EIO;		// sending command failed.
	}

	// now read the register back to check.
	data[0] = 0x1E;
	ret = s->c_i2c.writeread(s->c_i2c.key,1,data+0,1,data+2);
	if(ret)
	{
		snprintf(s->error_reason,sizeof(s->error_reason),"Sending I2C combined-write-read failed. ret=%d",ret);
		return EIO;	// reading back failed.
	}

	// compare
	if( data[2] != reg_value )
	{
		snprintf(
				s->error_reason ,
				sizeof(s->error_reason) ,
				"Reading back the programmed register value failed. "
					"Expected 0x%02X, got 0x%02X.\n" ,
				(unsigned int)reg_value ,
				(unsigned int)data[2]
		);
		s->backlight_is_on = 2;	// set to unknown. who knows what the backlight is doing now.
		return EIO;
	}

	s->backlight_is_on = ( flag ? 1 : 0 );

	return 0;
}

static int set_touch_enable(tmini *s,char flag)
{
	if( !s )
		return EINVAL;
	if( !s->is_online )
	{
		snprintf(s->error_reason,sizeof(s->error_reason),"cannot set touch when not online");
		return EINVAL;
	}

	// ..... todo: not implemented yet.
	if(flag)
	{
		snprintf(s->error_reason,sizeof(s->error_reason),"Enabling touch not implemented.");
		return EINVAL;
	}

	s->touch_is_on = 0;
	return 0;
}

/**
 * @brief: Function to read a stretch of bytes from I2C and output them as hexadecimal string.
 *
 * Call the 'read' function on the i2c interface we have from the open() call,
 * and write the result as a hex-string. The buffer supplied must be large enough
 * for the output string (with null-terminator).
 *
 * If the I2C read call fails or the buffer is too small, this function will fail
 * and return non-zero.
 */
static int read_address_range(tmini *s,uint8_t reg_addr,int count,char *out_buffer,int buffersize)
{
	int ret;
	int i;
	static const char hexes[16]="0123456789abcdef";

	// arguments sanity check
	if( !s || reg_addr<0 || reg_addr>=0x100 || count<1 || count>=0x80 || !out_buffer || buffersize<=(2*count) )
		return EINVAL;

	// online check
	if(!s->is_online)
		return EBADF;

	// do read. Using output buffer temprarily for binary data.
	ret = s->c_i2c.writeread(s->c_i2c.key,1,&reg_addr,count,out_buffer);
	if(ret)
		return ret;

	// convert output to hex. (backward not to overwrite bytes still to be used)
	// on function entry, buffersize way verified to be large enough for 2*count+1 bytes,
	for( i=count-1 ; i>=0 ; --i )
	{
		unsigned char b=out_buffer[i];
		out_buffer[i+i+1] = hexes[b&15];
		out_buffer[i+i+0] = hexes[b>>4];
	}
	out_buffer[count+count] = 0;
	// done
	return 0;
}
