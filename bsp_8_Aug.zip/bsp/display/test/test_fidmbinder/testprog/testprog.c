#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
//#include <sys/stat.h>

#include "libfidmbinder.h"


#define DEVNODE_NAME_STATUS "/dev/fidm-binder/display1-status"
#define DEVNODE_NAME_CONTROL "/dev/fidm-binder/display1-control"

static void show_help()
{
	printf("testprog\n");
	printf("-h  - show this message\n");
	printf("-d  - display to control with the other commands.\n");
	printf("-q  - query service online / offline status\n");
	printf("-g  - call 'get' on a parameter. (generic command to minidriver)\n");
	printf("-c  - call 'ctrl'. Needs two args. (generic command to minidriver)\n");
	printf("-u  - perform software-update.\n");
	printf("-o <online | offline> - move service to online / offline\n");
	printf("\n");
}

static int query_online_mode()
{
	char *online;
	int handle;
	int ret;

	handle = fidmbinder_status_open(DEVNODE_NAME_STATUS);
	if(handle<0)
	{
		printf("Could get access to status devnode\n");
		return 1;
	}


	ret = fidmbinder_status_get(handle, "online", &online);
	fidmbinder_status_close(handle);
	if(ret)
	{
		printf("Couldn't request status of the service\n");
		return 1;
	}

	printf("%s\n", online);

	free(online);
	return 0;
}

static int set_online(const char *online)
{
	char *cmd_value;
	int handle;
	int ret;

	if (!strcmp(online, "online")) {
		cmd_value = "1";
	} else if (!strcmp(online, "offline")) {
		cmd_value = "0";
	} else {
		printf("Unknown online/offline mode <%s>\n", online);
		return 1;
	}

	handle = fidmbinder_ctrl_open(DEVNODE_NAME_CONTROL);
	if(handle<0)
	{
		printf("Could get access to control devnode\n");
		return 1;
	}

	ret = fidmbinder_ctrl_set(handle, "online", cmd_value);
	fidmbinder_ctrl_close(handle);
	if(ret)
	{
		printf("Couldn't switch to %s\n", online);
		return 1;
	}
	return 0;
}

static int get_command(const char *arg)
{
	int handle;
	int ret;
	char *reply;

	handle = fidmbinder_status_open(DEVNODE_NAME_STATUS);
	if(handle<0)
	{
		printf("Could get access to status devnode\n");
		return 1;
	}

	reply = NULL;
	ret = fidmbinder_status_get(handle,arg,&reply);
//	ret = fidmbinder_ctrl_set(ctrl_handle, arg, cmd_value);
	fidmbinder_status_close(handle);
	if(ret)
	{
		printf("Couldn't call get status command for '%s'\n",arg);
		ret=1;
	}else{
		printf("get '%s' ->   %s\n",arg,(reply?reply:"<NULL>"));
	}
	if(reply)
		free(reply);
	return 0;
}

static int ctrl_command(const char *command,const char *arg)
{
	int handle;
	int ret;
	char *reply;
	char ctdata_copy[0x1000];

	if( !command || !arg )
	{
		printf("bug. ctrl_command() needs two arguments.\n");
		return 1;
	}

	snprintf(ctdata_copy,sizeof(ctdata_copy)-1,"%s",arg);

	handle = fidmbinder_ctrl_open(DEVNODE_NAME_CONTROL);
	if(handle<0)
	{
		printf("Could get access to control devnode\n");
		return 1;
	}

	reply = NULL;
	ret = fidmbinder_ctrl_set(handle,command,ctdata_copy);
	fidmbinder_status_close(handle);
	if(ret)
	{
		printf("Couldn't call ctrl command for '%s'  '%s'\n",command,arg);
		ret=1;
	}else{
		printf("ctrl command ->   %s\n",(reply?reply:"<NULL>"));
	}
	if(reply)
		free(reply);
	return 0;
}

static int ctrl_sw_update(const char *filename)
{
	int fh = -1;
	int res = EIO;
	int handle = -1;

	handle = fidmbinder_ctrl_open(DEVNODE_NAME_CONTROL);
	if(handle<0)
	{
		printf("Could get access to control devnode\n");
		goto leave;
	}

	fh = open(filename,O_RDONLY);
	if(fh<0)
	{
		fprintf(stderr,"Error opening file '%s'\n",filename);
		goto leave;
	}

	res = fidmbinder_ctrl_sw_update_fh(handle,"updatearg#1",fh);
	close(fh);
	fh=-1;
	if(res)
	{
		fprintf(stderr,"Error in SW-update (ret=%d)\n",res);
		goto leave;
	}

	res = 0;

leave:
	if(fh>=0)
		close(fh);
	if(handle>=0)
		fidmbinder_ctrl_close(handle);

	return res;
}

int main(int argc,char *const *argv)
{
	bool do_set_online = false;
	bool do_check_online = false;
	bool do_get = false;
	bool do_ctrl = false;
	const char *get_arg = NULL;
	const char *ctrl_command_key = NULL;
	const char *ctrl_command_arg = NULL;
	const char *sw_update_filename = NULL;
	char *new_online = NULL;
	int opt;
	int result=0;

	while(true)
	{
		opt = getopt(argc, argv, "hqo:g:c:u:");
		if (opt < 0)
			break;
		switch (opt)
		{
		case 'h':
			show_help();
			return 0;

		case 'q':
			do_check_online = true;
			break;

		case 'o':
			do_set_online = true;
			new_online = optarg;
			break;
		case 'g':
			do_get = true;
			get_arg = optarg;
			break;
		case 'c':
			do_ctrl = true;
			ctrl_command_key = optarg;
			if(optind>=argc)
			{
				fprintf(stderr,"option -c needs two arguments: control and value.\n");
				return 1;
			}
			ctrl_command_arg = argv[optind++];
			break;
		case 'u':
			sw_update_filename = optarg;
			break;
		default:
			break;
		}
	}

	if(1<do_set_online)
	{
		printf("Only one option of -o is allowed\n");
		return 1;
	}

	if( !do_set_online && !do_get && !do_ctrl && !do_check_online && !sw_update_filename )
	{
		printf("None of -o -g -q -c -u is set. Doing nothing.\n");
		return 0;
	}

	result=0;

	if(do_set_online)
	{
		if(!new_online)
		{
			printf("Online mode value required\n");
			result=1;
		}else{
			if(set_online(new_online))
				result=1;
		}
	}

	if(do_check_online)
	{
		if(query_online_mode())
			result=1;
	}

	if(do_get&&get_arg)
	{
		if(get_command(get_arg))
			result=1;
	}

	if(do_ctrl&&ctrl_command_key&&ctrl_command_arg)
	{
		if(ctrl_command(ctrl_command_key,ctrl_command_arg))
			result=1;
	}

	if(sw_update_filename)
	{
		if(ctrl_sw_update(sw_update_filename))
			result=1;
	}

	return result;
}
