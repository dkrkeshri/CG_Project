#include "parser.h"
#include <gmock/gmock.h>
#include <gtest/gtest.h>
//using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

TEST(GTest,clear_data_pass){
	clear_data(NULL);
	EXPECT_EQ(0,0);
}

TEST(GTest,load_configuration_pass){
	char *p=NULL;	
	char conf_file;
	EXPECT_EQ(p,load_configuration(&conf_file));
}

TEST(GTest,parse_active_mode_pass){
	bool mode;
	json_decoder_error_t obj;
	obj=parse_active_mode(&mode);
	EXPECT_NE(NULL,obj);
}
