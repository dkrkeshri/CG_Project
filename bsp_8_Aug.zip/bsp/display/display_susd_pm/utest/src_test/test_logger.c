#include"slog2_header.h"
#include<unistd.h>
#include<string.h>
#include <gmock/gmock.h>
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "logger.h"

TEST(GTest,slogger_init_pass){
	EXPECT_EQ(0,slogger_init());  
}
