#include <iostream>
#include <gmock/gmock.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif
using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;
#include "ipc_mock.h"
#include "logger.h"
#include "parser.h"
#include "sus_res_comm_lib.h"
#include "screen_pwrmgr_common.h"
#include "err_mem_mock.h"
#include "UT-unistd-mock.h"
#include "screen_mock.h"
#include "UT-utils-mock.h"

class D_TEST: public ::testing::Test {
protected:
	UT_err_mem_mock ut_err_mem_mock_obj;
	UT_ipc_mock ut_ipc_mock_obj;
	UT_screen_mock ut_screen_mock_obj;
	UT_utils_mock ut_utils_mock_obj;
	void SetUp() override {
	ut_err_mem_mock_ptr = &ut_err_mem_mock_obj;	
	ut_ipc_mock_ptr = &ut_ipc_mock_obj;
	ut_screen_mock_ptr=&ut_screen_mock_obj;
	ut_utils_mock_ptr=&ut_utils_mock_obj;
	}
	void TearDown() override {
		ut_ipc_mock_ptr = NULL;
		ut_err_mem_mock_ptr= NULL;
		ut_screen_mock_ptr=NULL;
		ut_utils_mock_ptr=NULL;
	}
};

TEST(GTest,remote_dev_display_binder_control_pass){
	const char *display_binder_node_path = "";
	const char *state = "online";
	EXPECT_EQ(0,remote_dev_display_binder_control(display_binder_node_path,state));
}

TEST(GTest,remote_dev_pwrmode_control_pass){
	const char *display_chain_path = "";
	const char *dev_pm_name = "";
	const char *pulse = "";
	EXPECT_NE(0,remote_dev_pwrmode_control(display_chain_path,dev_pm_name,pulse));  
}

TEST(GTest,state_change_handler_pass){
	int current = 0x00;
	EXPECT_EQ(0,state_change_handler(current));  
}

TEST(GTest,signal_handler_pass){
	int dummy = 1;
	signal_handler(dummy);
	EXPECT_EQ(0,0);  
}

TEST(GTest,state_handle_server_pass){
	const char *dev="asd";
	int fh=2;
	char nt;
	sus_res_list_all(dev,fh,&nt);
	EXPECT_EQ(0,0); 
}

TEST(GTest,sus_res_comm_handle_msg_pass){
	char nt;
	const char *disp_infras_susres_path="";
	sus_res_comm_handle_msg(&nt,disp_infras_susres_path);
	EXPECT_EQ(0,0);  
}

TEST(GTest,_secpol_in_use_pass){
	EXPECT_EQ(false,_secpol_in_use());  
}


TEST_F(D_TEST,disp_state_handle_msg_pass){
	name_attach_t name_attach;
	EXPECT_CALL(ut_ipc_mock_obj, name_attach(_,_,_)).WillOnce(Return(&name_attach));
	EXPECT_CALL(ut_ipc_mock_obj, name_detach(_,_)).WillOnce(Return(0));
	EXPECT_EQ(0,disp_state_handle_msg());
}

TEST_F(D_TEST,displays_pwrmode_control_pass){
	int power_mode = 1;
	EXPECT_CALL(ut_screen_mock_obj, screen_create_context(_,_)).WillOnce(Return(0));
	EXPECT_CALL(ut_screen_mock_obj, screen_get_context_property_iv(_,_,_)).WillOnce(Return(0));
	EXPECT_CALL(ut_screen_mock_obj, screen_get_context_property_pv(_,_,_)).WillOnce(Return(0));
	EXPECT_CALL(ut_screen_mock_obj, screen_destroy_context(_)).WillOnce(Return(0));
	EXPECT_EQ(0,displays_pwrmode_control(power_mode));
}

TEST_F(D_TEST,state_handle_server_pass){
	name_attach_t name_attach;
	EXPECT_CALL(ut_ipc_mock_obj, name_attach(_,_,_)).WillOnce(Return(&name_attach));
	EXPECT_CALL(ut_ipc_mock_obj, name_detach(_,_)).WillOnce(Return(0));
	EXPECT_EQ(0,state_handle_server());  

}
TEST_F(D_TEST,disp_state_thread_create_pass){
	EXPECT_CALL(ut_utils_mock_obj, mocked_vWritePrintfErrmem(_)).WillRepeatedly(Return());
	EXPECT_NE(0,disp_state_thread_create());  
}

TEST(GTest,main2_pass){
	int argc=3;
	char arg1[256]={0};
	strcpy(&arg1[0],"./display_unit-test_linux-x86_64_aborting.sh");
	char arg2[256]={0};
	strcpy(&arg2[0],"-f");
	char *argv[]={&arg1[0],&arg2[0]};
	EXPECT_EQ(0,main2(argc,&argv[0]));  
}
