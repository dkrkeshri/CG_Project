/**
 * @file       parser.h
 * @brief      JSON active mode parser
 *
 * @author     Vasyl Khursa <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __PARSER_H__
#define __PARSER_H__

#ifndef UNIT_TEST
#include <sys/json.h>
#else
#include "json_header.h"
#include <unistd.h>
#include <string.h>
#include "slog2_header.h"
#endif

#ifdef UNIT_TEST
inline void clear_data(void *buf);
char *load_configuration(char *conf_file);
#endif
json_decoder_error_t parse_active_mode(bool *mode);

#endif /* __PARSER_H__ */
