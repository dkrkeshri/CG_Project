#ifndef _SCREEN_PWRMGR_COMMON_H_
#define _SCREEN_PWRMGR_COMMON_H_

#ifdef UNIT_TEST
#include "screen_header.h"
 #include <stdint.h>
 #endif

#define SCREEN_PWR_ATTACH_POINT "lcm_screen_power"
#define DISP_STATE_ATTACH_POINT "disp_state_channel"

#define SCREEN_CONTROL_OFF    0xff00000
#define SCREEN_CONTROL_ON     0xff00001

enum disp_state_mode {
   VCD_DISP_STATE_READY = 0xf000,
   VCD_DISP_STATE_LOST,
   IPD_DISP_STATE_READY,
   IPD_DISP_STATE_LOST,
   HUD_DISP_STATE_READY,
   HUD_DISP_STATE_LOST,
   FCC_DISP_STATE_READY,
   FCC_DISP_STATE_LOST,
   RCC_DISP_STATE_READY,
   RCC_DISP_STATE_LOST,
   HVAC_DISP_STATE_READY,
   HVAC_DISP_STATE_LOST,
};

union _sigval { /* from siginfo.h */
        int  sival_int;
        void *sival_ptr;
};

struct _pulse {
        uint16_t      type;
        uint16_t      subtype;
        int8_t        code;
        uint8_t       zero[3];
        union _sigval value;
        int32_t       scoid;
};

/* We specify the header as being at least a pulse */
typedef struct _pulse msg_header_t;

/* Our real data comes after the header */
typedef struct _screen_pwr_data {
    msg_header_t hdr;
    int data;
} screen_pwr_data_t;

#ifdef UNIT_TEST
int displays_pwrmode_control(int power_mode);
int remote_dev_display_binder_control(const char *display_binder_node_path, const char *state);
int remote_dev_pwrmode_control(const char *display_chain_path, const char *dev_pm_name, const char *pulse);//SCREEN_DONT_BLOCK (1 << 5)
int state_change_handler(int current);
void signal_handler(int dummy);
int state_handle_server();
void sus_res_list_all(const char *dev,int fh,char *nt);
void sus_res_comm_handle_msg(char *nt,const char *disp_infras_susres_path);
int disp_state_handle_msg();
int disp_state_thread_create();
inline bool _secpol_in_use ( void );
int main2(int argc ,char *argv[]);
#endif

#endif //_SCREEN_PWRMGR_COMMON_H_
