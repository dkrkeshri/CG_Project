/**
 * @file       parser.c
 * @brief      JSON active mode parser
 *
 * @author     Vasyl Khursa <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */
#include <fcntl.h>
#include <sys/stat.h>
#ifndef UNIT_TEST
#include <sys/json.h>
#else
#include "json_header.h"
#include "slog2_header.h"
#include <unistd.h>
#include <string.h>
#include <cstdlib>
#endif
#include <stdlib.h>
#include "logger.h"

#define REQUIRED 0

#define alloc_data(count, type) (type *)calloc((count), sizeof(type))

#define CONFIGURATION_FILE                                                      \
    "/dev/provider/lcm-to-display-bridge.json"

#define CONF_NODE_SETTINGS      "settings"

#define CONF_FIELD_ACTIVE_MODE  "active-mode"
#ifndef UNIT_TEST
static
inline void clear_data(void *buf)
#else
inline void clear_data(void *buf)
#endif
{
    #ifndef UNIT_TEST
    void **ptr = buf;
    #else
    void **ptr = &buf;
    #endif

    if (NULL == ptr)
        return;

    free(*ptr);
    *ptr = NULL;
}
#ifndef UNIT_TEST
static
char *load_configuration(char *conf_file)
#else
char *load_configuration(char *conf_file)
#endif
{
    int fd = 0;
    off_t fsize = 0;
    off_t actual_size;
    struct stat stat;
    char *configuration = NULL;

    fd = open(conf_file, O_RDONLY);
    if (-1 == fd) {
        LOG_ERR("Failed to open configuration file '%s'\n", conf_file);

        goto exit_load;
    }

    fstat(fd, &stat);
    fsize = stat.st_size;

    /* JSON parser expects NULL-terminated string.
     * Add 1 byte for '\0', to get valid C-string from file.
     */
    configuration = alloc_data(fsize + 1, char);
    if (NULL == configuration) {
        LOG_ERR("Malloc error. Size was %ld \n", fsize + 1);

        goto close_conf;
    }

    actual_size = read(fd, configuration, fsize);
    LOG_DBG("Read size : %ld \n", actual_size);
    if (actual_size != fsize) {
        LOG_ERR("Error in reading configuration file\n");

        clear_data(&configuration);
    }

close_conf:
    LOG_DBG("Close file\n");
    close(fd);
exit_load:
    return configuration;
}

json_decoder_error_t parse_active_mode(bool *mode)
{
    char *config = NULL;
    json_decoder_t *decoder = NULL;
    json_decoder_error_t err;

    config = load_configuration(CONFIGURATION_FILE);
    if (NULL == config) {
        LOG_ERR("Can`t load configuration\n");

        return JSON_DECODER_FILE_READ_ERROR;
    }

    decoder = json_decoder_create();

    err = json_decoder_parse_json_str(decoder, config);
    if (JSON_DECODER_OK != err) {
        LOG_ERR("json decoder initialization failed: rc = 0x%x\n", err);

        goto free_alloc_data;
    }

    err = json_decoder_push_object(decoder, NULL, false);
    if (JSON_DECODER_OK != err) {
        LOG_ERR("Failed to parse JSON root node\n");

        goto free_alloc_data;
    }

    err = json_decoder_push_object(decoder, CONF_NODE_SETTINGS, REQUIRED);
    if (JSON_DECODER_OK != err) {
        LOG_ERR("Failed to parse '%s' node\n", CONF_NODE_SETTINGS);

        goto free_alloc_data;
    }

    err = json_decoder_get_bool(decoder, CONF_FIELD_ACTIVE_MODE, mode, false);
    if (err != JSON_DECODER_OK) {
        LOG_ERR("No bool field was provided, but field is required\n");

        goto free_alloc_data;
    }

    LOG_INFO("Success parse \"active-mode\" %d\n", *mode);

    /* pop from CONF_NODE_SETTINGS */
    json_decoder_pop(decoder);

    /* pop from NULL instance */
    json_decoder_pop(decoder);

free_alloc_data:
    json_decoder_destroy(decoder);

    free(config);

    return err;
}
