/**
 * @file       logger.c
 * @brief      slog logger wrapper
 *
 * @author     Vasyl Khursa <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */
#ifndef UNIT_TEST
#include <sys/slog2.h>
#else
#include "slog2_header.h"
#include <unistd.h>
#include <string.h>
#endif
#define SLOG_NUMBER_PAGES   8

/* log macros */
slog2_buffer_t buffer_handle = NULL;
/* log buffer */
slog2_buffer_set_config_t buffer_config;

extern char *__progname;

int slogger_init(void)
{
    int rc = 0;

    buffer_config.buffer_set_name = __progname;
    buffer_config.num_buffers = 1;
    buffer_config.verbosity_level = SLOG2_INFO;
    buffer_config.buffer_config[0].buffer_name = "display_susd_pm_logging";
    buffer_config.buffer_config[0].num_pages = SLOG_NUMBER_PAGES;

    rc = slog2_register(&buffer_config, &buffer_handle, 0);
    if (-1 == rc) {
        return rc;
    }

    return 0;
}
