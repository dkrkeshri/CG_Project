/**
 * @file       display_susd_pm_daemon.cpp
 * @brief      Display application "SUSDController Client" to process display power state change according to PLC events received. And
 *             Display application "/dev/pm Client" to process display power state change according to /dev/pm pulse message received.
 * @author     Dongsheng Zou (Dongsheng.Zou@cn.bosch.com)
 * @date       Created June 11, 2020
 * @copyright  (c) 2019 Robert Bosch GmbH, China
 */

#include <errno.h>
#include <stdint.h>

#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>

#ifndef UNIT_TEST
#include <sys/stat.h>
#include <sys/dispatch.h>
#include <img/img.h>
#include <sys/types.h>
#include <screen/screen.h>
#include <libgen.h>
#include <sys/slog2.h>
#include <sys/dispatch.h>
#include <getopt.h>
#include "login.h"
#include "sus_res_comm_lib.h"
#include "utils.h"
#include <pthread.h>
#include <dirent.h>
#include "lib_display_binder.h"
#else
#include <signal.h>
#include <cstdio>
#include "UT-pthread-mock.h"
//#include "sus_res_comm_lib.c" //CY- WHy source files has been added
//#include "txtdaemon_common.c" //CY- WHy source files has been added
#include "json_header.h"
#include "UT-unistd-mock.h"
#include "ipc_header.h"
#include "err_mem_mock.h"
#include "UT-utils-mock.h"
#include "screen_header.h"
#endif
#include "logger.h"
#include "parser.h"
#include "screen_pwrmgr_common.h"


extern int optind;

/*Path will change once we move to PV specific path in IM xml file*/
/*Currently only for testing*/
const char *vcd_pm_control = "/dev/vcd/suspend-resume-commander/control";
const char *vcd_touch_dev_name = "vcd-touch-pm";
const char *vcd_faceplate_dev_name = "vcd-faceplate-pm";
const char *vcd_hvac_dev_name = "vcd-hvac-pm";
const char *vcd_brightness_dev_name = "vcd-brightness-pm";

const char *ipd_pm_control = "/dev/ipd/suspend-resume-commander/control";
const char *ipd_brightness_dev_name = "ipd-brightness-pm";

const char *hud_pm_control = "/dev/hud/suspend-resume-commander/control";
const char *hud_brightness_dev_name = "hud-brightness-pm";

const char *fcc_pm_control = "/dev/fcc/suspend-resume-commander/control";
const char *fcc_touch_dev_name = "fcc-touch-pm";
const char *fcc_faceplate_dev_name = "fcc-faceplate-pm";
const char *fcc_brightness_dev_name = "fcc-brightness-pm";

const char *rcc_pm_control = "/dev/rcc/suspend-resume-commander/control";
const char *rcc_touch_dev_name = "rcc-touch-pm";
const char *rcc_faceplate_dev_name = "rcc-faceplate-pm";
const char *rcc_brightness_dev_name = "rcc-brightness-pm";

const char *hvac_pm_control = "/dev/hvac/suspend-resume-commander/control";
const char *hvac_touch_dev_name = "hvac-touch-pm";
const char *hvac_faceplate_dev_name = "hvac-faceplate-pm";
const char *hvac_brightness_dev_name = "hvac-brightness-pm";

const char *vcd_display_binder_control = "/dev/vcd/display-binder/control";
const char *fcc_display_binder_control = "/dev/fcc/display-binder/control";
const char *rcc_display_binder_control = "/dev/rcc/display-binder/control";

const char *cmd_suspend = "suspend";
const char *cmd_resume = "resume";
static int count1=0;
static int count2=0;

#define DAEMON_SLEEP_1_SEC 1

/*
* ##device can be touch, faceplate
* examples:
* SUSPEND_DEVICE_DRIVER(vcd_pm_control, vcd_touch_dev_name)
* SUSPEND_DEVICE_DRIVER(vcd_pm_control, vcd_faceplate_dev_name)
* RESUME_DEVICE_DRIVER(vcd_pm_control, vcd_touch_dev_name)
* RESUME_DEVICE_DRIVER(vcd_pm_control, vcd_faceplate_dev_name)
*/
#define SUSPEND_VCD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(vcd_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
  if(count1 < 10){ \
    vWritePrintfErrmem("Suspend %s failed!%s\n", pm_device,__func__); \
    count1++; \
  } \
} while(0)

#define SUSPEND_IPD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(ipd_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
} while(0)

#define SUSPEND_HUD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(hud_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
} while(0)

#define SUSPEND_FCC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(fcc_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
} while(0)

#define SUSPEND_RCC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(rcc_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
} while(0)

#define SUSPEND_HVAC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(hvac_pm_control, pm_device, cmd_suspend) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Suspended\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Suspended %s failed, just info\n", pm_device); \
} while(0)

#define RESUME_VCD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(vcd_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
  if(count2 < 10){ \
    vWritePrintfErrmem("Resume %s failed!%s\n", pm_device,__func__); \
    count2++; \
  } \
} while(0)

#define RESUME_IPD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(ipd_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
} while(0)

#define RESUME_HUD_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(hud_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
} while(0)

#define RESUME_FCC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(fcc_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
} while(0)

#define RESUME_RCC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(rcc_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
} while(0)

#define RESUME_HVAC_DEVICE_DRIVER(pm_device) \
do { \
if (remote_dev_pwrmode_control(hvac_pm_control, pm_device, cmd_resume) == 0) \
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Resumed\n", pm_device); \
else \
  LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Resumed %s failed, just info\n", pm_device); \
} while(0)


#define WAIT_INIT_IM_1SEC   1
#define IM_ATTEMPTS         100

#define WAIT_OPEN_IM_1SEC   WAIT_INIT_IM_1SEC

static bool quitreq = false;
static bool state_handle_server_state_exit = false;
static int SystemIsInPVMode = -1;

typedef struct _Disp_State_Data_t
{
    pthread_t disp_state_tid;
    bool disp_state_handle_msg_exit;
} DispStateData;
static DispStateData gDispInfo;

enum susd_pm_daemon_mode {
   DAEMON_MODE_LCM,
};

#ifdef UNIT_TEST
int displays_pwrmode_control(int power_mode)
#else
static int displays_pwrmode_control(int power_mode)
#endif
{
    int rc = EOK;
    int i = 0;
    int count = 0;
    int pwrmode = power_mode;
    screen_context_t screen_ctx;
    screen_display_t *screen_disps = NULL;

    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Go into displays power mode control...\n");

    /*create screen context*/
    if (EOK != (rc = screen_create_context(&screen_ctx,
                    SCREEN_APPLICATION_CONTEXT |
                    SCREEN_POWER_MANAGER_CONTEXT)))
    {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "screen_create_context(0x%x) failed, err=%d\n", SCREEN_APPLICATION_CONTEXT|SCREEN_POWER_MANAGER_CONTEXT, errno);
        goto exit1;
    }
    /* query screen to find out number of discplays connected */
    if ( EOK != (rc = screen_get_context_property_iv(screen_ctx,
            SCREEN_PROPERTY_DISPLAY_COUNT, &count)))
    {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "screen_get_context_property_iv failed  err=%d\n", errno);
        goto exit2;
    }
    screen_disps = (screen_display_t *)calloc(count, sizeof(screen_display_t));
    if (screen_disps == NULL) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Failed to alloc displays, failed  err=%d\n", errno);
        rc = errno;
        goto exit2;
    }
    /* get handles to the displays and dimensions */
    if (EOK != ( rc = screen_get_context_property_pv(screen_ctx,
            SCREEN_PROPERTY_DISPLAYS,
            (void **)screen_disps)))
    {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "screen_get_context_property_pv failed  err=%d\n", errno);
        goto exit3;
    }
    for (i = 0 ; i < count ; i++ ) {
        /* power on/off the displays in the system */
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Powering %s display %d", (pwrmode == SCREEN_POWER_MODE_ON) ? "on" : "off" , i);
        if (EOK != screen_set_display_property_iv(screen_disps[i],
                    SCREEN_PROPERTY_POWER_MODE, &pwrmode))
        {
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "SET SCREEN_PROPERTY_POWER_MODE(%d,ON) failed err=%d\n", i , errno);
        }
    }
    if (EOK != screen_flush_context(screen_ctx, SCREEN_WAIT_IDLE)) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "screen_flush_context(WAIT_IDLE) failed err=%d\n", errno);
    }

exit3:
    free(screen_disps);
exit2:
    (void) screen_destroy_context(screen_ctx);
exit1:
    return rc;
}
#ifdef UNIT_TEST
int remote_dev_display_binder_control(const char *display_binder_node_path, const char *state)
#else
static int remote_dev_display_binder_control(const char *display_binder_node_path, const char *state)
#endif
{

    int hdl;
    int ret = 0;
    hdl = displaybinder_ctrl_open(display_binder_node_path);
    if (hdl < 0) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "failed to open %s: ret=%d", display_binder_node_path, hdl);
        ret = hdl;
        goto leave;
    }
    // set online
    if (!strcmp(state, "online")) {
        ret = displaybinder_ctrl_set_online(hdl);
        if (ret) {
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "failed to set to online mode. ret=%d",
                    ret);
            goto leave;
        }
    }
    else if (!strcmp(state, "offline")) {
        ret = displaybinder_ctrl_set_offline(hdl);
        if (ret) {
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "failed to set to offline mode. ret=%d",
                    ret);
            goto leave;
        }
    }
    else {
        printf("Unknown online/offline mode <%s>\n", state);
        goto leave;
    }

leave:
    displaybinder_ctrl_close(hdl);
    return ret;


}
#ifdef UNIT_TEST
int remote_dev_pwrmode_control(const char *display_chain_path, const char *dev_pm_name, const char *pulse)
#else
static int remote_dev_pwrmode_control(const char *display_chain_path, const char *dev_pm_name, const char *pulse)
#endif
{
    int hdl;
    int ret = 0;
    static int count3=0;
    hdl = sus_res_comm_open_control(display_chain_path);
    if (hdl < 0) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "failed to open %s: ret=%d", display_chain_path, hdl);
        ret = hdl;
        goto leave;
    }

    // set online
    ret = sus_res_comm_set_online(hdl);
    if (ret) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "failed to set to online mode. ret=%d",
                ret);
        goto leave;
    }

    // send suspend command.
    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "sending %s pulse to %s...\n", pulse, dev_pm_name);
    ret = sus_res_comm_ctrl_set(hdl, pulse, dev_pm_name);
    if (ret) {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "suspend command for %s failed. ret=%d", dev_pm_name, ret);
        if(count3 < 10){
          vWritePrintfErrmem("Suspend command for %s failed!%s\n", dev_pm_name,__func__);
          count3++;
        }
        goto leave;
    }

    ret = 0;

leave:
    if (hdl >= 0)
        sus_res_comm_close(hdl);

    return ret;

}
#ifdef UNIT_TEST
/*callback function registered to receive plc state changes*/
int state_change_handler(int current)
#else
static int state_change_handler(int current)
#endif
{
    /* return from this function as early as possible to receive further notifications.
       perform activites related to state changes in seperate thread */

    int ret = EOK;
    FILE *fp = NULL;
    char android_str_sts[1] = {0};
    static int count4 = 0;
    static int count5 = 0;
    static int count6 = 0;

    if (true == SystemIsInPVMode) {
        return EOK;
    }

    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "state %d  \n", current);

    switch(current) {
        case SCREEN_CONTROL_OFF: /* RTOS is doing shutdown preparation operations*/
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Switching to OFF mode\n");

            /*If system is in noPV mode notify screen API's to suspend displays*/
            fp = fopen("/dev/qvm/la/power_status", "r");
            if (!fp) {
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "open /dev/qvm/la/power_status failed\n");
            } else {
                ret = fread((void *)android_str_sts, 1, 1, fp);
                if (ret == 1) {
                    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "android_str_sts:%c\n",android_str_sts[0]);
                } else {
                    LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Read android STR status failed.\n");
                    if(count4 < 10){
                      vWritePrintfErrmem("Read android STR status failed!%s\n", __func__);
                      count4++;
                    }
                }

                fclose(fp);
            }

            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Display suspending...\n");

            SUSPEND_VCD_DEVICE_DRIVER(vcd_touch_dev_name);
            SUSPEND_VCD_DEVICE_DRIVER(vcd_faceplate_dev_name);
            SUSPEND_VCD_DEVICE_DRIVER(vcd_hvac_dev_name);
            SUSPEND_VCD_DEVICE_DRIVER(vcd_brightness_dev_name);
            SUSPEND_IPD_DEVICE_DRIVER(ipd_brightness_dev_name);
            SUSPEND_HUD_DEVICE_DRIVER(hud_brightness_dev_name);
            SUSPEND_FCC_DEVICE_DRIVER(fcc_touch_dev_name);
            SUSPEND_FCC_DEVICE_DRIVER(fcc_faceplate_dev_name);
            SUSPEND_FCC_DEVICE_DRIVER(fcc_brightness_dev_name);
            SUSPEND_RCC_DEVICE_DRIVER(rcc_touch_dev_name);
            SUSPEND_RCC_DEVICE_DRIVER(rcc_faceplate_dev_name);
            SUSPEND_RCC_DEVICE_DRIVER(rcc_brightness_dev_name);
            SUSPEND_HVAC_DEVICE_DRIVER(hvac_touch_dev_name);
            SUSPEND_HVAC_DEVICE_DRIVER(hvac_faceplate_dev_name);
            SUSPEND_HVAC_DEVICE_DRIVER(hvac_brightness_dev_name);
            ret = displays_pwrmode_control(SCREEN_POWER_MODE_OFF);
            if (ret == EOK) {
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "SCREEN_POWER_MODE_OFF done\n");
            } else {
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "SCREEN_POWER_MODE_OFF failed\n");
                if(count5 < 10){
                  vWritePrintfErrmem("SCREEN_POWER_MODE_OFF failed!%s\n", __func__);
                  count5++;
                }
            }
        // set display binder to offline state during suspend
        if (remote_dev_display_binder_control(vcd_display_binder_control,"offline") == 0)
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Offline\n", vcd_display_binder_control);
        else
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not Offline %s , just info\n", vcd_display_binder_control);

        if (remote_dev_display_binder_control(fcc_display_binder_control,"offline") == 0)
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Offline\n", fcc_display_binder_control);
        else
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not Offline %s , just info\n", fcc_display_binder_control);

        if (remote_dev_display_binder_control(rcc_display_binder_control,"offline") == 0)
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Offline\n", rcc_display_binder_control);
        else
            LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not Offline %s , just info\n", rcc_display_binder_control);

            break;
        case SCREEN_CONTROL_ON: //on
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Switching to ON mode\n");
            /*If system is in noPV mode notify screen API's to start displays*/

            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Display resuming...\n");
            ret = displays_pwrmode_control(SCREEN_POWER_MODE_ON);
            if (ret == EOK) {
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "SCREEN_POWER_MODE_ON done\n");
            } else {
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "SCREEN_POWER_MODE_ON failed\n");
                if(count6 < 10){
                  vWritePrintfErrmem("SCREEN_POWER_MODE_ON failed!%s\n", __func__);
                  count6++;
                }
            }

            // set display binder to online state during resume
            if (remote_dev_display_binder_control(vcd_display_binder_control,"online") == 0)
                LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", vcd_display_binder_control);
            else
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not in Online %s , just info\n", vcd_display_binder_control);

            if (remote_dev_display_binder_control(fcc_display_binder_control,"online") == 0)
                LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", fcc_display_binder_control);
            else
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not Online %s , just info\n", fcc_display_binder_control);

            if (remote_dev_display_binder_control(rcc_display_binder_control,"online") == 0)
                LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", rcc_display_binder_control);
            else
                LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not Online %s , just info\n", rcc_display_binder_control);

            //TODO: maybe it is too early here. Need check later
            RESUME_VCD_DEVICE_DRIVER(vcd_touch_dev_name);
            RESUME_VCD_DEVICE_DRIVER(vcd_faceplate_dev_name);
            RESUME_VCD_DEVICE_DRIVER(vcd_hvac_dev_name);
            RESUME_VCD_DEVICE_DRIVER(vcd_brightness_dev_name);
            RESUME_IPD_DEVICE_DRIVER(ipd_brightness_dev_name);
            RESUME_HUD_DEVICE_DRIVER(hud_brightness_dev_name);
            RESUME_FCC_DEVICE_DRIVER(fcc_touch_dev_name);
            RESUME_FCC_DEVICE_DRIVER(fcc_faceplate_dev_name);
            RESUME_FCC_DEVICE_DRIVER(fcc_brightness_dev_name);
            RESUME_RCC_DEVICE_DRIVER(rcc_touch_dev_name);
            RESUME_RCC_DEVICE_DRIVER(rcc_faceplate_dev_name);
            RESUME_RCC_DEVICE_DRIVER(rcc_brightness_dev_name);
            RESUME_HVAC_DEVICE_DRIVER(hvac_touch_dev_name);
            RESUME_HVAC_DEVICE_DRIVER(hvac_faceplate_dev_name);
            RESUME_HVAC_DEVICE_DRIVER(hvac_brightness_dev_name);
            break;
        default:
            LOG_DISPLAY_SUSD_PM(SLOG2_WARNING, "won't handling for :0x%x\n", current);
            break;
    }

    return ret;
}
#ifdef UNIT_TEST
void signal_handler(int dummy)
#else
static void signal_handler(int dummy)
#endif
{
    /*user request to quit current program by pressing CTRL+C*/
    quitreq = true;
    state_handle_server_state_exit = true;
    gDispInfo.disp_state_handle_msg_exit = true;
}
#ifdef UNIT_TEST
int state_handle_server()
#else
static int state_handle_server()
#endif
{
    name_attach_t *attach;
    screen_pwr_data_t msg;
    int rcvid;
    static int count7 = 0;

    /* Create a local name (/dev/name/local/...) */
    if ((attach = name_attach(NULL, SCREEN_PWR_ATTACH_POINT, 0)) == NULL) {
       return EXIT_FAILURE;
    }
    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "state_handle_server starting...\n");
    /* Do your MsgReceive's here now with the chid */
    while (state_handle_server_state_exit == false) {
       rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);

       if (rcvid == -1) {/* Error condition, exit */
           if(count7 < 10){
             vWritePrintfErrmem("Suspend Resume recieve pulse failed!\n");
             count7++;
           }
           break;
       }

       if (rcvid == 0) {/* Pulse received */
           switch (msg.hdr.code) {
           case _PULSE_CODE_DISCONNECT:
               /*
                * A client disconnected all its connections (called
                * name_close() for each name_open() of our name) or
                * terminated
                */
               ConnectDetach(msg.hdr.scoid);
               break;
           case _PULSE_CODE_UNBLOCK:
               /*
                * REPLY blocked client wants to unblock (was hit by
                * a signal or timed out).  It's up to you if you
                * reply now or later.
                */
               break;
           default:
               /*
                * A pulse sent by one of your processes or a
                * _PULSE_CODE_COIDDEATH or _PULSE_CODE_THREADDEATH
                * from the kernel?
                */
               break;
           }
           continue;
       }

       /* If the Global Name Service (gns) is running, name_open()
          sends a connect message. The server  must EOK it. */
       if (msg.hdr.type == _IO_CONNECT ) {
           MsgReply( rcvid, EOK, NULL, 0 );
           continue;
       }

       /* Some other I/O message was received; reject it */
       if (msg.hdr.type > _IO_BASE && msg.hdr.type <= _IO_MAX ) {
           MsgError( rcvid, ENOSYS );
           continue;
       }

      /* A message (presumable ours) received, handle */
      LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "state_handle_server received 0x%x \n", msg.data);
      switch(msg.data) {
        case SCREEN_CONTROL_OFF:
        // reply wakeup device after operation is done
           state_change_handler(SCREEN_CONTROL_OFF);
           MsgReply(rcvid, EOK, 0, 0);
           break;
        case SCREEN_CONTROL_ON:
        //reply wakeup device immediately for resume case
          MsgReply(rcvid, EOK, 0, 0);
          state_change_handler(SCREEN_CONTROL_ON);
          break;
        default:
          MsgReply(rcvid, EOK, 0, 0);
          break;
      }

    }

  /* Remove the name from the space */
  name_detach(attach, 0);
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "state_handle_server exit...\n");
  return EXIT_SUCCESS;
}

#ifdef UNIT_TEST
void sus_res_list_all(const char *dev,int fh,char *nt)
#else
static void sus_res_list_all(const char *dev,int fh,char *nt)
#endif
{
    char buf[4096];
    char *disp_infras_pm_name;

    int handle = sus_res_comm_open_status(dev);
    if (handle < 0) {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Could not open device %s (%d)\n", dev, handle);
        return;
    }
    int ret = sus_res_comm_list_all(handle, buf, 4096);
    if (ret < 0) {
        printf("sus_res_comm_list_all failed (%d)", ret);
        return;
    }

    disp_infras_pm_name = strtok(buf,"\n");
    while(disp_infras_pm_name)
    {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "List of device %s", disp_infras_pm_name);
        ret = sus_res_comm_ctrl_set(fh, nt, disp_infras_pm_name);
        if (ret < 0) {
            LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%d command failed. ret=%d", handle, ret);
        }
        disp_infras_pm_name = strtok(NULL,"\n");
    }
    sus_res_comm_close(handle);
}

#ifdef UNIT_TEST
void sus_res_comm_handle_msg(char *nt,const char *disp_infras_susres_path)
#else
static void sus_res_comm_handle_msg(char *nt,const char *disp_infras_susres_path)
#endif
{
    int fh;
    int ret;

    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp_infras_susres_path = %s\n", disp_infras_susres_path);

    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Enter %s\n", __func__);
    ret = sus_res_comm_open_control(disp_infras_susres_path);
    if (ret < 0) {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "failed to open %s: ret=%d", disp_infras_susres_path, ret);
    }
    fh = ret;
    ret = sus_res_comm_set_online(fh);
    if (ret < 0) {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "failed to set to online mode. ret=%d", ret);
    }

    sus_res_list_all(disp_infras_susres_path,fh,nt);

    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Exit %s\n", __func__);
    sus_res_comm_close(fh);
}
#ifdef UNIT_TEST
int disp_state_handle_msg()
#else
static int disp_state_handle_msg()
#endif
{
    name_attach_t *attach;
    screen_pwr_data_t msg;
    int rcvid;

    /* Create a local name (/dev/name/local/...) */
    if ((attach = name_attach(NULL, DISP_STATE_ATTACH_POINT, 0)) == NULL) {
       return EXIT_FAILURE;
    }
    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp_state_handle_msg starting...\n");

    /* Do your MsgReceive's here now with the chid */
    while (gDispInfo.disp_state_handle_msg_exit == false) {
       rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);

       if (rcvid == -1) {/* Error condition, exit */
           break;
       }

       if (rcvid == 0) {/* Pulse received */
           switch (msg.hdr.code) {
           case _PULSE_CODE_DISCONNECT:
               /*
                * A client disconnected all its connections (called
                * name_close() for each name_open() of our name) or
                * terminated
                */
               ConnectDetach(msg.hdr.scoid);
               break;
           case _PULSE_CODE_UNBLOCK:
               /*
                * REPLY blocked client wants to unblock (was hit by
                * a signal or timed out).  It's up to you if you
                * reply now or later.
                */
               break;
           default:
               /*
                * A pulse sent by one of your processes or a
                * _PULSE_CODE_COIDDEATH or _PULSE_CODE_THREADDEATH
                * from the kernel?
                */
               break;
           }
           continue;
       }

       /* If the Global Name Service (gns) is running, name_open()
          sends a connect message. The server  must EOK it. */
       if (msg.hdr.type == _IO_CONNECT ) {
           MsgReply( rcvid, EOK, NULL, 0 );
           continue;
       }

       /* Some other I/O message was received; reject it */
       if (msg.hdr.type > _IO_BASE && msg.hdr.type <= _IO_MAX ) {
           MsgError( rcvid, ENOSYS );
           continue;
       }

      LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp_state_handle_server received 0x%x \n", msg.data);

      switch(msg.data) {
        case VCD_DISP_STATE_READY:
          // set display binder to online state during startup
          if (remote_dev_display_binder_control(vcd_display_binder_control,"online") == 0)
              LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", vcd_display_binder_control);
          else
              LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not online %s , just info\n", vcd_display_binder_control);

          sus_res_comm_handle_msg("resume",vcd_pm_control);
          // reply vcd bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case VCD_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",vcd_pm_control);
          //reply vcd bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case IPD_DISP_STATE_READY:
          sus_res_comm_handle_msg("resume",ipd_pm_control);
          // reply ipd bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case IPD_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",ipd_pm_control);
          // reply ipd bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case HUD_DISP_STATE_READY:
          sus_res_comm_handle_msg("resume",hud_pm_control);
          // reply ipd bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case HUD_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",hud_pm_control);
          // reply ipd bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case FCC_DISP_STATE_READY:
          if (remote_dev_display_binder_control(fcc_display_binder_control,"online") == 0)
              LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", fcc_display_binder_control);
          else
              LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not online %s , just info\n", fcc_display_binder_control);

          sus_res_comm_handle_msg("resume",fcc_pm_control);
          // reply fcc bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case FCC_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",fcc_pm_control);
          // reply fcc bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case RCC_DISP_STATE_READY:
          if (remote_dev_display_binder_control(rcc_display_binder_control,"online") == 0)
              LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "%s Display binder Online\n", rcc_display_binder_control);
          else
              LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display binder not online %s , just info\n", rcc_display_binder_control);

          sus_res_comm_handle_msg("resume",rcc_pm_control);
          // reply rcc bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case RCC_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",rcc_pm_control);
          // reply rcc bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case HVAC_DISP_STATE_READY:
          sus_res_comm_handle_msg("resume",hvac_pm_control);
          // reply hvac bridgechip server immediately for ready case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        case HVAC_DISP_STATE_LOST:
          sus_res_comm_handle_msg("suspend",hvac_pm_control);
          // reply hvac bridgechip server immediately for lost case
          MsgReply(rcvid, EOK, 0, 0);
          break;
        default:
          MsgReply(rcvid, EOK, 0, 0);
          break;
      }

    }
  /* Remove the name from the space */
  name_detach(attach, 0);
  LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp_state_handle_server exit...\n");
  return EXIT_SUCCESS;

}
#ifdef UNIT_TEST
int disp_state_thread_create()
#else
static int disp_state_thread_create()
#endif
{
    LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp_state_thread_create start...\n");

    int rc = EOK;
    gDispInfo.disp_state_handle_msg_exit = false;
    static int count8 = 0;
    static int count9 = 0;

    #ifndef UNIT_TEST
    if (pthread_create(&gDispInfo.disp_state_tid, NULL,
                (void *)&disp_state_handle_msg, NULL) != 0) {
    #else
    if(1) {
    #endif
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Failed to disp status thread create!\n");
        if(count8 < 10){
          vWritePrintfErrmem("Failed to disp status thread create!%s\n", __func__);
          count8++;
        }
        return -1;
    } else {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "disp status thread launched!\n");
        if(count9 < 10){
          vWritePrintfErrmem("disp status thread launched!%s\n", __func__);
          count9++;
        }
      }
    return rc;
}
#ifdef UNIT_TEST
inline bool _secpol_in_use ( void ) {
#else
static inline bool _secpol_in_use ( void ) {
#endif
    char *env = getenv ( "SECPOL_ENABLE" ) ;
    if ( env) {
        return (env[0] == '1');
    } else {
        return 0;
    }
}

#ifdef UNIT_TEST
int main2(int argc ,char *argv[])
#else
int main(int argc,  char *argv[])
#endif
{
    int daemon_mode = -1;
    int opt = -1;
    int ret = -1;
    bool slog2_reg_status = false;
    bool is_bridge_active = false;
    json_decoder_error_t err;

    #ifdef UNIT_TEST
		if((opt = getopt(argc, argv, "s:U:h")) != -1) {
		#else
    while((opt = getopt(argc, argv, "s:U:h")) != -1) {
		#endif
        switch(opt)
        {
        case 's':
            if (0 == strncmp(argv[optind - 1], "lcm", sizeof("lcm"))) {
                daemon_mode = DAEMON_MODE_LCM;
            } else {
                fprintf(stderr, "Parameter error! only support 'lcm'\n");
                goto err_exit;
            }
            break;
        case 'U':
            if(_secpol_in_use()) {
                if(set_ids_from_arg(optarg) != 0)
                {
                    fprintf(stderr, "DS : UID/GID setting failed");
                    goto err_exit;
                }
            } else {
                fprintf(stderr, "DS : secpol NOT in use");
            }
            break;
        case 'h':
            fprintf(stdout,"usage list:\n%s -s lcm\n", argv[0]);
            exit(EXIT_SUCCESS);
        default:
            fprintf(stderr,"Option error! Please use:\n%s -h\n", argv[0]);
            goto err_exit;;
        }
    }

    /*The variable optind is the index of the next element to be processed in argv. The system initializes this value to 1.
      So, here "1" means that no option was found after call back getopt(...).*/
    if (1 == optind) {
        fprintf(stderr,"No option was found! Usage list:\n%s -s lcm\n\n", argv[0]);
        goto err_exit;
    }

    if (slogger_init()) {
        slog2_reg_status = false;
        fprintf(stderr, "slogger_init failed! slog can't be printed from now on!");
    } else {
        slog2_reg_status = true;
    }

    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    err = parse_active_mode(&is_bridge_active);
    if (JSON_DECODER_OK != err) {
        LOG_ERR("Failed to parse \"active-mode\"\n");
    }

    /* When LCMBridge is active we just sit in an empty loop. */
    while (is_bridge_active) {
        sleep(DAEMON_SLEEP_1_SEC);
    };

    if (DAEMON_MODE_LCM == daemon_mode) {
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "Display state thread starting...\n");
        disp_state_thread_create();
        LOG_DISPLAY_SUSD_PM(SLOG2_INFO, "State handler thread starting...\n");
        state_handle_server();
    } else {
        LOG_DISPLAY_SUSD_PM(SLOG2_ERROR, "Display power control daemon mode error!");
    }


    if (true == slog2_reg_status) {
        ret = slog2_reset();
        if (-1 == ret) {
            fprintf(stderr, "slog2_reset() failed!");
        }
    }

err_exit:
#ifndef UNIT_TEST
    exit(EXIT_FAILURE);
#else
	return 0;
#endif
}
