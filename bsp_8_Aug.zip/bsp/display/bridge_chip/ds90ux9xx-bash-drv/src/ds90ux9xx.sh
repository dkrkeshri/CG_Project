# !/bin/ksh

G_CONFIG_DIR="${1}"
G_ROOT_DIR="$(echo ${0} | sed 's/[a-zA-Z0-9\.\-]*$//g')"

FN_ReadCfgLine()
{
	local l_config="${1}"
	local l_scope="${2}"
	local l_attr="${3}"

	local l_val=$(cat "${l_config}" | grep "^${l_scope}:${l_attr}=" | cut -d '=' -f 2)

	local l_val=$(echo "${l_val}" | sed "s,@cfg-dir,${G_CONFIG_DIR},g")
	echo "${l_val}" | sed "s,@script-root-dir,${G_ROOT_DIR},g"
}

FN_Config_HasLink()
{
	local l_config="${1}"
	local l_scope="${2}"

	local has_scope=$(cat "${l_config}" | grep -q "^${l_scope}:" && echo "true")

	if [ -z "${has_scope}" ] ; then
		local has_scope="false"
	fi

	echo "${has_scope}"
}

FN_ParseConfig()
{
	local l_config="${1}"

	SERIALIZER="$(FN_ReadCfgLine ${l_config} core serializer_addr)"
	DESERIALIZER="$(FN_ReadCfgLine ${l_config} core deserializer_addr)"

	G_SERIALIZER_FW_FILE="$(FN_ReadCfgLine ${l_config} core serializer_fw)"
	G_DESERIALIZER_PREPARE_FW_FILE="$(FN_ReadCfgLine ${l_config} core deserilizer_pre_fw)"
	G_DESERIALIZER_FW_FILE="$(FN_ReadCfgLine ${l_config} core deserializer_fw)"

	I2C_GET="$(FN_ReadCfgLine ${l_config} core i2cget_cmd)"
	I2C_SET="$(FN_ReadCfgLine ${l_config} core i2cset_cmd)"

	G_CHECK_CONNECTION_CMD="$(FN_ReadCfgLine ${l_config} core check_connection_cmd)"
}


FN_Read()
{
	local l_chip_address="${1}"
	local l_address="${2}"
	local val="$(${I2C_GET} ${l_chip_address} ${l_address})"

	echo "0x$(echo ${val} | sed 's/0x//g')"
}

FN_Write()
{
	local l_chip_address="${1}"
	local l_address="${2}"
	local l_val="${3}"

	local l_ret="$(${I2C_SET} ${l_chip_address} ${l_address} ${l_val})"
	echo "$l_ret"
}

FN_Read_AsChar()
{
	local l_chip_address="${1}"
	local l_address="${2}"

	local val="$(FN_Read ${l_chip_address} $l_address)"
	val="0x$(echo ${val} | sed 's/0x//g')"
	
	local ord=$(( ${val} ))
	echo ${ord} | awk 'BEGIN{for(n=0;n<256;n++)chr[n]=sprintf("%c",n)}{print chr[$1]}'
}

FN_Read_Chip_Id()
{
	local l_chip_addr="${1}"
	echo "$(FN_Read_AsChar ${l_chip_addr} 0xF0)$(FN_Read_AsChar ${l_chip_addr} 0xF1)$(FN_Read_AsChar ${l_chip_addr} 0xF2)$(FN_Read_AsChar ${l_chip_addr} 0xF3)$(FN_Read_AsChar ${l_chip_addr} 0xF4)$(FN_Read_AsChar ${l_chip_addr} 0xF5)"
}

FN_ApplyFirmware()
{
	local l_chip_address="${1}"
	local fw_file="${2}"

	while read line
	do
		local first_char="$(echo $line | cut -c 1)"
		if [[ "${first_char}" != "0" ]] ; then
			continue
		fi

		local addr="$(echo ${line}  | cut -d ' ' -f 1)"
		local val="$(echo ${line}  | cut -d ' ' -f 2)"
		local mask="$(echo ${line}  | cut -d ' ' -f 3)"

		local r_val=$(FN_Read ${l_chip_address} ${addr})

		local r_val_masked="$(( ( (~${mask}) & 0xff) & ${r_val} ))"
		r_val_masked=$(echo ${r_val_masked} | awk '{printf( "0x%02x", $1)}')
		local w_val="$(( ${r_val_masked} | ${val} ))"
		w_val=$(echo ${w_val} | awk '{printf( "0x%02x", $1)}')

		local l_ret="$(FN_Write ${l_chip_address} ${addr} ${w_val})"

	done < "${fw_file}"
}

FN_Exit_On_NoI2C()
{
	if [ -f "/tmp/no-display-i2c-access" ] ; then
		echo "[Video Output][INFO]: Access to the display I2C bus is disabled"
		echo "[Video Output][INFO]: Stopping I2C access to the display at QNX side"

		exit 0
	fi
}

FN_WaitConnection()
{
	local l_chip_address="${1}"
	local l_connection_check_cmd="${2}"

	local l_addr="$(echo ${l_connection_check_cmd}  | cut -d ' ' -f 1)"
	local l_mask="$(echo ${l_connection_check_cmd}  | cut -d ' ' -f 2)"

	while : ; do

		FN_Exit_On_NoI2C

		local r_val=$(FN_Read ${l_chip_address} ${l_addr})
		local r_masked="$(( ${r_val} & ${l_mask} ))"
		r_masked=$(echo ${r_masked} | awk '{printf( "0x%02x", $1)}')

		if [[ "${r_masked}" != "0x00" ]] ; then
			echo "Got ${r_val} from the connection status register"
			break
		fi
		sleep 1
	done
}

FN_WaitDisconnection()
{
	local l_chip_address="${1}"
	local l_connection_check_cmd="${2}"

	local l_addr="$(echo ${l_connection_check_cmd}  | cut -d ' ' -f 1)"
	local l_mask="$(echo ${l_connection_check_cmd}  | cut -d ' ' -f 2)"

	while : ; do

		FN_Exit_On_NoI2C

		local r_val=$(FN_Read ${l_chip_address} ${l_addr})
		local r_masked="$(( ${r_val} & ${l_mask} ))"
		r_masked=$(echo ${r_masked} | awk '{printf( "0x%02x", $1)}')

		if [[ "${r_masked}" == "0x00" ]] ; then
			echo "Disconnected"
			echo "Got ${r_val} from the connection status register"
			break
		fi
		sleep 1
	done
}


FN_PrepareDeserializer()
{
	local l_serializer_addr="${1}"
	local l_prepare_fw="${2}"

	FN_ApplyFirmware "${l_serializer_addr}" ${l_prepare_fw}

	if [ "${G_SERIALIZER_CHIP}" == "_UH941" ] ; then
		local l_deserializer_addr="$(FN_Read ${SERIALIZER} 0x06)"
	elif [ "${G_SERIALIZER_CHIP}" == "_UH983" ] ; then
		local l_deserializer_addr="$(FN_Read ${SERIALIZER} 0x08)"
	fi
	l_deserializer_addr="$(( ${l_deserializer_addr} >> 1 ))" 
	l_deserializer_addr=$(echo ${l_deserializer_addr} | awk '{printf( "0x%02x", $1)}') 

	local l_deserializer_chip="$(FN_Read_Chip_Id ${l_deserializer_addr})"
	echo "Discovered deserializer chip ${l_deserializer_chip} at ${l_deserializer_addr}"
}

FN_ConfigureRemoteDevices()
{
	local l_fw_file="${1}"

	if [ -z "${l_fw_file}" ] ; then
		return
	fi

	local l_i2c_addr=$(cat "${l_fw_file}" | grep "^@i2c-addr=" | cut -d '=' -f 2)

	FN_ApplyFirmware "${l_i2c_addr}" "${l_fw_file}"
}


FN_LifeCycle()
{
	local l_link="${1}"
	local l_config="${G_CONFIG}"

	local l_serializer="$(FN_ReadCfgLine ${l_config} ${l_link} serializer_addr)"
	local l_deserializer="$(FN_ReadCfgLine ${l_config} ${l_link} deserializer_addr)"
	local l_deserializer_prepare_fw_file="$(FN_ReadCfgLine ${l_config} ${l_link} deserilizer_pre_fw)"
	local l_deserializer_fw_file="$(FN_ReadCfgLine ${l_config} ${l_link} deserializer_fw)"
	local l_remote_dev_fw_file="$(FN_ReadCfgLine ${l_config} ${l_link} remote_dev_fw)"
	local l_check_connection_cmd="$(FN_ReadCfgLine ${l_config} ${l_link} check_connection_cmd)"

	echo "Starting lifecycle for ${l_link}..."
	echo "Following configuration will be used:"
	echo "\tSerializer address: ${l_serializer}"
	echo "\tTarget deserializer address: ${l_deserializer}"
	echo "\tI2C Bridge Configuration: ${l_deserializer_prepare_fw_file}"
	echo "\tDeserializer firmware: ${l_deserializer_fw_file}"
	echo "\tRemote devices firmware: ${l_remote_dev_fw_file}"
	echo "\tConnection check-up command: ${l_check_connection_cmd}"

	while : ; do

		FN_Exit_On_NoI2C

		echo "Waiting for connection..."
		FN_WaitConnection "${l_serializer}" "${l_check_connection_cmd}"
		echo "Coonection discovered, preconfiguring deserializer..."
		FN_PrepareDeserializer "${l_serializer}" "$l_deserializer_prepare_fw_file"
	
		echo "Configuring deserializer..."
		FN_ApplyFirmware "${l_deserializer}" "$l_deserializer_fw_file"

		echo "Configuring remote devices..."
		FN_ConfigureRemoteDevices "${l_remote_dev_fw_file}"

		if [ "${G_SERIALIZER_CHIP}" == "_UH941" ] ; then
			i2cdbgr /dev/i2c3 0x0c write 2 0x01 0x00
		fi

		echo "Monitoring connection status..."
		FN_WaitDisconnection "${l_serializer}" "${l_check_connection_cmd}"
	done
}

FN_Init()
{
	G_SERIALIZER_CHIP="$(FN_Read_Chip_Id ${SERIALIZER})"
	echo "Discovered serializer chip ${G_SERIALIZER_CHIP} at ${SERIALIZER}"

	echo "Configuring serializer from ${G_SERIALIZER_FW_FILE}..."
	FN_ApplyFirmware "${SERIALIZER}" "${G_SERIALIZER_FW_FILE}"
}

FN_Start_Lifecycles()
{
	local has_link_0=$(FN_Config_HasLink "${G_CONFIG}" "link-0")
	local has_link_1=$(FN_Config_HasLink "${G_CONFIG}" "link-1")

	if [ "${has_link_0}" == "true" ] ; then
		if [ "${has_link_1}" == "true" ] ; then
			FN_LifeCycle "link-0" & FN_LifeCycle "link-1"
		else
			FN_LifeCycle "link-0"
		fi
	else
		if [ "${has_link_1}" == "true" ] ; then
			FN_LifeCycle "link-1"
		fi
	fi
}

G_CONFIG="${G_ROOT_DIR}/${G_CONFIG_DIR}/ds90ux9xx.cfg"

FN_ParseConfig "${G_CONFIG}"

FN_Init
FN_Start_Lifecycles

