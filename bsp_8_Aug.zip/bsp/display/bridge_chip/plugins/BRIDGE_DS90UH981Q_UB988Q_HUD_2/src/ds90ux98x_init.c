#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT   0x0C
#define DES_ID_7BIT   0x2C
#define MCU_ID_7BIT   0x12

#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)

// Panel Timings
#define THW               560   // Total horizontal
#define TVW               247    // Total vertical
#define AHW               480   // Active horizontal
#define AVW               240    // Active vertical
#define HBP               15     // Horizontal back porch
#define VBP               2      // Vertical back porch
#define HSW               45     // Horizontal sync width
#define VSW               3      // Vertical sync width
#define VFP               2      // Vertical front porch
#define MDIV              806   // M Divider

static int32 verbosedebug = 1;
#define MODULE_NAME "CONTI_HUD2"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (1) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static uint8 upper_byte2(uint32 in_data)
{
    return (uint8)((in_data & 0xFF0000) >> 16);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    DEBUG_PRINT(MODULE_NAME, "%s Reg: 0x%x Data: 0x%x", __func__, reg, val);
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "%s 0x%x : 0x%x", __func__, reg, val);
        LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
    }
    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1)
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);

    return 0;
}

/*
static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Backlight", __func__);
    write_reg(fd, 0x03, 0x00);
    (void)usleep(50*1000);
    write_reg(fd, 0x20, 0x03);

    return BRIDGECHIP_STATUS_SUCCESS;
}
*/

BridgeChip_StatusType link_set_981_fpd3(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Set 981 to FPD-LINK III Mode..........", __func__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01); //Select port   0
    write_reg(fd, 0x70, 0x58); //slave ID port 0
    write_reg(fd, 0x78, 0x58); //slave alias port 0, bit 0 = 0 to map over FPD Port 0
    write_reg(fd, 0x71, 0x24);  //slave ID port 1 // MCU 8-bit slave address
    write_reg(fd, 0x79, 0x24); //slave alias port 1
    write_reg(fd, 0x05, 0x00);
    write_reg(fd, 0x59, 0x01);  //Forced single mode
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xE0);
    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x5B, 0x2B); //Enable FPD3 FIFO
    (void)usleep(400*1000);
    write_reg(fd, 0x07, 0x88);
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable I2C Passthrough..........", __func__);

    return BRIDGECHIP_STATUS_SUCCESS;
}

#if 1
static bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;

    if (read_reg(fd, 0x00, &regval) == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", __func__, regval, chipId);
        if (regval == chipId)
            return TRUE;
        else
            return FALSE;
    } else {
        return FALSE;
    }
}
#endif
/*
static uint8 check_98x_link(int32 fd)
{
    uint8 regval = 0;

    read_reg(fd, 0x0c, &regval);
    CRITICAL_PRINT(MODULE_NAME, "%s: Readed 0xc = 0x%02x", __func__, regval);
    return (regval &0x01);
}*/
#if 1
static BridgeChip_StatusType link_convert_988_fpd3_to_fpd4(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Disable DES0 OLDI", __func__);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00);

    /* Change des_id_remote0 PLL to FPD4 settings */
    CRITICAL_PRINT(MODULE_NAME, "%s: Change DES_ID_REMOTE0 PLL to FPD4 settings", __func__);
    write_reg(fd, 0x40, 0x38);//weller not match hud3
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0xb0);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0xb0);
    write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "%s: Reset Receiver", __func__);
    (void)usleep(400*1000);
    CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read receiver", __func__);
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
    CRITICAL_PRINT(MODULE_NAME, "%s: Program FPD4 PLL to 6.75 GHz on VCO", __func__);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x0e, 0x03);
    write_reg(fd, 0x61, 0x09);
    write_reg(fd, 0x95, 0x06);
    write_reg(fd, 0x60, 0x0F);
    write_reg(fd, 0x40, 0x56);
    write_reg(fd, 0x41, 0x34);
    write_reg(fd, 0x42, 0xff);
    write_reg(fd, 0x41, 0x35);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xB4);
    write_reg(fd, 0x42, 0xff);
    write_reg(fd, 0x41, 0xB5);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x33, 0x05);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x05);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x05);
    write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "%s: Issue a software reset to get the receiver PLL setting loaded", __func__);
    (void)usleep(400*1000);
    CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read receiver before writing FPD4 Settings", __func__);
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: End reprogramming FPD3 -> FPD4 settings", __func__);
        CRITICAL_PRINT(MODULE_NAME, "%s: Now to switch to FPD4 on 988.  Link will be lost momentarily.", __func__);
        write_reg(fd, 0x0e, 0x03);
        write_reg(fd, 0x5f, 0x00);
        write_reg(fd, 0x31, 0x67);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read receiver.  Increase delay prior to continuing program flow", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read receiver.  Increase delay prior to continuing program flow", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_988_enable_oldi(int32 fd)
{
    /* Port 0 HUD OLDI */
    unsigned int timing_mode = 0x13;
    unsigned int PLL_988_NDIV = 34;
    unsigned int PLL_988_NUM = 7152307;
    unsigned int PLL_988_DEN = 16777206;
    unsigned int PLL_988_PDIV = 0x14;
    unsigned int PLL_988_order = 0x20;

    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    write_reg(fd,0xd0,0xc); //
    write_reg(fd,0xd7,0x0); //

    write_reg(fd,0x40,0x2C); // #Page11_oLDI register

    write_reg(fd,0x41,0x00); //
    write_reg(fd,0x42,0x2F); //#Enable OLDI Port 0

    write_reg(fd,0x41,0x01); //
    write_reg(fd,0x42,0x2F); //#Enable OLDI Port 1


    //#PLL settings & output enable from working 720p 988 pat gen script
    //# PCLK = 74.25 MHz, 1280x720@60fps 

    CRITICAL_PRINT(MODULE_NAME, "Enable vertical bars ");

    write_reg(fd,0x40,0x2C); // #Page11_oLDI register
    write_reg(fd,0x41,0x00); //
    write_reg(fd,0x42,0x2F); //
    write_reg(fd,0x41,0x01); //
    write_reg(fd,0x42,0x2F); //
    write_reg(fd,0x40,0x2C); //
    write_reg(fd,0x41,0x18); // #PLL_NDIV
    write_reg(fd,0x42,lower_byte(PLL_988_NDIV)); //#1E
    write_reg(fd,0x41,0x0a); // #oLDI_PLL_DIG3
    write_reg(fd,0x42,lower_byte(PLL_988_NUM)); //
    write_reg(fd,0x41,0x09); // #oLDI_PLL_DIG2
    write_reg(fd,0x42,upper_byte(PLL_988_NUM)); //
    write_reg(fd,0x41,0x08); // #oLDI_PLL_DIG1
    write_reg(fd,0x42,upper_byte2(PLL_988_NUM)); //
    write_reg(fd,0x41,0x0b); // #oLDI_PLL_DIG4
    write_reg(fd,0x42,upper_byte2(PLL_988_DEN)); //
    write_reg(fd,0x41,0x0C); // #oLDI_PLL_DIG5
    write_reg(fd,0x42,upper_byte(PLL_988_DEN)); //
    write_reg(fd,0x41,0x0D); // #oLDI_PLL_DIG6
    write_reg(fd,0x42,lower_byte(PLL_988_DEN)); //
    write_reg(fd,0x41,0x2D); //
    write_reg(fd,0x42,PLL_988_PDIV); //
    write_reg(fd,0x41,0x38); //
    write_reg(fd,0x42,PLL_988_order); //
    write_reg(fd,0x40,0x50); //
    write_reg(fd,0x41,0x20); //
    write_reg(fd,0x42,timing_mode); //

    //# modified soft reset to oldi reset
    write_reg(fd,0x1,0x40); // # OLDI PLL RESET

    //# Enable OLDI 11"
    write_reg(fd,0x40,0x2c); // #Page11_OLDI Control

    write_reg(fd,0x41,0x20); //
    write_reg(fd,0x42,0x00); 
    write_reg(fd,0x41,0x22); //
    write_reg(fd,0x42,0x00); //
    //#Enable RGB Interface
    write_reg(fd,0x41,0x02); //
    write_reg(fd,0x42,0x18); //
    //#Enable output
    write_reg(fd,0x41,0x00); //
    write_reg(fd,0x42,0x2B); //

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_981_fpd4(int32 fd)
{
    uint8 RevId = 0;
    read_reg(fd, 0x30, &RevId);
    /* DSI config */
    CRITICAL_PRINT(MODULE_NAME, "%s: Configure DSI Port0", __func__);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x02, 0xD8);
    if ((RevId & 0xF0) >= 0x20)
    {
        write_reg(fd, 0x4F, 0x81);
    }
    else
    {
        write_reg(fd, 0x4F, 0x80);
    }
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x8F, 0x01);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    CRITICAL_PRINT(MODULE_NAME, "%s: Now switching 981 to FPD4 mode", __func__);
    if ((RevId & 0xF0) == 0x20)
    {
        write_reg(fd, 0x6E, 0x80);
    }
    write_reg(fd, 0x5B, 0x23);
//    write_reg(fd, 0x2d, 0x03);
//    write_reg(fd, 0x6a, 0x0a);
//    write_reg(fd, 0x59, 0x05);
    write_reg(fd, 0x05, 0x14);
//    write_reg(fd, 0x02, 0xd1);
    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
//    write_reg(fd, 0x41, 0x94);
//    write_reg(fd, 0x42, 0x02);

    CRITICAL_PRINT(MODULE_NAME, "%s: Program PLL Settings", __func__);
    write_reg(fd, 0x43, 0x00);  // enable 1 stream
    /* 981 PLL programming */
    CRITICAL_PRINT(MODULE_NAME, "%s: Properly program back channel", __func__);

    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x6a, 0x04);
    write_reg(fd, 0x05, 0x3C);


    CRITICAL_PRINT(MODULE_NAME, "%s: Program PLL0 Settings", __func__);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xA0);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x00);
    CRITICAL_PRINT(MODULE_NAME, "%s: Software reset 981", __func__);
    write_reg(fd, 0x01, 0x01);
    (void)usleep(400*1000);

    CRITICAL_PRINT(MODULE_NAME, "%s: End of FPD3 to FPD4 Conversion", __func__);

    CRITICAL_PRINT(MODULE_NAME, "Configure vp0 and patgen", __func__);
    write_reg(fd, 0x2D, 0x01); // select port 0 TX

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Configure VP0");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); // program h_act
    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP)); //program v front porch

    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(MDIV));
    write_reg(fd, 0x42, upper_byte(MDIV)); // set M divider
    write_reg(fd, 0x42, 0x0F); // set N divider
/*
    CRITICAL_PRINT(MODULE_NAME, "Enable Patgen", __func__);

    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x91);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x08);
*/
    //DPHY P0 Settings
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x2A);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x21);
    write_reg(fd, 0x41, 0x21);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0xBD, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Video processor stream", __func__);
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x01); //
    write_reg(fd, 0x42, 0x01); // enable stream 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00); // map stream 0 to VP0
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x3C); // set 60 time slots
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    write_reg(fd, 0x02, 0xF0);
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x01, 0x01);
    write_reg(fd, 0x43, 0x00); // enable VP0
    write_reg(fd, 0x44, 0x01); // enable VP0

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "%s: Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ", __func__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_981_fpd3(fd);
    looping_981_fpd_linkup(fd);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_988_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_981_fpd4(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | looping_981_fpd_linkup(fd));
//    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_vp(fd));

    return eStatus;
}

BridgeChip_StatusType wait_988_link_stable(int fd)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
    int32 i = 0;
    int32_t stable_count = 0;
    #define LOCK_STS_CHG_988 0x04 //bit2

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    do {
        read_reg(fd, 0x54, &regval);
        port0_link = regval & LOCK_STS_CHG_988;
        if (port0_link == 0x04) {
            //not stable
            stable_count = 0; 
            (void) usleep(50*1000);
        } else if (port0_link == 0x0) {
            //stable and count it
            stable_count ++;
            //break when continuous 5 times stable
            if (stable_count >= 5)
                break;
            (void) usleep(50*1000);
        }
    } while (i++ < 15);
    if (i < 15) {
        CRITICAL_PRINT(MODULE_NAME, "%s: 988 is stable", __func__);
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else {
        CRITICAL_PRINT(MODULE_NAME, "%s: 988 is NOT stable after waiting", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType link_enable_988_panel(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "%s: Enable 988 OLDI output", __func__);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    wait_988_link_stable(fd);
    CRITICAL_PRINT(MODULE_NAME, "%s: 988 is stable", __func__);
    (void)usleep (200*1000);
    eStatus = link_set_988_enable_oldi(fd);
    //i2c_set_slave_addr(fd, MCU_ID_7BIT, I2C_ADDRFMT_7BIT);
    //eStatus |= enable_panel_backlight(fd);

    return eStatus;
}

BridgeChip_StatusType get_981_link_status(int fd)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
	static int32_t port0_link_old = 0;
#define RX_LOCK_DETECT_BIT 6
#define LINK_DETECT_BIT    0
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ ) {
        port0_link = 1;

	} else {
		port0_link = 0;
	}

	if (port0_link_old != port0_link) {

        CRITICAL_PRINT(MODULE_NAME,
                "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x, reg: 0x0C = 0x%02x\n",
                (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01), regval);
		port0_link_old = port0_link;
	}

    if (port0_link == 1)
        return BRIDGECHIP_STATUS_SUCCESS;
    else
        return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType looping_981_fpd_linkup(int fd)
{
    int32_t i;
    //looping here max time with 500ms
    for (i=0; i<50; i++) {
        if (get_981_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
            return BRIDGECHIP_STATUS_SUCCESS;
        else
            (void) usleep(10*1000);
    }
    CRITICAL_PRINT(MODULE_NAME, "looping_981_fpd_linkup timeout, NO FPD link !!");
    return BRIDGECHIP_STATUS_FAILED;
}

#ifdef __cplusplus
}
#endif
