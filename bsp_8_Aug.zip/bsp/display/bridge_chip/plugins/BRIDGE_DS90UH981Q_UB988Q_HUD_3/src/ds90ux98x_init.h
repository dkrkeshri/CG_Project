#ifndef DS90UX98X_INIT_H
#define DS90UX98X_INIT_H

BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd);
BridgeChip_StatusType link_enable_988_panel(int32 fd);
BridgeChip_StatusType link_set_981_fpd3(int32 fd);
BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd);
BridgeChip_StatusType get_981_link_status(int fd);
BridgeChip_StatusType looping_981_fpd_linkup(int fd);
void ser_clear_linklost_flag(int32 i2c_fh);
#endif
