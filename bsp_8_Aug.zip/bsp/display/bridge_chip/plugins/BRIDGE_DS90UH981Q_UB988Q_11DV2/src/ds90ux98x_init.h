#ifndef DS90UX98X_INIT_H
#define DS90UX98X_INIT_H

#define SER_RESET_DIGITAL_ALL 0x02
#define SER_RESET_PLL_ONLY    0x30
int32 read_reg(int32 fd, uint8 reg, uint8 *retval);
BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd);
BridgeChip_StatusType link_enable_deserializer_panel(int32 fd);
BridgeChip_StatusType get_981_link_status(int fd);
BridgeChip_StatusType looping_981_fpd_linkup(int fd);
BridgeChip_StatusType check_988_lock();
BridgeChip_StatusType ser_config_update(int32 i2c_fh);
BridgeChip_StatusType dser_config_update(int32 i2c_fh);
void set_reset_keep_dsi(int32 val);
BridgeChip_StatusType recovery_ser_fpd3_init(int32 fd);
BridgeChip_StatusType recovery_serdes_fpd4_init(int32 fd);
void wait_988_link_stable(int fd);
void ser_clear_linklost_flag(int32 i2c_fh);

#endif
