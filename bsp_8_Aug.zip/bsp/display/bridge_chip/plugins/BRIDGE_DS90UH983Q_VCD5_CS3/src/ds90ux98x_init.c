#ifdef __cplusplus
extern "C"
{
#endif
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT   0x0C
#define DES_ID_7BIT   0x2C
#define MCU_ID_7BIT   0x12
#define TOUCH_ID_7BIT 0x24
#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)
#define TOUCH_ID_8BIT (TOUCH_ID_7BIT << 1)

// Panel Timings
#define THW               2216   // Total horizontal
#define TVW               982    // Total vertical
#define AHW               2000   // Active horizontal
#define AVW               974    // Active vertical
#define HBP               76     // Horizontal back porch
#define VBP               4      // Vertical back porch
#define HSW               20     // Horizontal sync width
#define VSW               1      // Vertical sync width
#define VFP               3      // Vertical front porch
#define FPS               60.0   // Frame rate 60fps
#define FC_FPD_FREQ       6.75

#define GENERAL_STS_MASK   0x5B
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define BIST_CRC_ERROR_BIT 3
#define BC_CRC_ERROR_BIT   1
#define LINK_DETECT_BIT    0

#define APB_CTL        0x48
#define APB_ADR0       0x49
#define APB_ADR1       0x4A
#define APB_DATA0      0x4B
#define APB_DATA1      0x4C
#define APB_DATA2      0x4D
#define APB_DATA3      0x4E

#define APB_DP_RX      0x00
#define APB_DP0_TX     APB_DP_RX
#define APB_DP1_TX     0x01
#define APB_CFG_DATA   0x02
#define APB_DIE_ID     0x03

static int32 verbosedebug = 1;
static int32 reset_keep_dprx = 0;

#define MODULE_NAME "SER-DES INX-VCD5 CS3.0"
#define ENABLE_VP0_PATTERN 0

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "i2c_write failed 0x%x : 0x%x",  reg, val);
    }

    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        //LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
        return -1;
    }

    return 0;
}

static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x03;
        break;
    case APB_DP1_TX:
        wr_val = 0x0B;
        break;
    case APB_CFG_DATA:
        wr_val = 0x13;
        break;
    case APB_DIE_ID:
        wr_val = 0x1B;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB write channel, try write APB channel 0");
        wr_val = 0x03;
        break;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}

static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x01;
        break;
    case APB_DP1_TX:
        wr_val = 0x09;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB read channel, try read APB channel 0");
        wr_val = 0x01;
        break;
    }
    write_reg(fd, APB_CTL, wr_val);

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);


    return 0;
}

static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

static BridgeChip_StatusType serdes_wait_des_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / 10;

    do
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(10 * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

static BridgeChip_StatusType link_set_serializer_i2c_pass_through(int32 fd)
{
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, TOUCH_ID_8BIT);
    write_reg(fd, 0x7A, TOUCH_ID_8BIT);
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);
    CRITICAL_PRINT(MODULE_NAME," Enable I2C Pass Through");
    write_reg(fd, 0x07, 0x88);
    write_reg(fd, 0x3A, 0x88);

    CRITICAL_PRINT(MODULE_NAME, "Set i2c pass through done");

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_serializer_gpio(int32 fd)
{
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set Serializer GPIOs...");
    read_reg(fd, 0x30, &RevId);
    RevId &= 0xF0;
    if (RevId >= 0x40)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}
//only can be called after softreset
static BridgeChip_StatusType link_set_serializer_dprx(int32 fd)
{
    //# *********************************************
    //# Set DP Config
    //# *********************************************
    apb_write_reg(fd, APB_DP_RX, 0x00, 0x00);   //Force HPD low to configure 983 DP settings
    apb_write_reg(fd, APB_DP_RX, 0x214, 0x02);  //Request min VOD swing of 0x02
 //   apb_write_reg(fd, APB_DP_RX, 0x18, 0x14);     //Set SST/MST mode and DP/eDP Mode
    apb_write_reg(fd, APB_DP_RX, 0xA0C, 0x01);     //Disable line reset for VS0

    //Lane Rate Optimizations for CS2.0 with 8155 at 8.1Gbps (No SSC);
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);

    apb_write_reg(fd, APB_DP_RX, 0x00, 0x01);     //Force HPD high to trigger link training

    // Allow time after HPD is pulled high for the source to train and provide video (may need to adjust based on source properties);
    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_video_input_reset(int32 fd)
{
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    apb_write_reg(fd, APB_DP_RX, 0x54, 0x01);   //Video Input Reset (should be executed after DP video is available from the source);

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 RevId = 0;

    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x08);

    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");
    //Disable FPD3 FIFO pass through
    write_reg(fd, 0x5B, 0x23);
    //Change FPDTX FPD3_MODE_CTL
    write_reg(fd, 0x59, 0x05);

    //Force FPD4_TX DUAL MODE
    write_reg(fd, 0x05, 0x2C); // FPD_TX to DUAL

    CRITICAL_PRINT(MODULE_NAME," Switch mode to FPD4 Dual");

    write_reg(fd, 0x02, 0xD1);
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90);

    write_reg(fd, 0x2D, 0x03);
    write_reg(fd, 0x6A, 0x0A);
    read_reg(fd, 0x30, &RevId);
    // for 983 CS2.0
    if ((RevId & 0xF0) == 0x50)
    {
        write_reg(fd, 0x6E, 0x80);
    }

    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    //Configure and Enable PLLs
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0xC7);
    write_reg(fd, 0x41, 0x4E);
    write_reg(fd, 0x42, 0xC7);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME," Software reset 983");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);

    //todo:
    serdes_wait_des_link_stable(fd, 100);

    CRITICAL_PRINT(MODULE_NAME," Software reset deserializer");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 100);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x40, 0x2E);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);
    CRITICAL_PRINT(MODULE_NAME,"Software reset 983 and 988 done");
    write_reg(fd, 0x2D, 0x01);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{

    uint8 n_value = 15;
    uint8 addr0, addr1;
    float fc_freq = 0;
    float src_pclk_freq = THW * TVW * FPS / 1000000;
    float m_value_f;
    uint16 m_value;

    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x32);

    // Set Stream Source to VPs
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0xA8); //SST0 for VP0

    // set timing on video processor 0
    addr0 = 0x02;
    addr1 = 0x10;
    // set dp_h_active
    write_reg(fd, 0x41, addr0);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_active
    write_reg(fd, 0x41, addr1); // h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_back
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW));

    // set video timing generator v_active
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP));

    write_reg(fd, 0x41, 0x27);
    write_reg(fd, 0x42, 0x00); //HSYNC Polarity = +,VSYNC Polarity = +
    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //10800  bps

    //  half rate mode
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "The source pixel clock is %f",  src_pclk_freq);
    CRITICAL_PRINT(MODULE_NAME, "The M value for VP0 is m_value = %d",  m_value);
    // full rate mode
    // m_value = sub_pclk_freq / 4.0 * (2 ^ n_value) / (fc_freq/80)

    // set m/n value for video processor 0
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);

    //==================================================
    // TODO: ENABLE VP need be called after video afailable and after video input reset
    // Enable VPs
    // main page: set number of video streams
    write_reg(fd, 0x43, 0x00); //Set number of VPs used = 1
    write_reg(fd, 0x44, 0x01); //Enable video processors
    /*
    CRITICAL_PRINT(MODULE_NAME, "Enable PATGEN");
    //## *********************************************
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x08); //Set PATGEN Color Depth to 24bpp for VP0
    write_reg(fd, 0x41, 0x28); //
    write_reg(fd, 0x42, 0x95); //Enable PATGEN on VP0 - Comment out this line to disable PATGEN and enable end to end video
    */
    //write_reg(fd, 0x01, 0x30);
    //serdes_wait_des_link_stable(fd, 100);
    //i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    // Config TX link layer

    // enable link layer stream
    // only for FPD4 mode
    // choose page 11, set auto-increment
    write_reg(fd, 0x40, 0x2E);  // Link layer register page
    write_reg(fd, 0x41, 0x01);  // Link layer stream enable
    write_reg(fd, 0x42, 0x01);  // Link layer stream enable
    write_reg(fd, 0x41, 0x06);  // Link layer time slot 0
    write_reg(fd, 0x42, 0x3C);  // Link layer time slot
    write_reg(fd, 0x41, 0x20);  // Set link layer vp bpp
    write_reg(fd, 0x42, 0x59);  // Set link layer vp bpp according to VP BPP
    write_reg(fd, 0x41, 0x00);  // Link layer enable
    write_reg(fd, 0x42, 0x03);  // Link layer enable

    return BRIDGECHIP_STATUS_SUCCESS;
}
#if 0
static BridgeChip_StatusType link_set_serializer_enable_sscg(int32 fd)
{
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    //#########################################################
    //#Programs FPD-Link SSCG PLL for 98x device to 6.750 Gbps
    //#PLL script revision: 0
    //#Configuring PLL0 (Port 0)
    //#N-divider set to 124
    //#########################################################
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7C); // write to register 0x05
    write_reg(fd, 0x42, 0x00); // write to register 0x06
    // Denominator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0xF6); // write to register 0x18
    write_reg(fd, 0x42, 0xFF); // write to register 0x19
    write_reg(fd, 0x42, 0xFF); // write to register 0x1a
    // Numerator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0xF6); // write to register 0x1e
    write_reg(fd, 0x42, 0xFF); // write to register 0x1f
    write_reg(fd, 0x42, 0xFF); // write to register 0x20
    // Post-divider set to 2 and auto VCO selection enabled
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90); // write to register 0x13
    // SSCG spread type set to Center-spread
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x14);
    write_reg(fd, 0x42, 0x80); // write to register 0x14
    // rampx_inc_6_0 programmed (rampx_inc =25700)
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x14);
    write_reg(fd, 0x42, 0xE4); // write to register 0x14
    // rampx_inc_14_7 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x15);
    write_reg(fd, 0x42, 0xC8); // write to register 0x15
    // rampx_stop_7_0 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x16);
    write_reg(fd, 0x42, 0xCC); // write to register 0x16
    // SSCG enabled, rampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x17);
    write_reg(fd, 0x42, 0x40); // write to register 0x17
    // PLL order set to fractional
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x09); // write to register 0x04
    //#########################################################
    //#Programs FPD-Link SSCG PLL for 98x device to 6.750 Gbps
    //#PLL script revision: 0
    //#Configuring PLL1 (Port 1)
    //#########################################################
    //#N-divider set to 124
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, 0x7C); // write to register 0x45
    write_reg(fd, 0x42, 0x00); // write to register 0x46
    // Denominator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x58);
    write_reg(fd, 0x42, 0xF6); // write to register 0x58
    write_reg(fd, 0x42, 0xFF); // write to register 0x59
    write_reg(fd, 0x42, 0xFF); // write to register 0x5a
    // Numerator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0xF6); // write to register 0x5e
    write_reg(fd, 0x42, 0xFF); // write to register 0x5f
    write_reg(fd, 0x42, 0xFF); // write to register 0x60
    // Post-divider set to 2 and auto VCO selection enabled
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90); // write to register 0x53
    // SSCG spread type set to Center-spread
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0x80); // write to register 0x54
    // rampx_inc_6_0 programmed (rampx_inc =25700)
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0xE4); // write to register 0x54
    // rampx_inc_14_7 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x55);
    write_reg(fd, 0x42, 0xC8); // write to register 0x55
    // rampx_stop_7_0 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0xCC); // write to register 0x56
    // SSCG enabledrampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x57);
    write_reg(fd, 0x42, 0x40); // write to register 0x57
    // PLL order set to fractional
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x09); // write to register 0x44

    write_reg(fd, 0x01, 0x30);
    serdes_wait_des_link_stable(fd, 100);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_disable_sscg(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Disable Serializer SSCG");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    // SSCG disabled, rampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x17);
    write_reg(fd, 0x42, 0x00); // write to register 0x17
    // SSCG disabled, rampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x57);
    write_reg(fd, 0x42, 0x00); // write to register 0x57

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_enable_sscg(int32 fd)
{
    uint8 idr_reg_rb = 0;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    //## *********************************************
    //## SSCG CDR DES Settings
    //## *********************************************
    //# # FPD FC Rate:6.75
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain trk to 2
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain trk to 3
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain ACQ to 2
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain ACQ to 3
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, (idr_reg_rb & 0xFC) | 0x01);  // Set CDR Dump Limit to 1
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain trk to 2
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain trk to 3
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain ACQ to 2
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain ACQ to 3
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, (idr_reg_rb & 0xFC) | 0x01);  // Set CDR Dump Limit to 1
    write_reg(fd, 0x01, 0x01);                        //digital reset

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_deserializer_temp_optimization(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    uint8 temp_final, rb;
    int32 temp_final_c, ramp_up_range_codes_needed, ramp_dn_range_codes_needed;
    int32 ramp_up_cap_delta, ramp_dn_cap_delta, ts_code_up, ts_code_dn;
    uint8 efuse_ts_code = 4;

    CRITICAL_PRINT(MODULE_NAME, "Set up deserializer Temp Ramp Optimizations");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    // Read Deserializer 0 Temp
    write_reg(fd, 0x40, 0x6C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13);
    read_reg(fd, 0x42, &temp_final);
    temp_final_c = 2 * temp_final - 273;

    // Set up Deserializer 0 Temp Ramp Optimizations
    ramp_up_range_codes_needed = (150 - temp_final_c) / (190 / 11) + 1;
    ramp_dn_range_codes_needed = (temp_final_c - 30) / (190 / 11) + 1;
    ramp_up_cap_delta = ramp_up_range_codes_needed - 4;
    ramp_dn_cap_delta = ramp_dn_range_codes_needed - 7;

    write_reg(fd, 0x40, 0x3C);
    write_reg(fd, 0x41, 0xF5);
    write_reg(fd, 0x42, (efuse_ts_code << 4) + 1);
    if (ramp_up_cap_delta > 0)
    {
        ts_code_up = efuse_ts_code - ramp_up_cap_delta;
        if (ts_code_up < 0)
            ts_code_up = 0;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_up << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }

    if (ramp_dn_cap_delta > 0)
    {
        ts_code_dn = efuse_ts_code + ramp_dn_cap_delta;
        if (ts_code_dn >= 7)
            ts_code_dn = 7;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_dn << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }
    (void)usleep(20*1000);
    serdes_wait_des_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_enable_oldi(int32 fd)
{
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Hold Des DTG in reset");
    write_reg(fd, 0x40, 0x50); //#Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02); //#Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x02); // #Hold Port 1 DTG in reset
    write_reg(fd, 0xDA, 0x00); // Override the OLDI Sync Mode

    CRITICAL_PRINT(MODULE_NAME, "Disable Stream Mapping");
    write_reg(fd, 0x0E, 0x03); //#Select both Output Ports
    write_reg(fd, 0xD0, 0x00); //#Disable FPD4 video forward to Output Port
    write_reg(fd, 0xD7, 0x00); //#Disable FPD3 video forward to Output Port

    CRITICAL_PRINT(MODULE_NAME, "Setup DTG for port 0");
    write_reg(fd, 0x40, 0x50); //#Select DTG Page
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0xA3); //#DTG detect HS active high and VS active high
    write_reg(fd, 0x41, 0x29); //#Set Hstart
    write_reg(fd, 0x42, 0x80); //#Hstart upper byte
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x60); //#Hstart lower byte
    write_reg(fd, 0x41, 0x2F); //#Set HSW
    write_reg(fd, 0x42, 0x40); //#HSW upper byte
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x14); //#HSW lower byte

    CRITICAL_PRINT(MODULE_NAME, "Map video to display output");
    write_reg(fd, 0x0E, 0x03); //#Select both Output Ports
    write_reg(fd, 0xD0, 0x0C); //#Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xD1, 0x0F); //Every stream forwarded on DC
    write_reg(fd, 0xD6, 0x00); //#Send Stream 0 to Output Port 0 and Send Stream 0 to Output Port 1
    write_reg(fd, 0xD7, 0x00); //#FPD3 mapping disabled
    write_reg(fd, 0x0E, 0x01); //#Select Port 0

    /* Port 0 11" OLDI */
    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    CRITICAL_PRINT(MODULE_NAME, "Configure 988 oLDI PLL");
    write_reg(fd, 0x40, 0x2C); //Configure OLDI/RGB Port Settings
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x40, 0x2E); //#Configure OLDI/RGB PLL
    write_reg(fd, 0x41, 0x08);
    write_reg(fd, 0x42, 0xD9); //#PLL_NUM23_16
    write_reg(fd, 0x42, 0x50); //#PLL_NUM15_8
    write_reg(fd, 0x42, 0x7B); //#PLL_NUM7_0
    write_reg(fd, 0x42, 0xFF); //#PLL_DEN23_16
    write_reg(fd, 0x42, 0xFF); //#PLL_DEN15_8
    write_reg(fd, 0x42, 0xA5); //#PLL_DEN7_0
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0x21); //#PLL_NDIV
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x11); //#TX_SEL_CLKDIV
    write_reg(fd, 0x40, 0x50); //#Configure Pixel Size
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x53);
/*
    CRITICAL_PRINT(MODULE_NAME, "Configure OLDI PLL SSCG");
    write_reg(fd, 0x40, 0x2C); //Page 11
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0x21);
    //PLL MASH order set to fractional
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x38);
    write_reg(fd, 0x42, 0x20);
    // Numerator set to 14241984
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x08);
    write_reg(fd, 0x42, 0xD9); // [23:16]
    write_reg(fd, 0x40, 0x2c); // Page 11
    write_reg(fd, 0x41, 0x09);
    write_reg(fd, 0x42, 0x50); // [15:8]
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0xC0); // [7:0]
    // Denominator set to 16777206
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0B);
    write_reg(fd, 0x42, 0xFF); // [23:16]
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0C);
    write_reg(fd, 0x42, 0xFF); // [15:8]
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0xF6); // [7:0]
    // PDIV = 1
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x00);
    // SSCG_EN Center Spread
    write_reg(fd, 0x40, 0x2c); // Page 11
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0xC0);
    // RAMPX_INC = 6310
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0xA6); // [7:0]
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x0F);
    write_reg(fd, 0x42, 0x98); // [14:8] + bit 8 = 1
    // RAMPX_STOP = 675
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x11);
    write_reg(fd, 0x42, 0x02); // [9:8]
    write_reg(fd, 0x40, 0x2C); // Page 11
    write_reg(fd, 0x41, 0x12);
    write_reg(fd, 0x42, 0xA3); // [7:0]

    write_reg(fd, 0x01, 0x40); //#OLDI Reset
    serdes_clear_link_crc_err_flag(fd);
    serdes_wait_des_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    */
    CRITICAL_PRINT(MODULE_NAME, "Release Des DTG reset");
    write_reg(fd, 0x40, 0x50);// #Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x00); //#Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x00);// #Release Des DTG reset

    CRITICAL_PRINT(MODULE_NAME, "Enable OLDI Output");
    write_reg(fd, 0x01, 0x40); //#OLDI Reset
    write_reg(fd, 0x40, 0x2C); //Enable OLDI/RGB
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x14);

    write_reg(fd, 0x41, 0x20); //P0 TX_EN (from strap?)
    write_reg(fd, 0x42, 0x80);

    write_reg(fd, 0x41, 0x22); //P1 TX_EN (from strap?)
    write_reg(fd, 0x42, 0x80);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd)
{
    uint32 lane01_status, lane23_status;
    static uint8  vp_status = 0, vp_status_tmp = 0, status_change = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    lane01_status = apb_read_reg(fd, APB_DP_RX, 0x43C);
    lane23_status = apb_read_reg(fd, APB_DP_RX, 0x440);
    read_reg(fd, 0x45, &vp_status);

    if (vp_status != vp_status_tmp)
    {
        CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
                vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);

        serdes_get_983_dp_rx_status(fd);
        vp_status_tmp = vp_status;

    }

    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377))
    {
        status_change = 1;
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        if (status_change == 1)
        {
            CRITICAL_PRINT(MODULE_NAME, "fail: | VP0:%d | VP1:%d | lane_status: 0x%x, 0x%x,",
                    vp_status & 0x1, (vp_status >> 1) & 0x01, lane01_status, lane23_status);
        }

        status_change = 0;
        return BRIDGECHIP_STATUS_FAILED;
    }
}

void serdes_get_983_dp_rx_status(int32 fd)
{
    uint32 dp_rate, lanes;
    uint32 h_res, h_pol, h_sync, h_back, h_total;
    uint32 v_res, v_pol, v_sync, v_back, v_total;
    uint32 lane01_status, lane23_status;
    uint8  vp_status;

    dp_rate = apb_read_reg(fd, APB_DP_RX, 0x400) * 27;
    lanes = apb_read_reg(fd, APB_DP_RX, 0x404);
    lane01_status = apb_read_reg(fd, APB_DP_RX, 0x43C);
    lane23_status = apb_read_reg(fd, APB_DP_RX, 0x440);
    h_res = apb_read_reg(fd, APB_DP_RX, 0x500);
    h_pol = apb_read_reg(fd, APB_DP_RX, 0x504);
    h_sync = apb_read_reg(fd, APB_DP_RX, 0x508);
    h_back = apb_read_reg(fd, APB_DP_RX, 0x50C) - h_sync;
    h_total = apb_read_reg(fd, APB_DP_RX, 0x510);
    v_res = apb_read_reg(fd, APB_DP_RX, 0x514);
    v_pol = apb_read_reg(fd, APB_DP_RX, 0x518);
    v_sync = apb_read_reg(fd, APB_DP_RX, 0x51C);
    v_back = apb_read_reg(fd, APB_DP_RX, 0x520) - v_sync;
    v_total = apb_read_reg(fd, APB_DP_RX, 0x524);

    read_reg(fd, 0x45, &vp_status);

    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "DP Lock Status");
    CRITICAL_PRINT(MODULE_NAME, "DP Rate: %d", dp_rate);
    CRITICAL_PRINT(MODULE_NAME, "Lanes: %d", lanes);
    CRITICAL_PRINT(MODULE_NAME, "Lane01 Status: 0x%x", lane01_status);
    CRITICAL_PRINT(MODULE_NAME, "Lane23 Status: 0x%x", lane23_status);
    CRITICAL_PRINT(MODULE_NAME, "H RES: %d", h_res);
    CRITICAL_PRINT(MODULE_NAME, "H POL: %d", h_pol);
    CRITICAL_PRINT(MODULE_NAME, "H SYNC WIDTH: %d", h_sync);
    CRITICAL_PRINT(MODULE_NAME, "H BACK PORCH: %d", h_back);
    CRITICAL_PRINT(MODULE_NAME, "H TOTAL: %d", h_total);
    CRITICAL_PRINT(MODULE_NAME, "v RES: %d", v_res);
    CRITICAL_PRINT(MODULE_NAME, "V POL: %d", v_pol);
    CRITICAL_PRINT(MODULE_NAME, "V SYNC WIDTH: %d", v_sync);
    CRITICAL_PRINT(MODULE_NAME, "V BACK PORCH: %d", v_back);
    CRITICAL_PRINT(MODULE_NAME, "V TOTAL: %d", v_total);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
            vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
}


BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8 regval = 0;
    int32 port0_linked = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x0c, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;
    }

    if (port0_linked == 1)
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        serdes_clear_link_crc_err_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }
}
static BridgeChip_StatusType disable_983_dp_line_reset(int32 fd)
{
    uint32 apb_data = 0;

    apb_data = apb_read_reg(fd, APB_DP_RX, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);
    apb_write_reg(fd, APB_DP_RX, 0xa0c, 1);
    apb_write_reg(fd, APB_DP_RX, 0xa0c, 1);
    apb_write_reg(fd, APB_DP_RX, 0xa0c, 1);
    apb_write_reg(fd, APB_DP_RX, 0xa0c, 1);
    apb_data = apb_read_reg(fd, APB_DP_RX, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup: Serializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(i2c_fh, 0x01, SER_RESET_DIGITAL_ALL);
    eStatus |= link_set_serializer_i2c_pass_through(i2c_fh);
    eStatus |= link_set_serializer_gpio(i2c_fh);
    eStatus |= link_set_serializer_fpd4(i2c_fh);
    eStatus |= link_set_serializer_dprx(i2c_fh);
    eStatus |= link_set_serializer_vp(i2c_fh);

    disable_983_dp_line_reset(i2c_fh);
    serdes_clear_link_crc_err_flag(i2c_fh);

    return eStatus;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup: Deserializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    link_set_serializer_video_input_reset(i2c_fh);
    CRITICAL_PRINT(MODULE_NAME, "Configure Deserializer");
    // CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer SSCG");
    // eStatus |= link_set_deserializer_enable_sscg(i2c_fh);
    // CRITICAL_PRINT(MODULE_NAME, "Enable Serializer SSCG");
    // eStatus |= link_set_serializer_enable_sscg(i2c_fh);
    eStatus |= link_set_deserializer_temp_optimization(i2c_fh);
    CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer oLDI");
    eStatus |= link_set_deserializer_enable_oldi(i2c_fh);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}


BridgeChip_StatusType recovery_ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Recovery: Serializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    if (reset_keep_dprx == 0)
    {
        write_reg(i2c_fh, 0x01, SER_RESET_DIGITAL_ALL);
    }
    //eStatus |= link_set_serializer_disable_sscg(i2c_fh);
    eStatus |= link_set_serializer_i2c_pass_through(i2c_fh);
    eStatus |= link_set_serializer_gpio(i2c_fh);
    eStatus |= link_set_serializer_fpd4(i2c_fh);
    eStatus |= link_set_serializer_dprx(i2c_fh);
    eStatus |= link_set_serializer_vp(i2c_fh);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;


}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

#ifdef __cplusplus
}
#endif
