#ifdef __cplusplus
extern "C"
{
#endif

#include "bc-com-res-mgr.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/dispatch.h>

#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "sus_res_comm_lib.h"
#include "libdisplaywakeup.h"
#include "disp_infras_int.h"
#include "ds90ux98x_init.h"
#include "screen_pwrmgr_common.h"

#define MODULE_NAME "DISP-INFRAS INX-VCD5 CS3.0"

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
    } while(0)

#define DISP_INFRAS_TOUCH_PM           "vcd-touch-pm"
#define DISP_INFRAS_BL_PM              "vcd-brightness-pm"
#define DISP_INFRAS_SUSRES_PATH        "/dev/vcd/suspend-resume-commander/control"

#define DISP_INFRAS_WKUP_CTRL_PATH     "/dev/wakeup-binder/control"
#define DISP_INFRAS_WKUP_CTRL_NAME     "vcd-wakeup"
#define DISP_INFRAS_WKUP_CTRL_ONLINE   "1"
#define DISP_INFRAS_WKUP_CTRL_OFFLINE  "0"
#define CLIENT_OPERATIONS_CNT 150

void display_state_notify(char *display_state)
{
    LOG_CRITICAL_INFO(MODULE_NAME, "VCD display_state %s \n", display_state);
    screen_pwr_data_t msg;
    int server_coid;

    if(0 == strcmp(display_state,"ready")) {
        msg.data = VCD_DISP_STATE_READY;
    } else if (0 == strcmp(display_state,"lost")) {
        msg.data = VCD_DISP_STATE_LOST;
    } else {
        LOG_CRITICAL_INFO(MODULE_NAME, "VCD display_state invalid agr\n");
        return;
    }
    if ((server_coid = name_open(DISP_STATE_ATTACH_POINT, 0)) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "name open %s failed, error %d(%s)",
                            DISP_STATE_ATTACH_POINT, server_coid, strerror(errno));
        return;
    }
    // We would have pre-defined data to stuff here
    msg.hdr.type = 0x00;
    msg.hdr.subtype = 0x00;
    if (MsgSend(server_coid, &msg, sizeof(msg), NULL, 0) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "VCD MsgSend error\n");
        goto fail;
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "display_state_notify Done\n");
fail:
    name_close(server_coid);
    return;
}

int BridgeChip_pdb_control(char *pdb_path, unsigned char val)
{

    FILE *pdb_fp = NULL;
    int ret_val = 0;

    pdb_fp = fopen (pdb_path, "r+");
    if (pdb_fp == NULL) {
        LOG_CRITICAL_INFO(MODULE_NAME, "open %s fail", pdb_path);
        return -1;
    }
    else{
        LOG_CRITICAL_INFO(MODULE_NAME, "-> 0x%x", val);
        rewind(pdb_fp);
        ret_val = fprintf(pdb_fp, "%x", val);
        if(ret_val != sizeof(unsigned char)) {
            LOG_CRITICAL_INFO(MODULE_NAME, "write %s fail", pdb_path);
            fclose(pdb_fp);
            pdb_fp = NULL;
            return -1;
        }
        fflush(pdb_fp);
        fclose(pdb_fp);
        BridgeChip_OSAL_SleepMs(10);
    }

    return 0;
}

BridgeChip_StatusType display_power_ctl(int32 enable)
{
    char cmd_value[8];
    int fh;
    int ret;

    LOG_CRITICAL_INFO(MODULE_NAME, "Enter %s\n", __func__);
    memset (cmd_value, 0, sizeof(cmd_value));
    if (enable == DISPLAY_WKUP_CTRL_ON)
        strcpy(cmd_value, "on");
    else if (enable == DISPLAY_WKUP_CTRL_OFF)
        strcpy(cmd_value, "off");
    else {
        LOG_CRITICAL_INFO(MODULE_NAME, "unknow power mode setting");
        return BRIDGECHIP_STATUS_FAILED;
    }

	fh = displaywakeup_status_open(DISP_INFRAS_WKUP_CTRL_PATH);
	if (fh < 0) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Could get access to status devnode: %s, error=%d", 
                            DISP_INFRAS_WKUP_CTRL_PATH, fh);
		return BRIDGECHIP_STATUS_FAILED;
	}

	ret = displaywakeup_ctrl_set(fh, "online", DISP_INFRAS_WKUP_CTRL_ONLINE);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Couldn't switch to online");
		goto fail;
	}
	ret = displaywakeup_ctrl_set(fh, DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME,"Couldn't set chain <%s> state to %s", DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
		goto fail;
	}
	displaywakeup_status_close(fh);
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s\n", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;

fail:
    displaywakeup_status_close(fh);
    return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType disp_infras_display_chain_control(int32 i2c_fh, int32 state)
{
    //TODO: need check return value of each functions
    if (DISPLAY_CHAIN_CTRL_OFF == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s OFF", __func__);
        BridgeChip_pdb_control(BRIDGECHIP_GPIO_PDB, DISPLAY_PDB_CTRL_OFF);
    } else if (DISPLAY_CHAIN_CTRL_ON == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s ON", __func__);
        BridgeChip_pdb_control(BRIDGECHIP_GPIO_PDB, DISPLAY_PDB_CTRL_ON);
        (void) usleep(100*1000); //wait ser ready after enable PDB
        set_reset_keep_dprx(0);
        ser_config_update(i2c_fh);
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType disp_infras_display_chain_recovery(int32 i2c_fh, int32 state, bc_com_i2c_st_t *bc_com_i2c)
{
    //TODO: need check return value of each functions
    if (DISPLAY_CHAIN_CTRL_OFF == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s OFF", __func__);
        display_state_notify("lost");
        display_power_ctl(DISPLAY_WKUP_CTRL_OFF);
        (void)usleep(200*1000); // delay 200ms for display power off ready. TODO: need be adjust for final display HW
    } else if (DISPLAY_CHAIN_CTRL_ON == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s ON", __func__);
        display_power_ctl(DISPLAY_WKUP_CTRL_ON);
        (void)usleep(200*1000); // delay 200ms for display power on ready. TODO: need be adjust for final display HW
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s", __func__);

    return BRIDGECHIP_STATUS_SUCCESS;
}

#ifdef __cplusplus
}
#endif
