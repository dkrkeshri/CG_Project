#ifndef DS90UX98X_INIT_H
#define DS90UX98X_INIT_H

#define SER_RESET_DIGITAL_ALL 0x02
#define SER_RESET_PLL_ONLY    0x30
BridgeChip_StatusType ser_config_update(int32 i2c_fh);
BridgeChip_StatusType serdes_get_ser_link_status(int32 fd);
BridgeChip_StatusType dser_config_update(int32 i2c_fh);
void set_reset_keep_dprx(int32 val);
BridgeChip_StatusType recovery_ser_config_update(int32 i2c_fh);
BridgeChip_StatusType serdes_wait_ser_fpd_linkup(int32 fd, int32 timeout);
void serdes_get_983_dp_rx_status(int32 fd);
BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd);
#endif
