#ifdef __cplusplus
extern "C"
{
#endif

#include "bc-com-res-mgr.h"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/dispatch.h>

#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "sus_res_comm_lib.h"
#include "libdisplaywakeup.h"
#include "disp_infras_int.h"
#include "ds90ux98x_init.h"
#include "screen_pwrmgr_common.h"

#define MODULE_NAME "ASIC39-TP-PM"

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
    } while(0)

#define DISP_INFRAS_TOUCH_PM           "vcd-touch-pm"
#define DISP_INFRAS_BL_PM              "vcd-brightness-pm"
#define DISP_INFRAS_SUSRES_PATH        "/dev/vcd/suspend-resume-commander/control"

#define DISP_INFRAS_WKUP_CTRL_PATH     "/dev/wakeup-binder/control"
#define DISP_INFRAS_WKUP_CTRL_NAME     "vcd-wakeup"
#define DISP_INFRAS_WKUP_CTRL_ONLINE   "1"
#define DISP_INFRAS_WKUP_CTRL_OFFLINE  "0"

#define RECOVERY_WAIT_TIMEOUT 180
#define RECOVERY_CHECKLINK_INTERVAL_MS 1000
#define RECOVERY_CHECKLINK_LOOP_TIMES (RECOVERY_WAIT_TIMEOUT*1000/RECOVERY_CHECKLINK_INTERVAL_MS)

#define CLIENT_OPERATIONS_CNT                 150

void display_state_notify(char *display_state)
{
    LOG_CRITICAL_INFO(MODULE_NAME, "IPC display_state %s \n", display_state);
    screen_pwr_data_t msg;
    int server_coid;
    
    if(0 == strcmp(display_state,"ready")) {
        msg.data = VCD_DISP_STATE_READY;
    } else if (0 == strcmp(display_state,"lost")) { 
        msg.data = VCD_DISP_STATE_LOST;
    } else {
        LOG_CRITICAL_INFO(MODULE_NAME, "IPC display_state invalid agr\n");
        return;
    }
    if ((server_coid = name_open(DISP_STATE_ATTACH_POINT, 0)) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "name open %s failed, error %d(%s)",
                            DISP_STATE_ATTACH_POINT, server_coid, strerror(errno));
        return;
    }
    // We would have pre-defined data to stuff here
    msg.hdr.type = 0x00;
    msg.hdr.subtype = 0x00;
    if (MsgSend(server_coid, &msg, sizeof(msg), NULL, 0) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "IPC  MsgSend error\n");
        goto fail;
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "display_state_notify Done\n");
fail:
    name_close(server_coid);
    return;
}

int BridgeChip_pdb_control(char *pdb_path, unsigned char val)
{

    FILE *pdb_fp;
    int ret_val;
    pdb_fp = fopen (pdb_path, "r+");
    if (pdb_fp == NULL) {
        LOG_CRITICAL_INFO(MODULE_NAME, "open %s fail", pdb_path);
        return -1;
    }
    else{
        LOG_CRITICAL_INFO(MODULE_NAME, "-> 0x%x", val);
        rewind(pdb_fp);
        ret_val = fprintf(pdb_fp, "%x", val);
        if(ret_val != sizeof(unsigned char)) {
            LOG_CRITICAL_INFO(MODULE_NAME, "write %s fail", pdb_path);
            fflush(pdb_fp);
			fclose(pdb_fp);
            return -1;
        }
        fflush(pdb_fp);
        fclose(pdb_fp);
        BridgeChip_OSAL_SleepMs(10);
    }
    return 0;
}

BridgeChip_StatusType display_power_ctl(int32 enable)
{
    char cmd_value[8];
    int fh;
    int ret;

    LOG_CRITICAL_INFO(MODULE_NAME, "Enter %s\n", __func__);
    memset (cmd_value, 0, sizeof(cmd_value));
    if (enable == DISPLAY_WKUP_CTRL_ON) 
        strcpy(cmd_value, "on");
    else if (enable == DISPLAY_WKUP_CTRL_OFF)
        strcpy(cmd_value, "off");
    else {
        LOG_CRITICAL_INFO(MODULE_NAME, "unknow power mode setting");
        return BRIDGECHIP_STATUS_FAILED;
    }

	fh = displaywakeup_status_open(DISP_INFRAS_WKUP_CTRL_PATH);
	if (fh < 0) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Could get access to status devnode: %s, error=%d", 
                            DISP_INFRAS_WKUP_CTRL_PATH, fh);
		return BRIDGECHIP_STATUS_FAILED;
	}

	ret = displaywakeup_ctrl_set(fh, "online", DISP_INFRAS_WKUP_CTRL_ONLINE);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Couldn't switch to online");
		goto fail;
	}
	ret = displaywakeup_ctrl_set(fh, DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME,"Couldn't set chain <%s> state to %s", DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
		goto fail;
	}
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s\n", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;

fail:
    displaywakeup_status_close(fh);
    return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType disp_infras_display_chain_control(int32 i2c_fh, int32 state)
{
    //TODO: need check return value of each functions
    if (DISPLAY_CHAIN_CTRL_OFF == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s OFF", __func__);
        //display_state_notify("suspend");
        //display_power_ctl(DISPLAY_WKUP_CTRL_OFF);
        BridgeChip_pdb_control(BRIDGECHIP_GPIO_PDB, DISPLAY_PDB_CTRL_OFF);
    } else if (DISPLAY_CHAIN_CTRL_ON == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s ON", __func__);
        BridgeChip_pdb_control(BRIDGECHIP_GPIO_PDB, DISPLAY_PDB_CTRL_ON);
        (void) usleep(50*1000); //wait ser ready after enable PDB
        //display_power_ctl(DISPLAY_WKUP_CTRL_ON);
        //usleep(500*1000); // delay 500ms for display ready. TODO: need be adjust for final display HW
        set_reset_keep_dprx(0);
        ser_config_update(i2c_fh);
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType disp_infras_display_chain_recovery(int32 i2c_fh, int32 state,
        bc_com_i2c_st_t *bc_com_i2c){
    //TODO: need check return value of each functions
    if (DISPLAY_CHAIN_CTRL_OFF == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s OFF", __func__);
        display_state_notify("lost");
        display_power_ctl(DISPLAY_WKUP_CTRL_OFF);
    } else if (DISPLAY_CHAIN_CTRL_ON == state) {
        int i;
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s ON", __func__);
        display_power_ctl(DISPLAY_WKUP_CTRL_ON);
        (void)usleep(500*1000); // delay 500ms for display ready. TODO: need be adjust for final display HW
        set_reset_keep_dprx(1);

        recovery_ti983_fpd3_init(i2c_fh);
        // check 180s to wait display linkup again
        for (i = 0; i < RECOVERY_CHECKLINK_LOOP_TIMES; i++) {
            bc_serve_clients(bc_com_i2c, CLIENT_OPERATIONS_CNT,
                             RECOVERY_CHECKLINK_INTERVAL_MS);

            // linkup : display powered on
            if ((serdes_get_ser_link_status(i2c_fh) == BRIDGECHIP_STATUS_SUCCESS)) {
                    //do switch over for 983 and 984
                    recovery_ti983_fpd4_init(i2c_fh);

                    //dp also need health: lane state and VP state
                    if (serdes_check_983_dp_linkup(i2c_fh) == BRIDGECHIP_STATUS_SUCCESS) {
                        break;
                    } else {
                        //redo 983 init and try again
                        recovery_ti983_fpd3_init(i2c_fh);
                    }
            }
        }

        if (i == RECOVERY_CHECKLINK_LOOP_TIMES) {
            //timeout: last chance to do switch over for 983 and 984
            recovery_ti983_fpd4_init(i2c_fh);
        }

        set_reset_keep_dprx(0);
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;
}

#if 0 //supply_handling method is not used anymore
static BridgeChip_StatusType check_supply_handling()
{
    if ( access("/dev/supply_handling", F_OK | W_OK) == 0)
        return BRIDGECHIP_STATUS_SUCCESS;
    else
        return BRIDGECHIP_STATUS_FAILED;
}

static BridgeChip_StatusType display_power_ctl(int32 enable)
{
    int32 fd = -1;
    int32 ret = -1;
    int32 data = 0;
    supply_ioctl_buf_t buf;

    if (check_supply_handling() != BRIDGECHIP_STATUS_SUCCESS)
    {
        LOG_CRITICAL_INFO(CHIP_ID, "Supply handling is not ready\n");
        return BRIDGECHIP_STATUS_FAILED;
    }

    LOG_CRITICAL_INFO(CHIP_ID, "Supply handling is ready\n");

    fd = open("/dev/supply_handling", O_RDWR);
    if (fd < 0)
    {
        LOG_CRITICAL_INFO(CHIP_ID, "open Supply handling failed\n");
        return BRIDGECHIP_STATUS_FAILED;
    }

    ret = devctl(fd, IOCTRL_SUPPLY_REGISTER_CLIENT, &data, sizeof(data), NULL);
    if (ret != 0)
    {
        LOG_CRITICAL_INFO(CHIP_ID, "Register Supply Client failed\n");
        close(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }

    buf.supply_id = SUPPLY_ID_DISPLAY0; //will define in supply_handling.h supply_id_t
    if (enable != 0) {
        buf.set_state = SUPPLY_STATE_ON; //SUPPLY_STATE
        LOG_CRITICAL_INFO(CHIP_ID, "Set SUPPLY_STATE_ON\n");
    } else {
        buf.set_state = SUPPLY_STATE_OFF; //SUPPLY_STATE
        LOG_CRITICAL_INFO(CHIP_ID, "Set SUPPLY_STATE_OFF\n");
    }

    ret = devctl(fd, IOCTRL_SUPPLY_SET_STATE, &buf, sizeof(buf), NULL);
    if (ret != 0)
    {
        LOG_CRITICAL_INFO(CHIP_ID, "Set supply state failed\n");
    }

    //unregister
    ret = devctl(fd, IOCTRL_SUPPLY_UNREGISTER_CLIENT, NULL, 0, NULL);

    if (ret != 0)
    {
        close(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }

    close (fd);

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif
#ifdef __cplusplus
}
#endif