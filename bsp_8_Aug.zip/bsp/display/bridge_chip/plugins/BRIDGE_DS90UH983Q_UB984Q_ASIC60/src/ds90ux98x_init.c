#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT       0x0C
#define DES_ID_7BIT       0x2C
#define MCU_ID_7BIT       0x12
#define TOUCH_ID_7BIT     0x24

#define SER_ID_8BIT       (SER_ID_7BIT << 1)      //0x18
#define DES_ID_8BIT       (DES_ID_7BIT << 1)      //0x58
#define MCU_ID_8BIT       (MCU_ID_7BIT << 1)      //0x24
#define TOUCH_ID_8BIT     (TOUCH_ID_7BIT << 1)    //0x48

#define THW               4680
#define TVW               1408
#define AHW               4480
#define AVW               1320
#define HBP               80
#define VBP               40
#define HSW               40
#define VSW               8
#define PCLK_FREQ         395.367
#define FC_FPD_FREQ       12.528
#define PAGE_REG          0x40
#define PAGE_ADDR         0x41
#define PAGE_DATA         0x42
#define PAGE_DISPPATTEN   0x30
#define HSTART            (HBP+HSW)
#define VIDEO_RESOLUTION  "ASIC60HZ"

static int32 verbosedebug = 1;
static int32 I2C_passthru = 1;
static float FPD3_PCLK = 148.5;
static int32 Bits_Per_Color = 10;
static uint16 src_v_front = 40;

static int32 DES_1_Video_ON = 1;
static int32 DES_1_DP_PORT_0 = 1;
static int32 DES_1_DP_PORT_1 = 1;
static int32 Force_Rate_DP_DES_1 = 1;
static int32 Force_Speed_DP_DES_1 = 5400;
static uint16 DP_Rate = 5400;
static uint16 nvid = 32768;
static float vid_freq = PCLK_FREQ;
static uint16 my_pixels = 4480;
static uint8 hsync_pol = 0;
static uint8 vsync_pol = 0;
#define FPD4_MODE 1
/**********************************************
 * Fixed parameters
 **********************************************/
static uint8 Bypass_PLL_Speed_Setting = 0;
static uint8 Enable_PLL_Jitter_Fix = 0;
static float Main_link_speed = FC_FPD_FREQ;
static float DES_1_link_speed = FC_FPD_FREQ;
static uint8 Bypass_Display_Panel = 0;
static uint8 VIDEO_CHECK_ENABLE_DES_1 = 0;
static uint8 CRC_WAIT = 1;   //seconds to check for errors
static uint8 Loop_RESET = 1; //Number of retries for Video CRC checking
static uint8 SOFT_RESET = 1;
static uint8 Force_960AEQ = 1;
static uint8 Enable_SHOW_ALL_COEFFICIENTS = 0;
static uint8 Enable_Experiments = 1;
static uint8 Enable_FIXED_CTLE = 0;
static uint8 Fixed_EQ_Val_0 = 15;
static uint8 Fixed_EQ_Val_1 = 15;
static uint8 Enable_EOM_OFFSET = 1;
static uint8 EOM_OFFSET_0 = 0x3B;
static uint8 EOM_OFFSET_1 = 0x3B;

/**********************************************
 * Bypass Script
 **********************************************/
static uint8 Bypass_960_AEQ_Optimization = 0;
static uint8 Bypass_CDR_Params = 0;
static uint8 Bypass_AEQ_MAP = 0;
static uint8 Bypass_LEVEL_SHIFTER = 0;
static uint8 Bypass_Echo_PI = 0;
static uint8 Bypass_SUM_BUFF_VGA_THRESHOLD = 0;
static uint8 Bypass_BC_Params = 0;
static uint8 Bypass_Post_Init_Reset = 0;
static uint8 Bypass_Link_Status = 0;
static uint8 Bypass_DFE_Monitors = 0;
static uint8 Bypass_CHECK_ALIGNMNET = 0;

static uint32 dp_mvalue, dp_nvalue;

static int32 reset_keep_dprx = 0;
#define MODULE_NAME "ASIC60HZ-FF"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

struct video_timing {
    uint32 htotal;
    uint32 vtotal;
    uint32 hres;
    uint32 vres;
    uint32 hstart;
    uint32 vstart;
    uint32 hswidth;
    uint32 vswidth;
};


static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset);
static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data);
//static BridgeChip_StatusType link_set_serializer_vp(int32 fd);

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "i2c_write failed 0x%x : 0x%x",  reg, val);
        //LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
    }

    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
		return -1;
    }

    return 0;
}

static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{
    uint8 bl_data[8] = {0x20, 0x65, 0x08,0xFF,0x7F,0xF0};

    i2c_write(fd, bl_data, 6);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd3(int32 fd)
{
    float vco_freq = FPD3_PCLK * 35;


    uint8 vco_cnt = (uint8)(vco_freq / 27 / 2);
    uint8 vco_sel = 0xC3;
    uint8 general_sts_p0, general_sts_p1;
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set Serializer to FPD-LINK III Mode, vco_cnt=0x%x, date=%s, time=%s",  vco_cnt, __DATE__, __TIME__);

    //sleep(2);
    if (I2C_passthru == 1) {
        write_reg(fd, 0x2B, 0x1C);
        write_reg(fd, 0x2C, 0x1C);
        write_reg(fd, 0x07, 0x88);
    }
    CRITICAL_PRINT(MODULE_NAME, "Set PLL TX_0 to %f Hz",  vco_freq);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, vco_sel);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, vco_cnt);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xF0);

    CRITICAL_PRINT(MODULE_NAME, "Set PLL TX_1 to %f Hz",  vco_freq);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x4E);
    write_reg(fd, 0x42, vco_sel);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, vco_cnt);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0xF0);

    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x5B, 0x2B);
    write_reg(fd, 0x05, 0x00);
    write_reg(fd, 0x02, 0xF0);
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x59, 0x03);

    read_reg(fd, 0x30, &RevId);

    if (Enable_PLL_Jitter_Fix == 1)
    {
        CRITICAL_PRINT(MODULE_NAME, "PLL-TX Jitter Improvements Enabled");
        write_reg(fd, 0x40, 0x08);

        write_reg(fd, 0x41, 0x23);
        write_reg(fd, 0x42, 0x3F);
        write_reg(fd, 0x41, 0x24);
        write_reg(fd, 0x42, 0x23);
        write_reg(fd, 0x41, 0x21);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x2F);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x0E);
        write_reg(fd, 0x42, 0x47);

        write_reg(fd, 0x41, 0x63);
        write_reg(fd, 0x42, 0x3F);
        write_reg(fd, 0x41, 0x64);
        write_reg(fd, 0x42, 0x23);
        write_reg(fd, 0x41, 0x61);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x6F);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x4E);
        write_reg(fd, 0x42, 0x47);
    }
/*
    write_reg(fd, 0x40, 0x04);
    // Lane 0 TX
    write_reg(fd, 0x41, 0x00); // Reg0x00 and Reg0x0A should have same value.
    write_reg(fd, 0x42, 0x01); // Allowed values are 0x00 0x01 0x03 0x07 0x0F
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x01);
    // Lane 1 TX
    write_reg(fd, 0x41, 0x20); // Reg0x20 and Reg0x2A should have same value.
    write_reg(fd, 0x42, 0x01); // Allowed values are 0x00 0x01 0x03 0x07 0x0F
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x01);
*/

    CRITICAL_PRINT(MODULE_NAME, "Soft Reset Serializer");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    //sleep(1);
    write_reg(fd, 0x2D, 0x01);

    CRITICAL_PRINT(MODULE_NAME, "Main-Link DES Address Set to 0x%x",  DES_ID_8BIT >> 1);
    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, TOUCH_ID_8BIT);
    write_reg(fd, 0x7A, TOUCH_ID_8BIT);

    // Config GPIOs for Touch IRQ
    if (RevId >= 0x40)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x02, 0xF0); // Clear CRC
    write_reg(fd, 0x02, 0xD0); // Clear CRC
    write_reg(fd, 0x2D, 0x12);
    write_reg(fd, 0x02, 0xF0); // Clear CRC
    write_reg(fd, 0x02, 0xD0); // Clear CRC

    //sleep(1);

    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0C, &general_sts_p0);
    CRITICAL_PRINT(MODULE_NAME, "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG 0x%x, LINK_DETECT: 0x%x",
            (general_sts_p0 >> 4) & 0x01, (general_sts_p0 >> 1) & 0x01, general_sts_p0 & 0x01);
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0C, &general_sts_p1);
    CRITICAL_PRINT(MODULE_NAME, "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG 0x%x, LINK_DETECT: 0x%x",
            (general_sts_p1 >> 4) & 0x01, (general_sts_p1 >> 1) & 0x01, general_sts_p1 & 0x01);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType link_set_serializer_patgen(int32 fd)
{
    uint8  PATGEN_IA = 0x2A;
    uint8  PATGEN_ID = 0x2B;
    uint8 PAGE_DISPPATTGEN = 0x30;

    write_reg(fd,PAGE_REG,PAGE_DISPPATTGEN);

    // Pixel Setting
    CRITICAL_PRINT(MODULE_NAME, "VP0 Color Depth Set To: %d bpc",  Bits_Per_Color);
    if (Bits_Per_Color == 6)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x44);
    }
    else if (Bits_Per_Color == 8)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x4c);
    }
    else if (Bits_Per_Color == 10)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x14);
    }

    // Start programming patgen parameters from register 0x06 - 0x16 (Bit 7 is auto-increment for address)
    write_reg(fd, PAGE_ADDR, PATGEN_IA);
    write_reg(fd, PAGE_DATA, 0x86);
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID); // Set HSYNC and VSYNC polarity positive (Default=negative)
    write_reg(fd, PAGE_DATA, 0x00);

    // Enable patgen
    write_reg(fd, PAGE_ADDR, 0x28);
    write_reg(fd, PAGE_DATA, 0x95); //Color Bar Pattern
    write_reg(fd, PAGE_ADDR, 0x29);
    write_reg(fd, PAGE_DATA, 0x08);

    // VP1
    // Pixel Setting
    CRITICAL_PRINT(MODULE_NAME, "VP1 Color Depth Set To: %d bpc",  Bits_Per_Color);
    if (Bits_Per_Color == 6)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x00);
    }
    else if (Bits_Per_Color == 8)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x08);
    }
    else if (Bits_Per_Color == 10)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x14);
    }
    PATGEN_IA = 0x6A;
    PATGEN_ID = 0x6B;

    write_reg(fd, PAGE_ADDR, PATGEN_IA);
    write_reg(fd, PAGE_DATA, 0x86);
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID); // Set HSYNC and VSYNC polarity positive (Default=negative)
    write_reg(fd, PAGE_DATA, 0x00);
    // Enable patgen
    write_reg(fd, PAGE_ADDR, 0x68);
    write_reg(fd, PAGE_DATA, 0x95); //vertical black to white
    write_reg(fd, PAGE_ADDR, 0x69);
    write_reg(fd, PAGE_DATA, 0x08);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{

    uint8 n_value = 15;
    uint8 addr0, addr1;
    float fc_freq = 0;
    float src_pclk_freq = PCLK_FREQ;
    float m_value_f;
    uint16 m_value;
    uint16 src_dp_h_active = AHW;

    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x32);
    // Set crop value on video processor 0
    // set crop start as default (0, 0)
    // set crop stop as (4480, 1320)

    // set crop stop x to 4480-1
    write_reg(fd, 0x41, 0x0C);
    write_reg(fd, 0x42, lower_byte(AHW-1));
    write_reg(fd, 0x42, upper_byte(AHW-1));

    // set crop stop y to to 1320-1
    write_reg(fd, 0x42, lower_byte(AVW-1));
    write_reg(fd, 0x42, upper_byte(AVW-1));

    // set crop value on video processor 1
    // set crop start as default (4480, 0)
    // set crop stop as (8960, 1320)

    //  set crop start x to 4480
    write_reg(fd, 0x41, 0x48);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set crop start y to 0
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x42, 0x00);

    // set crop stop x to 8960-1
    write_reg(fd, 0x42, lower_byte(AHW+AHW-1));
    write_reg(fd, 0x42, upper_byte(AHW+AHW-1));

    // set crop stop y to 1320-1
    write_reg(fd, 0x42, lower_byte(AVW-1));
    write_reg(fd, 0x42, upper_byte(AVW-1));


    // Enable cropping/filtering in VPs
    // enable cropping on VP0
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x04);

    // enable cropping/filtering on VP1
    write_reg(fd, 0x41, 0x40);
    write_reg(fd, 0x42, 0x04);

    // Set Stream Source to VPs
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0xA8); //SST0 for VP0
    write_reg(fd, 0x41, 0x41);
    write_reg(fd, 0x42, 0xA8); //SST0 for VP1

    // set timing on video processor 0
    addr0 = 0x02;
    addr1 = 0x10;
    // set dp_h_active
    write_reg(fd, 0x41, addr0); // dp_h_active
    write_reg(fd, 0x42, lower_byte(src_dp_h_active));
    write_reg(fd, 0x42, upper_byte(src_dp_h_active));

    // set video timing generator h_active
    write_reg(fd, 0x41, addr1); // h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_back
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW));

    // set video timing generator v_active
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    write_reg(fd, 0x42, lower_byte(src_v_front));
    write_reg(fd, 0x42, upper_byte(src_v_front));

    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //10800  bps

    //  half rate mode
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "m_value = %d",  m_value);
    // full rate mode
    // m_value = sub_pclk_freq / 4.0 * (2 ^ n_value) / (fc_freq/80)

    // set m/n value for video processor 0
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);

    // set timing on video processor 1
    // choose page 12, set auto-increment
    write_reg(fd, 0x40, 0x32);

    addr0 = 0x42;
    addr1 = 0x50;
    CRITICAL_PRINT(MODULE_NAME, "video processor 1 addr0 = 0x%02x, addr1=0x%02x",  addr0, addr1);

    // set timing on video processor 1
    // set dp_h_active
    write_reg(fd, 0x41, addr0);  // dp_h_active
    write_reg(fd, 0x42, lower_byte(src_dp_h_active));
    write_reg(fd, 0x42, upper_byte(src_dp_h_active));

    // set video timing generator h_active
    write_reg(fd, 0x41, addr1); // h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_back
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW));

    // set video timing generator v_active
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    write_reg(fd, 0x42, lower_byte(src_v_front));
    write_reg(fd, 0x42, upper_byte(src_v_front));


    // set m/n value for video processor 1
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;

    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //10800 bps

    // half rate mode
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq/40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "m_value = %d",  m_value);

    // set m/n value for video processor 1
    write_reg(fd, 0x41, 0x63);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);

    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0xff);

    // main page: set number of video streams
    write_reg(fd, 0x43, 0x01);

    // enable video processor 0
    write_reg(fd, 0x44, 0x03);

    // Config TX link layer

    // enable link layer stream
    // only for FPD4 mode
    // choose page 11, set auto-increment
    write_reg(fd, 0x40, 0x2E);

    // enable link layer 0, stream 0
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x03);
    write_reg(fd, 0x41, 0x02);  //map vp1 to stream 0, vp0 to stream 1
    write_reg(fd, 0x42, 0x01);

    // map video processor output to link layer stream
    // only for FPD4 mode
    // Set link layer to 30bpp
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x5A);
    // assign slots to link layer stream
    // only for FPD4 mode
    // assign 32 slots to each link layer stream
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x20);
    write_reg(fd, 0x41, 0x07);
    write_reg(fd, 0x42, 0x20);

    // enable link layer
    // only for FPD4 mode
    // enable link layer 0
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);

    return BRIDGECHIP_STATUS_SUCCESS;
}

bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;

    if (read_reg(fd, 0x00, &regval) == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", regval, chipId);
        if (regval == chipId)
            return TRUE;
        else
            return FALSE;
    } else {
        return FALSE;
    }
}

static void force_fixed_ctle_setting(int fd, uint8 eq0, uint8 eq1, uint8 en_override)
{
    uint8 set_ctle_0;
    uint8 set_ctle_1;
    uint8 read_val;

    if (en_override == 1)
    {
        CRITICAL_PRINT(MODULE_NAME, "FIX CTLE VALUE FORCED");
        set_ctle_0 = 0x40 + eq0;
        set_ctle_1 = 0x40 + eq1;
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "FIX CTLE VALUE Released");
        set_ctle_0 = 0x00 + eq0;
        set_ctle_1 = 0x00 + eq1;
    }
    write_reg(fd, 0x40, 0x38); // SELECT AEQ_SNS PAGE
    write_reg(fd, 0x41, 0x1A);
    write_reg(fd, 0x42, set_ctle_0);
    read_reg(fd, 0x42, &read_val);
    CRITICAL_PRINT(MODULE_NAME, "CTLE0 (DEC) Set to:  0x%02x", read_val - 64);
    write_reg(fd, 0x41, 0x4A);
    write_reg(fd, 0x42, set_ctle_1);
    read_reg(fd, 0x42, &read_val);
    CRITICAL_PRINT(MODULE_NAME, "CTLE1 (DEC) Set to:  0x%02x", read_val - 64);

    return;
}

static void vga_thresholds_adjust(int fd, uint8 low_thr, uint8 high_thr, uint8 vga_sweep_thr, uint8 port)
{
    uint8 reg = 0;
    uint8 value_54 = 0;
    uint8 value_30 = 0;

    if (port == 0)
        reg = 0x54;
    else if (port == 1)
        reg = 0x58;

    write_reg(fd, 0x40, reg);
    write_reg(fd, 0x41, 0x2B);
    write_reg(fd, 0x42, vga_sweep_thr);

    //LOW_THR = 14 #0x14=20(Dec)
    value_54 = (low_thr >> 4) & 0x3;
    value_30 = (low_thr & 0x0F);
    write_reg(fd, 0x40, reg); //  PAGE Select
    write_reg(fd, 0x41, 0x7B);
    write_reg(fd, 0x42, value_30 << 4); // LOW VGA THRESHOLD
    write_reg(fd, 0x41, 0x7A);
    write_reg(fd, 0x42, value_54 << 4); // LOW VGA THRESHOLD

    // HIGH_THR = 24 # 0x37=55 (55 DEC * 6.5mV) =Default
    write_reg(fd, 0x40, reg); //  PAGE Select
    write_reg(fd, 0x41, 0x89); // VGA HIGH THRESHOLD [5:0] => Default 0x37
    //write_reg(fd, 0x42, 0x37) // DEFAULT
    write_reg(fd, 0x42, high_thr); // Proposed

    return;
}

static void replica_rdac(int fd, uint8 ch0_rdac, uint8 ch1_rdac)
{
    //Echo Canceller Setting and PI
    //CRITICAL_PRINT(MODULE_NAME," ECHO-R_DAC Optimization"
    write_reg(fd, 0x40, 23*4);     //Page TOC 0 & 1
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, ch0_rdac); //fpd_rx_rep_rdac_en [5:0]
    write_reg(fd, 0x41, 0xA6);
    write_reg(fd, 0x42, ch1_rdac); //fpd_rx_rep_rdac_en [5:0]

    return;
}

static uint8 EOM_OFFSET(int fd, int8 eom_offset, uint8 port)
{
    uint8 e_offset = 0;
    int8 e_offset_add = 0;
    uint8 REG1 = 0, REG2 = 0;

    if (port == 0)
    {
        REG1 = 0x1C;
        REG2 = 0x5C;
    }
    else if (port == 1)
    {
        REG1 = 0x9C;
        REG2 = 0x58;
    }
    write_reg(fd, 0x40, 0x5C);
    write_reg(fd, 0x40, REG1);
    read_reg(fd, 0x42, &e_offset);
    e_offset_add = e_offset + eom_offset;

    if (e_offset_add > 63)
    {
        e_offset_add = e_offset_add - 64;
    }
    else if (e_offset_add < 0)
    {
        e_offset_add = e_offset_add + 64;
    }
    else
    {
        e_offset_add = e_offset_add;
    }

    write_reg(fd, 0x40, REG2);
    write_reg(fd, 0x41, 0x3F);
    write_reg(fd, 0x40, (e_offset_add << 1) + 1);

    return e_offset_add;
}

static BridgeChip_StatusType link_set_deserializer_video_misc(int32 fd)
{
    uint8 value;
    uint8 reg, data, ch_offset;
    // Bypass Initialization
    uint8 Bypass_VGA_GAIN = 0;
    uint8 VGA_GAIN_P0 = 0x10 + 6; // 4 (0-15)
    uint8 VGA_GAIN_P1 = 0x10 + 6; // 10 (0-15)

    uint8 AC_ATTEN_CORNER_HIGH_FREQ = 1;
    uint8 VGA_BW_TUNE = 0;
    uint8 LF_BOOST = 0;
    uint8 C_EQ2_BOOST = 1;
    uint8 C_EQ3_BOOST = 1;
    uint8 data_lsb;
    uint8 data_msb;

    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x00, &value);

    if (value == DES_ID_8BIT)
    {
        CRITICAL_PRINT(MODULE_NAME, "Main-Link RX Device ID: 0x%02x",  value);
        read_reg(fd, 0x24, &value);
        CRITICAL_PRINT(MODULE_NAME, "Current Mode Selected (Reg 0x24): 0x%02x",  value);
/*
        CRITICAL_PRINT(MODULE_NAME,"Hold DTG In Reset");
        write_reg(fd, 0x40, 0x50);
        write_reg(fd, 0x41, 0x32);
        write_reg(fd, 0x42, 0x02);
        write_reg(fd, 0x41, 0x32 + 0x30);
        write_reg(fd, 0x42, 0x02);
*/
        if (Enable_PLL_Jitter_Fix == 1)
        {
            write_reg(fd, 0x40, 0x0C);
            write_reg(fd, 0x41, 0x23);
            write_reg(fd, 0x42, 0x3F); //ICP
            write_reg(fd, 0x41, 0x24);
            write_reg(fd, 0x42, 0x0F); //rzero  #0x23
            write_reg(fd, 0x41, 0x21); //cdac_filter
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x2f); //r4 and filter cap
            write_reg(fd, 0x42, 0x00);

            write_reg(fd, 0x41, 0x63);
            write_reg(fd, 0x42, 0x3F); //ICP
            write_reg(fd, 0x41, 0x64);
            write_reg(fd, 0x42, 0x0F); //rzero #23
            write_reg(fd, 0x41, 0x61); //cdac_filter
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x6f); //r4 and filter cap
            write_reg(fd, 0x42, 0x00);
        }

        if (Enable_Experiments == 1)
        {
            // print "ODAC Timer Increased M"
            write_reg(fd, 0x40, 0x54);
            write_reg(fd, 0x41, 0x28);
            write_reg(fd, 0x42, 0x1F);
            write_reg(fd, 0x40, 0x58);
            write_reg(fd, 0x41, 0x28);
            write_reg(fd, 0x42, 0x1F);
        }

        if (Force_960AEQ == 1)
        {
            uint8 Adapt_Mode = 0x01;	       // 0x00: AEQ_SNS+CTLE_LMS, 0x01: 960_AEQ
            // print "Setting Adaptation Mode"
            write_reg(fd, 0x0e, 0x03);          // Port 0
            write_reg(fd, 0x60, 0x0f);          // Increase Timers
            write_reg(fd, 0x61, Adapt_Mode);    // Sets Adapt Mode
            write_reg(fd, 0x0e, 0x01);          //  Port 0
            // print "Adaptation Mode CH0: ", board.ReadI2C(Device_RX, 0x61)
            (void) usleep(100*1000);//
            write_reg(fd, 0x0e, 0x12);          //  Port 1
            // print "Adaptation Mode CH1: ", board.ReadI2C(Device_RX, 0x61)
            (void) usleep(100*1000);//
            if (Adapt_Mode == 0x01)
            {
                write_reg(fd, 0x0E, 0x01); //
                write_reg(fd, 0x95, 0x06); //  BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ
                write_reg(fd, 0x0E, 0x12); //
                write_reg(fd, 0x95, 0x06); //  BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ 
            }
            write_reg(fd, 0x0E, 0x01);//
        }


        if (Bypass_PLL_Speed_Setting == 0)
        {
            uint8 Value_Main = (uint8)(Main_link_speed * 1000 / 27 / 4);
            uint8 Value;

            CRITICAL_PRINT(MODULE_NAME,
                    "Setting Main-Link PLL_RX to %f GHz, Value_Main : 0x%x" ,
                    DES_1_link_speed, Value_Main);
            Value_Main = (uint8)(Main_link_speed*1000/27/4);
            CRITICAL_PRINT(MODULE_NAME,
                    "Setting Main-Link PLL_RX to %f GHz, Value_Main : 0x%x" ,
                    DES_1_link_speed, Value_Main);

            write_reg(fd, 0x40, 0x08);//  # Page 2 on 984
            write_reg(fd, 0x41, 0x05);//
            write_reg(fd, 0x42, Value_Main);// # NCount [7:0]   #7D
            //write_reg(fd, 0x42, 0x74);// # NCount [7:0]   #73
            write_reg(fd, 0x41, 0x13);//
            write_reg(fd, 0x42, 0x80);// # Divider = 1

            write_reg(fd, 0x0E, 0x01);//
            CRITICAL_PRINT(MODULE_NAME, "SOFT RESET PLL_RX");
            /*
               write_reg(fd, 0x01, 0x80);
               print "SOFT RESET PLL_TX0";
               write_reg(fd, 0x01, 0x20);
               print "SOFT RESET PLL_TX1";
               write_reg(fd, 0x01, 0x10);
               */
            write_reg(fd, 0x40, 0x08);//
            write_reg(fd, 0x41, 0x07);//
            read_reg(fd, 0x42, &Value);//
            CRITICAL_PRINT(MODULE_NAME,
                    "PLL_RX_LOCK: 0x%x PLL_VCNTRL_HIGH= 0x%x  PLL_VCNTL_LOW: 0x%x ",
                    (Value & 0x01), (Value >> 4) & 0x01, (Value >> 3) & 0x01);
            // print "[7:5]: RSRVD, [4]:pll_vcntrl_high, [3]:pll_vcntrl_low, [2:1]:RSRVD, [0]:PLL_LOCK"

        }

        if (Bypass_960_AEQ_Optimization == 0)
        {
            // Error Thresholds on 960 AEQ
            // print "Change AEQ-960 Defaults"
            write_reg(fd, 0x40, 0x38);// # SELECT PAGE AEQ_SNS

            write_reg(fd, 0x41, 0x2C);//
            write_reg(fd, 0x42, 0x01);//  #[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
            write_reg(fd, 0x41, 0x24);//
            write_reg(fd, 0x42, 0x45);//  #[6]: S-Filter_EN, AEQ Timer [2:0]   ===> HUGE DIFFERENCE IN LOCK WHEN 0x45 vs 0x46, or 47, or 44

            write_reg(fd, 0x41, 0x5C);//
            write_reg(fd, 0x42, 0x01);//   #[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
            write_reg(fd, 0x41, 0x54);//
            write_reg(fd, 0x42, 0x45);//  #AEQ Timer [2:0]

            // print "End of 960 Opt"
        }

        if (Bypass_SUM_BUFF_VGA_THRESHOLD == 0)
        {
            vga_thresholds_adjust(fd, 30, 50, 50, 0);
            vga_thresholds_adjust(fd, 30, 50, 50, 1);
        }

        if (Bypass_VGA_GAIN == 0)
        {
            //CRITICAL_PRINT(MODULE_NAME," VGA Gain Override"
            write_reg(fd, 0x40, 0x38);        // AEQ_SENSOR PAGE
            write_reg(fd, 0x41, 0x1B);
            write_reg(fd, 0x42, VGA_GAIN_P0); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"
            write_reg(fd, 0x41, 0x4B);
            write_reg(fd, 0x42, VGA_GAIN_P1); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"
        }
        if (Bypass_CDR_Params == 0)
        {
            //CRITICAL_PRINT(MODULE_NAME," CDR Parameters Changed"
            write_reg(fd, 0x40, 0x54); // SO DROP
            write_reg(fd, 0x41, 0x44);
            write_reg(fd, 0x42, 0x1C); // Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop, 

            write_reg(fd, 0x40, 0x54);
            write_reg(fd, 0x41, 0xAA);
            write_reg(fd, 0x42, 0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

            write_reg(fd, 0x41, 0xAB); // [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1
            write_reg(fd, 0x42, 0x0E); //5 Efuse

            write_reg(fd, 0x40, 0x58);
            write_reg(fd, 0x41, 0x44);
            write_reg(fd, 0x42, 0x1C); //5 Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop, 

            write_reg(fd, 0x40, 0x58);
            write_reg(fd, 0x41, 0xAA);
            write_reg(fd, 0x42, 0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

            write_reg(fd, 0x41, 0xAB);
            write_reg(fd, 0x42, 0x0E); //5 [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1
        }

        if (Bypass_BC_Params == 0)
        {
            //CRITICAL_PRINT(MODULE_NAME," Diable iPWM"
            write_reg(fd, 0x0e, 0x03); // Port 0
            write_reg(fd, 0xB9, 0x0F); //NTUNE [4:0]
            write_reg(fd, 0xBA, 0x13); //PTUNE [4:0]
            write_reg(fd, 0xBB, 0x01); //Enable iPWM
            write_reg(fd, 0x0e, 0x01);

            //Enable Driver R-BIAS
            write_reg(fd, 0x40, 15*4); // DFT PAGE
            write_reg(fd, 0x41, 0x3A); // [3]:reg_fpd_rx_en_drv_rbias_ov_en_p0, [2]:reg_fpd_rx_en_drv_rbias_ov_p0,[1]:reg_fpd_rx_en_drv_rbias_ov_en_p1, [0]:reg_fpd_rx_en_drv_rbias_ov_p1
            write_reg(fd, 0x42, 0x0F);

            write_reg(fd, 0x40, 0x10); // Page FPD_RX Analog

            ch_offset = 0x00;

            reg = 0x01; // [7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x02; //[7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
            data = 0x13;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x03; // //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
            data = 0x13;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x04;  //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x05;  //[7]=EN_TX_DRV (SPARE), [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
            data = 0x00;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
            data = 0x0A;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x08;  // [7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
            data = 0x14;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            ch_offset = 0x10;

            reg = 0x01; //[7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x02; // [7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x03; //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
            data = 0x33;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x04; //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
            data = 0x14;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x05; //[7]=EN_TX_DRV (SPARE), [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
            data = 0x00;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
            data = 0x0A;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x08; //[7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
            data = 0x14;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);

            reg = 0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
            data = 0x0F;
            write_reg(fd, 0x41, ch_offset + reg);
            write_reg(fd, 0x42, data);
        }

        if (Bypass_AEQ_MAP == 0)
        {
            //AEQ MAP Changes
            //CRITICAL_PRINT(MODULE_NAME," AEQ MAPPING (FPD4) TABLE OPTIMIZATION"
            write_reg(fd, 0x40, 0x38); // Select AEQ_SENS PAGE

            AC_ATTEN_CORNER_HIGH_FREQ = 1;
            VGA_BW_TUNE = 0;
            value = (AC_ATTEN_CORNER_HIGH_FREQ << 6)+ (VGA_BW_TUNE << 4) ;
            //CRITICAL_PRINT(MODULE_NAME," 0x0E=",Value
            //CRITICAL_PRINT(MODULE_NAME," 0x3E=",Value
            write_reg(fd, 0x41, 0x0E);
            write_reg(fd, 0x42, value);
            write_reg(fd, 0x41, 0x3E);
            write_reg(fd, 0x42, value);

            C_EQ2_BOOST = 1;
            LF_BOOST = 0;
            value = C_EQ2_BOOST << 4;
            value = value + LF_BOOST;
            //#CRITICAL_PRINT(MODULE_NAME," 0x0F=",Value
            //#CRITICAL_PRINT(MODULE_NAME," 0x3F=",Value
            write_reg(fd, 0x41, 0x0F);
            write_reg(fd, 0x42, value);
            write_reg(fd, 0x41, 0x3F);
            write_reg(fd, 0x42, value);

            C_EQ3_BOOST = 1;
            LF_BOOST = 0;
            value = C_EQ3_BOOST << 4;
            value = value + LF_BOOST;
            //CRITICAL_PRINT(MODULE_NAME," 0x10=",Value
            //CRITICAL_PRINT(MODULE_NAME," 0x10=",Value
            write_reg(fd, 0x41, 0x10);
            write_reg(fd, 0x42, value);
            write_reg(fd, 0x41, 0x40);
            write_reg(fd, 0x42, value);

            write_reg(fd, 0x41, 0x69);
            write_reg(fd, 0x42, 0x90); //opt = 0xcc
            write_reg(fd, 0x41, 0x6A);
            write_reg(fd, 0x42, 0xAA); //opt = 0xcc
            write_reg(fd, 0x41, 0x6B);
            write_reg(fd, 0x42, 0xAA); //opt = 0xcc
            write_reg(fd, 0x41, 0x6C);
            write_reg(fd, 0x42, 0xAA); //opt = 0x0c
            data_lsb = 0;              // Opt=2
            data_msb = 1  << 3;         //Opt=2
            write_reg(fd, 0x41, 0x6D);
            write_reg(fd, 0x42, data_lsb + data_msb);
            // CRITICAL_PRINT(MODULE_NAME," 0x6D:",hex(EQ_MSB+EQ_LSB);
            data_lsb = 2;        //Opt=2
            data_msb = 3 << 3;   //Opt=2
            write_reg(fd, 0x41, 0x6E);
            //write_reg(fd, 0x42, 0x1a)  #EFUSE & DEFAULT
            write_reg(fd, 0x42, data_lsb + data_msb);
            //CRITICAL_PRINT(MODULE_NAME," 0x6E:",hex(EQ_MSB+EQ_LSB)

            data_lsb = 3;       // Opt=2
            data_msb = 4 << 3;  // Opt=2
            write_reg(fd, 0x41, 0x6F);
            //write_reg(fd, 0x42, 0x2c) #EFUSE & DEFAULT
            write_reg(fd, 0x42, data_lsb + data_msb);
            //CRITICAL_PRINT(MODULE_NAME," 0x6F:",hex(EQ_MSB+EQ_LSB)

            data_lsb = 5; //Opt=2
            write_reg(fd, 0x41, 0x70);
            //write_reg(fd, 0x42, 0x05) #EFUSE & DEFAULT
            write_reg(fd, 0x42, data_lsb);
            //CRITICAL_PRINT(MODULE_NAME," 0x70:",hex(EQ_MSB+EQ_LSB)

            write_reg(fd, 0x41, 0x71);
            //write_reg(fd, 0x42, 0x04) # DEFAULT
            write_reg(fd, 0x42, 0x20); // TC3 EFUSE CHANGE

            write_reg(fd, 0x41, 0x72);
            write_reg(fd, 0x42, 0x29); // TC3 EFUSE CHANGE
            write_reg(fd, 0x41, 0x73);
            write_reg(fd, 0x42, 0x32); // TC3 EFUSE CHANGE
            write_reg(fd, 0x41, 0x74);
            write_reg(fd, 0x42, 0x07); // DEFAULT
            write_reg(fd, 0x41, 0x75);
            write_reg(fd, 0x42, 0x3B); // New CHANGE
            CRITICAL_PRINT(MODULE_NAME, "Done w/ AEQ_MAP");
        }

        if (Bypass_LEVEL_SHIFTER == 0)
        {
            CRITICAL_PRINT(MODULE_NAME, "Setting Level-Shifter Change");

            write_reg(fd, 0x40, 23 * 4);
            write_reg(fd, 0x41, 0x34);
            write_reg(fd, 0x42, 0xFF); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
            write_reg(fd, 0x41, 0x35);
            write_reg(fd, 0x42, 0x00); // fpd_rx_sel_thresh_m_9_8 #[3:2]
            write_reg(fd, 0x41, 0x34 + 0x80);
            write_reg(fd, 0x42, 0xFF); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
            write_reg(fd, 0x41, 0x35 + 0x80);
            write_reg(fd, 0x42, 0x00); // fpd_rx_sel_thresh_m_9_8 #[3:2]
        }
        if (Bypass_Echo_PI == 0)
        {
            replica_rdac(fd, 0x1C, 0x1C);
            //CRITICAL_PRINT(MODULE_NAME," EchoC Canceller & PI Optimization"
            write_reg(fd, 0x40, 0x10); // SELECT Analog RX PAG
            //Channel 0/1: ECHO_C_DAC=>[7]:RSRVD, [6:4]:pi_i_dac_lv<2:0>,[3]:RSRVD, [2:0]:CDAC"
            write_reg(fd, 0x41, 0x0A);
            write_reg(fd, 0x42, 0x04);  // MH=0x20 (BEST)
            write_reg(fd, 0x41, 0x1A);
            write_reg(fd, 0x42, 0x04);  // MH=0x20 (BEST)
        }
        if (Bypass_Post_Init_Reset == 0)
        {
            //CRITICAL_PRINT(MODULE_NAME," Soft reset SER & DES"
            write_reg(fd, 0x1, 0x1);
            (void) usleep(1000*1000);
        }

        if (Enable_EOM_OFFSET == 1)
        {
            EOM_OFFSET(fd, EOM_OFFSET_0, 0);
            EOM_OFFSET(fd, EOM_OFFSET_1, 1);
        }

        if (Enable_FIXED_CTLE == 1)
        {
            force_fixed_ctle_setting(fd, Fixed_EQ_Val_0, Fixed_EQ_Val_1, 1);
        }
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_convert_deserializer_fpd3_to_fpd4(int32 fd)
{
    uint8 Value, Value0, Value1;

    CRITICAL_PRINT(MODULE_NAME, "SWITCHING Main-Link RX from FPD3 to FPD4");

    write_reg(fd, 0x01, 0x01);

    (void) usleep(50 * 1000);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME,"I2C Address Before Switch: 0x%02x", Value);

    //read_reg(fd, 0x53, &Value0);
    read_reg(fd, 0x53, &Value0);
    //usleep(500 * 1000);
    read_reg(fd, 0x53, &Value0);
    write_reg(fd, 0x0E, 0x12);
    //read_reg(fd, 0x53, &Value1);
    read_reg(fd, 0x53, &Value1);
    //(void) usleep(500 * 1000);
    read_reg(fd, 0x53, &Value1);
    CRITICAL_PRINT(MODULE_NAME, "Port 0 Lock Status: 0x%02x, Port1 Lock Status: 0x%02x", Value0, Value1);

    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x5F, &Value);
    CRITICAL_PRINT(MODULE_NAME, "984 BC_TX CLK Source (0x02=AON, 0x00=PLLRX): 0x%02x", Value);
    write_reg(fd, 0x0E, 0x03);
    write_reg(fd, 0x5F, 0x00); //BC AON OFF
    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x5F, &Value);
    CRITICAL_PRINT(MODULE_NAME,"984 FORCE BC_TX CLK Source (0x00=PLLRX): 0x%02x", Value);

    // write_reg(fd, 0x31, 0x62) # Port 1 first
    // time.sleep(1)
    write_reg(fd, 0x31, 0x63); // Port 0 next
    CRITICAL_PRINT(MODULE_NAME," Switched from FPD3 to FPD4 on Main-Link RX");
    //debug:weller

    //	read_reg(fd, 0x00, &Value);
    //	CRITICAL_PRINT(MODULE_NAME," read test 984 0x%x",  Value);

    //write_reg(fd, 0x01, 0x01);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType disable_983_dp_line_reset(int32 fd)
{
    uint32 apb_data = 0;

    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 Value = 0;
    uint8 RevId = 0;
    // DP0 Lane 0
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 1
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 2
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 3
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x08);

    read_reg(fd, 0x30, &RevId);
    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");
    write_reg(fd, 0x2D, 0x03);
    write_reg(fd, 0x6A, 0x4A);
    // for 983 CS2.0
    if ((RevId & 0xF0) == 0x50)
    {
        write_reg(fd, 0x6E, 0x80);
    }

    //CRITICAL_PRINT(MODULE_NAME," Disable FPD3 FIFO pass through"
    write_reg(fd, 0x5B, 0x23);
    //CRITICAL_PRINT(MODULE_NAME," Change FPDTX FPD3_MODE_CTL"
    write_reg(fd, 0x59, 0x03);

    // CRITICAL_PRINT(MODULE_NAME," Force FPD4_TX DUAL MODE"
    write_reg(fd, 0x05, 0x28); // FPD_TX to DUAL

    CRITICAL_PRINT(MODULE_NAME," Switch mode to FPD4");
    write_reg(fd, 0x05, 0x28);
    write_reg(fd, 0x02, 0xD1);
    write_reg(fd, 0x2d, 0x01);

    //CRITICAL_PRINT(MODULE_NAME," Switch encoder from FPD3 to FPD4"
    write_reg(fd, 0x40, 9*4);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);
    Value = Main_link_speed * 1000 / 27 / 4;
    CRITICAL_PRINT(MODULE_NAME," Programming Serializer PLL, Value = %d", Value);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x80);

    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x4e);
    write_reg(fd, 0x42, 0xc7);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME," Software reset 983");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    (void) usleep(300*1000);

    CRITICAL_PRINT(MODULE_NAME," Software reset 984");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test1 984 0x%x",  Value);

    write_reg(fd, 0x01, 0x01);
    (void) usleep (300*1000);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test2 984 0x%x",  Value);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    link_set_serializer_vp(fd);
    write_reg(fd, 0x40, 0x2E);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);
    CRITICAL_PRINT(MODULE_NAME," Software reset 983 and 984 done");
    write_reg(fd, 0x2D, 0x01);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    disable_983_dp_line_reset(fd);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static uint32 XOR_MARGIN_OUTPUT(int fd, int wait_time, int port)
{
    uint8 REG0 = 0, REG1 = 0;
    uint8 Value_0_7, Value_15_8, Value_23_16, Value_29_24;
    uint32 Value_Port;
    // print""
    // CRITICAL_PRINT(MODULE_NAME," Running Margin Testing"

    if (port == 0)
    {
        REG0 = 0x00;
        REG1 = 0x54;
    }
    else if (port == 1)
    {
        REG0 = 0x80;
        REG1 = 0x58;
    }

    write_reg(fd, 0x40, 0x5C);
    write_reg(fd, 0x41, REG0); // Channel 0
    write_reg(fd, 0x42, 0x04); // Starts XOR Counter

    (void) usleep(wait_time * 1000);

    write_reg(fd, 0x40, REG1); // TOCCOA 0
    write_reg(fd, 0x41, 0xFB);
    read_reg(fd, 0x42, &Value_0_7); // Starts XOR Counter
    //CRITICAL_PRINT(MODULE_NAME," Value_0_7: ", Value_0_7
    write_reg(fd, 0x41, 0xFC);
    read_reg(fd, 0x42, &Value_15_8); // Starts XOR Counter
    //CRITICAL_PRINT(MODULE_NAME," Value_15_8: ", Value_15_8
    write_reg(fd, 0x41, 0xFD);
    read_reg(fd, 0x42, &Value_23_16); // Starts XOR Counter
    //CRITICAL_PRINT(MODULE_NAME," Value_23_16: ", Value_23_16
    write_reg(fd, 0x41, 0xFE);
    read_reg(fd, 0x42, &Value_29_24); // Starts XOR Counter
    //CRITICAL_PRINT(MODULE_NAME," Value_29_24: ", Value_29_24
    Value_Port = (Value_29_24 << 30) + (Value_23_16 << 16) + (Value_15_8 << 8) + Value_0_7;

    //if (port)
    //	CRITICAL_PRINT(MODULE_NAME," Port1 XOR: ", hex(Value_Port);
    //else
    //	CRITICAL_PRINT(MODULE_NAME," Port0 XOR: ", hex(Value_Port);

    write_reg(fd, 0x40, 0x5C);
    write_reg(fd, 0x41, REG0); // Channel 0
    write_reg(fd, 0x42, 0x00); // Starts XOR Counter

    return Value_Port;
}

static void CHECK_ALIGNMENT (int fd)
{
    uint8 DEF_Port0, DEF_Port1;
    //uint32 Value_0, Value_1;
    //CRITICAL_PRINT(MODULE_NAME," Checking Alignment Status"
    //Override Adapted Initial DFE Value
    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &DEF_Port0);
    DEF_Port0 = DEF_Port0 >> 2;
    //DFE_Port0 = board.ReadI2C(DEV_ADR, 0x42)>>2 # [15:8]
    write_reg(fd, 0x41, 0x8F);
    write_reg(fd, 0x42, DEF_Port0);
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x85);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    //Channel 1
    // Override Adapted Initial DFE Value
    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &DEF_Port1);
    DEF_Port0 = DEF_Port1 >> 2; // [15:8]
    write_reg(fd, 0x41, 0x8F);
    write_reg(fd, 0x42, DEF_Port1);
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0);
    write_reg(fd, 0x41, 0x85);
    write_reg(fd, 0x42, 0);
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    XOR_MARGIN_OUTPUT(fd, 0, 0);
    XOR_MARGIN_OUTPUT(fd, 0, 1);
    //CRITICAL_PRINT(MODULE_NAME," Port0 Alignment (0-Aligned): ", hex(Value_0), " Port1 XOR: ", hex(Value_1)
    //CRITICAL_PRINT(MODULE_NAME," Port0 TAP1: ", DFE_Port0, " Port1 TAP1: ", DFE_Port1

    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"
    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"        

    return;
}

static void DFE_TAP1_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, MSB_ON;

    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final, ((0x16>>2) & 0x3F), des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final - 64, ((0x16>>2) & 0x3F), des_num);
    }

    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final, ((0x16>>2) & 0x3F), des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final - 64, ((0x16>>2) & 0x3F), des_num);
    }

    return;
}

static void DFE_REF0_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, Value_LSB, MSB_ON;
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x00); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    //CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Value_MSB: ", hex(Value_MSB), " Value_LSB:", hex(Value_LSB)
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final - 128, des_num);
    }

    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x00); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    //CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Value_MSB: ", hex(Value_MSB), " Value_LSB:", hex(Value_LSB)
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final - 128, des_num);
    }

    return;
}

static void DFE_REF1_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, Value_LSB, MSB_ON;
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x20); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final - 128, des_num);
    }

    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x20); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final - 128, des_num);
    }

    return;
}

static void VIDEO_LINK_LAYER_SETUP (int fd, uint8 bits_per_color, uint8 DES_HOP)
{
    CRITICAL_PRINT(MODULE_NAME,"Enabling DES_%d Video to Stream_0",  DES_HOP);
    write_reg(fd, 0x0E, 0x03); //Set TX Port select
    write_reg(fd, 0xD0, 0x0C); //FPD_RX to DP Port 0 and Port 1 enable
    write_reg(fd, 0xD1, 0x00); //Every stream forwarded on DC
    write_reg(fd, 0xD6, 0x08); //Send Stream ID0 to DP Port 1 and and Send Stream ID1 Port 0
    write_reg(fd, 0xD7, 0x00);
    write_reg(fd, 0x0E, 0x01); //Set TX Port select

    return;
}

static int32 check_mesaure_video(struct video_timing *timing)
{
    if ((timing->vtotal > (TVW -10)) && (timing->vtotal < (TVW + 10)) &&
            (timing->htotal > (THW -10)) && (timing->htotal < (THW + 10)) &&
            (timing->hres == AHW) && (timing->vres == AVW))
    {
        return 1;
    }

    return 0;
}

static uint32 measure_video (int fd, int port, struct video_timing *timing)
{
    uint8 offset;
    uint8 dtg_status;
    uint32 htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;
    uint8 read_val;

    if (port == 0)
    {
        offset = 0;
    }
    else
    {
        offset = 0x30;
    }

    //DTG Status
    write_reg(fd, 0x40, 15*4);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x31); //Display 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x03);

    read_reg(fd, 0x42, &dtg_status);
    CRITICAL_PRINT(MODULE_NAME," DTG_STATUS DISP_0: 0x%02x",  dtg_status);

    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x32); //Display 1
    write_reg(fd, 0x41, 0x03);
    read_reg(fd, 0x42, &dtg_status);
    CRITICAL_PRINT(MODULE_NAME," DTG_STATUS DISP_1: 0x%02x",  dtg_status);
    CRITICAL_PRINT(MODULE_NAME," {early_de, vid_de_dtg, vid_hsync_dtg, vid_vsync_dtg, meas_done, 1'b0, rx_hsync, rx_vsync}");
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00); // Zero-Out the MUX
    do {
        write_reg(fd, 0x40, 81);

        write_reg(fd, 0x41, 0x40 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = read_val * 256;

        write_reg(fd, 0x41, 0x41 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = htotal + read_val;

        write_reg(fd, 0x41, 0x42 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = read_val * 256;
        write_reg(fd, 0x41, 0x43 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = vtotal + read_val;

        write_reg(fd, 0x41, 0x44 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = read_val * 256;
        write_reg(fd, 0x41, 0x45 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = hres + read_val;

        write_reg(fd, 0x41, 0x46 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = read_val * 256;
        write_reg(fd, 0x41, 0x47 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = vres + read_val;

        write_reg(fd, 0x41, 0x48 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = read_val * 256;
        write_reg(fd, 0x41, 0x49 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = hstart + read_val;

        write_reg(fd, 0x41, 0x4a + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = read_val * 256;
        write_reg(fd, 0x41, 0x4b + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = vstart + read_val;

        write_reg(fd, 0x41, 0x4c + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4d + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = hswidth + read_val;

        write_reg(fd, 0x41, 0x4e + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4f + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = vswidth + read_val;
        CRITICAL_PRINT(MODULE_NAME," Port %d Measured Video Data:",  port);
        CRITICAL_PRINT(MODULE_NAME," Port %d: htotal = %d",  port, htotal);
        CRITICAL_PRINT(MODULE_NAME," Port %d: vtotal = %d",  port, vtotal);
        CRITICAL_PRINT(MODULE_NAME," Port %d: hres = %d",  port, hres);
        CRITICAL_PRINT(MODULE_NAME," Port %d: vres = %d",  port, vres);
        CRITICAL_PRINT(MODULE_NAME," Port %d: hstart = %d",  port, hstart);
        CRITICAL_PRINT(MODULE_NAME," Port %d: vstart = %d",  port, vstart);
        CRITICAL_PRINT(MODULE_NAME," Port %d: hswidth = %d",  port, hswidth);
        CRITICAL_PRINT(MODULE_NAME," Port %d: vswidth = %d",  port, vswidth);

        //(void) usleep(200*1000);
        if ((vtotal < (TVW -10)) || (vtotal > (TVW + 10)) || (htotal < (THW -10))|| (htotal > (THW + 10))|| (hres != AHW) || (vres != AVW))
        {
            //reset_984_for_corruption(fd, Port);
        }
        else
        {
            break;
        }
    } while (0);

    if (timing)
    {
        timing->htotal = htotal;
        timing->vtotal = vtotal;
        timing->hres = hres;
        timing->vres = vres;
        timing->hstart = hstart;
        timing->vstart = vstart;
        timing->hswidth = hswidth;
        timing->vswidth = vswidth;
    }

    return htotal;
}

static uint8 lower_byte_QCLK(uint32 in_data)
{
    uint8 out_data = (uint8)(in_data & 0xFF);
    return out_data;
}
static uint8 upper_byte_QCLK(uint32 in_data)
{
    uint8 out_data =  (uint8)((in_data & 0xFF0000)>>16);
    return out_data;
}
static uint8 middle_byte_QCLK(uint32 in_data)
{
    uint8 out_data =  (uint8)((in_data & 0xFF00)>>8);
    return out_data;
}
static uint8 lower_byte_DTG(uint16 in_data)
{
    uint8 out_data = (uint8)(in_data & 0xFF);
    return out_data;
}
static uint8 upper_byte_DTG(uint16 in_data)
{
    uint8 out_data = (uint8)((in_data & 0xFF00)>>8);
    return out_data;
}

#define APB_CTL   0x48
#define APB_ADR0  0x49
#define APB_ADR1  0x4A
#define APB_DATA0 0x4B
#define APB_DATA1 0x4C
#define APB_DATA2 0x4D
#define APB_DATA3 0x4E
//def apb_read_reg(addr16b, channel, Device_ID):
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    if (channel == 0) {
        wr_val = 0x03;
    } else if (channel == 1) {
        wr_val = 0x0B;
    } else {
        wr_val = 0x03;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}
//def apb_write_reg(addr16b, data32b, channel, Device_ID):
static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);

    if (channel == 0) {
        wr_val = 0x01;
    } else if (channel == 1) {
        wr_val = 0x09;
    } else {
        wr_val = 0x01;
    }
    write_reg(fd, APB_CTL, wr_val);

    return EXIT_SUCCESS;
}

//static uint32 apb_read_modifywrite(int32 fd, uint8 channel, uint16 offset, uint32 mask, uint32 write_data)
//def apb_read_modifywrite(addr16b, mask, write_data, channel, Device_ID):
static uint32 apb_read_modifywrite(uint16 offset, uint32 mask, uint32 write_data, uint8 channel,int32 fd)
{
    uint32 read_data;
    uint32 temp_wr_data;

    read_data = apb_read_reg(fd, channel, offset);
    temp_wr_data = (read_data & (~mask)) | (write_data & mask);
    apb_write_reg(fd, channel, offset, temp_wr_data);

    return EXIT_SUCCESS;
}

static void DES_RESET_CONTROL (int fd)
{
    if (SOFT_RESET == 1)
    {
        CRITICAL_PRINT(MODULE_NAME," Data Errors - Issuing Soft Reset");
        write_reg(fd, 0x01, 0x01);
        (void) usleep(100 * 1000);
    }

    return;
}

static uint16 video_crc_check (int fd, uint8 CRC_WAIT)
{
    uint8 Line_MSB, Line_LSB, CRC_BYTE_LSB, Value;
    uint16 Line, CRC_BYTE_Init, Errors;

    write_reg(fd, 0x40, 0x48); // RX Link Layer
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x00); // Reg_Update_En; CLEAR ONLY
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x0F); // CLEAR ERROR COUTNER ENABLE
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x40); // Reg_Update_En; CLEAR ONLY
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x00); // BACK TO 0

    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x00); // CLEAR ERROR COUTNER DISABLE
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x4f); // CAPTURE

    write_reg(fd, 0x41, 0x39);
    read_reg(fd, 0x42, &Line_LSB);
    write_reg(fd, 0x41, 0x3A);
    read_reg(fd, 0x42, &Line_MSB);
    Line = (Line_MSB << 8) + Line_LSB;
    if (Line != 0)
    {
        Value = 0;
        write_reg(fd, 0x41, 0x34);
        read_reg(fd, 0x42, &CRC_BYTE_LSB);
        write_reg(fd, 0x41, 0x35);
        read_reg(fd, 0x42, &Value);
        CRC_BYTE_Init = (Value << 8) + CRC_BYTE_LSB; // Store initial errors
        sleep (CRC_WAIT);

        //CRITICAL_PRINT(MODULE_NAME," Video Error Checking"
        //CRITICAL_PRINT(MODULE_NAME," VIDEO (STREAM 0) Status:"
        write_reg(fd, 0x40, 0x48); // RX Link Layer
        write_reg(fd, 0x41, 0x2A);
        write_reg(fd, 0x42, 0xF);  // CLEAR ERROR COUTNER ENABLE
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x40); // Reg_Update_En; CLEAR ONLY
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x00); // BACK TO 0
        write_reg(fd, 0x41, 0x2A);
        write_reg(fd, 0x42, 0x00); // CLEAR ERROR COUTNER DISABLE
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x4f); // CAPTURE
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0xf);  // REG_UPDATE_EN BACK TO 0
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x4f); // CAPTURE; ONE MORE TIME

        // write_reg(fd, 0x40, 0x48) # RX Link Layer
        // write_reg(fd, 0x41, 0x29)
        // write_reg(fd, 0x42, 0x3F) # [6]:Reg_Update_En; [5:0]: reg_cnt_capture

        write_reg(fd, 0x41, 0x34);
        read_reg(fd, 0x42, &CRC_BYTE_LSB);
        write_reg(fd, 0x41, 0x35);
        read_reg(fd, 0x42, &Value);
        Value = ((Value << 8) + CRC_BYTE_LSB);
        Errors = Value - CRC_BYTE_Init;

        CRITICAL_PRINT(MODULE_NAME,"video_crc_check %d", Errors);
        return Errors;
    }
    else
    {
        Errors = 0xFFFF;
        return Errors;
    }
}



static uint16 DP_VIDEO_SETUP (int fd, uint8 Force_DP_Rate, uint16 DP_FORCE_RATE, uint8 DP0_ON, uint8 DP1_ON, uint8 DES_HOP, float LINK_SPEED)
{
    uint8 dp_force_rate = 0xC0;
    uint32 video_clk_freq;
    uint16 DP_Rate, dp_tx_rate;
    // Force_DP_Rate = 0 or 1
    // DP_FORCE_RATE = One of the below frequencies
    // DES_HOP = Which DES, 1:DES_1, 2:DES_2, 3:DES_3, 4: DES_4
    // LINK_SPEED = 10.8, 13.5, 6.75
    if (Force_DP_Rate == 1)
    {
        CRITICAL_PRINT(MODULE_NAME," Forcing DP Fixed Rate of On DES: %d Link-Rate: %d", DES_HOP, DP_FORCE_RATE);
        //Override link rate
        //Link rate Addr data
        //2.7 Gbps 0x81 8'b0110_0000
        //5.4 Gbps 0x81 8'b1100_0000
        //8.1 Gbps 0x81 8'b1110_0000
        //1.62 Gbps 0x81 8'b0000_0000
        //2.16 Gbps 0x81 8'b0010_0000
        //2.43 Gbps 0x81 8'b0100_0000
        //3.24 Gbps 0x81 8'b1000_0000
        //4.32 Gbps 0x81 8'b1010_0000
        if (DP_FORCE_RATE == 1620)
            dp_force_rate = 0x00;
        else if (DP_FORCE_RATE == 2160)
            dp_force_rate = 0x20;
        else if (DP_FORCE_RATE == 2430)
            dp_force_rate = 0x40;
        else if (DP_FORCE_RATE == 2700)
            dp_force_rate = 0x60;
        else if (DP_FORCE_RATE == 3240)
            dp_force_rate = 0x80;
        else if (DP_FORCE_RATE == 4320)
            dp_force_rate = 0xA0;
        else if (DP_FORCE_RATE == 5400)
            dp_force_rate = 0xC0;
        else if (DP_FORCE_RATE == 8100)
            dp_force_rate = 0xE0;

        //Override to Rate
        write_reg(fd, 0x40, 0x2C);
        write_reg(fd, 0x41, 0x81);
        write_reg(fd, 0x42, dp_force_rate);
        // Force Rate
        write_reg(fd, 0x41, 0x82);
        write_reg(fd, 0x42, 0x02);
    }
    if (DP0_ON == 1 && DP1_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," DP_PORT 0 SELECTED ONLY on DES_%d", DES_HOP);
        // Select DP Port 1
        write_reg(fd, 0x0E, 0x12);
        // Disable DP port 1
        write_reg(fd, 0x46, 0x00);
        write_reg(fd, 0x0E, 0x01);

        CRITICAL_PRINT(MODULE_NAME," Port 0: Apply DTG Reset on DES_%d", DES_HOP);
        write_reg(fd, 0x40, 80);
        write_reg(fd, 0x41, 0x32+0x00);
        write_reg(fd, 0x42, 0x02);

        CRITICAL_PRINT(MODULE_NAME," DP-TX-PLL RESET Applied/Required on DES_%d", DES_HOP);
        write_reg(fd, 0x01, 0x40);
        //sleep(1); //wait for remote programming
    }
    else if( DP0_ON == 0 && DP1_ON == 1)
    {
        CRITICAL_PRINT(MODULE_NAME," DP_PORT 1 SELECTED ONLY on DES_%d", DES_HOP);
        // Select DP Port 0
        write_reg(fd, 0x0E, 0x01);
        // Disable DP Port 0
        write_reg(fd, 0x46, 0x00);

        CRITICAL_PRINT(MODULE_NAME," Port 1: Apply DTG Reset on DES_%d", DES_HOP);
        write_reg(fd, 0x40, 0x50);
        write_reg(fd, 0x41, 0x32 + 0x30);
        write_reg(fd, 0x42, 0x02);

        CRITICAL_PRINT(MODULE_NAME," Daisy-DES DP-TX-PLL RESET Applied on DES_%d", DES_HOP);
        write_reg(fd, 0x01, 0x40);
        //sleep(1); //wait for remote programming
    }
    else if (DP0_ON == 0 && DP1_ON == 0)
    {
        write_reg(fd, 0x0E, 0x12);
        write_reg(fd, 0x46, 0x00);
        write_reg(fd, 0x0E, 0x01);
        write_reg(fd, 0x46, 0x00);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port 0: Apply DTG Reset on DES_%d", DES_HOP);
        write_reg(fd, 0x40, 0x50);
        write_reg(fd, 0x41, 0x32 + 0x00);
        write_reg(fd, 0x42, 0x02);
        CRITICAL_PRINT(MODULE_NAME," Port 1: Apply DTG Reset on DES_%d", DES_HOP);
        write_reg(fd, 0x40, 0x50);
        write_reg(fd, 0x41, 0x32 + 0x30);
        write_reg(fd, 0x42, 0x02);
    }


    CRITICAL_PRINT(MODULE_NAME," VIDEO PARAMETERS On DES_%d: SET:", DES_HOP);
    CRITICAL_PRINT(MODULE_NAME," FPD-Link Rate = %.2f GHz", LINK_SPEED);
    CRITICAL_PRINT(MODULE_NAME," PCLK = %.3f MHz", PCLK_FREQ);
    CRITICAL_PRINT(MODULE_NAME," THW = %d", THW);
    CRITICAL_PRINT(MODULE_NAME," TVW = %d", TVW);
    CRITICAL_PRINT(MODULE_NAME," AHW = %d", AHW);
    CRITICAL_PRINT(MODULE_NAME," AVW = %d", AVW);
    CRITICAL_PRINT(MODULE_NAME," HBP = %d", HBP);
    CRITICAL_PRINT(MODULE_NAME," VBP = %d", VBP);
    CRITICAL_PRINT(MODULE_NAME," HSW = %d", HSW);
    CRITICAL_PRINT(MODULE_NAME," VSW = %d", VSW);


    //VIDEO_LINK_LAYER_SETUP(DEV_ADDR, Bits_Per_Color)

    CRITICAL_PRINT(MODULE_NAME," DP-TX DES_%d VIDEO RESOLUTION: %s Configuration for DISPLAY" , DES_HOP, VIDEO_RESOLUTION);

    DP_Rate = 5400;
    //pixel clock of video format in MHz
    video_clk_freq = (int32)(PCLK_FREQ*1000);   // 148500 # in kHz
    dp_tx_rate = DP_FORCE_RATE; // example case
    dp_mvalue = (int32)(video_clk_freq);
    CRITICAL_PRINT(MODULE_NAME," dp_mvalue %d", dp_mvalue);
    dp_nvalue = dp_tx_rate * 400;

    return DP_Rate;
}
#if 0
static uint32 AEQ_960_VIDEO_ADJUST (int fd, uint8 Method)
{
    uint8 STORE_CTLE_0 = 0, STORE_CTLE_1 = 0;
    int32 Wait_Time = 0;
    uint8 STORE_Init_0 = 0;
    uint8 STORE_Init_1 = 0;
    uint8 CTLE_MAX_OFFSET = 4;
    uint8 Jump_Step = 1;
    uint32 Errors = 0;

    //Wait_Time = CRC_WAIT;
    Wait_Time = 1;

    write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0xFF);
    read_reg(fd, 0x42, &STORE_CTLE_0);
    write_reg(fd, 0x40, 0x58); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0xFF);
    read_reg(fd, 0x42, &STORE_CTLE_1);

    if (Method == 1)
    {
        while ((STORE_CTLE_0 <= STORE_CTLE_1) &&  (STORE_CTLE_0 <= (STORE_Init_0 + CTLE_MAX_OFFSET)))
        {
            STORE_CTLE_0 = STORE_CTLE_0 + Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23);
            write_reg(fd,0x42,STORE_CTLE_0); // SET AEQ_MIN
            sleep(Wait_Time);
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0) {
                return Errors;
                break;
            }
        }
        while ((STORE_CTLE_1 <= STORE_CTLE_0) && (STORE_CTLE_1 <= (STORE_Init_1 +CTLE_MAX_OFFSET)))
        {
            STORE_CTLE_1 = STORE_CTLE_1 + Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23+0x30);
            write_reg(fd,0x42,STORE_CTLE_1);
            sleep(Wait_Time);
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0)
                return Errors;
        }
        while ((STORE_CTLE_0 == STORE_CTLE_1) && (STORE_CTLE_1 <= (STORE_Init_1 +CTLE_MAX_OFFSET)) && (STORE_CTLE_0 <= (STORE_Init_0 +CTLE_MAX_OFFSET)))
        {
            STORE_CTLE_0 = STORE_CTLE_0 + Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23);
            write_reg(fd,0x42,STORE_CTLE_0);
            sleep(Wait_Time);
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0) {
                return Errors;
            } else {
                STORE_CTLE_1 = STORE_CTLE_1 + Jump_Step;
                CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
                write_reg(fd,0x40,0x38); //AEQ_SNS Page
                write_reg(fd,0x41,0x23+0x30);
                write_reg(fd,0x42,STORE_CTLE_1); // SET AEQ_MIN
                Errors = video_crc_check (fd, CRC_WAIT);
                if (Errors == 0) {
                    return Errors;
                }
            }
        }

    }
    else if (Method == 0)
    {
        while ((STORE_CTLE_1 >= (STORE_Init_1 -CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 >= (STORE_Init_0 -CTLE_MAX_OFFSET)))
        {
            STORE_CTLE_1 = STORE_CTLE_1 - Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23+0x30);
            write_reg(fd,0x42,STORE_CTLE_1); // SET AEQ_MIN
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0)
            {
                CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
                return Errors;
            } else {
                CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
            }
            STORE_CTLE_0 = STORE_CTLE_0 - Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23);
            write_reg(fd,0x42,STORE_CTLE_0); //SET AEQ_MIN
            sleep(Wait_Time);
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0)
            {
                CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
                return Errors;
            }
            else
            {
                CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
            }
        }
        write_reg(fd,0x40,0x38); //AEQ_SNS Page
        write_reg(fd,0x41,0x23);
        write_reg(fd,0x42,STORE_Init_0); // SET AEQ_MIN
        write_reg(fd,0x40,0x38); //AEQ_SNS Page
        write_reg(fd,0x41,0x23+0x30);
        write_reg(fd,0x42,STORE_Init_1); // SET AEQ_MIN
        while ((STORE_CTLE_1 <= (STORE_Init_1 +CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 <= (STORE_Init_0 +CTLE_MAX_OFFSET)))
        {
            STORE_CTLE_1 = STORE_CTLE_1 + Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23+0x30);
            write_reg(fd,0x42,STORE_CTLE_1); // SET AEQ_MIN
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0) {
                CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
                return Errors;
            }
            else {
                CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
            }
            STORE_CTLE_0 = STORE_CTLE_0 + Jump_Step;
            CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
            write_reg(fd,0x40,0x38); //AEQ_SNS Page
            write_reg(fd,0x41,0x23);
            write_reg(fd,0x42,STORE_CTLE_0); // SET AEQ_MIN
            sleep(Wait_Time);
            Errors = video_crc_check (fd, CRC_WAIT);
            if (Errors == 0) {
                CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
                return Errors;
            }
            else {
                CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
            }
        }
        write_reg(fd,0x40,0x38); //AEQ_SNS Page
        write_reg(fd,0x41,0x23);
        write_reg(fd,0x42,STORE_Init_0); // SET AEQ_MIN
        write_reg(fd,0x40,0x38); //AEQ_SNS Page
        write_reg(fd,0x41,0x23+0x30);
        write_reg(fd,0x42,STORE_Init_1); // SET AEQ_MIN

    }
    CRITICAL_PRINT(MODULE_NAME,  "No Solution Found");
    Errors = 0xDEADBEEF;
    return Errors;

}
#else
static uint32 AEQ_960_VIDEO_ADJUST (int fd, uint8 Method)
{
    uint8 STORE_CTLE_0 = 0, STORE_CTLE_1 = 0;
    int32 Wait_Time = 0;
    uint8 STORE_Init_0 = 0;
    uint8 STORE_Init_1 = 0;
    uint8 CTLE_MAX_OFFSET = 4;
    uint8 Jump_Step = 1;
    uint32 Errors = 0;

    Wait_Time = CRC_WAIT;

    write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0xFF);
    read_reg(fd, 0x42, &STORE_CTLE_0);
    write_reg(fd, 0x40, 0x58); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0xFF);
    read_reg(fd, 0x42, &STORE_CTLE_1);

    if (STORE_CTLE_0 < STORE_CTLE_1)
    {
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to EQ Port1 Value of %d", STORE_CTLE_1);
        STORE_Init_0 = STORE_CTLE_1;
        STORE_CTLE_0 = STORE_CTLE_1;
        CRITICAL_PRINT(MODULE_NAME, "CTLE0: %d, CTLE1: %d", STORE_CTLE_0, STORE_CTLE_1);
        force_fixed_ctle_setting(fd, STORE_CTLE_1, STORE_CTLE_1, 1);
    }
    else if (STORE_CTLE_0 > STORE_CTLE_1)
    {
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to EQ Port1 Value of %d", STORE_CTLE_0);
        STORE_Init_1 = STORE_CTLE_0;
        STORE_CTLE_1 = STORE_CTLE_0;
        CRITICAL_PRINT(MODULE_NAME, "CTLE0: %d, CTLE1: %d", STORE_CTLE_0, STORE_CTLE_1);
        force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_0, 1);

    }
    Errors = video_crc_check (fd, CRC_WAIT);
    CRITICAL_PRINT(MODULE_NAME, "*****DES VIDEO CRC Errors: %d", Errors);
    if (Errors == 0)
    {
        return Errors;
    }
    else
    {

    }
    while ((STORE_CTLE_1 >= (STORE_Init_1 -CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 >= (STORE_Init_0 -CTLE_MAX_OFFSET)))
    {
        STORE_CTLE_1 = STORE_CTLE_1 - Jump_Step;
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
        force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
        Errors = video_crc_check (fd, CRC_WAIT);
        if (Errors == 0)
        {
            CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
        }
        STORE_CTLE_0 = STORE_CTLE_0 - Jump_Step;
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
        force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
        sleep(Wait_Time);
        Errors = video_crc_check (fd, CRC_WAIT);
        if (Errors == 0)
        {
            CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
        }
    }
    force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
    Errors = video_crc_check (fd, CRC_WAIT);
    if (Errors == 0)
    {
        CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
        return Errors;
    } else {
        CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
    }
    while ((STORE_CTLE_1 <= (STORE_Init_1 + CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 <= (STORE_Init_0 + CTLE_MAX_OFFSET)))
    {
        STORE_CTLE_1 = STORE_CTLE_1 + Jump_Step;
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port1 to :0x%02x", STORE_CTLE_1);
        force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
        Errors = video_crc_check (fd, CRC_WAIT);
        if (Errors == 0)
        {
            CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
        }

        STORE_CTLE_0 = STORE_CTLE_0 + Jump_Step;
        CRITICAL_PRINT(MODULE_NAME, "Setting EQ Port0 to :0x%02x", STORE_CTLE_0);
        force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
        sleep(Wait_Time);
        Errors = video_crc_check (fd, CRC_WAIT);
        if (Errors == 0)
        {
            CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
        }

    }
    force_fixed_ctle_setting(fd, STORE_CTLE_0, STORE_CTLE_1, 1);
    Errors = video_crc_check (fd, CRC_WAIT);
    if (Errors == 0)
    {
        CRITICAL_PRINT(MODULE_NAME,  "*****DES VIDEO CRC Errors: %d", Errors);
        return Errors;
    } else {
        CRITICAL_PRINT(MODULE_NAME,  "VIDEO CRC ERRORS: %d", Errors);
    }


    CRITICAL_PRINT(MODULE_NAME,  "No Solution Found");
    Errors = 0xDEADBEEF;
    return Errors;
}
#endif

#define CHECK_I2C_RETURN(ret) \
    do { \
        if(ret < 0) \
        CRITICAL_PRINT(MODULE_NAME, ">>%d", __LINE__); \
    } while (0)

static int32 VIDEO_CRC_CHECK_LOOP (int fd, uint8 Enable_CRC_CHECK, uint8 DISPLAY_Port0_En, uint8 DISPLAY_Port1_En, uint8 DES)
{
    int32 i = 0;
    uint8 Line_LSB, Line_MSB, Val, LOCK_0, DECODE_ERR_0, LOCK_1, DECODE_ERR_1;
    uint8 AEQ_0, AEQ_1;
    uint8 Value;
    uint16 Line, Errors, New_Errors;
    int32 ret;

    if (Enable_CRC_CHECK == 1)
    {
        for (i = 0; i < Loop_RESET; i++)
        {
            write_reg(fd, 0x40, 0x48); // RX Link Layer
            write_reg(fd, 0x41, 0x39);
            ret=read_reg(fd, 0x42, &Line_LSB);
            CHECK_I2C_RETURN(ret);
            write_reg(fd, 0x41, 0x3A) ;
            ret=read_reg(fd, 0x42, &Line_MSB);
            Line = (Line_MSB << 8) + Line_LSB;

            write_reg(fd, 0x0E, 0x01);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            (void) usleep(100*1000);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            sleep(1);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            //CRITICAL_PRINT(MODULE_NAME," Lock Status: ", hex(Val)
            LOCK_0 = Val & 0x01;
            DECODE_ERR_0 = (Val >> 7) & 0x1;

            write_reg(fd, 0x0E, 0x12);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            (void) usleep(100 * 1000);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            sleep(1);
            ret=read_reg(fd, 0x53, &Val);
            CHECK_I2C_RETURN(ret);
            //CRITICAL_PRINT(MODULE_NAME," Lock Status: ", hex(Val)
            LOCK_1 = Val & 0x01;
            DECODE_ERR_1 = (Val >> 7) & 0x1;

            write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
            write_reg(fd, 0x41, 0xFF);
            ret=read_reg(fd, 0x53, &AEQ_0);
            CHECK_I2C_RETURN(ret);
            write_reg(fd, 0x40, 0x58); // SELECT TOCCOA1 PAGE
            write_reg(fd, 0x41, 0xFF);
            ret=read_reg(fd, 0x53, &AEQ_1);
            CHECK_I2C_RETURN(ret);


            if ((Line > 0) && (LOCK_0 != 0) && (LOCK_1 != 0) && (DECODE_ERR_0 != 1) && (DECODE_ERR_1 != 1))
            {
                CRITICAL_PRINT(MODULE_NAME," Valid Video Line %d Detected on DES ", Line, DES);
                CRITICAL_PRINT(MODULE_NAME," Line: %d Lock_0: 0x%02x Lock_1: 0x%02x DECODE_ERR_0: 0x%02x DECODE_ERR_1: 0x%02x EQ_0: 0x%02x EQ_1: 0x%02x", 
                         Line, LOCK_0, LOCK_1, DECODE_ERR_0, DECODE_ERR_1, AEQ_0 , AEQ_1);
                Errors = video_crc_check(fd, CRC_WAIT);

                CRITICAL_PRINT(MODULE_NAME," *****DES %d VIDEO CRC Errors: %d", DES, Errors);
                if (Errors == 0)
                {
                    write_reg(fd, 0x0E, 0x01);
                    read_reg(fd, 0x53, &Value);

                    if (Value != 0)
                    {
                        return 1;
                    }
                    else
                    {
                        CRITICAL_PRINT(MODULE_NAME," LOST I2C Transaction on DES %d", DES);
                        return 0;
                    }
                }
                else
                {
                    DES_RESET_CONTROL (fd);
                    New_Errors = AEQ_960_VIDEO_ADJUST (fd, 0);
                    sleep(1);
                    VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, DES);
                    if ((i == (Loop_RESET-1)) && (New_Errors != 0))
                    {
                        return 0;
                    }
                    else if (New_Errors == 0)
                    {
                        return 1;
                    }
                }
            }
            else if ((Line <=0) || (DECODE_ERR_0 ==1) || (DECODE_ERR_1 ==1) )
            {
                CRITICAL_PRINT(MODULE_NAME," #######No Valid Video or Decode Errors on DES %d", DES);
                CRITICAL_PRINT(MODULE_NAME," Line: %d Lock_0: 0x%02x Lock_1: 0x%02x DECODE_ERR_0: 0x%02x DECODE_ERR_1: 0x%02x EQ_0: 0x%02x EQ_1: 0x%02x",
                         Line, LOCK_0, LOCK_1, DECODE_ERR_0, DECODE_ERR_1, AEQ_0 , AEQ_1);
                DES_RESET_CONTROL (fd);
                VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, DES);
                ret = video_crc_check (fd, CRC_WAIT);
                return 0;
            }
        }

    }
    else
    {
        return 1;
    }

    return 0;
}

static void DTG_RESET_TOGGLE(int fd)
{
    CRITICAL_PRINT(MODULE_NAME," DTG RESET TOGGLE APPLIED");
    /*
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x06);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x06);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x04);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x04);
    */

    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02);
    (void)usleep(100*1000);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x02);
    (void)usleep(100*1000);
    write_reg(fd, 0x42, 0x00);
    return;
}

static void DP_DISPLY_PROGRAM (uint8 channel, int fd)
{
    uint8 page, offset0, offset1;
    uint32 mvid;
    uint32 reg_value, vsync_wr, hsync_wr, wr_data;
    uint32 bpc = 0x00000020;
    uint8 lane_count = 4;
    uint8 Active_Lanes = 0;

    if (channel == 0)
    {
        page = 0x01;
        offset0 = 0x00;
        offset1 = 0x00;
    }
    else
    {
        page = 0x12;
        offset0 = 0x30;
        offset1 = 0x01;
    }

    write_reg(fd, 0x0E, page);
    CRITICAL_PRINT(MODULE_NAME," SETTING DTG Parameters for DP_PORT %d Video: %s", channel, VIDEO_RESOLUTION);
    //enable clock divider
    CRITICAL_PRINT(MODULE_NAME," Port %d Setting QCLK", channel);
    write_reg(fd, 0xB1, 0x01);
    write_reg(fd, 0xB2, lower_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB3, middle_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB4, upper_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB5, lower_byte_QCLK(dp_nvalue));
    write_reg(fd, 0xB6, middle_byte_QCLK(dp_nvalue));
    write_reg(fd, 0xB7, upper_byte_QCLK(dp_nvalue));

    write_reg(fd, 0x0E, 0x01);

    CRITICAL_PRINT(MODULE_NAME," Port %d: Setting DTG", channel);
    write_reg(fd, 0x40, 0x50);
    //Quad pixel mode
    write_reg(fd, 0x41, 0x20 + offset0);
    //write_reg(fd, 0x42, 0x81);
    write_reg(fd, 0x42, 0xA3);//weller
    wr_data = AHW | 0x8000;
    write_reg(fd, 0x41, 0x25 + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x26 + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));

    wr_data = HSTART | 0x8000;
    write_reg(fd, 0x41, 0x29 + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x2A + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));
    wr_data = HSW | 0x4000;
    write_reg(fd, 0x41, 0x2F + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x30 + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));

    // Determine Active Lanes
    // Select DP port SM
    write_reg(fd, 0x40, 0x3C); //Select DFT Page
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x09 + offset1);
    // Select DP master SM vector sel
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x05);
    write_reg(fd, 0x41, 0x03);
    read_reg(fd, 0x42, &Active_Lanes);
    CRITICAL_PRINT(MODULE_NAME," Port %d: Active_Lanes", channel, Active_Lanes & 0x07);
    if (Active_Lanes == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "NO ACTIVE LANES DETECTED for PORT %d",channel);
        CRITICAL_PRINT(MODULE_NAME, "Main-Link DP-TX-PLL RESET Applied");
    }

    CRITICAL_PRINT(MODULE_NAME," Port %d Setting the Pattern Programming to %s", channel, VIDEO_RESOLUTION);
    lane_count = 4; //Active_Lanes & 0x07
    //Choose bpc = 24 bit, bits 7:5 = 001
    if (Bits_Per_Color == 6)
        bpc = 0x00000000;
    else if (Bits_Per_Color == 10)
        bpc = 0x00000040;
    else if (Bits_Per_Color == 8)
        bpc = 0x00000020;

    CRITICAL_PRINT(MODULE_NAME,"################# Port %d Setting %d bpc", channel, Bits_Per_Color*3);
    apb_read_modifywrite(0x1A4, 0x000000E0, bpc, channel, fd);
    //Quad pixel
    apb_read_modifywrite(0x1B8, 0x00000007, 0x00000004, channel, fd);
    mvid = (uint32)(vid_freq * 10.0 / DP_Rate * nvid);
    //print 'written ' + str(mvid) + ' Hex = '  + hex(mvid)
    CRITICAL_PRINT(MODULE_NAME,"mvid:0x%x, nvid:0x%x",mvid, nvid);
    apb_write_reg(fd, channel, 0x1AC, mvid);
    apb_write_reg(fd, channel, 0x1B4, nvid);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1AC:0x%08x, 0x1B4:0x%08x",
                    apb_read_reg(fd, channel, 0x1AC), apb_read_reg(fd, channel, 0x1B4));
    //print 'Readback ' + str(readback) + ' hex = ' + hex(readback)

    apb_write_reg(fd, channel, 0x1C8, 0x00);
    //###########################################################################
    apb_write_reg(fd, channel, 0x1B0, 0x2c0040); //FIFO Depth to 56
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1B0:0x%08x",apb_read_reg(fd, channel, 0x1B0));
    apb_write_reg(fd, channel, 0x0C8, 0x4004);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x0C8:0x%08x",apb_read_reg(fd, channel, 0x0C8));
    //generate_tu(bits_per_pixel=30, number_of_lanes=4.0, speed_of_lanes=5.4, pixel_clock=395.367, tu = 64, fifo_depth = 4, channel = int(channel), addr =DEVICE_ADDR)
    //###########################################################################

    // apb_write_reg(0x1C8, 0x01, int(channel), DEVICE_ADDR)
    // ############################################################################
    // apb_write_reg(0x1B0, 0x28, int(channel), DEVICE_ADDR) #FIFO Depth to 56
    // apb_write_reg(0x0C8, 0x201d, int(channel), DEVICE_ADDR)
    // #generate_tu(bits_per_pixel=30, number_of_lanes=4.0, speed_of_lanes=5.4, pixel_clock=395.367, tu = 64, fifo_depth = 4, channel = int(channel), addr =DEVICE_ADDR)
    // ############################################################################



    reg_value = ((my_pixels * Bits_Per_Color * 3) + 7) / 8;
    if (lane_count != 0)
        reg_value = (reg_value + lane_count - 1) / lane_count;
    //CRITICAL_PRINT(MODULE_NAME," reg_value", reg_value
    CRITICAL_PRINT(MODULE_NAME,"reg_value:0x%x",reg_value);
    apb_write_reg(fd, channel, 0x1BC, reg_value);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1BC:0x%08x",apb_read_reg(fd, channel, 0x1BC));
    apb_write_reg(fd, channel, 0x1C0, 0x00);
    vsync_wr = ((~vsync_pol) & 0x01) << 1;
    hsync_wr = ((~hsync_pol) & 0x01);
    wr_data = 0x0000000c | vsync_wr | hsync_wr;
    CRITICAL_PRINT(MODULE_NAME,"wr_data:0x%x",wr_data);
    //print wr_data
    apb_write_reg(fd, channel, 0x1C4, wr_data);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1C4:0x%08x",apb_read_reg(fd, channel, 0x1C4));
    // Main stream Enable
    // apb_write_reg(0x084, 0x01, int(channel), DEVICE_ADDR)

    CRITICAL_PRINT(MODULE_NAME," Port %d: Remove DTG Reset", channel);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32+offset0);
    write_reg(fd, 0x42, 0x00);

    return;
}

static uint32 ENABLE_DISPLAY (int fd, uint8 DISPLAY_Port0_En, uint8 DISPLAY_Port1_En, uint8 DES, uint16 DEVICE_TYPE, uint8 DTG_TOGGLE,
         struct video_timing *timing0, struct video_timing *timing1)
{
    uint32 htotal0 = 0, htotal1 = 0;

    if (DISPLAY_Port0_En == 1)
    {
        DP_DISPLY_PROGRAM (0,fd);
        (void) usleep(100 * 1000);
        if (DTG_TOGGLE == 1)
            DTG_RESET_TOGGLE(fd);
        (void) usleep(200 * 1000);
        htotal0 = measure_video (fd, 0, timing0);
    }

    if (DISPLAY_Port1_En == 1)
    {
        DP_DISPLY_PROGRAM (1,fd);
        (void) usleep(100 * 1000);
        if (DTG_TOGGLE == 1)
            DTG_RESET_TOGGLE(fd);
        (void) usleep(300 * 1000);
        htotal1 = measure_video (fd, 1, timing1);
    }


    if ((htotal0 < (THW-10)) || (htotal0 > (THW+10)))
        return htotal0;
    else if ((htotal1 < (THW-10)) || (htotal1 > (THW+10)))
        return htotal1;
    else
        return htotal0;
}

void patch_983_apb_a18(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_a18");
    apb_write_reg(fd, 0, 0xa18, 0x5);
}

void patch_983_apb_a28(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_a28");
    apb_write_reg(fd, 0, 0xa28, 0x4123);
}

static BridgeChip_StatusType link_set_des_bypass_link_status(int32 fd)
{
    uint8 Value = 0;
    uint8 Value1 = 0;
    uint8 e_offset0, e_offset1, q_offset0, q_offset1;
    uint8 MSB_CDR, LSB_CDR;
    uint8 EQ_PORT_0, EQ_PORT_1;
    uint8 DFE_Port0, DFE_Port1;

    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test3 984 0x%x", Value);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test3 984 0x%x", Value);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test3 984 0x%x", Value);
    Value = 0;
    if (Bypass_Link_Status == 0)
    {
        // CRITICAL_PRINT(MODULE_NAME," "
        // CRITICAL_PRINT(MODULE_NAME," Main Link Status Registers:"
        write_reg(fd, 0x40, 0x38); // SELECT AEQ_SNS PAGE
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x1a); // [5]:aeq_sns_fsm_dbg_sel [4:0]:aeq_sns_dbg_sel[4:0]

        //write_reg(fd, 0x41, 0x15); // [7:0]: aeq_sns_dbg_bus[15:8]
        //read_reg(fd, 0x42, &eq0);
        //eq0 = eq0 >> 2;          // read and feedback to design for debug
        // CRITICAL_PRINT(MODULE_NAME," PORT0 EQ setting (AEQ_SNS Dbug_Reg)= " + str(eq0)

        write_reg(fd, 0x40, 0x38); // SELECT AEQ_SNS PAGE
        write_reg(fd, 0x41, 0x43);
        write_reg(fd, 0x42, 0x1a);
        //#write_reg(fd, 0x40, 0x39)
        //write_reg(fd, 0x41, 0x45);
        //read_reg(fd, 0x42, &eq1);
        //eq1 = eq1 >> 2;          // read and feedback to design for debug
        // CRITICAL_PRINT(MODULE_NAME," PORT1 EQ setting (AEQ_SNS Dbug_Reg) = " + str(eq1)

        // write_reg(fd, 0x40, 0x38);
        // write_reg(fd, 0x41, 0x2A);
        // read_reg(fd, 0x42, &Value);
        // CRITICAL_PRINT(MODULE_NAME," Port 0: AEQ Actual Start (DEC): ", Value & 0x3F
        // write_reg(fd, 0x41, 0x5A);
        // read_reg(fd, 0x42, &Value);
        // CRITICAL_PRINT(MODULE_NAME," Port 1: AEQ Actual Start(DEC): ", Value & 0x3F

        write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
        write_reg(fd, 0x41, 0xFF);
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 CTLE BOOST (DEC)(TOCCOA): ", board.ReadI2C(Device_RX, 0x42)
        write_reg(fd, 0x40, 0x58); // SELECT TOCCOA1 PAGE
        write_reg(fd, 0x41, 0xFF);
        //#CRITICAL_PRINT(MODULE_NAME," PORT1 CTLE BOOST (DEC) (TOCCOA): ", board.ReadI2C(Device_RX, 0x42)

        //#CRITICAL_PRINT(MODULE_NAME," "
        write_reg(fd, 0x40, 0x38);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
        write_reg(fd, 0x41, 0x14);
        read_reg(fd, 0x42, &Value);

        //#CRITICAL_PRINT(MODULE_NAME," PORT0: AEQ_SNS VGA: ", (Value & 0x0F)
        write_reg(fd, 0x41, 0x43);
        write_reg(fd, 0x42, 0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
        write_reg(fd, 0x41, 0x44);
        read_reg(fd, 0x42, &Value);
        //#CRITICAL_PRINT(MODULE_NAME," PORT1: AEQ_SNS VGA: ", (Value & 0x0F)

        write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
        write_reg(fd, 0x41, 0x51);
        write_reg(fd, 0x42, 0xA0); // Snapshot selects the VGA
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x08); // Capture the data
        write_reg(fd, 0x41, 0xF2);
        read_reg(fd, 0x42, &Value);
        //Value_Adaptive_VGA = Value & 0x0F;
        //Value_VGA_Sweep_END = (Value >> 4) & 0x0F;
        //#CRITICAL_PRINT(MODULE_NAME," PORT0: TOCC VGA Adaptive Gain: ", Value_Adaptive_VGA, " TOCC VGA Sweep Gain: ", Value_VGA_Sweep_END

        write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
        write_reg(fd, 0x41, 0x51);
        write_reg(fd, 0x42, 0xA0); // Snapshot selects the VGA
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x08); // Capture the data
        write_reg(fd, 0x41, 0xF2);

        Value = 0;
        read_reg(fd, 0x42, &Value);
        //Value_Adaptive_VGA = Value & 0x0F;
        //Value_VGA_Sweep_END = (Value >> 4) & 0x0F;
        //CRITICAL_PRINT(MODULE_NAME," PORT1: TOCC VGA Adaptive Gain: ", Value_Adaptive_VGA, " TOCC VGA Sweep Gain: ", Value_VGA_Sweep_END
        //CRITICAL_PRINT(MODULE_NAME," "

        write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
        write_reg(fd, 0x41, 0x2D);
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 Auto-Align Pass: ", (board.ReadI2C(Device_RX, 0x42) & 0x01)
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 Auto-Align Done: ",(board.ReadI2C(Device_RX, 0x42)>>1 & 0x01)
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 Auto-Align SM State: ",(board.ReadI2C(Device_RX, 0x42)>>2 & 0x07)
        write_reg(fd, 0x41, 0x4b);
        read_reg(fd, 0x42, &Value);
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 Auto-Align Status: L-SHIFT [5:3] (MAX=4):", (value & 0x38)>>3, "R-SHIFT [2:0] MAX=4:", value & 0x07
        write_reg(fd, 0x40, 0x58); //# SELECT TOCCOA1 PAGE
        write_reg(fd, 0x41, 0x2D);
        //#CRITICAL_PRINT(MODULE_NAME," PORT1 Auto-Align Pass: ", (board.ReadI2C(Device_RX, 0x42) & 0x01)
        //#CRITICAL_PRINT(MODULE_NAME," PORT1 Auto-Align Done: ",(board.ReadI2C(Device_RX, 0x42)>>1 & 0x01)
        //#CRITICAL_PRINT(MODULE_NAME," PORT0 Auto-Align SM State: ",(board.ReadI2C(Device_RX, 0x42)>>2 & 0x07)
        write_reg(fd, 0x41, 0x4b);
        read_reg(fd, 0x42, &Value);
        //#CRITICAL_PRINT(MODULE_NAME," PORT1 Auto-Align Status: L-SHIFT [5:3] (MAX=4):", (value & 0x38)>>3, "R-SHIFT [2:0] MAX=4:", value & 0x07

        write_reg(fd, 0x40, 0x5c); //# SELECT TOCCOA P0 & P1
        write_reg(fd, 0x41, 0x1c);
        read_reg(fd, 0x42, &e_offset0); //# Error Offset Value
        write_reg(fd, 0x40, 0x5c);
        write_reg(fd, 0x41, 0x1e);
        read_reg(fd, 0x42, &q_offset0); //# Q_Offset Value
        //#CRITICAL_PRINT(MODULE_NAME," PORT 0 Qoffset = " + hex(q_offset0) + " EOffset = " + hex(e_offset0)

        write_reg(fd, 0x40, 0x5c); // SELECT TOCCOA P0 & P1
        write_reg(fd, 0x41, 0x9c);
        read_reg(fd, 0x42, &e_offset1); //# Error Offset Value
        write_reg(fd, 0x40, 0x5c);
        write_reg(fd, 0x41, 0x9e);
        read_reg(fd, 0x42, &q_offset1); //# Q_Offset Value
        //#CRITICAL_PRINT(MODULE_NAME," PORT 1 Qoffset = " + hex(q_offset1) + " EOffset = " + hex(e_offset1)

        //#CRITICAL_PRINT(MODULE_NAME," "
        //# Channel 0 Check
        write_reg(fd, 0x0E, 0x1);
        //# CLEAR CRC Erros
        CRITICAL_PRINT(MODULE_NAME," Clearing CRC");
        CRITICAL_PRINT(MODULE_NAME," ##### Port 0 ######");
        write_reg(fd, 0x05, 0xE0);
        write_reg(fd, 0x05, 0xC0); // Clear CRC
        //# CLEAR FC CRC Erros FPD_RX

        //# Clear Flags by Reading
        read_reg(fd, 0x3C, &Value); //DCA_DET_ERR_CNTR_P0/P1
        read_reg(fd, 0x3D, &Value); //DCA_CRC_ERR_CNTR_P0/P1
        read_reg(fd, 0x3E, &Value); //DCA_8b10b_ERR_CNTR_P0/P1
        read_reg(fd, 0x3F, &Value); //ECC_ERR_CNTR_P0/P1

        read_reg(fd, 0x53, &Value);
        (void) usleep(100*1000);
        Value = 0;
        read_reg(fd, 0x53, &Value);
        CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x53): 0x%02x ", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
        Value = 0;
        read_reg(fd, 0x3B, &Value);
        CRITICAL_PRINT(MODULE_NAME," FPD Error Conters (REG 0x3B): 0x%02x", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

        read_reg(fd, 0x54, &Value);
        read_reg(fd, 0x09, &Value);
        CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x54): 0x%02x", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");
        read_reg(fd, 0x6A, &Value);
        read_reg(fd, 0x6B, &Value1);
        CRITICAL_PRINT(MODULE_NAME," FC CRC Error (MSB+LSB): 0x%02x",  (Value1 << 4) + Value);
        read_reg(fd, 0x09, &Value);
        CRITICAL_PRINT(MODULE_NAME," FC CRC Error FLAG: ", Value >> 6 & 0x01);

        // Channel 1 Check
        write_reg(fd, 0x0E, 0x12);
        // CLEAR BC CRC Erros on Daisy BC_RX
        CRITICAL_PRINT(MODULE_NAME," ##### Port 1 #####");
        write_reg(fd, 0x05, 0xE0);
        write_reg(fd, 0x05, 0xC0); // Clear CRC
        // CLEAR FC CRC Erros FPD_RX

        // Clear Flags by Reading
        //# Clear Flags by Reading
        read_reg(fd, 0x3C, &Value); //DCA_DET_ERR_CNTR_P0/P1
        read_reg(fd, 0x3D, &Value); //DCA_CRC_ERR_CNTR_P0/P1
        read_reg(fd, 0x3E, &Value); //DCA_8b10b_ERR_CNTR_P0/P1
        read_reg(fd, 0x3F, &Value); //ECC_ERR_CNTR_P0/P1

        read_reg(fd, 0x53, &Value);
        (void) usleep(100*1000);
        read_reg(fd, 0x53, &Value);
        CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x53): 0x%02x ", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
        Value=0;
        read_reg(fd, 0x3B, &Value);
        CRITICAL_PRINT(MODULE_NAME," FPD Error Conters (REG 0x3B): 0x%02x", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

        read_reg(fd, 0x54, &Value);
        read_reg(fd, 0x09, &Value1);
        CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x54): 0x%02x", Value);
        CRITICAL_PRINT(MODULE_NAME," REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");
        Value=0;
        read_reg(fd, 0x6A, &Value);
        read_reg(fd, 0x6B, &Value1);
        CRITICAL_PRINT(MODULE_NAME," FC CRC Error (MSB+LSB): 0x%02x",  (Value1 << 4) + Value);
        Value=0;
        read_reg(fd, 0x09, &Value);
        CRITICAL_PRINT(MODULE_NAME," FC CRC Error FLAG: ",  Value >> 6 & 0x01);

        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0x12); // Snapshot select
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x13); // Take the snapshot
        write_reg(fd, 0x42, 0x08);
        write_reg(fd, 0x41, 0xDF);
        read_reg(fd, 0x42, &MSB_CDR);
        write_reg(fd, 0x41, 0xE0);
        read_reg(fd, 0x42,&LSB_CDR);

        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x12); // Snapshot select
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x13); // Take the snapshot
        write_reg(fd, 0x42, 0x08);
        write_reg(fd, 0x41, 0xDF);
        read_reg(fd, 0x42, &MSB_CDR);
        write_reg(fd, 0x41, 0xE0);
        read_reg(fd, 0x42, &LSB_CDR);

        write_reg(fd, 0x40, 0x08);
        write_reg(fd, 0x41, 0x07);
        Value = 0;
        read_reg(fd, 0x42, &Value);
        CRITICAL_PRINT(MODULE_NAME," PLL_RX_LOCK: 0x%02x PLL_VCNTRL_HIGH= 0x%02x PLL_VCNTL_LOW: 0x%02x",  (Value & 0x01), (Value >> 4) & 0x01, (Value >> 3) & 0x01);
    }

    if (Enable_SHOW_ALL_COEFFICIENTS == 1)
    {
        uint8 ch0_I_DCD, ch1_I_DCD;
        uint8 ch0_Q_DCD, ch1_Q_DCD;
        uint8 ch0_EOM_DCD, ch1_EOM_DCD;
        uint8 ch0_Q_Offset, ch1_Q_Offset;
        uint8 ch0_EOM_Offset, ch1_EOM_Offset;

        CRITICAL_PRINT(MODULE_NAME,"--------%s-----------", __LINE__);
        //CRITICAL_PRINT(MODULE_NAME," PRINTING ALL COEFFICIENTS"
        // CTLE
        write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
        write_reg(fd, 0x41, 0xFF); //
        read_reg(fd, 0x42, &EQ_PORT_0);

        write_reg(fd, 0x40, 0x58); // SELECT TOCCOA1 PAGE
        write_reg(fd, 0x41, 0xFF);
        read_reg(fd, 0x42, &EQ_PORT_1);

        //CRITICAL_PRINT(MODULE_NAME," CTLE_P0=", EQ_PORT_0, " CTLE_P1: ", EQ_PORT_1)

        // TAP1
        write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
        write_reg(fd, 0x41, 0x51);
        write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x08); // Capture the data
        write_reg(fd, 0x41, 0xF1);
        read_reg(fd, 0x42, &DFE_Port0);
        DFE_Port0 = DFE_Port0>>2; // [15:8]
        write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
        write_reg(fd, 0x41, 0x51);
        write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x08); // Capture the data
        write_reg(fd, 0x41, 0xF1);
        read_reg(fd, 0x42, &DFE_Port1);
        DFE_Port1 = DFE_Port0>>2; // [15:8]
        //CRITICAL_PRINT(MODULE_NAME," TAP1_P0=", DFE_Port0, " TAP1_P1: ", DFE_Port1

        write_reg(fd, 0x40, 0x5C);
        write_reg(fd, 0x41, 0x6F);
        read_reg(fd, 0x42, &ch0_I_DCD);
        write_reg(fd, 0x41, 0x6F+0x80);
        read_reg(fd, 0x42, &ch1_I_DCD);
        //CRITICAL_PRINT(MODULE_NAME," I_DCD_P0=", hex(ch0_I_DCD), " I_DCD_P1: ", hex(ch1_I_DCD)

        write_reg(fd, 0x41, 0x72);
        read_reg(fd, 0x42, &ch0_Q_DCD);
        write_reg(fd, 0x41, 0x72+0x80);
        read_reg(fd, 0x42, &ch1_Q_DCD);
        //CRITICAL_PRINT(MODULE_NAME," Q_DCD_P0=", hex(ch0_Q_DCD), " Q_DCD_P1: ", hex(ch1_Q_DCD)

        write_reg(fd, 0x41, 0x75);
        read_reg(fd, 0x42, &ch0_EOM_DCD);
        write_reg(fd, 0x41, 0x75+0x80);
        read_reg(fd, 0x42, &ch1_EOM_DCD);
        //CRITICAL_PRINT(MODULE_NAME," EOM_DCD_P0=", hex(ch0_EOM_DCD), " EOM_DCD_P1: ", hex(ch1_EOM_DCD)

        write_reg(fd, 0x41, 0x1E);
        read_reg(fd, 0x42, &ch0_Q_Offset);
        write_reg(fd, 0x41, 0x1E + 0x80);
        read_reg(fd, 0x42, &ch1_Q_Offset);

        //CRITICAL_PRINT(MODULE_NAME," Q_Offset_P0=", hex(ch0_Q_Offset), " Q_Offset_P1: ", hex(ch1_Q_Offset)
        if (ch0_Q_Offset > 31 && ch0_Q_Offset <= 63)
            ch0_Q_Offset = ch0_Q_Offset -64;
        if (ch1_Q_Offset > 31 && ch1_Q_Offset <= 63)
            ch1_Q_Offset = ch1_Q_Offset -64;
        //CRITICAL_PRINT(MODULE_NAME," Q_Offset_P0 (+/-)=", ch0_Q_Offset, " Q_Offset_P1 (+/-)=", ch1_Q_Offset

        write_reg(fd, 0x41, 0x1C);
        read_reg(fd, 0x42, &ch0_EOM_Offset);
        write_reg(fd, 0x41, 0x1C+0x80);
        read_reg(fd, 0x42, &ch1_EOM_Offset);
        //CRITICAL_PRINT(MODULE_NAME," EOM_Offset_P0=", hex(ch0_EOM_Offset), " EOM_Offset_P1: ", hex(ch1_EOM_Offset)
        if (ch0_EOM_Offset > 31 && ch0_EOM_Offset <= 63)
            ch0_EOM_Offset = ch0_EOM_Offset -64;
        if (ch1_EOM_Offset > 31 && ch1_EOM_Offset <= 63)
            ch1_EOM_Offset = ch1_EOM_Offset -64;
        //CRITICAL_PRINT(MODULE_NAME," EOM_Offset_P0 (+/-)=", ch0_EOM_Offset, " EOM_Offset_P1 (+/-)=", ch1_EOM_Offset
    }

    if (Bypass_CHECK_ALIGNMNET == 0)
    {
        CHECK_ALIGNMENT(fd);
    }

    if (Bypass_DFE_Monitors == 0)
    {
        uint16 Value_MSB;
        uint8 read_val;
        DFE_TAP1_SNAPSHOT(fd, 1);
        DFE_REF0_SNAPSHOT(fd, 1);
        DFE_REF1_SNAPSHOT(fd, 1);

        write_reg(fd, 0x41, 0x12); // Snapshot select
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x13); // Take the snapshot
        write_reg(fd, 0x42, 0x08);
        write_reg(fd, 0x41, 0xDF);
        read_reg(fd, 0x42, &read_val);
        Value_MSB = read_val << 8;
        write_reg(fd, 0x41, 0xE0);
        read_reg(fd, 0x42, &read_val);
        CRITICAL_PRINT(MODULE_NAME," Port0: CDR_FQ (PPM): %d",  Value_MSB + read_val);

        // write_reg(fd, 0x41, 0x02) # ref_cntrl + DFE
        // write_reg(fd, 0x42, 0x82)

        write_reg(fd, 0x41, 0x12); // Snapshot select
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x13); // Take the snapshot
        write_reg(fd, 0x42, 0x08);
        write_reg(fd, 0x41, 0xDF);
        read_reg(fd, 0x42, &read_val);
        Value_MSB = read_val << 8;
        write_reg(fd, 0x41, 0xE0);
        read_reg(fd, 0x42, &read_val);
        CRITICAL_PRINT(MODULE_NAME," Port1: CDR_FQ (PPM): %d",  Value_MSB + read_val);
    }

    if (Bypass_Display_Panel == 0)
    {
        uint16 DP_Rate, dp_tx_rate;
        uint32 video_clk_freq;
        struct video_timing timing0, timing1;

        if (DES_1_Video_ON == 1)
        {
            CRITICAL_PRINT(MODULE_NAME,">>>>>Hold DTG In Reset");
            (void)usleep(200*1000);
            write_reg(fd, 0x40, 0x50);
            write_reg(fd, 0x41, 0x32);
            write_reg(fd, 0x42, 0x02);
            write_reg(fd, 0x41, 0x32 + 0x30);
            write_reg(fd, 0x42, 0x02);
            write_reg(fd, 0x0E, 0x01);
            read_reg(fd, 0x00, &Value);
            CRITICAL_PRINT(MODULE_NAME," DES_1 I2C Adress Aquired: 0x%02x",  Value);

            if (Value == 0)
            {
                write_reg(fd, 0x0E, 0x01);
                read_reg(fd, 0x00, &Value);
                CRITICAL_PRINT(MODULE_NAME," DES_1 I2C Adress Aquired: 0x%02x",  Value);
            }

            if (Value != 0)
            {
                DP_Rate = DP_VIDEO_SETUP (fd, Force_Rate_DP_DES_1, Force_Speed_DP_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, DES_1_link_speed);
                video_clk_freq = (uint32)(PCLK_FREQ*1000);   //  148500 # in kHz
                dp_tx_rate = DP_Rate; // example case
                dp_mvalue = (uint32)(video_clk_freq);
                dp_nvalue = dp_tx_rate * 400;
                int retryvideo=0;

                do {
                    Value = VIDEO_CRC_CHECK_LOOP (fd, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1);
                    if (Value == 1)
                    {
                        VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, 1); // Enable DC on Previous Device
                        ENABLE_DISPLAY (fd, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1, &timing0, &timing1); //(DEV_ADDR, DISPLAY_Port0_En, DISPLAY_Port1_En, DES, DEVICE_TYPE, DTG_TOGGLE)
                        if ((check_mesaure_video(&timing0) == 0) || (check_mesaure_video(&timing1) == 0))
                        {
                            CRITICAL_PRINT(MODULE_NAME," VIDEO NOT MEASURED CORRECTY! - Applying RESET");
                            write_reg(fd, 0x01, 0x01);
                            (void) usleep(500 * 1000);
                            VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, 1); // Enable DC on Previous Device
                            Value = VIDEO_CRC_CHECK_LOOP (fd, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1);
                            ENABLE_DISPLAY (fd, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1, &timing0, &timing1);
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        CRITICAL_PRINT(MODULE_NAME," Apply Reset to ALL Links and Re-do Stream Mapping");
                        write_reg(fd, 0x01, 0x01);
                        (void) usleep(500 * 1000);
                        VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, 1); // Enable DC on Previous Device
#if 1
                        Value = VIDEO_CRC_CHECK_LOOP (fd, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1);
                        ENABLE_DISPLAY (fd, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1, &timing0, &timing1);
                        if ((check_mesaure_video(&timing0) == 0) || (check_mesaure_video(&timing1) == 0))
                        {
                            CRITICAL_PRINT(MODULE_NAME," VIDEO NOT MEASURED CORRECTY! - Applying RESET");
                            write_reg(fd, 0x01, 0x01);
                            (void) usleep(500 * 1000);
                            VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color, 1); // Enable DC on Previous Device
                            Value = VIDEO_CRC_CHECK_LOOP (fd, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1);
                            ENABLE_DISPLAY (fd, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1, &timing0, &timing1);
                        }
#endif
                    }
                    retryvideo++;
                } while (retryvideo < 5);

                CRITICAL_PRINT(MODULE_NAME,"ENABLE_DISPLAY done");
                CRITICAL_PRINT(MODULE_NAME,"Turning Off FSM Test MUXES DES_1");
                write_reg(fd, 0x40, 0x3C); // Select DFT Page
                write_reg(fd, 0x41, 0x00);
                write_reg(fd, 0x42, 0x00);
                write_reg(fd, 0x41, 0x01);
                write_reg(fd, 0x42, 0x00);
                write_reg(fd, 0x41, 0x02);
                write_reg(fd, 0x42, 0x00);
                apb_write_reg(fd, 0, 0x084, 0x01);
                apb_write_reg(fd, 1, 0x084, 0x01);
                CRITICAL_PRINT(MODULE_NAME,"Turning Off FSM Test MUXES DES_1 done");
            }
        }
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_check_ser_vp_status(int32 fd)
{
    uint8  vp_status;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x45, &vp_status);

    if(((vp_status & 0x1) == 1)  &&  (((vp_status >> 1) & 0x01) == 1)) {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>vp  synced");
        return BRIDGECHIP_STATUS_SUCCESS;
    } else {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>>>vp not synced, do reset");
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd)
{
    uint32 lane01_status, lane23_status;
    static uint8  vp_status = 0, vp_status_tmp = 0, status_change = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    lane01_status = apb_read_reg(fd, 0, 0x43C);
    lane23_status = apb_read_reg(fd, 0, 0x440);
    read_reg(fd, 0x45, &vp_status);

    if (vp_status != vp_status_tmp) {
        CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
                vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);

        serdes_get_983_dp_rx_status(fd);
        vp_status_tmp = vp_status;

    }

    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377)) {
        status_change = 1;
        return BRIDGECHIP_STATUS_SUCCESS;
    } else {
        //only print when dp from ok to bad
        if (status_change == 1) {
            CRITICAL_PRINT(MODULE_NAME, "fail: | VP0:%d | VP1:%d | lane_status: 0x%x, 0x%x,",
                vp_status & 0x1, (vp_status >> 1) & 0x01, lane01_status, lane23_status);
        }

        status_change = 0;
        return BRIDGECHIP_STATUS_FAILED;
    }
}

void serdes_get_983_dp_rx_status(int32 fd)
{
    uint32 dp_rate, lanes;
    uint32 h_res, h_pol, h_sync, h_back, h_total;
    uint32 v_res, v_pol, v_sync, v_back, v_total;
    uint32 lane01_status, lane23_status;
    uint8  vp_status;

    dp_rate = apb_read_reg(fd, 0, 0x400) * 27;
    lanes = apb_read_reg(fd, 0, 0x404);
    lane01_status = apb_read_reg(fd, 0, 0x43C);
    lane23_status = apb_read_reg(fd, 0, 0x440);
    h_res = apb_read_reg(fd, 0, 0x500);
    h_pol = apb_read_reg(fd, 0, 0x504);
    h_sync = apb_read_reg(fd, 0, 0x508);
    h_back = apb_read_reg(fd, 0, 0x50C) - h_sync;
    h_total = apb_read_reg(fd, 0, 0x510);
    v_res = apb_read_reg(fd, 0, 0x514);
    v_pol = apb_read_reg(fd, 0, 0x518);
    v_sync = apb_read_reg(fd, 0, 0x51C);
    v_back = apb_read_reg(fd, 0, 0x520) - v_sync;
    v_total = apb_read_reg(fd, 0, 0x524);

    read_reg(fd, 0x45, &vp_status);

    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "DP Lock Status");
    CRITICAL_PRINT(MODULE_NAME, "DP Rate: %d", dp_rate);
    CRITICAL_PRINT(MODULE_NAME, "Lanes: %d", lanes);
    CRITICAL_PRINT(MODULE_NAME, "Lane01 Status: 0x%x", lane01_status);
    CRITICAL_PRINT(MODULE_NAME, "Lane23 Status: 0x%x", lane23_status);
    CRITICAL_PRINT(MODULE_NAME, "H RES: %d", h_res);
    CRITICAL_PRINT(MODULE_NAME, "H POL: %d", h_pol);
    CRITICAL_PRINT(MODULE_NAME, "H SYNC WIDTH: %d", h_sync);
    CRITICAL_PRINT(MODULE_NAME, "H BACK PORCH: %d", h_back);
    CRITICAL_PRINT(MODULE_NAME, "H TOTAL: %d", h_total);
    CRITICAL_PRINT(MODULE_NAME, "v RES: %d", v_res);
    CRITICAL_PRINT(MODULE_NAME, "V POL: %d", v_pol);
    CRITICAL_PRINT(MODULE_NAME, "V SYNC WIDTH: %d", v_sync);
    CRITICAL_PRINT(MODULE_NAME, "V BACK PORCH: %d", v_back);
    CRITICAL_PRINT(MODULE_NAME, "V TOTAL: %d", v_total);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
            vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");


}


BridgeChip_StatusType serdes_des_update_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    /*
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus |= link_set_deserializer_video_misc(fd);
    eStatus |= link_convert_deserializer_fpd3_to_fpd4(fd);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus |= link_set_serializer_fpd4(fd);
    */
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_des_bypass_link_status(fd));
    i2c_set_slave_addr(fd, MCU_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | enable_panel_backlight(fd));
    sleep(1);

    return eStatus;
}

BridgeChip_StatusType serdes_fpd_link_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    int i = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_DIGITAL_ALL);
    write_reg(fd, 0x01, SER_RESET_DIGITAL_ALL);

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

    eStatus = link_set_serializer_fpd3(fd);
   // eStatus = link_set_serializer_patgen(fd);
    for (i = 0; i < 5; i++) {
        (void) usleep(100*1000);
        if ((serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS))
            break;
    }

    if(i >= 5)
        CRITICAL_PRINT(MODULE_NAME, "Link up fail ");

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_video_misc(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));

    return eStatus;
}

//used for link lost recovery init
BridgeChip_StatusType recovery_ti983_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);

    CRITICAL_PRINT(MODULE_NAME, "Link setup to FPD-Link III mode");

    eStatus = link_set_serializer_fpd3(fd);

    return eStatus;
}

BridgeChip_StatusType recovery_ti983_fpd4_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_video_misc(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));

    return eStatus;
}
static BridgeChip_StatusType soc_983_link_status = (BridgeChip_StatusType)0;
BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
    int32_t port1_link = 0;
    BridgeChip_StatusType soc_983_link_status_tmp = (BridgeChip_StatusType)0;

    int32_t port0_llost_flag = 0;
    int32_t port1_llost_flag = 0;
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define LINK_DETECT_BIT    0

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ))
        port0_link = 1;

    if ( (((regval>>LINK_LOST_FLAG_BIT) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ )
        port0_llost_flag = 1;

    /*
       CRITICAL_PRINT(MODULE_NAME,
       "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x, reg: 0x0C = 0x%02x\n",
       (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01), regval);
    */
    regval = 0;
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ))
        port1_link = 1;

    if ( (((regval>>LINK_LOST_FLAG_BIT) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ )
        port1_llost_flag = 1;
    /*
       CRITICAL_PRINT(MODULE_NAME,
       "Port1: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x, reg: 0x0C = 0x%02x\n",
       (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01), regval);
    */
	write_reg(fd, 0x2D, 0x01);
    soc_983_link_status_tmp = serdes_check_983_dp_linkup(fd);
    if (soc_983_link_status != soc_983_link_status_tmp)
    {
        soc_983_link_status = soc_983_link_status_tmp;
        if (soc_983_link_status == BRIDGECHIP_STATUS_FAILED) {
            CRITICAL_PRINT(MODULE_NAME, "!!!! soc to 983 dp link NOT valid !!!!");
            serdes_get_983_dp_rx_status(fd);
		}
        else if(soc_983_link_status == BRIDGECHIP_STATUS_SUCCESS)
            CRITICAL_PRINT(MODULE_NAME, " soc to 983 dp link valid");
    }

    if ((port0_link == 1) && (port1_link == 1) &&
        (port0_llost_flag == 0) && (port1_llost_flag == 0))
        return BRIDGECHIP_STATUS_SUCCESS;
    else if (((port0_link == 1) && (port0_llost_flag == 1)) ||
        ((port1_link == 1) && (port1_llost_flag == 1))) {
        ser_clear_linklost_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    } else
        return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = serdes_fpd_link_cfg(i2c_fh);
    return eStatus;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    eStatus = serdes_des_update_cfg(i2c_fh);
    return eStatus;
}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

void ser_clear_linklost_flag(int32 i2c_fh)
{
    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(i2c_fh, 0x2D, 0x01);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x12);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x01);
}

#ifdef __cplusplus
}
#endif
