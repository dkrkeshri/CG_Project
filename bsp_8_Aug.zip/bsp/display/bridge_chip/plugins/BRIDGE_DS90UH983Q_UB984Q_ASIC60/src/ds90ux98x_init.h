#ifndef DS90UX98X_INIT_H
#define DS90UX98X_INIT_H

#define SER_RESET_DIGITAL_ALL 0x02
#define SER_RESET_PLL_ONLY    0x30
BridgeChip_StatusType serdes_fpd_link_cfg(int32 fd);
BridgeChip_StatusType serdes_des_update_cfg(int32 fd);
BridgeChip_StatusType serdes_get_ser_link_status(int32 fd);

BridgeChip_StatusType serdes_check_ser_vp_status(int32 fd);
void serdes_get_983_dp_rx_status(int32 fd);
BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd);
BridgeChip_StatusType ser_config_update(int32 i2c_fh);
BridgeChip_StatusType dser_config_update(int32 i2c_fh);
void set_reset_keep_dprx(int32 val);
BridgeChip_StatusType recovery_ti983_fpd4_init(int32 fd);
BridgeChip_StatusType recovery_ti983_fpd3_init(int32 fd);
void ser_clear_linklost_flag(int32 i2c_fh);

#endif
