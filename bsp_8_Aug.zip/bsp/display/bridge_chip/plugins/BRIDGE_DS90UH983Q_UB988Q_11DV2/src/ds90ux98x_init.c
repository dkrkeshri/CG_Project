#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT   0x0C
#define DES_ID_7BIT   0x2C
#define MCU_ID_7BIT   0x12
#define TOUCH_ID_7BIT 0x24

#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)
#define TOUCH_ID_8BIT (TOUCH_ID_7BIT << 1)


// Panel Timings
#define THW               2232   // Total horizontal
#define TVW               994    // Total vertical
#define AHW               2000   // Active horizontal
#define AVW               974    // Active vertical
#define HBP               50     // Horizontal back porch
#define VBP               10     // Vertical back porch
#define HSW               40     // Horizontal sync width
#define VSW               5      // Vertical sync width
#define VFP               5      // Vertical front porch
#define MDIV              6462   // M Divider

static int32 verbosedebug = 1;

static int32 reset_keep_dprx = 0;
#define MODULE_NAME "INNOLUX 11.34 DV2"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "0x%x : 0x%x", reg, val);
        LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
        return -1;
    }
    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
        return -1;
    }

    return 0;
}

#define APB_CTL   0x48
#define APB_ADR0  0x49
#define APB_ADR1  0x4A
#define APB_DATA0 0x4B
#define APB_DATA1 0x4C
#define APB_DATA2 0x4D
#define APB_DATA3 0x4E
//def apb_read_reg(addr16b, channel, Device_ID):
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    if (channel == 0) {
        wr_val = 0x03;
    } else if (channel == 1) {
        wr_val = 0x0B;
    } else {
        wr_val = 0x03;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}

static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);

    if (channel == 0) {
        wr_val = 0x01;
    } else if (channel == 1) {
        wr_val = 0x09;
    } else {
        wr_val = 0x01;
    }
    write_reg(fd, APB_CTL, wr_val);

    return EXIT_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_gpio(int32 fd)
{
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set 983/981 GPIOs...");
    read_reg(fd, 0x30, &RevId);
    RevId &= 0xF0;
    if (RevId >= 0x40)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd3(int32 fd)
{
	CRITICAL_PRINT(MODULE_NAME, "Soft Reset Serializer");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "Set 983/981 to FPD-LINK III Mode..........");
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, TOUCH_ID_8BIT);
    write_reg(fd, 0x7A, TOUCH_ID_8BIT);
    write_reg(fd, 0x05, 0x00);
    write_reg(fd, 0x59, 0x01);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xE0);
    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x01, 0x00);
    write_reg(fd, 0x5B, 0x2B);
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);
    (void)usleep(20*1000);
    CRITICAL_PRINT(MODULE_NAME, "Enable I2C Passthrough..........");
    write_reg(fd, 0x07, 0x88);
    (void)usleep(20*1000);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;
    uint8 i = 0;
    for (i=0; i<5; i++) {

        if (read_reg(fd, 0x00, &regval) == 0) {
            CRITICAL_PRINT(MODULE_NAME, "Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", regval, chipId);
            if (regval == chipId) {
                break;
            }
        }
        (void) usleep(50*1000);

    }

    if (i<5)
        return TRUE;
    else
        return FALSE;
}

static BridgeChip_StatusType link_convert_deserializer_fpd3_to_fpd4(int32 fd)
{
    write_reg(fd, 0x0e, 0x3);
    //write_reg(fd, 0x91, 0x80);
    write_reg(fd, 0x9b, 0x1c);
    write_reg(fd, 0x0e, 0x1);
    /* Disable DES 0 OLDI */
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00);

    /* Change des_id_remote0 PLL to FPD4 settings */
    CRITICAL_PRINT(MODULE_NAME, "Change DES_ID_REMOTE0 PLL to FPD4 settings");
    write_reg(fd, 0x40, 0x38);
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0xb0);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0xb0);

    write_reg(fd, 0x2b, 0x1b);
    write_reg(fd, 0x2c, 0x1b);

    write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "Reset Receiver");
    (void)usleep(40*1000);
    CRITICAL_PRINT(MODULE_NAME, "Check if we can read receiver");
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "Program FPD4 PLL to 6.75 GHz on VCO");
        write_reg(fd, 0x40, 0x08);
        write_reg(fd, 0x41, 0x05);
        write_reg(fd, 0x42, 0x7d);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x80);
        write_reg(fd, 0x0e, 0x03);
        write_reg(fd, 0x61, 0x09);
        write_reg(fd, 0x95, 0x06);
        write_reg(fd, 0x60, 0x0F);
        write_reg(fd, 0x40, 0x56);
        write_reg(fd, 0x41, 0x34);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0x35);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0xB4);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0xB5);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x33, 0x05);
        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "Issue a software reset to get the receiver PLL setting loaded");
        (void)usleep(40*1000);
        CRITICAL_PRINT(MODULE_NAME, "Check if we can read receiver before writing FPD4 Settings");
        if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
        {
            CRITICAL_PRINT(MODULE_NAME, "End reprogramming FPD3 -> FPD4 settings");
            CRITICAL_PRINT(MODULE_NAME, "Now to switch to FPD4 on deserializer.  Link will be lost momentarily.");
            write_reg(fd, 0x0e, 0x03);
            write_reg(fd, 0x5f, 0x00);
            //TODO: 0X31 register write fail
            write_reg(fd, 0x31, 0x67);
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME, "Warning: Could not read receiver.  Increase delay prior to continuing program flow");
            return BRIDGECHIP_STATUS_FAILED;
        }
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "Warning: Could not read receiver.  Increase delay prior to continuing program flow");
        return BRIDGECHIP_STATUS_FAILED;
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_deserializer_enable_oldi(int32 fd)
{
    /* Port 0 11" OLDI */
    write_reg(fd, 0xD0, 0x04);
    write_reg(fd, 0xD7, 0x00);
    write_reg(fd, 0x40, 0x2C); //Page11_oLDI register
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x18); //PLL_NDIV
    write_reg(fd, 0x42, 0x22);
    write_reg(fd, 0x41, 0x08); //oLDI_PLL_DIG1
    write_reg(fd, 0x42, 0x82);
    write_reg(fd, 0x41, 0x09); //oLDI_PLL_DIG2
    write_reg(fd, 0x42, 0xF1);
    write_reg(fd, 0x41, 0x0A); //oLDI_PLL_DIG3
    write_reg(fd, 0x42, 0xDF);
    write_reg(fd, 0x41, 0x0B); //oLDI_PLL_DIG4
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x41, 0x0C); //oLDI_PLL_DIG5
    write_reg(fd, 0x42, 0xD8);
    write_reg(fd, 0x41, 0x0D); //oLDI_PLL_DIG6
    write_reg(fd, 0x42, 0x18);
//    write_reg(fd, 0x41, 0x2D);
//    write_reg(fd, 0x42, 0x11);
    write_reg(fd, 0x40, 0x50); //Page20_Display timing
    write_reg(fd, 0x41, 0x20); //timing_gen_reg20
    write_reg(fd, 0x42, 0x53);
    write_reg(fd, 0x01, 0x40); // OLDI RESET

    write_reg(fd, 0x40, 0x2c);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x14);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType disable_983_dp_line_reset(int32 fd)
{
    uint32 apb_data = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 RevId = 0;
#if 0 //old lane setting
    // DP0 Lane 0	
    write_reg(fd, 0x40, 0x10);	
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);
	
    // DP0 Lane 1
	write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);
	
    // DP0 Lane 2
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);
	
    // DP0 Lane 3
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);
#else
    //lane setting for 8.1G, latest from TI
    // DP0 Lane 0
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 1
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 2
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 3
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);
#endif
	
    /* DP config */
    CRITICAL_PRINT(MODULE_NAME, "Configure DP");
    read_reg(fd, 0x30, &RevId);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    CRITICAL_PRINT(MODULE_NAME, "Now switching 983 to FPD4 mode");
    //write_reg(fd, 0x2d, 0x03);
    //write_reg(fd, 0x6a, 0x4a);
    // for 983 CS2.0
    if ((RevId & 0xF0) == 0x50)
    {
        write_reg(fd, 0x6E, 0x80);
    }
    //CRITICAL_PRINT(MODULE_NAME," Disable FPD3 FIFO pass through"
    write_reg(fd, 0x5B, 0x23);
    write_reg(fd, 0x59, 0x05);
    write_reg(fd, 0x05, 0x3C);
    write_reg(fd, 0x02, 0xd1);
    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);

    CRITICAL_PRINT(MODULE_NAME, "Program PLL Settings");
    write_reg(fd, 0x43, 0x00);  // enable 1 stream
    /* 981 PLL programming */
    CRITICAL_PRINT(MODULE_NAME, "Properly program back channel");

    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x6a, 0x4a);

    CRITICAL_PRINT(MODULE_NAME, "Program PLL0 Settings");

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "Software reset 983");
	if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    (void) usleep(100*1000);
	
	write_reg(fd, 0x40, 0x08);
	write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "PLL reset 983");
    write_reg(fd, 0x01, 0x30);

    CRITICAL_PRINT(MODULE_NAME, "End of FPD3 to FPD4 Conversion");
    apb_write_reg(fd, 0, 0x0, 0x0);//Force HPD Low.
    patch_983_apb_vod(fd);
    apb_write_reg(fd, 0, 0x0, 0x1);//Force HPD hi.
    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Configure VP0");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); // program h_act
    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP)); //program v front porch

    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(MDIV));
    write_reg(fd, 0x42, upper_byte(MDIV)); // set M divider
    write_reg(fd, 0x42, 0x0F); // set N divider
/*
    CRITICAL_PRINT(MODULE_NAME, "Enable Patgen");
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x95);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x08);
*/
    CRITICAL_PRINT(MODULE_NAME, "Enable Video processor stream");
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x01); //
    write_reg(fd, 0x42, 0x01); // enable stream 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00); // map stream 0 to VP0
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x20); // set 32 time slots
	write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    write_reg(fd, 0x2D, 0x01);
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
	write_reg(fd, 0x01, 0x01);
	write_reg(fd, 0x43, 0x00); // enable VP0
    write_reg(fd, 0x44, 0x01); // enable VP0

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_serializer_fpd3(fd);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_gpio(fd));

    // If there is problem on FPDLINK3 stage. it is not need to later configs
    if (looping_983_fpd_linkup(fd) != BRIDGECHIP_STATUS_SUCCESS)
        return BRIDGECHIP_STATUS_FAILED;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | looping_983_fpd_linkup(fd));

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_vp(fd));

    return eStatus;
}

BridgeChip_StatusType link_enable_deserializer_panel(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    disable_983_dp_line_reset(fd);

    CRITICAL_PRINT(MODULE_NAME, "Enable 988 OLDI output");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    wait_988_link_stable(fd);
    eStatus = link_set_deserializer_enable_oldi(fd);

    return eStatus;
}

void wait_988_link_stable(int fd)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
    int32 i = 0;
    int32_t stable_count = 0;
    #define LOCK_STS_CHG_988 0x04 //bit2

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    do {
        read_reg(fd, 0x54, &regval);
        port0_link = regval & LOCK_STS_CHG_988;
        if (port0_link == 0x04) {
            //not stable
            stable_count = 0; 
            (void) usleep(50*1000);
        } else if (port0_link == 0x0) {
            //stable and count it
            stable_count ++;
            //break when continuous 5 times stable
            if (stable_count >= 5)
                break;
            (void) usleep(50*1000);
        }
    } while (i++ < 10);
}

BridgeChip_StatusType get_983_link_status(int fd)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
	static int32_t port0_link_old = 0;

    int32_t port0_llost_flag = 0;
    static int32_t port0_llost_flag_old = 0;
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FALG_BIT 4
#define LINK_DETECT_BIT    0


    write_reg(fd, 0x2D, 0x01);

    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ ) {
        port0_link = 1;
	} else {
		port0_link = 0;
	}

    if ( (((regval>>LINK_LOST_FALG_BIT) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ ) {
        port0_llost_flag = 1;
    } else {
        port0_llost_flag = 0;
    }


	if ((port0_link_old != port0_link)  || (port0_llost_flag_old != port0_llost_flag)) {

        CRITICAL_PRINT(MODULE_NAME,
                "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x, reg: 0x0C = 0x%02x\n",
                (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01), regval);
		port0_link_old = port0_link;
        port0_llost_flag_old = port0_llost_flag;
	}

    get_983_irq_status_reg_bit0(fd);
    // port0_link indicate the cable connection.  port0_llost_flag indicate the forward channel
    if ((port0_link == 1) && (port0_llost_flag == 0))
        return BRIDGECHIP_STATUS_SUCCESS;
    else if ((port0_link == 1) && (port0_llost_flag == 1)) {
        ser_clear_linklost_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    } else
        return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType looping_983_fpd_linkup(int fd)
{
    int32_t i;
    //looping here max time with 500ms
    for (i=0; i<50; i++) {
        if (get_983_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
            return BRIDGECHIP_STATUS_SUCCESS;
        else
            (void) usleep(10*1000);
    }
    CRITICAL_PRINT(MODULE_NAME, "looping_983_fpd_linkup timeout, NO FPD link !!");
    return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType is_983_dp_linkup(int fd)
{
    uint32 lane01_status, lane23_status;
    static uint8  vp_status = 0, vp_status_tmp = 0, dp_linklost = 1;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    lane01_status = apb_read_reg(fd, 0, 0x43C);
    lane23_status = apb_read_reg(fd, 0, 0x440);
    read_reg(fd, 0x45, &vp_status);	
	
    if (vp_status != vp_status_tmp) {
        CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
                vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);
        CRITICAL_PRINT(MODULE_NAME, "DP lane state : | VP0:%d |lane01_status:0x%x |lane23_status:0x%x",
                vp_status & 0x1,lane01_status,lane23_status);
        vp_status_tmp = vp_status;
    }

#ifdef FORCE_CHECK_VP
    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377) && ((vp_status & 0x03) == 0x01))
#else
    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377))
#endif
	{
        //only inform once to slog
        if (dp_linklost == 1) {
            CRITICAL_PRINT(MODULE_NAME, "DP lane state : | VP0:%d |lane01_status:0x%x |lane23_status:0x%x",
                vp_status & 0x1,lane01_status,lane23_status);
        }
        dp_linklost = 0;
        return BRIDGECHIP_STATUS_SUCCESS;
	}
    else
	{
        //only inform once to slog
        if (dp_linklost == 0) {
            CRITICAL_PRINT(MODULE_NAME, "DP link lost or not ready: | VP0:%d |lane01_status:0x%x |lane23_status:0x%x",
                vp_status & 0x1,lane01_status,lane23_status);
        }
        dp_linklost = 1;
        return BRIDGECHIP_STATUS_FAILED;
	}
}

BridgeChip_StatusType looping_983_dp_linkup(int fd)
{
    int32_t i;
    for (i=0; i<100; i++) {
        if (is_983_dp_linkup(fd) == BRIDGECHIP_STATUS_SUCCESS)
            return BRIDGECHIP_STATUS_SUCCESS;
        else
            (void) usleep(20*1000);
    }
    CRITICAL_PRINT(MODULE_NAME, "looping_983_dp_linkup timeout, NO dp link !!");
    return BRIDGECHIP_STATUS_FAILED;
}

//used for link lost recovery init
BridgeChip_StatusType recovery_ti983_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);

    CRITICAL_PRINT(MODULE_NAME, "Link setup to FPD-Link III mode");
    eStatus = link_set_serializer_gpio(fd);
    eStatus = link_set_serializer_fpd3(fd);

    return eStatus;
}

BridgeChip_StatusType recovery_ti983_fpd4_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_vp(fd));

    return eStatus;
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    eStatus = link_convert_fpd3_to_fpd4(i2c_fh);

    return eStatus;
}

BridgeChip_StatusType check_988_lock()
{
    /*
    uint8 lock_statu1 = 0, lock_statu2 = 0;
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    int i;

    for (i = 0; i < 20; i++) {
        eStatus = bridge_i2c_read(gsPluginInfo.hI2CFileDes, 0x53, &lock_statu1, I2C_READ_1_BYTE_LENGTH);
        if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
        {
            LOG_CRITICAL_INFO(CHIP_ID, "%s read DESID REG:0x06 failed", __func__);

        }
        LOG_CRITICAL_INFO(CHIP_ID, "%s read REG:0x53, val:%x ", __func__, lock_statu1);

        if (((lock_statu1 & 0x1) == 0x1) &&((lock_statu1 & 0x80) == 0x0)) {
            if(lock_statu1 == lock_statu2)
                break;
        }
        lock_statu2 = lock_statu1;

    }
    if (i >= 20)
        return BRIDGECHIP_STATUS_FAILED;
    else
    */
        return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    uint8 val = 0;
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	
	eStatus = (BridgeChip_StatusType)read_reg(i2c_fh, 0x08, &val);
	if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        goto fail;
    }
/*
    eStatus = bridge_i2c_read(i2c_fh, 0x08, &val, I2C_READ_1_BYTE_LENGTH);
    if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        LOG_CRITICAL_INFO(CHIP_ID, "%s read DESID REG:0x08, val:%x failed", __func__, val);
        goto fail;
    }*/
    i2c_set_slave_addr(i2c_fh, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    if (check_988_lock() == BRIDGECHIP_STATUS_SUCCESS)
    {
        eStatus = link_enable_deserializer_panel(i2c_fh);
    }
    else
    {
 //       LOG_CRITICAL_INFO(CHIP_ID, "Failed to update dserializer registers");
        eStatus = BRIDGECHIP_STATUS_FAILED;
    }

fail:
	i2c_set_slave_addr(i2c_fh, SER_ID_7BIT , I2C_ADDRFMT_7BIT);

	return eStatus;
}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

void ser_clear_linklost_flag(int32 i2c_fh)
{
    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(i2c_fh, 0x2D, 0x01);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x12);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x01);
}

static int irq_status_reg_bit0 = 0;
void get_983_irq_status_reg_bit0(int fd)
{
    uint8_t regval=0;
    uint8_t regval_0=0;
    write_reg(fd, 0x40, 0x25);
    write_reg(fd, 0x41, 0x3F);
    read_reg(fd, 0x42, &regval);
    regval_0 = regval & 0x1;

    if (regval_0 != irq_status_reg_bit0) {
        irq_status_reg_bit0 = regval_0;
        CRITICAL_PRINT(MODULE_NAME, "983_irq_status_reg_bit0: %d(0x3f=0x%x)", regval_0, regval);
    }
}

void patch_983_apb_vod(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_vod");
    apb_write_reg(fd, 0, 0x214, 0x02);
}

void patch_983_apb_54rst(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_54rst");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    apb_write_reg(fd, 0, 0x54, 0x01);
}

#ifdef __cplusplus
}
#endif
