#ifndef DS90UX98X_INIT_H
#define DS90UX98X_INIT_H

#define SER_RESET_DIGITAL_ALL 0x02
#define SER_RESET_PLL_ONLY    0x30
BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd);
BridgeChip_StatusType link_enable_deserializer_panel(int32 fd);
BridgeChip_StatusType get_983_link_status(int fd);
BridgeChip_StatusType looping_983_fpd_linkup(int fd);
BridgeChip_StatusType is_983_dp_linkup(int fd);
BridgeChip_StatusType looping_983_dp_linkup(int fd);
BridgeChip_StatusType check_988_lock();
BridgeChip_StatusType ser_config_update(int32 i2c_fh);
BridgeChip_StatusType dser_config_update(int32 i2c_fh);
void set_reset_keep_dprx(int32 val);
BridgeChip_StatusType recovery_ti983_fpd4_init(int32 fd);
BridgeChip_StatusType recovery_ti983_fpd3_init(int32 fd);
void wait_988_link_stable(int fd);
void ser_clear_linklost_flag(int32 i2c_fh);
void patch_983_apb_vod(int32 fd);
void patch_983_apb_54rst(int32 fd);
void get_983_irq_status_reg_bit0(int fd);

#endif
