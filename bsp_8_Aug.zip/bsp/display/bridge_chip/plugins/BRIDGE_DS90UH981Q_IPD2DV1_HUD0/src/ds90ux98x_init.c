#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT       0x0C
#define DES_ID_7BIT       0x2C
#define MCU_ID_7BIT       0x12
#define DES_DC_ID_7BIT    0x2C
#define MCU_DC_ID_7BIT    0x12

#define DES_DC_ID_7BIT_ALIAS    0x40
#define MCU_DC_ID_7BIT_ALIAS    0x48

#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)
#define DES_DC_ID_8BIT   (DES_DC_ID_7BIT << 1)
#define MCU_DC_ID_8BIT   (MCU_DC_ID_7BIT << 1)

#define DES_DC_ID_8BIT_ALIAS   (DES_DC_ID_7BIT_ALIAS << 1)
#define MCU_DC_ID_8BIT_ALIAS   (MCU_DC_ID_7BIT_ALIAS << 1)

#define FC_FPD_FREQ       6.75
#define FPS               60

// Panel Timings
#define THW               2308   // Total horizontal
#define TVW               858    // Total vertical
#define AHW               2000   // Active horizontal
#define AVW               810    // Active vertical
#define HBP               36     // Horizontal back porch
#define HSW               12     // Horizontal sync width
#define VBP               2      // Vertical back porch
#define VSW               22      // Vertical sync width
#define VFP               24     // Vertical front porch

// Panel Timings
#define DC_THW            720    // Total horizontal
#define DC_TVW            264    // Total vertical
#define DC_AHW            480    // Active horizontal
#define DC_AVW            240    // Active vertical
#define DC_HBP            16     // Horizontal back porch
#define DC_HSW            32     // Horizontal sync width
#define DC_VBP            2      // Vertical back porch
#define DC_VSW            3      // Vertical sync width
#define DC_VFP            19     // Vertical front porch


#define ENABLE_VP0_PATTERN        0
#define ENABLE_VP1_PATTERN        0

#define LOCK_STS_CHG_988 0x04 //bit2
#define RX_LOCK_DETECT_BIT 6
#define LINK_DETECT_BIT    0

static int32 verbosedebug = 1;
static int32 reset_keep_dsi = 0;
#define MODULE_NAME "SER-DES [TOPOLOGY-16]"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    DEBUG_PRINT(MODULE_NAME, "%s Reg: 0x%x Data: 0x%x", __func__, reg, val);
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2)
    {
        CRITICAL_PRINT(MODULE_NAME, "0x%x : 0x%x", reg, val);
        LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
        return  iRetVal;
    }
    else
    {
        return 0;
    }
}

int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1)
    {
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
        return iRetVal;
    }
    else
    {
        return 0;
    }
}

static BridgeChip_StatusType link_set_serializer_fpd3(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Soft Reset Serializer");
    if (reset_keep_dsi)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "Set 983/981 to FPD-LINK III Mode..........");
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, DES_DC_ID_8BIT);
    write_reg(fd, 0x7A, DES_DC_ID_8BIT_ALIAS);
    write_reg(fd, 0x73, MCU_DC_ID_8BIT);
    write_reg(fd, 0x7B, MCU_DC_ID_8BIT_ALIAS);
    write_reg(fd, 0x8A, 0x01);
    write_reg(fd, 0x8B, 0x01);
    write_reg(fd, 0x05, 0x00);
    write_reg(fd, 0x59, 0x01);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xE0);
    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x01, 0x00);
    write_reg(fd, 0x5B, 0x2B);
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);
    (void)usleep(20*1000);
    CRITICAL_PRINT(MODULE_NAME, "Enable I2C Passthrough..........");
    write_reg(fd, 0x07, 0x88);
    (void)usleep(20*1000);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_gpio(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Set 981 GPIOs...");
    // write_reg(fd, 0x18, 0x80); //GPIO1 OUTPUT, Source: FPD Port 0, Select: BC_GPIO0
    write_reg(fd, 0x23, 0x81); //GPIO12 OUTPUT, Source: FPD Port 0, Select: BC_GPIO1

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_gpio(int32 fd)
{
    write_reg(fd, 0x40, 0x04); // Page 1
    write_reg(fd, 0x41, 0x10); // BC_GPIO0_SEL
    write_reg(fd, 0x42, 0x00); // BC GPIO0 send local GPIO0
    write_reg(fd, 0x41, 0x11); // BC_GPIO1_SEL
    write_reg(fd, 0x42, 0x10); // BC GPIO1 send Daisy Chain port0 BC_GPIO1

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_daisy_gpio(int32 fd)
{
    write_reg(fd, 0x40, 0x04); // Page 1
    write_reg(fd, 0x41, 0x11); // BC_GPIO1_SEL
    write_reg(fd, 0x42, 0x00); // BC GPIO1 send local GPIO0

    return BRIDGECHIP_STATUS_SUCCESS;
}

static bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;
    uint8 i = 0;

    for (i = 0; i < 5; i++ )
    {
        if (read_reg(fd, 0x00, &regval) == 0)
        {
            CRITICAL_PRINT(MODULE_NAME, "Readed ChipId = 0x%02x, wanted ChipId = 0x%02x",regval, chipId);
            if (regval == chipId)
                break;
            (void) usleep(10 * 1000);
        }
    }

    if (i < 5)
        return TRUE;
    else
        return FALSE;
}

static BridgeChip_StatusType serdes_wait_des_fpd_linkup(int fd)
{
    uint8_t regval = 0;
    int32_t port0_link = 0;
    int32 i = 0;
    int32_t stable_count = 0;

    do
    {
        if (read_reg(fd, 0x54, &regval) == 0)
        {
            port0_link = regval & LOCK_STS_CHG_988;
            if (port0_link == 0x04)
            {
                //not stable
                stable_count = 0;
            }
            else if (port0_link == 0x0)
            {
                //stable and count it
                stable_count ++;
                //break when continuous 5 times stable
                if (stable_count >= 5)
                    break;
            }
        }
        (void) usleep(50*1000);
    }
    while (i++ < 10);

    if (stable_count >= 5)
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        return BRIDGECHIP_STATUS_FAILED;
    }
}

static BridgeChip_StatusType link_convert_deserializer_fpd3_to_fpd4(int32 fd)
{
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
        write_reg(fd, 0x0E, 0x03);
        write_reg(fd, 0x9B, 0x1C);
        write_reg(fd, 0x0E, 0x01);
        /* Disable DES 0 OLDI */
        write_reg(fd, 0x40, 0x2C);
        write_reg(fd, 0x41, 0x02);
        write_reg(fd, 0x42, 0x00);

        /* Change des_id_remote0 PLL to FPD4 settings */
        CRITICAL_PRINT(MODULE_NAME, "Change DES_ID_REMOTE0 PLL to FPD4 settings");
        write_reg(fd, 0x40, 0x38);
        write_reg(fd, 0x41, 0x23);
        write_reg(fd, 0x42, 0x0f);
        write_reg(fd, 0x41, 0x53);
        write_reg(fd, 0x42, 0x0f);
        write_reg(fd, 0x41, 0x24);
        write_reg(fd, 0x42, 0x64);
        write_reg(fd, 0x41, 0x54);
        write_reg(fd, 0x42, 0x64);
        write_reg(fd, 0x41, 0x26);
        write_reg(fd, 0x42, 0xb0);
        write_reg(fd, 0x41, 0x56);
        write_reg(fd, 0x42, 0xb0);

        write_reg(fd, 0x2b, 0x1b);
        write_reg(fd, 0x2c, 0x1b);
        write_reg(fd, 0x0e, 0x03);
        //write_reg(fd, 0x91, 0x80);
        write_reg(fd, 0x9b, 0x1c);
        write_reg(fd, 0x0e, 0x01);

        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "Reset Receiver");
        (void) usleep(40*1000);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "We cann't read receiver, init IPD0 failed");
        return BRIDGECHIP_STATUS_FAILED;
    }
    CRITICAL_PRINT(MODULE_NAME, "Check if we can read receiver");
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "Program FPD4 PLL to 6.75 GHz on VCO");
        write_reg(fd, 0x40, 0x08);
        write_reg(fd, 0x41, 0x05);
        write_reg(fd, 0x42, 0x7d);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x80);
        write_reg(fd, 0x0e, 0x03);
        write_reg(fd, 0x61, 0x09);
        write_reg(fd, 0x95, 0x06);
        write_reg(fd, 0x60, 0x0F);
        write_reg(fd, 0x40, 0x5C);
        write_reg(fd, 0x41, 0x34);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0x35);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0xB4);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0xB5);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x33, 0x05);
        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "Issue a software reset to get the receiver PLL setting loaded");
        (void) usleep(40*1000);
        CRITICAL_PRINT(MODULE_NAME, "Check if we can read receiver before writing FPD4 Settings");
        if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
        {
            CRITICAL_PRINT(MODULE_NAME, "End reprogramming FPD3 -> FPD4 settings");
            CRITICAL_PRINT(MODULE_NAME, "Now to switch to FPD4 on deserializer.  Link will be lost momentarily.");
            write_reg(fd, 0x0e, 0x03);
            write_reg(fd, 0x5f, 0x00);
            //TODO: 0X31 register write fail
            write_reg(fd, 0x31, 0x67);
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME, "Warning: Could not read receiver.  Increase delay prior to continuing program flow");
            return BRIDGECHIP_STATUS_FAILED;
        }
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "Warning: Could not read receiver.  Increase delay prior to continuing program flow");
        return BRIDGECHIP_STATUS_FAILED;
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_oldi_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    eStatus = serdes_wait_des_fpd_linkup(fd);

    if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait deserializer 1 linkup fail");
        return eStatus;
    }
    else
    {
    }

    /* Port 0 8" OLDI */
    CRITICAL_PRINT(MODULE_NAME, "Enable 988 OLDI output for 11 inch IPD2");
    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    write_reg(fd, 0xD0, 0x04);
    write_reg(fd, 0xD7, 0x00);

    write_reg(fd, 0x40, 0x2C); //Page11_oLDI register
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x18); //PLL_NDIV
    write_reg(fd, 0x42, 0x1E);
    write_reg(fd, 0x41, 0x0A); //oLDI_PLL_DIG3
    write_reg(fd, 0x42, 0xA8);
    write_reg(fd, 0x41, 0x09); //oLDI_PLL_DIG2
    write_reg(fd, 0x42, 0xF0);
    write_reg(fd, 0x41, 0x08); //oLDI_PLL_DIG1
    write_reg(fd, 0x42, 0x6A);
    write_reg(fd, 0x41, 0x0B); //oLDI_PLL_DIG4
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x41, 0x0C); //oLDI_PLL_DIG5
    write_reg(fd, 0x42, 0xC6);
    write_reg(fd, 0x41, 0x0D); //oLDI_PLL_DIG6
    write_reg(fd, 0x42, 0x84);
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x11);
    write_reg(fd, 0x40, 0x50); //Page20_Display timing
    write_reg(fd, 0x41, 0x20); //timing_gen_reg20
    write_reg(fd, 0x42, 0x53);
    write_reg(fd, 0x01, 0x40); // OLDI RESET

    return eStatus;
}

BridgeChip_StatusType link_set_deserializer_enable_oldi(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    eStatus = serdes_wait_des_fpd_linkup(fd);

    if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait deserializer 1 linkup fail");
        return eStatus;
    }
    else
    {
    }

    /* Enable OLDI 11" */
    CRITICAL_PRINT(MODULE_NAME, "Enable 988 OLDI output for 11 inch IPD0");
    write_reg(fd, 0x40, 0x2c);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x14);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Configure DSI");
    read_reg(fd, 0x30, &RevId);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x02, 0xD8);
    if ((RevId & 0xF0) >= 0x20)
    {
        write_reg(fd, 0x4F, 0x8D);
    }
    else
    {
        write_reg(fd, 0x4F, 0x8C);
    }
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    CRITICAL_PRINT(MODULE_NAME, "Now switching 981 to FPD4 mode");
    //write_reg(fd, 0x2d, 0x03);
    //write_reg(fd, 0x6a, 0x0a);
    // for 981 CS2.0
    if ((RevId & 0xF0) == 0x20)
    {
        write_reg(fd, 0x6E, 0x80);
    }
    //CRITICAL_PRINT(MODULE_NAME," Disable FPD3 FIFO pass through"
    write_reg(fd, 0x5B, 0x23);
    write_reg(fd, 0x59, 0x05);
    write_reg(fd, 0x05, 0x3C);
    write_reg(fd, 0x02, 0xd1);
    write_reg(fd, 0x2d, 0x01);
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);

    CRITICAL_PRINT(MODULE_NAME, "Program PLL Settings");
    //    write_reg(fd, 0x43, 0x00);  // enable 1 stream
    /* 981 PLL programming */
    CRITICAL_PRINT(MODULE_NAME, "Properly program back channel");

    write_reg(fd, 0x43, 0x01); // enable 2 stream
    write_reg(fd, 0x44, 0x03); // enable VP0 and VP1
    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x6a, 0x4a);

    CRITICAL_PRINT(MODULE_NAME, "Program PLL0 Settings");

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "Software reset 981");
    if (reset_keep_dsi)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);

    CRITICAL_PRINT(MODULE_NAME, "End of FPD3 to FPD4 Conversion");

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    uint8 n_value = 15;
    uint16 m_value = 0;
    float src_pclk_freq = 0;
    float fc_freq = 0;
    float m_value_f = 0;


    CRITICAL_PRINT(MODULE_NAME, "Configure VP0");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page

    // Set crop for VP0
    write_reg(fd, 0x41, 0x0C);
    write_reg(fd, 0x42, lower_byte(AHW-1)); // stop x
    write_reg(fd, 0x42, upper_byte(AHW-1));
    write_reg(fd, 0x42, lower_byte(AVW-1)); // stop Y
    write_reg(fd, 0x42, upper_byte(AVW-1));

    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); // program h_act
    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP)); //program v front porch
    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //6750  bps
    src_pclk_freq = THW * TVW * FPS / 1000000.00f;
    CRITICAL_PRINT(MODULE_NAME, "VP0 PCLK = %f MHz",  src_pclk_freq);
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "VP0 m_value = %d",  m_value);

    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value)); // set M divider
    write_reg(fd, 0x42, n_value);             // set N divider
#if ENABLE_VP0_PATTERN
    CRITICAL_PRINT(MODULE_NAME, "Enable VP0 Patgen", __func__);
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x91);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x08);
#endif
    CRITICAL_PRINT(MODULE_NAME, "Configure VP1");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page

    // Set filter for VP1
    write_reg(fd, 0x41, 0x46);
    write_reg(fd, 0x42, 0x04);
    write_reg(fd, 0x41, 0x47);
    write_reg(fd, 0x42, 0x0D);
    // Set crop for VP1
    write_reg(fd, 0x41, 0x48);
    write_reg(fd, 0x42, lower_byte(AHW));  // start x
    write_reg(fd, 0x42, upper_byte(AHW));
    write_reg(fd, 0x42, 0x00);             // start y
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x42, lower_byte(AHW + DC_AHW - 1)); // stop x
    write_reg(fd, 0x42, upper_byte(AHW + DC_AHW - 1));
    write_reg(fd, 0x42, lower_byte(DC_AVW - 1));       // stop y
    write_reg(fd, 0x42, upper_byte(DC_AVW - 1));

    write_reg(fd, 0x41, 0x42);
    write_reg(fd, 0x42, lower_byte(DC_AHW));
    write_reg(fd, 0x42, upper_byte(DC_AHW)); // program h_act
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, lower_byte(DC_AHW));
    write_reg(fd, 0x42, upper_byte(DC_AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(DC_HBP));
    write_reg(fd, 0x42, upper_byte(DC_HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(DC_HSW));
    write_reg(fd, 0x42, upper_byte(DC_HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(DC_THW));
    write_reg(fd, 0x42, upper_byte(DC_THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(DC_AVW));
    write_reg(fd, 0x42, upper_byte(DC_AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(DC_VBP));
    write_reg(fd, 0x42, upper_byte(DC_VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(DC_VSW));
    write_reg(fd, 0x42, upper_byte(DC_VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(DC_VFP));
    write_reg(fd, 0x42, upper_byte(DC_VFP)); //program v front porch
    // set m/n value for video processor 1
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //6750  bps
    src_pclk_freq = DC_THW * DC_TVW * FPS / 1000000.00f;
    CRITICAL_PRINT(MODULE_NAME, "VP1 PCLK = %f MHz",  src_pclk_freq);
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "VP1 m_value = %d",  m_value);

    write_reg(fd, 0x41, 0x63);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value)); // set M divider
    write_reg(fd, 0x42, n_value);             // set N divider

    // Enable VP0 Crop
    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x04);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0xA8);

    // Enable VP1 Filtering and Crop
    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x40);
    write_reg(fd, 0x42, 0x06);
    write_reg(fd, 0x41, 0x41);
    write_reg(fd, 0x42, 0xA8);

#if ENABLE_VP1_PATTERN
    CRITICAL_PRINT(MODULE_NAME, "Enable VP1 Patgen", __func__);
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x68);
    write_reg(fd, 0x42, 0x95);
    write_reg(fd, 0x41, 0x69);
    write_reg(fd, 0x42, 0x08);
#endif

    CRITICAL_PRINT(MODULE_NAME, "Enable Video processor stream");
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x01); //
    write_reg(fd, 0x42, 0x03); // enable stream 0 and stream 1
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x10); // map stream 0 to VP0, map stream 1 to VP1
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x20); // set 32 time slots
    write_reg(fd, 0x41, 0x07);
    write_reg(fd, 0x42, 0x1E); // set 30 time slots
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x44, 0x03); // enable VP0 and VP1
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_tx_fpd3(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Set 988 TX to FPD-LINK III Mode for Daisy Chain..........");
    // For Daisy Chain
    write_reg(fd, 0x40, 0x1C); // Page 7
    // De-Emphasis Settings
    // Lane 0 TX
    write_reg(fd, 0x41, 0x00); // Flip driver segment for de-emphasis [7:0]
    write_reg(fd, 0x42, 0x07);
    write_reg(fd, 0x41, 0x01); // Flip driver segment for de-emphasis [15:8]
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x02); // Flip driver segment for de-emphasis [17:16]
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x0A); // Delay driver segment for de-emphasis [7:0]
    write_reg(fd, 0x42, 0x07);
    write_reg(fd, 0x41, 0x0B); // Delay driver segment for de-emphasis [15:8]
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x0C); // Delay driver segment for de-emphasis [17:16]
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "Setting PLL_TX_0 to 2.592GHz (PCLK=148.5MHz)");
    write_reg(fd, 0x40, 0x0C);  // Page 3
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7D);  // NCount [7:0]
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xE0);

    write_reg(fd, 0x01, 0x20);
    write_reg(fd, 0x01, 0x10);

    // FPD3 Mode control for port 0
    write_reg(fd, 0x40, 0x20); // Patge TX-DIG
    write_reg(fd, 0x41, 0x02); // FPD3_MODE_CTL_P0
    write_reg(fd, 0x42, 0x01); // Force FPD3 Single Mode on port 0
    // FPD3 Mode control for port 1
    //write_reg(fd, 0x41, 0x12); // FPD3_MODE_CTL_P1
    //write_reg(fd, 0x42, 0x01); // Force FPD3 Dual Mode on port 1

    write_reg(fd, 0x40, 0x20); // FPD_TX Digital
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x2B); // Enable FPD3 FIFO
    //write_reg(fd, 0x41, 0x14);
    //write_reg(fd, 0x42, 0x2B); // Enable FPD3 FIFO

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_daisy_fpd3_to_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Set daisy chain 1 from fpd3 to fpd4..........");
    if (TRUE == check_98x_chipid(fd, DES_DC_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Disable DES0 OLDI", __func__);
        write_reg(fd, 0x40, 0x2C);
        write_reg(fd, 0x41, 0x02);
        write_reg(fd, 0x42, 0x00);

        /* Change des_id_remote0 PLL to FPD4 settings */
        CRITICAL_PRINT(MODULE_NAME, "%s: Change Daisy DES_ID_REMOTE1 PLL to FPD4 settings", __func__);
        write_reg(fd, 0x40, 0x38);
        write_reg(fd, 0x41, 0x23);
        write_reg(fd, 0x42, 0x0f);
        write_reg(fd, 0x41, 0x53);
        write_reg(fd, 0x42, 0x0f);
        write_reg(fd, 0x41, 0x24);
        write_reg(fd, 0x42, 0x64);
        write_reg(fd, 0x41, 0x54);
        write_reg(fd, 0x42, 0x64);
        write_reg(fd, 0x41, 0x26);
        write_reg(fd, 0x42, 0xb0);
        write_reg(fd, 0x41, 0x56);
        write_reg(fd, 0x42, 0xb0);
        /*
           write_reg(fd, 0x2b, 0x1b);
           write_reg(fd, 0x2c, 0x1b);
           write_reg(fd, 0x0e, 0x3);
           write_reg(fd, 0x9b, 0x1c);
           write_reg(fd, 0x0e, 0x1);
           */
        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "%s: Reset Daisy Receiver", __func__);
        (void)usleep(40*1000);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: We cann't read DAISY receiver, init HUD failed", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }
    CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read DAISY receiver", __func__);
    if (TRUE == check_98x_chipid(fd, DES_DC_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Program Daisy Des FPD4 PLL to 6.75 GHz on VCO", __func__);
        write_reg(fd, 0x40, 0x08);
        write_reg(fd, 0x41, 0x05);
        write_reg(fd, 0x42, 0x7d);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x80);
        write_reg(fd, 0x0e, 0x03);
        write_reg(fd, 0x61, 0x09);
        write_reg(fd, 0x95, 0x06);
        write_reg(fd, 0x60, 0x0F);
        write_reg(fd, 0x40, 0x56);
        write_reg(fd, 0x41, 0x34);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0x35);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0xB4);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0xB5);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x33, 0x05);
        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "%s: Issue a software reset to get the daisy receiver PLL setting loaded", __func__);
        (void)usleep(40*1000);
        CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read daisy receiver before writing FPD4 Settings", __func__);
        if (TRUE == check_98x_chipid(fd, DES_DC_ID_8BIT))
        {
            CRITICAL_PRINT(MODULE_NAME, "%s: End reprogramming daisy chain FPD3 -> FPD4 settings", __func__);
            CRITICAL_PRINT(MODULE_NAME, "%s: Now to switch to FPD4 on daisy 988.  Link will be lost momentarily.", __func__);
            write_reg(fd, 0x0e, 0x03);
            write_reg(fd, 0x5f, 0x00);
            write_reg(fd, 0x31, 0x67);
            (void)usleep(100*1000);
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read daisy receiver.  Increase delay prior to continuing program flow", __func__);
            return BRIDGECHIP_STATUS_FAILED;
        }
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read daisy receiver.  Increase delay prior to continuing program flow", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_tx_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    // "Disable FPD3 FIFO on DES_TX"
    write_reg(fd,0x40,0x20);   // FPD_TX Digital
    write_reg(fd,0x41,0x04);
    write_reg(fd,0x42,0x23);   // Disable FPD3 FIFO
    write_reg(fd,0x41,0x14);
    write_reg(fd,0x42,0x23);   // Disable FPD3 FIFO
    (void) usleep(100 * 1000);

    CRITICAL_PRINT(MODULE_NAME,  "Force DAISY FPD4_TX to Single MODE");
    write_reg(fd,0xA8,0x14);  // FPD_TX to Single

    // Properly program back channel
    write_reg(fd,0x1E,0x03);
    write_reg(fd,0x90,0x0a);

    CRITICAL_PRINT(MODULE_NAME,  "Switch DAISY encoder from FPD3 to FPD4");
    write_reg(fd,0x40,0x20);
    write_reg(fd,0x41,0x84);
    write_reg(fd,0x42,0x02);
    write_reg(fd,0x41,0x94);
    write_reg(fd,0x42,0x02);

    // 988 PLL programming
    CRITICAL_PRINT(MODULE_NAME, "Program 988 Tx PLL Settings");
    write_reg(fd,0x40,0x0C);
    write_reg(fd,0x41,0x05);
    write_reg(fd,0x42,0x7d);
    write_reg(fd,0x41,0x13);
    write_reg(fd,0x42,0x90);
    write_reg(fd,0x41,0x04);
    write_reg(fd,0x42,0x01);
    write_reg(fd,0x41,0x1e);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x1f);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x20);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x45);
    write_reg(fd,0x42,0x7d);
    write_reg(fd,0x41,0x53);
    write_reg(fd,0x42,0x90);
    write_reg(fd,0x41,0x44);
    write_reg(fd,0x42,0x01);
    write_reg(fd,0x41,0x5e);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x5f);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x60);
    write_reg(fd,0x42,0x00);
    write_reg(fd,0x41,0x0e);
    write_reg(fd,0x42,0xc7);
    write_reg(fd,0x41,0x4e);
    write_reg(fd,0x42,0xc7);

    CRITICAL_PRINT(MODULE_NAME, "Software reset 988 Des 0");
    write_reg(fd,0x01,0x30);
    CRITICAL_PRINT(MODULE_NAME, "End of FPD3 to FPD4 Conversion for Daisy Chain");

    CRITICAL_PRINT(MODULE_NAME, "Enabling Daisy Chain Video to Stream_0");
    write_reg(fd,0x0E,0x01); // Set TX Port select
    write_reg(fd,0xD1,0x3F); // Set stream mapping, 02 is default
    write_reg(fd,0xD2,0x08); // Set stream 1 map to daisy chain port
    write_reg(fd,0x40,0x44); // TX Link Layer
    write_reg(fd,0x41,0x20);
    write_reg(fd,0x42,0x55); // Set 24 bit mode
    write_reg(fd,0x41,0x06); // default is 07
    write_reg(fd,0x42,0x20); // Set number of slots to 32 for video stream 0
    write_reg(fd,0x41,0x07); // default is 07
    write_reg(fd,0x42,0x1E); // Set number of slots to 30 for video stream 1
    write_reg(fd,0x41,0x01);
    write_reg(fd,0x42,0x03); // Enable stream 0 & 1 to link layer 0, default=02
    write_reg(fd,0x41,0x00);
    write_reg(fd,0x42,0x00); // Enable link layer and en_new_tslot0
    write_reg(fd,0x41,0x00);
    write_reg(fd,0x42,0x02); // Enable link layer and en_new_tslot0
    (void) usleep(10 * 1000);
    write_reg(fd,0x41,0x00);
    write_reg(fd,0x42,0x01); // Enable link layer and en_new_tslot0
    (void) usleep(10 * 1000);

    return eStatus;
}

#if 0
static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{
    uint8 r_data[] = {0x06, 0x00, 0x00 };

    sleep(2);
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Backlight", __func__);
    write_reg(fd, 0x05, 0x01);
    (void)usleep(20*1000);
    write_reg(fd, 0x06, 0xCC);

    i2c_combined_writeread(fd, &r_data[0], 1, &r_data[1], 2);
    CRITICAL_PRINT(MODULE_NAME, "%s: read back dimming_data: REG: 0x%02x, Data: 0x%02x, 0x%02x", __func__, r_data[0], r_data[1], r_data[2]);

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_deserializer_daisy_oldi_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    eStatus = serdes_wait_des_fpd_linkup(fd);

    if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait HUD 0 linkup fail");
        return eStatus;
    }
    else
    {
    }

    /* Port 0 HUD OLDI */
    CRITICAL_PRINT(MODULE_NAME, "Config 988 OLDI output for Panasonic HUD0");
    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    write_reg(fd, 0xD0, 0x04);
    write_reg(fd, 0xD7, 0x00);
    write_reg(fd, 0xD6, 0x01); // Set stream 1 map to Display output port 0
    write_reg(fd, 0x40, 0x2C); //Page11_oLDI register
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x18); //PLL_NDIV
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x08); //oLDI_PLL_DIG1
    write_reg(fd, 0x42, 0x7C);
    write_reg(fd, 0x41, 0x09); //oLDI_PLL_DIG2
    write_reg(fd, 0x42, 0xED);
    write_reg(fd, 0x41, 0x0A); //oLDI_PLL_DIG3
    write_reg(fd, 0x42, 0x65);
    write_reg(fd, 0x41, 0x0B); //oLDI_PLL_DIG4
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x41, 0x0C); //oLDI_PLL_DIG5
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x41, 0x0D); //oLDI_PLL_DIG6
    write_reg(fd, 0x42, 0xA5);
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x14);
    write_reg(fd, 0x40, 0x50); //Page20_Display timing
    write_reg(fd, 0x41, 0x20); //timing_gen_reg20
    write_reg(fd, 0x42, 0x13);
    write_reg(fd, 0x01, 0x40); // OLDI RESET

    return eStatus;
}

BridgeChip_StatusType link_set_deserializer_daisy_enable_oldi(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    eStatus = serdes_wait_des_fpd_linkup(fd);

    if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait HUD0 linkup fail");
        return eStatus;
    }
    else
    {
    }

    CRITICAL_PRINT(MODULE_NAME, "Enable 988 OLDI output for Panasonic HUD0");
    write_reg(fd, 0x40, 0x2c);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x11);

    return eStatus;
}

BridgeChip_StatusType serdes_get_des_daisy_link_status(int32 fd)
{
    return BRIDGECHIP_STATUS_FAILED;
}

static BridgeChip_StatusType serdes_wait_ser_fpd_linkup(int fd)
{
    int32 i = 0;

    for (i = 0; i < 50; i++)
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
            return BRIDGECHIP_STATUS_SUCCESS;
        else
            (void) usleep(10*1000);
    }
    return BRIDGECHIP_STATUS_FAILED;
}

static BridgeChip_StatusType serdes_daisy_fpd_link_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert daisy chain from FPD-Link III mode to FPD-Link IV mode.");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_deserializer_tx_fpd3(fd);
    eStatus = link_set_deserializer_gpio(fd);

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_daisy_fpd3_to_fpd4(fd));
    }

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_tx_fpd4(fd));
    }

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_daisy_gpio(fd));
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_daisy_oldi_cfg(fd));
    }

    return eStatus;
}

BridgeChip_StatusType serdes_fpd_link_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_serializer_fpd3(fd);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_gpio(fd));
    if (serdes_wait_ser_fpd_linkup(fd) != BRIDGECHIP_STATUS_SUCCESS)
        return BRIDGECHIP_STATUS_FAILED;

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));
    }
    else
    {
    }

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));
        eStatus = (BridgeChip_StatusType)(eStatus | serdes_wait_ser_fpd_linkup(fd));
    }
    else
    {
    }

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_oldi_cfg(fd));
    }
    else
    {
    }

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        serdes_daisy_fpd_link_cfg(fd);
    }
    else
    {
    }

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_vp(fd));

    return eStatus;
}

BridgeChip_StatusType serdes_des_update_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Enable 988 OLDI output for Link Chain");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_deserializer_enable_oldi(fd);

    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_daisy_enable_oldi(fd));
    }
    else
    {
    }

    #if 0
    if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
    {
        i2c_set_slave_addr(fd, MCU_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
        eStatus = (BridgeChip_StatusType)(eStatus | enable_panel_backlight(fd));
    }
    else
    {
    }
    #endif
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8_t regval = 0;
    int32_t port0_link = 0;
    static int32_t port0_link_old = 0;

    int32_t port0_llost_flag = 0;
    static int32_t port0_llost_flag_old = 0;

    write_reg(fd, 0x2D, 0x01);

    read_reg(fd, 0x0c, &regval);

    if ((((regval >> LINK_DETECT_BIT) & 0x01) == 1))
    {
        port0_link = 1;
    }
    else
    {
        port0_link = 0;
    }

    if ( (((regval>>LOCK_STS_CHG_988) & 0x01) == 1 ) //&&
            /*(((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 )*/ ) {
        port0_llost_flag = 1;
    } else {
        port0_llost_flag = 0;
    }

    if ((port0_link_old != port0_link)  || (port0_llost_flag_old != port0_llost_flag))
    {

        CRITICAL_PRINT(MODULE_NAME,
                "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x, reg: 0x0C = 0x%02x\n",
                (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01), regval);
        port0_link_old = port0_link;
        port0_llost_flag_old = port0_llost_flag;
    }

    if ((port0_link == 1) && (port0_llost_flag == 0))
        return BRIDGECHIP_STATUS_SUCCESS;
    else if ((port0_link == 1) && (port0_llost_flag == 1)) {
        ser_clear_linklost_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    } else
        return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType serdes_check_ser_vp_status(int32 fd)
{
    uint8  vp_status;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x45, &vp_status);

    if (((vp_status & 0x1) == 1)  &&  (((vp_status >> 1) & 0x01) == 1))
    {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>>>VP0 and VP1  synced");
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>>>VP not synced, VP0 = %d, VP1 = %d", vp_status & 0x01, (vp_status >> 1) & 0x01);
        return BRIDGECHIP_STATUS_FAILED;
    }
}
//used for link lost recovery init
BridgeChip_StatusType recovery_ser_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);

    CRITICAL_PRINT(MODULE_NAME, "Link setup to FPD-Link III mode");

    eStatus = link_set_serializer_fpd3(fd);

    return eStatus;
}

BridgeChip_StatusType recovery_serdes_fpd4_init(int32 fd)
{
    return serdes_fpd_link_cfg(fd);
}

void set_reset_keep_dsi(int32 val)
{
    reset_keep_dsi = val;
}

void ser_clear_linklost_flag(int32 i2c_fh)
{
    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(i2c_fh, 0x2D, 0x01);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x12);
    write_reg(i2c_fh, 0x02, 0xF0); // Clear CRC
    write_reg(i2c_fh, 0x02, 0xD0); // Clear CRC
    write_reg(i2c_fh, 0x2D, 0x01);
}
#ifdef __cplusplus
}
#endif
