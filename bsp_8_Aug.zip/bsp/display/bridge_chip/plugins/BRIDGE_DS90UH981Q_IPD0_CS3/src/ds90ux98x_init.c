#ifdef __cplusplus
extern "C"
{
#endif
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT   0x0C
#define DES_ID_7BIT   0x2C
#define MCU_ID_7BIT   0x12
#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)

// Panel Timings
#define THW               1456   // Total horizontal
#define TVW               818    // Total vertical
#define AHW               1350   // Active horizontal
#define AVW               810    // Active vertical
#define HBP               52     // Horizontal back porch
#define VBP               4      // Vertical back porch
#define HSW               20     // Horizontal sync width
#define VSW               2      // Vertical sync width
#define VFP               2      // Vertical front porch
//#define PCLK_FREQ         117.763
#define FC_FPD_FREQ       6.75
#define FPS               60

#define GENERAL_STS_MASK   0x5B
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define BIST_CRC_ERROR_BIT 3
#define BC_CRC_ERROR_BIT   1
#define LINK_DETECT_BIT    0

static int32 verbosedebug = 1;
static int32 reset_keep_dsi = 0;

#define MODULE_NAME "SER-DES INX-IPD0 CS3.0"
#define ENABLE_VP0_PATTERN 0

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "i2c_write failed 0x%x : 0x%x",  reg, val);
    }

    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        //LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
        return -1;
    }

    return 0;
}

static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

static BridgeChip_StatusType serdes_wait_des_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / 10;

    do
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(10 * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

static BridgeChip_StatusType link_set_serializer_i2c_pass_through(int32 fd)
{
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);

    CRITICAL_PRINT(MODULE_NAME," Enable I2C Pass Through");
    write_reg(fd, 0x07, 0x88);
    write_reg(fd, 0x3A, 0x88);

    CRITICAL_PRINT(MODULE_NAME, "Set i2c pass through done");

    return BRIDGECHIP_STATUS_SUCCESS;
}


#if 0
static BridgeChip_StatusType link_set_serializer_gpio(int32 fd)
{
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set 983/981 GPIOs...");
    read_reg(fd, 0x30, &RevId);
    RevId &= 0xF0;
    if (RevId >= 0x20)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd) /*Almost finished.  TODO at the end of this function*/
{
    uint8 RevId = 0;

    read_reg(fd, 0x30, &RevId);
    /* DSI config */
    CRITICAL_PRINT(MODULE_NAME, "%s: Configure DSI Port0", __func__);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x02, 0xD8);
    if ((RevId & 0xF0) >= 0x20)
    {
        write_reg(fd, 0x4F, 0x8D);
    }
    else
    {
        write_reg(fd, 0x4F, 0x8C);
    }
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x08);

    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");
    //Disable FPD3 FIFO pass through
    write_reg(fd, 0x5B, 0x23);
    //Change FPDTX FPD3_MODE_CTL
    write_reg(fd, 0x59, 0x05);

    //Force FPD4_TX DUAL MODE
    write_reg(fd, 0x05, 0x2C); // FPD_TX to Single link

    CRITICAL_PRINT(MODULE_NAME," Switch mode to FPD4 Single");

    write_reg(fd, 0x02, 0xD1);
    write_reg(fd, 0x2D, 0x01);

    //CRITICAL_PRINT(MODULE_NAME," Switch encoder from FPD3 to FPD4"
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90);

    write_reg(fd, 0x2D, 0x03);
    write_reg(fd, 0x6A, 0x0A);
    read_reg(fd, 0x30, &RevId);
    // for 983 CS2.0
//    if ((RevId & 0xF0) == 0x50)
//    {
        write_reg(fd, 0x6E, 0x80);
//    }

    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    //Configure and Enable PLLs
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0xC7);
    write_reg(fd, 0x41, 0x4E);
    write_reg(fd, 0x42, 0xC7);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME," Software reset 981");
    if (reset_keep_dsi)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);

    //todo:
    serdes_wait_des_link_stable(fd, 100);

    CRITICAL_PRINT(MODULE_NAME," Software reset 988");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 100);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    //CRITICAL_PRINT(MODULE_NAME,"983 link layer config");
    write_reg(fd, 0x40, 0x2E);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);
    CRITICAL_PRINT(MODULE_NAME,"Software reset 981 and 988 done");
    write_reg(fd, 0x2D, 0x01);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd) /*modification was done;*/
{

    uint8 n_value = 15;
    uint8 addr0, addr1;
    float fc_freq = 0;
    float src_pclk_freq = THW * TVW * FPS / 1000000.00f;;
    float m_value_f;
    uint16 m_value;

    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x32);

    // Set Stream Source to VPs
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0xA8); //SST0 for VP0

    // set timing on video processor 0
    addr0 = 0x02;
    addr1 = 0x10;
    // set dsi_h_active
    write_reg(fd, 0x41, addr0);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_active
    write_reg(fd, 0x41, addr1); // h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_back
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW));

    // set video timing generator v_active
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP));

    write_reg(fd, 0x41, 0x27);
    write_reg(fd, 0x42, 0x00); //HSYNC Polarity = +,VSYNC Polarity = +
    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //10800  bps

    //  half rate mode
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "m_value = %d",  m_value);
    // full rate mode
    // m_value = sub_pclk_freq / 4.0 * (2 ^ n_value) / (fc_freq/80)

    // set m/n value for video processor 0
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);

    //==================================================
    // TODO: ENABLE VP need be called after video afailable and after video input reset
    // Enable VPs
    // main page: set number of video streams
    write_reg(fd, 0x43, 0x00); //Set number of VPs used = 1
    write_reg(fd, 0x44, 0x01); //Enable video processors

#if 0
    CRITICAL_PRINT(MODULE_NAME, "Enable PATGEN");
    //## *********************************************
    write_reg(fd,0x40,0x30);
    write_reg(fd,0x41,0x29);
    write_reg(fd,0x42,0x08); //Set PATGEN Color Depth to 24bpp for VP0
    write_reg(fd,0x41,0x28); //
    write_reg(fd,0x42,0x95); //Enable PATGEN on VP0 - Comment out this line to disable PATGEN and enable end to end video
#endif

    // Config TX link layer

    // enable link layer stream
    // only for FPD4 mode
    // choose page 11, set auto-increment
    write_reg(fd, 0x40, 0x2E);  // Link layer register page
    write_reg(fd, 0x41, 0x01);  // Link layer stream enable
    write_reg(fd, 0x42, 0x01);  // Link layer stream enable
    write_reg(fd, 0x41, 0x06);  // Link layer time slot 0
    write_reg(fd, 0x42, 0x3C);  // Link layer time slot
    write_reg(fd, 0x41, 0x20);  // Set link layer vp bpp
    write_reg(fd, 0x42, 0x59);  // Set link layer vp bpp according to VP BPP
    write_reg(fd, 0x41, 0x00);  // Link layer enable
    write_reg(fd, 0x42, 0x03);  // Link layer enable

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_des_update_cfg(int32 fd) /*Modification was done*/
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    uint8 temp_final, rb;
    int32 temp_final_c, ramp_up_range_codes_needed, ramp_dn_range_codes_needed;
    int32 ramp_up_cap_delta, ramp_dn_cap_delta, ts_code_up, ts_code_dn, Efuse_TS_CODE;

    CRITICAL_PRINT(MODULE_NAME, ">>>>serdes_des_update_cfg");
    // Read Deserializer 0 Temp
    write_reg(fd, 0x40, 0x6C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13);
    read_reg(fd, 0x42, &temp_final);
    temp_final_c = 2 * temp_final - 273;

    // Set up Deserializer 0 Temp Ramp Optimizations
    Efuse_TS_CODE = 4;
    ramp_up_range_codes_needed = (150 - temp_final_c) / (190 / 11) + 1;
    ramp_dn_range_codes_needed = (temp_final_c - 30) / (190 / 11) + 1;
    ramp_up_cap_delta = ramp_up_range_codes_needed - 4;
    ramp_dn_cap_delta = ramp_dn_range_codes_needed - 7;

    write_reg(fd, 0x40, 0x3C);
    write_reg(fd, 0x41, 0xF5);
    write_reg(fd, 0x42, (Efuse_TS_CODE << 4) + 1); // Override TS_CODE Efuse Code
    if (ramp_up_cap_delta > 0)
    {
        ts_code_up = Efuse_TS_CODE - ramp_up_cap_delta;
        if (ts_code_up < 0)
            ts_code_up = 0;
        write_reg(fd, 0x40, 0x3c);
        write_reg(fd, 0x41, 0xf5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_up << 4);
        write_reg(fd, 0x42, (rb & 0xff));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xff));
        write_reg(fd, 0x1, 0x1);
        serdes_clear_link_crc_err_flag(fd);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }

    if (ramp_dn_cap_delta > 0)
    {
        ts_code_dn = Efuse_TS_CODE + ramp_dn_cap_delta;
        if (ts_code_dn >= 7)
            ts_code_dn = 7;
        write_reg(fd, 0x40, 0x3c);
        write_reg(fd, 0x41, 0xf5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_dn << 4);
        write_reg(fd, 0x42, (rb & 0xff));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xff));
        write_reg(fd, 0x1, 0x1);
        serdes_clear_link_crc_err_flag(fd);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }
    (void)usleep(20 * 1000);

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_enable_oldi(int32 fd) /*Modification was almost done*/
{
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Hold Des DTG in reset");
    write_reg(fd, 0x40, 0x50); //#Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02); //#Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x02); // #Hold Port 1 DTG in reset
    write_reg(fd, 0xDA, 0x00); // Override the OLDI Sync Mode

    CRITICAL_PRINT(MODULE_NAME, "Disable Stream Mapping");
    write_reg(fd, 0x0E, 0x03); //#Select both Output Ports
    write_reg(fd, 0xD0, 0x00); //#Disable FPD4 video forward to Output Port
    write_reg(fd, 0xD7, 0x00); //#Disable FPD3 video forward to Output Port

    CRITICAL_PRINT(MODULE_NAME, "Setup DTG for port 0");
    write_reg(fd, 0x40, 0x50); //#Select DTG Page
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0xA3); //#DTG detect HS active high and VS active high
    write_reg(fd, 0x41, 0x29); //#Set Hstart
    write_reg(fd, 0x42, 0x80); //#Hstart upper byte
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x48); //#Hstart lower byte
    write_reg(fd, 0x41, 0x2F); //#Set HSW
    write_reg(fd, 0x42, 0x40); //#HSW upper byte
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x14); //#HSW lower byte

    CRITICAL_PRINT(MODULE_NAME, "Map video to display output");
    write_reg(fd, 0x0E, 0x03); //#Select both Output Ports
    write_reg(fd, 0xD0, 0x0C); //#Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xD1, 0x0F); //Every stream forwarded on DC
    write_reg(fd, 0xD6, 0x00); //#Send Stream 0 to Output Port 0 and Send Stream 0 to Output Port 1
    write_reg(fd, 0xD7, 0x00); //#FPD3 mapping disabled
    write_reg(fd, 0x0E, 0x01); //#Select Port 0

    /* Port 0 8" OLDI */
    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    CRITICAL_PRINT(MODULE_NAME, "Configure 988 oLDI PLL");
    write_reg(fd, 0x40, 0x2C); //Configure OLDI/RGB Port Settings
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2F);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x0C);
    write_reg(fd, 0x40, 0x2E); //#Configure OLDI/RGB PLL
    write_reg(fd, 0x41, 0x08);
    write_reg(fd, 0x42, 0x0D); //#PLL_NUM23_16
    write_reg(fd, 0x42, 0xA7); //#PLL_NUM15_8
    write_reg(fd, 0x42, 0x40); //#PLL_NUM7_0
    write_reg(fd, 0x42, 0xFF); //#PLL_DEN23_16
    write_reg(fd, 0x42, 0xFF); //#PLL_DEN15_8
    write_reg(fd, 0x42, 0xF0); //#PLL_DEN7_0
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0x25); //#PLL_NDIV
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x11); //#TX_SEL_CLKDIV
    write_reg(fd, 0x40, 0x50); //#Configure Pixel Size
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x13);

/*new--------------------------------------------------------------------------start*/
#if 0
    //NDIV = 37
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0x25);
    //PLL MASH order set to fractional
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x38);
    write_reg(fd, 0x42, 0x20);
    //Numerator set to 894784
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x08);
    write_reg(fd, 0x42, 0x0D);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x09);
    write_reg(fd, 0x42, 0xA7);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x40);
    //Denominator set to 16777206
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0B);
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0C);
    write_reg(fd, 0x42, 0xFF);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0xF6);
    //PDIV = 2
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x01);
    //SSCG_EN Center Spread
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0xC0);
    //RAMPX_INC = 6709
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0xFB);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x0F);
    write_reg(fd, 0x42, 0x9A);
    //RAMPX_STOP = 675
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x11);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x12);
    write_reg(fd, 0x42, 0xA3);
#endif
/*new----------------------------------------------------------------------------end*/

    CRITICAL_PRINT(MODULE_NAME, "Release Des DTG reset");
    write_reg(fd, 0x40, 0x50);// #Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x00); //#Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x00);// #Release Des DTG reset

    CRITICAL_PRINT(MODULE_NAME, "Enable OLDI Output");
    write_reg(fd, 0x01, 0x40); //#OLDI Reset
    serdes_clear_link_crc_err_flag(fd);
    serdes_wait_des_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x40, 0x2C); //Enable OLDI/RGB
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x10);

    write_reg(fd, 0x41, 0x20); //P0 TX_EN (from strap?)
    write_reg(fd, 0x42, 0x80);

#if 1 /*not sure required or not*/
    write_reg(fd, 0x41, 0x22); //P1 TX_EN (from strap?)
    write_reg(fd, 0x42, 0x80);
#endif

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8 regval = 0;
    int32 port0_linked = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x0c, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;
    }

    if (port0_linked == 1)
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        serdes_clear_link_crc_err_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup: Serializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus |= link_set_serializer_i2c_pass_through(i2c_fh);
//    eStatus |= link_set_serializer_gpio(i2c_fh);
    eStatus |= link_set_serializer_fpd4(i2c_fh);
    eStatus |= link_set_serializer_vp(i2c_fh);
    serdes_clear_link_crc_err_flag(i2c_fh);
    serdes_wait_des_link_stable(i2c_fh, 100);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(i2c_fh, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Configure Deserializer");
    eStatus |= serdes_des_update_cfg(i2c_fh);
    CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer oLDI");
    eStatus |= link_set_deserializer_enable_oldi(i2c_fh);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

void set_reset_keep_dsi(int32 val)
{
    reset_keep_dsi = val;
}

#ifdef __cplusplus
}
#endif
