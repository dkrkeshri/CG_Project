
#define lower_byte(in_data) (in_data & 0xFF)
#define upper_byte(in_data) ((in_data & 0xFF00)>>8)
#define APB_CTL   0x48
#define APB_ADR0  0x49
#define APB_ADR1  0x4A
#define APB_DATA0 0x4B
#define APB_DATA1 0x4C
#define APB_DATA2 0x4D
#define APB_DATA3 0x4E

int video_crc_check (unsigned char DEVICE_ADDR, int CRC_WAIT);
int AEQ_960_VIDEO_ADJUST (unsigned char DEVICE_ADDR);
void DES_RESET_CONTROL (unsigned char DEVICE_ADDR);
int DP_DISPLY_PROGRAM (int channel, unsigned char DEVICE_ADDR) ;

static int write_reg(uint8_t addr8bit, uint8_t reg, uint8_t val)
{
    uint8_t writedata[2];
    int32_t iRetVal;
    writedata[0] = reg;
    writedata[1] = val;

    //check current address
    if((addr8bit>>1) != board.device_address7bit) {
        CRITICAL_PRINT("i2c address switch from 0x%x to 0x%x", board.device_address7bit, (addr8bit>>1));
        i2c_set_slave_addr(board.fd, (addr8bit>>1), I2C_ADDRFMT_7BIT);
        board.device_address7bit=(addr8bit>>1);
    }
    iRetVal = i2c_write(board.fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT("%s 0x%x : 0x%x", __func__, reg, val);
    }
    return  0;
}

static uint8_t read_reg(uint8_t addr8bit, uint8_t reg)
{
    uint32_t write_data[2];
    uint8_t retval;
    int32_t iRetVal=0;

    if((addr8bit>>1) != board.device_address7bit) {
        CRITICAL_PRINT("i2c address switch from 0x%x to 0x%x", board.device_address7bit, (addr8bit>>1));
        i2c_set_slave_addr(board.fd, (addr8bit>>1), I2C_ADDRFMT_7BIT);
        board.device_address7bit=(addr8bit>>1);
    }

    write_data[0] = reg;
    iRetVal = i2c_combined_writeread(board.fd, write_data, 1, &retval, 1);

    if (iRetVal != 1) {
        CRITICAL_PRINT(">>i2c_combined_writeread() FAILED, iRetVal=%d,  0x%x", iRetVal, retval);
        return -1;
    }

    return retval;
}


static uint32_t apb_read_reg(uint16_t offset, uint8_t channel,  unsigned char addr8bit)
{
    uint8_t  addr16b_lsb;
    uint8_t  addr16b_msb;
    uint8_t  wr_val;
    uint8_t  apb_data0;
    uint8_t  apb_data1;
    uint8_t  apb_data2;
    uint8_t  apb_data3;
    uint32_t apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(addr8bit, APB_ADR0, addr16b_lsb);
    write_reg(addr8bit, APB_ADR1, addr16b_msb);

    if (channel == 0) {
        wr_val = 0x03;
    } else if (channel == 1) {
        wr_val = 0x0B;
    } else {
        wr_val = 0x03;
    }

    write_reg(addr8bit, APB_CTL, wr_val);

    apb_data0=read_reg(addr8bit, APB_DATA0);
    apb_data1=read_reg(addr8bit, APB_DATA1);
    apb_data2=read_reg(addr8bit, APB_DATA2);
    apb_data3=read_reg(addr8bit, APB_DATA3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}

static int32_t apb_write_reg(uint16_t offset, uint32_t apb_data, uint8_t channel, uint8_t addr8bit)
{
    uint8_t addr16b_lsb;
    uint8_t addr16b_msb;
    uint8_t wr_val;
    uint8_t apb_data0;
    uint8_t apb_data1;
    uint8_t apb_data2;
    uint8_t apb_data3;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(addr8bit, APB_ADR0, addr16b_lsb);
    write_reg(addr8bit, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(addr8bit, APB_DATA0, apb_data0);
    write_reg(addr8bit, APB_DATA1, apb_data1);
    write_reg(addr8bit, APB_DATA2, apb_data2);
    write_reg(addr8bit, APB_DATA3, apb_data3);

    if (channel == 0) {
        wr_val = 0x01;
    } else if (channel == 1) {
        wr_val = 0x09;
    } else {
        wr_val = 0x01;
    }
    write_reg(addr8bit, APB_CTL, wr_val);

    return EXIT_SUCCESS;
}

int32_t apb_read_modifywrite(uint16_t addr16b, uint32_t mask, uint32_t write_data, uint8_t channel, uint8_t Device_ID)
{
    uint32_t read_data = apb_read_reg(addr16b, channel, Device_ID);
    uint32_t temp_wr_data = (read_data & (~mask)) | (write_data & mask);
    apb_write_reg(addr16b, temp_wr_data, channel, Device_ID);
    return 0;
}

int XOR_MARGIN_OUTPUT(unsigned char DEV_ADDR, int Wait_Time, int Port)
{
    int Value_Port;
    int Value_0_7, Value_15_8, Value_23_16, Value_29_24;

    CRITICAL_PRINT("%s", __func__);
    unsigned char REG0=0, REG1=0;
    if (Port == 0) {
        REG0 = 0x00;
        REG1 = 0x54;
    }
    else if (Port == 1) {
        REG0 = 0x80;
        REG1 = 0x58;
    }

    board.WriteI2C(DEV_ADDR,0x40,0x5C);
    board.WriteI2C(DEV_ADDR,0x41,REG0); // Channel 0
    board.WriteI2C(DEV_ADDR,0x42,0x04); // Starts XOR Counter

    board.sleep(Wait_Time);

    board.WriteI2C(DEV_ADDR,0x40,REG1); // TOCCOA 0
    board.WriteI2C(DEV_ADDR,0x41,0xFB);
    Value_0_7 = board.ReadI2C(DEV_ADDR,0x42); // Starts XOR Counter

    board.WriteI2C(DEV_ADDR,0x41,0xFC);
    Value_15_8 = board.ReadI2C(DEV_ADDR,0x42) << 8; // Starts XOR Counter
    board.WriteI2C(DEV_ADDR,0x41,0xFD);
    Value_23_16 = board.ReadI2C(DEV_ADDR,0x42) << 16; // Starts XOR Counter
    board.WriteI2C(DEV_ADDR,0x41,0xFE);
    Value_29_24 = board.ReadI2C(DEV_ADDR,0x42) << 30; // Starts XOR Counter
    Value_Port = Value_29_24 + Value_23_16 + Value_15_8 + Value_0_7;

    board.WriteI2C(DEV_ADDR,0x40,0x5C);
    board.WriteI2C(DEV_ADDR,0x41,REG0);// Channel 0
    board.WriteI2C(DEV_ADDR,0x42,0x00); // Starts XOR Counter
    return Value_Port;
}

int CHECK_ALIGNMENT (unsigned char DEV_ADR) 
{
    //print "Checking Alignment Status"
    // Override Adapted Initial DFE Value
    CRITICAL_PRINT("%s", __func__);
    unsigned char DFE_Port0, DFE_Port1;
    board.WriteI2C(DEV_ADR,0x40,0x54); // TOCCOA PAGE 0
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x40); // Snapshot selects the Tap1 Accumulator
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    DFE_Port0 = board.ReadI2C(DEV_ADR, 0x42)>>2;// [15:8] 
    board.WriteI2C(DEV_ADR,0x41,0x8F);
    board.WriteI2C(DEV_ADR,0x42,DFE_Port0);
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    board.WriteI2C(DEV_ADR,0x41,0x82);
    board.WriteI2C(DEV_ADR,0x42,0x00);
    board.WriteI2C(DEV_ADR,0x41,0x85);
    board.WriteI2C(DEV_ADR,0x42,0x00);
    board.WriteI2C(DEV_ADR,0x41,0x2A);
    board.WriteI2C(DEV_ADR,0x42,0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    //Channel 1
    // Override Adapted Initial DFE Value
    board.WriteI2C(DEV_ADR,0x40,0x58); // TOCCOA PAGE 1
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x40); // Snapshot selects the Tap1 Accumulator
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    DFE_Port1 = board.ReadI2C(DEV_ADR, 0x42)>>2; // [15:8] 

    board.WriteI2C(DEV_ADR,0x41,0x8F);
    board.WriteI2C(DEV_ADR,0x42,DFE_Port1); 
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    board.WriteI2C(DEV_ADR,0x41,0x82);
    board.WriteI2C(DEV_ADR,0x42,0);
    board.WriteI2C(DEV_ADR,0x41,0x85);
    board.WriteI2C(DEV_ADR,0x42,0);
    board.WriteI2C(DEV_ADR,0x41,0x2A);
    board.WriteI2C(DEV_ADR,0x42,0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    int Value_0 = XOR_MARGIN_OUTPUT(DEV_ADR, 0, 0);
    int Value_1 = XOR_MARGIN_OUTPUT(DEV_ADR, 0, 1);
    CRITICAL_PRINT ("Port0 Alignment (0-Aligned): 0x%x  Port1 XOR: 0x%x", (Value_0), (Value_1));

    board.WriteI2C(DEV_ADR,0x40,0x54); // TOCCOA PAGE 0
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    board.WriteI2C(DEV_ADR,0x41,0x2A);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"
    board.WriteI2C(DEV_ADR,0x40,0x58); // TOCCOA PAGE 1
    board.WriteI2C(DEV_ADR,0x41,0x1C);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    board.WriteI2C(DEV_ADR,0x41,0x2A);
    board.WriteI2C(DEV_ADR,0x42,0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"        
    return 0;
}



int DFE_TAP1_SNAPSHOT (unsigned char DEV_ADR, int DES_NUM)
{
    CRITICAL_PRINT("%s", __func__);
    unsigned char Value_MSB, Value_Final, MSB_ON;
    board.WriteI2C(DEV_ADR,0x40,0x54); // TOCCOA PAGE 0
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x40); // Snapshot selects the Tap1 Accumulator
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]

    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 TAP1 ACC: Final Value = %d, Initial Value: 0x%x   on DES: %d", Value_Final, ((0x16>>2) & 0x3F), DES_NUM);
    else
        CRITICAL_PRINT("Port0 TAP1 ACC: Final Value = %d, Initial Value: 0x%x   on DES: %d", (Value_Final-64), ((0x16>>2) & 0x3F), DES_NUM);

    board.WriteI2C(DEV_ADR,0x40,0x58); // TOCCOA PAGE 0
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x40); // Snapshot selects the Tap1 Accumulator
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]
    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 TAP1 ACC: Final Value = %d, Initial Value: 0x%x   on DES: %d", Value_Final, ((0x16>>2) & 0x3F), DES_NUM);
    else
        CRITICAL_PRINT("Port0 TAP1 ACC: Final Value = %d, Initial Value: 0x%x   on DES: %d", (Value_Final-64), ((0x16>>2) & 0x3F), DES_NUM);

    return 0;
}

int DFE_REF0_SNAPSHOT (unsigned char DEV_ADR, int DES_NUM)
{
    CRITICAL_PRINT("%s", __func__);
    unsigned char Value_MSB, Value_LSB, Value_Final, MSB_ON;
    board.WriteI2C(DEV_ADR,0x40,0x54);
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x00); // Snapshot selects the ref_adapt0
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]
    board.WriteI2C(DEV_ADR,0x41,0xF2);
    Value_LSB = board.ReadI2C(DEV_ADR, 0x42); // [7:0]
    (void)Value_LSB;
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 Ref0: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), Value_Final, DES_NUM);
    else
        CRITICAL_PRINT("Port0 Ref0: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final - 128), DES_NUM);

    board.WriteI2C(DEV_ADR,0x40,0x58);
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x00); // Snapshot selects the ref_adapt0
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]
    board.WriteI2C(DEV_ADR,0x41,0xF2);
    Value_LSB = board.ReadI2C(DEV_ADR, 0x42); // [7:0]
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 Ref0: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), Value_Final, DES_NUM);
    else
        CRITICAL_PRINT("Port0 Ref0: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final - 128), DES_NUM);

    return 0;
}

int DFE_REF1_SNAPSHOT (unsigned char DEV_ADR, int DES_NUM)
{
    unsigned char Value_MSB, Value_LSB, Value_Final, MSB_ON;
    board.WriteI2C(DEV_ADR,0x40,0x54);
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x20); // Snapshot selects the ref_adapt0
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]
    board.WriteI2C(DEV_ADR,0x41,0xF2);
    Value_LSB = board.ReadI2C(DEV_ADR, 0x42); // [7:0]
    (void)Value_LSB;
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 Ref1: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final), DES_NUM);
    else
        CRITICAL_PRINT("Port0 Ref1: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final - 128), DES_NUM);

    board.WriteI2C(DEV_ADR,0x40,0x58);
    board.WriteI2C(DEV_ADR,0x41,0x51);
    board.WriteI2C(DEV_ADR,0x42,0x20); // Snapshot selects the ref_adapt0
    board.WriteI2C(DEV_ADR,0x41,0x13);
    board.WriteI2C(DEV_ADR,0x42,0x08); // Capture the data
    board.WriteI2C(DEV_ADR,0x41,0xF1);
    Value_MSB = board.ReadI2C(DEV_ADR, 0x42); // [15:8]
    board.WriteI2C(DEV_ADR,0x41,0xF2);
    Value_LSB = board.ReadI2C(DEV_ADR, 0x42); // [7:0]
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    if (MSB_ON == 0)
        CRITICAL_PRINT("Port0 Ref1: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final), DES_NUM);
    else
        CRITICAL_PRINT("Port0 Ref1: Initial: = %d, Value_Final: 0x%x   on DES: %d", (0x68-128), (Value_Final - 128), DES_NUM);

    return 0;
}

int VIDEO_LINK_LAYER_SETUP (unsigned char DEV_ADDR, int bits_per_color, int DES_HOP)
{
    CRITICAL_PRINT("Enabling DES_ %d Video to Stream_0", DES_HOP);
    board.WriteI2C(DEV_ADDR,0x0E,0x03); //Set TX Port select
    board.WriteI2C(DEV_ADDR,0xD0,0x0C); //FPD_RX to DP Port 0 and Port 1 enable
    board.WriteI2C(DEV_ADDR,0xD1,0x00); //Every stream forwarded on DC
    board.WriteI2C(DEV_ADDR,0xD6,0x00); //Send Stream ID0 to DP Port 0 and and Send Stream ID1 Port 1
    board.WriteI2C(DEV_ADDR,0xD7,0x00);           
    board.WriteI2C(DEV_ADDR,0x0E,0x01); //Set TX Port select

    return 0;
}

int Measure_Video (unsigned char DEVICE_ADDR, int Port)
{
    unsigned char Offset, DTG_Status;
    unsigned int htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;
    int i = 0;
    if (Port == 0)
    {
        Offset = 0;
    }
    else
    {
        Offset = 0x30;
    }
    //DTG Status
    board.WriteI2C(DEVICE_ADDR,0x40,15*4);
    board.WriteI2C(DEVICE_ADDR,0x41,0x00);
    board.WriteI2C(DEVICE_ADDR,0x42,0x80);
    board.WriteI2C(DEVICE_ADDR,0x41,0x01);
    board.WriteI2C(DEVICE_ADDR,0x42,0x31); //Display 0
    board.WriteI2C(DEVICE_ADDR,0x41,0x02);
    board.WriteI2C(DEVICE_ADDR,0x42,0x80);
    board.WriteI2C(DEVICE_ADDR,0x41,0x03);

    DTG_Status = board.ReadI2C(DEVICE_ADDR,0x42);
    CRITICAL_PRINT("DTG_STATUS DISP_0: 0x%x", DTG_Status);
    //#{early_de, vid_de_dtg, vid_hsync_dtg, vid_vsync_dtg, meas_done, 1'b0, rx_hsync, rx_vsync}
    board.WriteI2C(DEVICE_ADDR,0x41,0x01);
    board.WriteI2C(DEVICE_ADDR,0x42,0x32); //Display 1
    board.WriteI2C(DEVICE_ADDR,0x41,0x03);
    DTG_Status = board.ReadI2C(DEVICE_ADDR,0x42);
    CRITICAL_PRINT("DTG_STATUS DISP_1: 0x%x", DTG_Status);

    board.WriteI2C(DEVICE_ADDR,0x41,0x01);
    board.WriteI2C(DEVICE_ADDR,0x42,0x00);
    board.WriteI2C(DEVICE_ADDR,0x41,0x02);
    board.WriteI2C(DEVICE_ADDR,0x42,0x00); // Zero-Out the MUX

    do {
        i++;
        sleep(0.1);
        board.WriteI2C(DEVICE_ADDR,0x40,81);

        board.WriteI2C(DEVICE_ADDR,0x41,0x40 + Offset);
        htotal = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x41 + Offset);
        htotal = htotal + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x42 + Offset);
        vtotal = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x43 + Offset);
        vtotal = vtotal + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x44 + Offset);
        hres = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x45 + Offset);
        hres = hres + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x46 + Offset);
        vres = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x47 + Offset);
        vres = vres + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x48 + Offset);
        hstart = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x49 + Offset);
        hstart = hstart + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x4a + Offset);
        vstart = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x4b + Offset);
        vstart = vstart + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x4c + Offset);
        hswidth = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x4d + Offset);
        hswidth = hswidth + board.ReadI2C(DEVICE_ADDR,0x42);

        board.WriteI2C(DEVICE_ADDR,0x41,0x4e + Offset);
        vswidth = board.ReadI2C(DEVICE_ADDR,0x42)* 256;
        board.WriteI2C(DEVICE_ADDR,0x41,0x4f + Offset);
        vswidth = vswidth + board.ReadI2C(DEVICE_ADDR,0x42);


        
    } while ((vtotal < (TVW -10)) || (vtotal > (TVW + 10)));

    CRITICAL_PRINT("port :%d", Port);
    CRITICAL_PRINT("htotal :%d", htotal);
    CRITICAL_PRINT("vtotal :%d", vtotal);
    CRITICAL_PRINT("hres :%d", hres);
    CRITICAL_PRINT("vres :%d", vres);
    CRITICAL_PRINT("hstart :%d", hstart);
    CRITICAL_PRINT("vstart :%d", vstart);
    CRITICAL_PRINT("hswidth :%d", hswidth);
    CRITICAL_PRINT("vswidth :%d", vswidth);

    return htotal;
}

#define lower_byte_QCLK(in_data) (in_data & 0xFF)
//out_data= (in_data & 0xFF)
//return out_data    
#define upper_byte_QCLK(in_data) ((in_data & 0xFF0000)>>16)
//out_data=  (in_data & 0xFF0000)>>16
//return out_data
#define middle_byte_QCLK(in_data) ((in_data & 0xFF00)>>8)
//out_data=  (in_data & 0xFF00)>>8
//return out_data           
#define lower_byte_DTG(in_data) (in_data & 0xFF)
//out_data= (in_data & 0xFF)
//return out_data    
#define upper_byte_DTG(in_data) ((in_data & 0xFF00)>>8)
//out_data=  (in_data & 0xFF00)>>8
//return out_data           



int DP_VIDEO_SETUP (unsigned char DEV_ADDR, int Force_DP_Rate, int DP_FORCE_RATE, int DP0_ON, int DP1_ON, int DES_HOP, int LINK_SPEED)
{
    // DEV_ADDR = Phy Address
    // Force_DP_Rate = 0 or 1
    // DP_FORCE_RATE = One of the below frequencies
    // DES_HOP = Which DES, 1:DES_1, 2:DES_2, 3:DES_3, 4: DES_4
    // LINK_SPEED = 10.8, 13.5, 6.75
    if (Force_DP_Rate == 1) {
        //print "Forcing DP Fixed Rate of On DES: ",DES_HOP, " Link-Rate: ", DP_FORCE_RATE
        CRITICAL_PRINT("Forcing DP Fixed Rate of On DES: %d  Link-Rate: %d", DES_HOP, DP_FORCE_RATE);
        //Override link rate
        //Link rate Addr data
        //2.7 Gbps 0x81 8'b0110_0000
        //5.4 Gbps 0x81 8'b1100_0000
        //8.1 Gbps 0x81 8'b1110_0000
        //1.62 Gbps 0x81 8'b0000_0000
        //2.16 Gbps 0x81 8'b0010_0000
        //2.43 Gbps 0x81 8'b0100_0000
        //3.24 Gbps 0x81 8'b1000_0000
        //4.32 Gbps 0x81 8'b1010_0000
        if (DP_FORCE_RATE == 1620)
            DP_FORCE_RATE = 0x00;
        else if (DP_FORCE_RATE == 2160)
            DP_FORCE_RATE = 0x20;
        else if (DP_FORCE_RATE == 2430)
            DP_FORCE_RATE = 0x40;
        else if (DP_FORCE_RATE == 2700)
            DP_FORCE_RATE = 0x60;
        else if (DP_FORCE_RATE == 3240)
            DP_FORCE_RATE = 0x80;
        else if (DP_FORCE_RATE == 4320)
            DP_FORCE_RATE = 0xA0;
        else if (DP_FORCE_RATE == 5400)
            DP_FORCE_RATE = 0xC0;
        else if (DP_FORCE_RATE == 8100)
            DP_FORCE_RATE = 0xE0;

        //Override to Rate
        board.WriteI2C(DEV_ADDR,0x40,0x2C);
        board.WriteI2C(DEV_ADDR,0x41,0x81);
        board.WriteI2C(DEV_ADDR,0x42,DP_FORCE_RATE);
        // Force Rate
        board.WriteI2C(DEV_ADDR,0x41,0x82);
        board.WriteI2C(DEV_ADDR,0x42,0x02);
    }
    if ((DP0_ON == 1) && (DP1_ON == 0)) {
        CRITICAL_PRINT("DP_PORT 0 SELECTED ONLY on DES_%d", DES_HOP);
        //## Select DP Port 1
        board.WriteI2C(DEV_ADDR,0x0E,0x12);
        //## Disable DP port 1
        board.WriteI2C(DEV_ADDR,0x46,0x00);
        board.WriteI2C(DEV_ADDR,0x0E,0x01);

        CRITICAL_PRINT("Port 0: Apply DTG Reset on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x40,80);
        board.WriteI2C(DEV_ADDR,0x41,0x32+0x00);
        board.WriteI2C(DEV_ADDR,0x42,0x02);

        CRITICAL_PRINT("DP-TX-PLL RESET Applied/Required on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x01,0x40);
        board.sleep(0.1); //wait for remote programming
    }
    else if ((DP0_ON == 0) && (DP1_ON == 1)) {
        CRITICAL_PRINT("DP_PORT 1 SELECTED ONLY on DES_%d", DES_HOP);
        //## Select DP Port 0
        board.WriteI2C(DEV_ADDR,0x0E,0x01);
        //## Disable DP Port 0
        board.WriteI2C(DEV_ADDR,0x46,0x00);

        CRITICAL_PRINT("Port 1: Apply DTG Reset on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x40,80);
        board.WriteI2C(DEV_ADDR,0x41,0x32+0x30);
        board.WriteI2C(DEV_ADDR,0x42,0x02);

        CRITICAL_PRINT("DP-TX-PLL RESET Applied/Required on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x01,0x40);
        board.sleep(0.1); //wait for remote programming
    }
    else if ((DP0_ON == 0) && (DP1_ON == 0)) {
        board.WriteI2C(DEV_ADDR,0x0E,0x12);
        board.WriteI2C(DEV_ADDR,0x46,0x00);
        board.WriteI2C(DEV_ADDR,0x0E,0x01);
        board.WriteI2C(DEV_ADDR,0x46,0x00);
    }
    else {
        CRITICAL_PRINT( "Port 0: Apply DTG Reset on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x40,80);
        board.WriteI2C(DEV_ADDR,0x41,0x32+0x00);
        board.WriteI2C(DEV_ADDR,0x42,0x02);
        CRITICAL_PRINT( "Port 1: Apply DTG Reset on DES_%d", DES_HOP);
        board.WriteI2C(DEV_ADDR,0x40,80);
        board.WriteI2C(DEV_ADDR,0x41,0x32+0x30);
        board.WriteI2C(DEV_ADDR,0x42,0x02);
    }

    CRITICAL_PRINT("VIDEO PARAMETERS On DES_:%d SET:", DES_HOP);
    CRITICAL_PRINT("FPD-Link Rate = %.2f GHz", LINK_SPEED);
    CRITICAL_PRINT("PCLK = %f MHz", PCLK_FREQ);

    CRITICAL_PRINT("THW = %d", THW);
    CRITICAL_PRINT("TVW = %d", TVW);
    CRITICAL_PRINT("AHW = %d", AHW);
    CRITICAL_PRINT("AVW = %d", AVW);
    CRITICAL_PRINT("HBP = %d", HBP);
    CRITICAL_PRINT("VBP = %d", VBP);
    CRITICAL_PRINT("HSW = %d", HSW);
    CRITICAL_PRINT("VSW = %d", VSW);

    CRITICAL_PRINT("DP-TX DES_%d  VIDEO RESOLUTION: %s Configuration for DISPLAY", DES_HOP, VIDEO_RESOLUTION);
    int DP_Rate = 0;
    // Detect DP_Rate (Not Port Dependent)
    board.WriteI2C(DEV_ADDR,0x40,0x3C); // Select DFT Page
    //## Enable debug mux
    board.WriteI2C(DEV_ADDR,0x41,0x00);
    board.WriteI2C(DEV_ADDR,0x42,0x80);
    //## Select DP master SM
    board.WriteI2C(DEV_ADDR,0x41,0x01);
    board.WriteI2C(DEV_ADDR,0x42,0x0C);
    //## Select DP master SM vector sel
    board.WriteI2C(DEV_ADDR,0x41,0x02);
    board.WriteI2C(DEV_ADDR,0x42,0x01);
    board.WriteI2C(DEV_ADDR,0x41,0x03);
    unsigned char DP_Status = board.ReadI2C(DEV_ADDR,0x42);

    DP_Rate = DP_Status & 0x07; /* range0~7 */
    if (DP_Rate == 0)
        DP_Rate = 1620; // MHz
    else if (DP_Rate == 1)
        DP_Rate = 2160; // MHz
    else if (DP_Rate == 2)
        DP_Rate = 2160; // MHz
    else if (DP_Rate == 3)
        DP_Rate = 2700; // MHz
    else if (DP_Rate == 4)
        DP_Rate = 3240; // MHz
    else if (DP_Rate == 5)
        DP_Rate = 4320; // MHz
    else if (DP_Rate == 6)
        DP_Rate = 5400; // MHz
    else if (DP_Rate == 7)
        DP_Rate = 8100; // MHz
    /*else {
        DP_Rate = 0;
        CRITICAL_PRINT("No DP_RATE Found on DES_%d", DES_HOP);
    }*/

    CRITICAL_PRINT("DP-Rate Detected on Panel: %d MHz On DES: %d",DP_Rate, DES_HOP);

    dp_rate = DP_Rate;
    //pixel clock of video format in MHz
    unsigned int video_clk_freq = (PCLK_FREQ*1000);   //  148500 // in kHz
    unsigned int dp_tx_rate = DP_Rate; // example case
    dp_mvalue = (video_clk_freq);
    dp_nvalue = dp_tx_rate * 400;
    CRITICAL_PRINT("dp_mvalue %d, dp_nvalue %d", dp_mvalue, dp_nvalue);

    return DP_Rate;
}

int VIDEO_CRC_CHECK_LOOP (unsigned char DEV_ADDR, int Enable_CRC_CHECK, int DISPLAY_Port0_En, int DISPLAY_Port1_En, int DES, int DEVICE_TYPE)
{
    int num_try;
    unsigned char Line_LSB,Line_MSB, Val, LOCK_0, DECODE_ERR_0, LOCK_1, DECODE_ERR_1, AEQ_0, AEQ_1;
    int Line;
    if (Enable_CRC_CHECK == 1) {
        for (num_try=0; num_try<Loop_RESET; num_try++) {
            board.WriteI2C(DEV_ADDR,0x40,0x48); // RX Link Layer
            board.WriteI2C(DEV_ADDR,0x41,0x39); 
            Line_LSB = board.ReadI2C(DEV_ADDR,0x42); 
            board.WriteI2C(DEV_ADDR,0x41,0x3A); 
            Line_MSB = board.ReadI2C(DEV_ADDR,0x42);
            Line = (Line_MSB << 8) + Line_LSB;

            board.WriteI2C(DEV_ADDR,0x0E,0x01);
            //Val = board.ReadI2C(DEV_ADDR,0x53);
            //board.sleep(0.1);
            //Val = board.ReadI2C(DEV_ADDR,0x53);
            //board.sleep(0.1);
            Val = 0;
            Val = board.ReadI2C(DEV_ADDR,0x53);
            //print "Lock Status: ", hex(Val);
            LOCK_0 = Val & 0x01;
            DECODE_ERR_0 = (Val >> 7) & 0x1;

            board.WriteI2C(DEV_ADDR,0x0E,0x12);
            //Val = board.ReadI2C(DEV_ADDR,0x53);
            //board.sleep(0.1);
            //Val = board.ReadI2C(DEV_ADDR,0x53);
            //board.sleep(0.1);
            Val = 0;
            Val = board.ReadI2C(DEV_ADDR,0x53);
            //print "Lock Status: ", hex(Val)
            LOCK_1 = Val & 0x01;
            DECODE_ERR_1 = (Val >> 7) & 0x1;

            board.WriteI2C(DEV_ADDR,0x40,0x54); // SELECT TOCCOA0 PAGE
            board.WriteI2C(DEV_ADDR,0x41,0xFF);
            AEQ_0 = board.ReadI2C(DEV_ADDR,0x42);
            board.WriteI2C(DEV_ADDR,0x40,0x58); // SELECT TOCCOA1 PAGE
            board.WriteI2C(DEV_ADDR,0x41,0xFF);
            AEQ_1 = board.ReadI2C(DEV_ADDR,0x42);

            if ((Line > 0) & (LOCK_0 !=0) & (LOCK_1 !=0) & (DECODE_ERR_0 !=1) & (DECODE_ERR_1 !=1) ) {

                CRITICAL_PRINT("Valid Video Line %d Detected on DES %d", Line, DES);
                CRITICAL_PRINT("Line:%d Lock_0:%d  Lock_1: %d  DECODE_ERR_0:%d  DECODE_ERR_1:%d  EQ_0:%d  EQ_1:%d", Line, LOCK_0,LOCK_1, DECODE_ERR_0, DECODE_ERR_1, AEQ_0, AEQ_1);

                int Errors = video_crc_check(DEV_ADDR, CRC_WAIT);

                CRITICAL_PRINT("*****DES %d VIDEO CRC Errors: 0x%x", DES, Errors);
                if (Errors == 0) {
                    board.WriteI2C(DEV_ADDR,0x0E,0x01);
                    unsigned char Value = board.ReadI2C(DEV_ADDR,0x00);
                    if (Value != 0) {

                        return 1;
                        break;
                    }
                    else {
                        CRITICAL_PRINT("LOST I2C Transaction on DES %d", DES);
                        return 0;
                    }
                } else {
                    DES_RESET_CONTROL (DEV_ADDR);
                    int New_Errors = AEQ_960_VIDEO_ADJUST (DEV_ADDR);
                    board.sleep(0.1);
                    VIDEO_LINK_LAYER_SETUP (DEV_ADDR, bits_per_color, DES);
                    if ((num_try == (Loop_RESET-1)) && (New_Errors != 0))
                        return 0;
                    else if (New_Errors == 0)
                        return 1;

                }
            }
            else if ((Line <=0) || (DECODE_ERR_0 ==1) || (DECODE_ERR_1 ==1) ){

                CRITICAL_PRINT(">>>>>No Valid Video or Decode Errors on DES %d", DES  );
                CRITICAL_PRINT(">>>>>Line:%d Lock_0:%d  Lock_1: %d  DECODE_ERR_0:%d  DECODE_ERR_1:%d  EQ_0:%d  EQ_1:%d", Line, LOCK_0,LOCK_1, DECODE_ERR_0, DECODE_ERR_1, AEQ_0, AEQ_1);
                // DES_RESET_CONTROL (DEV_ADDR)
                // board.sleep(3)
                // VIDEO_LINK_LAYER_SETUP (DEV_ADDR, bits_per_color, DES)
                // Errors = video_crc_check(DEV_ADDR, CRC_WAIT)

                return 1;
            }
        }

    } else {
        return 1;
    }

    return 0;
}

int  DTG_RESET_TOGGLE(unsigned char DEV_ADDR)
{
    CRITICAL_PRINT("DTG RESET TOGGLE APPLIED");
    board.WriteI2C(DEV_ADDR,0x40,80);
    board.WriteI2C(DEV_ADDR,0x41,0x32+0);
    board.WriteI2C(DEV_ADDR,0x42,0x06);
    board.WriteI2C(DEV_ADDR,0x41,0x32+0x30);
    board.WriteI2C(DEV_ADDR,0x42,0x06);
    board.WriteI2C(DEV_ADDR,0x40,80);
    board.WriteI2C(DEV_ADDR,0x41,0x32+0);
    board.WriteI2C(DEV_ADDR,0x42,0x04);
    board.WriteI2C(DEV_ADDR,0x41,0x32+0x30);
    board.WriteI2C(DEV_ADDR,0x42,0x04);
    return 0;
}

int ENABLE_DISPLAY (unsigned char DEV_ADDR, int DISPLAY_Port0_En, int DISPLAY_Port1_En, int DES, int DEVICE_TYPE, int DTG_TOGGLE)
{
    int htotal = 0;
    if (DISPLAY_Port0_En ==1)
    {

        if (DEVICE_TYPE == 984)
        {
            DP_DISPLY_PROGRAM (0,DEV_ADDR);
            board.sleep(0.1);

            if (DTG_TOGGLE == 1)
                DTG_RESET_TOGGLE(DEV_ADDR);
            htotal = Measure_Video (DEV_ADDR, 0);
        }
    }
    if (DISPLAY_Port1_En ==1)
    {

        if (DEVICE_TYPE == 984) {
            DP_DISPLY_PROGRAM (1,DEV_ADDR);
            board.sleep(0.1);

            if (DTG_TOGGLE == 1)
                DTG_RESET_TOGGLE(DEV_ADDR);
            htotal = Measure_Video (DEV_ADDR, 1);
        }
    }
    return htotal;
}

int video_crc_check (unsigned char DEVICE_ADDR, int CRC_WAIT)
{

    int Line, Errors;
    unsigned char Line_LSB, Line_MSB;

    board.WriteI2C(DEVICE_ADDR,0x40,0x48); // RX Link Layer
    board.WriteI2C(DEVICE_ADDR,0x41,0x29); 
    board.WriteI2C(DEVICE_ADDR,0x42,0x00); //# Reg_Update_En; CLEAR ONLY
    board.WriteI2C(DEVICE_ADDR,0x41,0x2A); 
    board.WriteI2C(DEVICE_ADDR,0x42,0xF); //# CLEAR ERROR COUTNER ENABLE
    board.WriteI2C(DEVICE_ADDR,0x41,0x29); 
    board.WriteI2C(DEVICE_ADDR,0x42,0x40); //# Reg_Update_En; CLEAR ONLY
    board.WriteI2C(DEVICE_ADDR,0x41,0x29); 
    board.WriteI2C(DEVICE_ADDR,0x42,0x00); //# BACK TO 0

    board.WriteI2C(DEVICE_ADDR,0x41,0x2A); 
    board.WriteI2C(DEVICE_ADDR,0x42,0x00); //# CLEAR ERROR COUTNER DISABLE
    board.WriteI2C(DEVICE_ADDR,0x41,0x29);
    board.WriteI2C(DEVICE_ADDR,0x42,0x4f); //# CAPTURE

    board.WriteI2C(DEVICE_ADDR,0x41,0x39);
    Line_LSB = board.ReadI2C(DEVICE_ADDR,0x42);
    board.WriteI2C(DEVICE_ADDR,0x41,0x3A);
    Line_MSB = board.ReadI2C(DEVICE_ADDR,0x42);
    Line = (Line_MSB << 8) + Line_LSB;

    if (Line !=0)
    {
        unsigned short Value = 0;
        board.WriteI2C(DEVICE_ADDR,0x41,0x34);
        unsigned short CRC_BYTE_LSB = board.ReadI2C(DEVICE_ADDR,0x42);
        board.WriteI2C(DEVICE_ADDR,0x41,0x35);
        unsigned short CRC_BYTE_Init = (board.ReadI2C(DEVICE_ADDR,0x42) << 8) + CRC_BYTE_LSB; //# Store initial errors
        board.sleep (CRC_WAIT);

        board.WriteI2C(DEVICE_ADDR,0x40,0x48); //# RX Link Layer
        board.WriteI2C(DEVICE_ADDR,0x41,0x2A);
        board.WriteI2C(DEVICE_ADDR,0x42,0xF); //# CLEAR ERROR COUTNER ENABLE
        board.WriteI2C(DEVICE_ADDR,0x41,0x29);
        board.WriteI2C(DEVICE_ADDR,0x42,0x40); //# Reg_Update_En; CLEAR ONLY
        board.WriteI2C(DEVICE_ADDR,0x41,0x29);
        board.WriteI2C(DEVICE_ADDR,0x42,0x00); //# BACK TO 0
        board.WriteI2C(DEVICE_ADDR,0x41,0x2A);
        board.WriteI2C(DEVICE_ADDR,0x42,0x00); //# CLEAR ERROR COUTNER DISABLE
        board.WriteI2C(DEVICE_ADDR,0x41,0x29);
        board.WriteI2C(DEVICE_ADDR,0x42,0x4f); //# CAPTURE
        board.WriteI2C(DEVICE_ADDR,0x41,0x29);
        board.WriteI2C(DEVICE_ADDR,0x42,0xf); //# REG_UPDATE_EN BACK TO 0
        board.WriteI2C(DEVICE_ADDR,0x41,0x29);
        board.WriteI2C(DEVICE_ADDR,0x42,0x4f); //# CAPTURE; ONE MORE TIME

        //# board.WriteI2C(DEVICE_ADDR,0x40,0x48) # RX Link Layer
        //# board.WriteI2C(DEVICE_ADDR,0x41,0x29)
        //# board.WriteI2C(DEVICE_ADDR,0x42,0x3F) # [6]:Reg_Update_En; [5:0]: reg_cnt_capture

        board.WriteI2C(DEVICE_ADDR,0x41,0x34);
        CRC_BYTE_LSB = board.ReadI2C(DEVICE_ADDR,0x42);
        board.WriteI2C(DEVICE_ADDR,0x41,0x35);
        Value = ((board.ReadI2C(DEVICE_ADDR,0x42) << 8) + CRC_BYTE_LSB);
        Errors = Value - CRC_BYTE_Init;
        DEVICE_ADDR = 0x00;
        CRC_WAIT = 0;
        return Errors;
    }
    else
    {
        DEVICE_ADDR = 0x00;
        CRC_WAIT = 0;
        Errors = 0xFFFF;
        return Errors;
    }
}

void DES_RESET_CONTROL (unsigned char DEVICE_ADDR)
{

    board.WriteI2C(DEVICE_ADDR,0x01,0x01);
    board.sleep(0.5);
}

int AEQ_960_VIDEO_ADJUST (unsigned char DEVICE_ADDR)
{
    int Errors = -1;
    board.WriteI2C(DEVICE_ADDR,0x40,0x54); //# SELECT TOCCOA0 PAGE
    board.WriteI2C(DEVICE_ADDR,0x41,0xFF);
    unsigned char STORE_CTLE_0 = board.ReadI2C(DEVICE_ADDR,0x42);
    board.WriteI2C(DEVICE_ADDR,0x40,0x58); //# SELECT TOCCOA0 PAGE
    board.WriteI2C(DEVICE_ADDR,0x41,0xFF);
    unsigned char STORE_CTLE_1 = board.ReadI2C(DEVICE_ADDR,0x42);                            
    CRITICAL_PRINT ("CTLE0:0x%x CTLE1: 0x%x", STORE_CTLE_0, STORE_CTLE_1);

    unsigned char STORE_Init_0 = STORE_CTLE_0;
    unsigned char STORE_Init_1 = STORE_CTLE_1;
    unsigned char CTLE_MAX_OFFSET = 4;
    unsigned char Jump_Step = 1;
    unsigned char Wait_Time = 1;
    unsigned char Method = 0;
    (void) Method;

    while ((STORE_CTLE_1 >= (STORE_Init_1 -CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 >= (STORE_Init_0 -CTLE_MAX_OFFSET)))
    {
        STORE_CTLE_1 = STORE_CTLE_1 - Jump_Step;
        CRITICAL_PRINT ("Setting EQ Port1 to :0x%x", STORE_CTLE_1);
        board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
        board.WriteI2C(DEVICE_ADDR,0x41,0x23+0x30);
        board.WriteI2C(DEVICE_ADDR,0x42,STORE_CTLE_1); //# SET AEQ_MIN
        Errors = video_crc_check (DEVICE_ADDR, CRC_WAIT);
        if (Errors == 0){
            CRITICAL_PRINT ("*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT ("VIDEO CRC ERRORS: %d", Errors);
        }
        STORE_CTLE_0 = STORE_CTLE_0 - Jump_Step;
        CRITICAL_PRINT ("Setting EQ Port0 to :0x%x", STORE_CTLE_0);
        board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
        board.WriteI2C(DEVICE_ADDR,0x41,0x23);
        board.WriteI2C(DEVICE_ADDR,0x42,STORE_CTLE_0); //# SET AEQ_MIN
        board.sleep(Wait_Time);
        Errors = video_crc_check (DEVICE_ADDR, CRC_WAIT);
        if (Errors == 0){
            CRITICAL_PRINT ("*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT ("VIDEO CRC ERRORS: %d", Errors);
        }
    }

    board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
    board.WriteI2C(DEVICE_ADDR,0x41,0x23);
    board.WriteI2C(DEVICE_ADDR,0x42,STORE_Init_0); //# SET AEQ_MIN
    board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
    board.WriteI2C(DEVICE_ADDR,0x41,0x23+0x30);
    board.WriteI2C(DEVICE_ADDR,0x42,STORE_Init_1); //# SET AEQ_MIN

    while ((STORE_CTLE_1 <= (STORE_Init_1 +CTLE_MAX_OFFSET)) &&  (STORE_CTLE_0 <= (STORE_Init_0 +CTLE_MAX_OFFSET)))
    {
        STORE_CTLE_1 = STORE_CTLE_1 + Jump_Step;
        CRITICAL_PRINT ("Setting EQ Port1 to :0x%x", STORE_CTLE_1);
        board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
        board.WriteI2C(DEVICE_ADDR,0x41,0x23+0x30);
        board.WriteI2C(DEVICE_ADDR,0x42,STORE_CTLE_1); //# SET AEQ_MIN
        Errors = video_crc_check (DEVICE_ADDR, CRC_WAIT);
        if (Errors == 0){
            CRITICAL_PRINT ("*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT ("VIDEO CRC ERRORS: %d", Errors);
        }
        STORE_CTLE_0 = STORE_CTLE_0 + Jump_Step;
        CRITICAL_PRINT ("Setting EQ Port0 to :0x%x", STORE_CTLE_0);
        board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
        board.WriteI2C(DEVICE_ADDR,0x41,0x23);
        board.WriteI2C(DEVICE_ADDR,0x42,STORE_CTLE_0); //# SET AEQ_MIN
        board.sleep(Wait_Time);
        Errors = video_crc_check (DEVICE_ADDR, CRC_WAIT);
        if (Errors == 0){
            CRITICAL_PRINT ("*****DES VIDEO CRC Errors: %d", Errors);
            return Errors;
        } else {
            CRITICAL_PRINT ("VIDEO CRC ERRORS: %d", Errors);
        }
    }
    board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
    board.WriteI2C(DEVICE_ADDR,0x41,0x23);
    board.WriteI2C(DEVICE_ADDR,0x42,STORE_Init_0); //# SET AEQ_MIN
    board.WriteI2C(DEVICE_ADDR,0x40,0x38); //#AEQ_SNS Page
    board.WriteI2C(DEVICE_ADDR,0x41,0x23+0x30);
    board.WriteI2C(DEVICE_ADDR,0x42,STORE_Init_1); //# SET AEQ_MIN

    CRITICAL_PRINT ("No Solution Found");
    return Errors;
}

int DP_DISPLY_PROGRAM (int channel, unsigned char DEVICE_ADDR)
{
    unsigned char page;
    unsigned char offset0;
    unsigned char offset1;
    unsigned int bpc = 0;
    unsigned short wr_data;

    if (channel == 0) {
        page = 0x01;
        offset0 = 0x00;
        offset1 = 0x00;
    } else {
        page = 0x12;
        offset0 = 0x30;
        offset1 = 0x01;
    }

    board.WriteI2C(DEVICE_ADDR,0x0E,page);
    CRITICAL_PRINT ("SETTING DTG Parameters for DP_PORT %d Video: %s", channel, VIDEO_RESOLUTION);
    //#enable clock divider
    CRITICAL_PRINT ("Port %d: Setting QCLK", channel);
    board.WriteI2C(DEVICE_ADDR,0xB1,0x01);
    board.WriteI2C(DEVICE_ADDR,0xB2,lower_byte_QCLK(dp_mvalue));
    board.WriteI2C(DEVICE_ADDR,0xB3,middle_byte_QCLK(dp_mvalue));
    board.WriteI2C(DEVICE_ADDR,0xB4,upper_byte_QCLK(dp_mvalue));
    board.WriteI2C(DEVICE_ADDR,0xB5,lower_byte_QCLK(dp_nvalue));
    board.WriteI2C(DEVICE_ADDR,0xB6,middle_byte_QCLK(dp_nvalue));
    board.WriteI2C(DEVICE_ADDR,0xB7,upper_byte_QCLK(dp_nvalue));

    board.WriteI2C(DEVICE_ADDR,0x0E,0x01);

    CRITICAL_PRINT ("Port %d: Setting DTG", channel);
    board.WriteI2C(DEVICE_ADDR,0x40,0x50);
    //#Quad pixel mode
    board.WriteI2C(DEVICE_ADDR,0x41,0x20+offset0);
    //board.WriteI2C(DEVICE_ADDR,0x42,0x81);
    board.WriteI2C(DEVICE_ADDR,0x42,0xA3);
    wr_data = AHW | 0x8000;
    board.WriteI2C(DEVICE_ADDR,0x41,0x25+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, upper_byte_DTG(wr_data));
    board.WriteI2C(DEVICE_ADDR,0x41,0x26+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, lower_byte_DTG(wr_data));

    wr_data = HSTART | 0x8000;
    board.WriteI2C(DEVICE_ADDR,0x41,0x29+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, upper_byte_DTG(wr_data));
    board.WriteI2C(DEVICE_ADDR,0x41,0x2A+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, lower_byte_DTG(wr_data));
    wr_data = HSW | 0x4000;
    board.WriteI2C(DEVICE_ADDR,0x41,0x2F+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, upper_byte_DTG(wr_data));
    board.WriteI2C(DEVICE_ADDR,0x41,0x30+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42, lower_byte_DTG(wr_data));

    //#for i in range (1):
    //# Determine Active Lanes
    //## Select DP port SM     
    board.WriteI2C(DEVICE_ADDR,0x40,0x3C); //# Select DFT Page        
    board.WriteI2C(DEVICE_ADDR,0x41,0x01);
    board.WriteI2C(DEVICE_ADDR,0x42,0x09 + offset1);
    //## Select DP master SM vector sel
    board.WriteI2C(DEVICE_ADDR,0x41,0x02);
    board.WriteI2C(DEVICE_ADDR,0x42,0x05);
    board.WriteI2C(DEVICE_ADDR,0x41,0x03);
    unsigned char Active_Lanes = board.ReadI2C(DEVICE_ADDR,0x42);
    CRITICAL_PRINT ("Port %d: Active Lanes=0x%x", channel, Active_Lanes & 0x07);
    if (Active_Lanes == 0){
        CRITICAL_PRINT ("NO ACTIVE LANES DETECTED for PORT %d",channel);
        CRITICAL_PRINT ("Main-Link DP-TX-PLL RESET Applied");
    }

    CRITICAL_PRINT ("Port  %d: Setting the Pattern Programming to %s Tri-Linear IP", channel,VIDEO_RESOLUTION);
    unsigned char lane_count = Active_Lanes & 0x07;
    //#Choose bpc = 24 bit, bits 7:5 = 001
    if (bits_per_color == 6) {
        bpc = 0x00000000;
    }
    else if (bits_per_color == 10) {
        bpc = 0x00000040;
    }
    else if ( bits_per_color == 8) {
        bpc = 0x00000020;
    }
    CRITICAL_PRINT ("Port %d: Setting %d bpc", channel, bits_per_color*3);
    apb_read_modifywrite(0x1A4, 0x000000E0, bpc, (channel), DEVICE_ADDR);
    //#Quad pixel
    apb_read_modifywrite(0x1B8, 0x00000007, 0x00000004, (channel), DEVICE_ADDR);
    unsigned int mvid = (vid_freq * 10 / dp_rate * nvid);
    CRITICAL_PRINT ("Port %d: mvid : %d", channel, mvid);
    //#print 'written ' + str(mvid) + ' Hex = '  + hex(mvid)
    apb_write_reg(0x1AC, mvid, (channel), DEVICE_ADDR);
    apb_write_reg(0x1B4, nvid, (channel), DEVICE_ADDR);
    //unsigned int readback = apb_read_reg(0x1AC, (channel), DEVICE_ADDR);

    apb_write_reg(0x1C8, 0x00, (channel), DEVICE_ADDR);

    //############################################################################
    apb_write_reg(0x1B0, 0xE310040, (channel), DEVICE_ADDR); //#FIFO Depth to 56
    apb_write_reg(0x0C8, 0x4005, (channel), DEVICE_ADDR);
    //############################################################################
    unsigned int reg_value = ((my_pixels * bits_per_color * 3) + 7) / 8;
    if (lane_count != 0)
        reg_value = (reg_value + lane_count - 1) / lane_count;
    apb_write_reg(0x1BC, reg_value, (channel), DEVICE_ADDR);
    apb_write_reg(0x1C0, 0x00, (channel), DEVICE_ADDR);

    unsigned int vsync_wr = ((~vsync_pol) & 0x01) << 1;
    unsigned int hsync_wr = ((~hsync_pol) & 0x01);
    unsigned int wr_data_apb = 0x0000000c | vsync_wr | hsync_wr;
    apb_write_reg(0x1C4, wr_data_apb, (channel), DEVICE_ADDR);
    /*
    # Main stream Enable
    # apb_write_reg(0x084, 0x01, int(channel), DEVICE_ADDR)

    # time.sleep(0.5)
    # apb_write_reg(0x180, 0x1248, int(channel), DEVICE_ADDR)
    */

    CRITICAL_PRINT ("Port %d  Remove DTG Reset",channel);

    board.WriteI2C(DEVICE_ADDR,0x40,80);
    board.WriteI2C(DEVICE_ADDR,0x41,0x32+offset0);
    board.WriteI2C(DEVICE_ADDR,0x42,0x00);


    return 0;
}

int ti983_pattgen()
{
    //int FC_FPD_FREQ = link_speed;
    if (Video_Patt_Gen_Enable == 1) {
    //if (0) {
        CRITICAL_PRINT ("Video Patt-Gen Enabled");
        CRITICAL_PRINT("PCLK = %f MHz", PCLK_FREQ);

        CRITICAL_PRINT("THW = %d", THW);
        CRITICAL_PRINT("TVW = %d", TVW);
        CRITICAL_PRINT("AHW = %d", AHW);
        CRITICAL_PRINT("AVW = %d", AVW);
        CRITICAL_PRINT("HBP = %d", HBP);
        CRITICAL_PRINT("VBP = %d", VBP);
        CRITICAL_PRINT("HSW = %d", HSW);
        CRITICAL_PRINT("VSW = %d", VSW);

        #define PAGE_REG  0x40
        #define PAGE_ADDR  0x41
        #define PAGE_DATA  0x42
        #define PAGE_DISPPATTGEN  0x30
        #define PATGEN_IA  0x2A
        #define PATGEN_ID  0x2B


        board.WriteI2C(Device_TX,PAGE_REG,PAGE_DISPPATTGEN);

        // Pixel Setting
        CRITICAL_PRINT ("Color Depth Set To: %d bpc", bits_per_color);
        if (bits_per_color == 6) {
            board.WriteI2C(Device_TX,PAGE_ADDR,0x29);
            board.WriteI2C(Device_TX,PAGE_DATA,0x44);
        }else if ( bits_per_color == 8) {
            board.WriteI2C(Device_TX,PAGE_ADDR,0x29);
            //board.WriteI2C(Device_TX,PAGE_DATA,0x08);
            board.WriteI2C(Device_TX,PAGE_DATA,0x0C);
        } else if ( bits_per_color == 10) {
            board.WriteI2C(Device_TX,PAGE_ADDR,0x29);
            //board.WriteI2C(Device_TX,PAGE_DATA,0x10);
            board.WriteI2C(Device_TX,PAGE_DATA,0x14);
        }
        //Start programming patgen parameters from register 0x06 - 0x16 (Bit 7 is auto-increment for address)
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_IA);
        board.WriteI2C(Device_TX,PAGE_DATA,0x86);
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(THW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(THW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(TVW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(TVW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(AHW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(AHW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(AVW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(AVW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(HSW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(HSW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(VSW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(VSW));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(HBP));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(HBP));
        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,lower_byte(VBP));

        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID);
        board.WriteI2C(Device_TX,PAGE_DATA,upper_byte(VBP));

        board.WriteI2C(Device_TX,PAGE_ADDR,PATGEN_ID); // Set HSYNC and VSYNC polarity positive (Default=negative)
        board.WriteI2C(Device_TX,PAGE_DATA,0x00);

        // #Enable patgen
        //board.WriteI2C(Device_TX,PAGE_ADDR,0x28);
        //board.WriteI2C(Device_TX,PAGE_DATA,0x95); //Color Bar Pattern
        //board.WriteI2C(Device_TX,PAGE_DATA,0x94); //Color Bar Pattern
    }
/*#####################################
###     Config video processor     ###
#####################################*/

    //# provide source image (combined image) attributes

    //src_pclk_freq = PCLK_FREQ; //MHz

    //src_dp_h_active = AHW;

    //second I2C port Device_TX = 0x1A
    //third I2C port  Device_TX = 0x1C
    CRITICAL_PRINT ("====>>Config video processor 0 ");
    board.WriteI2C(Device_TX, 0x2D, 0x01);  // write Port select to port 0 initially.

    // choose page 12, set auto-increment
    board.WriteI2C(Device_TX, 0x40, 0x32); 

    unsigned char addr0 = 0x02;
    unsigned char addr1 = 0x10;
    CRITICAL_PRINT ("video processor 0 addr0 0x%x addr1 0x%x", (addr0), (addr1));


/*#####################################
# set timing on video processor 0 
######################################*/
    // set dp_h_active
    board.WriteI2C(Device_TX, 0x41, addr0); //# dp_h_active
    board.WriteI2C(Device_TX, 0x42, lower_byte(AHW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(AHW));
    //board.WriteI2C(Device_TX, 0x42, lower_byte(src_dp_h_active)); 
    //board.WriteI2C(Device_TX, 0x42, upper_byte(src_dp_h_active)); 
    // set video timing generator h_active
    board.WriteI2C(Device_TX, 0x41, addr1); //# h_active
    board.WriteI2C(Device_TX, 0x42, lower_byte(AHW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(AHW));

    //# set video timing generator h_back
    board.WriteI2C(Device_TX, 0x42, lower_byte(HBP));
    board.WriteI2C(Device_TX, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    board.WriteI2C(Device_TX, 0x42, lower_byte(HSW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    board.WriteI2C(Device_TX, 0x42, lower_byte(THW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(THW));

    // set video timing generator v_active
    board.WriteI2C(Device_TX, 0x42, lower_byte(AVW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    board.WriteI2C(Device_TX, 0x42, lower_byte(VBP));
    board.WriteI2C(Device_TX, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    board.WriteI2C(Device_TX, 0x42, lower_byte(VSW));
    board.WriteI2C(Device_TX, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    board.WriteI2C(Device_TX, 0x42, lower_byte(src_v_front));
    board.WriteI2C(Device_TX, 0x42, upper_byte(src_v_front));


    //board.WriteI2C(Device_TX, 0x40, 0x30)
    //board.WriteI2C(Device_TX, 0x42, 0x22)
    //board.WriteI2C(Device_TX, 0x42, 0x01)

/*#####################################
# set m/n value for video processor 0
# only for FPD4 mode
#####################################*/
    // n_value fixed as 15
    unsigned short n_value = 15;
/*
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000; //10800 #bps
    m_value = src_pclk_freq / 4.0 * (2 ** n_value) / (fc_freq/40.0);
    m_value = int(round(m_value));
    // print 'm_value= ',m_value
*/
    unsigned short m_value = 13608;//17615 ok;//17614 ok;//17616 ok;//17612 nok;//17613 nok //17618 nok //17617 nok
/*
    int ffd = open("/m.txt", O_RDONLY);
    if (ffd) {
        char sstr[32];
        memset(sstr, 0, 32);
        if (read(ffd, sstr, 32) > 0) {
            m_value = atoi(sstr);
            CRITICAL_PRINT("\n\nfrom file =======>>>> m_value %d\n", m_value);
        }
    }
*/
    CRITICAL_PRINT("\n\n=======>>>> m_value %d\n", m_value);

    // set m/n value for video processor 0
    board.WriteI2C(Device_TX, 0x41, 0x23) ;
    board.WriteI2C(Device_TX, 0x42, lower_byte(m_value)) ;
    board.WriteI2C(Device_TX, 0x42, upper_byte(m_value)) ;
    board.WriteI2C(Device_TX, 0x42, n_value) ;
//andrew

    board.WriteI2C(Device_TX, 0x40, 0x32);
    board.WriteI2C(Device_TX, 0x41, 0x26);
    board.WriteI2C(Device_TX, 0x42, 0xff);

    // main page: set number of video streams
    board.WriteI2C(Device_TX, 0x43, 0x00);

    // enable video processor 0
    board.WriteI2C(Device_TX, 0x44, 0x01);

/*#####################################
###     Config TX link layer       ###
#####################################*/

/*#####################################
# enable link layer stream
# only for FPD4 mode
#####################################*/
    // choose page 11, set auto-increment
    board.WriteI2C(Device_TX, 0x40, 0x2E);

    // enable link layer 0, stream 0
    board.WriteI2C(Device_TX, 0x41, 0x01);
    board.WriteI2C(Device_TX, 0x42, 0x01);

    if (bits_per_color == 8)
    {
        board.WriteI2C(Device_TX, 0x41, 0x20);
        board.WriteI2C(Device_TX, 0x42, 0x55);
    }
    else if (bits_per_color == 10)
    {
        board.WriteI2C(Device_TX, 0x41, 0x20);
        board.WriteI2C(Device_TX, 0x42, 0x5A);
    }

/*#####################################
# map video processor output to link layer stream
# only for FPD4 mode
######################################
# default mapping
# vp0 -> link layer 0, stream 0

######################################
# assign slots to link layer stream
# only for FPD4 mode
######################################
# assign 60 slots to each link layer stream
*/
    board.WriteI2C(Device_TX, 0x41, 0x06);
    board.WriteI2C(Device_TX, 0x42, 0x3C);

/*#####################################
# enable link layer
# only for FPD4 mode
######################################
# enable link layer 0
*/
    board.WriteI2C(Device_TX, 0x41, 0x00);
    board.WriteI2C(Device_TX, 0x42, 0x03);

    return 0;
}

void dp_read()
{
    CRITICAL_PRINT("Rate : %d",apb_read_reg(0x400, 0, Device_TX)*27);
    CRITICAL_PRINT("Lanes : %d",apb_read_reg(0x404, 0, Device_TX));
    CRITICAL_PRINT("0x43c : %d",apb_read_reg(0x43c, 0, Device_TX));
    CRITICAL_PRINT("0x440 : %d",apb_read_reg(0x440, 0, Device_TX));
    CRITICAL_PRINT("H Res : %d",apb_read_reg(0x500, 0, Device_TX));
    CRITICAL_PRINT("H POL : %d",apb_read_reg(0x504, 0, Device_TX));
    uint32_t h_sync = apb_read_reg(0x508, 0, Device_TX);
    CRITICAL_PRINT("H SYNC WIDTH : %d", h_sync);
    CRITICAL_PRINT("H BACK PORCH : %d",apb_read_reg(0x50C, 0, Device_TX)-h_sync);
    CRITICAL_PRINT("H TOTAL : %d",apb_read_reg(0x510, 0, Device_TX));
    CRITICAL_PRINT("V Res : %d",apb_read_reg(0x514, 0, Device_TX));
    CRITICAL_PRINT("V POL : %d",apb_read_reg(0x518, 0, Device_TX));
    uint32_t v_sync = apb_read_reg(0x51C, 0, Device_TX);
    CRITICAL_PRINT("V SYNC WIDTH : %d", v_sync);
    CRITICAL_PRINT("V BACK PORCH : %d",apb_read_reg(0x520, 0, Device_TX)-v_sync);
    CRITICAL_PRINT("HV TOTAL: %d",apb_read_reg(0x524, 0, Device_TX));
}

void patch_983_apb_vod()
{
    CRITICAL_PRINT(">>>>>>patch_983_apb_vod");
    apb_write_reg(0x214, 0x02, 0, Device_TX);
}

void patch_983_apb_54rst()
{
    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;
    CRITICAL_PRINT(">>>>>>patch_983_apb_54rst");
    apb_write_reg(0x54, 0x01, 0, Device_TX);
}

