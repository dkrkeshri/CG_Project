#define FPD3_PCLK  (148.5)
#define Device_TX  0x18  //8 bit address, 983
#define Device_RX  0x58  //8 bit address, 984
#define MCU_ID_7BIT       0x12
#define MCU_ID_8BIT       (MCU_ID_7BIT << 1)      //0x64
#define TOUCH_ID_7BIT     0x70
#define TOUCH_ID_8BIT     (TOUCH_ID_7BIT << 1)    //0x48
unsigned char Device_RX_7bit = 0;

static int32 reset_keep_dprx = 0;

#define FPD_MODE 1
#define SER_RESET_DIGITAL_ALL 0x02
#define SER_RESET_PLL_ONLY    0x30

#define DISP_INFRAS_TOUCH_PM           "vcd-touch-pm"
#define DISP_INFRAS_BL_PM              "vcd-brightness-pm"
#define DISP_INFRAS_SUSRES_PATH        "/dev/vcd/suspend-resume-commander/control"

#define DISP_INFRAS_WKUP_CTRL_PATH     "/dev/wakeup-binder/control"
#define DISP_INFRAS_WKUP_CTRL_NAME     "vcd-wakeup"
#define DISP_INFRAS_WKUP_CTRL_ONLINE   "1"
#define DISP_INFRAS_WKUP_CTRL_OFFLINE  "0"

#define RECOVERY_WAIT_TIMEOUT 180
#define RECOVERY_CHECKLINK_INTERVAL_MS 1000
#define RECOVERY_CHECKLINK_LOOP_TIMES (RECOVERY_WAIT_TIMEOUT*1000/RECOVERY_CHECKLINK_INTERVAL_MS)
#define MODULE_NAME "BUICK-TP-PM"

#define DISPLAY_WKUP_CTRL_ON  1
#define DISPLAY_WKUP_CTRL_OFF 0 
#define DISPLAY_PDB_CTRL_ON  1
#define DISPLAY_PDB_CTRL_OFF 0 
#define DISPLAY_CHAIN_CTRL_ON  1
#define DISPLAY_CHAIN_CTRL_OFF 0 

int device = 984;
int REMOTE_SWITCH_FROM_983 = 1;
int Video_Patt_Gen_Enable = 0;
#define link_speed (6.75)

int DES_1_Video_ON = 1;

//# DP Ports Selection
int DES_1_DP_PORT_0 = 1;
int DES_1_DP_PORT_1 = 0;

int Force_Rate_DP_DES_1 = 1;
int Force_Speed_DP_DES_1 = 2700 ;//#MHz

//VIDEO_RESOLUTION = "6k" #
int bits_per_color = 8;


//if VIDEO_RESOLUTION == "6k" :
//#Video parameters
#define PCLK_FREQ (280.31)
#define THW 3550
#define TVW 1316
#define AHW 3400
#define AVW 1300
#define HBP 7
#define VBP 7
#define HSW 30
#define VSW 1
#define src_v_front 8

#define VIDEO_RESOLUTION "6k"

#define HSTART  (HBP + HSW)
int nvid = 32768;// #270000
int vid_freq = PCLK_FREQ; //# 148.5 
float my_pixels = 3400;//same AHW
int hsync_pol = 0;
int vsync_pol = 0;

int Bypass_PLL_Speed_Setting = 0 ;
int Enable_PLL_Jitter_Fix = 1;
#define Main_link_speed  (6.75)
float DES_1_link_speed = Main_link_speed ;
int Bypass_Display_Panel = 0;
int VIDEO_CHECK_ENABLE_DES_1 = 0;
int CRC_WAIT = 2; //#seconds to check for errors
int Loop_RESET = 1; //#Number of retries for Video CRC checking
int SOFT_RESET = 1;
int Force_960AEQ = 1;
int Enable_SHOW_ALL_COEFFICIENTS = 0;

//if FPD_MODE == "FPD4" :
//#Bypass Initialization 
int Bypass_VGA_GAIN = 0;
#define VGA_GAIN_P0  (0x10 + 6)// # 4 (0-15)
#define VGA_GAIN_P1  (0x10 + 6)// # 10 (0-15)

//# BYPASS SCRIPTS
int Bypass_960_AEQ_Optimization = 0;
int Bypass_CDR_Params = 0;
int Bypass_AEQ_MAP = 0;
int Bypass_LEVEL_SHIFTER = 0;
int Bypass_Echo_PI = 0;
int Bypass_SUM_BUFF_VGA_THRESHOLD = 0;
int Bypass_BC_Params = 0;
int Bypass_Post_Init_Reset = 0;
int Bypass_Link_Status = 0;
int Bypass_DFE_Monitors = 0;
int Bypass_CHECK_ALIGNMNET = 0;

int dp_mvalue, dp_nvalue, dp_rate;

//static int verbosedebug = 1;
#define DEBUG_VERBOSE 1
#define DEBUG_CRITICAL 1

#define DEBUG_PRINT( _str_, ...)               \
    do { \
        if (DEBUG_VERBOSE) { \
            LOG_CRITICAL_INFO(CHIP_ID, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT( _str_, ...)               \
    do { \
        if (DEBUG_CRITICAL) { \
            LOG_CRITICAL_INFO(CHIP_ID, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct board_t
{
    int (*WriteI2C)(uint8_t addr, uint8_t reg, uint8_t val);
    uint8_t (*ReadI2C)(uint8_t addr, uint8_t reg);
    void (*sleep)(float s);
    int fd;   // give the I2C fd to here
    unsigned char device_address7bit;
};

struct board_t board;

#include "patac_ff_funcs.c"
#include "sus_res_comm_lib.h"
#include "libdisplaywakeup.h"
#include <sys/dispatch.h>
#include "screen_pwrmgr_common.h"

BridgeChip_StatusType ti983_fpdlink3_init();
BridgeChip_StatusType ti983_init_switch_fpd4();
int ti984_init_switch_fpd4();

void sleep_s(float s);
int VGA_THRESHOLDS_ADJUST (unsigned char DEVICE_ADR, unsigned short LOW_THR, unsigned short HIGH_THR, unsigned char VGA_SWEEP_THR, int PORT);
int REPLICA_RDAC(unsigned char DEVIDE_ADR, unsigned char CH0_RDAC, unsigned char CH1_RDAC);

int buick_ff_pre_init()
{
    board.WriteI2C = write_reg;
    board.ReadI2C = read_reg;
    board.sleep = sleep_s;
    return 0;
}

BridgeChip_StatusType buick_ff_init()
{
    int i;
    if (ti983_fpdlink3_init() == BRIDGECHIP_STATUS_FAILED) {

        return BRIDGECHIP_STATUS_FAILED;
    }
    ti984_init_switch_fpd4();
    ti983_init_switch_fpd4();

    for (i = 0; i < 5; i++) {
        board.sleep(0.1);
        board.WriteI2C(Device_TX,0x2D, 0x01);
        unsigned char Value= board.ReadI2C(Device_TX,0x0c);
        CRITICAL_PRINT("Port0: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x  LINK_DETECT: 0x%x",(Value >>4)&0x01, (Value >>1)&0x01, (Value & 0x01));
        board.WriteI2C(Device_TX,0x2D, 0x12);
        unsigned char Value2= board.ReadI2C(Device_TX,0x0c);
        CRITICAL_PRINT("Port1: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x LINK_DETECT: 0x%x",(Value2 >>4)&0x01,(Value2 >>1)&0x01,(Value2 & 0x01));
        CRITICAL_PRINT( "===>DES ID=0x%x", board.ReadI2C(Device_TX,0x08));

        if ((Value & 0x01) && (Value2 & 0x01))
            break;
    }
    board.WriteI2C(Device_TX,0x2D, 0x01);
    apb_write_reg(0xa18, 0x5, 0, Device_TX);
    return BRIDGECHIP_STATUS_SUCCESS;
}

void sleep_s(float s)
{
    if (s < 1)
    {
        unsigned int ss = s*1000*1000;
        (void)usleep(ss);
    }
    else
    {
        sleep(s);
    }
}

//fail: return -1, success: 0
BridgeChip_StatusType ti983_fpdlink3_init()
{

    float VCO_FREQ = FPD3_PCLK * 35;
    unsigned int VCO_CNT = (unsigned int)(VCO_FREQ /27/2);
    unsigned int VCO_SEL = 0xC3;
    int i;
    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;

    CRITICAL_PRINT( "===>VCO_CNT=%d", VCO_CNT);
    CRITICAL_PRINT( "===>chip ID=0x%x", board.ReadI2C(Device_TX,0x00));
//    board.WriteI2C(Device_TX,0x1,0x2);
    board.sleep(0.1);

    CRITICAL_PRINT("Enable I2C Passthru");
    board.WriteI2C(Device_TX,0x07,0x88);

    CRITICAL_PRINT( "Setting PLL_TX_0 To: %f GHz", FPD3_PCLK * 35 / 1000);
    board.WriteI2C(Device_TX,0x40,0x08);  // Page 2
    board.WriteI2C(Device_TX,0x41,0x0E);
    board.WriteI2C(Device_TX,0x42,VCO_SEL); // Select VCO  // TODO: NOT AVAILABE in 984 script
    board.WriteI2C(Device_TX,0x41,0x05);
    board.WriteI2C(Device_TX,0x42,(VCO_CNT)); // NCount [7:0]

    board.WriteI2C(Device_TX,0x41,0x13);
    board.WriteI2C(Device_TX,0x42,0xF0);

    board.WriteI2C(Device_TX,0x40,0x08);  // Page 2
    board.WriteI2C(Device_TX,0x41,0x4E);
    board.WriteI2C(Device_TX,0x42,VCO_SEL); // Select VCO
    board.WriteI2C(Device_TX,0x41,0x05+0x40);
    board.WriteI2C(Device_TX,0x42,(VCO_CNT)); // NCount [7:0]
    board.WriteI2C(Device_TX,0x41,0x13+0x40);
    board.WriteI2C(Device_TX,0x42,0xF0);

    board.WriteI2C(Device_TX,0x01,0x30);

    board.WriteI2C(Device_TX,0x5b,0x2b); // Enable FPD3 FIFO

    //print "Clear BC CRC Flags"
    board.WriteI2C(Device_TX,0x02,0xF0); // Clear CRC
    board.WriteI2C(Device_TX,0x02,0xD0); // Clear CRC
    board.WriteI2C(Device_TX,0x59,0x3); //dual mode
    board.WriteI2C(Device_TX,0x05,0x00);
#if 0
    CRITICAL_PRINT("PLL-TX Jitter Improvements Enabled");
    board.WriteI2C(Device_TX,0x40,0x08);
    board.WriteI2C(Device_TX,0x41,0x23);
    board.WriteI2C(Device_TX,0x42,0x3F); //ICP
    board.WriteI2C(Device_TX,0x41,0x24);
    board.WriteI2C(Device_TX,0x42,0x23); //rzero
    board.WriteI2C(Device_TX,0x41,0x21); //cdac_filter
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x2f); //r4 and filter cap
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x0E); //r4 and filter cap
    board.WriteI2C(Device_TX,0x42,0x47); // Disable Temp_comp


    board.WriteI2C(Device_TX,0x41,0x63);
    board.WriteI2C(Device_TX,0x42,0x3F); //ICP
    board.WriteI2C(Device_TX,0x41,0x64);
    board.WriteI2C(Device_TX,0x42,0x23); //rzero
    board.WriteI2C(Device_TX,0x41,0x61); //cdac_filter
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x6f); //r4 and filter cap
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x4E); //r4 and filter cap
    board.WriteI2C(Device_TX,0x42,0x47); // Disable Temp_comp   
#endif
    // SOFT RESET
//    board.WriteI2C(Device_TX,0x01,0x01);
    if (reset_keep_dprx)
        board.WriteI2C(Device_TX,0x01,0x30);
    else
        board.WriteI2C(Device_TX,0x01,0x01);
    board.sleep(0.1);//TODO:

    board.WriteI2C(Device_TX,0x2D,0x01); // Select Port 0
    //set speed to 400k
    board.WriteI2C(Device_TX, 0x2B, 0x1C);
    board.WriteI2C(Device_TX, 0x2C, 0x1C);
    // DES_1
    board.WriteI2C(Device_TX, 0x70, Device_RX); // SLAVE_ID[0]
    board.WriteI2C(Device_TX, 0x78, Device_RX); // SLAVE_ALIAS[0]
    board.WriteI2C(Device_TX, 0x71, MCU_ID_8BIT);
    board.WriteI2C(Device_TX, 0x79, MCU_ID_8BIT);
    board.WriteI2C(Device_TX, 0x72, TOUCH_ID_8BIT);
    board.WriteI2C(Device_TX, 0x7A, TOUCH_ID_8BIT);

    board.WriteI2C(Device_TX, 0x17, 0x80);
    board.WriteI2C(Device_TX, 0x18, 0x81);

    board.WriteI2C(Device_TX, 0x88, 0x00); // SLAVE_DEST[0]

    CRITICAL_PRINT("Main-Link DES Address Set To: 0x%x", (Device_RX));
    CRITICAL_PRINT( "===>chip ID=0x%x", board.ReadI2C(Device_TX,0x00));

    CRITICAL_PRINT("Clear BC CRC Flags");
    board.WriteI2C(Device_TX,0x2D,0x01);
    board.WriteI2C(Device_TX,0x02,0xF0); // Clear CRC
    board.WriteI2C(Device_TX,0x02,0xD0); // Clear CRC
    board.WriteI2C(Device_TX,0x2D,0x12);
    board.WriteI2C(Device_TX,0x02,0xF0); // Clear CRC
    board.WriteI2C(Device_TX,0x02,0xD0); // Clear CRC
    board.sleep(0.2);

    //todo: need wait for linkup. if display is not connected in 1s. return fail
    for (i = 0; i < 5; i++) {
        board.sleep(0.2);
        board.WriteI2C(Device_TX,0x2D, 0x01);
        unsigned char Value= board.ReadI2C(Device_TX,0x0c);
        CRITICAL_PRINT("Port0: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x  LINK_DETECT: 0x%x",(Value >>4)&0x01, (Value >>1)&0x01, (Value & 0x01));
        board.WriteI2C(Device_TX,0x2D, 0x12);
        unsigned char Value2= board.ReadI2C(Device_TX,0x0c);
        CRITICAL_PRINT("Port1: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x LINK_DETECT: 0x%x",(Value2 >>4)&0x01,(Value2 >>1)&0x01,(Value2 & 0x01));
        CRITICAL_PRINT( "===>DES ID=0x%x", board.ReadI2C(Device_TX,0x08));

        if ((Value & 0x01) && (Value2 & 0x01))
            break;
    }
    board.WriteI2C(Device_TX,0x2D, 0x01);
    if (i >= 5) {
        CRITICAL_PRINT( "Display not detected");
        return BRIDGECHIP_STATUS_FAILED;
    }
    //ti983_pattgen();

    return BRIDGECHIP_STATUS_SUCCESS;
} 

void ti983_set_lane()
{
#if 0
    // DP0 Lane 0
    board.WriteI2C(Device_TX, 0x40, 0x10);
    board.WriteI2C(Device_TX, 0x41, 0x4C);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x50);
    board.WriteI2C(Device_TX, 0x42, 0x80);
    board.WriteI2C(Device_TX, 0x41, 0x25);
    board.WriteI2C(Device_TX, 0x42, 0x35);
    board.WriteI2C(Device_TX, 0x41, 0x24);
    board.WriteI2C(Device_TX, 0x42, 0x25);
    board.WriteI2C(Device_TX, 0x41, 0x0A);
    board.WriteI2C(Device_TX, 0x42, 0x77);
    board.WriteI2C(Device_TX, 0x41, 0x28);
    board.WriteI2C(Device_TX, 0x42, 0x30);

    // DP0 Lane 1
    board.WriteI2C(Device_TX, 0x40, 0x10);
    board.WriteI2C(Device_TX, 0x41, 0xCC);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD0);
    board.WriteI2C(Device_TX, 0x42, 0x80);
    board.WriteI2C(Device_TX, 0x41, 0xA5);
    board.WriteI2C(Device_TX, 0x42, 0x35);
    board.WriteI2C(Device_TX, 0x41, 0xA4);
    board.WriteI2C(Device_TX, 0x42, 0x25);
    board.WriteI2C(Device_TX, 0x41, 0x8A);
    board.WriteI2C(Device_TX, 0x42, 0x77);
    board.WriteI2C(Device_TX, 0x41, 0xA8);
    board.WriteI2C(Device_TX, 0x42, 0x30);

    // DP0 Lane 2
    board.WriteI2C(Device_TX, 0x40, 0x14);
    board.WriteI2C(Device_TX, 0x41, 0x4C);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x50);
    board.WriteI2C(Device_TX, 0x42, 0x80);
    board.WriteI2C(Device_TX, 0x41, 0x25);
    board.WriteI2C(Device_TX, 0x42, 0x35);
    board.WriteI2C(Device_TX, 0x41, 0x24);
    board.WriteI2C(Device_TX, 0x42, 0x25);
    board.WriteI2C(Device_TX, 0x41, 0x0A);
    board.WriteI2C(Device_TX, 0x42, 0x77);
    board.WriteI2C(Device_TX, 0x41, 0x28);
    board.WriteI2C(Device_TX, 0x42, 0x30);

    // DP0 Lane 3
    board.WriteI2C(Device_TX, 0x40, 0x14);
    board.WriteI2C(Device_TX, 0x41, 0xCC);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD0);
    board.WriteI2C(Device_TX, 0x42, 0x80);
    board.WriteI2C(Device_TX, 0x41, 0xA5);
    board.WriteI2C(Device_TX, 0x42, 0x35);
    board.WriteI2C(Device_TX, 0x41, 0xA4);
    board.WriteI2C(Device_TX, 0x42, 0x25);
    board.WriteI2C(Device_TX, 0x41, 0x8A);
    board.WriteI2C(Device_TX, 0x42, 0x77);
    board.WriteI2C(Device_TX, 0x41, 0xA8);
    board.WriteI2C(Device_TX, 0x42, 0x30);
#else
    //latest setting from TI for 8.1G
    // DP0 Lane 0
    board.WriteI2C(Device_TX, 0x40, 0x10);
    board.WriteI2C(Device_TX, 0x41, 0x30);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x4C);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x50);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x56);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    // DP0 Lane 1
    board.WriteI2C(Device_TX, 0x40, 0x10);
    board.WriteI2C(Device_TX, 0x41, 0xB0);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xCC);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD0);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD6);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    // DP0 Lane 2
    board.WriteI2C(Device_TX, 0x40, 0x14);
    board.WriteI2C(Device_TX, 0x41, 0x30);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x4C);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x50);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0x56);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    // DP0 Lane 3
    board.WriteI2C(Device_TX, 0x40, 0x14);
    board.WriteI2C(Device_TX, 0x41, 0xB0);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xCC);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD0);
    board.WriteI2C(Device_TX, 0x42, 0x00);
    board.WriteI2C(Device_TX, 0x41, 0xD6);
    board.WriteI2C(Device_TX, 0x42, 0x00);
#endif
}

BridgeChip_StatusType ti983_init_switch_fpd4()
{
    unsigned char chip_rev;
    CRITICAL_PRINT("Switched from FPD3 to FPD4 on Main-Link RX");
    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;

    ti983_set_lane();

    chip_rev = board.ReadI2C(Device_TX, 0x30);
/*
    board.WriteI2C(Device_TX,0x40,0x08);
    board.WriteI2C(Device_TX,0x41,0x1B);
    board.WriteI2C(Device_TX,0x42,0x08);
    board.WriteI2C(Device_TX,0x41,0x5B);
    board.WriteI2C(Device_TX,0x42,0x08);    
*/
    CRITICAL_PRINT("Configuring 983/981 to FPD4 Mode");
    board.WriteI2C(Device_TX,0x2D,0x03);
    board.WriteI2C(Device_TX,0x6A,0x10);

    // for 983 CS2.0
    if ((chip_rev & 0xF0) == 0x50)
    {
        board.WriteI2C(Device_TX,0x6E, 0x80);
    }
/*
    board.WriteI2C(Device_TX,0x5B,0x23);
    board.WriteI2C(Device_TX,0x59,0x03);
*/
    //board.WriteI2C(Device_TX,0x05,0x28); // FPD_TX to DUAL 

    CRITICAL_PRINT("Switch mode to FPD4");
    board.WriteI2C(Device_TX,0x05,0x28);
    board.WriteI2C(Device_TX,0x02,0xD1);
    board.WriteI2C(Device_TX,0x2d,0x01);

    board.WriteI2C(Device_TX,0x40,9*4);
    board.WriteI2C(Device_TX,0x41,0x84);
    board.WriteI2C(Device_TX,0x42,0x02);
    board.WriteI2C(Device_TX,0x41,0x94);
    board.WriteI2C(Device_TX,0x42,0x02);

    CRITICAL_PRINT("Programming 981/983 PLL");
    board.WriteI2C(Device_TX,0x40,0x08);

    board.WriteI2C(Device_TX,0x41,0x05);
    board.WriteI2C(Device_TX,0x42,0x7D);
    board.WriteI2C(Device_TX,0x41,0x0e);
    board.WriteI2C(Device_TX,0x42,0xC7);
    board.WriteI2C(Device_TX,0x41,0x13);
    board.WriteI2C(Device_TX,0x42,0x90);

    board.WriteI2C(Device_TX,0x41,0x45);
    board.WriteI2C(Device_TX,0x42,0x7D);
    board.WriteI2C(Device_TX,0x41,0x4e);
    board.WriteI2C(Device_TX,0x42,0xC7);
    board.WriteI2C(Device_TX,0x41,0x53);
    board.WriteI2C(Device_TX,0x42,0x90);
/*
    board.WriteI2C(Device_TX,0x2D,0x03);
    board.WriteI2C(Device_TX,0x6A,0x10); // BC Oversampling to 20
    board.WriteI2C(Device_TX,0x2D,0x01);
*/
    // Zero out fractional
    board.WriteI2C(Device_TX,0x41,0x04);
    board.WriteI2C(Device_TX,0x42,0x01);
    board.WriteI2C(Device_TX,0x41,0x1E);
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x1F);
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x20);
    board.WriteI2C(Device_TX,0x42,0x00);

    board.WriteI2C(Device_TX,0x41,0x44);
    board.WriteI2C(Device_TX,0x42,0x01);
    board.WriteI2C(Device_TX,0x41,0x5e);
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x5f);
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x60);
    board.WriteI2C(Device_TX,0x42,0x00);
/*
    board.WriteI2C(Device_TX,0x41,0x0e);
    board.WriteI2C(Device_TX,0x42,0xc7);
    board.WriteI2C(Device_TX,0x41,0x4e);
    board.WriteI2C(Device_TX,0x42,0xc7);
*/
/*
    board.WriteI2C(Device_TX,0x40,0x08);
    board.WriteI2C(Device_TX,0x41,0x1B);
    board.WriteI2C(Device_TX,0x42,0x00);
    board.WriteI2C(Device_TX,0x41,0x5B);
    board.WriteI2C(Device_TX,0x42,0x00);
    apb_write_reg(0xa28, 0x4123, 0, Device_TX);
*/
    
    
    CRITICAL_PRINT("=====>>Software reset 983");
//    board.WriteI2C(Device_TX,0x01,0x01);
    if (reset_keep_dprx)
        board.WriteI2C(Device_TX,0x01,0x30);
    else
        board.WriteI2C(Device_TX,0x01,0x01);
    board.sleep(0.1);
    //board.WriteI2C(Device_TX,0x01,0x30)
    i2c_set_slave_addr(board.fd, Device_RX_7bit, I2C_ADDRFMT_7BIT);
    board.device_address7bit = Device_RX_7bit;

    CRITICAL_PRINT("=====>>Software reset 984");
    board.WriteI2C(Device_RX,0x01,0x01);
    board.sleep (0.1);

    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;
    board.WriteI2C(Device_TX, 0x40, 0x2E); 
    board.WriteI2C(Device_TX, 0x41, 0x00); 
    board.WriteI2C(Device_TX, 0x42, 0x03);
    patch_983_apb_vod();
    ti983_pattgen();
	
    return BRIDGECHIP_STATUS_SUCCESS;
}

static int irq_status_reg_bit0 = 0;
void get_983_irq_status_reg_bit0()
{
    uint8_t regval=0;
    uint8_t regval_0=0;
    board.WriteI2C(Device_TX, 0x40, 0x25);
    board.WriteI2C(Device_TX, 0x41, 0x3F);
    regval = read_reg(Device_TX, 0x42);

    regval_0 = regval & 0x1;

    if (regval_0 != irq_status_reg_bit0) {
        irq_status_reg_bit0 = regval_0;
        CRITICAL_PRINT("983_irq_status_reg_bit0: %d(0x3f=0x%x)", regval_0, regval);
    }
}

BridgeChip_StatusType get_983_link_status()
{
    uint8_t regval=0;
    int32_t port0_link = 0;
    int32_t port1_link = 0;
    #define RX_LOCK_DETECT_BIT 6
    #define LINK_DETECT_BIT    0

    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;

    write_reg(Device_TX, 0x2D, 0x01);
    regval=read_reg(Device_TX, 0x0c);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) &&
            (((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 ) )
        port0_link = 1;
/*
    CRITICAL_PRINT(
            "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));
*/
    regval=0;
    write_reg(Device_TX, 0x2D, 0x12);
    regval=read_reg(Device_TX, 0x0c);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) &&
            (((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 ) )
        port1_link = 1;		
	write_reg(Device_TX, 0x2D, 0x01);
/*
    CRITICAL_PRINT(
            "Port1: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));
*/

    get_983_irq_status_reg_bit0();
    //dp_read();                   
    if ((port0_link == 1) && (port1_link == 1))
        return BRIDGECHIP_STATUS_SUCCESS;
    else
        return BRIDGECHIP_STATUS_FAILED;
}

int is_983_dp_linkup()
{
    uint32 lane01_status, lane23_status;
//    uint8  vp_status;
    static uint8  vp_status = 0, vp_status_tmp = 0;
	
    i2c_set_slave_addr(board.fd, 0xc, I2C_ADDRFMT_7BIT);
    board.device_address7bit = 0xc;
    lane01_status = apb_read_reg(0x43C, 0, Device_TX);
    lane23_status = apb_read_reg(0x440, 0, Device_TX);

    vp_status = read_reg(Device_TX, 0x45);
//	if (vp_status != vp_status_tmp) {
        CRITICAL_PRINT( "vp_status | 0x%x,vp_status_tmp |  0x%x,",vp_status, vp_status_tmp);
        CRITICAL_PRINT( "0x%x, 0x%x, VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",lane01_status, lane23_status,
            vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);
        vp_status_tmp = vp_status;	
//	}
    dp_read();
    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377))
        return 1;
    else
        return 0;
}

int ti984_init_switch_fpd4()
{
    unsigned char REG, DATA, Value;
    Device_RX_7bit = (Device_RX>>1);
    i2c_set_slave_addr(board.fd, Device_RX_7bit, I2C_ADDRFMT_7BIT);
    board.device_address7bit = Device_RX_7bit;

    board.WriteI2C(Device_RX,0x0E,0x01);
    CRITICAL_PRINT( "===>des chip ID=0x%x", board.ReadI2C(Device_RX,0x00));
    CRITICAL_PRINT( "===>des chip ID=0x%x", board.ReadI2C(Device_RX,0x00));
    CRITICAL_PRINT( "===>des chip ID=0x%x", board.ReadI2C(Device_RX,0x00));


    if (Enable_PLL_Jitter_Fix == 1)
    {
        board.WriteI2C(Device_RX,0x40,0x0C);
        board.WriteI2C(Device_RX,0x41,0x23);
        board.WriteI2C(Device_RX,0x42,0x3F); //ICP
        board.WriteI2C(Device_RX,0x41,0x24);
        board.WriteI2C(Device_RX,0x42,0x0F); //rzero  //0x23
        board.WriteI2C(Device_RX,0x41,0x21); //cdac_filter
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x2f); //r4 and filter cap
        board.WriteI2C(Device_RX,0x42,0x00);

        board.WriteI2C(Device_RX,0x41,0x63);
        board.WriteI2C(Device_RX,0x42,0x3F); //ICP
        board.WriteI2C(Device_RX,0x41,0x64);
        board.WriteI2C(Device_RX,0x42,0x0F); //rzero //23
        board.WriteI2C(Device_RX,0x41,0x61); //cdac_filter
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x6f); //r4 and filter cap
        board.WriteI2C(Device_RX,0x42,0x00);
    }

    if (Force_960AEQ == 1)
    {
        int Adapt_Mode = 0x01; //   #0x00: AEQ_SNS+CTLE_LMS, 0x01: 960_AEQ
        board.WriteI2C(Device_RX,0x0e,0x03); // Port 0
        board.WriteI2C(Device_RX,0x60,0x0f); // Increase Timers
        board.WriteI2C(Device_RX,0x61,Adapt_Mode); // Sets Adapt Mode
        board.WriteI2C(Device_RX,0x0e,0x01); // Port 0
        //board.sleep(0.1);
        board.WriteI2C(Device_RX,0x0e,0x12); // Port 1
        //board.sleep(0.1);
        if (Adapt_Mode == 0x01) {
            board.WriteI2C(Device_RX,0x0E,0x01);
            board.WriteI2C(Device_RX,0x95,0x06); // BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ
            board.WriteI2C(Device_RX,0x0E,0x12);
            board.WriteI2C(Device_RX,0x95,0x06); // BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ 
        }
        board.WriteI2C(Device_RX,0x0E,0x01);
    }

    if (Bypass_PLL_Speed_Setting == 0)
    {
        int Value_Main = Main_link_speed*1000/27/4;
        Value_Main = 2*Main_link_speed*1000/27/4;
        CRITICAL_PRINT("Setting Main-Link PLL_RX to %f GHz, Value_Main: %d", DES_1_link_speed, Value_Main);
        board.WriteI2C(Device_RX,0x40,0x08);  // Page 2 on 984
        board.WriteI2C(Device_RX,0x41,0x05);
        board.WriteI2C(Device_RX,0x42,(Value_Main)); // NCount [7:0]   //7D
        board.WriteI2C(Device_RX,0x41,0x4);
        board.WriteI2C(Device_RX,0x42,0x1);
        board.WriteI2C(Device_RX,0x41,0xe);
        board.WriteI2C(Device_RX,0x42,0xc7);
        board.WriteI2C(Device_RX,0x41,0x13);
        board.WriteI2C(Device_RX,0x42,0x80);
        board.WriteI2C(Device_RX,0x0E,0x03);
        board.WriteI2C(Device_RX,0x33,0x05); //PI POST DIV=2
        board.WriteI2C(Device_RX,0x0E,0x01);

        CRITICAL_PRINT("SOFT RESET PLL_RX");
        board.WriteI2C(Device_RX,0x01,0x80); //
        // print "SOFT RESET PLL_TX0"
        // board.WriteI2C(Device_RX,0x01,0x20) //
        // print "SOFT RESET PLL_TX1"
        // board.WriteI2C(Device_RX,0x01,0x10) //

        board.WriteI2C(Device_RX,0x40,0x08);
        board.WriteI2C(Device_RX,0x41,0x07);
        Value = board.ReadI2C(Device_RX,0x42);
        CRITICAL_PRINT("PLL_RX_LOCK: 0x%x PLL_VCNTRL_HIGH= 0x%x  PLL_VCNTL_LOW: 0x%x ", Value & 0x01, (Value >> 4) & 0x01, (Value >> 3) & 0x01);
    }

    if (Bypass_960_AEQ_Optimization == 0)
    {
        board.WriteI2C(Device_RX,0x40,0x38); // SELECT PAGE AEQ_SNS

        board.WriteI2C(Device_RX,0x41,0x2C);
        board.WriteI2C(Device_RX,0x42,0x01);  //[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
        board.WriteI2C(Device_RX,0x41,0x24);
        board.WriteI2C(Device_RX,0x42,0x45);  //[6]: S-Filter_EN, AEQ Timer [2:0]   ===> HUGE DIFFERENCE IN LOCK WHEN 0x45 vs 0x46, or 47, or 44

        board.WriteI2C(Device_RX,0x41,0x5C);
        board.WriteI2C(Device_RX,0x42,0x01);   //[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
        board.WriteI2C(Device_RX,0x41,0x54);
        board.WriteI2C(Device_RX,0x42,0x45);  //AEQ Timer [2:0]
    }

    if (Bypass_SUM_BUFF_VGA_THRESHOLD == 0)
    {
        ////print "Setting VGA Adapt Thresholds"
        CRITICAL_PRINT("Setting VGA Adapt Thresholds");
        VGA_THRESHOLDS_ADJUST(Device_RX,30,50, 50, 0);
        VGA_THRESHOLDS_ADJUST(Device_RX,30,50, 50, 1);
    }

    if (Bypass_VGA_GAIN == 0) {
        CRITICAL_PRINT("VGA Gain Override");
        board.WriteI2C(Device_RX,0x40,0x38); // AEQ_SENSOR PAGE
        board.WriteI2C(Device_RX,0x41,0x1B);
        board.WriteI2C(Device_RX,0x42,VGA_GAIN_P0); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"
        board.WriteI2C(Device_RX,0x41,0x4B);
        board.WriteI2C(Device_RX,0x42,VGA_GAIN_P1); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"
    }
    if (Bypass_CDR_Params ==0) {
        CRITICAL_PRINT("CDR Parameters Changed");
        board.WriteI2C(Device_RX,0x40,0x54); // SO DROP
        board.WriteI2C(Device_RX,0x41,0x44);
        board.WriteI2C(Device_RX,0x42,0x1C); // Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop, 

        board.WriteI2C(Device_RX,0x40,0x54);
        board.WriteI2C(Device_RX,0x41,0xAA);
        board.WriteI2C(Device_RX,0x42,0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

        board.WriteI2C(Device_RX,0x41,0xAB); // [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1
        board.WriteI2C(Device_RX,0x42,0x0e); //5 Efuse

        board.WriteI2C(Device_RX,0x40,0x58);
        board.WriteI2C(Device_RX,0x41,0x44);
        board.WriteI2C(Device_RX,0x42,0x1C); //5 Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop, 

        board.WriteI2C(Device_RX,0x40,0x58);
        board.WriteI2C(Device_RX,0x41,0xAA);
        board.WriteI2C(Device_RX,0x42,0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

        board.WriteI2C(Device_RX,0x41,0xAB);
        board.WriteI2C(Device_RX,0x42,0x0e); //5 [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1
    }
    if (Bypass_BC_Params == 0) {

        //print "Diable iPWM"
        board.WriteI2C(Device_RX,0x0e,0x03); // Port 0
        board.WriteI2C(Device_RX,0xB9,0x0F); //NTUNE [4:0]
        board.WriteI2C(Device_RX,0xBA,0x13); //PTUNE [4:0]
        board.WriteI2C(Device_RX,0xBB,0x01); //Enable iPWM
        board.WriteI2C(Device_RX,0x0e,0x01);

        //Enable Driver R-BIAS
        board.WriteI2C(Device_RX,0x40,15*4); // DFT PAGE
        board.WriteI2C(Device_RX,0x41,0x3A); // [3]:reg_fpd_rx_en_drv_rbias_ov_en_p0, [2]:reg_fpd_rx_en_drv_rbias_ov_p0,[1]:reg_fpd_rx_en_drv_rbias_ov_en_p1, [0]:reg_fpd_rx_en_drv_rbias_ov_p1
        board.WriteI2C(Device_RX,0x42,0x0f);

        board.WriteI2C(Device_RX,0x40,0x10); // Page FPD_RX Analog

        unsigned char CH_OFFSET = 0x00;

        REG=0x01; //[7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
        DATA = 0x0F;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x02; //[7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
        DATA = 0x13;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x03; //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
        DATA = 0x13;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x04; //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
        DATA = 0x0f;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x05; //[7]=EN_TX_DRV (SPARE);, [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
        DATA = 0x00;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
        DATA = 0x0A;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x08; //[7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
        DATA = 0x14;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
        DATA = 0x0f;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        CH_OFFSET = 0x10;

        REG=0x01; //[7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
        DATA = 0x0F;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x02; //[7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
        DATA = 0x0F;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x03; //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
        DATA = 0x33;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x04; //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
        DATA = 0x14;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x05; //[7]=EN_TX_DRV (SPARE);, [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
        DATA = 0x00;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
        DATA = 0x0A;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x08; //[7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
        DATA = 0x14;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);

        REG=0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
        DATA = 0x0f;
        board.WriteI2C(Device_RX,0x41,CH_OFFSET+REG);
        board.WriteI2C(Device_RX,0x42,DATA);
    }


    if ((Bypass_AEQ_MAP == 0) && (FPD_MODE == 1)) {
        //AEQ MAP Changes
        CRITICAL_PRINT("AEQ MAPPING (FPD4) TABLE OPTIMIZATION");
        board.WriteI2C(Device_RX,0x40,0x38); // Select AEQ_SENS PAGE

        unsigned char AC_ATTEN_CORNER_HIGH_FREQ = 1;
        unsigned char VGA_BW_TUNE = 0;
        Value = (AC_ATTEN_CORNER_HIGH_FREQ<<6)+ (VGA_BW_TUNE<<4) ;

        board.WriteI2C(Device_RX,0x41,0x0e);
        board.WriteI2C(Device_RX,0x42,Value);
        board.WriteI2C(Device_RX,0x41,0x3e);
        board.WriteI2C(Device_RX,0x42,Value);

        unsigned char C_EQ2_BOOST = 1;
        unsigned char LF_BOOST = 0;
        Value = C_EQ2_BOOST << 4;
        Value = Value + LF_BOOST;

        board.WriteI2C(Device_RX,0x41,0x0f);
        board.WriteI2C(Device_RX,0x42,Value);
        board.WriteI2C(Device_RX,0x41,0x3f);
        board.WriteI2C(Device_RX,0x42,Value);

        unsigned char C_EQ3_BOOST = 1;
        LF_BOOST = 0;
        Value = C_EQ3_BOOST << 4;
        Value = Value + LF_BOOST;

        board.WriteI2C(Device_RX,0x41,0x10);
        board.WriteI2C(Device_RX,0x42,Value);
        board.WriteI2C(Device_RX,0x41,0x40);
        board.WriteI2C(Device_RX,0x42,Value);

        board.WriteI2C(Device_RX,0x41,0x69);
        board.WriteI2C(Device_RX,0x42,0xdd); //opt = 0xcc
        board.WriteI2C(Device_RX,0x41,0x6a);
        board.WriteI2C(Device_RX,0x42,0xdd); //opt = 0xcc
        board.WriteI2C(Device_RX,0x41,0x6b);
        board.WriteI2C(Device_RX,0x42,0xdd); //opt = 0xcc
        board.WriteI2C(Device_RX,0x41,0x6c);
        board.WriteI2C(Device_RX,0x42,0x0d); //opt = 0x0c
        unsigned char EQ_LSB = 2; //Opt=2
        unsigned char EQ_MSB = 2 << 3; //Opt=2
        board.WriteI2C(Device_RX,0x41,0x6d);
        board.WriteI2C(Device_RX,0x42,EQ_MSB+EQ_LSB);

        EQ_LSB = 2; //Opt=2
        EQ_MSB = 2 << 3; //Opt=2
        board.WriteI2C(Device_RX,0x41,0x6e);
        //board.WriteI2C(Device_RX,0x42,0x1a) //EFUSE & DEFAULT
        board.WriteI2C(Device_RX,0x42,EQ_MSB+EQ_LSB);


        EQ_LSB = 2; //Opt=2
        EQ_MSB = 3 << 3;  //Opt=2
        board.WriteI2C(Device_RX,0x41,0x6f);
        //board.WriteI2C(Device_RX,0x42,0x2c); //EFUSE & DEFAULT
        board.WriteI2C(Device_RX,0x42,EQ_MSB+EQ_LSB);


        EQ_LSB = 3; //Opt=2
        board.WriteI2C(Device_RX,0x41,0x70);
        //board.WriteI2C(Device_RX,0x42,0x05); //EFUSE & DEFAULT
        board.WriteI2C(Device_RX,0x42,EQ_LSB);


//        unsigned char Filter = 7; //3

        //unsigned char boost_lsb = Filter;
        //unsigned char boost_msb = Filter;
        //Value =(boost_msb<<3)+boost_lsb;
        board.WriteI2C(Device_RX,0x41,0x71);
        //board.WriteI2C(Device_RX,0x42,0x04); // DEFAULT
        board.WriteI2C(Device_RX,0x42,0x20); // TC3 EFUSE CHANGE

        //boost_lsb = Filter;
        //boost_msb = Filter;
        //Value = (boost_msb<<3)+boost_lsb;

        board.WriteI2C(Device_RX,0x42,0x29); // TC3 EFUSE CHANGE

        //boost_lsb = Filter;
        //boost_msb = Filter;
        //Value = (boost_msb<<3)+boost_lsb;
        board.WriteI2C(Device_RX,0x41,0x73);
        //board.WriteI2C(Device_RX,0x42,0x3f); // DEFAULT
        board.WriteI2C(Device_RX,0x42,0x32); // TC3 EFUSE CHANGE

        //boost_lsb = Filter;
        //boost_msb = Filter;
        //Value = (boost_msb<<3)+boost_lsb;
        board.WriteI2C(Device_RX,0x41,0x74);
        board.WriteI2C(Device_RX,0x42,0x07); // DEFAULT

        //boost_lsb = Filter;
        //boost_msb = Filter;
        //Value = (boost_msb<<3)+boost_lsb;
        board.WriteI2C(Device_RX,0x41,0x75);

        board.WriteI2C(Device_RX,0x42,0x3B); // New CHANGE
    }

    if (Bypass_LEVEL_SHIFTER == 0) {

        board.WriteI2C(Device_RX,0x40,23*4);
        board.WriteI2C(Device_RX,0x41,0x34); 
        board.WriteI2C(Device_RX,0x42,0xff); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
        board.WriteI2C(Device_RX,0x41,0x35);        
        board.WriteI2C(Device_RX,0x42,0x00); // fpd_rx_sel_thresh_m_9_8 //[3:2] 
        board.WriteI2C(Device_RX,0x41,0x34+0x80); 
        board.WriteI2C(Device_RX,0x42,0xff); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
        board.WriteI2C(Device_RX,0x41,0x35+0x80);        
        board.WriteI2C(Device_RX,0x42,0x00); // fpd_rx_sel_thresh_m_9_8 //[3:2]
    }

    if (Bypass_Echo_PI ==0)
    {

        REPLICA_RDAC(Device_RX, 0x1c, 0x1c);

        board.WriteI2C(Device_RX,0x40,0x10); // SELECT Analog RX PAG
        //Channel 0/1: ECHO_C_DAC=>[7]:RSRVD, [6:4]:pi_i_dac_lv<2:0>,[3]:RSRVD, [2:0]:CDAC"
        board.WriteI2C(Device_RX,0x41,0x0a);
        board.WriteI2C(Device_RX,0x42,0x04);  //MH=0x20 (BEST);
        board.WriteI2C(Device_RX,0x41,0x1a);
        board.WriteI2C(Device_RX,0x42,0x04);  //MH=0x20 (BEST);
    }

    if (Bypass_Post_Init_Reset == 0) {
        board.WriteI2C(Device_RX,0x1,0x1);
        board.sleep(0.1);
    }

    CRITICAL_PRINT("SWITCHING Main-Link RX from FPD3 to FPD4");

    board.WriteI2C(Device_RX,0x01,0x01);

    board.sleep(0.1);
    Value = board.ReadI2C(Device_RX,0x00);
    CRITICAL_PRINT("I2C Address Before Switch: 0x%x", (Value));

    unsigned char Value0 = board.ReadI2C(Device_RX,0x53);
    //Value0 = board.ReadI2C(Device_RX,0x53);
    //board.sleep(0.1);
    //Value0 = board.ReadI2C(Device_RX,0x53);
    board.WriteI2C(Device_RX,0x0E,0x12);
    unsigned char Value1 = board.ReadI2C(Device_RX,0x53);
    //Value1 = board.ReadI2C(Device_RX,0x53);
    board.sleep(0.1);
    Value1 = board.ReadI2C(Device_RX,0x53);

    CRITICAL_PRINT("Port 0 Lock Status: 0x%x Port1 Lock Status: 0x%x", Value0, (Value1));
    board.WriteI2C(Device_RX,0x0E,0x01);
    Value = board.ReadI2C(Device_RX,0x5F);

    CRITICAL_PRINT("984 BC_TX CLK Source (0x02=AON, 0x00=PLLRX): 0x%x", (Value));

    board.WriteI2C(Device_RX,0x0E,0x03);
    board.WriteI2C(Device_RX,0x5F,0x00); //BC AON OFF
    board.WriteI2C(Device_RX,0x0E,0x01);
    Value = board.ReadI2C(Device_RX,0x5F);

    CRITICAL_PRINT("984 FORCE BC_TX CLK Source (0x00=PLLRX): 0x%x", (Value));

    // board.WriteI2C(Device_RX,0x31,0x62) // Port 1 first
    // board.sleep(1)
    board.WriteI2C(Device_RX,0x31,0x63); // Port 0 next
    return 0;
}

int ti984_init_video()
{
    unsigned char Value;

    if ((Bypass_Link_Status == 0) && (FPD_MODE == 1))
    {

        i2c_set_slave_addr(board.fd, Device_RX_7bit, I2C_ADDRFMT_7BIT);
        board.device_address7bit = Device_RX_7bit;

        CRITICAL_PRINT("Main Link Status Registers:");
        board.WriteI2C(Device_RX,0x40,0x38); // SELECT AEQ_SNS PAGE
        board.WriteI2C(Device_RX,0x41,0x13);
        board.WriteI2C(Device_RX,0x42,0x1a); // [5]:aeq_sns_fsm_dbg_sel [4:0]:aeq_sns_dbg_sel[4:0]
        //board.WriteI2C(Device_RX,0x40,0x39); // READ
        board.WriteI2C(Device_RX,0x41,0x15); // [7:0]: aeq_sns_dbg_bus[15:8]
        unsigned char eq0 = (board.ReadI2C(Device_RX,0x42) >> 2);  // read and feedback to design for debug

        CRITICAL_PRINT("PORT0 EQ setting (AEQ_SNS Dbug_Reg)=0x%x", eq0);
        board.WriteI2C(Device_RX,0x40,0x38); // SELECT AEQ_SNS PAGE
        board.WriteI2C(Device_RX,0x41,0x43);
        board.WriteI2C(Device_RX,0x42,0x1a);
        //board.WriteI2C(Device_RX,0x40,0x39)
        board.WriteI2C(Device_RX,0x41,0x45);
        unsigned char eq1 = (board.ReadI2C(Device_RX,0x42) >> 2);  // read and feedback to design for debug

        CRITICAL_PRINT("PORT1 EQ setting (AEQ_SNS Dbug_Reg)=0x%x", eq1);
        board.WriteI2C(Device_RX,0x40,0x38);
        board.WriteI2C(Device_RX,0x41,0x2A);
        Value = board.ReadI2C(Device_RX,0x42);

        CRITICAL_PRINT("Port 0: AEQ Actual Start (DEC): 0x%x", Value & 0x3F);
        board.WriteI2C(Device_RX,0x41,0x5A);
        Value = board.ReadI2C(Device_RX,0x42);

        CRITICAL_PRINT("Port 1: AEQ Actual Start (DEC): 0x%x", Value & 0x3F);

        board.WriteI2C(Device_RX,0x40,0x54); // SELECT TOCCOA0 PAGE
        board.WriteI2C(Device_RX,0x41,0xFF);

        board.WriteI2C(Device_RX,0x40,0x58); // SELECT TOCCOA1 PAGE
        board.WriteI2C(Device_RX,0x41,0xFF);

        board.WriteI2C(Device_RX,0x40,0x38);
        board.WriteI2C(Device_RX,0x41,0x13);
        board.WriteI2C(Device_RX,0x42,0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
        board.WriteI2C(Device_RX,0x41,0x14);
        Value = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x41,0x43);
        board.WriteI2C(Device_RX,0x42,0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
        board.WriteI2C(Device_RX,0x41,0x44);
        Value = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x40,0x54); // TOCCOA PAGE 0
        board.WriteI2C(Device_RX,0x41,0x51);
        board.WriteI2C(Device_RX,0x42,0xA0); // Snapshot selects the VGA
        board.WriteI2C(Device_RX,0x41,0x13);
        board.WriteI2C(Device_RX,0x42,0x08); // Capture the data
        board.WriteI2C(Device_RX,0x41,0xF2);
        Value = board.ReadI2C(Device_RX, 0x42);
        unsigned char Value_Adaptive_VGA = Value & 0x0F;
        unsigned char Value_VGA_Sweep_END = (Value >> 4) & 0x0F;

        board.WriteI2C(Device_RX,0x40,0x58); // TOCCOA PAGE 1
        board.WriteI2C(Device_RX,0x41,0x51);
        board.WriteI2C(Device_RX,0x42,0xA0); // Snapshot selects the VGA
        board.WriteI2C(Device_RX,0x41,0x13);
        board.WriteI2C(Device_RX,0x42,0x08); // Capture the data
        board.WriteI2C(Device_RX,0x41,0xF2);
        Value = board.ReadI2C(Device_RX, 0x42);
        Value_Adaptive_VGA = Value & 0x0F;
        Value_VGA_Sweep_END = (Value >> 4) & 0x0F;

        (void)Value_Adaptive_VGA;
        (void)Value_VGA_Sweep_END;

        board.WriteI2C(Device_RX,0x40,0x54); // SELECT TOCCOA0 PAGE
        board.WriteI2C(Device_RX,0x41,0x2D);

        board.WriteI2C(Device_RX,0x41,0x4b);
        Value = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x40,0x58); // SELECT TOCCOA1 PAGE
        board.WriteI2C(Device_RX,0x41,0x2D);

        board.WriteI2C(Device_RX,0x41,0x4b);
        Value = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x40,0x5c); // SELECT TOCCOA P0 & P1
        board.WriteI2C(Device_RX,0x41,0x1c);
        //unsigned char e_offset0 = board.ReadI2C(Device_RX,0x42); // Error Offset Value
        board.WriteI2C(Device_RX,0x40,0x5c);
        board.WriteI2C(Device_RX,0x41,0x1e);
        //unsigned char q_offset0 = board.ReadI2C(Device_RX,0x42); // Q_Offset Value

        board.WriteI2C(Device_RX,0x40,0x5c); // SELECT TOCCOA P0 & P1
        board.WriteI2C(Device_RX,0x41,0x9c);
        //unsigned char e_offset1 = board.ReadI2C(Device_RX,0x42); // Error Offset Value
        board.WriteI2C(Device_RX,0x40,0x5c);
        board.WriteI2C(Device_RX,0x41,0x9e);
        //unsigned char q_offset1 = board.ReadI2C(Device_RX,0x42); // Q_Offset Value

        // Channel 0 Check
        board.WriteI2C(Device_RX,0x0E,0x1);
        // CLEAR CRC Erros 

        CRITICAL_PRINT("Clearing CRC port 0");

        board.WriteI2C(Device_RX,0x05,0xE0);
        board.WriteI2C(Device_RX,0x05,0xC0); // Clear CRC
        // CLEAR FC CRC Erros FPD_RX

        // Clear Flags by Reading
        board.ReadI2C(Device_RX,0x3C); //DCA_DET_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3D); //DCA_CRC_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3E); //DCA_8b10b_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3F); //ECC_ERR_CNTR_P0/P1
        unsigned char Val = board.ReadI2C(Device_RX,0x53);
        //board.sleep(0.1);
        //Val = board.ReadI2C(Device_RX,0x53);
        board.sleep(0.1);
        Val = board.ReadI2C(Device_RX,0x53);
        CRITICAL_PRINT("Lock Status (REG 0x53): 0x%x", (Val));
        CRITICAL_PRINT ("REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
        CRITICAL_PRINT("FPD Error Conters (REG 0x3B): 0x%x", (board.ReadI2C(Device_RX,0x3B)));
        CRITICAL_PRINT ("REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

        //Val = board.ReadI2C(Device_RX,0x54);
        //board.ReadI2C(Device_RX,0x09);
        //board.sleep(0.1);
        //Val = board.ReadI2C(Device_RX,0x54);
        //board.ReadI2C(Device_RX,0x09);
        //board.sleep(0.1);
        Val = 0;
        Val = board.ReadI2C(Device_RX,0x54);
        board.ReadI2C(Device_RX,0x09);
        //print "Lock Status (REG 0x54): ", hex(Val)
        CRITICAL_PRINT("Lock Status (REG 0x54): 0x%x", (Val));
        CRITICAL_PRINT ("REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");

        CRITICAL_PRINT ("FC CRC Error (MSB+LSB): 0x%x", ((board.ReadI2C(Device_RX,0x6B)<<4) + board.ReadI2C(Device_RX,0x6A)));
        CRITICAL_PRINT ("FC CRC Error FLAG: 0x%x", board.ReadI2C(Device_RX,0x09)>>6 & 0x01);


        // Channel 1 Check
        board.WriteI2C(Device_RX,0x0E,0x12);
        // CLEAR BC CRC Erros on Daisy BC_RX
        CRITICAL_PRINT ("////////# Port 1 #####");
        board.WriteI2C(Device_RX,0x05,0xE0);
        board.WriteI2C(Device_RX,0x05,0xC0); // Clear CRC
        // CLEAR FC CRC Erros FPD_RX

        // Clear Flags by Reading
        board.ReadI2C(Device_RX,0x3C); //DCA_DET_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3D); //DCA_CRC_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3E); //DCA_8b10b_ERR_CNTR_P0/P1
        board.ReadI2C(Device_RX,0x3F); //ECC_ERR_CNTR_P0/P1
        Val = board.ReadI2C(Device_RX,0x53);
        //board.sleep(0.1);
        //Val = board.ReadI2C(Device_RX,0x53);
        board.sleep(0.1);
        Val = board.ReadI2C(Device_RX,0x53);
        CRITICAL_PRINT ("Lock Status (REG 0x53): 0x%x", (Val));
        CRITICAL_PRINT ("REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
        CRITICAL_PRINT ("FPD Error Conters (REG 0x3B): 0x%x", (board.ReadI2C(Device_RX,0x3B)));
        CRITICAL_PRINT ("REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

        //Val = board.ReadI2C(Device_RX,0x54);
        //board.ReadI2C(Device_RX,0x09);
        //board.sleep(0.1);
        //Val = board.ReadI2C(Device_RX,0x54);
        //board.ReadI2C(Device_RX,0x09);
        //board.sleep(0.1);
        Val = board.ReadI2C(Device_RX,0x54);
        board.ReadI2C(Device_RX,0x09);
        CRITICAL_PRINT ("Lock Status (REG 0x54): 0x%x", (Val));
        CRITICAL_PRINT ("REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");

        CRITICAL_PRINT ("FC CRC Error (MSB+LSB): 0x%x", ((board.ReadI2C(Device_RX,0x6B)<<4) + board.ReadI2C(Device_RX,0x6A)));
        CRITICAL_PRINT ("FC CRC Error FLAG: 0x%x", ((board.ReadI2C(Device_RX,0x09)>>6) & 0x01));


        board.WriteI2C(Device_RX,0x40,0x54);
        board.WriteI2C(Device_RX,0x41,0x12); // Snapshot select
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x13); // Take the snapshot
        board.WriteI2C(Device_RX,0x42,0x08);
        board.WriteI2C(Device_RX,0x41,0xDF);
        unsigned char MSB_CDR = board.ReadI2C(Device_RX,0x42);
        unsigned char MSB_BIT = (MSB_CDR >> 7) & 0x01;
        board.WriteI2C(Device_RX,0x41,0xE0);
        unsigned char LSB_CDR = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x40,0x58);
        board.WriteI2C(Device_RX,0x41,0x12); // Snapshot select
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x13); // Take the snapshot
        board.WriteI2C(Device_RX,0x42,0x08);
        board.WriteI2C(Device_RX,0x41,0xDF);
        MSB_CDR = board.ReadI2C(Device_RX,0x42);
        MSB_BIT = (MSB_CDR >> 7) & 0x01;
        board.WriteI2C(Device_RX,0x41,0xE0);
        LSB_CDR = board.ReadI2C(Device_RX,0x42);

        board.WriteI2C(Device_RX,0x40,0x08);
        board.WriteI2C(Device_RX,0x41,0x07);
        Value = board.ReadI2C(Device_RX,0x42);
        CRITICAL_PRINT ("PLL_RX_LOCK: 0x%x PLL_VCNTRL_HIGH=0x%x PLL_VCNTL_LOW: 0x%x",Value & 0x01,(Value >> 4) & 0x01,  (Value >> 3) & 0x01);
        (void)LSB_CDR;
        (void)MSB_BIT;

    }
    if (Bypass_CHECK_ALIGNMNET == 0) {
        //print ""
        //print "CHECKING ALIGNMENT of Analog DES"
        CHECK_ALIGNMENT (Device_RX);
    }

    if (Bypass_DFE_Monitors ==0)
    {
        DFE_TAP1_SNAPSHOT (Device_RX, 1);
        DFE_REF0_SNAPSHOT (Device_RX, 1);
        DFE_REF1_SNAPSHOT (Device_RX, 1);

        //print""
        board.WriteI2C(Device_RX,0x41,0x12); // Snapshot select
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x13); // Take the snapshot
        board.WriteI2C(Device_RX,0x42,0x08);
        board.WriteI2C(Device_RX,0x41,0xDF);
        unsigned int Value_MSB = board.ReadI2C(Device_RX,0x42) << 8;
        board.WriteI2C(Device_RX,0x41,0xE0);
        CRITICAL_PRINT ("Port0: CDR_FQ (PPM): 0x%x", Value_MSB + board.ReadI2C(Device_RX,0x42));

        // board.WriteI2C(Device_RX,0x41,0x02) // ref_cntrl + DFE
        // board.WriteI2C(Device_RX,0x42,0x82)

        board.WriteI2C(Device_RX,0x41,0x12); // Snapshot select
        board.WriteI2C(Device_RX,0x42,0x00);
        board.WriteI2C(Device_RX,0x41,0x13); // Take the snapshot
        board.WriteI2C(Device_RX,0x42,0x08);
        board.WriteI2C(Device_RX,0x41,0xDF);
        Value_MSB = board.ReadI2C(Device_RX,0x42) << 8;
        board.WriteI2C(Device_RX,0x41,0xE0);
        CRITICAL_PRINT ("Port1: CDR_FQ (PPM): 0x%x", Value_MSB + board.ReadI2C(Device_RX,0x42));
    }

    if (Bypass_Display_Panel == 0)
    {

        if (DES_1_Video_ON == 1)
        {
            CRITICAL_PRINT ("Hold DTG In Reset");
            board.WriteI2C(Device_RX,0x40,80);
            board.WriteI2C(Device_RX,0x41,0x32+0);
            board.WriteI2C(Device_RX,0x42,0x02);
            board.WriteI2C(Device_RX,0x41,0x32+0x30);
            board.WriteI2C(Device_RX,0x42,0x02);

            board.WriteI2C(Device_RX,0x0E,0x01);
            Value = board.ReadI2C(Device_RX, 0x00);
            CRITICAL_PRINT ("DES_1 I2C Adress Aquired: 0x%x", (Value));

            if (Value == 0)
            {
                board.WriteI2C(Device_RX,0x0E,0x01);
                Value = board.ReadI2C(Device_RX, 0x00);
                CRITICAL_PRINT( "DES_1 I2C Adress Aquired: 0x%x", (Value));
            }

             board.WriteI2C(Device_TX,0x40,0x30);
            // Enable patgen
            // board.WriteI2C(Device_TX,0x41,0x68)
            // board.WriteI2C(Device_TX,0x42,0x51) //vertical black to white
            //Enable patgen
            //board.WriteI2C(Device_TX,0x41,0x28);
            // board.WriteI2C(Device_TX,0x42,0x6D); //Color Bar Pattern
            if (Value != 0)
            {
                if (device == 984)
                {
                    int DP_Rate = DP_VIDEO_SETUP (Device_RX, Force_Rate_DP_DES_1, Force_Speed_DP_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, DES_1_link_speed);//(DEV_ADDR, Force_DP_Rate, DP_FORCE_RATE, DP0_ON, DP1_ON, DES_HOP, LINK_SPEED)
                    (void)DP_Rate;
                    //int video_clk_freq = (PCLK_FREQ*1000);   //  148500 // in kHz
                    //int dp_tx_rate = DP_Rate; // example case
                    //int dp_mvalue = (video_clk_freq);
                    //int dp_nvalue = dp_tx_rate * 400;
                    int HTOTAL;
                    //VIDEO_LINK_LAYER_SETUP (Device_RX, bits_per_color, 1)
                    Value = VIDEO_CRC_CHECK_LOOP (Device_RX, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984);
                    //HTOTAL = ENABLE_DISPLAY (Device_RX, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1) //(DEV_ADDR, DISPLAY_Port0_En, DISPLAY_Port1_En, DES, DEVICE_TYPE, DTG_TOGGLE
                    if (Value == 1) {
                        VIDEO_LINK_LAYER_SETUP (Device_RX, bits_per_color, 1); // Enable DC on Previous Device
                        HTOTAL = ENABLE_DISPLAY (Device_RX, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1); //(DEV_ADDR, DISPLAY_Port0_En, DISPLAY_Port1_En, DES, DEVICE_TYPE, DTG_TOGGLE)
                        if ((HTOTAL < (THW-10)) || (HTOTAL > (THW+10))) {
                            CRITICAL_PRINT( "VIDEO NOT MEASURED CORRECTY! - Applying RESET");
                            board.WriteI2C(Device_RX,0x01,0x01);
                            board.sleep(0.5);
                            VIDEO_LINK_LAYER_SETUP (Device_RX, bits_per_color, 1); // Enable DC on Previous Device
                            Value = VIDEO_CRC_CHECK_LOOP (Device_RX, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984);
                            HTOTAL = ENABLE_DISPLAY (Device_RX, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1);
                        }
                    }
                    else
                    {
                        CRITICAL_PRINT( "Apply Reset to ALL Links and Re-do Stream Mapping");
                        board.WriteI2C(Device_RX,0x01,0x01);
                        board.sleep(0.5);
                        VIDEO_LINK_LAYER_SETUP (Device_RX, bits_per_color, 1); // Enable DC on Previous Device
                        Value = VIDEO_CRC_CHECK_LOOP (Device_RX, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984);
                        HTOTAL = ENABLE_DISPLAY (Device_RX, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1);
                        if ((HTOTAL < (THW-10)) || (HTOTAL > (THW+10))) {
                            CRITICAL_PRINT ( "VIDEO NOT MEASURED CORRECTY! - Applying RESET");
                            board.WriteI2C(Device_RX,0x01,0x01);
                            board.sleep(0.5);
                            VIDEO_LINK_LAYER_SETUP (Device_RX, bits_per_color, 1); // Enable DC on Previous Device
                            Value = VIDEO_CRC_CHECK_LOOP (Device_RX, VIDEO_CHECK_ENABLE_DES_1, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984);
                            HTOTAL = ENABLE_DISPLAY (Device_RX, DES_1_DP_PORT_0, DES_1_DP_PORT_1, 1, 984, 1);
                        }
                    }
                    CRITICAL_PRINT( "Turning Off FSM Test MUXES DES_1");
                    board.WriteI2C(Device_RX,0x40,0x3C); // Select DFT Page
                    board.WriteI2C(Device_RX,0x41,0x00);
                    board.WriteI2C(Device_RX,0x42,0x00);
                    board.WriteI2C(Device_RX,0x41,0x01);
                    board.WriteI2C(Device_RX,0x42,0x00);
                    board.WriteI2C(Device_RX,0x41,0x02);
                    board.WriteI2C(Device_RX,0x42,0x00);
                    apb_write_reg(0x084, 0x01, (0), Device_RX);
                    //apb_write_reg(0x084, 0x01, int(1), Device_RX)
                    // apb_write_reg(0x90, 1, int(0), Device_RX) 
                    // apb_write_reg(0x90, 1, int(1), Device_RX)
                    //board.sleep(1.5);
                    //board.WriteI2C(Device_RX,0x1,0x40);
                }
            }
        }
    }
    return 0; 

}

int VGA_THRESHOLDS_ADJUST (unsigned char DEVICE_ADR, unsigned short LOW_THR, unsigned short HIGH_THR, unsigned char VGA_SWEEP_THR, int PORT)
{
    unsigned char Reg = 0;
    if (PORT == 0)
        Reg = 0x54;
    else if (PORT == 1)
        Reg = 0x58;

    board.WriteI2C(Device_RX,0x40,Reg); //
    board.WriteI2C(Device_RX,0x41,0x2B);
    board.WriteI2C(Device_RX,0x42,VGA_SWEEP_THR);

    //LOW_THR = 14 //0x14=20(Dec)
    unsigned char Value_54 = (LOW_THR >>4) & 0x3;
    unsigned char Value_30 = (LOW_THR & 0x0F);
    board.WriteI2C(DEVICE_ADR,0x40,Reg); //  PAGE Select
    board.WriteI2C(DEVICE_ADR,0x41,0x7B);
    board.WriteI2C(DEVICE_ADR,0x42,Value_30<<4); // LOW VGA THRESHOLD
    board.WriteI2C(DEVICE_ADR,0x41,0x7A);
    board.WriteI2C(DEVICE_ADR,0x42,Value_54<<4); // LOW VGA THRESHOLD

    // HIGH_THR = 24 // 0x37=55 (55 DEC * 6.5mV) =Default
    board.WriteI2C(DEVICE_ADR,0x40,Reg); //  PAGE Select
    board.WriteI2C(DEVICE_ADR,0x41,0x89); // VGA HIGH THRESHOLD [5:0] => Default 0x37
    //board.WriteI2C(Device_RX,0x42,0x37) // DEFAULT
    board.WriteI2C(DEVICE_ADR,0x42,HIGH_THR); // Proposed

    return 0;
}

int REPLICA_RDAC(unsigned char DEVIDE_ADR, unsigned char CH0_RDAC, unsigned char CH1_RDAC)
{
    //Echo Canceller Setting and PI
    //print "ECHO-R_DAC Optimization"
    board.WriteI2C(DEVIDE_ADR,0x40,23*4); //Page TOC 0 & 1
    board.WriteI2C(DEVIDE_ADR,0x41,0x26);
    board.WriteI2C(DEVIDE_ADR,0x42,CH0_RDAC); //fpd_rx_rep_rdac_en [5:0]
    board.WriteI2C(DEVIDE_ADR,0x41,0xA6);
    board.WriteI2C(DEVIDE_ADR,0x42,CH1_RDAC); //fpd_rx_rep_rdac_en [5:0]
    return 0;
}

//used for link lost recovery init
BridgeChip_StatusType recovery_ti983_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT("Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);

    CRITICAL_PRINT("Link setup to FPD-Link III mode");

	eStatus = ti983_fpdlink3_init();

    return eStatus;
}

BridgeChip_StatusType recovery_ti983_fpd4_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	int i;
    CRITICAL_PRINT("Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

	eStatus = (BridgeChip_StatusType)(eStatus | ti984_init_switch_fpd4());
	eStatus = (BridgeChip_StatusType)(eStatus | ti983_init_switch_fpd4());		
	for (i = 0; i < 5; i++) {
	board.sleep(0.1);
	board.WriteI2C(Device_TX,0x2D, 0x01);
	unsigned char Value= board.ReadI2C(Device_TX,0x0c);
	CRITICAL_PRINT("Port0: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x  LINK_DETECT: 0x%x",(Value >>4)&0x01, (Value >>1)&0x01, (Value & 0x01));
	board.WriteI2C(Device_TX,0x2D, 0x12);
	unsigned char Value2= board.ReadI2C(Device_TX,0x0c);
	CRITICAL_PRINT("Port1: LINK_LOST_FLAG:0x%x BC_CRC_ERROR_FLAG:0x%x LINK_DETECT: 0x%x",(Value2 >>4)&0x01,(Value2 >>1)&0x01,(Value2 & 0x01));
	CRITICAL_PRINT( "===>DES ID=0x%x", board.ReadI2C(Device_TX,0x08));

	if ((Value & 0x01) && (Value2 & 0x01))
		break;
	}
	board.WriteI2C(Device_TX,0x2D, 0x01);
	apb_write_reg(0xa18, 0x5, 0, Device_TX);
	
    return eStatus;
}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

void display_state_notify(char *display_state)
{
    LOG_CRITICAL_INFO(MODULE_NAME, "IPC display_state %s \n", display_state);
    screen_pwr_data_t msg;
    int server_coid;
    
    if(0 == strcmp(display_state,"ready")) {
        msg.data = VCD_DISP_STATE_READY;
    } else if (0 == strcmp(display_state,"lost")) { 
        msg.data = VCD_DISP_STATE_LOST;
    } else {
        LOG_CRITICAL_INFO(MODULE_NAME, "IPC display_state invalid agr\n");
        return;
    }
    if ((server_coid = name_open(DISP_STATE_ATTACH_POINT, 0)) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "name open %s failed, error %d(%s)",
                            DISP_STATE_ATTACH_POINT, server_coid, strerror(errno));
        return;
    }
    // We would have pre-defined data to stuff here
    msg.hdr.type = 0x00;
    msg.hdr.subtype = 0x00;
    if (MsgSend(server_coid, &msg, sizeof(msg), NULL, 0) == -1) {
        LOG_CRITICAL_INFO(MODULE_NAME, "IPC  MsgSend error\n");
        goto fail;
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "display_state_notify Done\n");
fail:
    name_close(server_coid);
    return;
}

int BridgeChip_pdb_control(char *pdb_path, unsigned char val)
{

    FILE *pdb_fp;
    int ret_val;
    pdb_fp = fopen (pdb_path, "r+");
    if (pdb_fp == NULL) {
        LOG_CRITICAL_INFO(MODULE_NAME, "open %s fail", pdb_path);
        return -1;
    }
    else{
        LOG_CRITICAL_INFO(MODULE_NAME, "-> 0x%x", val);
        rewind(pdb_fp);
        ret_val = fprintf(pdb_fp, "%x", val);
        if(ret_val != sizeof(unsigned char)) {
            LOG_CRITICAL_INFO(MODULE_NAME, "write %s fail", pdb_path);
            fflush(pdb_fp);
			fclose(pdb_fp);
            return -1;
        }
        fflush(pdb_fp);
        fclose(pdb_fp);
        BridgeChip_OSAL_SleepMs(10);
    }
    return 0;
}

BridgeChip_StatusType display_power_ctl(int32 enable)
{
    char cmd_value[8];
    int fh;
    int ret;

    LOG_CRITICAL_INFO(MODULE_NAME, "Enter %s\n", __func__);
    memset (cmd_value, 0, sizeof(cmd_value));
    if (enable == DISPLAY_WKUP_CTRL_ON) 
        strcpy(cmd_value, "on");
    else if (enable == DISPLAY_WKUP_CTRL_OFF)
        strcpy(cmd_value, "off");
    else {
        LOG_CRITICAL_INFO(MODULE_NAME, "unknow power mode setting");
        return BRIDGECHIP_STATUS_FAILED;
    }

	fh = displaywakeup_status_open(DISP_INFRAS_WKUP_CTRL_PATH);
	if (fh < 0) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Could get access to status devnode: %s, error=%d", 
                            DISP_INFRAS_WKUP_CTRL_PATH, fh);
		return BRIDGECHIP_STATUS_FAILED;
	}

	ret = displaywakeup_ctrl_set(fh, "online", DISP_INFRAS_WKUP_CTRL_ONLINE);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME, "Couldn't switch to online");
		goto fail;
	}
	ret = displaywakeup_ctrl_set(fh, DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
	if (ret) {
		LOG_CRITICAL_INFO(MODULE_NAME,"Couldn't set chain <%s> state to %s", DISP_INFRAS_WKUP_CTRL_NAME, cmd_value);
		goto fail;
	}
    displaywakeup_status_close(fh);
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s\n", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;

fail:
    displaywakeup_status_close(fh);
    return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType disp_infras_display_chain_recovery(int32 i2c_fh, int32 state)
{
    //TODO: need check return value of each functions
    if (DISPLAY_CHAIN_CTRL_OFF == state) {
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s OFF", __func__);
        display_state_notify("lost");
        display_power_ctl(DISPLAY_WKUP_CTRL_OFF);
    } else if (DISPLAY_CHAIN_CTRL_ON == state) {
        int i;
        LOG_CRITICAL_INFO(MODULE_NAME, "call %s ON", __func__);
        display_power_ctl(DISPLAY_WKUP_CTRL_ON);
        (void)usleep(500*1000); // delay 500ms for display ready. TODO: need be adjust for final display HW
        set_reset_keep_dprx(1);

        recovery_ti983_fpd3_init(i2c_fh);
        // check 180s to wait display linkup again
        for (i = 0; i < RECOVERY_CHECKLINK_LOOP_TIMES; i++) {
            (void)usleep(RECOVERY_CHECKLINK_INTERVAL_MS*1000);

            // linkup : display powered on
            if ((get_983_link_status() == BRIDGECHIP_STATUS_SUCCESS)) {
                    //do switch over for 983 and 984
                    if(recovery_ti983_fpd4_init(i2c_fh) == BRIDGECHIP_STATUS_SUCCESS){
						break;
					}else{
						LOG_CRITICAL_INFO(CHIP_ID, "recovery_ti983_fpd4_init(i2c_fh) failed\n");
					}
            }
        }

        if (i == RECOVERY_CHECKLINK_LOOP_TIMES) {
            //timeout: last chance to do switch over for 983 and 984
            recovery_ti983_fpd4_init(i2c_fh);
        }

        set_reset_keep_dprx(0);
    }
    LOG_CRITICAL_INFO(MODULE_NAME, "Exit %s", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;
}






