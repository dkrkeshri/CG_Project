#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT   0x0C
#define DES_ID_7BIT   0x2C
#define MCU_ID_7BIT   0x12

#define SER_ID_8BIT   (SER_ID_7BIT << 1)
#define DES_ID_8BIT   (DES_ID_7BIT << 1)
#define MCU_ID_8BIT   (MCU_ID_7BIT << 1)

// Panel Timings
#define THW               854   // Total horizontal
#define TVW               488    // Total vertical
#define AHW               800   // Active horizontal
#define AVW               480    // Active vertical
#define HBP               22     // Horizontal back porch
#define VBP               4      // Vertical back porch
#define HSW               12     // Horizontal sync width
#define VSW               2      // Vertical sync width
#define VFP               2      // Vertical front porch
#define MDIV              2430   // M Divider

#define GENERAL_STS_MASK   0x5B
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define BIST_CRC_ERROR_BIT 3
#define BC_CRC_ERROR_BIT   1
#define LINK_DETECT_BIT    0

static int32 verbosedebug = 1;
static int32 reset_keep_dsi = 0;
#define MODULE_NAME "SER-DES TOPOLOGY-45-HUD3_1"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (1) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    DEBUG_PRINT(MODULE_NAME, "%s Reg: 0x%x Data: 0x%x", __func__, reg, val);
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "%s 0x%x : 0x%x", __func__, reg, val);
        LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
    }
    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1){
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
    }
    return 0;
}


static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Backlight", __func__);
    write_reg(fd, 0x03, 0x00);
    (void)usleep(20*1000);
    write_reg(fd, 0x20, 0x03);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_981_fpd3(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Set 981 to FPD-LINK III Mode..........", __func__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01); //Select port   0
    write_reg(fd, 0x70, 0x58); //slave ID port 0
    write_reg(fd, 0x78, 0x58); //slave alias port 0, bit 0 = 0 to map over FPD Port 0
    write_reg(fd, 0x71, 0x24);  //slave ID port 1 // MCU 8-bit slave address
    write_reg(fd, 0x79, 0x24); //slave alias port 1
    write_reg(fd, 0x05, 0x00);
    write_reg(fd, 0x59, 0x01);  //Forced single mode
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xE0);
    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x5B, 0x2B); //Enable FPD3 FIFO
    write_reg(fd, 0x07, 0x88);
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable I2C Passthrough..........", __func__);
    return BRIDGECHIP_STATUS_SUCCESS;
}

static bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;

    if (read_reg(fd, 0x00, &regval) == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", __func__, regval, chipId);
        if (regval == chipId)
            return TRUE;
        else
            return FALSE;
    } else {
        return FALSE;
    }
}

static BridgeChip_StatusType link_convert_988_fpd3_to_fpd4(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "%s: Disable DES0 OLDI", __func__);
    write_reg(fd, 0x40, 0x2C);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00);

    /* Change des_id_remote0 PLL to FPD4 settings */
    CRITICAL_PRINT(MODULE_NAME, "%s: Change DES_ID_REMOTE0 PLL to FPD4 settings", __func__);
    write_reg(fd, 0x40, 0x38);//weller not match hud3
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x0f);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0x64);
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0xb0);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0xb0);
    write_reg(fd, 0x01, 0x01);
    CRITICAL_PRINT(MODULE_NAME, "%s: Reset Receiver", __func__);
    serdes_wait_ser_fpd_linkup(fd, 400);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read receiver", __func__);
    if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Program FPD4 PLL to 3.375 GHz on VCO", __func__);
        write_reg(fd, 0x40, 0x08);
        write_reg(fd, 0x41, 0x05);
        write_reg(fd, 0x42, 0x7d);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x90);
        write_reg(fd, 0x0e, 0x03);
        write_reg(fd, 0x61, 0x09);
        write_reg(fd, 0x95, 0x06);
        write_reg(fd, 0x60, 0x0F);
        write_reg(fd, 0x40, 0x56);
        write_reg(fd, 0x41, 0x34);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0x35);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0xB4);
        write_reg(fd, 0x42, 0xff);
        write_reg(fd, 0x41, 0xB5);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x33, 0x05);
        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x05);
        write_reg(fd, 0x01, 0x01);
        CRITICAL_PRINT(MODULE_NAME, "%s: Issue a software reset to get the receiver PLL setting loaded", __func__);
        serdes_wait_ser_fpd_linkup(fd, 400);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
        CRITICAL_PRINT(MODULE_NAME, "%s: Check if we can read receiver before writing FPD4 Settings", __func__);
        if (TRUE == check_98x_chipid(fd, DES_ID_8BIT))
        {
            CRITICAL_PRINT(MODULE_NAME, "%s: End reprogramming FPD3 -> FPD4 settings", __func__);
            CRITICAL_PRINT(MODULE_NAME, "%s: Now to switch to FPD4 on 988.  Link will be lost momentarily.", __func__);
            write_reg(fd, 0x0e, 0x03);
            write_reg(fd, 0x5f, 0x00);
            write_reg(fd, 0x31, 0x67);
        }
        else
        {
            CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read receiver.  Increase delay prior to continuing program flow", __func__);
            return BRIDGECHIP_STATUS_FAILED;
        }
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "%s: Warning: Could not read receiver.  Increase delay prior to continuing program flow", __func__);
        return BRIDGECHIP_STATUS_FAILED;
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_988_enable_oldi(int32 fd)
{
    /* Port 0 HUD OLDI */

    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    write_reg(fd,0xd0,0xc); //
    write_reg(fd,0xd7,0x0); //

    CRITICAL_PRINT(MODULE_NAME, "Config OLDI ");
    write_reg(fd,0x40,0x2C); // #Page11_oLDI register
    write_reg(fd,0x41,0x00); //
    write_reg(fd,0x42,0x2B); //
    write_reg(fd,0x41,0x01); //
    write_reg(fd,0x42,0x2F); //
    write_reg(fd,0x40,0x2C); //
    write_reg(fd,0x41,0x18); // #PLL_NDIV
    write_reg(fd,0x42,0x33); //#1E
    write_reg(fd,0x41,0x0a); // #oLDI_PLL_DIG3
    write_reg(fd,0x42,0x6D); //
    write_reg(fd,0x41,0x09); // #oLDI_PLL_DIG2
    write_reg(fd,0x42,0xB5); //
    write_reg(fd,0x41,0x08); // #oLDI_PLL_DIG1
    write_reg(fd,0x42,0xDC); //
    write_reg(fd,0x41,0x0b); // #oLDI_PLL_DIG4
    write_reg(fd,0x42,0xFF); //
    write_reg(fd,0x41,0x0C); // #oLDI_PLL_DIG5
    write_reg(fd,0x42,0xFA); //
    write_reg(fd,0x41,0x0D); // #oLDI_PLL_DIG6
    write_reg(fd,0x42,0x27); //
    write_reg(fd,0x41,0x2D); //
    write_reg(fd,0x42,0x13); //

    //# modified soft reset to oldi reset
    write_reg(fd,0x1,0x40); // # OLDI PLL RESET

    //# Enable OLDI"
    write_reg(fd,0x40,0x2c); // #Page11_OLDI Control
    write_reg(fd,0x41,0x02); //
    write_reg(fd,0x42,0x10); //

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_981_fpd4(int32 fd)
{
    uint8 RevId = 0;
    read_reg(fd, 0x30, &RevId);
    /* DSI config */
    CRITICAL_PRINT(MODULE_NAME, "%s: Configure DSI Port0", __func__);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x02, 0xD8);
    if ((RevId & 0xF0) >= 0x20)
    {
        write_reg(fd, 0x4F, 0x81);
    }
    else
    {
        write_reg(fd, 0x4F, 0x80);
    }
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x8F, 0x01);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x08);
    CRITICAL_PRINT(MODULE_NAME, "%s: Now switching 981 to FPD4 mode", __func__);
    if ((RevId & 0xF0) == 0x20)
    {
        write_reg(fd, 0x6E, 0x80);
    }
    write_reg(fd, 0x5B, 0x23);
    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x6a, 0x0a);
    //    write_reg(fd, 0x59, 0x05);
    write_reg(fd, 0x05, 0x14);
    //    write_reg(fd, 0x02, 0xd1);
    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    //    write_reg(fd, 0x41, 0x94);
    //    write_reg(fd, 0x42, 0x02);

    CRITICAL_PRINT(MODULE_NAME, "%s: Program PLL Settings", __func__);
    write_reg(fd, 0x43, 0x00);  // enable 1 stream
    /* 981 PLL programming */
    CRITICAL_PRINT(MODULE_NAME, "%s: Properly program back channel", __func__);

    write_reg(fd, 0x2d, 0x03);
    write_reg(fd, 0x6a, 0x04);
    write_reg(fd, 0x05, 0x3C);


    CRITICAL_PRINT(MODULE_NAME, "%s: Program PLL0 Settings", __func__);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7d);
    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xA0);
    write_reg(fd, 0x41, 0x1b);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5b);
    write_reg(fd, 0x42, 0x00);
    CRITICAL_PRINT(MODULE_NAME, "%s: Software reset 981", __func__);
    write_reg(fd, 0x01, 0x01);
    (void)usleep(10*1000);

    CRITICAL_PRINT(MODULE_NAME, "%s: End of FPD3 to FPD4 Conversion", __func__);

    CRITICAL_PRINT(MODULE_NAME, "Configure vp0 and patgen", __func__);
    write_reg(fd, 0x2D, 0x01); // select port 0 TX

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME, "Configure VP0");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); // program h_act
    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP)); //program v front porch

    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(MDIV));
    write_reg(fd, 0x42, upper_byte(MDIV)); // set M divider
    write_reg(fd, 0x42, 0x0F); // set N divider
    /*
       CRITICAL_PRINT(MODULE_NAME, "Enable Patgen", __func__);
       write_reg(fd, 0x40, 0x30);
       write_reg(fd, 0x41, 0x28);
       write_reg(fd, 0x42, 0x91);
       write_reg(fd, 0x41, 0x29);
       write_reg(fd, 0x42, 0x08);
       */
    //DPHY P0 Settings
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x2A);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x21);
    write_reg(fd, 0x41, 0x21);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0xBD, 0x00);

    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Video processor stream", __func__);
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x01); //
    write_reg(fd, 0x42, 0x01); // enable stream 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00); // map stream 0 to VP0
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x3C); // set 60 time slots
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    write_reg(fd, 0x02, 0xF0);
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x2D, 0x01);
    if (reset_keep_dsi)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    write_reg(fd, 0x43, 0x00); // enable VP0
    write_reg(fd, 0x44, 0x01); // enable VP0

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "%s: Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ", __func__);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_981_fpd3(fd);
    CRITICAL_PRINT(MODULE_NAME, "link_convert_fpd3_to_fpd4--->eStatus |%d",eStatus);

    // If there is problem on FPDLINK3 stage. it is not need to later configs
    if (serdes_wait_ser_fpd_linkup(fd, 500) != BRIDGECHIP_STATUS_SUCCESS)
        return BRIDGECHIP_STATUS_FAILED;
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_988_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_981_fpd4(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | serdes_wait_ser_fpd_linkup(fd, 500));
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_vp(fd));

    return eStatus;
}

static void serdes_wait_des_link_stable(int32 fd, int32 timeout)
{
    uint8_t regval=0;
    int32_t port0_link = 0;
    int32 i = timeout / 50;
    int32_t stable_count = 0;
#define LOCK_STS_CHG_988 0x04 //bit2

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    do {
        if (read_reg(fd, 0x54, &regval) == 0)
        {
            port0_link = regval & LOCK_STS_CHG_988;
            if (port0_link == 0x04) {
                //not stable
                stable_count = 0;
            } else if (port0_link == 0x0) {
                //stable and count it
                stable_count ++;
                //break when continuous 5 times stable
                if (stable_count >= 5)
                    break;
            }
        }
        (void) usleep(50*1000);
    } while (i--);
}

static BridgeChip_StatusType link_enable_988_panel(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    CRITICAL_PRINT(MODULE_NAME, "link_enable_deserializer_panel: wait 988 stable... ... ...");
    serdes_wait_des_link_stable(fd, 500);

    CRITICAL_PRINT(MODULE_NAME, "%s: Enable 988 OLDI output", __func__);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_set_988_enable_oldi(fd);
    CRITICAL_PRINT(MODULE_NAME, "%s: Enable panel backlight", __func__);
    i2c_set_slave_addr(fd, MCU_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | enable_panel_backlight(fd));

    return eStatus;
}


BridgeChip_StatusType serdes_wait_ser_fpd_linkup(int32 fd, int32 timeout)
{
    int32_t i = timeout / 20;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    do {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
            return BRIDGECHIP_STATUS_SUCCESS;
        else
            (void) usleep(20*1000);
    } while (i--);

    return BRIDGECHIP_STATUS_FAILED;
}

//used for link lost recovery init
BridgeChip_StatusType recovery_ser_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);
    CRITICAL_PRINT(MODULE_NAME, "Link setup to FPD-Link III mode");
    eStatus = link_set_981_fpd3(fd);
    return eStatus;
}
BridgeChip_StatusType recovery_serdes_fpd4_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    //   eStatus |= link_set_deserializer_video_misc(fd);
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_988_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_981_fpd4(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | serdes_wait_ser_fpd_linkup(fd, 200));
    return eStatus;
}

static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8 regval = 0;
    int32 port0_linked = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x0c, &regval)!= 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;
    }

    if (port0_linked == 1)
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        serdes_clear_link_crc_err_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    link_convert_fpd3_to_fpd4(i2c_fh);

    return eStatus;
}

static BridgeChip_StatusType check_988_lock()
{
    /*
       uint8 lock_statu1=0, lock_statu2=0;
       BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

       int i = 0;

       for (i=0; i<20;i++) {
       eStatus = bridge_i2c_read(gsPluginInfo.hI2CFileDes, 0x53, &lock_statu1, I2C_READ_1_BYTE_LENGTH);
       if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
       {
       LOG_CRITICAL_INFO(CHIP_ID, "%s read DESID REG:0x06 failed", __func__);

       }
       LOG_CRITICAL_INFO(CHIP_ID, "%s read REG:0x53, val:%x ", __func__, lock_statu1);

       if (((lock_statu1&0x1)== 0x1) &&((lock_statu1&0x80)== 0x0)) {
       if(lock_statu1 == lock_statu2)
       break;
       }
       lock_statu2=lock_statu1;

       }
       if (i >= 20)
       return BRIDGECHIP_STATUS_FAILED;
       else*/
    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    LOG_CRITICAL_INFO(MODULE_NAME, "Call %s, Date: %s, %s", __func__, __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    if (check_988_lock() == BRIDGECHIP_STATUS_SUCCESS)
    {
        eStatus = link_enable_988_panel(i2c_fh);
    }
    else
    {
        LOG_CRITICAL_INFO(MODULE_NAME, "Failed to update dserializer OLDI registers");
        eStatus = BRIDGECHIP_STATUS_FAILED;
    }

    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

void set_reset_keep_dsi(int32 val)
{
    reset_keep_dsi = val;
}

#ifdef __cplusplus
}
#endif
