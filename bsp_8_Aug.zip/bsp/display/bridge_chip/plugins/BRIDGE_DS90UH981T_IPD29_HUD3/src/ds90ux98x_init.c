#ifdef __cplusplus
extern "C"
{
#endif
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT             0x0C
#define DES_ID_7BIT             0x2C
#define MCU_ID_7BIT             0x12
#define DES_DC_ID_7BIT          0x2C
#define MCU_DC_ID_7BIT          0x12

#define DES_DC_ID_7BIT_ALIAS    0x40
#define MCU_DC_ID_7BIT_ALIAS    0x48

#define SER_ID_8BIT             (SER_ID_7BIT << 1)
#define DES_ID_8BIT             (DES_ID_7BIT << 1)
#define MCU_ID_8BIT             (MCU_ID_7BIT << 1)
#define DES_DC_ID_8BIT          (DES_DC_ID_7BIT << 1)
#define MCU_DC_ID_8BIT          (MCU_DC_ID_7BIT << 1)

#define DES_DC_ID_8BIT_ALIAS    (DES_DC_ID_7BIT_ALIAS << 1)
#define MCU_DC_ID_8BIT_ALIAS    (MCU_DC_ID_7BIT_ALIAS << 1)
#define WAIT_INTERVAL           10

// IPD Panel Timings
#define THW                     2088    // Total horizontal
#define TVW                     940     // Total vertical
#define AHW                     2000    // Active horizontal
#define AVW                     810     // Active vertical
#define HBP                     16      // Horizontal back porch
#define VBP                     30      // Vertical back porch
#define HSW                     16      // Horizontal sync width
#define VSW                     50      // Vertical sync width
#define VFP                     50      // Vertical front porch

// HUD Panel Timings
#define DC_THW                  856     // Total horizontal
#define DC_TVW                  488     // Total vertical
#define DC_AHW                  800     // Active horizontal
#define DC_AVW                  480     // Active vertical
#define DC_HBP                  20      // Horizontal back porch
#define DC_HSW                  16      // Horizontal sync width
#define DC_VBP                  4      // Vertical back porch
#define DC_VSW                  2      // Vertical sync width
#define DC_VFP                  2      // Vertical front porch

#define VFILTER_A_VP1           3
#define VFILTER_N_VP1           5

#define FC_FPD_FREQ             6.75
#define FPS                     60

#define GENERAL_STS_MASK        0x5B
#define RX_LOCK_DETECT_BIT      6
#define LINK_LOST_FLAG_BIT      4
#define BIST_CRC_ERROR_BIT      3
#define BC_CRC_ERROR_BIT        1
#define LINK_DETECT_BIT         0

#define DAISY_RX_LOCK_DET_P0    6

#define APB_CTL        0x48
#define APB_ADR0       0x49
#define APB_ADR1       0x4A
#define APB_DATA0      0x4B
#define APB_DATA1      0x4C
#define APB_DATA2      0x4D
#define APB_DATA3      0x4E

#define APB_DP_RX      0x00
#define APB_DP0_TX     APB_DP_RX
#define APB_DP1_TX     0x01
#define APB_CFG_DATA   0x02
#define APB_DIE_ID     0x03

static int32 verbosedebug = 1;
static int32 reset_keep_dsi = 0;

struct video_timing {
    uint32 htotal;
    uint32 vtotal;
    uint32 hres;
    uint32 vres;
    uint32 hstart;
    uint32 vstart;
    uint32 hswidth;
    uint32 vswidth;
};


#define MODULE_NAME "SER-DES TOPOLOGY-60 DSI CS3.0"
#define ENABLE_VP0_PATTERN 0
#define ENABLE_VP1_PATTERN 0

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "i2c_write failed 0x%x : 0x%x",  reg, val);
    }

    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        return -1;
    }

    return 0;
}
#if 0
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x03;
        break;
    case APB_DP1_TX:
        wr_val = 0x0B;
        break;
    case APB_CFG_DATA:
        wr_val = 0x13;
        break;
    case APB_DIE_ID:
        wr_val = 0x1B;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB write channel, try write APB channel 0");
        wr_val = 0x03;
        break;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}
#endif

static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x01;
        break;
    case APB_DP1_TX:
        wr_val = 0x09;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB read channel, try read APB channel 0");
        wr_val = 0x01;
        break;
    }
    write_reg(fd, APB_CTL, wr_val);

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);


    return 0;
}

static uint32 serdes_des_measure_video (int32 fd, struct video_timing *timing)
{
    uint32 htotal = 0, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;
    uint32 hactive0, hactive1, hactive2, hactive3;
    uint8 read_val;

    if (timing == NULL) {
        return htotal;
    }

    (void)usleep(100 * 1000);

    write_reg(fd, 0x40, 0x53);
    write_reg(fd, 0x41, 0x40);
    read_reg(fd, 0x42, &read_val);
    htotal = read_val * 256;
    write_reg(fd, 0x41, 0x41);
    read_reg(fd, 0x42, &read_val);
    htotal = htotal + read_val;

    write_reg(fd, 0x41, 0x42);
    read_reg(fd, 0x42, &read_val);
    vtotal = read_val * 256;
    write_reg(fd, 0x41, 0x43);
    read_reg(fd, 0x42, &read_val);
    vtotal = vtotal + read_val;

    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &read_val);
    hres = read_val * 256;
    write_reg(fd, 0x41, 0x45);
    read_reg(fd, 0x42, &read_val);
    hres = hres + read_val;

    write_reg(fd, 0x41, 0x46);
    read_reg(fd, 0x42, &read_val);
    vres = read_val * 256;
    write_reg(fd, 0x41, 0x47);
    read_reg(fd, 0x42, &read_val);
    vres = vres + read_val;

    write_reg(fd, 0x41, 0x48);
    read_reg(fd, 0x42, &read_val);
    hstart = read_val * 256;
    write_reg(fd, 0x41, 0x49);
    read_reg(fd, 0x42, &read_val);
    hstart = hstart + read_val;

    write_reg(fd, 0x41, 0x4a);
    read_reg(fd, 0x42, &read_val);
    vstart = read_val * 256;
    write_reg(fd, 0x41, 0x4b);
    read_reg(fd, 0x42, &read_val);
    vstart = vstart + read_val;

    write_reg(fd, 0x41, 0x4c);
    read_reg(fd, 0x42, &read_val);
    hswidth = read_val * 256;
    write_reg(fd, 0x41, 0x4d);
    read_reg(fd, 0x42, &read_val);
    hswidth = hswidth + read_val;

    write_reg(fd, 0x41, 0x4e);
    read_reg(fd, 0x42, &read_val);
    vswidth = read_val * 256;
    write_reg(fd, 0x41, 0x4f);
    read_reg(fd, 0x42, &read_val);
    vswidth = vswidth + read_val;

    if (timing)
    {
        timing->htotal = htotal;
        timing->vtotal = vtotal;
        timing->hres = hres;
        timing->vres = vres;
        timing->hstart = hstart;
        timing->vstart = vstart;
        timing->hswidth = hswidth;
        timing->vswidth = vswidth;
    }
    write_reg(fd, 0x40, 0x4B);
    write_reg(fd, 0x41, 0x39);
    read_reg(fd, 0x42, &read_val);
    hactive0 = read_val;
    read_reg(fd, 0x42, &read_val);
    hactive0 = hactive0 + read_val * 256;

    read_reg(fd, 0x42, &read_val);
    hactive1 = read_val;
    read_reg(fd, 0x42, &read_val);
    hactive1 = hactive1 + read_val * 256;

    read_reg(fd, 0x42, &read_val);
    hactive2 = read_val;
    read_reg(fd, 0x42, &read_val);
    hactive2 = hactive2 + read_val * 256;

    read_reg(fd, 0x42, &read_val);
    hactive3 = read_val;
    read_reg(fd, 0x42, &read_val);
    hactive3 = hactive3 + read_val * 256;

    CRITICAL_PRINT(MODULE_NAME," Measured Video Timing Success");
    CRITICAL_PRINT(MODULE_NAME," DTG Port0 Measured Video Timing:");
    CRITICAL_PRINT(MODULE_NAME,"  htotal = %d",  timing->htotal);
    CRITICAL_PRINT(MODULE_NAME,"  vtotal = %d",  timing->vtotal);
    CRITICAL_PRINT(MODULE_NAME,"  hres = %d",  timing->hres);
    CRITICAL_PRINT(MODULE_NAME,"  vres = %d",  timing->vres);
    CRITICAL_PRINT(MODULE_NAME,"  hstart = %d",  timing->hstart);
    CRITICAL_PRINT(MODULE_NAME,"  vstart = %d",  timing->vstart);
    CRITICAL_PRINT(MODULE_NAME,"  hswidth = %d",  timing->hswidth);
    CRITICAL_PRINT(MODULE_NAME,"  vswidth = %d",  timing->vswidth);
    CRITICAL_PRINT(MODULE_NAME," Streams video info");
    CRITICAL_PRINT(MODULE_NAME,"  Stream 0 Hactive = %d", hactive0);
    CRITICAL_PRINT(MODULE_NAME,"  Stream 1 Hactive = %d", hactive1);
    CRITICAL_PRINT(MODULE_NAME,"  Stream 2 Hactive = %d", hactive2);
    CRITICAL_PRINT(MODULE_NAME,"  Stream 3 Hactive = %d", hactive3);


    return htotal;
}

static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

static BridgeChip_StatusType serdes_wait_des_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / WAIT_INTERVAL;

    do
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(WAIT_INTERVAL * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

static BridgeChip_StatusType serdes_wait_des_daisy_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / WAIT_INTERVAL;

    do
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_DC_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(WAIT_INTERVAL * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

static BridgeChip_StatusType link_set_serializer_i2c_pass_through(int32 fd)
{
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x88, 0x00);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x89, 0x00);
    write_reg(fd, 0x72, DES_DC_ID_8BIT);
    write_reg(fd, 0x7A, DES_DC_ID_8BIT_ALIAS);
    write_reg(fd, 0x8A, 0x01);
    write_reg(fd, 0x73, MCU_DC_ID_8BIT);
    write_reg(fd, 0x7B, MCU_DC_ID_8BIT_ALIAS);
    write_reg(fd, 0x8B, 0x01);
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);
    CRITICAL_PRINT(MODULE_NAME," Enable I2C Pass Through");
    write_reg(fd, 0x07, 0x88);
    write_reg(fd, 0x3A, 0x88);

    CRITICAL_PRINT(MODULE_NAME, "Set i2c pass through done");

    return BRIDGECHIP_STATUS_SUCCESS;
}


static BridgeChip_StatusType link_set_serializer_gpio(int32 fd)
{
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set Serializer GPIOs...");
    read_reg(fd, 0x30, &RevId);
    RevId &= 0xF0;
    if (RevId >= 0x20)
    {
		CRITICAL_PRINT(MODULE_NAME, "Setting GPIO12...");
        write_reg(fd, 0x23, 0x81); //GPIO12 OUTPUT, Source: FPD Port 0, Select: BC_GPIO1
    }
    else
    {
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}
//only can be called after softreset
static BridgeChip_StatusType link_set_serializer_dsirx(int32 fd)
{
    uint8 Reg_value = 0;

    CRITICAL_PRINT(MODULE_NAME, "Configure DSI");
    read_reg(fd, 0x02, &Reg_value);
    Reg_value = Reg_value | 0x8;
    write_reg(fd, 0x02, Reg_value);       //Disable DSI

    write_reg(fd, 0x2D, 0x01);            //Select port 0
    write_reg(fd, 0x40, 0x10);            //Change indirect page to page 4
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x0e);            //Port 0 TSKIP value:14     formula : TSKIP_CNT= ROUND((130*fdsi)/4000 -3)

    read_reg(fd, 0x4f, &Reg_value);
    Reg_value = Reg_value & 0x73;
 	Reg_value = Reg_value | 0x8c;
    write_reg(fd, 0x4f, Reg_value);       //Set number of lanes and continuous or non-continuous

	write_reg(fd, 0x2D, 0x12);            //Select port 1
    write_reg(fd, 0x40, 0x18);            //Change indirect page to page 6
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x0);            //Port 1 TSKIP value:11      formula : TSKIP_CNT= ROUND((130*fdsi)/4000 -3)

    read_reg(fd, 0x4f, &Reg_value);
    Reg_value = Reg_value & 0x73;
 	Reg_value = Reg_value | 0x8c;
    write_reg(fd, 0x4f, Reg_value);       //Set number of lanes and continuous or non-continuous

    write_reg(fd, 0x2d, 0x03);    //Select write port 0 and 1
    write_reg(fd, 0xbd, 0x20);    //Set DSI source for the Video processors 0 and 1
    write_reg(fd, 0xbe, 0x00);    //Set DSI source for the Video processors 2 and 3

    read_reg(fd, 0x02, &Reg_value);
    Reg_value = Reg_value & 0xf7;
    write_reg(fd, 0x02, Reg_value);            /* enable DSI */

    write_reg(fd, 0x2D, 0x01);                 /* select potr 0 */

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    //uint8 RevId = 0;

    write_reg(fd, 0x2D, 0x01);

    //Disable FPD3 FIFO pass through
    write_reg(fd, 0x5B, 0x23);
    //Force Single FPD4 Port0, Port1 disabled
    write_reg(fd, 0x05, 0x2C); // FPD_TX to single fpd4 port0, port1 disabled
    write_reg(fd, 0x40, 0x08); // Select PLL reg page
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x08); // Disable PLL0
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x08); // Disable PLL1

    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");

    write_reg(fd, 0x02, 0xD1); // Enable mode overwrite
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x40, 0x24); // Select digital reg page
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02); // Switch encoder from ADAS to IVI on port 0
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02); // Switch encoder from ADAS to IVI on port 1
    write_reg(fd, 0x40, 0x08); // Select PLL page
    write_reg(fd, 0x41, 0x05); // Select Ncount Reg
    write_reg(fd, 0x42, 0x7D); // Set Ncount
    write_reg(fd, 0x41, 0x13); // Select post div reg
    write_reg(fd, 0x42, 0x90); // Set post div for 6.75 Gbps

    write_reg(fd, 0x2D, 0x01); // Select write reg to port 0
    write_reg(fd, 0x6A, 0x0A); // set BC sampling rate
    write_reg(fd, 0x6E, 0x80); // set BC fractional sampling

    write_reg(fd, 0x41, 0x45); // Select Ncount Reg
    write_reg(fd, 0x42, 0x7D); // Set Ncount
    write_reg(fd, 0x41, 0x53); // Select post div reg
    write_reg(fd, 0x42, 0x90); // Set post div for 6.75 Gbps
    write_reg(fd, 0x2D, 0x12); // Select write reg to port 1
    write_reg(fd, 0x6A, 0x0A); // set BC sampling rate
    write_reg(fd, 0x6E, 0x80); // set BC fractional sampling
    write_reg(fd, 0x02, 0xD1); // Set HALFRATE_MODE
    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    //Configure and Enable PLLs
    write_reg(fd, 0x41, 0x0E); // Select VCO reg
    write_reg(fd, 0x42, 0xC7); // Set VCO
    write_reg(fd, 0x41, 0x4E); // Select VCO reg
    write_reg(fd, 0x42, 0xC7); // Set VCO
    write_reg(fd, 0x01, 0x30); // soft reset PLL

    write_reg(fd, 0x40, 0x08); // Select PLL page
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x00); // Enable PLL0

    //write_reg(fd, 0x41, 0x5B); //PLL1 only needed when using dual FPD4, IPD/HUD use only single FPD4 link
    //write_reg(fd, 0x42, 0x00); // Enable PLL1

    CRITICAL_PRINT(MODULE_NAME," Software reset 981");
    if (reset_keep_dsi)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);

    //todo:
    serdes_wait_des_link_stable(fd, 100);

    CRITICAL_PRINT(MODULE_NAME," Software reset deserializer");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 100);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x40, 0x2E); // Select Ser link layer
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // refresh time slot
    CRITICAL_PRINT(MODULE_NAME,"Software reset 981 and 988 done");
    write_reg(fd, 0x2D, 0x01); // Select write to port0 reg

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    uint8 n_value = 15;
    uint16 m_value = 0;
    float src_pclk_freq = 0;
    float fc_freq = 0;
    float m_value_f = 0;

    CRITICAL_PRINT(MODULE_NAME, "Configure VP0");
    write_reg(fd, 0x2D, 0x01); // select port 0 TX
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0xA8); // select VP source - stream 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); // program h_act

    // Set crop for VP0   **** crop only needed when using SuperFrame
    //write_reg(fd, 0x41, 0x08);
    //write_reg(fd, 0x42, 0x00); // start x
    //write_reg(fd, 0x42, 0x00); // start x
    //write_reg(fd, 0x42, 0x00); // start y
    //write_reg(fd, 0x42, 0x00); // start y
    //write_reg(fd, 0x42, lower_byte(AHW-1)); // stop x
    //write_reg(fd, 0x42, upper_byte(AHW-1));
    //write_reg(fd, 0x42, lower_byte(AVW-1)); // stop Y
    //write_reg(fd, 0x42, upper_byte(AVW-1));

    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP)); //program v front porch
    write_reg(fd, 0x41, 0x27);
    write_reg(fd, 0x42, 0x00);

    // Enable video cropping  ****only needed in SuperFrame
    //write_reg(fd, 0x41, 0x00);
    //write_reg(fd, 0x42, 0x04);

    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //6750  bps
    src_pclk_freq = THW * TVW * FPS / 1000000.00f;
    CRITICAL_PRINT(MODULE_NAME, "VP0 PCLK = %f MHz",  src_pclk_freq);
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "VP0 m_value = %d",  m_value);

    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value)); // set M divider
    write_reg(fd, 0x42, n_value);             // set N divider
#if ENABLE_VP0_PATTERN
    CRITICAL_PRINT(MODULE_NAME, "Enable VP0 Patgen", __func__);
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x95);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x08);
#endif

    CRITICAL_PRINT(MODULE_NAME, "Configure VP1");
    write_reg(fd, 0x40, 0x32); // select VP03 indirect registers page
    write_reg(fd, 0x41, 0x41);
    write_reg(fd, 0x42, 0xA9); // select VP source - stream 1
    write_reg(fd, 0x41, 0x42);
    write_reg(fd, 0x42, lower_byte(DC_AHW));
    write_reg(fd, 0x42, upper_byte(DC_AHW)); // program h_act

    // Set filter for VP1 **** filter only needed when using SuperFrame
    //write_reg(fd, 0x41, 0x46);
    //write_reg(fd, 0x42, VFILTER_A_VP1);
    //write_reg(fd, 0x42, VFILTER_N_VP1);

    // Set crop for VP1   **** crop only needed when using SuperFrame
    //write_reg(fd, 0x41, 0x48);
    //write_reg(fd, 0x42, lower_byte(AHW));  // start x
    //write_reg(fd, 0x42, upper_byte(AHW));
    //write_reg(fd, 0x42, 0x00);             // start y
    //write_reg(fd, 0x42, 0x00);
    //write_reg(fd, 0x42, lower_byte(AHW + DC_AHW - 1)); // stop x
    //write_reg(fd, 0x42, upper_byte(AHW + DC_AHW - 1));
    //write_reg(fd, 0x42, lower_byte(DC_AVW - 1));       // stop y
    //write_reg(fd, 0x42, upper_byte(DC_AVW - 1));

    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, lower_byte(DC_AHW));
    write_reg(fd, 0x42, upper_byte(DC_AHW)); //program h_act
    write_reg(fd, 0x42, lower_byte(DC_HBP));
    write_reg(fd, 0x42, upper_byte(DC_HBP)); //program h back porch
    write_reg(fd, 0x42, lower_byte(DC_HSW));
    write_reg(fd, 0x42, upper_byte(DC_HSW)); //program h sync
    write_reg(fd, 0x42, lower_byte(DC_THW));
    write_reg(fd, 0x42, upper_byte(DC_THW)); //program h_tot
    write_reg(fd, 0x42, lower_byte(DC_AVW));
    write_reg(fd, 0x42, upper_byte(DC_AVW)); //program v_act
    write_reg(fd, 0x42, lower_byte(DC_VBP));
    write_reg(fd, 0x42, upper_byte(DC_VBP)); //program v back porch
    write_reg(fd, 0x42, lower_byte(DC_VSW));
    write_reg(fd, 0x42, upper_byte(DC_VSW)); //program v sync
    write_reg(fd, 0x42, lower_byte(DC_VFP));
    write_reg(fd, 0x42, upper_byte(DC_VFP)); //program v front porch
    write_reg(fd, 0x41, 0x67);
    write_reg(fd, 0x42, 0x00);

    // Enable video cropping  ****only needed in SuperFrame
    //write_reg(fd, 0x41, 0x40);
    //write_reg(fd, 0x42, 0x06);

    // set m/n value for video processor 1
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //6750  bps
    src_pclk_freq = DC_THW * DC_TVW * FPS / 1000000.00f;
    CRITICAL_PRINT(MODULE_NAME, "VP1 PCLK = %f MHz",  src_pclk_freq);
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "VP1 m_value = %d",  m_value);

    write_reg(fd, 0x41, 0x63);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value)); // set M divider
    write_reg(fd, 0x42, n_value);             // set N divider

    write_reg(fd, 0x43, 0x01); // enable VP0 and VP1
    write_reg(fd, 0x44, 0x03); // enable VP0 and VP1

#if ENABLE_VP1_PATTERN
    CRITICAL_PRINT(MODULE_NAME, "Enable VP1 Patgen", __func__);
    write_reg(fd, 0x40, 0x30);
    write_reg(fd, 0x41, 0x68);
    write_reg(fd, 0x42, 0x95);
    write_reg(fd, 0x41, 0x69);
    write_reg(fd, 0x42, 0x08);
#endif

    CRITICAL_PRINT(MODULE_NAME, "Enable Video processor stream");
    write_reg(fd, 0x40, 0x2E); // go to Link Layer indirect registers page
    write_reg(fd, 0x41, 0x01); //
    write_reg(fd, 0x42, 0x03); // enable stream 0 and stream 1
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x20); // set 32 time slots
    write_reg(fd, 0x41, 0x07);
    write_reg(fd, 0x42, 0x1E); // set 30 time slots
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x55); // set link layer VP bpp
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // enable LL0 & send new time slots

    return BRIDGECHIP_STATUS_SUCCESS;
}

#if 0
static BridgeChip_StatusType link_set_serializer_enable_sscg(int32 fd)
{
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    //#########################################################
    //#Programs FPD-Link SSCG PLL for 98x device to 6.750 Gbps
    //#PLL script revision: 0
    //#Configuring PLL0 (Port 0)
    //#N-divider set to 124
    //#########################################################
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7C); // write to register 0x05
    write_reg(fd, 0x42, 0x00); // write to register 0x06
    // Denominator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0xF6); // write to register 0x18
    write_reg(fd, 0x42, 0xFF); // write to register 0x19
    write_reg(fd, 0x42, 0xFF); // write to register 0x1a
    // Numerator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0xF6); // write to register 0x1e
    write_reg(fd, 0x42, 0xFF); // write to register 0x1f
    write_reg(fd, 0x42, 0xFF); // write to register 0x20
    // Post-divider set to 2 and auto VCO selection enabled
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90); // write to register 0x13
    // SSCG spread type set to Center-spread
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x14);
    write_reg(fd, 0x42, 0x80); // write to register 0x14
    // rampx_inc_6_0 programmed (rampx_inc =25700)
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x14);
    write_reg(fd, 0x42, 0xE4); // write to register 0x14
    // rampx_inc_14_7 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x15);
    write_reg(fd, 0x42, 0xC8); // write to register 0x15
    // rampx_stop_7_0 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x16);
    write_reg(fd, 0x42, 0xCC); // write to register 0x16
    // SSCG enabled, rampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x17);
    write_reg(fd, 0x42, 0x40); // write to register 0x17
    // PLL order set to fractional
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x09); // write to register 0x04
    //#########################################################
    //#Programs FPD-Link SSCG PLL for 98x device to 6.750 Gbps
    //#PLL script revision: 0
    //#Configuring PLL1 (Port 1)
    //#########################################################
    //#N-divider set to 124
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, 0x7C); // write to register 0x45
    write_reg(fd, 0x42, 0x00); // write to register 0x46
    // Denominator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x58);
    write_reg(fd, 0x42, 0xF6); // write to register 0x58
    write_reg(fd, 0x42, 0xFF); // write to register 0x59
    write_reg(fd, 0x42, 0xFF); // write to register 0x5a
    // Numerator set to 16777206
    write_reg(fd, 0x40, 0x0A);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0xF6); // write to register 0x5e
    write_reg(fd, 0x42, 0xFF); // write to register 0x5f
    write_reg(fd, 0x42, 0xFF); // write to register 0x60
    // Post-divider set to 2 and auto VCO selection enabled
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90); // write to register 0x53
    // SSCG spread type set to Center-spread
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0x80); // write to register 0x54
    // rampx_inc_6_0 programmed (rampx_inc =25700)
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x54);
    write_reg(fd, 0x42, 0xE4); // write to register 0x54
    // rampx_inc_14_7 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x55);
    write_reg(fd, 0x42, 0xC8); // write to register 0x55
    // rampx_stop_7_0 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0xCC); // write to register 0x56
    // SSCG enabledrampx_stop_9_8 programmed
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x57);
    write_reg(fd, 0x42, 0x40); // write to register 0x57
    // PLL order set to fractional
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x09); // write to register 0x44

    write_reg(fd, 0x01, 0x30);
    serdes_clear_link_crc_err_flag(fd);
    serdes_wait_des_link_stable(fd, 100);

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_deserializer_gpio(int32 fd)
{
    write_reg(fd, 0x40, 0x04); // Page 1
    write_reg(fd, 0x41, 0x11); // BC_GPIO1_SEL
    write_reg(fd, 0x42, 0x10); // BC GPIO1 send Daisy Chain port0 BC_GPIO1

    return BRIDGECHIP_STATUS_SUCCESS;
}
#if 0
static BridgeChip_StatusType link_set_deserializer_enable_sscg(int32 fd)
{
    uint8 idr_reg_rb = 0;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    //## *********************************************
    //## SSCG CDR DES Settings
    //## *********************************************
    //# # FPD FC Rate:6.75
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain trk to 2
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain trk to 3
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain ACQ to 2
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain ACQ to 3
    write_reg(fd, 0x40, 0x55);
    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, (idr_reg_rb & 0xFC) | 0x01);  // Set CDR Dump Limit to 1
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain trk to 2
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAC);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAC);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain trk to 3
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0x1F) | 0x40);  // Set CDR FO Gain ACQ to 2
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0xAD);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0xAD);
    write_reg(fd, 0x42, (idr_reg_rb & 0xE3) | 0x0C);  // Set CDR SO Gain ACQ to 3
    write_reg(fd, 0x40, 0x59);
    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &idr_reg_rb);
    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, (idr_reg_rb & 0xFC) | 0x01);  // Set CDR Dump Limit to 1
    write_reg(fd, 0x01, 0x01);                        //digital reset
    (void)usleep(40 * 1000);

    return BRIDGECHIP_STATUS_SUCCESS;
}
#endif

static BridgeChip_StatusType link_set_deserializer_temp_optimization(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    uint8 temp_final, rb;
    int32 temp_final_c, ramp_up_range_codes_needed, ramp_dn_range_codes_needed;
    int32 ramp_up_cap_delta, ramp_dn_cap_delta, ts_code_up, ts_code_dn;
    uint8 efuse_ts_code = 2;

    CRITICAL_PRINT(MODULE_NAME, "Set up deserializer Temp Ramp Optimizations");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    // Read Deserializer 0 Temp
    write_reg(fd, 0x40, 0x6C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13);
    read_reg(fd, 0x42, &temp_final);
    temp_final_c = 2 * temp_final - 273;

    // Set up Deserializer 0 Temp Ramp Optimizations
    ramp_up_range_codes_needed = (150 - temp_final_c) / (190 / 11) + 1;
    ramp_dn_range_codes_needed = (temp_final_c - 30) / (190 / 11) + 1;
    ramp_up_cap_delta = ramp_up_range_codes_needed - 4;
    ramp_dn_cap_delta = ramp_dn_range_codes_needed - 7;

    write_reg(fd, 0x40, 0x3C);
    write_reg(fd, 0x41, 0xF5);
    write_reg(fd, 0x42, (efuse_ts_code << 4) + 1);
    if (ramp_up_cap_delta > 0)
    {
        ts_code_up = efuse_ts_code - ramp_up_cap_delta;
        if (ts_code_up < 0)
            ts_code_up = 0;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_up << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }

    if (ramp_dn_cap_delta > 0)
    {
        ts_code_dn = efuse_ts_code + ramp_dn_cap_delta;
        if (ts_code_dn >= 7)
            ts_code_dn = 7;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_dn << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }
    (void)usleep(20*1000);
    serdes_wait_des_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_enable_edp_tx(int32 fd)
{
    serdes_clear_link_crc_err_flag(fd);
    serdes_wait_des_link_stable(fd, 50);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);

    CRITICAL_PRINT(MODULE_NAME, "Hold Des DTG in reset");
    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02); // Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x02); // Hold Port 1 DTG in reset

    CRITICAL_PRINT(MODULE_NAME, "Disable Stream Mapping");
    write_reg(fd, 0x0E, 0x03); // Select both Output Ports
    write_reg(fd, 0xD0, 0x00); // Disable FPD4 video forward to Output Port
    write_reg(fd, 0xD7, 0x00); // Disable FPD3 video forward to Output Port

    CRITICAL_PRINT(MODULE_NAME, "Force DP Rate");
    write_reg(fd, 0x40, 0x2C); //  Select DP Page
    write_reg(fd, 0x41, 0x81);
    write_reg(fd, 0x42, 0x60); //  Set DP Rate to 2.7Gbps
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0x02); //  Enable force DP rate
    write_reg(fd, 0x41, 0x91);
    write_reg(fd, 0x42, 0x0C); //  Force 4 lanes

    CRITICAL_PRINT(MODULE_NAME, "Setup DP ports");
    write_reg(fd, 0x0E, 0x12); //  Select Port 1 registers
    write_reg(fd, 0x46, 0x00); //  Disable DP Port 1
    write_reg(fd, 0x0E, 0x01); //  Select Port 0 registers
    write_reg(fd, 0x01, 0x40); //  DP-TX-PLL RESET Applied

    (void)usleep(50 * 1000);

    CRITICAL_PRINT(MODULE_NAME, "Map video to display output");
    write_reg(fd, 0x0E, 0x03); //  Select both Output Ports
    write_reg(fd, 0xD0, 0x0C); //  Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xD1, 0x0F); //  Stream 1 forwarded on DC
    write_reg(fd, 0xD6, 0x08); //  Send Stream 0 to Output Port 0 and Send Stream 1 to Output Port 1
    write_reg(fd, 0xD7, 0x00); //  FPD3 mapping disabled
    write_reg(fd, 0x0E, 0x01); //  Select Port 0

    CRITICAL_PRINT(MODULE_NAME, "Program quad pixel clock for DP port 0");
    write_reg(fd, 0x0E, 0x01); //  Select Port0 registers
    write_reg(fd, 0xB1, 0x01); //  Enable clock divider
    write_reg(fd, 0xB2, 0x28); //  Program M value lower byte
    write_reg(fd, 0xB3, 0xCC); //  Program M value middle byte
    write_reg(fd, 0xB4, 0x01); //  Program M value upper byte
    write_reg(fd, 0xB5, 0xC0); //  Program N value lower byte
    write_reg(fd, 0xB6, 0x7A); //  Program N value middle byte
    write_reg(fd, 0xB7, 0x10); //  Program N value upper byte
    write_reg(fd, 0x0E, 0x01); //  Select Port 0 registers

    (void)usleep(50 * 1000);

    CRITICAL_PRINT(MODULE_NAME, "Setup DTG for port 0");
    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0xA3); // Set up DTG BPP, Sync Polarities, and Measurement Type
    write_reg(fd, 0x41, 0x29); // Set Hstart
    write_reg(fd, 0x42, 0x80); // Hstart upper byte
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x20); // Hstart lower byte
    write_reg(fd, 0x41, 0x2F); // Set HSW
    write_reg(fd, 0x42, 0x40); // HSW upper byte
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x10); // HSW lower byte

    (void)usleep(50 * 1000);

    CRITICAL_PRINT(MODULE_NAME, "Program DPTX for DP port 0");
    apb_write_reg(fd, APB_DP0_TX, 0x1A4, 0x40);         //Set bit per color
    apb_write_reg(fd, APB_DP0_TX, 0x1B8, 0x04);         //Set pixel width
    apb_write_reg(fd, APB_DP0_TX, 0x1AC, 0x37D8);       //Set DP Mvid
    apb_write_reg(fd, APB_DP0_TX, 0x1B4, 0x8000);       //Set DP Nvid
    apb_write_reg(fd, APB_DP0_TX, 0x1C8, 0x00);         //Set TU Mode
    apb_write_reg(fd, APB_DP0_TX, 0x1B0, 0x41A0040);     //Set TU Size
    apb_write_reg(fd, APB_DP0_TX, 0xC8, 0x4006);        //Set FIFO Size
    apb_write_reg(fd, APB_DP0_TX, 0x1BC, 0x0753);       //Set data count
    apb_write_reg(fd, APB_DP0_TX, 0x1C0, 0x00);         //Disable STREAM INTERLACED
    apb_write_reg(fd, APB_DP0_TX, 0x1C4, 0x0C);         //Set SYNC polarity

    CRITICAL_PRINT(MODULE_NAME, "Release Des DTG reset");
    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x00); // Release Port 0 DTG
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x00); // Release Port 1 DTG

    apb_write_reg(fd, APB_DP0_TX, 0x180, 0x828);         //Set DP0 Htotal

    (void)usleep(100 * 1000);

    CRITICAL_PRINT(MODULE_NAME, "Enable DP 0 output");
    apb_write_reg(fd, APB_DP0_TX, 0x84, 0x01);         //Enable DP0 Output

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_tx_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x08, 0x20); // Disable TX_BCC I2C master
    CRITICAL_PRINT(MODULE_NAME, "Configure Deserializer TX Link Layer");
    write_reg(fd, 0x40, 0x44); // TX Link Layer
    write_reg(fd, 0x41, 0x01); // Link0 layer stream enable
    write_reg(fd, 0x42, 0x02); // Enable link layer 0 stream 0 & stream 1, forwarded daisy chain streams
    write_reg(fd, 0x41, 0x07); // Set number of slots for stream 1
    write_reg(fd, 0x42, 0x3C); // Set number of slots to 30 for video stream 1
    write_reg(fd, 0x41, 0x20); // Set Link layer vp bpp
    write_reg(fd, 0x42, 0x55); // Set Link layer vp bpp according to VP Bit per pixel, Set 24 bit mode
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03); // Enable link layer and en_new_tslot0
    write_reg(fd, 0x2B, 0x1C); // set I2C speed to 400KHz
    write_reg(fd, 0x2C, 0x1C);

    CRITICAL_PRINT(MODULE_NAME,  "Force Deserializer TX to FPD4 Single MODE");
    write_reg(fd, 0xA8, 0x2C);  // FPD_TX to Single
    // 984 PLL programming
    CRITICAL_PRINT(MODULE_NAME, "Program 988 Tx PLL Settings (3.375Gbps)");
    write_reg(fd, 0x40, 0x0C);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, 0x7D);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);  // Post div = 2
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, 0x7D);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x05, 0x01);

    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x40, 0x0C); // Select PLL Reg page
    write_reg(fd, 0x41, 0x5B); // Select Channel 1 PLL Register
    write_reg(fd, 0x42, 0x08); // Disable Unused Channel 1 PLL, only needed on Dual FPD4 link.
    CRITICAL_PRINT(MODULE_NAME, "Software reset 984 Des 0");
    write_reg(fd,0x01,0x30);
    (void)usleep(50*1000);
    CRITICAL_PRINT(MODULE_NAME, "End of PLL Configuration for Daisy Chain");

    CRITICAL_PRINT(MODULE_NAME, "Enabling Daisy Chain Video to Stream_0");

    serdes_wait_des_daisy_link_stable(fd, 100);

    return eStatus;
}

static BridgeChip_StatusType link_set_deserializer_daisy_gpio(int32 fd)
{
    write_reg(fd, 0x40, 0x04); // Page 1
    write_reg(fd, 0x41, 0x11); // BC_GPIO1_SEL
    write_reg(fd, 0x42, 0x00); // BC GPIO1 send local GPIO0

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_deserializer_daisy_temp_optimization(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    uint8 temp_final, rb;
    int32 temp_final_c, ramp_up_range_codes_needed, ramp_dn_range_codes_needed;
    int32 ramp_up_cap_delta, ramp_dn_cap_delta, ts_code_up, ts_code_dn;
    uint8 efuse_ts_code = 2;

    CRITICAL_PRINT(MODULE_NAME, "Set up deserializer Temp Ramp Optimizations");
    i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    // Read Deserializer 0 Temp
    write_reg(fd, 0x40, 0x6C);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13);
    read_reg(fd, 0x42, &temp_final);
    temp_final_c = 2 * temp_final - 273;

    // Set up Deserializer 0 Temp Ramp Optimizations
    ramp_up_range_codes_needed = (150 - temp_final_c) / (190 / 11) + 1;
    ramp_dn_range_codes_needed = (temp_final_c - 30) / (190 / 11) + 1;
    ramp_up_cap_delta = ramp_up_range_codes_needed - 4;
    ramp_dn_cap_delta = ramp_dn_range_codes_needed - 7;

    write_reg(fd, 0x40, 0x3C);
    write_reg(fd, 0x41, 0xF5);
    write_reg(fd, 0x42, (efuse_ts_code << 4) + 1);
    if (ramp_up_cap_delta > 0)
    {
        ts_code_up = efuse_ts_code - ramp_up_cap_delta;
        if (ts_code_up < 0)
            ts_code_up = 0;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_up << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_daisy_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    }

    if (ramp_dn_cap_delta > 0)
    {
        ts_code_dn = efuse_ts_code + ramp_dn_cap_delta;
        if (ts_code_dn >= 7)
            ts_code_dn = 7;
        write_reg(fd, 0x41, 0xF5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_dn << 4);
        write_reg(fd, 0x42, (rb & 0xFF));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb & 0xFF));
        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_daisy_link_stable(fd, 100);
        i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    }
    (void)usleep(20*1000);
    serdes_wait_des_daisy_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);

    return eStatus;
}


static BridgeChip_StatusType link_set_deserializer_daisy_enable_oldi(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);

    CRITICAL_PRINT(MODULE_NAME, "Hold Des DTG in reset");
    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x06); // Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x06); // Hold Port 1 DTG in reset

    CRITICAL_PRINT(MODULE_NAME, "Disable Stream Mapping");
    write_reg(fd, 0x0E, 0x03); // Select both Output Ports
    write_reg(fd, 0xD0, 0x00); // Disable FPD4 video forward to Output Port
    write_reg(fd, 0xD7, 0x00); // Disable FPD3 video forward to Output Port

    CRITICAL_PRINT(MODULE_NAME, "Setup DTG for port 0");

    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x13); // DTG detect HS active high and VS active high
    //write_reg(fd, 0x41, 0x29); // Set Hstart
    //write_reg(fd, 0x42, 0x80); // Hstart upper byte
    //write_reg(fd, 0x41, 0x2A);
    //write_reg(fd, 0x42, 0x24); // Hstart lower byte
    //write_reg(fd, 0x41, 0x2F); // Set HSW
    //write_reg(fd, 0x42, 0x40); // HSW upper byte
    //write_reg(fd, 0x41, 0x30);
    //write_reg(fd, 0x42, 0x10); // HSW lower byte

    CRITICAL_PRINT(MODULE_NAME, "Map video to display output");
    write_reg(fd, 0x0E, 0x03); // Select both Output Ports
    write_reg(fd, 0xD0, 0x0C); // Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xD1, 0x0F); // Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xD6, 0x09); // Send Stream 1 to Output Port 0 and Send Stream 1 to Output Port 1
    write_reg(fd, 0xD7, 0x00); // FPD3 mapping disabled
    write_reg(fd, 0x0E, 0x01); // Select Port 0

    /* Port 0 HUD" OLDI */
    CRITICAL_PRINT(MODULE_NAME, "Setting the stream mapping");
    CRITICAL_PRINT(MODULE_NAME, "Configure 988 oLDI PLL");
    write_reg(fd, 0x40, 0x2C); // Configure OLDI/RGB Port Settings
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x2B);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x0C);
    write_reg(fd, 0x40, 0x2E); // Configure OLDI/RGB PLL
    write_reg(fd, 0x41, 0x08);
    write_reg(fd, 0x42, 0xFC); // PLL_NUM23_16
    write_reg(fd, 0x42, 0x0D); // PLL_NUM15_8
    write_reg(fd, 0x42, 0xE9); // PLL_NUM7_0
    write_reg(fd, 0x42, 0xFF); // PLL_DEN23_16
    write_reg(fd, 0x42, 0xFF); // PLL_DEN15_8
    write_reg(fd, 0x42, 0xA5); // PLL_DEN7_0
    write_reg(fd, 0x41, 0x18);
    write_reg(fd, 0x42, 0x33); // PLL_NDIV
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x13); // TX_SEL_CLKDIV
    write_reg(fd, 0x40, 0x50); // Configure Pixel Size
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x13); //Single OLDI

    CRITICAL_PRINT(MODULE_NAME, "Release Des DTG reset");
    write_reg(fd, 0x40, 0x50); // Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x04); // Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x04); // Release Des DTG reset

    CRITICAL_PRINT(MODULE_NAME, "Enable OLDI Output");
    write_reg(fd, 0x01, 0x40); // OLDI Reset
    serdes_wait_des_daisy_link_stable(fd, 100);
    i2c_set_slave_addr(fd, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x40, 0x2C); // Enable OLDI/RGB
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x10);
    write_reg(fd, 0x41, 0x20); // P0 TX_EN (from strap?)
    write_reg(fd, 0x42, 0x80);

    return eStatus;
}

/*
static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{

    CRITICAL_PRINT(MODULE_NAME, "%s: Enable Backlight", __func__);
    write_reg(fd, 0x03, 0x00);
    (void)usleep(20*1000);
    write_reg(fd, 0x05, 0x00);
    (void)usleep(20*1000);
    write_reg(fd, 0x20, 0x05);

    return BRIDGECHIP_STATUS_SUCCESS;
}
*/

BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8 regval = 0;
    int32 port0_linked = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x0c, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;
    }


    if (port0_linked == 1)
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        serdes_clear_link_crc_err_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType serdes_get_daisy_link_status(int32 fd)
{
    uint8 regval = 0;

    if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_FAILED)
        return BRIDGECHIP_STATUS_FAILED;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);

    if (read_reg(fd, 0x53, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & (1 << DAISY_RX_LOCK_DET_P0)))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        return BRIDGECHIP_STATUS_FAILED;
    }

    return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup: Serializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(i2c_fh, 0x01, SER_RESET_DIGITAL_ALL);
    eStatus |= link_set_serializer_i2c_pass_through(i2c_fh);
    eStatus |= link_set_serializer_gpio(i2c_fh);
    eStatus |= link_set_serializer_dsirx(i2c_fh);
    eStatus |= link_set_serializer_fpd4(i2c_fh);
    eStatus |= link_set_serializer_vp(i2c_fh);
    serdes_clear_link_crc_err_flag(i2c_fh);
    serdes_wait_des_link_stable(i2c_fh, 100);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    struct video_timing des0_timing;

    CRITICAL_PRINT(MODULE_NAME, "Link setup: Deserializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    CRITICAL_PRINT(MODULE_NAME, "Configure IPD Deserializer");
  //  CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer SSCG");
  //  eStatus |= link_set_deserializer_enable_sscg(i2c_fh);
  //  CRITICAL_PRINT(MODULE_NAME, "Enable Serializer SSCG");
  //  eStatus |= link_set_serializer_enable_sscg(i2c_fh);
    eStatus |= link_set_deserializer_temp_optimization(i2c_fh);
    eStatus |= link_set_deserializer_gpio(i2c_fh);
    eStatus |= link_set_deserializer_tx_fpd4(i2c_fh);
    CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer eDP");
    eStatus |= link_set_deserializer_enable_edp_tx(i2c_fh);
    i2c_set_slave_addr(i2c_fh, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "----------Measure Timing from Deserializer 0---------");
    serdes_des_measure_video(i2c_fh, &des0_timing);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

BridgeChip_StatusType dser_daisy_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    struct video_timing des1_timing;

    CRITICAL_PRINT(MODULE_NAME, "Configure HUD Deserializer");
    eStatus |= link_set_deserializer_daisy_temp_optimization(i2c_fh);
    CRITICAL_PRINT(MODULE_NAME, "Enable Deserializer oLDI");
    eStatus |= link_set_deserializer_daisy_enable_oldi(i2c_fh);
    eStatus |= link_set_deserializer_daisy_gpio(i2c_fh);
    i2c_set_slave_addr(i2c_fh, DES_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "----------Measure Timing from Deserializer 1---------");
    serdes_des_measure_video(i2c_fh, &des1_timing);
    //i2c_set_slave_addr(i2c_fh, MCU_DC_ID_7BIT_ALIAS, I2C_ADDRFMT_7BIT);
    //eStatus |= enable_panel_backlight(i2c_fh);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

BridgeChip_StatusType recovery_ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    CRITICAL_PRINT(MODULE_NAME, "Recovery: Serializer FPD-Link IV mode. Build Time=%s, %s", __DATE__, __TIME__);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    if (reset_keep_dsi == 0)
    {
        write_reg(i2c_fh, 0x01, SER_RESET_DIGITAL_ALL);
    }
    eStatus |= link_set_serializer_i2c_pass_through(i2c_fh);
    eStatus |= link_set_serializer_gpio(i2c_fh);
    eStatus |= link_set_serializer_dsirx(i2c_fh);
    eStatus |= link_set_serializer_fpd4(i2c_fh);
    eStatus |= link_set_serializer_vp(i2c_fh);
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return BRIDGECHIP_STATUS_SUCCESS;

}
void set_reset_keep_dsi(int32 val)
{
    reset_keep_dsi = val;
}

#ifdef __cplusplus
}
#endif