#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT       0x0C
#define DES_ID_7BIT       0x2C
#define MCU_ID_7BIT       0x12
#define TOUCH_ID_7BIT     0x24

#define SER_ID_8BIT       (SER_ID_7BIT << 1)      //0x18
#define DES_ID_8BIT       (DES_ID_7BIT << 1)      //0x58
#define MCU_ID_8BIT       (MCU_ID_7BIT << 1)      //0x24
#define TOUCH_ID_8BIT     (TOUCH_ID_7BIT << 1)    //0x48

#define THW               4680
#define TVW               1408
#define AHW               4480
#define AVW               1320
#define HBP               80
#define VBP               40
#define HSW               40
#define VSW               8
#define HFP               80
#define VFP               40
#define PCLK_FREQ         395.367
#define FC_FPD_FREQ       12.528
#define PAGE_REG          0x40
#define PAGE_ADDR         0x41
#define PAGE_DATA         0x42
#define PAGE_DISPPATTEN   0x30
#define HSTART            (HBP+HSW)

#define GENERAL_STS_MASK   0x51
#define GENERAL_STS_MASK_BIT2  0x02
#define GENERAL_STS_MASK_BIT4  0x10
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define BIST_CRC_ERROR_BIT 3
#define BC_CRC_ERROR_BIT   1
#define LINK_DETECT_BIT    0

#define APB_CTL        0x48
#define APB_ADR0       0x49
#define APB_ADR1       0x4A
#define APB_DATA0      0x4B
#define APB_DATA1      0x4C
#define APB_DATA2      0x4D
#define APB_DATA3      0x4E

#define APB_DP_RX      0x00
#define APB_DP0_TX     APB_DP_RX
#define APB_DP1_TX     0x01
#define APB_CFG_DATA   0x02
#define APB_DIE_ID     0x03

static int32 verbosedebug = 1;
static float Main_link_speed = FC_FPD_FREQ;
static int32 reset_keep_dprx = 0;
#define MODULE_NAME "SER-DES [FF1 CS3.0]"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

struct video_timing {
    uint32 htotal;
    uint32 vtotal;
    uint32 hres;
    uint32 vres;
    uint32 hstart;
    uint32 vstart;
    uint32 hswidth;
    uint32 vswidth;
};


static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset);
static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data);
static void dser_getclear_0x54(int32 fd, int32 print);

#if 0
static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}
#endif

/*------------------------------------------------------------------------------
 * write_reg
 * i2c write oprtation function.
 *----------------------------------------------------------------------------*/
static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal < 0) {
        CRITICAL_PRINT(MODULE_NAME, "write_reg failed 0x%x : 0x%x",  reg, val);
        return -1;
    }

    return  0;
}
/*------------------------------------------------------------------------------
 * read_reg
 * i2c read oprtation function.
 *----------------------------------------------------------------------------*/
static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal < 0) {
        CRITICAL_PRINT(MODULE_NAME, "read_reg(0x%x) FAILED, iRetVal=%d", reg, iRetVal);
        return -1;
    }

    return 0;
}

/*------------------------------------------------------------------------------
 * apb_read_reg
 * Ser-Des chip APB register read function.
 * APB register is indirect register which need combine several register opeations.
 *----------------------------------------------------------------------------*/
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x03;
        break;
    case APB_DP1_TX:
        wr_val = 0x0B;
        break;
    case APB_CFG_DATA:
        wr_val = 0x13;
        break;
    case APB_DIE_ID:
        wr_val = 0x1B;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB write channel, try write APB channel 0");
        wr_val = 0x03;
        break;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}
/*------------------------------------------------------------------------------
 * apb_write_reg
 * Ser-Des chip APB register write function.
 * APB register is indirect register which need combine several register opeations.
 *----------------------------------------------------------------------------*/
static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    switch (channel)
    {
    case APB_DP_RX:
        wr_val = 0x01;
        break;
    case APB_DP1_TX:
        wr_val = 0x09;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unsupport APB read channel, try read APB channel 0");
        wr_val = 0x01;
        break;
    }
    write_reg(fd, APB_CTL, wr_val);

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);


    return 0;
}

/*------------------------------------------------------------------------------
 * link_set_serializer_vp
 * Ser chip video processor 0 and 1
 * Config the VP with corresponding display timing and enable the function
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{
    //// *********************************************
    //// Program VP Configs
    //// *********************************************
    // Configure VP 0
    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x1);
    write_reg(fd, 0x42, 0xa8); //Set VP_SRC_SELECT to Stream 0 for SST Mode
    write_reg(fd, 0x41, 0x2);
    write_reg(fd, 0x42, 0x80); //VID H Active
    write_reg(fd, 0x42, 0x11); //VID H Active
    write_reg(fd, 0x41, 0x8);
    write_reg(fd, 0x42, 0x0); //Crop Start X
    write_reg(fd, 0x42, 0x0); //Crop Start X
    write_reg(fd, 0x42, 0x0); //Crop Start Y
    write_reg(fd, 0x42, 0x0); //Crop Start Y
    write_reg(fd, 0x42, 0x7f); //Crop Stop X
    write_reg(fd, 0x42, 0x11); //Crop Stop X
    write_reg(fd, 0x42, 0x27); //Crop Stop Y
    write_reg(fd, 0x42, 0x5);  //Crop Stop Y
    write_reg(fd, 0x41, 0x10);
    write_reg(fd, 0x42, 0x80); //Horizontal Active
    write_reg(fd, 0x42, 0x11); //Horizontal Active
    write_reg(fd, 0x42, 0x50); //Horizontal Back Porch
    write_reg(fd, 0x42, 0x0); //Horizontal Back Porch
    write_reg(fd, 0x42, 0x28); //Horizontal Sync
    write_reg(fd, 0x42, 0x0); //Horizontal Sync
    write_reg(fd, 0x42, 0x48); //Horizontal Total
    write_reg(fd, 0x42, 0x12); //Horizontal Total
    write_reg(fd, 0x42, 0x28); //Vertical Active
    write_reg(fd, 0x42, 0x5); //Vertical Active
    write_reg(fd, 0x42, 0x28); //Vertical Back Porch
    write_reg(fd, 0x42, 0x0); //Vertical Back Porch
    write_reg(fd, 0x42, 0x8); //Vertical Sync
    write_reg(fd, 0x42, 0x0); //Vertical Sync
    write_reg(fd, 0x42, 0x28); //Vertical Front Porch
    write_reg(fd, 0x42, 0x0); //Vertical Front Porch
    write_reg(fd, 0x41, 0x27);
    write_reg(fd, 0x42, 0x0); //HSYNC Polarity = +,  VSYNC Polarity = +
    write_reg(fd, 0x41, 0x0);
    write_reg(fd, 0x42, 0x4); //Enable Cropping
    write_reg(fd, 0x41, 0x23); //M/N Register
    write_reg(fd, 0x42, 0x65); //M value
    write_reg(fd, 0x42, 0x28); //M value
    write_reg(fd, 0x42, 0xf); //N value
    // Configure VP 1
    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x41);
    write_reg(fd, 0x42, 0xa8); //Set VP_SRC_SELECT to Stream 0 for SST Mode
    write_reg(fd, 0x41, 0x42);
    write_reg(fd, 0x42, 0x80); //VID H Active
    write_reg(fd, 0x42, 0x11); //VID H Active
    write_reg(fd, 0x41, 0x48);
    write_reg(fd, 0x42, 0x80); //Crop Start X
    write_reg(fd, 0x42, 0x11); //Crop Start X
    write_reg(fd, 0x42, 0x0); //Crop Start Y
    write_reg(fd, 0x42, 0x0); //Crop Start Y
    write_reg(fd, 0x42, 0xff); //Crop Stop X
    write_reg(fd, 0x42, 0x22); //Crop Stop X
    write_reg(fd, 0x42, 0x27); //Crop Stop Y
    write_reg(fd, 0x42, 0x5); //Crop Stop Y
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80); //Horizontal Active
    write_reg(fd, 0x42, 0x11); //Horizontal Active
    write_reg(fd, 0x42, 0x50); //Horizontal Back Porch
    write_reg(fd, 0x42, 0x0); //Horizontal Back Porch
    write_reg(fd, 0x42, 0x28); //Horizontal Sync
    write_reg(fd, 0x42, 0x0); //Horizontal Sync
    write_reg(fd, 0x42, 0x48); //Horizontal Total
    write_reg(fd, 0x42, 0x12); //Horizontal Total
    write_reg(fd, 0x42, 0x28); //Vertical Active
    write_reg(fd, 0x42, 0x5); //Vertical Active
    write_reg(fd, 0x42, 0x28); //Vertical Back Porch
    write_reg(fd, 0x42, 0x0); //Vertical Back Porch
    write_reg(fd, 0x42, 0x8); //Vertical Sync
    write_reg(fd, 0x42, 0x0); //Vertical Sync
    write_reg(fd, 0x42, 0x28); //Vertical Front Porch
    write_reg(fd, 0x42, 0x0); //Vertical Front Porch
    write_reg(fd, 0x41, 0x67);
    write_reg(fd, 0x42, 0x0); //HSYNC Polarity = +,  VSYNC Polarity = +
    write_reg(fd, 0x41, 0x40);
    write_reg(fd, 0x42, 0x4); //Enable Cropping
    write_reg(fd, 0x41, 0x63); //M/N Register
    write_reg(fd, 0x42, 0x65); //M value
    write_reg(fd, 0x42, 0x28); //M value
    write_reg(fd, 0x42, 0xf); //N value

    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x26); //MAX_M_ADJUST_VP0
    write_reg(fd, 0x42, 0xff);
    //write_reg(fd, 0x41, 0x66); //MAX_M_ADJUST_VP1
    //write_reg(fd, 0x42, 0xff);
    CRITICAL_PRINT(MODULE_NAME, "MAX_M_ADJUST_VP set for VP0");
    //// *********************************************
    //// Enable VPs
    //// *********************************************
    write_reg(fd, 0x43, 0x1); //Set number of VPs used = 2
    write_reg(fd, 0x44, 0x3); //Enable video processors
    //// *********************************************
    //// Configure Serializer TX Link Layer
    //// *********************************************
    write_reg(fd, 0x40, 0x2e); //Link layer Reg page
    write_reg(fd, 0x41, 0x1); //Link layer 0 stream enable
    write_reg(fd, 0x42, 0x3); //Link layer 0 stream enable
    write_reg(fd, 0x41, 0x6); //Link layer 0 time slot 0
    write_reg(fd, 0x42, 0x20); //Link layer 0 time slot
    write_reg(fd, 0x41, 0x7); //Link layer 0 time slot 1
    write_reg(fd, 0x42, 0x20); //Link layer 0 time slot
    write_reg(fd, 0x41, 0x20); //Set Link layer vp bpp
    write_reg(fd, 0x42, 0x6a); //Set Link layer vp bpp according to VP Bit per pixel
    write_reg(fd, 0x41, 0x0); //Link layer 0 enable
    write_reg(fd, 0x42, 0x3); //Link layer 0 enable

    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * check_98x_chipid
 * read the chip ID register to get the ID
 *----------------------------------------------------------------------------*/
bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;

    if (read_reg(fd, 0x00, &regval) == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", regval, chipId);
        if (regval == chipId)
            return TRUE;
        else
            return FALSE;
    } else {
        return FALSE;
    }
}

/*------------------------------------------------------------------------------
 * check_mesaured_video
 * To judge the timing is match the expectation or not
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType check_mesaured_video(struct video_timing *timing)
{
    if ((timing->vtotal > (TVW -10)) && (timing->vtotal < (TVW + 10)) &&
            (timing->htotal > (THW -10)) && (timing->htotal < (THW + 10)) &&
            (timing->hres == AHW) && (timing->vres == AVW))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }

    return BRIDGECHIP_STATUS_FAILED;
}

/*------------------------------------------------------------------------------
 * serdes_des_measure_video_fpd_iv
 * Diagnostic function to read FPD IV Link Layer Timing
 *----------------------------------------------------------------------------*/
static uint32 serdes_des_measure_video_fpd_iv(int32 fd, int32 print_status)
{
    int32 i;
    uint32 hactive = 0;
    uint8 regval;

    if (print_status)
        CRITICAL_PRINT(MODULE_NAME, "FPD IV Link Layer Timing:");
    write_reg(fd, 0x40, 0x4B);
    write_reg(fd, 0x41, 0x39);

    for (i = 0; i < 4; i++)
    {
        read_reg(fd, 0x42, &regval);
        hactive = regval;
        read_reg(fd, 0x42, &regval);
        hactive = hactive + (regval << 8);
        if (print_status)
        {
            CRITICAL_PRINT(MODULE_NAME, "Stream %d Hactive = %d", i, hactive);
        }
    }

    return 0;
}

/*------------------------------------------------------------------------------
 * serdes_des_measure_video_dptx
 * Diagnostic function to read DES chip DPTX timing
 *----------------------------------------------------------------------------*/
static uint32 serdes_des_measure_video_dptx(int32 fd, int32 port, struct video_timing *timing, int32 print_status)
{
    uint32 htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;

    uint8 channel = 0;

    if (port == 0)
    {
        channel = APB_DP0_TX;
    }
    else if (port == 1)
    {
        channel = APB_DP1_TX;
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, "Unknow Port Selected port = %d", port);
        return 0;
    }

    htotal  = apb_read_reg(fd, channel, 0x180);
    vtotal  = apb_read_reg(fd, channel, 0x184);
    hswidth = apb_read_reg(fd, channel, 0x18C);
    vswidth = apb_read_reg(fd, channel, 0x190);
    hres    = apb_read_reg(fd, channel, 0x194);
    vres    = apb_read_reg(fd, channel, 0x198);
    hstart  = apb_read_reg(fd, channel, 0x19C);
    vstart  = apb_read_reg(fd, channel, 0x1A0);

    if (print_status)
    {
        CRITICAL_PRINT(MODULE_NAME, "Port%d: 984 DPTX VIDEO RESOLUTION:", port);
        CRITICAL_PRINT(MODULE_NAME, "htotal(0x180)= %d " \
                "vtotal(0x184)=%d " \
                "hswidth(0x18C)=%d " \
                "vswidth(0x190)=%d " \
                "hres(0x194)=%d " \
                "vres(0x198)=%d " \
                "hstart(0x19C)=%d " \
                "vstart(0x1A0)=%d",
                htotal,
                vtotal,
                hswidth,
                vswidth,
                hres,
                vres,
                hstart,
                vstart);
    }

    if (timing)
    {
        timing->htotal = htotal;
        timing->vtotal = vtotal;
        timing->hres = hres;
        timing->vres = vres;
        timing->hstart = hstart;
        timing->vstart = vstart;
        timing->hswidth = hswidth;
        timing->vswidth = vswidth;
    }

    return htotal;
}

/*------------------------------------------------------------------------------
 * serdes_des_measure_video_dtg
 * Diagnostic function to read DES chip DTG timing
 *----------------------------------------------------------------------------*/
static uint32 serdes_des_measure_video_dtg (int32 fd, int32 port, struct video_timing *timing, int32 print_status)
{
    uint8 offset;
    uint32 htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;
    uint8 read_val;

    if (port == 0)
    {
        offset = 0;
    }
    else
    {
        offset = 0x30;
    }

    do {
        write_reg(fd, 0x40, 81);

        write_reg(fd, 0x41, 0x40 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = read_val * 256;

        write_reg(fd, 0x41, 0x41 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = htotal + read_val;

        write_reg(fd, 0x41, 0x42 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = read_val * 256;
        write_reg(fd, 0x41, 0x43 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = vtotal + read_val;

        write_reg(fd, 0x41, 0x44 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = read_val * 256;
        write_reg(fd, 0x41, 0x45 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = hres + read_val;

        write_reg(fd, 0x41, 0x46 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = read_val * 256;
        write_reg(fd, 0x41, 0x47 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = vres + read_val;

        write_reg(fd, 0x41, 0x48 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = read_val * 256;
        write_reg(fd, 0x41, 0x49 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = hstart + read_val;

        write_reg(fd, 0x41, 0x4a + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = read_val * 256;
        write_reg(fd, 0x41, 0x4b + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = vstart + read_val;

        write_reg(fd, 0x41, 0x4c + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4d + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = hswidth + read_val;

        write_reg(fd, 0x41, 0x4e + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4f + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = vswidth + read_val;

    } while (0);

    if (print_status)
    {
        CRITICAL_PRINT(MODULE_NAME, "Port%d: DTG VIDEO RESOLUTION", port);
        CRITICAL_PRINT(MODULE_NAME, "htotal=%d " \
                "vtotal=%d " \
                "hswidth=%d " \
                "vswidth=%d " \
                "hres =%d " \
                "vres =%d " \
                "hstart=%d " \
                "vstar=%d",
                htotal,
                vtotal,
                hswidth,
                vswidth,
                hres,
                vres,
                hstart,
                vstart);
    }

    if (timing)
    {
        timing->htotal = htotal;
        timing->vtotal = vtotal;
        timing->hres = hres;
        timing->vres = vres;
        timing->hstart = hstart;
        timing->vstart = vstart;
        timing->hswidth = hswidth;
        timing->vswidth = vswidth;
    }

    return htotal;
}

/*------------------------------------------------------------------------------
 * serdes_des_read_video_stream_error_status
 * Diagnostic function to read DES chip ECC and CRC error and can select clear
 * only fucntion by clear_err argument
 *----------------------------------------------------------------------------*/
static uint32 serdes_des_read_video_stream_error_status(int32 fd, int32 stream_id, int32 err_wait, int32 clear_err, int32 print_status)
{
    uint8 offset = 0;
    uint8 s_video_comp = 0;
    uint8 bpp = 0;
    uint8 regval = 0;
    uint16 line_length = 0;
    uint16 line_cnt = 0;
    uint16 crc = 0;
    uint16 ecc = 0;
    uint32 data_frame_cnt = 0;
    uint32 ctl_frame_cnt = 0;
    uint8 ecc_error_flag = 0;
    uint8 crc_error_flag = 0;
    uint8 line_lgth_chng = 0;
    uint8 line_cnt_chng = 0;
    uint8 error_flags = 0;

    write_reg(fd, 0x40, 0x48);  // Page 18

    switch (stream_id)
    {
    case 0:
        offset = 0;
        write_reg(fd, 0x41, 0x45);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = s_video_comp & 0x03;
        break;
    case 1:
        offset = 0x10;
        write_reg(fd, 0x41, 0x45);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = (s_video_comp >> 2) & 0x03;
        break;
    case 2:
        offset = 0x20;
        write_reg(fd, 0x41, 0x45);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = (s_video_comp >> 4) & 0x03;
        break;
    case 3:
        offset = 0x30;
        write_reg(fd, 0x41, 0x45);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = (s_video_comp >> 6) & 0x03;
        break;
    case 4:
        offset = 0x40;
        write_reg(fd, 0x41, 0x46);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = s_video_comp & 0x03;
        break;
    case 5:
        offset = 0x50;
        write_reg(fd, 0x41, 0x46);
        read_reg(fd, 0x42, &s_video_comp);
        s_video_comp = (s_video_comp >> 2) & 0x03;
        break;
    default:
        CRITICAL_PRINT(MODULE_NAME, "Unknown stream id = %d", stream_id);
        break;
    }

    if (s_video_comp == 0x00)
        bpp = 18;
    else if (s_video_comp == 0x01)
        bpp = 24;
    else if (s_video_comp == 0x02)
        bpp = 30;
    else
        bpp = 0;

    // ENABLE CAPTURE

    // Disable All Captures (Main & Stream Based)
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x00);  // Disable All Captures & Update
    write_reg(fd, 0x41, 0x60 + offset);
    write_reg(fd, 0x42, 0x00);  // Disable All Captures & Update

    // Select All Captures (Main & Stream Based)
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x3F);  // Select All Captures
    write_reg(fd, 0x41, 0x60 + offset);
    write_reg(fd, 0x42, 0xF0);  // Select All Captures (Stream Based)

    if (clear_err)
    {
        // Select All Clear Controls (Main & Stream Based)
        write_reg(fd, 0x41, 0x2A);
        write_reg(fd, 0x42, 0x3F);  // Select All Clear Controls
        write_reg(fd, 0x41, 0x60 + offset);
        write_reg(fd, 0x42, 0xFF);  // Select All Clear Controls (Stream Based)

        write_reg(fd, 0x40, 18 * 4);
        // Toggle re_update_en to take effect
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x3F);  // Toggle re_update_en
        write_reg(fd, 0x41, 0x29);
        write_reg(fd, 0x42, 0x7F);  // Toggle re_update_en

        // De-Select All Clear Controls (Main & Stream Based)
        write_reg(fd, 0x41, 0x2A);
        write_reg(fd, 0x42, 0x00);  // Select All Clear Controls
        write_reg(fd, 0x41, 0x60 + offset);
        write_reg(fd, 0x42, 0xF0);  // Select All Clear Controls (Stream Based)
    }

    // Toggle re_update_en to take effect
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x3F);  // Toggle re_update_en
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x7F);  // Toggle re_update_en

    // Clear Stream Error Flags
    write_reg(fd, 0x40, 18 * 4 + 1);
    write_reg(fd, 0x41, 0x69 + offset);
    read_reg(fd, 0x42, &regval);
    read_reg(fd, 0x42, &regval);
    write_reg(fd, 0x40, 18 * 4);

    // WAIT TIMER
    if (err_wait)
        (void) usleep(err_wait * 1000);

    // LINE_LENGTH
    write_reg(fd, 0x41, 0x66 + offset);

    read_reg(fd, 0x42, &regval);
    line_length = regval << 8;
    write_reg(fd, 0x41, 0x65 + offset);
    read_reg(fd, 0x42, &regval);
    line_length = line_length + regval;

    // LINE_COUNT
    write_reg(fd, 0x41, 0x68 + offset);
    read_reg(fd, 0x42, &regval);
    line_cnt = regval << 8;
    write_reg(fd, 0x41, 0x67 + offset);
    read_reg(fd, 0x42, &regval);
    line_cnt = line_cnt + regval;

    // CRC
    write_reg(fd, 0x41, 0x64 + offset);
    read_reg(fd, 0x42, &regval);
    crc = regval << 8;
    write_reg(fd, 0x41, 0x63 + offset);
    read_reg(fd, 0x42, &regval);
    crc = crc + regval;

    // ECC
    write_reg(fd, 0x41, 0x62 + offset);
    read_reg(fd, 0x42, &regval);
    ecc = regval << 8;
    write_reg(fd, 0x41, 0x61 + offset);
    read_reg(fd, 0x42, &regval);
    ecc = ecc + regval;

    // Frame Data Counter
    write_reg(fd, 0x41, 0x33);
    read_reg(fd, 0x42, &regval);
    data_frame_cnt = regval << 16;
    write_reg(fd, 0x41, 0x32);
    read_reg(fd, 0x42, &regval);
    data_frame_cnt = data_frame_cnt + (regval << 8);
    write_reg(fd, 0x41, 0x31);
    read_reg(fd, 0x42, &regval);
    data_frame_cnt = data_frame_cnt + regval;

    // Frame Control Counter
    write_reg(fd, 0x41, 0x30);
    read_reg(fd, 0x42, &regval);
    ctl_frame_cnt = regval << 16;
    write_reg(fd, 0x41, 0x2F);
    read_reg(fd, 0x42, &regval);
    ctl_frame_cnt = ctl_frame_cnt + (regval << 8);
    write_reg(fd, 0x41, 0x2E);
    read_reg(fd, 0x42, &regval);
    ctl_frame_cnt = ctl_frame_cnt + regval;

    // READ FLAGS
    write_reg(fd, 0x40, 18 * 4 + 1);
    write_reg(fd, 0x41, 0x69 + offset);
    read_reg(fd, 0x42, &regval);
    ecc_error_flag = (regval >> 3) & 0x01;
    crc_error_flag = (regval >> 2) & 0x01;
    line_lgth_chng = (regval >> 1) & 0x01;
    line_cnt_chng = regval & 0x01;
    write_reg(fd, 0x40, 18 * 4);

    error_flags = ecc_error_flag || crc_error_flag || line_lgth_chng;  // || line_cnt_chng

    if (print_status)
    {
        CRITICAL_PRINT(MODULE_NAME, "STREAM=%d ERROR_WAIT=%d CLEAR_ERR=%d", stream_id, err_wait, clear_err);
        CRITICAL_PRINT(MODULE_NAME, "ERROR FLAGS: ECC_ERROR_FLAG=%d CRC_ERROR_FLAG=%d LINE_LGTH_CHNG=%d LINE_CNT_CHNG=%d",
                ecc_error_flag, crc_error_flag, line_lgth_chng, line_cnt_chng);
        CRITICAL_PRINT(MODULE_NAME, "READ_VIDEO_STREAM_ERROR_STATUS: ALL_ERROR_FLAG=0x%02X CRC ERR=%d ECC ERR=%d LINE_LENGTH=%d LINE_CNT=%d BPP=%d",
                regval, crc, ecc, line_length, line_cnt, bpp);
        CRITICAL_PRINT(MODULE_NAME, "DATA_FRAME_CNT=0x%X CONTROL_FRAME_CNT=0x%X STREAM=%d ERROR_WAIT=%d",
                data_frame_cnt, ctl_frame_cnt, stream_id, err_wait);
    }

    return error_flags; // ERROR_FLAGS, BPP, LINE_LENGTH, LINE_CNT, CRC, ECC, ECC_ERROR_FLAG, CRC_ERROR_FLAG, LINE_LGTH_CHNG, LINE_CNT_CHNG, DATA_FRAME_CNTR, CTL_FRAME_CNTR
}

/*------------------------------------------------------------------------------
 * serdes_check_des_fifo_ov
 * Diagnostic function to read DES chip FIFO status
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serdes_check_des_fifo_ov(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    uint32 dp0_fifo_ov, dp1_fifo_ov;

    dp0_fifo_ov = apb_read_reg(fd, APB_DP0_TX, 0x1CC);
    dp1_fifo_ov = apb_read_reg(fd, APB_DP1_TX, 0x1CC);

    if ((dp0_fifo_ov & 0x03) > 0 || (dp1_fifo_ov & 0x03) > 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "DES FIFO OVERFLOW: dp0_fifo_ov = 0x%04x, dp1_fifo_ov = 0x%04x",
                dp0_fifo_ov, dp1_fifo_ov);
        eStatus = BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        eStatus = BRIDGECHIP_STATUS_FAILED;
    }

    return eStatus;
}

/*------------------------------------------------------------------------------
 * serdes_do_des_dp_dtg_reset
 * FIFO overflow handling. Follow TI script to do DTG reset.
 *----------------------------------------------------------------------------*/
static void serdes_do_des_dp_dtg_reset(int32 fd)
{
    //*********************************************
    // Hold Des DTG in reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x6);  //Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x6);  //Hold Port 1 DTG in reset

    apb_write_reg(fd, APB_DP0_TX, 0x90, 0x01);         //Enable DP0 link management
    apb_write_reg(fd, APB_DP1_TX, 0x90, 0x01);         //Enable DP1 link management

    //*********************************************
    // Release Des DTG reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset
}

/*------------------------------------------------------------------------------
 * serdes_wait_des_link_stable
 * fast polling to check linkup status
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serdes_wait_des_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / 10;

    do
    {
        if (serdes_get_ser_link_status(fd, 0) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(10 * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

/*------------------------------------------------------------------------------
 * serializer_i2c_pass_through_cfg
 * remote slave device at display side address config
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serializer_i2c_pass_through_cfg(int32 fd)
{
    uint8 RevId = 0;
    write_reg(fd, 0x2D, 0x01);

    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, TOUCH_ID_8BIT);
    write_reg(fd, 0x7A, TOUCH_ID_8BIT);

    read_reg(fd, 0x30, &RevId);
    // Config GPIOs for Touch IRQ
    if (RevId >= 0x40)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);
    CRITICAL_PRINT(MODULE_NAME," Enable I2C Pass Through");
    write_reg(fd, 0x07, 0x88);
    write_reg(fd, 0x3A, 0x88);  // Disable Remote I2C controller from FPD Link Port 0 and Port 1

    CRITICAL_PRINT(MODULE_NAME, "Set i2c pass through done");

    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * serializer_dprx_cfg
 * Ser DPRX config. this is precondition for DP link training with SoC
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serializer_dprx_cfg(int32 fd)
{
    //# *********************************************
    //# Set DP Config
    //# *********************************************
    apb_write_reg(fd, APB_DP_RX, 0x00, 0x00);   //Force HPD low to configure 983 DP settings
    apb_write_reg(fd, APB_DP_RX, 0x214, 0x02);  //Request min VOD swing of 0x02

    //Lane Rate Optimizations for CS2.0 with 8155 at 8.1Gbps (No SSC);
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x4c);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xb0);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xcc);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xd0);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xd6);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x4c);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xb0);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xcc);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xd0);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0xd6);
    write_reg(fd, 0x42, 0x0);

    // apb_write_reg(fd, APB_DP_RX, 0x18, 0x14);     //Set SST/MST mode and DP/eDP Mode
    apb_write_reg(fd, APB_DP_RX, 0xA0C, 0x01);     //Disable line reset for VS0 - suggested remove by TI
    CRITICAL_PRINT(MODULE_NAME, "------>0xA0C = 0x%x", apb_read_reg(fd, APB_DP_RX, 0xa0c));
    apb_write_reg(fd, APB_DP_RX, 0x00, 0x01);     //Force HPD high to trigger link training

    // Allow time after HPD is pulled high for the source to train and provide video (may need to adjust based on source properties);
    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * link_set_serializer_fpd4
 * Ser chip FPD4 initialization.  prepare for link to DES Chip.
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 Value = 0;

    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");
    //Disable FPD3 FIFO pass through
    write_reg(fd, 0x5B, 0x23);
    write_reg(fd, 0x05, 0x28); // FPD_TX to DUAL
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B); //Disable PLL0
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0x5B); //Disable PLL1
    write_reg(fd, 0x42, 0x08);
    //Change FPDTX FPD3_MODE_CTL
    //write_reg(fd, 0x59, 0x03);  //weller review:
    write_reg(fd, 0x02, 0xD1);
    write_reg(fd, 0x2D, 0x01);
    Value = Main_link_speed * 1000 / 27 / 4;
    CRITICAL_PRINT(MODULE_NAME," Programming Serializer PLL, Value = 0x%x(expect 0x74)", Value);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x6A, 0x4A);
    write_reg(fd, 0x6E, 0x80);
    write_reg(fd, 0x40, 0x04); //#Select FPD page and set BC settings for FPD IV port 0
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x0D);
    write_reg(fd, 0x42, 0x34);
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0x53);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x2D, 0x12);
    write_reg(fd, 0x6A, 0x4A);
    write_reg(fd, 0x6E, 0x80);
    write_reg(fd, 0x40, 0x04);//#Select FPD page and set BC settings for FPD IV port 1
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0x00) ;
    write_reg(fd, 0x41, 0x2D);
    write_reg(fd, 0x42, 0x34);
    write_reg(fd, 0x41, 0x2E);
    write_reg(fd, 0x42, 0x53);
    write_reg(fd, 0x02, 0xD1) ;//#Set HALFRATE_MODE
    // Zero out fractional
    write_reg(fd, 0x40, 0x08); //Select PLL page, reviewd with casey
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);
    //Configure and Enable PLLs
    write_reg(fd, 0x41, 0x0e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x4e);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x1B);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5B);
    write_reg(fd, 0x42, 0x00);
    CRITICAL_PRINT(MODULE_NAME," Software reset 983");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    //todo:
    serdes_wait_des_link_stable(fd, 50);
    CRITICAL_PRINT(MODULE_NAME," Software reset 984");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 50);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME,"983 link layer config");
    //reiewed with casey: not need below 4 lines
    //write_reg(fd, 0x40, 0x2E);
    //write_reg(fd, 0x41, 0x00);
    //write_reg(fd, 0x42, 0x03);
    write_reg(fd, 0x2D, 0x01);
    //write_reg(fd, 0x01, 0x30);
    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * serializer_video_input_reset
 * called after DP link training and video ready.
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serializer_video_input_reset(int32 fd)
{
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    apb_write_reg(fd, APB_DP_RX, 0x54, 0x01);   //Video Input Reset (should be executed after DP video is available from the source);

    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * serdes_check_ser_vp_status
 * function to check the Ser chip VP sync status register
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType serdes_check_ser_vp_status(int32 fd)
{
    uint8  vp_status;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x45, &vp_status);

    if(((vp_status & 0x1) == 1)  &&  (((vp_status >> 1) & 0x01) == 1))
    {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>vp  synced");
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME, ">>>>>>>vp not synced, do reset");
        return BRIDGECHIP_STATUS_FAILED;
    }
}

/*------------------------------------------------------------------------------
 * serdes_check_983_dp_linkup
 * check the SoC
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd)
{
    uint32 lane01_status, lane23_status, h_res, v_res;
    static uint8  vp_status = 0, vp_status_tmp = -1, status_change = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    lane01_status = apb_read_reg(fd, APB_DP_RX, 0x43C);
    lane23_status = apb_read_reg(fd, APB_DP_RX, 0x440);
    h_res = apb_read_reg(fd, APB_DP_RX, 0x500);
    v_res = apb_read_reg(fd, APB_DP_RX, 0x514);
    read_reg(fd, 0x45, &vp_status);

    if (vp_status != vp_status_tmp)
    {
        CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | WxH = %d x %d",
                vp_status & 0x1, (vp_status >> 1) & 0x01, h_res, v_res);

        serdes_get_983_dp_rx_status(fd);
        vp_status_tmp = vp_status;

    }

    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377) && (h_res == 8960) && (v_res = 1320))
    {
        if (status_change == 0)
            CRITICAL_PRINT(MODULE_NAME, "DP video source ready");
        status_change = 1;
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        //only print when dp from ok to bad
        if (status_change == 1)
        {
            CRITICAL_PRINT(MODULE_NAME, "FATAL: | VP0:%d | VP1:%d | lane_status: 0x%x, 0x%x,  WxH = %d x %d, Screen is BLACK",
                    vp_status & 0x1, (vp_status >> 1) & 0x01, lane01_status, lane23_status, h_res, v_res);
        }

        status_change = 0;
        return BRIDGECHIP_STATUS_FAILED;
    }
}

/*------------------------------------------------------------------------------
 * serdes_get_983_dp_rx_status
 * dump the Ser chip DPRX detail for incoming video status and DP link status
 *----------------------------------------------------------------------------*/
void serdes_get_983_dp_rx_status(int32 fd)
{
    uint32 dp_rate, lanes;
    uint32 h_res, h_total;
    uint32 v_res, v_total;
    uint32 lane01_status, lane23_status;
    uint8  vp_status;

    dp_rate = apb_read_reg(fd, APB_DP_RX, 0x400) * 27;
    lanes = apb_read_reg(fd, APB_DP_RX, 0x404);
    lane01_status = apb_read_reg(fd, APB_DP_RX, 0x43C);
    lane23_status = apb_read_reg(fd, APB_DP_RX, 0x440);
    h_res = apb_read_reg(fd, APB_DP_RX, 0x500);
    h_total = apb_read_reg(fd, APB_DP_RX, 0x510);
    v_res = apb_read_reg(fd, APB_DP_RX, 0x514);
    v_total = apb_read_reg(fd, APB_DP_RX, 0x524);

    read_reg(fd, 0x45, &vp_status);

    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "983 DPRX:");
    CRITICAL_PRINT(MODULE_NAME, "DP Rate: %d, Lanes: %d, Lane01: 0x%x, Lane23: 0x%x, Htotal:%d(9360), Vtotal:%d(1408), WxH:%d x %d", 
            dp_rate, lanes, lane01_status, lane23_status, h_total, v_total, h_res, v_res);
    CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d", vp_status & 0x1, (vp_status >> 1) & 0x01);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
}

/*------------------------------------------------------------------------------
 * serdes_clear_link_crc_err_flag
 * clear the Ser chip CRC error register 
 *----------------------------------------------------------------------------*/
static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

/*------------------------------------------------------------------------------
 * serdes_ser_get_crc_err_count
 * get  crc err count
 *----------------------------------------------------------------------------*/
static void serdes_ser_log_crc_err_count(int32 fd)
{
    uint8 bc_crc_count_lsb = 0;
    uint8 bc_crc_count_msb = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0a, &bc_crc_count_lsb);
    read_reg(fd, 0x0b, &bc_crc_count_msb);
    CRITICAL_PRINT(MODULE_NAME, "port0 bc_crc_count:0x%x", ((bc_crc_count_msb<<8) | bc_crc_count_lsb));
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0a, &bc_crc_count_lsb);
    read_reg(fd, 0x0b, &bc_crc_count_msb);
    CRITICAL_PRINT(MODULE_NAME, "port1 bc_crc_count:0x%x", ((bc_crc_count_msb<<8) | bc_crc_count_lsb));
    write_reg(fd, 0x2D, 0x01);
}

/*------------------------------------------------------------------------------
 * serdes_des_update_cfg
 * Function to initialize the Des chip
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType serdes_des_update_cfg(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    //uint8 regval;
    //uint32 addr = 0;
    //uint32 apb_reg_val = 0;
    uint8 temp_final, rb;
    int32 temp_final_c, ramp_up_range_codes_needed, ramp_dn_range_codes_needed, ramp_up_cap_delta, ramp_dn_cap_delta, ts_code_up, ts_code_dn;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);

    //*********************************************
    // Diagnostics
    //*********************************************
    //serdes_des_measure_video_dptx(fd, 0, NULL, 1);
    //serdes_des_measure_video_dptx(fd, 1, NULL, 1);
    //read_reg(fd, 0x00, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back DES_ID after temp ramp optimization - expected 0x%02X, DES_ID = 0x%02X", DES_ID_8BIT, regval);
    //read_reg(fd, 0x54, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back deserializer status reg 0x54 for port 0 - expected 0x53 or 0xD3 - received 0x%X", regval);
    //write_reg(fd, 0x0E, 0x12); // select port 1
    //read_reg(fd, 0x54, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back deserializer status reg 0x54 for port 1 - expected 0x53 or 0xD3 - received 0x%X", regval);
    //write_reg(fd, 0x0E, 0x01); // select port 0

    //*********************************************
    // Map video to display output
    //*********************************************
    //Fist write the stream map register in case of i2c write failed on bellow
    //register writes.
    write_reg(fd, 0xe, 0x3);  //Select both Output Ports
    write_reg(fd, 0xd6, 0x1);  //Send Stream 0 to Output Port 1 and Send Stream 1 to Output Port 0
    write_reg(fd, 0xe, 0x1);  //Select Port 0
    //*********************************************
    // Read Deserializer 0 Temp
    //*********************************************
    write_reg(fd, 0x40, 0x6c);
    write_reg(fd, 0x41, 0xd);
    write_reg(fd, 0x42, 0x0);
    write_reg(fd, 0x41, 0x13);
    read_reg(fd, 0x42, &temp_final);
    temp_final_c = 2*temp_final - 273;

    //**********************************************
    // Set up Deserializer 0 Temp Ramp Optimizations
    //**********************************************
    ramp_up_range_codes_needed = (150-temp_final_c)/(190/11) + 1;
    ramp_dn_range_codes_needed = (temp_final_c-30)/(190/11) + 1;
    ramp_up_cap_delta = ramp_up_range_codes_needed - 4;
    ramp_dn_cap_delta = ramp_dn_range_codes_needed - 7;

    if (ramp_up_cap_delta > 0)
    {
        ts_code_up = 4 - ramp_up_cap_delta;
        if (ts_code_up < 0)
            ts_code_up = 0;
        write_reg(fd, 0x40, 0x3c);
        write_reg(fd, 0x41, 0xf5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_up << 4);
        write_reg(fd, 0x42, (rb&0xff));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb&0xff));
        write_reg(fd, 0x1, 0x1);
    }

    if (ramp_dn_cap_delta > 0)
    {
        ts_code_dn = 4 + ramp_dn_cap_delta;
        if (ts_code_dn >= 7)
            ts_code_dn = 7;
        write_reg(fd, 0x40, 0x3c);
        write_reg(fd, 0x41, 0xf5);
        read_reg(fd, 0x42, &rb);
        rb &= 0x8F;
        rb |= (ts_code_dn << 4);
        write_reg(fd, 0x42, (rb&0xff));

        read_reg(fd, 0x42, &rb);
        rb &= 0xFE;
        rb |= 0x01;
        write_reg(fd, 0x42, (rb&0xff));
        write_reg(fd, 0x1, 0x1);
    }

    // Due to Ti CS3.0 chip relock issue this kind of behavior where the lock
    // comes up initially and then drops and toggles a few times before becoming
    // fully stable. The process normally takes < 30ms but maybe in a rare case
    // it is taking longer? On the final trim silicon a revised lock algorithm
    // is used that does not have this behavior of toggling many times and the
    // lock time is reduced to <10ms.
    //
    //TODO: review with casey: delay only when there is reset happen above
    (void)usleep(50 * 1000);   //give 50 msec delay for stable lock
    if (serdes_wait_des_link_stable(fd, 50) == BRIDGECHIP_STATUS_FAILED)
    {
        /* We should not be entering here as per TI, safer side giving another 50msec in rare cases*/
        CRITICAL_PRINT(MODULE_NAME,"Wait des link stable failed");
        (void)usleep(50 * 1000);   //give another 50 msec delay for stable lock
    }

    //*********************************************
    // Diagnostics -- can be removed
    //*********************************************
    //read_reg(fd, 0x00, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back DES_ID after temp ramp optimization - expected 0x%02X, DES_ID = 0x%02X", DES_ID_8BIT, regval);
    // Clear 0x54 status register initial flags
    //write_reg(fd, 0x0E, 0x01); // select port 0
    //read_reg(fd, 0x54, &regval);
    //write_reg(fd, 0x0E, 0x12); // select port 1
    //read_reg(fd, 0x54, &regval);
    //write_reg(fd, 0x0E, 0x01); // select port 0
    // Clear initial video stream errors, no print

    //*********************************************
    // Clear CRC errors from initial link process
    // FIXME:
    //*********************************************
    serdes_clear_link_crc_err_flag(fd);
    serdes_ser_log_crc_err_count(fd);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    serdes_des_read_video_stream_error_status(fd, 0, 0, 1, 0);
    serdes_des_read_video_stream_error_status(fd, 1, 0, 1, 0);

    //*********************************************
    // Hold Des DTG in reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x6);  //Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x6);  //Hold Port 1 DTG in reset

    //*********************************************
    // Disable Stream Mapping
    //*********************************************
    write_reg(fd, 0xe, 0x3);  //Select both Output Ports
    write_reg(fd, 0xd0, 0x0);  //Disable FPD4 video forward to Output Port
    write_reg(fd, 0xd7, 0x0);  //Disable FPD3 video forward to Output Port

    //*********************************************
    // Force DP Rate
    //*********************************************
    write_reg(fd, 0x40, 0x2c);  //Select DP Page
    write_reg(fd, 0x41, 0x81);
    write_reg(fd, 0x42, 0xc0);  //Set DP Rate to 5.4Gbps
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0x2);  //Enable force DP rate
    write_reg(fd, 0x41, 0x91);
    write_reg(fd, 0x42, 0xc);  //Force 4 lanes
    write_reg(fd, 0x40, 0x30);  //Disable DP SSCG
    write_reg(fd, 0x41, 0xf);
    write_reg(fd, 0x42, 0x1);
    write_reg(fd, 0x1, 0x40);

    //*********************************************
    // Diagnostics -- Can be removed
    //*********************************************
    //(void)usleep(100 * 1000);
    //CRITICAL_PRINT(MODULE_NAME, "Read back DP Train Status on DPRX - expect 0x77, 0x77");
    //for (addr = 0x202; addr < 0x204; addr++)
    //{
    // Aux read transaction to read DPCD registers
    //apb_write_reg(fd, APB_DP0_TX, 0x108, addr);         //AUX address
    //apb_write_reg(fd, APB_DP0_TX, 0x100, 0x900);        //AUX command to read
    //(void)usleep(250 * 1000);
    //apb_reg_val = apb_read_reg(fd, APB_DP0_TX, 0x134);
    //CRITICAL_PRINT(MODULE_NAME, "DPCD addr 0x%X is 0x%X", addr, apb_reg_val);
    //}

    //*********************************************
    // Setup DP ports
    //*********************************************
    // Both Ports enabled

    //*********************************************
    // Map video to display output
    //*********************************************
    write_reg(fd, 0xe, 0x3);  //Select both Output Ports
    write_reg(fd, 0xd0, 0xc);  //Enable FPD_RX video forward to Output Port
    write_reg(fd, 0xd1, 0xf);  //Every stream forwarded on DC
    write_reg(fd, 0xd6, 0x1);  //Send Stream 0 to Output Port 1 and Send Stream 1 to Output Port 0
    write_reg(fd, 0xd7, 0x0);  //FPD3 mapping disabled
    write_reg(fd, 0xe, 0x1);  //Select Port 0

    //*********************************************
    // Program quad pixel clock for DP port 0
    //*********************************************
    write_reg(fd, 0xe, 0x1);  //Select Port0 registers
    write_reg(fd, 0xb1, 0x1);  //Enable clock divider
    write_reg(fd, 0xb2, 0x67);  //Program M value lower byte
    write_reg(fd, 0xb3, 0x8);  //Program M value middle byte
    write_reg(fd, 0xb4, 0x6);  //Program M value upper byte
    write_reg(fd, 0xb5, 0x80);  //Program N value lower byte
    write_reg(fd, 0xb6, 0xf5);  //Program N value middle byte
    write_reg(fd, 0xb7, 0x20);  //Program N value upper byte
    write_reg(fd, 0xe, 0x1);  //Select Port 0 registers

    //*********************************************
    // Setup DTG for port 0
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0xa3);  //DTG detect HS active high and VS active high
    write_reg(fd, 0x41, 0x29);  //Set Hstart
    write_reg(fd, 0x42, 0x80);  //Hstart upper byte
    write_reg(fd, 0x41, 0x2a);
    write_reg(fd, 0x42, 0x78);  //Hstart lower byte
    write_reg(fd, 0x41, 0x2f);  //Set HSW
    write_reg(fd, 0x42, 0x40);  //HSW upper byte
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x28);  //HSW lower byte

    //*********************************************
    // Program DPTX for DP port 0
    //*********************************************
    apb_write_reg(fd, APB_DP0_TX, 0x1A4, 0x40);         //Set bit per color
    apb_write_reg(fd, APB_DP0_TX, 0x1B8, 0x04);         //Set pixel width
    apb_write_reg(fd, APB_DP0_TX, 0x1AC, 0x5DB7);       //Set DP Mvid
    apb_write_reg(fd, APB_DP0_TX, 0x1B4, 0x8000);       //Set DP Nvid
    apb_write_reg(fd, APB_DP0_TX, 0x1C8, 0x00);         //Set TU Mode
    apb_write_reg(fd, APB_DP0_TX, 0x1B0, 0x2C0040);     //Set TU Size
    apb_write_reg(fd, APB_DP0_TX, 0xC8, 0x4006);        //Set FIFO Size
    apb_write_reg(fd, APB_DP0_TX, 0x1BC, 0x1068);       //Set data count
    apb_write_reg(fd, APB_DP0_TX, 0x1C0, 0x00);         //Disable STREAM INTERLACED
    apb_write_reg(fd, APB_DP0_TX, 0x1C4, 0x0C);         //Set SYNC polarity

    //*********************************************
    // Program quad pixel clock for DP port 1
    //*********************************************
    write_reg(fd, 0xe, 0x12);  //Select Port1 registers
    write_reg(fd, 0xb1, 0x1);  //Enable clock divider
    write_reg(fd, 0xb2, 0x67);  //Program M value lower byte
    write_reg(fd, 0xb3, 0x8);  //Program M value middle byte
    write_reg(fd, 0xb4, 0x6);  //Program M value upper byte
    write_reg(fd, 0xb5, 0x80);  //Program N value lower byte
    write_reg(fd, 0xb6, 0xf5);  //Program N value middle byte
    write_reg(fd, 0xb7, 0x20);  //Program N value upper byte
    write_reg(fd, 0xe, 0x1);  //Select Port 0 registers

    //*********************************************
    // Setup DTG for port 1
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0xa3);  //DTG detect HS active high and VS active high
    write_reg(fd, 0x41, 0x59);  //Set Hstart
    write_reg(fd, 0x42, 0x80);  //Hstart upper byte
    write_reg(fd, 0x41, 0x5a);
    write_reg(fd, 0x42, 0x78);  //Hstart lower byte
    write_reg(fd, 0x41, 0x5f);  //Set HSW
    write_reg(fd, 0x42, 0x40);  //HSW upper byte
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x28);  //HSW lower byte

    //*********************************************
    // Program DPTX for DP port 1
    //*********************************************
    apb_write_reg(fd, APB_DP1_TX, 0x1A4, 0x40);         //Set bit per color
    apb_write_reg(fd, APB_DP1_TX, 0x1B8, 0x04);         //Set pixel width
    apb_write_reg(fd, APB_DP1_TX, 0x1AC, 0x5DB7);       //Set DP Mvid
    apb_write_reg(fd, APB_DP1_TX, 0x1B4, 0x8000);       //Set DP Nvid
    apb_write_reg(fd, APB_DP1_TX, 0x1C8, 0x00);         //Set TU Mode
    apb_write_reg(fd, APB_DP1_TX, 0x1B0, 0x2C0040);     //Set TU Size
    apb_write_reg(fd, APB_DP1_TX, 0xC8, 0x4006);        //Set FIFO Size
    apb_write_reg(fd, APB_DP1_TX, 0x1BC, 0x1068);       //Set data count
    apb_write_reg(fd, APB_DP1_TX, 0x1C0, 0x00);         //Disable STREAM INTERLACED
    apb_write_reg(fd, APB_DP1_TX, 0x1C4, 0x0C);         //Set SYNC polarity

    //*********************************************
    // Release Des DTG reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset

    apb_write_reg(fd, APB_DP0_TX, 0x180, 0x1248);         //Set DP0 Htotal
    apb_write_reg(fd, APB_DP1_TX, 0x180, 0x1248);         //Set DP1 Htotal

    (void)usleep(40 * 1000);   // Add delay to settle DTG to incoming video data
    //*********************************************
    // Diagnostics - can be removed
    //*********************************************
    // Clear 0x54 status register initial flags
    //write_reg(fd, 0x0E, 0x01); // select port 0
    //read_reg(fd, 0x54, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back deserializer status reg 0x54 for port 0 - expected 0x53 or 0xD3 - received 0x%X", regval);
    //write_reg(fd, 0x0E, 0x12); // select port 1
    //read_reg(fd, 0x54, &regval);
    //CRITICAL_PRINT(MODULE_NAME, "Reading back deserializer status reg 0x54 for port 1 - expected 0x53 or 0xD3 - received 0x%X", regval);
    //write_reg(fd, 0x0E, 0x01); // select port 0
    //CRITICAL_PRINT(MODULE_NAME, "Check for any video errors accumulating in the stream:");
    //serdes_des_read_video_stream_error_status(fd, 0, 0, 0, 1);
    //serdes_des_read_video_stream_error_status(fd, 1, 0, 0, 1);
    //CRITICAL_PRINT(MODULE_NAME, "Read back DP Train Status on DPRX - expect 0x77, 0x77");
    //for (addr = 0x202; addr < 0x204; addr++)
    //{
    // Aux read transaction to read DPCD registers
    //apb_write_reg(fd, APB_DP0_TX, 0x108, addr);         //AUX address
    //apb_write_reg(fd, APB_DP0_TX, 0x100, 0x900);        //AUX command to read
    //(void)usleep(250 * 1000);
    //apb_reg_val = apb_read_reg(fd, APB_DP0_TX, 0x134);
    //CRITICAL_PRINT(MODULE_NAME, "DPCD addr 0x%X is 0x%X", addr, apb_reg_val);
    //}

    //*********************************************
    // Enable DP 0 output
    //*********************************************
    apb_write_reg(fd, APB_DP0_TX, 0x84, 0x01);         //Enable DP0 Output

    //*********************************************
    // Enable DP 1 output
    //*********************************************
    apb_write_reg(fd, APB_DP1_TX, 0x84, 0x01);         //Enable DP1 Output

    //*********************************************
    // Diagnostics
    //*********************************************
    serdes_des_measure_video_dptx(fd, 0, NULL, 1);
    serdes_des_measure_video_dptx(fd, 1, NULL, 1);
    serdes_des_measure_video_dtg(fd, 0, NULL, 1);
    serdes_des_measure_video_dtg(fd, 1, NULL, 1);
    serdes_des_measure_video_fpd_iv(fd, 1);

    return eStatus;
}

/*------------------------------------------------------------------------------
 * serdes_monitor_des_video
 * monitor function for check the 984 DTG video timing and FIFO status
 * call hanlding if the FIFO overflow happens
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType serdes_monitor_des_video(int32 fd, bool32 print)
{
    struct video_timing dp0_timing, dp1_timing;
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    serdes_des_measure_video_dtg(fd, 0, &dp0_timing, 0);
    serdes_des_measure_video_dtg(fd, 1, &dp1_timing, 0);

    if ((check_mesaured_video(&dp0_timing) == BRIDGECHIP_STATUS_SUCCESS)
            && check_mesaured_video(&dp1_timing) == BRIDGECHIP_STATUS_SUCCESS)
    {
        if (print == TRUE)
        {
            CRITICAL_PRINT(MODULE_NAME," Measured Video Timing Success");
            CRITICAL_PRINT(MODULE_NAME," DP0: htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth");
            CRITICAL_PRINT(MODULE_NAME,"      %d  %d  %d  %d  %d  %d  %d  %d",
                    dp0_timing.htotal,dp0_timing.vtotal, dp0_timing.hres,dp0_timing.vres,dp0_timing.hstart,dp0_timing.vstart, dp0_timing.hswidth, dp0_timing.vswidth);
            CRITICAL_PRINT(MODULE_NAME," DP1: htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth");
            CRITICAL_PRINT(MODULE_NAME,"      %d  %d  %d  %d  %d  %d  %d  %d",
                    dp1_timing.htotal,dp1_timing.vtotal, dp1_timing.hres,dp1_timing.vres,dp1_timing.hstart,dp1_timing.vstart, dp1_timing.hswidth, dp1_timing.vswidth);
            //apb_write_reg(fd, APB_DP0_TX, 0x90, 0x01);         //Enable DP0 link management
            //apb_write_reg(fd, APB_DP1_TX, 0x90, 0x01);         //Enable DP1 link management
        }
        eStatus = BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," *** Bad Video Timing Port0 (htotal %d, vtotal %d, hres %d, vres %d)",
                dp0_timing.htotal, dp0_timing.vtotal, dp0_timing.hres, dp0_timing.vres);
        CRITICAL_PRINT(MODULE_NAME," *** Bad Video Timing Port1 (htotal %d, vtotal %d, hres %d, vres %d)",
                dp1_timing.htotal, dp1_timing.vtotal, dp1_timing.hres, dp1_timing.vres);
        serdes_des_read_video_stream_error_status(fd, 0, 0, 0, 1);
        serdes_des_read_video_stream_error_status(fd, 1, 0, 0, 1);

        eStatus = BRIDGECHIP_STATUS_FAILED;
    }
    if (serdes_check_des_fifo_ov(fd) == BRIDGECHIP_STATUS_SUCCESS)
    {
        serdes_des_read_video_stream_error_status(fd, 0, 0, 0, 1);
        serdes_des_read_video_stream_error_status(fd, 1, 0, 0, 1);
        serdes_do_des_dp_dtg_reset(fd);
    }
    
    //casey: not need to clear it regularlly. double check with logan
    //serdes_des_read_video_stream_error_status(fd, 0, 0, 1, 0);
    //serdes_des_read_video_stream_error_status(fd, 1, 0, 1, 0);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}

/*------------------------------------------------------------------------------
 * serdes_get_ser_link_status
 * judge the Ser-Des link status: linked or lost
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType serdes_get_ser_link_status(int32 fd, int32 print)
{
    uint8 regval = 0;
    int32 port0_linked = 0;
    int32 port1_linked = 0;
    uint8 sts_reg_bc_crc_error = 0;
    uint8 sts_reg_lost_flag = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0c, &regval);
    //GENERAL_STS_MASK=0x51 : bit 0,4,6
    //0xc = 0x41 which bit 0 and 6 equal 1 means the link is ok.
    //bit 4 equal 1 means the link lost
    //any bit of 0, 6 equal 0 means link lost
    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;

    } else {
        if (print == 1)
            CRITICAL_PRINT(MODULE_NAME, "port0_0xc:0x%x bit1:%x, bit4:%x", regval, ((regval>>1)&0x01), ((regval>>4)&0x01));
    }

    sts_reg_bc_crc_error = ((regval & GENERAL_STS_MASK_BIT2) >> 1);  // bit1 : BC_CRC_ERROR
    sts_reg_lost_flag = ((regval & GENERAL_STS_MASK_BIT4) >> 4);  // bit4 : link lost flag

    regval = 0;
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0c, &regval);
    write_reg(fd, 0x2D, 0x01);

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port1_linked = 1;

    } else {
        if (print == 1)
            CRITICAL_PRINT(MODULE_NAME, "port1_0xc:0x%x bit1:%x, bit4:%x", regval, ((regval>>1)&0x01), ((regval>>4)&0x01));
    }

    sts_reg_bc_crc_error = ((regval & GENERAL_STS_MASK_BIT2) >> 1);  // bit1 : BC_CRC_ERROR
    sts_reg_lost_flag = ((regval & GENERAL_STS_MASK_BIT4) >> 4);  // bit4 : link lost flag.

    // clear bc_ecc and logging it
    // clear the lost flag , otherwise function will always report link lost
    if ((sts_reg_lost_flag == 1) || (sts_reg_bc_crc_error == 1) || (port0_linked == 0) || (port1_linked == 0)) {
        serdes_ser_log_crc_err_count(fd);  // log
        serdes_clear_link_crc_err_flag(fd); // clear
        serdes_ser_log_crc_err_count(fd);
    }

    if ((port0_linked == 1) && (port1_linked == 1))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        return BRIDGECHIP_STATUS_FAILED;
    }

}


/*------------------------------------------------------------------------------
 * serdes_get_bridge_name
 * to read chip ID string.
 *----------------------------------------------------------------------------*/
static BridgeChip_StatusType serdes_get_bridge_name(int32 fd, uint8 *chip_name)
{
    uint8 regval = 0;
    int32 i = 0;
    uint8 offset = 0xF1;
    uint8 reg = 0;
    chip_name[0] = 'D';
    chip_name[1] = 'S';
    chip_name[2] = '9';
    chip_name[3] = '0';
    for (i = 0; i < 5; i++)
    {
        reg = offset + i;
        if (read_reg(fd, reg, &regval))
        {
            return BRIDGECHIP_STATUS_FAILED;
        }
        chip_name[4 + i] = regval;
    }
    chip_name[9] = 0;
    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType serdes_get_serializer_info(int32 fd)
{
    uint8 chip_name[10] = {0};
    uint8 revision[10] = {0};
    uint8 rev_id = 0;
    serdes_get_bridge_name(fd, chip_name);
    read_reg(fd, 0x30, &rev_id);
    rev_id = (rev_id >> 4) & 0x0F;
    switch(rev_id)
    {
    case 0:
        strncpy((char *)revision, "ES1.0", 5);
        break;
    case 1:
        strncpy((char *)revision, "ES2.0", 5);
        break;
    case 2:
        strncpy((char *)revision, "ProA0", 5);
        break;
    case 5:
        strncpy((char *)revision, "CS2.0", 5);
        break;
    default:
        strncpy((char *)revision, "Unknown", 7);
        break;
    }
    CRITICAL_PRINT(MODULE_NAME,"Serializer name is: %s Rev: %s", chip_name, revision);
    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType serdes_get_deserializer_info(int32 fd)
{
    uint8 chip_name[10] = {0};
    uint8 revision[10] = {0};
    uint8 rev_id = 0;
    serdes_get_bridge_name(fd, chip_name);
    read_reg(fd, 0x30, &rev_id);
    rev_id = (rev_id >> 4) & 0x0F;
    switch(rev_id)
    {
    case 1:
        strncpy((char *)revision, "CS1.0", 5);
        break;
    case 3:
        strncpy((char *)revision, "CS2.0", 5);
        break;
    case 4:
        strncpy((char *)revision, "CS3.0", 5);
        break;
    default:
        strncpy((char *)revision, "Unknown", 7);
        break;
    }
    CRITICAL_PRINT(MODULE_NAME,"De-serializer name is: %s Rev: %s", chip_name, revision);
    return BRIDGECHIP_STATUS_SUCCESS;
}

/*------------------------------------------------------------------------------
 * ser_config_update
 * Ser chip initialization.  first call function before DP link training.
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType ser_config_update(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    serdes_get_serializer_info(fd);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_DIGITAL_ALL);
    write_reg(fd, 0x01, SER_RESET_DIGITAL_ALL);
    //review with casey: need 2ms delay after reset
    (void) usleep(5*1000);
    CRITICAL_PRINT(MODULE_NAME, "983 Link setup--> FPD-Link IV mode");

    serializer_i2c_pass_through_cfg(fd);
    eStatus = link_set_serializer_fpd4(fd);
    //Set 983 DPRX Config
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    serializer_dprx_cfg(fd);

    serdes_clear_link_crc_err_flag(fd);

    return eStatus;
}


/*------------------------------------------------------------------------------
 * dser_config_update
 * Note: This function only for first time initialization 
 *      Don't use it for link lost recovery becasue it contain 983 config.
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType dser_config_update(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    //do videoin reset
    serializer_video_input_reset(fd);
    link_set_serializer_vp(fd);

    CRITICAL_PRINT(MODULE_NAME, "DES 984 init...");
    CRITICAL_PRINT(MODULE_NAME, "CHANGE : #### ADD 0x26 setting for VP0 + dp line reset");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    serdes_get_deserializer_info(fd);
    eStatus = serdes_des_update_cfg(fd);
    dser_getclear_0x54(fd, 0); // clear
    dser_getclear_0x54(fd, 1); // log

    // back to serializer access
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    return eStatus;
}

/*------------------------------------------------------------------------------
 * dser_config_update_recovery
 * Note: For 984 reini in the link lost recovery case.
 *      do : 984 software reset and reinit complete 984
 *----------------------------------------------------------------------------*/
BridgeChip_StatusType dser_config_update_recovery(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    dser_getclear_0x54(fd, 1); //log
    CRITICAL_PRINT(MODULE_NAME, "DES 984 reini for recovery: Software reset 984");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 50);

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = serdes_des_update_cfg(fd);

    dser_getclear_0x54(fd, 1); //log
    // back to serializer access
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    return eStatus;
}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

/*------------------------------------------------------------------------------
 *dser_getclear_0x54
 *Note: 0x54 is clear on read register
 *      This is forward channel status change register.
 *      after iniitalizaiton, this register shall be read to clear it.
 *      after link lost recovered to read it. if this bits changed when 
 *      link lost happen. it means there is forward channel error. The information
 *      from TI is: add status registers at Ser side can't indicate the forward channel.
 *      for example the bit6 of 983 0x0c.  That information is also from back channel.
 *      so this register is very import to read as logging when lost happens to know
 *      the detail of lost.
 *----------------------------------------------------------------------------*/
void dser_getclear_0x54(int32 fd, int32 print)
{
    uint8 reg_val;
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x54, &reg_val);
    if (print)
        CRITICAL_PRINT(MODULE_NAME, "DES 0x54:0x%x(bit2:0x%x)", reg_val, ((reg_val >> 2) & 0x01));

}


#ifdef __cplusplus
}
#endif
