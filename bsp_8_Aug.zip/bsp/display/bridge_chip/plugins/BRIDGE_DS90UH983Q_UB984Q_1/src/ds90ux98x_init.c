#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "ds90ux98x_init.h"

#define SER_ID_7BIT       0x0C
#define DES_ID_7BIT       0x38
#define MCU_ID_7BIT       0x32
#define TOUCH_ID_7BIT     0x24

#define SER_ID_8BIT       (SER_ID_7BIT << 1)      //0x18
#define DES_ID_8BIT       (DES_ID_7BIT << 1)      //0x70
#define MCU_ID_8BIT       (MCU_ID_7BIT << 1)      //0x64
#define TOUCH_ID_8BIT     (TOUCH_ID_7BIT << 1)    //0x48

#define PCLK_FREQ  (362.796)
#define THW  6208
#define TVW  974
#define AHW  6008
#define AVW  934
#define HBP  80
#define VBP  14
#define HSW  32
#define VSW  10
#define VFP  16

#define FC_FPD_FREQ       6.75
#define PAGE_REG          0x40
#define PAGE_ADDR         0x41
#define PAGE_DATA         0x42
#define PAGE_DISPPATTEN   0x30
#define HSTART            (HBP+HSW)
#define VIDEO_RESOLUTION  "6K"

#define GENERAL_STS_MASK   0x5B
#define RX_LOCK_DETECT_BIT 6
#define LINK_LOST_FLAG_BIT 4
#define BIST_CRC_ERROR_BIT 3
#define BC_CRC_ERROR_BIT   1
#define LINK_DETECT_BIT    0

#define APB_CTL   0x48
#define APB_ADR0  0x49
#define APB_ADR1  0x4A
#define APB_DATA0 0x4B
#define APB_DATA1 0x4C
#define APB_DATA2 0x4D
#define APB_DATA3 0x4E

#define APB_DP_RX      0x00
#define APB_DP0_TX     APB_DP_RX
#define APB_DP1_TX     0x01
#define APB_CFG_DATA   0x02
#define APB_DIE_ID     0x03

static int32 verbosedebug = 1;
static int32 I2C_passthru = 1;
static float FPD3_PCLK = 148.5;
static int32 Bits_Per_Color = 10;

static uint8 Force_Rate_DP_DES = 1;
static uint16 Force_Speed_DP_DES = 5400;
/**********************************************
 * Fixed parameters
 **********************************************/
static uint8 Enable_PLL_Jitter_Fix = 1;
static float Main_link_speed = FC_FPD_FREQ;

static int32 reset_keep_dprx = 0;

#define MODULE_NAME "SER-DES BUICK-FF CS2.0"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

struct reg_val {
    uint8 reg;
    uint8 val;
};

struct video_timing {
    uint32 htotal;
    uint32 vtotal;
    uint32 hres;
    uint32 vres;
    uint32 hstart;
    uint32 vstart;
    uint32 hswidth;
    uint32 vswidth;
};


static void serdes_clear_link_crc_err_flag(int32 fd);
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset);
static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data);

static uint8 lower_byte(uint16 in_data)
{
    return (uint8)(in_data & 0xFF);
}

static uint8 upper_byte(uint16 in_data)
{
    return (uint8)((in_data & 0xFF00) >> 8);
}

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "i2c_write failed 0x%x : 0x%x",  reg, val);
        //LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
    }

    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1) {
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);
		return -1;
    }

    return 0;
}
/*
static void patch_983_apb_a18(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_a18");
    apb_write_reg(fd, 0, 0xa18, 0x5);
}

static void patch_983_apb_a28(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_a28");
    apb_write_reg(fd, 0, 0xa28, 0x4123);
}
*/
static void patch_983_apb_vod(int32 fd)
{
    CRITICAL_PRINT(MODULE_NAME,">>>>>>patch_983_apb_vod");
    apb_write_reg(fd, 0, 0x214, 0x02);
}
/*
static BridgeChip_StatusType enable_panel_backlight(int32 fd)
{
    uint8 bl_data[8] = {0x20, 0x65, 0x08,0xFF,0x7F,0xF0};

    i2c_write(fd, bl_data, 6);

    return BRIDGECHIP_STATUS_SUCCESS;
}
*/
static BridgeChip_StatusType link_set_serializer_fpd3(int32 fd)
{
    float vco_freq = FPD3_PCLK * 35;


    uint8 vco_cnt = (uint8)(vco_freq / 27 / 2);
    uint8 vco_sel = 0xC3;
    uint8 general_sts_p0, general_sts_p1;
    uint8 RevId = 0;

    CRITICAL_PRINT(MODULE_NAME, "Set Serializer to FPD-LINK III Mode, vco_cnt=0x%x, date=%s, time=%s",  vco_cnt, __DATE__, __TIME__);

    if (I2C_passthru == 1) {
        write_reg(fd, 0x07, 0x88);
    }
    CRITICAL_PRINT(MODULE_NAME, "Set PLL TX_0 to %f Hz",  vco_freq);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, vco_sel);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, vco_cnt);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0xF0);

    CRITICAL_PRINT(MODULE_NAME, "Set PLL TX_1 to %f Hz",  vco_freq);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x4E);
    write_reg(fd, 0x42, vco_sel);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, vco_cnt);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0xF0);

    write_reg(fd, 0x01, 0x30);
    write_reg(fd, 0x5B, 0x2B);
    write_reg(fd, 0x02, 0xF0);
    write_reg(fd, 0x02, 0xD0);
    write_reg(fd, 0x59, 0x03);
    write_reg(fd, 0x05, 0x00);

    read_reg(fd, 0x30, &RevId);
    // for 983 CS2.0
    if (RevId >= 0x40)
    {
        Enable_PLL_Jitter_Fix = 1;
    }
    else
    {
        Enable_PLL_Jitter_Fix = 0;
    }
/*
    if (Enable_PLL_Jitter_Fix == 1)
    {
        CRITICAL_PRINT(MODULE_NAME, "PLL-TX Jitter Improvements Enabled");
        write_reg(fd, 0x40, 0x08);

        write_reg(fd, 0x41, 0x23);
        write_reg(fd, 0x42, 0x3F);
        write_reg(fd, 0x41, 0x24);
        write_reg(fd, 0x42, 0x23);
        write_reg(fd, 0x41, 0x21);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x2F);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x0E);
        write_reg(fd, 0x42, 0x47);

        write_reg(fd, 0x41, 0x63);
        write_reg(fd, 0x42, 0x3F);
        write_reg(fd, 0x41, 0x64);
        write_reg(fd, 0x42, 0x23);
        write_reg(fd, 0x41, 0x61);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x6F);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x41, 0x4E);
        write_reg(fd, 0x42, 0x47);
    }
*/

/*
    write_reg(fd, 0x40, 0x04);
    // Lane 0 TX
    write_reg(fd, 0x41, 0x00); // Reg0x00 and Reg0x0A should have same value.
    write_reg(fd, 0x42, 0x03); // Allowed values are 0x00 0x01 0x03 0x07 0x0F
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x03);
    // Lane 1 TX
    write_reg(fd, 0x41, 0x20); // Reg0x20 and Reg0x2A should have same value.
    write_reg(fd, 0x42, 0x01); // Allowed values are 0x00 0x01 0x03 0x07 0x0F
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x01);
*/

    CRITICAL_PRINT(MODULE_NAME, "Soft Reset Serializer");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x2B, 0x1C);
    write_reg(fd, 0x2C, 0x1C);

    CRITICAL_PRINT(MODULE_NAME, "Main-Link DES Address Set to 0x%x",  DES_ID_8BIT >> 1);
    write_reg(fd, 0x70, DES_ID_8BIT);
    write_reg(fd, 0x78, DES_ID_8BIT);
    write_reg(fd, 0x71, MCU_ID_8BIT);
    write_reg(fd, 0x79, MCU_ID_8BIT);
    write_reg(fd, 0x72, TOUCH_ID_8BIT);
    write_reg(fd, 0x7A, TOUCH_ID_8BIT);

    // Config GPIOs for Touch IRQ
    if (RevId >= 0x40)
    {
        write_reg(fd, 0x17, 0x80);
        write_reg(fd, 0x18, 0x81);
    }
    else
    {
        write_reg(fd, 0x17, 0x40);
        write_reg(fd, 0x18, 0x41);
    }
    write_reg(fd, 0x88, 0x00);

    serdes_clear_link_crc_err_flag(fd);
    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0C, &general_sts_p0);
    CRITICAL_PRINT(MODULE_NAME, "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG 0x%x, LINK_DETECT: 0x%x",
            (general_sts_p0 >> 4) & 0x01, (general_sts_p0 >> 1) & 0x01, general_sts_p0 & 0x01);
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0C, &general_sts_p1);
    CRITICAL_PRINT(MODULE_NAME, "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG 0x%x, LINK_DETECT: 0x%x",
            (general_sts_p1 >> 4) & 0x01, (general_sts_p1 >> 1) & 0x01, general_sts_p1 & 0x01);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType link_set_serializer_patgen(int32 fd)
{
    uint8  PATGEN_IA = 0x2A;
    uint8  PATGEN_ID = 0x2B;
    uint8 PAGE_DISPPATTGEN = 0x30;

    write_reg(fd,PAGE_REG,PAGE_DISPPATTGEN);

    // Pixel Setting
    CRITICAL_PRINT(MODULE_NAME, "VP0 Color Depth Set To: %d bpc",  Bits_Per_Color);
    if (Bits_Per_Color == 6)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x44);
    }
    else if (Bits_Per_Color == 8)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x4c);
    }
    else if (Bits_Per_Color == 10)
    {
        write_reg(fd, PAGE_ADDR, 0x29);
        write_reg(fd, PAGE_DATA, 0x14);
    }

    // Start programming patgen parameters from register 0x06 - 0x16 (Bit 7 is auto-increment for address)
    write_reg(fd, PAGE_ADDR, PATGEN_IA);
    write_reg(fd, PAGE_DATA, 0x86);
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID); // Set HSYNC and VSYNC polarity positive (Default=negative)
    write_reg(fd, PAGE_DATA, 0x00);

    // Enable patgen
    write_reg(fd, PAGE_ADDR, 0x28);
    write_reg(fd, PAGE_DATA, 0x95); //Color Bar Pattern
    write_reg(fd, PAGE_ADDR, 0x29);
    write_reg(fd, PAGE_DATA, 0x08);

    // VP1
    // Pixel Setting
    CRITICAL_PRINT(MODULE_NAME, "VP1 Color Depth Set To: %d bpc",  Bits_Per_Color);
    if (Bits_Per_Color == 6)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x00);
    }
    else if (Bits_Per_Color == 8)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x08);
    }
    else if (Bits_Per_Color == 10)
    {
        write_reg(fd, PAGE_ADDR, 0x69);
        write_reg(fd, PAGE_DATA, 0x14);
    }
    PATGEN_IA = 0x6A;
    PATGEN_ID = 0x6B;

    write_reg(fd, PAGE_ADDR, PATGEN_IA);
    write_reg(fd, PAGE_DATA, 0x86);
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(THW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(TVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AHW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(AVW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VSW));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(HBP));
    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, lower_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID);
    write_reg(fd, PAGE_DATA, upper_byte(VBP));

    write_reg(fd, PAGE_ADDR, PATGEN_ID); // Set HSYNC and VSYNC polarity positive (Default=negative)
    write_reg(fd, PAGE_DATA, 0x00);
    // Enable patgen
    write_reg(fd, PAGE_ADDR, 0x68);
    write_reg(fd, PAGE_DATA, 0x95); //vertical black to white
    write_reg(fd, PAGE_ADDR, 0x69);
    write_reg(fd, PAGE_DATA, 0x08);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_vp(int32 fd)
{

    uint8 n_value = 15;
    uint8 addr0, addr1;
    float fc_freq = 0;
    float src_pclk_freq = PCLK_FREQ;
    float m_value_f;
    uint16 m_value;

    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x40, 0x32);

    // set timing on video processor 0
    addr0 = 0x02;
    addr1 = 0x10;
    // set dp_h_active
    write_reg(fd, 0x41, addr0); // dp_h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_active
    write_reg(fd, 0x41, addr1); // h_active
    write_reg(fd, 0x42, lower_byte(AHW));
    write_reg(fd, 0x42, upper_byte(AHW));

    // set video timing generator h_back
    write_reg(fd, 0x42, lower_byte(HBP));
    write_reg(fd, 0x42, upper_byte(HBP));

    // set video timing generator h_width
    write_reg(fd, 0x42, lower_byte(HSW));
    write_reg(fd, 0x42, upper_byte(HSW));

    // set video timing generator h_total
    write_reg(fd, 0x42, lower_byte(THW));
    write_reg(fd, 0x42, upper_byte(THW));

    // set video timing generator v_active
    write_reg(fd, 0x42, lower_byte(AVW));
    write_reg(fd, 0x42, upper_byte(AVW));

    // set video timing generator v_back
    write_reg(fd, 0x42, lower_byte(VBP));
    write_reg(fd, 0x42, upper_byte(VBP));

    // set video timing generator v_width
    write_reg(fd, 0x42, lower_byte(VSW));
    write_reg(fd, 0x42, upper_byte(VSW));

    // set video timing generator v_front
    write_reg(fd, 0x42, lower_byte(VFP));
    write_reg(fd, 0x42, upper_byte(VFP));

    // set m/n value for video processor 0
    // only for FPD4 mode
    // n_value fixed as 15
    n_value = 0xF;
    // forward channel rate
    fc_freq = FC_FPD_FREQ *1000;  //10800  bps

    //  half rate mode
    m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
    m_value = (uint16)round(m_value_f);
    CRITICAL_PRINT(MODULE_NAME, "m_value = %d",  m_value);
    // full rate mode
    // m_value = sub_pclk_freq / 4.0 * (2 ^ n_value) / (fc_freq/80)

    // set m/n value for video processor 0
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);

    // set timing on video processor 1
    // choose page 12, set auto-increment
    write_reg(fd, 0x40, 0x32);
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, 0xff);

    // main page: set number of video streams
    write_reg(fd, 0x43, 0x00);

    // enable video processor 0
    write_reg(fd, 0x44, 0x01);

    // Config TX link layer

    // enable link layer stream
    // only for FPD4 mode
    // choose page 11, set auto-increment
    write_reg(fd, 0x40, 0x2E);

    // enable link layer 0, stream 0
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x5A);

    // map video processor output to link layer stream
    // only for FPD4 mode
    // Set link layer to 30bpp
    //write_reg(fd, 0x41, 0x20);
    //write_reg(fd, 0x42, 0x5A);
    // assign slots to link layer stream
    // only for FPD4 mode
    // assign 32 slots to each link layer stream
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x3C);

    // enable link layer
    // only for FPD4 mode
    // enable link layer 0
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);

    return BRIDGECHIP_STATUS_SUCCESS;
}

bool32 check_98x_chipid(int32 fd, uint8 chipId)
{
    uint8 regval = 0;

    if (read_reg(fd, 0x00, &regval) == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Readed ChipId = 0x%02x, wanted ChipId = 0x%02x", regval, chipId);
        if (regval == chipId)
            return TRUE;
        else
            return FALSE;
    } else {
        return FALSE;
    }
}

static BridgeChip_StatusType serdes_wait_des_link_stable(int32 fd, int32 timeout_ms)
{
    uint8 regval = 0;
    int32 times = timeout_ms / 10;

    do
    {
        if (serdes_get_ser_link_status(fd) == BRIDGECHIP_STATUS_SUCCESS)
        {
            i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
            if (read_reg(fd, 0x00, &regval) == 0)
            {
                if (regval == DES_ID_8BIT)
                {
                    break;
                }
            }
        }
        (void)usleep(10 * 1000);
    }
    while(times--);

    if (times < 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "Wait des link stable timeout, timeout: %d ms", timeout_ms);
        return BRIDGECHIP_STATUS_FAILED;
    }
    else
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
}

static void serdes_clear_link_crc_err_flag(int32 fd)
{
    uint8 reg_cfg2 = 0;

    CRITICAL_PRINT(MODULE_NAME, "Link is not stable, Clear BC CRC Flags");
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 |= 0x20;
        write_reg(fd, 0x02, reg_cfg2);
    }
    if (read_reg(fd, 0x02, &reg_cfg2) == 0)
    {
        reg_cfg2 &= 0xDF;
        write_reg(fd, 0x02, reg_cfg2);
    }
}

static void vga_thresholds_adjust(int fd, uint8 low_thr, uint8 high_thr, uint8 vga_sweep_thr, uint8 port)
{
    uint8 reg = 0;
    uint8 value_54 = 0;
    uint8 value_30 = 0;

    if (port == 0)
        reg = 0x54;
    else if (port == 1)
        reg = 0x58;

    write_reg(fd, 0x40, reg);
    write_reg(fd, 0x41, 0x2B);
    write_reg(fd, 0x42, vga_sweep_thr);

    //LOW_THR = 14 #0x14=20(Dec)
    value_54 = (low_thr >> 4) & 0x3;
    value_30 = (low_thr & 0x0F);
    write_reg(fd, 0x40, reg); //  PAGE Select
    write_reg(fd, 0x41, 0x7B);
    write_reg(fd, 0x42, value_30 << 4); // LOW VGA THRESHOLD
    write_reg(fd, 0x41, 0x7A);
    write_reg(fd, 0x42, value_54 << 4); // LOW VGA THRESHOLD

    // HIGH_THR = 24 # 0x37=55 (55 DEC * 6.5mV) =Default
    write_reg(fd, 0x40, reg); //  PAGE Select
    write_reg(fd, 0x41, 0x89); // VGA HIGH THRESHOLD [5:0] => Default 0x37
    //write_reg(fd, 0x42, 0x37) // DEFAULT
    write_reg(fd, 0x42, high_thr); // Proposed

    return;
}

static void replica_rdac(int fd, uint8 ch0_rdac, uint8 ch1_rdac)
{
    //Echo Canceller Setting and PI
    //CRITICAL_PRINT(MODULE_NAME," ECHO-R_DAC Optimization"
    write_reg(fd, 0x40, 23*4);     //Page TOC 0 & 1
    write_reg(fd, 0x41, 0x26);
    write_reg(fd, 0x42, ch0_rdac); //fpd_rx_rep_rdac_en [5:0]
    write_reg(fd, 0x41, 0xA6);
    write_reg(fd, 0x42, ch1_rdac); //fpd_rx_rep_rdac_en [5:0]

    return;
}

static BridgeChip_StatusType link_set_deserializer_video_misc(int32 fd)
{
    uint8 value, Value_Main;
    uint8 reg, data, ch_offset;
    uint8 VGA_GAIN_P0 = 0x10 + 6; // 4 (0-15)
    uint8 VGA_GAIN_P1 = 0x10 + 6; // 10 (0-15)

    uint8 AC_ATTEN_CORNER_HIGH_FREQ = 1;
    uint8 VGA_BW_TUNE = 0;
    uint8 LF_BOOST = 0;
    uint8 C_EQ2_BOOST = 1;
    uint8 C_EQ3_BOOST = 1;
    uint8 data_lsb;
    uint8 data_msb;

    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x00, &value);

    if (value == DES_ID_8BIT)
    {
        CRITICAL_PRINT(MODULE_NAME, "Main-Link RX Device ID: 0x%02x",  value);
        read_reg(fd, 0x24, &value);
        CRITICAL_PRINT(MODULE_NAME, "Current Mode Selected (Reg 0x24): 0x%02x",  value);
        /*
           CRITICAL_PRINT(MODULE_NAME,"Hold DTG In Reset");
           write_reg(fd, 0x40, 0x50);
           write_reg(fd, 0x41, 0x32);
           write_reg(fd, 0x42, 0x02);
           write_reg(fd, 0x41, 0x32 + 0x30);
           write_reg(fd, 0x42, 0x02);
           */
        if (Enable_PLL_Jitter_Fix == 1)
        {
            CRITICAL_PRINT(MODULE_NAME, "Enable PLL Jitter Fix");
            write_reg(fd, 0x40, 0x0C);
            write_reg(fd, 0x41, 0x23);
            write_reg(fd, 0x42, 0x3F); //ICP
            write_reg(fd, 0x41, 0x24);
            write_reg(fd, 0x42, 0x0F); //rzero  #0x23
            write_reg(fd, 0x41, 0x21); //cdac_filter
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x2f); //r4 and filter cap
            write_reg(fd, 0x42, 0x00);

            write_reg(fd, 0x41, 0x63);
            write_reg(fd, 0x42, 0x3F); //ICP
            write_reg(fd, 0x41, 0x64);
            write_reg(fd, 0x42, 0x0F); //rzero #23
            write_reg(fd, 0x41, 0x61); //cdac_filter
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x6f); //r4 and filter cap
            write_reg(fd, 0x42, 0x00);
        }

        write_reg(fd, 0x0e, 0x03);          // Port 0
        write_reg(fd, 0x60, 0x0f);          // Increase Timers
        write_reg(fd, 0x61, 0x01);    // Sets Adapt Mode
        write_reg(fd, 0x0e, 0x12);          //  Port 1
        (void) usleep(100*1000);//
        write_reg(fd, 0x0E, 0x01); //
        write_reg(fd, 0x95, 0x06); //  BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ
        write_reg(fd, 0x0E, 0x12); //
        write_reg(fd, 0x95, 0x06); //  BYPASS CDR RESET BASED ON DCA ERROR  -->> HAVE TO BE OFF FOR DFE ADAPTATION WITH 960 AEQ 
        write_reg(fd, 0x0E, 0x01);//

        Value_Main = (uint8)(2 * Main_link_speed*1000/27/4);
        CRITICAL_PRINT(MODULE_NAME,
                "Setting Main-Link PLL_RX to %f GHz, Value_Main : 0x%x" ,
                Main_link_speed, Value_Main);

        write_reg(fd, 0x40, 0x08);//  # Page 2 on 984
        write_reg(fd, 0x41, 0x05);//
        write_reg(fd, 0x42, Value_Main);// # NCount [7:0]   #7D
        write_reg(fd, 0x41, 0x04);
        write_reg(fd, 0x42, 0x01);
        write_reg(fd, 0x41, 0x0E);
        write_reg(fd, 0x42, 0xC7);
        write_reg(fd, 0x41, 0x13);
        write_reg(fd, 0x42, 0x80);
        write_reg(fd, 0x0E, 0x03);
        write_reg(fd, 0x33, 0x05);
        write_reg(fd, 0x0E, 0x01);
        write_reg(fd, 0x40, 0x08);//
        write_reg(fd, 0x41, 0x07);//
        read_reg(fd, 0x42, &value);//
        CRITICAL_PRINT(MODULE_NAME,
                "PLL_RX_LOCK: 0x%x PLL_VCNTRL_HIGH= 0x%x  PLL_VCNTL_LOW: 0x%x ",
                (value & 0x01), (value >> 4) & 0x01, (value >> 3) & 0x01);

        // Error Thresholds on 960 AEQ
        write_reg(fd, 0x40, 0x38);// # SELECT PAGE AEQ_SNS

        write_reg(fd, 0x41, 0x2C);//
        write_reg(fd, 0x42, 0x01);//  #[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
        write_reg(fd, 0x41, 0x24);//
        write_reg(fd, 0x42, 0x45);//  #[6]: S-Filter_EN, AEQ Timer [2:0]   ===> HUGE DIFFERENCE IN LOCK WHEN 0x45 vs 0x46, or 47, or 44

        write_reg(fd, 0x41, 0x5C);//
        write_reg(fd, 0x42, 0x01);//   #[0]:CDR Toggle, [1]:DES_Toggle, [2]:en_err_cntr_rst
        write_reg(fd, 0x41, 0x54);//
        write_reg(fd, 0x42, 0x45);//  #AEQ Timer [2:0]

        vga_thresholds_adjust(fd, 30, 50, 50, 0);
        vga_thresholds_adjust(fd, 30, 50, 50, 1);

        CRITICAL_PRINT(MODULE_NAME," VGA Gain Override");
        write_reg(fd, 0x40, 0x38);        // AEQ_SENSOR PAGE
        write_reg(fd, 0x41, 0x1B);
        write_reg(fd, 0x42, VGA_GAIN_P0); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"
        write_reg(fd, 0x41, 0x4B);
        write_reg(fd, 0x42, VGA_GAIN_P1); //[4]:aeq_vga_gain_ov_sel, [3:0]=aeq_vga_gain_ov"

        CRITICAL_PRINT(MODULE_NAME," CDR Parameters Changed");
        write_reg(fd, 0x40, 0x54); // SO DROP
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x1C); // Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop,

        write_reg(fd, 0x40, 0x54);
        write_reg(fd, 0x41, 0xAA);
        write_reg(fd, 0x42, 0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

        write_reg(fd, 0x41, 0xAB); // [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1
        write_reg(fd, 0x42, 0x0e); //5 Efuse

        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0x44);
        write_reg(fd, 0x42, 0x1C); //5 Efuse [4:2]: cdr_lock_dump_limit_sel, [1:0]:cdr_so_bit_drop,

        write_reg(fd, 0x40, 0x58);
        write_reg(fd, 0x41, 0xAA);
        write_reg(fd, 0x42, 0x00); //5 [4:2]: cdr_so_gain_trk_div_sel1, [1:0]: cdr_fo_gain_trk_div_sel1

        write_reg(fd, 0x41, 0xAB);
        write_reg(fd, 0x42, 0x0e); //5 [4:2]: cdr_so_gain_acq_div_sel1, [1:0]: cdr_fo_gain_acq_div_sel1

        CRITICAL_PRINT(MODULE_NAME," Diable iPWM");
        write_reg(fd, 0x0e, 0x03); // Port 0
        write_reg(fd, 0xB9, 0x0F); //NTUNE [4:0]
        write_reg(fd, 0xBA, 0x13); //PTUNE [4:0]
        write_reg(fd, 0xBB, 0x01); //Enable iPWM
        write_reg(fd, 0x0e, 0x01);

        //Enable Driver R-BIAS
        write_reg(fd, 0x40, 15*4); // DFT PAGE
        write_reg(fd, 0x41, 0x3A); // [3]:reg_fpd_rx_en_drv_rbias_ov_en_p0, [2]:reg_fpd_rx_en_drv_rbias_ov_p0,[1]:reg_fpd_rx_en_drv_rbias_ov_en_p1, [0]:reg_fpd_rx_en_drv_rbias_ov_p1
        write_reg(fd, 0x42, 0x0f);

        write_reg(fd, 0x40, 0x10); // Page FPD_RX Analog

        ch_offset = 0x00;
        reg = 0x01; // [7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
        data = 0x0F;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x02; //[7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
        data = 0x13;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x03; // //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
        data = 0x13;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x04;  //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
        data = 0x0f;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x05;  //[7]=EN_TX_DRV (SPARE), [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
        data = 0x00;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
        data = 0x0A;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x08;  // [7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
        data = 0x14;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
        data = 0x0f;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        ch_offset = 0x10;

        reg = 0x01; //[7:5]=EQ2_OS_Trim, [4:0]=TRF_NM_DN
        data = 0x0F;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x02; // [7:5]=EQ3_OS_Trim, [4:0]=TRF_NM_DP
        data = 0x0F;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x03; //[7:6]=EN_ATP_FPD_RX, [5]=Flip_FPD3_POL, [4:0]=TRF_PM_DN
        data = 0x33;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x04; //[7]=EN_Term_LPTHRU, [6:5]=ATP_SEL_FPD_RX, [4:0]=TRF_PM_DP
        data = 0x14;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x05; //[7]=EN_TX_DRV (SPARE), [6:1]=TX_FLP_SEG, [0]=EN_LPTHRU
        data = 0x00;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x06; //[7]=EN_TX_DRV_OSC [6:4]=EN_ATP_DRV, [3:2]=TX_NM_R, [1:0]=TX_PM_R
        data = 0x0A;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x08; //[7:6]=DRV_R_TRIM_UP, [5]=FPD3_ATP_VCO_EN, [4:3]=FPD3_SEL_VF, [2:1]=FPD3_SEL_OPAMP_BIAS, [0]=FPD3_PLL_MODE
        data = 0x14;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        reg = 0x09; //[7:6]=DRV_R_TRIM_DN, [5:0]=TX_EN_DRV_SEG
        data = 0x0f;
        write_reg(fd, 0x41, ch_offset + reg);
        write_reg(fd, 0x42, data);

        //AEQ MAP Changes
        CRITICAL_PRINT(MODULE_NAME," AEQ MAPPING (FPD4) TABLE OPTIMIZATION");
        write_reg(fd, 0x40, 0x38); // Select AEQ_SENS PAGE

        AC_ATTEN_CORNER_HIGH_FREQ = 1;
        VGA_BW_TUNE = 0;
        value = (AC_ATTEN_CORNER_HIGH_FREQ << 6)+ (VGA_BW_TUNE << 4) ;
        write_reg(fd, 0x41, 0x0e);
        write_reg(fd, 0x42, value);
        write_reg(fd, 0x41, 0x3e);
        write_reg(fd, 0x42, value);

        C_EQ2_BOOST = 1;
        LF_BOOST = 0;
        value = C_EQ2_BOOST << 4;
        value = value + LF_BOOST;
        write_reg(fd, 0x41, 0x0f);
        write_reg(fd, 0x42, value);
        write_reg(fd, 0x41, 0x3f);
        write_reg(fd, 0x42, value);

        C_EQ3_BOOST = 1;
        LF_BOOST = 0;
        value = C_EQ3_BOOST << 4;
        value = value + LF_BOOST;
        write_reg(fd, 0x41, 0x10);
        write_reg(fd, 0x42, value);
        write_reg(fd, 0x41, 0x40);
        write_reg(fd, 0x42, value);

        write_reg(fd, 0x41, 0x69);
        write_reg(fd, 0x42, 0xdd); //opt = 0xcc
        write_reg(fd, 0x41, 0x6a);
        write_reg(fd, 0x42, 0xdd); //opt = 0xcc
        write_reg(fd, 0x41, 0x6b);
        write_reg(fd, 0x42, 0xdd); //opt = 0xcc
        write_reg(fd, 0x41, 0x6c);
        write_reg(fd, 0x42, 0x0d); //opt = 0x0c
        data_lsb = 2;              // Opt=2
        data_msb = 2  << 3;         //Opt=2
        write_reg(fd, 0x41, 0x6d);
        write_reg(fd, 0x42, data_lsb + data_msb);
        // CRITICAL_PRINT(MODULE_NAME," 0x6D:",hex(EQ_MSB+EQ_LSB);
        data_lsb = 2;        //Opt=2
        data_msb = 2 << 3;   //Opt=2
        write_reg(fd, 0x41, 0x6e);
        //write_reg(fd, 0x42, 0x1a)  #EFUSE & DEFAULT
        write_reg(fd, 0x42, data_lsb + data_msb);
        //CRITICAL_PRINT(MODULE_NAME," 0x6E:",hex(EQ_MSB+EQ_LSB)

        data_lsb = 2;       // Opt=2 //weller-review-error L463
        data_msb = 3 << 3;  // Opt=2
        write_reg(fd, 0x41, 0x6f);
        //write_reg(fd, 0x42, 0x2c) #EFUSE & DEFAULT
        write_reg(fd, 0x42, data_lsb + data_msb);
        //CRITICAL_PRINT(MODULE_NAME," 0x6F:",hex(EQ_MSB+EQ_LSB)

        data_lsb = 3; //Opt=2
        write_reg(fd, 0x41, 0x70);
        //write_reg(fd, 0x42, 0x05) #EFUSE & DEFAULT
        write_reg(fd, 0x42, data_lsb);
        //CRITICAL_PRINT(MODULE_NAME," 0x70:",hex(EQ_MSB+EQ_LSB)

        write_reg(fd, 0x41, 0x71);
        //write_reg(fd, 0x42, 0x04) # DEFAULT
        write_reg(fd, 0x42, 0x20); // TC3 EFUSE CHANGE

        write_reg(fd, 0x42, 0x29); // TC3 EFUSE CHANGE
        write_reg(fd, 0x41, 0x73);
        write_reg(fd, 0x42, 0x32); // TC3 EFUSE CHANGE
        write_reg(fd, 0x41, 0x74);
        write_reg(fd, 0x42, 0x07); // DEFAULT
        write_reg(fd, 0x41, 0x75);
        write_reg(fd, 0x42, 0x3B); // New CHANGE
        CRITICAL_PRINT(MODULE_NAME, "Done w/ AEQ_MAP");

        CRITICAL_PRINT(MODULE_NAME, "Setting Level-Shifter Change");

        write_reg(fd, 0x40, 23 * 4);
        write_reg(fd, 0x41, 0x34);
        write_reg(fd, 0x42, 0xff); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
        write_reg(fd, 0x41, 0x35);
        write_reg(fd, 0x42, 0x00); // fpd_rx_sel_thresh_m_9_8 #[3:2]
        write_reg(fd, 0x41, 0x34 + 0x80);
        write_reg(fd, 0x42, 0xff); // fpd_rx_sel_thresh_m_7_0 [7:0] Ch0
        write_reg(fd, 0x41, 0x35 + 0x80);
        write_reg(fd, 0x42, 0x00); // fpd_rx_sel_thresh_m_9_8 #[3:2]

        replica_rdac(fd, 0x1c, 0x1c);
        //CRITICAL_PRINT(MODULE_NAME," EchoC Canceller & PI Optimization"
        write_reg(fd, 0x40, 0x10); // SELECT Analog RX PAG
        //Channel 0/1: ECHO_C_DAC=>[7]:RSRVD, [6:4]:pi_i_dac_lv<2:0>,[3]:RSRVD, [2:0]:CDAC"
        write_reg(fd, 0x41, 0x0a);
        write_reg(fd, 0x42, 0x04);  // MH=0x20 (BEST)
        write_reg(fd, 0x41, 0x1a);
        write_reg(fd, 0x42, 0x04);  // MH=0x20 (BEST)

        write_reg(fd, 0x1, 0x1);
        serdes_wait_des_link_stable(fd, 300);
        i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_convert_deserializer_fpd3_to_fpd4(int32 fd)
{
    uint8 Value, Value0, Value1;

    CRITICAL_PRINT(MODULE_NAME, "SWITCHING Main-Link RX from FPD3 to FPD4");

    write_reg(fd, 0x01, 0x01);

    serdes_wait_des_link_stable(fd, 300);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME,"I2C Address Before Switch: 0x%02x", Value);

    read_reg(fd, 0x53, &Value0);
    read_reg(fd, 0x53, &Value0);
    write_reg(fd, 0x0E, 0x12);
    read_reg(fd, 0x53, &Value1);
    read_reg(fd, 0x53, &Value1);
    CRITICAL_PRINT(MODULE_NAME, "Port 0 Lock Status: 0x%02x, Port1 Lock Status: 0x%02x", Value0, Value1);

    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x5F, &Value);
    CRITICAL_PRINT(MODULE_NAME, "984 BC_TX CLK Source (0x02=AON, 0x00=PLLRX): 0x%02x", Value);
    write_reg(fd, 0x0E, 0x03);
    write_reg(fd, 0x5F, 0x00); //BC AON OFF
    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x5F, &Value);
    CRITICAL_PRINT(MODULE_NAME,"984 FORCE BC_TX CLK Source (0x00=PLLRX): 0x%02x", Value);

    write_reg(fd, 0x31, 0x63); // Port 0 next
    CRITICAL_PRINT(MODULE_NAME," Switched from FPD3 to FPD4 on Main-Link RX");

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType disable_983_dp_line_reset(int32 fd)
{
    uint32 apb_data = 0;

    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_write_reg(fd, 0, 0xa0c, 1);
    apb_data = apb_read_reg(fd, 0, 0xa0c);
    CRITICAL_PRINT(MODULE_NAME, "-------------------------->0xA0C = 0x%x", apb_data);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType link_set_serializer_fpd4(int32 fd)
{
    uint8 Value = 0;
    uint8 RevId = 0;
#if 0
    // DP0 Lane 0
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 1
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 2
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x25);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0x24);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x0A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0x28);
    write_reg(fd, 0x42, 0x30);

    // DP0 Lane 3
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xA5);
    write_reg(fd, 0x42, 0x35);
    write_reg(fd, 0x41, 0xA4);
    write_reg(fd, 0x42, 0x25);
    write_reg(fd, 0x41, 0x8A);
    write_reg(fd, 0x42, 0x77);
    write_reg(fd, 0x41, 0xA8);
    write_reg(fd, 0x42, 0x30);
#else
    // DP0 Lane 0
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 1
    write_reg(fd, 0x40, 0x10);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 2
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x4C);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x50);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x56);
    write_reg(fd, 0x42, 0x00);
    // DP0 Lane 3
    write_reg(fd, 0x40, 0x14);
    write_reg(fd, 0x41, 0xB0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xCC);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD0);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0xD6);
    write_reg(fd, 0x42, 0x00);
#endif
    read_reg(fd, 0x30, &RevId);
    CRITICAL_PRINT(MODULE_NAME," Configuring Serializer to FPD4 Mode");
    write_reg(fd, 0x2D, 0x03);
    write_reg(fd, 0x6A, 0x10);
    // for 983 CS2.0
    if ((RevId & 0xF0) == 0x50)
    {
        write_reg(fd, 0x6E, 0x80);
    }

    CRITICAL_PRINT(MODULE_NAME," Switch mode to FPD4");
    write_reg(fd, 0x05, 0x28);
    write_reg(fd, 0x02, 0xD1);
    write_reg(fd, 0x2d, 0x01);

    write_reg(fd, 0x40, 9*4);
    write_reg(fd, 0x41, 0x84);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x94);
    write_reg(fd, 0x42, 0x02);
    CRITICAL_PRINT(MODULE_NAME," Software reset 983");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    (void) usleep(50*1000);
    Value = (uint8)(2 * Main_link_speed * 1000 / 27 / 4);
    CRITICAL_PRINT(MODULE_NAME," Programming Serializer PLL, Value = %d", Value);
    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x05);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x0E);
    write_reg(fd, 0x42, 0xC7);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x45);
    write_reg(fd, 0x42, Value);
    write_reg(fd, 0x41, 0x4E);
    write_reg(fd, 0x42, 0xc7);
    write_reg(fd, 0x41, 0x53);
    write_reg(fd, 0x42, 0x90);

    // Zero out fractional
    write_reg(fd, 0x41, 0x04);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x1E);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x1F);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x00);

    write_reg(fd, 0x41, 0x44);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x5e);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x5f);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x60);
    write_reg(fd, 0x42, 0x00);

    CRITICAL_PRINT(MODULE_NAME," Software reset 983");
    if (reset_keep_dprx)
        write_reg(fd, 0x01, 0x30);
    else
        write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 300);
    CRITICAL_PRINT(MODULE_NAME," Software reset 984");
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test1 984 0x%x",  Value);
    write_reg(fd, 0x01, 0x01);
    serdes_wait_des_link_stable(fd, 300);
    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," read test2 984 0x%x",  Value);

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    write_reg(fd, 0x40, 0x2E);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);
    patch_983_apb_vod(fd);
    link_set_serializer_vp(fd);

    CRITICAL_PRINT(MODULE_NAME," Software reset 983 and 984 done");
    write_reg(fd, 0x2D, 0x01);
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static uint32 XOR_MARGIN_OUTPUT(int fd, int wait_time, int port)
{
    uint8 REG0 = 0, REG1 = 0;
    uint8 Value_0_7, Value_15_8, Value_23_16, Value_29_24;
    uint32 Value_Port;

    if (port == 0)
    {
        REG0 = 0x00;
        REG1 = 0x54;
    }
    else if (port == 1)
    {
        REG0 = 0x80;
        REG1 = 0x58;
    }

    write_reg(fd, 0x40, 0x5C);
    write_reg(fd, 0x41, REG0); // Channel 0
    write_reg(fd, 0x42, 0x04); // Starts XOR Counter

    (void) usleep(wait_time * 1000);

    write_reg(fd, 0x40, REG1); // TOCCOA 0
    write_reg(fd, 0x41, 0xFB);
    read_reg(fd, 0x42, &Value_0_7); // Starts XOR Counter
    write_reg(fd, 0x41, 0xFC);
    read_reg(fd, 0x42, &Value_15_8); // Starts XOR Counter
    write_reg(fd, 0x41, 0xFD);
    read_reg(fd, 0x42, &Value_23_16); // Starts XOR Counter
    write_reg(fd, 0x41, 0xFE);
    read_reg(fd, 0x42, &Value_29_24); // Starts XOR Counter
    Value_Port = (Value_29_24 << 30) + (Value_23_16 << 16) + (Value_15_8 << 8) + Value_0_7;

    write_reg(fd, 0x40, 0x5C);
    write_reg(fd, 0x41, REG0); // Channel 0
    write_reg(fd, 0x42, 0x00); // Starts XOR Counter

    return Value_Port;
}

static void CHECK_ALIGNMENT (int fd)
{
    uint8 DEF_Port0, DEF_Port1;

    //CRITICAL_PRINT(MODULE_NAME," Checking Alignment Status"
    //Override Adapted Initial DFE Value
    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &DEF_Port0);
    DEF_Port0 = DEF_Port0 >> 2;
    //DFE_Port0 = board.ReadI2C(DEV_ADR, 0x42)>>2 # [15:8]
    write_reg(fd, 0x41, 0x8F);
    write_reg(fd, 0x42, DEF_Port0);
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x85);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    //Channel 1
    // Override Adapted Initial DFE Value
    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &DEF_Port1);
    DEF_Port0 = DEF_Port1 >> 2; // [15:8]
    write_reg(fd, 0x41, 0x8F);
    write_reg(fd, 0x42, DEF_Port1);
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x10); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD"

    // SET REF0/1 to 0
    write_reg(fd, 0x41, 0x82);
    write_reg(fd, 0x42, 0);
    write_reg(fd, 0x41, 0x85);
    write_reg(fd, 0x42, 0);
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x10); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"

    XOR_MARGIN_OUTPUT(fd, 0, 0);
    XOR_MARGIN_OUTPUT(fd, 0, 1);

    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"
    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
    write_reg(fd, 0x41, 0x1C);
    write_reg(fd, 0x42, 0x00); // [7]:pi_en_ov, [6]:pi_en_q_ov, [5]:eom_pi_en_ov, [4]:eq_adapt1_ov_en, [3:0]:RSVD
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x00); // [7]:vga_sweep_start_ov_l, [6]:vga_sweep_start_ov_m, [5]:sampler_tap2_en_ov_h, [4]:ref_adapt_ov_en, [3:2]:RSVD, [1]:vga_sweep_start_ov_val_l, [0]:vga_sweep_start_ov_val_m"        

    return;
}

static void DFE_TAP1_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, MSB_ON;

    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final, ((0x16>>2) & 0x3F), des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final - 64, ((0x16>>2) & 0x3F), des_num);
    }

    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x40); // Snapshot selects the Tap1 Accumulator
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    Value_Final =(Value_MSB >> 2) & 0x3F;
    MSB_ON = Value_Final >> 5 & 0x01;
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final, ((0x16>>2) & 0x3F), des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 TAP1 ACC: Final Value = 0x%02x, Initial Value: 0x%02x,  on DES: %d", Value_Final - 64, ((0x16>>2) & 0x3F), des_num);
    }

    return;
}
static void DFE_REF0_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, Value_LSB, MSB_ON;
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x00); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    //CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Value_MSB: ", hex(Value_MSB), " Value_LSB:", hex(Value_LSB)
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final - 128, des_num);
    }

    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x00); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    //CRITICAL_PRINT(MODULE_NAME," Port0 TAP1 ACC: Value_MSB: ", hex(Value_MSB), " Value_LSB:", hex(Value_LSB)
    //Value_Final = (Value_MSB << 8) + Value_LSB
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref0: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x68-128), Value_Final - 128, des_num);
    }

    return;
}

static void DFE_REF1_SNAPSHOT (int fd, uint8 des_num)
{
    uint8 Value_Final, Value_MSB, Value_LSB, MSB_ON;
    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x20); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port0 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final - 128, des_num);
    }

    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0x20); // Snapshot selects the ref_adapt0
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF1);
    read_reg(fd, 0x42, &Value_MSB); //[15:8]
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value_LSB); //[7:0]
    Value_Final = Value_MSB;
    MSB_ON = Value_Final >> 6 & 0x01;
    //CRITICAL_PRINT(MODULE_NAME," Port0_REF0-RAW: ", hex(Value_Final)
    if (MSB_ON == 0)
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final, des_num);
    }
    else
    {
        CRITICAL_PRINT(MODULE_NAME," Port1 Ref1: Initial: 0x%02x,  Value_Final: 0x%02x, on DES: %d", (0x18), Value_Final - 128, des_num);
    }

    return;
}

static void VIDEO_LINK_LAYER_SETUP (int fd, uint8 bits_per_color)
{
    CRITICAL_PRINT(MODULE_NAME,"Enabling DES_1 Video to Stream_0");
    write_reg(fd, 0x0E, 0x03); //Set TX Port select
    write_reg(fd, 0xD0, 0x0C); //FPD_RX to DP Port 0 and Port 1 enable
    write_reg(fd, 0xD1, 0x00); //Every stream forwarded on DC
    write_reg(fd, 0xD6, 0x08); //Send Stream ID0 to DP Port 0 and and Send Stream ID1 Port 1
    write_reg(fd, 0xD7, 0x00);
    write_reg(fd, 0x0E, 0x01); //Set TX Port select

    return;
}

static int32 check_mesaured_video(struct video_timing *timing)
{
    if ((timing->vtotal > (TVW -10)) && (timing->vtotal < (TVW + 10)) &&
            (timing->htotal > (THW -10)) && (timing->htotal < (THW + 10)) &&
            (timing->hres == AHW) && (timing->vres == AVW))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }

    return BRIDGECHIP_STATUS_FAILED;
}

static uint32 serdes_des_measure_video (int fd, int port, struct video_timing *timing)
{
    uint8 offset;
    uint8 dtg_status;
    uint32 htotal, vtotal, hres, vres, hstart, vstart, hswidth, vswidth;
    uint8 read_val;

    if (port == 0)
    {
        offset = 0;
    }
    else
    {
        offset = 0x30;
    }

    //DTG Status
    write_reg(fd, 0x40, 15*4);
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x31); //Display 0
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x03);

    read_reg(fd, 0x42, &dtg_status);

    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x32); //Display 1
    write_reg(fd, 0x41, 0x03);
    read_reg(fd, 0x42, &dtg_status);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x00); // Zero-Out the MUX
    do {
        write_reg(fd, 0x40, 81);

        write_reg(fd, 0x41, 0x40 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = read_val * 256;

        write_reg(fd, 0x41, 0x41 + offset);
        read_reg(fd, 0x42, &read_val);
        htotal = htotal + read_val;

        write_reg(fd, 0x41, 0x42 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = read_val * 256;
        write_reg(fd, 0x41, 0x43 + offset);
        read_reg(fd, 0x42, &read_val);
        vtotal = vtotal + read_val;

        write_reg(fd, 0x41, 0x44 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = read_val * 256;
        write_reg(fd, 0x41, 0x45 + offset);
        read_reg(fd, 0x42, &read_val);
        hres = hres + read_val;

        write_reg(fd, 0x41, 0x46 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = read_val * 256;
        write_reg(fd, 0x41, 0x47 + offset);
        read_reg(fd, 0x42, &read_val);
        vres = vres + read_val;

        write_reg(fd, 0x41, 0x48 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = read_val * 256;
        write_reg(fd, 0x41, 0x49 + offset);
        read_reg(fd, 0x42, &read_val);
        hstart = hstart + read_val;

        write_reg(fd, 0x41, 0x4a + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = read_val * 256;
        write_reg(fd, 0x41, 0x4b + offset);
        read_reg(fd, 0x42, &read_val);
        vstart = vstart + read_val;

        write_reg(fd, 0x41, 0x4c + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4d + offset);
        read_reg(fd, 0x42, &read_val);
        hswidth = hswidth + read_val;

        write_reg(fd, 0x41, 0x4e + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = read_val * 256;
        write_reg(fd, 0x41, 0x4f + offset);
        read_reg(fd, 0x42, &read_val);
        vswidth = vswidth + read_val;
    } while (0);

    if (timing)
    {
        timing->htotal = htotal;
        timing->vtotal = vtotal;
        timing->hres = hres;
        timing->vres = vres;
        timing->hstart = hstart;
        timing->vstart = vstart;
        timing->hswidth = hswidth;
        timing->vswidth = vswidth;
    }

    return htotal;
}

static BridgeChip_StatusType serdes_check_des_fifo_ov(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    uint32 dp0_fifo_ov;

    dp0_fifo_ov = apb_read_reg(fd, APB_DP0_TX, 0x1CC);

    if ((dp0_fifo_ov & 0x03) > 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "DES FIFO OVERFLOW: dp0_fifo_ov = 0x%04x", dp0_fifo_ov);
        eStatus = BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        eStatus = BRIDGECHIP_STATUS_FAILED;
    }

    return eStatus;
}

static void serdes_do_des_dp_dtg_reset(int32 fd)
{
    //*********************************************
    // Hold Des DTG in reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x6);  //Hold Port 0 DTG in reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x6);  //Hold Port 1 DTG in reset

    write_reg(fd, 0x01, 0x40); //Reset DPTX PLL

    //*********************************************
    // Release Des DTG reset
    //*********************************************
    write_reg(fd, 0x40, 0x50);  //Select DTG Page
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset
    write_reg(fd, 0x41, 0x62);
    write_reg(fd, 0x42, 0x4);  //Release Des DTG reset
    apb_write_reg(fd, APB_DP0_TX, 0x90, 0x01);         //Enable DP0 link management
}

static void serdes_show_measured_video_timing(uint8 port, struct video_timing timing)
{
    CRITICAL_PRINT(MODULE_NAME," DP%d Measured Video Timing:", port);
    CRITICAL_PRINT(MODULE_NAME,"  htotal = %d",  timing.htotal);
    CRITICAL_PRINT(MODULE_NAME,"  vtotal = %d",  timing.vtotal);
    CRITICAL_PRINT(MODULE_NAME,"  hres = %d",  timing.hres);
    CRITICAL_PRINT(MODULE_NAME,"  vres = %d",  timing.vres);
    CRITICAL_PRINT(MODULE_NAME,"  hstart = %d",  timing.hstart);
    CRITICAL_PRINT(MODULE_NAME,"  vstart = %d",  timing.vstart);
    CRITICAL_PRINT(MODULE_NAME,"  hswidth = %d", timing.hswidth);
    CRITICAL_PRINT(MODULE_NAME,"  vswidth = %d",  timing.vswidth);
}

BridgeChip_StatusType serdes_monitor_des_video(int32 fd, bool32 reset)
{
    struct video_timing dp0_timing;
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    serdes_des_measure_video(fd, 0, &dp0_timing);

    if (check_mesaured_video(&dp0_timing) == BRIDGECHIP_STATUS_SUCCESS)
    {
        if (reset == TRUE)
        {
            CRITICAL_PRINT(MODULE_NAME," Measured Video Timing Success");
            serdes_show_measured_video_timing(0, dp0_timing);
            CRITICAL_PRINT(MODULE_NAME,"Do a reset of 984 DP link management");
            apb_write_reg(fd, APB_DP0_TX, 0x90, 0x01);         //Enable DP0 link management
            CRITICAL_PRINT(MODULE_NAME,"ENABLE_DISPLAY done");
            CRITICAL_PRINT(MODULE_NAME,"Turning Off FSM Test MUXES DES_1");
            write_reg(fd, 0x40, 0x3C); // Select DFT Page
            write_reg(fd, 0x41, 0x00);
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x01);
            write_reg(fd, 0x42, 0x00);
            write_reg(fd, 0x41, 0x02);
            write_reg(fd, 0x42, 0x00);
            apb_write_reg(fd, 0, 0x084, 0x01);
            CRITICAL_PRINT(MODULE_NAME,"Turning Off FSM Test MUXES DES_1 done");
        }
        eStatus = BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        eStatus = BRIDGECHIP_STATUS_FAILED;
    }
    if (serdes_check_des_fifo_ov(fd) == BRIDGECHIP_STATUS_SUCCESS)
    {
        serdes_do_des_dp_dtg_reset(fd);
    }
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    return eStatus;
}


static uint8 lower_byte_QCLK(uint32 in_data)
{
    uint8 out_data = (uint8)(in_data & 0xFF);
    return out_data;
}
static uint8 upper_byte_QCLK(uint32 in_data)
{
    uint8 out_data =  (uint8)((in_data & 0xFF0000)>>16);
    return out_data;
}
static uint8 middle_byte_QCLK(uint32 in_data)
{
    uint8 out_data =  (uint8)((in_data & 0xFF00)>>8);
    return out_data;
}
static uint8 lower_byte_DTG(uint16 in_data)
{
    uint8 out_data = (uint8)(in_data & 0xFF);
    return out_data;
}
static uint8 upper_byte_DTG(uint16 in_data)
{
    uint8 out_data = (uint8)((in_data & 0xFF00)>>8);
    return out_data;
}

static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;
    uint32 apb_data;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    if (channel == 0) {
        wr_val = 0x03;
    } else if (channel == 1) {
        wr_val = 0x0B;
    } else {
        wr_val = 0x03;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return apb_data;
}

static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    if (channel == 0) {
        wr_val = 0x01;
    } else if (channel == 1) {
        wr_val = 0x09;
    } else {
        wr_val = 0x01;
    }
    write_reg(fd, APB_CTL, wr_val);

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);

    return 0;
}

static uint32 apb_read_modifywrite(uint16 offset, uint32 mask, uint32 write_data, uint8 channel,int32 fd)
{
    uint32 read_data;
    uint32 temp_wr_data;

    read_data = apb_read_reg(fd, channel, offset);
    temp_wr_data = (read_data & (~mask)) | (write_data & mask);
    apb_write_reg(fd, channel, offset, temp_wr_data);

    return 0;
}

static uint16 serdes_des_dp_video_setup(int fd, uint8 is_force_dp_rate, uint16 dp_force_rate, float link_speed)
{
    uint8 dp_rate_reg = 0xC0;
    uint32 dp_rate_rd = 0;

    if (is_force_dp_rate == 1)
    {
        CRITICAL_PRINT(MODULE_NAME," Forcing DP Fixed Rate of On DES, Link-Rate: %d", dp_force_rate);
        //Override link rate
        //Link rate Addr data
        //2.7 Gbps 0x81 8'b0110_0000
        //5.4 Gbps 0x81 8'b1100_0000
        //8.1 Gbps 0x81 8'b1110_0000
        //1.62 Gbps 0x81 8'b0000_0000
        //2.16 Gbps 0x81 8'b0010_0000
        //2.43 Gbps 0x81 8'b0100_0000
        //3.24 Gbps 0x81 8'b1000_0000
        //4.32 Gbps 0x81 8'b1010_0000
        if (dp_force_rate == 1620)
            dp_rate_reg = 0x00;
        else if (dp_force_rate == 2160)
            dp_rate_reg = 0x20;
        else if (dp_force_rate == 2430)
            dp_rate_reg = 0x40;
        else if (dp_force_rate == 2700)
            dp_rate_reg = 0x60;
        else if (dp_force_rate == 3240)
            dp_rate_reg = 0x80;
        else if (dp_force_rate == 4320)
            dp_rate_reg = 0xA0;
        else if (dp_force_rate == 5400)
            dp_rate_reg = 0xC0;
        else if (dp_force_rate == 8100)
            dp_rate_reg = 0xE0;

        //Override to Rate
        write_reg(fd, 0x40, 0x2C);
        write_reg(fd, 0x41, 0x81);
        write_reg(fd, 0x42, dp_rate_reg);
        // Force Rate
        write_reg(fd, 0x41, 0x82);
        write_reg(fd, 0x42, 0x02);
    }
    CRITICAL_PRINT(MODULE_NAME, "DP_PORT 0 SELECTED ONLY on DES_1");
    write_reg(fd, 0x0E, 0x12);
    write_reg(fd, 0x46, 0x00);
    write_reg(fd, 0x0E, 0x01);

    CRITICAL_PRINT(MODULE_NAME," Port 0: Apply DTG Reset on DES");
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32 + 0x00);
    write_reg(fd, 0x42, 0x02);
    CRITICAL_PRINT(MODULE_NAME, "DP-TX-PLL RESET Applied/Required on DES_1");
    write_reg(fd, 0x01, 0x40);

    CRITICAL_PRINT(MODULE_NAME," VIDEO PARAMETERS On DES: SET:");
    CRITICAL_PRINT(MODULE_NAME," FPD-Link Rate = %.2f GHz", link_speed);
    CRITICAL_PRINT(MODULE_NAME," PCLK = %.3f MHz", PCLK_FREQ);
    CRITICAL_PRINT(MODULE_NAME," THW = %d", THW);
    CRITICAL_PRINT(MODULE_NAME," TVW = %d", TVW);
    CRITICAL_PRINT(MODULE_NAME," AHW = %d", AHW);
    CRITICAL_PRINT(MODULE_NAME," AVW = %d", AVW);
    CRITICAL_PRINT(MODULE_NAME," HBP = %d", HBP);
    CRITICAL_PRINT(MODULE_NAME," VBP = %d", VBP);
    CRITICAL_PRINT(MODULE_NAME," HSW = %d", HSW);
    CRITICAL_PRINT(MODULE_NAME," VSW = %d", VSW);

    CRITICAL_PRINT(MODULE_NAME," DP-TX DES VIDEO RESOLUTION: %s Configuration for DISPLAY" , VIDEO_RESOLUTION);

    write_reg(fd, 0x40, 0x3C); // Select DFT Page
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x0C);
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x01);
    write_reg(fd, 0x41, 0x03);
    read_reg(fd, 0x42, &dp_rate_reg);

    dp_rate_reg = dp_rate_reg & 0x07;

    switch (dp_rate_reg)
    {
    case 0:
        dp_rate_rd = 1620; // MHz
        break;
    case 1:
        dp_rate_rd = 2160; // MHz
        break;
    case 2:
        dp_rate_rd = 2160; // MHz
        break;
    case 3:
        dp_rate_rd = 2700; // MHz
        break;
    case 4:
        dp_rate_rd = 3200; // MHz
        break;
    case 5:
        dp_rate_rd = 4320; // MHz
        break;
    case 6:
        dp_rate_rd = 5400; // MHz
        break;
    case 7:
        dp_rate_rd = 8100; // MHz
        break;
    }

    CRITICAL_PRINT(MODULE_NAME, "DP-Rate Detected on Panel: %d MHz On DES", dp_rate_rd);

    return dp_force_rate;
}

static void dtg_reset_toggle(int fd)
{
    CRITICAL_PRINT(MODULE_NAME," DTG RESET TOGGLE APPLIED");

    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x06);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x06);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x00);
    return;
}

static void DP_DISPLY_PROGRAM (uint8 channel, int fd)
{
    uint8 page, offset0, offset1;
    uint32 mvid = 0;
    uint32 reg_value, vsync_wr, hsync_wr, wr_data;
    uint32 bpc = 0x00000020;
    uint8 lane_count = 4;
    uint8 Active_Lanes = 0;
    float vid_freq = PCLK_FREQ;
    uint16 nvid = 32768;
    uint32 dp_mvalue, dp_nvalue;
    uint16 my_pixels = AHW;
    uint8 hsync_pol = 0;
    uint8 vsync_pol = 0;

    dp_mvalue = (uint32)(PCLK_FREQ * 1000);   //  148500 # in kHz
    dp_nvalue = Force_Speed_DP_DES * 400;

    if (channel == 0)
    {
        page = 0x01;
        offset0 = 0x00;
        offset1 = 0x00;
    }
    else
    {
        page = 0x12;
        offset0 = 0x30;
        offset1 = 0x01;
    }

    write_reg(fd, 0x0E, page);
    CRITICAL_PRINT(MODULE_NAME," SETTING DTG Parameters for DP_PORT %d Video: %s", channel, VIDEO_RESOLUTION);
    //enable clock divider
    CRITICAL_PRINT(MODULE_NAME," Port %d Setting QCLK", channel);
    write_reg(fd, 0xB1, 0x01);
    write_reg(fd, 0xB2, lower_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB3, middle_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB4, upper_byte_QCLK(dp_mvalue));
    write_reg(fd, 0xB5, lower_byte_QCLK(dp_nvalue));
    write_reg(fd, 0xB6, middle_byte_QCLK(dp_nvalue));
    write_reg(fd, 0xB7, upper_byte_QCLK(dp_nvalue));

    write_reg(fd, 0x0E, 0x01);

    CRITICAL_PRINT(MODULE_NAME," Port %d: Setting DTG", channel);

    //TI update for black startup screen issue
    write_reg(fd, 0x40, 0x50);
    //Quad pixel mode
    write_reg(fd, 0x41, 0x20 + offset0);
    //write_reg(fd, 0x42, 0x81);
    write_reg(fd, 0x42, 0xA3);
    wr_data = AHW | 0x8000;
    write_reg(fd, 0x41, 0x25 + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x26 + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));

    wr_data = HSTART | 0x8000;
    write_reg(fd, 0x41, 0x29 + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x2A + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));
    wr_data = HSW | 0x4000;
    write_reg(fd, 0x41, 0x2F + offset0);
    write_reg(fd, 0x42, upper_byte_DTG(wr_data));
    write_reg(fd, 0x41, 0x30 + offset0);
    write_reg(fd, 0x42, lower_byte_DTG(wr_data));

    // Determine Active Lanes
    // Select DP port SM
    write_reg(fd, 0x40, 0x3C); //Select DFT Page
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x09 + offset1);
    // Select DP master SM vector sel
    write_reg(fd, 0x41, 0x02);
    write_reg(fd, 0x42, 0x05);
    write_reg(fd, 0x41, 0x03);
    read_reg(fd, 0x42, &Active_Lanes);
    CRITICAL_PRINT(MODULE_NAME," Port %d: Active_Lanes", channel, Active_Lanes & 0x07);
    if (Active_Lanes == 0)
    {
        CRITICAL_PRINT(MODULE_NAME, "NO ACTIVE LANES DETECTED for PORT %d",channel);
        CRITICAL_PRINT(MODULE_NAME, "Main-Link DP-TX-PLL RESET Applied");
    }

    CRITICAL_PRINT(MODULE_NAME," Port %d Setting the Pattern Programming to %s", channel, VIDEO_RESOLUTION);
    lane_count = 4; //Active_Lanes & 0x07
    //Choose bpc = 24 bit, bits 7:5 = 001
    if (Bits_Per_Color == 6)
        bpc = 0x00000000;
    else if (Bits_Per_Color == 10)
        bpc = 0x00000040;
    else if (Bits_Per_Color == 8)
        bpc = 0x00000020;

    CRITICAL_PRINT(MODULE_NAME,"#################>>>>> Port %d Setting %d bpc", channel, Bits_Per_Color*3);
    apb_read_modifywrite(0x1A4, 0x000000E0, bpc, channel, fd);
    //Quad pixel
    apb_read_modifywrite(0x1B8, 0x00000007, 0x00000004, channel, fd);
    mvid = (uint32)(vid_freq * 10.0 / Force_Speed_DP_DES * nvid);
    CRITICAL_PRINT(MODULE_NAME,"mvid:0x%x, nvid:0x%x",mvid, nvid);
    apb_write_reg(fd, channel, 0x1AC, mvid);
    apb_write_reg(fd, channel, 0x1B4, nvid);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1AC:0x%08x, 0x1B4:0x%08x",
            apb_read_reg(fd, channel, 0x1AC), apb_read_reg(fd, channel, 0x1B4));

    apb_write_reg(fd, channel, 0x1C8, 0x00);//weller-review-error L1516
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1c8:0x%08x",apb_read_reg(fd, channel, 0x1C8));

    //###########################################################################
    //apb_write_reg(fd, channel, 0x1B0, 0x180040);//0x38);//0x180040); //FIFO Depth to 56  //weller-review-error L1519
    apb_write_reg(fd, channel, 0x1B0, 0x06280040);//0x38);//0x180040); //FIFO Depth to 56  //weller-review-error L1519
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1B0:0x%08x",apb_read_reg(fd, channel, 0x1B0));
    apb_write_reg(fd, channel, 0x0C8, 0x4006);//0x4006);
    //apb_write_reg(fd, channel, 0x0C8, 0x4006);//0x4006);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x0C8:0x%08x",apb_read_reg(fd, channel, 0x0C8));

    reg_value = ((my_pixels * Bits_Per_Color * 3) + 7) / 8;
    if (lane_count != 0)
        reg_value = (reg_value + lane_count - 1) / lane_count;
    //CRITICAL_PRINT(MODULE_NAME," reg_value", reg_value
    CRITICAL_PRINT(MODULE_NAME,"reg_value:0x%x",reg_value);
    apb_write_reg(fd, channel, 0x1BC, reg_value);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1BC:0x%08x",apb_read_reg(fd, channel, 0x1BC));
    apb_write_reg(fd, channel, 0x1C0, 0x00);
    vsync_wr = ((~vsync_pol) & 0x01) << 1;
    hsync_wr = ((~hsync_pol) & 0x01);
    wr_data = 0x0000000c | vsync_wr | hsync_wr;
    CRITICAL_PRINT(MODULE_NAME,"wr_data:0x%x",wr_data);
    apb_write_reg(fd, channel, 0x1C4, wr_data);
    CRITICAL_PRINT(MODULE_NAME,">>>>read back 0x1C4:0x%08x",apb_read_reg(fd, channel, 0x1C4));

    CRITICAL_PRINT(MODULE_NAME," Port %d: Remove DTG Reset", channel);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32+offset0);
    write_reg(fd, 0x42, 0x00);

    return;
}

static uint32 ENABLE_DISPLAY (int fd, uint8 dtg_toggle, struct video_timing *timing0, struct video_timing *timing1)
{
    uint32 htotal0 = 0;

    DP_DISPLY_PROGRAM (0,fd);
    if (dtg_toggle)
        dtg_reset_toggle(fd);
    htotal0 = serdes_des_measure_video (fd, 0, timing0);
    serdes_show_measured_video_timing(0, *timing0);

    return htotal0;
}

static BridgeChip_StatusType serializer_video_input_reset(int32 fd)
{
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    apb_write_reg(fd, APB_DP_RX, 0x54, 0x01);   //Video Input Reset (should be executed after DP video is available from the source);

    return BRIDGECHIP_STATUS_SUCCESS;
}

static BridgeChip_StatusType serdes_des_update_cfg(int32 fd)
{
    uint8 Value = 0;
    uint8 Value1 = 0;
    uint8 e_offset0, e_offset1, q_offset0, q_offset1;
    uint8 MSB_CDR, LSB_CDR;
    struct video_timing timing0, timing1;
    uint16 Value_MSB;
    uint8 read_val;

    write_reg(fd, 0x40, 0x38); // SELECT AEQ_SNS PAGE
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x1a); // [5]:aeq_sns_fsm_dbg_sel [4:0]:aeq_sns_dbg_sel[4:0]

    write_reg(fd, 0x40, 0x38); // SELECT AEQ_SNS PAGE
    write_reg(fd, 0x41, 0x43);
    write_reg(fd, 0x42, 0x1a);

    write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0xFF);
    write_reg(fd, 0x40, 0x58); // SELECT TOCCOA1 PAGE
    write_reg(fd, 0x41, 0xFF);

    write_reg(fd, 0x40, 0x38);
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
    write_reg(fd, 0x41, 0x14);
    read_reg(fd, 0x42, &Value);

    write_reg(fd, 0x41, 0x43);
    write_reg(fd, 0x42, 0x18); // AEQ_SNS_DEBUG_SELECT for VGA Read
    write_reg(fd, 0x41, 0x44);
    read_reg(fd, 0x42, &Value);

    write_reg(fd, 0x40, 0x54); // TOCCOA PAGE 0
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0xA0); // Snapshot selects the VGA
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF2);
    read_reg(fd, 0x42, &Value);

    write_reg(fd, 0x40, 0x58); // TOCCOA PAGE 1
    write_reg(fd, 0x41, 0x51);
    write_reg(fd, 0x42, 0xA0); // Snapshot selects the VGA
    write_reg(fd, 0x41, 0x13);
    write_reg(fd, 0x42, 0x08); // Capture the data
    write_reg(fd, 0x41, 0xF2);

    Value = 0;
    read_reg(fd, 0x42, &Value);

    write_reg(fd, 0x40, 0x54); // SELECT TOCCOA0 PAGE
    write_reg(fd, 0x41, 0x4b);
    read_reg(fd, 0x42, &Value);
    write_reg(fd, 0x40, 0x58); //# SELECT TOCCOA1 PAGE
    write_reg(fd, 0x41, 0x4b);
    read_reg(fd, 0x42, &Value);

    write_reg(fd, 0x40, 0x5c); //# SELECT TOCCOA P0 & P1
    write_reg(fd, 0x41, 0x1c);
    read_reg(fd, 0x42, &e_offset0); //# Error Offset Value
    write_reg(fd, 0x40, 0x5c);
    write_reg(fd, 0x41, 0x1e);
    read_reg(fd, 0x42, &q_offset0); //# Q_Offset Value

    write_reg(fd, 0x40, 0x5c); // SELECT TOCCOA P0 & P1
    write_reg(fd, 0x41, 0x9c);
    read_reg(fd, 0x42, &e_offset1); //# Error Offset Value
    write_reg(fd, 0x40, 0x5c);
    write_reg(fd, 0x41, 0x9e);
    read_reg(fd, 0x42, &q_offset1); //# Q_Offset Value

    //# Channel 0 Check
    write_reg(fd, 0x0E, 0x1);
    //# CLEAR CRC Erros
    CRITICAL_PRINT(MODULE_NAME," Clearing CRC");
    CRITICAL_PRINT(MODULE_NAME," ##### Port 0 ######");
    write_reg(fd, 0x05, 0xE0);
    write_reg(fd, 0x05, 0xC0); // Clear CRC
    //# CLEAR FC CRC Erros FPD_RX

    //# Clear Flags by Reading
    read_reg(fd, 0x3C, &Value); //DCA_DET_ERR_CNTR_P0/P1
    read_reg(fd, 0x3D, &Value); //DCA_CRC_ERR_CNTR_P0/P1
    read_reg(fd, 0x3E, &Value); //DCA_8b10b_ERR_CNTR_P0/P1
    read_reg(fd, 0x3F, &Value); //ECC_ERR_CNTR_P0/P1

    read_reg(fd, 0x53, &Value);
    Value = 0;
    read_reg(fd, 0x53, &Value);
    CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x53): 0x%02x ", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
    Value = 0;
    read_reg(fd, 0x3B, &Value);
    CRITICAL_PRINT(MODULE_NAME," FPD Error Conters (REG 0x3B): 0x%02x", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

    Value = 0;
    read_reg(fd, 0x54, &Value);
    read_reg(fd, 0x09, &Value1);
    CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x54): 0x%02x", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");
    read_reg(fd, 0x6A, &Value);
    read_reg(fd, 0x6B, &Value1);
    CRITICAL_PRINT(MODULE_NAME," FC CRC Error (MSB+LSB): 0x%02x",  (Value1 << 4) + Value);
    read_reg(fd, 0x09, &Value);
    CRITICAL_PRINT(MODULE_NAME," FC CRC Error FLAG: ", Value >> 6 & 0x01);

    // Channel 1 Check
    write_reg(fd, 0x0E, 0x12);
    // CLEAR BC CRC Erros on Daisy BC_RX
    CRITICAL_PRINT(MODULE_NAME," ##### Port 1 #####");
    write_reg(fd, 0x05, 0xE0);
    write_reg(fd, 0x05, 0xC0); // Clear CRC
    // CLEAR FC CRC Erros FPD_RX

    // Clear Flags by Reading
    read_reg(fd, 0x3C, &Value); //DCA_DET_ERR_CNTR_P0/P1
    read_reg(fd, 0x3D, &Value); //DCA_CRC_ERR_CNTR_P0/P1
    read_reg(fd, 0x3E, &Value); //DCA_8b10b_ERR_CNTR_P0/P1
    read_reg(fd, 0x3F, &Value); //ECC_ERR_CNTR_P0/P1

    Value=0;
    read_reg(fd, 0x53, &Value);
    CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x53): 0x%02x ", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x53: [7]:FPD_DECODE_ERROR, [6]:Daisy_RX_LOCK, [5]:Daisy_RX_LinkLost_Flag, [4]:FPD_RX_LOCK_LOST_FLAG, [3]:RSRVD, [2]:TX_PLL_LOCK, [1]:FPD3_LOCK, [0]:FPD4_LOCK");
    Value=0;
    read_reg(fd, 0x3B, &Value);
    CRITICAL_PRINT(MODULE_NAME," FPD Error Conters (REG 0x3B): 0x%02x", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x3B: [4]:ALL_ERR_FLAG_P0/P1, [3]:DCA_DET_ERR_FLAG_P0/P1, [2]:DCA_CRC_ERR_FLAG_P0/P1, [1]:DCA_8b10b_ERR_FLAG_P0/P1, [0]:ECC_ERR_FLAG_P0/P1 ");

    Value=0;
    read_reg(fd, 0x54, &Value);
    read_reg(fd, 0x09, &Value1);
    CRITICAL_PRINT(MODULE_NAME," Lock Status (REG 0x54): 0x%02x", Value);
    CRITICAL_PRINT(MODULE_NAME," REG-0x54: [7]:DPTX_PLL_DONE, [6]:PLL_RX_PLL_LOCK, [5]:DUAL_TX_STS, [4]:DUAL_RX_STS, [3]:I2S_LOCKED, [2]:RX_LOCK_STATUS_CHNG, [1]:DCA_DETECT, [0]:RX_LOCK_OR_Port_0_1");
    Value=0;
    read_reg(fd, 0x6A, &Value);
    read_reg(fd, 0x6B, &Value1);
    CRITICAL_PRINT(MODULE_NAME," FC CRC Error (MSB+LSB): 0x%02x",  (Value1 << 4) + Value);
    Value=0;
    read_reg(fd, 0x09, &Value);
    CRITICAL_PRINT(MODULE_NAME," FC CRC Error FLAG: ",  Value >> 6 & 0x01);

    write_reg(fd, 0x0E, 0x1);

    write_reg(fd, 0x40, 0x54);
    write_reg(fd, 0x41, 0x12); // Snapshot select
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13); // Take the snapshot
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0xDF);
    read_reg(fd, 0x42, &MSB_CDR);
    write_reg(fd, 0x41, 0xE0);
    read_reg(fd, 0x42,&LSB_CDR);

    write_reg(fd, 0x40, 0x58);
    write_reg(fd, 0x41, 0x12); // Snapshot select
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13); // Take the snapshot
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0xDF);
    read_reg(fd, 0x42, &MSB_CDR);
    write_reg(fd, 0x41, 0xE0);
    read_reg(fd, 0x42, &LSB_CDR);

    write_reg(fd, 0x40, 0x08);
    write_reg(fd, 0x41, 0x07);
    Value = 0;
    read_reg(fd, 0x42, &Value);
    CRITICAL_PRINT(MODULE_NAME," PLL_RX_LOCK: 0x%02x PLL_VCNTRL_HIGH= 0x%02x PLL_VCNTL_LOW: 0x%02x",  (Value & 0x01), (Value >> 4) & 0x01, (Value >> 3) & 0x01);

    CHECK_ALIGNMENT(fd);

    DFE_TAP1_SNAPSHOT(fd, 1);
    DFE_REF0_SNAPSHOT(fd, 1);
    DFE_REF1_SNAPSHOT(fd, 1);

    write_reg(fd, 0x41, 0x12); // Snapshot select
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13); // Take the snapshot
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0xDF);
    read_reg(fd, 0x42, &read_val);
    Value_MSB = read_val << 8;
    write_reg(fd, 0x41, 0xE0);
    read_reg(fd, 0x42, &read_val);
    CRITICAL_PRINT(MODULE_NAME," Port0: CDR_FQ (PPM): %d",  Value_MSB + read_val);

    write_reg(fd, 0x41, 0x12); // Snapshot select
    write_reg(fd, 0x42, 0x00);
    write_reg(fd, 0x41, 0x13); // Take the snapshot
    write_reg(fd, 0x42, 0x08);
    write_reg(fd, 0x41, 0xDF);
    read_reg(fd, 0x42, &read_val);
    Value_MSB = read_val << 8;
    write_reg(fd, 0x41, 0xE0);
    read_reg(fd, 0x42, &read_val);
    CRITICAL_PRINT(MODULE_NAME," Port1: CDR_FQ (PPM): %d",  Value_MSB + read_val);

    CRITICAL_PRINT(MODULE_NAME,">>>>>Hold DTG In Reset");
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02);
    write_reg(fd, 0x41, 0x32 + 0x30);
    write_reg(fd, 0x42, 0x02);

    write_reg(fd, 0x0E, 0x01);
    read_reg(fd, 0x00, &Value);
    CRITICAL_PRINT(MODULE_NAME," DES_1 I2C Adress Aquired: 0x%02x",  Value);

    if (Value != 0)
    {
        serdes_des_dp_video_setup(fd, Force_Rate_DP_DES, Force_Speed_DP_DES, Main_link_speed);
        VIDEO_LINK_LAYER_SETUP (fd, Bits_Per_Color); // Enable DC on Previous Device

        ENABLE_DISPLAY (fd, 1, &timing0, &timing1);
        if ((check_mesaured_video(&timing0) == BRIDGECHIP_STATUS_FAILED))
        {
            CRITICAL_PRINT(MODULE_NAME," VIDEO NOT MEASURED CORRECTY!");
        }
    }

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType serdes_check_983_dp_linkup(int32 fd)
{
    uint32 lane01_status, lane23_status;
    static uint8  vp_status = 0, vp_status_tmp = 0, status_change = 0;
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    lane01_status = apb_read_reg(fd, 0, 0x43C);
    lane23_status = apb_read_reg(fd, 0, 0x440);
    read_reg(fd, 0x45, &vp_status);

    if (vp_status != vp_status_tmp) {
        CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
                vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);

        serdes_get_983_dp_rx_status(fd);
        vp_status_tmp = vp_status;

    }

    if (((lane01_status&0x3ff) == 0x377) && ((lane23_status&0x3ff) == 0x377)) {

        status_change = 1;
        return BRIDGECHIP_STATUS_SUCCESS;
    } else {
        if (status_change == 1) {
            CRITICAL_PRINT(MODULE_NAME, "fail: | VP0:%d | VP1:%d | lane_status: 0x%x, 0x%x,",
                    vp_status & 0x1, (vp_status >> 1) & 0x01, lane01_status, lane23_status);
        }

        status_change = 0;
        return BRIDGECHIP_STATUS_FAILED;
    }
}

void serdes_get_983_dp_rx_status(int fd)
{
    uint32 dp_rate, lanes;
    uint32 h_res, h_pol, h_sync, h_back, h_total;
    uint32 v_res, v_pol, v_sync, v_back, v_total;
    uint32 lane01_status, lane23_status;
    uint8  vp_status;

    dp_rate = apb_read_reg(fd, 0, 0x400) * 27;
    lanes = apb_read_reg(fd, 0, 0x404);
    lane01_status = apb_read_reg(fd, 0, 0x43C);
    lane23_status = apb_read_reg(fd, 0, 0x440);
    h_res = apb_read_reg(fd, 0, 0x500);
    h_pol = apb_read_reg(fd, 0, 0x504);
    h_sync = apb_read_reg(fd, 0, 0x508);
    h_back = apb_read_reg(fd, 0, 0x50C) - h_sync;
    h_total = apb_read_reg(fd, 0, 0x510);
    v_res = apb_read_reg(fd, 0, 0x514);
    v_pol = apb_read_reg(fd, 0, 0x518);
    v_sync = apb_read_reg(fd, 0, 0x51C);
    v_back = apb_read_reg(fd, 0, 0x520) - v_sync;
    v_total = apb_read_reg(fd, 0, 0x524);

    read_reg(fd, 0x45, &vp_status);

    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "DP Lock Status");
    CRITICAL_PRINT(MODULE_NAME, "DP Rate: %d", dp_rate);
    CRITICAL_PRINT(MODULE_NAME, "Lanes: %d", lanes);
    CRITICAL_PRINT(MODULE_NAME, "Lane01 Status: 0x%x", lane01_status);
    CRITICAL_PRINT(MODULE_NAME, "Lane23 Status: 0x%x", lane23_status);
    CRITICAL_PRINT(MODULE_NAME, "H RES: %d", h_res);
    CRITICAL_PRINT(MODULE_NAME, "H POL: %d", h_pol);
    CRITICAL_PRINT(MODULE_NAME, "H SYNC WIDTH: %d", h_sync);
    CRITICAL_PRINT(MODULE_NAME, "H BACK PORCH: %d", h_back);
    CRITICAL_PRINT(MODULE_NAME, "H TOTAL: %d", h_total);
    CRITICAL_PRINT(MODULE_NAME, "v RES: %d", v_res);
    CRITICAL_PRINT(MODULE_NAME, "V POL: %d", v_pol);
    CRITICAL_PRINT(MODULE_NAME, "V SYNC WIDTH: %d", v_sync);
    CRITICAL_PRINT(MODULE_NAME, "V BACK PORCH: %d", v_back);
    CRITICAL_PRINT(MODULE_NAME, "V TOTAL: %d", v_total);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, "VP STATUS: | VP0:%d | VP1:%d | VP2:%d | VP3:%d |",
            vp_status & 0x1, (vp_status >> 1) & 0x01, (vp_status >> 2) & 0x01, (vp_status >> 3) & 0x01);
    CRITICAL_PRINT(MODULE_NAME, "===================================================");
    CRITICAL_PRINT(MODULE_NAME, " ");
    CRITICAL_PRINT(MODULE_NAME, " ");
}

static BridgeChip_StatusType serdes_setup_video_output(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | serdes_des_update_cfg(fd));
    //i2c_set_slave_addr(fd, MCU_ID_7BIT, I2C_ADDRFMT_7BIT);
    //eStatus = (BridgeChip_StatusType)(eStatus | enable_panel_backlight(fd));

    return eStatus;
}

static BridgeChip_StatusType link_convert_fpd3_to_fpd4(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_DIGITAL_ALL);
    write_reg(fd, 0x01, SER_RESET_DIGITAL_ALL);

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

    eStatus = link_set_serializer_fpd3(fd);
    eStatus = serdes_wait_des_link_stable(fd, 500);

    if(eStatus == BRIDGECHIP_STATUS_FAILED) {
        CRITICAL_PRINT(MODULE_NAME, "Wait FPD-LINK III link up failed !!!");
        return eStatus;
    }

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_video_misc(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));

    return eStatus;
}

//used for link lost recovery init
BridgeChip_StatusType recovery_ser_fpd3_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    CRITICAL_PRINT(MODULE_NAME, "Reset Serializer : 0x%x", SER_RESET_PLL_ONLY);
    write_reg(fd, 0x01, SER_RESET_PLL_ONLY);

    CRITICAL_PRINT(MODULE_NAME, "Link setup to FPD-Link III mode");

    eStatus = link_set_serializer_fpd3(fd);

    return eStatus;
}

BridgeChip_StatusType recovery_serdes_fpd4_init(int32 fd)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

    CRITICAL_PRINT(MODULE_NAME, "Link setup-->Convert from FPD-Link III mode to FPD-Link IV mode ");

    i2c_set_slave_addr(fd, DES_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_deserializer_video_misc(fd));
    eStatus = (BridgeChip_StatusType)(eStatus | link_convert_deserializer_fpd3_to_fpd4(fd));
    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = (BridgeChip_StatusType)(eStatus | link_set_serializer_fpd4(fd));

    return eStatus;
}

BridgeChip_StatusType serdes_get_ser_link_status(int32 fd)
{
    uint8 regval = 0;
    int32 port0_linked = 0;
    int32 port1_linked = 0;

    i2c_set_slave_addr(fd, SER_ID_7BIT, I2C_ADDRFMT_7BIT);

    write_reg(fd, 0x2D, 0x01);
    if (read_reg(fd, 0x0c, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port0_linked = 1;
    }

    write_reg(fd, 0x2D, 0x12);
    if (read_reg(fd, 0x0c, &regval) != 0)
        return BRIDGECHIP_STATUS_FAILED;

    if ((regval & GENERAL_STS_MASK) == ((1 << LINK_DETECT_BIT) | (1 << RX_LOCK_DETECT_BIT)))
    {
        port1_linked = 1;
    }

    write_reg(fd, 0x2D, 0x01);

    if ((port0_linked == 1) && (port1_linked == 1))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        serdes_clear_link_crc_err_flag(fd);
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType ser_config_update(int32 i2c_fh)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    i2c_set_slave_addr(i2c_fh, SER_ID_7BIT, I2C_ADDRFMT_7BIT);
    eStatus = link_convert_fpd3_to_fpd4(i2c_fh);
    return eStatus;
}

BridgeChip_StatusType dser_config_update(int32 i2c_fh)
{
    CRITICAL_PRINT(MODULE_NAME, "De-serializer config update, Date:%s Time:%s", __DATE__, __TIME__);
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    serializer_video_input_reset(i2c_fh);
    eStatus = serdes_setup_video_output(i2c_fh);
    return eStatus;
}

void set_reset_keep_dprx(int32 val)
{
    reset_keep_dprx = val;
}

#ifdef __cplusplus
}
#endif
