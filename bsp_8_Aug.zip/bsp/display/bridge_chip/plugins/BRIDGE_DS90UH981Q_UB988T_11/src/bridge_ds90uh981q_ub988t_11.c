/*
 ===========================================================================

 FILE:         bridge_ds90uh981q_ub988t_11.c

 $File$

 ===========================================================================
 Copyright (c) 2018 Qualcomm Technologies, Inc.
 All Rights Reserved.
 Qualcomm Technologies Proprietary and Confidential.

 Copyright (c) 2020 Bosch Automotive Products (Suzhou) Co.,Ltd(RBAC).
 All Rights Reserved.
 RBAC Proprietary and Confidential.

 ===========================================================================
 */

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/iofunc.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <devctl.h>
#include <errno.h>
#include <semaphore.h>

#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"
#include "bridgechip_i.h"
#include "i2c_client.h"
#include "DALDeviceId.h"
#include "devcfg_BridgeChip.h"
#include "ds90ux98x_init.h"
#include "supply_handling.h"
#include "disp_infras_int.h"
#include "screen_pwrmgr_common.h"

#define CHIP_ID                                       "Chevy-FF-11"
#define BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM            0xDEADC0DE
#define I2C_BUS_ID_MAX_LENGTH                         0x10
#define I2C_WRITE_2_BYTE_LENGTH                       2
#define I2C_WRITE_MAX_LENGTH                          64
#define I2C_READ_1_BYTE_LENGTH                        1
#define I2C_WRITE_3_BYTE_LENGTH                       3
#define I2C_READ_2_BYTE_LENGTH                        2
#define GENERAL_STS2_ADDR                             0x06
#define PLL_REFCLK_VALID                              0x08
#define RX_DETECT_LOCK                                0x41
#define FPD3_STS_ADDR                                 0x58
#define FPD3_LINK_TX_STS                              0xC0

/* DIRTY BITS */
#define BRIDGECHIP_POWER_DIRTYBIT             0x00000001

#define DEFAULT_I2C_SLAVE_ADDR                0x0C
#define DEFAULT_I2C_MCU_ADDR                  0x12
#define DEFAULT_I2C_GSBI_ID                   "/dev/i2c3"

#define DEFAULT_SINK_ERR_INTR_SUPPORT         FALSE
#define DEFAULT_ERR_POLLING_TIME_IN_MS        (1000)   // 1 seconds
#define I2C_BUS_ACCESS_INFO_FILE              "/tmp/no-display-i2c-access"
//#define BRIDGECHIP_GPIO_PDB                   "/dev/gpio/cpu_dsi_ctrl_en/value"

typedef struct _Plugin_Data_t
{
	int32 hI2CFileDes; /* Handle to I2C RM  */
	/* Board configuration information */
	uint8 uI2CSlaveId;
	uint8 uDeserNewSlaveAddr;
	char aI2CBusId[I2C_BUS_ID_MAX_LENGTH];
	BridgeChip_ThreadStateType ePollingThreadState; /* Tracking state of the polling thread */
	BridgeChip_OSAL_ThreadID hPollingThreadID; /* Thread ID of the error polling thread */
	uint32 uErrorPollingTime; /* Error polling time */
	/* Other statuses */
	bool32 bIsRxDetected;
	bool32 bIsPLLLocked;
	bool32 bIsPllValid;
	bool32 bSinkErrIntrSupported;
	BridgeChipDal *reg_table_ser;
	uint32 reg_table_ser_num;
	BridgeChipDal *reg_table_dser;
	uint32 reg_table_dser_num;
	BridgeChipDal_slave *reg_table_slave;
	uint32 reg_table_slave_num;
    uint32 power_count;
    bool32 first_poweron;
    uint32 open_counter;
    pthread_cond_t cond_disp_recovery;
    pthread_mutex_t mutex_disp_recovery;
    BridgeChip_OSAL_ThreadID disp_recovery_thread_id;
    BridgeChip_ThreadStateType disp_stat_recovery_thread_state;
    bool32 bdisplay_state_ready;
    uint32 linkup_counter;
    uint32 linkdown_counter;
} PluginData;

/*!
 *  \b BridgeChip_Plugin_UserCtxtInfo
 *
 *  Defines the structure containing user context information specific to the plugged in
 *  bridge chip driver.
 *
 */
typedef struct _BridgeChip_Plugin_UserCtxInfo_t
{
	uint32 uMagicNumCheck; /* Magic number for checking handle sanity */
	BridgeChip_Plugin_PhyCtxInfo *pPhysicalContext; /* Pointer to the physical context information */
	struct _BridgeChip_Plugin_UserCtxInfo_t *pNextUser;
	bool32 bPowerEnable; /* Flag indicating power status  */
	BridgeChip_Plugin_CbInfo sCallbackInfo; /* Client callback registration information */
	uint32 uDirtyBits;
	uint32 uFlags;

} BridgeChip_Plugin_UserCtxtInfo;

static BridgeChip_Plugin_PhyCtxInfo gsPhyCtx;
static PluginData gsPluginInfo;
//static int iI2cErrValue = -1;
sem_t mutex_sem;

/*------------------------------------------------------------------------------
 * Prototypes
 *----------------------------------------------------------------------------*/
static void bridge_ds90uh981q_ub988q_process_cb(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo, uint32 uEventMask);
static void bridge_ds90uh981q_ub988q_add_usr(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo,
		BridgeChip_Plugin_UserCtxtInfo *pUserInfo);
static void bridge_ds90uh981q_ub988q_remove_usr(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo,
		BridgeChip_Plugin_UserCtxtInfo *pUserInfo);

void disp_chain_recovery_thread(void *pArgs)
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    BridgeChip_Plugin_PhyCtxInfo *pPhyInfo = NULL;
    //bool32 b_state = FALSE;
	pPhyInfo = (BridgeChip_Plugin_PhyCtxInfo *) pArgs;
	PluginData *pInfo = NULL;

	pInfo = (PluginData *) pPhyInfo->pCustomData;
    LOG_CRITICAL_INFO(CHIP_ID, "Enter %s", __func__);
    while (pInfo->disp_stat_recovery_thread_state == BRIDGECHIP_OSAL_THREAD_STATE_RUN) {
        pthread_mutex_lock( &pInfo->mutex_disp_recovery );
        pthread_cond_wait( &pInfo->cond_disp_recovery, &pInfo->mutex_disp_recovery);
        pthread_mutex_unlock( &pInfo->mutex_disp_recovery );

        eStatus = BridgeChip_OSAL_LockMutex(pPhyInfo->sHwMutex);
        if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
        {
            LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
           // goto fail;
        }

        //Check the power state before do recovery
        if (TRUE == pPhyInfo->bPowerEnable) {
            LOG_CRITICAL_INFO(CHIP_ID, "=========>>>handle for HPD : %s", __func__);
            disp_infras_display_chain_recovery(pInfo->hI2CFileDes, DISPLAY_CHAIN_CTRL_OFF);
            disp_infras_display_chain_recovery(pInfo->hI2CFileDes, DISPLAY_CHAIN_CTRL_ON);
        }

        BridgeChip_OSAL_UnLockMutex(pPhyInfo->sHwMutex);
    };

    LOG_CRITICAL_INFO(CHIP_ID, "Exit %s", __func__);

}

static BridgeChip_StatusType disp_chain_recovery_init()
{
    BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
    gsPluginInfo.cond_disp_recovery = (pthread_cond_t)PTHREAD_COND_INITIALIZER;
    gsPluginInfo.mutex_disp_recovery = (pthread_cond_t)PTHREAD_MUTEX_INITIALIZER;
    gsPluginInfo.bdisplay_state_ready = FALSE;
    if (pthread_cond_init(&gsPluginInfo.cond_disp_recovery, NULL) != EOK)
    {
        LOG_ERROR(CHIP_ID, "Failed to pthread_cond_init cond_disp_recovery");
    }

    gsPluginInfo.disp_stat_recovery_thread_state = BRIDGECHIP_OSAL_THREAD_STATE_RUN;
    eStatus = BridgeChip_OSAL_CreateThread(&gsPluginInfo.disp_recovery_thread_id,
            disp_chain_recovery_thread, (void *) &gsPhyCtx);
    if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
    {
        LOG_ERROR(CHIP_ID, "Failed to create Error SER INIT thread (%d)", eStatus);
    }
    return BRIDGECHIP_STATUS_SUCCESS;
}

static void disp_chain_recovery_deinit()
{
    BridgeChip_OSAL_DestroyThread(&gsPluginInfo.disp_recovery_thread_id);
    pthread_cond_destroy(&gsPluginInfo.cond_disp_recovery);
    pthread_mutex_destroy(&gsPluginInfo.mutex_disp_recovery);
}

static int sem_timedwait_ms(sem_t *sem, int ms)
{
    struct timespec tm;
    clock_gettime(CLOCK_MONOTONIC, &tm);
    tm.tv_sec += (ms/1000);
    tm.tv_nsec += (ms - (ms/1000)*1000)*1000*1000;
    if (tm.tv_nsec >= 1000000000) {
        tm.tv_sec ++;
        tm.tv_nsec -= 1000000000;
    }
    return sem_timedwait_monotonic( sem, &tm );
}

static void bridge_ds90uh981q_ub988q_add_usr(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo,
		BridgeChip_Plugin_UserCtxtInfo *pUserInfo)
{
	pUserInfo->pNextUser = (BridgeChip_Plugin_UserCtxtInfo *) pPhyInfo->pClientInfo;
	pPhyInfo->pClientInfo = (void *) pUserInfo;
	LOG_INFO(CHIP_ID, "Add new client (%p)", pUserInfo);
}

static void bridge_ds90uh981q_ub988q_remove_usr(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo,
		BridgeChip_Plugin_UserCtxtInfo *pUserInfo)
{
	BridgeChip_Plugin_UserCtxtInfo *pTmp;
	BridgeChip_Plugin_UserCtxtInfo *pPrev;

	pTmp = pPrev = (BridgeChip_Plugin_UserCtxtInfo *) pPhyInfo->pClientInfo;

	if (pTmp == pUserInfo)
	{
		pPhyInfo->pClientInfo = pTmp->pNextUser;
		LOG_INFO(CHIP_ID, "Remove client (%p)", pUserInfo);
	}
	else
	{
		while (NULL != pTmp)
		{
			if (pTmp == pUserInfo)
			{
				pPrev->pNextUser = pUserInfo->pNextUser;
				LOG_INFO(CHIP_ID, "Remove client (%p)", pUserInfo);
				break;
			}
			else
			{
				pPrev = pTmp;
				pTmp = pTmp->pNextUser;
			}
		}
	}
}

static void bridge_ds90uh981q_ub988q_process_cb(BridgeChip_Plugin_PhyCtxInfo *pPhyInfo, uint32 uEventMask)
{
	PluginData *pInfo = (PluginData *) pPhyInfo->pCustomData;
	uint32 uI = 0;
	uint32 uEventId = 0;
	BridgeChip_Plugin_UserCtxtInfo *pTmp = NULL;
	BridgeChip_CallbackInfoType sCbInfo;

	pTmp = (BridgeChip_Plugin_UserCtxtInfo *) pPhyInfo->pClientInfo;

	while (NULL != pTmp)
	{
		LOG_INFO(CHIP_ID, "client = %p; uEventMask=0x%x", pTmp, pTmp->sCallbackInfo.sCbRegInfo.uEventMask);

		/* Proceed if a callback function and a valid event mask exist,
		 * and a new event notification matches the user's event mask
		 */
		if ((NULL != pTmp->sCallbackInfo.sCbRegInfo.pCallback)
				&& (0x00 != pTmp->sCallbackInfo.sCbRegInfo.uEventMask)
				&& (0x00 != (pTmp->sCallbackInfo.sCbRegInfo.uEventMask & uEventMask)))
		{
			BridgeChip_OSAL_Memset(&sCbInfo, 0x00, sizeof(BridgeChip_CallbackInfoType));

			sCbInfo.hHandle = pTmp->sCallbackInfo.hUserHandle;
			sCbInfo.pUserData = pTmp->sCallbackInfo.sCbRegInfo.pUserData;
			sCbInfo.uFlags = 0x00;

			for (uI = 1, uEventId = 0; uI < (BRIDGECHIP_EVENT_ALL + 1); uI = uI << 1, uEventId++)
			{
				/* Process events for which this client has registered */
				if ((0x00 != (pTmp->sCallbackInfo.sCbRegInfo.uEventMask & uI)) && (0x00 != (uEventMask & uI)))
				{
					sCbInfo.sEventInfo.uEventMask |= uI;
					switch (uI)
					{
					case BRIDGECHIP_EVENT_HPD:
						if (pInfo->bIsRxDetected)
							sCbInfo.sEventInfo.sHPDInfo.bPlugged = TRUE;
                        else {
                            LOG_CRITICAL_INFO (CHIP_ID, "sHPDInfo.bPlugged = FALSE");
                            sCbInfo.sEventInfo.sHPDInfo.bPlugged = FALSE;
                            pthread_cond_signal( &pInfo->cond_disp_recovery);
                        }

						break;
					case BRIDGECHIP_EVENT_PLL:
					case BRIDGECHIP_EVENT_REMOTE_DEVICE_INTERRUPT:
					case BRIDGECHIP_EVENT_HDCP:
					case BRIDGECHIP_EVENT_DEVICE_RECOVERY:
						break;
					default:
						{
							// Should never reach here
							LOG_WARNING(CHIP_ID, "Unsupported interrupt (%x) - should not reach here", uI);
							continue;
						}
					}
				}
			}

			if (0x00 != sCbInfo.sEventInfo.uEventMask)
			{
				LOG_INFO(CHIP_ID, "Invoking Callback: client = %p, uEventMask = 0x%x", pTmp, uEventMask);

				pTmp->sCallbackInfo.sCbRegInfo.pCallback(&sCbInfo);

				LOG_INFO(CHIP_ID, "Callback Done");
			}
		}

		LOG_INFO(CHIP_ID, "client->next = %p", pTmp->pNextUser);
		pTmp = pTmp->pNextUser;
	}
}

void bridge_ds90uh981q_ub988q_err_poll(void *pArgs)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_PhyCtxInfo *pPhyInfo = NULL;
	PluginData *pInfo = NULL;
	uint8 uSTSRegVal = 0;
	uint8 uGENSTSRegVal = 0;
	uint8 uFPDSTSRegVal = 0;
	uint32 uEventMask = 0;
	bool32 bUnlockMutex = FALSE;
	bool32 bExist;

    struct timespec tm;
    uint32 loop_flood_check = 0;
    struct timespec tm_old, tm_now;
    uint32 timediff = 0;

	pPhyInfo = (BridgeChip_Plugin_PhyCtxInfo *) pArgs;
	pInfo = (PluginData *) pPhyInfo->pCustomData;

    LOG_CRITICAL_INFO(CHIP_ID, "ENTER ErrorPolling polling");

    pInfo->bIsRxDetected = FALSE;
    pInfo->linkup_counter = 0;
    pInfo->linkdown_counter = 0;

	while (BRIDGECHIP_OSAL_THREAD_STATE_RUN == pInfo->ePollingThreadState)
	{
		eStatus = BridgeChip_OSAL_LockMutex(pPhyInfo->sHwMutex);
		if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
		{
			LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
			goto fail;
		}

		bUnlockMutex = TRUE;

		if (TRUE == pPhyInfo->bPowerEnable)
		{
			/* Reset re-usable variables */
			uEventMask = 0x00;
			uSTSRegVal = 0x00;
			uGENSTSRegVal = 0x00;
			uFPDSTSRegVal = 0;

			// Read GEN_STS register
			read_reg(pInfo->hI2CFileDes, GENERAL_STS2_ADDR, &uGENSTSRegVal);
			// Read STS register
			read_reg(pInfo->hI2CFileDes, DS90UH9XX_GEN_STS_ADDR, &uSTSRegVal);
			read_reg(pInfo->hI2CFileDes, FPD3_STS_ADDR, &uFPDSTSRegVal);

			/*** Check status registers for errors ***/
			/* Only error scenarios are reported to client.
			 * Otherwise, register statuses are used to update software statuses
			 */

			/* Check for valid PLL detection */
			if (0x00 == (uGENSTSRegVal & PLL_REFCLK_VALID))
			{
				/* Print log in case of state transition from TRUE to FALSE */
				if (TRUE == pInfo->bIsPllValid)
				{
					LOG_CRITICAL_INFO(CHIP_ID, "PClk NOT detected, uGENSTSRegVal=0x%x", uGENSTSRegVal);
				}
				pInfo->bIsPllValid = FALSE;
			}
			else
			{
				pInfo->bIsPllValid = TRUE;
			}

			/* Check if Receiver is not detected */
			if (0x00 == (uSTSRegVal & RX_DETECT_LOCK))
			{
				//uEventMask |= BRIDGECHIP_EVENT_HPD; /* TODO: support HPD based on DAL config */
				/* Print log in case of state transition from TRUE to FALSE */
				if (TRUE == pInfo->bIsRxDetected)
				{
					uEventMask |= BRIDGECHIP_EVENT_HPD;
					LOG_CRITICAL_INFO(CHIP_ID, "RX NOT detected, uSTSRegVal=0x%x", uSTSRegVal);
				}
				pInfo->bIsRxDetected = FALSE;
			}
			else
			{
				/* Print log in case of state transition from FALSE to TRUE */
				if (FALSE == pInfo->bIsRxDetected)
				{
					uEventMask |= BRIDGECHIP_EVENT_HPD;
					LOG_CRITICAL_INFO(CHIP_ID, "RX detected, uSTSRegVal=0x%x", uSTSRegVal);
					pInfo->bIsRxDetected = TRUE;
					eStatus = dser_config_update(pInfo->hI2CFileDes);
                    BridgeChip_OSAL_SleepMs(50);
					if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
					{
						LOG_CRITICAL_INFO(CHIP_ID, "De-serializer config update failed");
						pInfo->bIsRxDetected = FALSE;
					}
					/* RX is detected and 981 also initialized */
                    pInfo->linkup_counter ++;
                    display_state_notify("ready");
                    LOG_CRITICAL_INFO(CHIP_ID, "DISP INIT DONE");
				}
			}
#if 0
			/* Check if Receiver is not locked to transmitter's signal */
			if (0x00 == (uFPDSTSRegVal & FPD3_LINK_TX_STS))
			{
				/* Print log in case of state transition from TRUE to FALSE */
				if (TRUE == pInfo->bIsPLLLocked)
				{
					LOG_CRITICAL_INFO(CHIP_ID, "RX NOT LOCKED, uFPDSTSRegVal=0x%x", uFPDSTSRegVal);
				}
				pInfo->bIsPLLLocked = FALSE;

				/* We only expect PLL to lock if receiver is connected */
				if (TRUE == pInfo->bIsRxDetected)
				{
					uEventMask |= BRIDGECHIP_EVENT_PLL;
					pInfo->linkdown_counter ++;			
					LOG_CRITICAL_INFO(CHIP_ID, "RX NOT detected or lost");
				}
			}
			else
			{
				/* Print log in case of state transition from FALSE to TRUE */
				if (FALSE == pInfo->bIsPLLLocked)
				{
					LOG_CRITICAL_INFO(CHIP_ID, "RX LOCKED, uFPDSTSRegVal=0x%x", uFPDSTSRegVal);
				}
				pInfo->bIsPLLLocked = TRUE;
			}
#endif
			LOG_INFO(CHIP_ID, "uEventMask = 0x%x", uEventMask);

			// Provide callbacks
			bridge_ds90uh981q_ub988q_process_cb(pPhyInfo, uEventMask);
		}
		else
		{
		  pInfo->uErrorPollingTime = DEFAULT_ERR_POLLING_TIME_IN_MS;
          pInfo->bIsRxDetected = FALSE;
		}

fail:
		if (bUnlockMutex)
		{
			BridgeChip_OSAL_UnLockMutex(pPhyInfo->sHwMutex);
			bUnlockMutex = FALSE; /* reset flag */
		}

		if (BRIDGECHIP_OSAL_THREAD_STATE_RUN == pInfo->ePollingThreadState)
		{
            sem_timedwait_ms(&mutex_sem, pInfo->uErrorPollingTime);
			clock_gettime(CLOCK_MONOTONIC, &tm);
            LOG_TRACE(CHIP_ID, ">>> new loop, %d, %d s , %d ns", pInfo->uErrorPollingTime, tm.tv_sec, tm.tv_nsec);
		}
		eStatus = BridgeChip_OSAL_IsPathExist(I2C_BUS_ACCESS_INFO_FILE, &bExist, NULL);
		if (eStatus == BRIDGECHIP_STATUS_SUCCESS)
		{
			if (bExist && pInfo->bIsRxDetected)
				break;
		}

        /* Check if looping is too fast */
        clock_gettime(CLOCK_REALTIME, &tm_now);
        if (loop_flood_check == 0)
            tm_old = tm_now;

        if (loop_flood_check == 20) {
            /* if 20 loop time diff < 200ms which means there are no blocking and timeout for looping */
            timediff = (tm_now.tv_sec - tm_old.tv_sec)*1000;
            timediff += (tm_now.tv_nsec - tm_old.tv_nsec)/1000/1000;
            if (timediff < 200)
                LOG_CRITICAL_INFO(CHIP_ID, "!!!!!! looping flood !!!!!!");
            loop_flood_check = 0;
            continue;
        }
        loop_flood_check++;
        /* Check if looping is too fast */

    }
    LOG_CRITICAL_INFO(CHIP_ID, "%s will EXIT", __func__);
    pInfo->ePollingThreadState = BRIDGECHIP_OSAL_THREAD_STATE_EXITED;

    LOG_TRACE(CHIP_ID, "EXIT");
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_get_capabilities()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_get_capabilities function returns the capabilities
 *   of the bridge chip.
 *
 * \param [out] pCaps        - Pointer to the structure where caps will be stored.
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_get_capabilities(BridgeChip_CapabilitiesType *pCaps)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

	LOG_TRACE(CHIP_ID, "ENTER");

	if ( NULL == pCaps)
	{
		LOG_ERROR(CHIP_ID, "Bad Params");
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	BridgeChip_OSAL_Memset(pCaps, 0x00, sizeof(BridgeChip_CapabilitiesType));

	pCaps->eVideoInput[0] = BRIDGECHIP_VIDEO_INTERFACE_DSI;
	pCaps->eAudioInput[0] = BRIDGECHIP_AUDIO_INTERFACE_NONE;

	pCaps->eVideoOutput[0] = BRIDGECHIP_VIDEO_INTERFACE_FPDLINK_III;
	pCaps->eAudioOutput[0] = BRIDGECHIP_AUDIO_INTERFACE_NONE;

	pCaps->bRemoteDeviceComm[BRIDGECHIP_REMOTE_DEVICE_PROTOCOL_I2C] = FALSE;

	pCaps->uMaxPixelClock = 210000; // 210Mhz
	pCaps->uMinPixelClock = 50000;  //  50Mhz

	pCaps->bHDCPSupported = FALSE;
	pCaps->bHPDSupported = FALSE;
	pCaps->bTestPatternSupport = FALSE;
	pCaps->bVideoBytePackingModeSupport = FALSE;
	pCaps->bBackwardCompatibiltySupport = FALSE;

fail:
	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_open()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_open function initializes the plugged in bridge chip
 *   driver. Each new client should call this function again to request a unique handle.
 *   On successful execution, a unique handle will be returned that needs to be used with
 *   subsequent calls.
 *
 * \param [in]  hHandle      - Pointer to the handle which will be returned.
 * \param [in]  uFlags       - Reserved for future use
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_open(BridgeChip_HandleType *phHandle, uint32 uFlags)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;

	LOG_TRACE(CHIP_ID, "ENTER");

	if (NULL == phHandle)
	{
		LOG_ERROR(CHIP_ID, "Bad Params");
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

    if (gsPluginInfo.open_counter > 0)
    {
        LOG_ERROR(CHIP_ID, "only support open once: gsPluginInfo.open_counter :%d", gsPluginInfo.open_counter);
        eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
        goto fail;
    }

	if (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != gsPhyCtx.uMagicNumCheck)
	{
		LOG_INFO(CHIP_ID, "First client: Creating physical context");
		BridgeChip_OSAL_Memset(&gsPhyCtx, 0x00, sizeof(gsPhyCtx));

		eStatus = BridgeChip_OSAL_CreateMutex(&gsPhyCtx.sHwMutex, TRUE);
		if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
		{
			LOG_ERROR(CHIP_ID, "Failed to create mutex (%d)", eStatus);
			goto phyfail;
		}

		if (BRIDGECHIP_STATUS_SUCCESS == (eStatus = BridgeChip_OSAL_LockMutex(gsPhyCtx.sHwMutex)))
		{
			/* Default configuration */
			gsPluginInfo.uI2CSlaveId = DEFAULT_I2C_SLAVE_ADDR;
			gsPluginInfo.uDeserNewSlaveAddr = 0x00;
			BridgeChip_OSAL_StrCpy(gsPluginInfo.aI2CBusId, DEFAULT_I2C_GSBI_ID,
					I2C_BUS_ID_MAX_LENGTH);
			gsPluginInfo.uErrorPollingTime = DEFAULT_ERR_POLLING_TIME_IN_MS;
			gsPluginInfo.bSinkErrIntrSupported = DEFAULT_SINK_ERR_INTR_SUPPORT;

			/* Open a fd for i2c client and set slave address */
			gsPluginInfo.hI2CFileDes = i2c_open(gsPluginInfo.aI2CBusId);
			if (-1 == gsPluginInfo.hI2CFileDes)
			{
				LOG_ERROR(CHIP_ID, "Failed to open an i2c client handle");
				eStatus = BRIDGECHIP_STATUS_NO_RESOURCES;
				goto phyfail;
			}
			i2c_set_slave_addr(gsPluginInfo.hI2CFileDes, gsPluginInfo.uI2CSlaveId, I2C_ADDRFMT_7BIT);
			uint32_t speed = 0;
			int i2c_rc = 0;

			i2c_rc = i2c_set_bus_speed(gsPluginInfo.hI2CFileDes, I2C_SPEED_FAST, &speed);
			if (-1 == i2c_rc)
			{
				LOG_ERROR(CHIP_ID, "%s ::Failed with Err=[%d], Speed=[%d]! <i2c_set_bus_speed!>", __func__, i2c_rc,
						speed);
			}

			gsPhyCtx.pCustomData = (void *) &gsPluginInfo;
			gsPhyCtx.uMagicNumCheck = BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM;

			disp_chain_recovery_init();
			eStatus = ser_config_update(gsPluginInfo.hI2CFileDes);
			if (eStatus != BRIDGECHIP_STATUS_SUCCESS)
				LOG_ERROR(CHIP_ID, "Serializer reg update failed");

			if (FALSE == gsPluginInfo.bSinkErrIntrSupported)
			{
				// Create an error status polling thread if de-serializer doesn't support HDCP
				gsPluginInfo.ePollingThreadState = BRIDGECHIP_OSAL_THREAD_STATE_RUN;
                gsPluginInfo.first_poweron = TRUE;
                if (sem_init(&mutex_sem, 0, 0) < 0) {
                    LOG_ERROR(CHIP_ID, "sem_init fail, bridgechip startup fail");
					eStatus = BRIDGECHIP_STATUS_NO_RESOURCES;
                    goto phyfail;
                }
				eStatus = BridgeChip_OSAL_CreateThread(&gsPluginInfo.hPollingThreadID,
						bridge_ds90uh981q_ub988q_err_poll, (void *) &gsPhyCtx);
				if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
				{
					gsPluginInfo.ePollingThreadState = BRIDGECHIP_OSAL_THREAD_STATE_NONE;
					LOG_ERROR(CHIP_ID, "Failed to create Error Polling thread (%d)", eStatus);
				}
			}

			LOG_INFO(CHIP_ID, "i2c_bus = %s, i2c_slave_id = 0x%02x", gsPluginInfo.aI2CBusId,
					gsPluginInfo.uI2CSlaveId);

			(void) BridgeChip_OSAL_UnLockMutex(gsPhyCtx.sHwMutex);
		}
	
	}

	if (BRIDGECHIP_STATUS_SUCCESS == (eStatus = BridgeChip_OSAL_LockMutex(gsPhyCtx.sHwMutex)))
	{
		pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) BridgeChip_OSAL_Malloc(
				sizeof(BridgeChip_Plugin_UserCtxtInfo), 0x00);

		if (NULL == pUserInfo)
		{
			LOG_ERROR(CHIP_ID, "Malloc failed");
			eStatus = BRIDGECHIP_STATUS_NO_RESOURCES;
			(void) BridgeChip_OSAL_UnLockMutex(gsPhyCtx.sHwMutex);
			goto fail;
		}

		BridgeChip_OSAL_Memset(pUserInfo, 0x00, sizeof(BridgeChip_Plugin_UserCtxtInfo));
		pUserInfo->uMagicNumCheck = BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM;
		pUserInfo->pPhysicalContext = &gsPhyCtx;

		bridge_ds90uh981q_ub988q_add_usr(&gsPhyCtx, pUserInfo);

		*phHandle = (BridgeChip_HandleType) pUserInfo;
		gsPluginInfo.open_counter ++;
		(void) BridgeChip_OSAL_UnLockMutex(gsPhyCtx.sHwMutex);
	}
	else
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

	LOG_INFO(CHIP_ID, "Successful");

phyfail:
	if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
	{
		if (-1 != gsPluginInfo.hI2CFileDes)
		{
			i2c_close(gsPluginInfo.hI2CFileDes);
		}
		gsPluginInfo.hI2CFileDes = 0;

		if (gsPhyCtx.sHwMutex)
		{
			(void) BridgeChip_OSAL_UnLockMutex(gsPhyCtx.sHwMutex);
			BridgeChip_OSAL_DestroyMutex(gsPhyCtx.sHwMutex);
		}

		BridgeChip_OSAL_Memset(&gsPhyCtx, 0x00, sizeof(gsPhyCtx));
	}

fail:
	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_close()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_close function cloese the context for in bridge chip
 *   driver. Once all the open clients call this function, all resources acquired
 *   as part of Open will be freed.
 *
 * \param [in]  hHandle      - Pointer to the handle.
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_close(BridgeChip_HandleType hHandle)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;

	LOG_TRACE(CHIP_ID, "ENTER");

	pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) hHandle;

	if ((NULL == pUserInfo) || (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != pUserInfo->uMagicNumCheck))
	{
		LOG_ERROR(CHIP_ID, "Bad Params");
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	if (BRIDGECHIP_STATUS_SUCCESS
			== (eStatus = BridgeChip_OSAL_LockMutex(pUserInfo->pPhysicalContext->sHwMutex)))
	{
		bridge_ds90uh981q_ub988q_remove_usr(pUserInfo->pPhysicalContext, pUserInfo);

		(void) BridgeChip_OSAL_UnLockMutex(pUserInfo->pPhysicalContext->sHwMutex);

		BridgeChip_OSAL_Free(pUserInfo);

		if (NULL == gsPhyCtx.pClientInfo)
		{
			LOG_INFO(CHIP_ID, "Last Client: Destroying physical context");
			if (gsPhyCtx.sHwMutex)
			{
				BridgeChip_OSAL_DestroyMutex(gsPhyCtx.sHwMutex);
			}

			if (gsPluginInfo.hPollingThreadID)
			{
				BridgeChip_OSAL_DestroyThread(&gsPluginInfo.hPollingThreadID);
			}

			if (-1 != gsPluginInfo.hI2CFileDes)
			{
				i2c_close(gsPluginInfo.hI2CFileDes);
			}
			gsPluginInfo.hI2CFileDes = 0;
			disp_chain_recovery_deinit();
			BridgeChip_OSAL_Memset(&gsPhyCtx, 0x00, sizeof(gsPhyCtx));
		}
	}
	else
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

fail:
	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_get_prop()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_get_prop function retrieves the properties of the bridge chip
 *   associated with the input handle. The properties returned by this function reflect
 *   the current device status. It does not return the un-committed properties set by client.
 *
 * \param [in]  hHandle        - Pointer to the handle.
 * \param [in]  eProperty      - Property type to retrieve.
 * \param [out] pPropertyData  - Pointer to the structure to store property data.
 * \param [in]  uFlags         - Reserved for future use.
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_get_prop(BridgeChip_HandleType hHandle,
		BridgeChip_PropertyType eProperty, BridgeChip_PropertyDataType *pPropertyData, uint32 uFlags)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;

	LOG_TRACE(CHIP_ID, "ENTER");

	pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) hHandle;

	if ((NULL == pUserInfo) || (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != pUserInfo->uMagicNumCheck)
			|| (BRIDGECHIP_PROPERTY_NONE == eProperty) || (BRIDGECHIP_PROPERTY_MAX <= eProperty)
			|| (NULL == pPropertyData))
	{
		LOG_ERROR(CHIP_ID, "Bad Params hHandle = %p, property (%d), pPropData = %p", hHandle, eProperty,
				pPropertyData);
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	eStatus = BridgeChip_OSAL_LockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

	LOG_INFO(CHIP_ID, "client = %p, eProperty = %d", pUserInfo, eProperty);
	switch (eProperty)
	{
	case BRIDGECHIP_PROPERTY_POWER:
		{
			pPropertyData->bPowerOn = pUserInfo->pPhysicalContext->bPowerEnable;
			break;
		}
	default:
		LOG_ERROR(CHIP_ID, "Property(%d) not supported", eProperty);
		eStatus = BRIDGECHIP_STATUS_NOT_SUPPORTED;
		break;
	}

	BridgeChip_OSAL_UnLockMutex(pUserInfo->pPhysicalContext->sHwMutex);

fail:
	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_set_prop()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_set_prop function modifies the properties of the bridge chip
 *   associated with the input handle.
 *   All bridge chips do not support all the properties. Client should check the
 *   bridge chip capabilities before configuring the properties.
 *   Each client has its own context to set properties, and each client only commits
 *   property updates by itself.
 *   Validation is performed on BridgeChip_Device_Commit(). If commit fails, the latest
 *   successfully committed properties will be in effect.
 *   In case of multiple clients to the same bridge chip, the actual hardware configuration
 *   depends on the requests from other clients as well. In case of conflicting properties,
 *   the latest API call will be in effect.
 *
 * \param [in]  hHandle       - Pointer to the handle.
 * \param [in]  eProperty     - Property type to modify.
 * \param [in]  pPropertyData - Pointer to the structure containing new property data.
 * \param [in]  uFlags        - Reserved for future use.
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_set_prop(BridgeChip_HandleType hHandle,
		BridgeChip_PropertyType eProperty, BridgeChip_PropertyDataType *pPropertyData, uint32 uFlags)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;

	LOG_TRACE(CHIP_ID, "ENTER");

	pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) hHandle;

	if ((NULL == pUserInfo) || (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != pUserInfo->uMagicNumCheck)
			|| (BRIDGECHIP_PROPERTY_NONE == eProperty) || (BRIDGECHIP_PROPERTY_MAX <= eProperty)
			|| (NULL == pPropertyData))
	{
		LOG_ERROR(CHIP_ID, "Bad Params hHandle = %p, property (%d), pPropData = %p", hHandle, eProperty,
				pPropertyData);
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	eStatus = BridgeChip_OSAL_LockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

	LOG_INFO(CHIP_ID, "client = %p, eProperty = %d, uFlags=0x%x", pUserInfo, eProperty, uFlags);

	switch (eProperty)
	{
	case BRIDGECHIP_PROPERTY_POWER:
		{
			LOG_CRITICAL_INFO(CHIP_ID, "##### BRIDGECHIP_PROPERTY_POWER : %d", pPropertyData->bPowerOn);
			pUserInfo->bPowerEnable = pPropertyData->bPowerOn;
			pUserInfo->uDirtyBits |= BRIDGECHIP_POWER_DIRTYBIT;
			pUserInfo->uFlags |= uFlags;
			break;
		}
	default:
		LOG_ERROR(CHIP_ID, "Property(%d) not supported", eProperty);
		eStatus = BRIDGECHIP_STATUS_NOT_SUPPORTED;
		break;
	}

	BridgeChip_OSAL_UnLockMutex(pUserInfo->pPhysicalContext->sHwMutex);

fail:
	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_commit()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_commit function commits all the changes done to a device
 *   to hardware. This function is a synchronous call and will return after all the
 *   hardware changes are done.
 *
 * \param [in]  hHandle        - Pointer to the handle.
 * \param [in]  uFlags         - Reserved for future use.
 *
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_commit(BridgeChip_HandleType hHandle, uint32 uFlags)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;
	bool32 bUnlockMutex = FALSE;

	LOG_TRACE(CHIP_ID, "ENTER");

	pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) hHandle;

	if ((NULL == pUserInfo) || (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != pUserInfo->uMagicNumCheck))
	{
		LOG_ERROR(CHIP_ID, "Bad Params hHandle = %p", hHandle);
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	eStatus = BridgeChip_OSAL_LockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

	bUnlockMutex = TRUE;

  LOG_CRITICAL_INFO(CHIP_ID, "Client = %p, Dirtybits = 0x%x, uFlags= 0x%x", pUserInfo, pUserInfo->uDirtyBits, uFlags);
    if (BRIDGECHIP_POWER_DIRTYBIT & pUserInfo->uDirtyBits)
    {
        if (pUserInfo->pPhysicalContext->bPowerEnable == FALSE) {


            LOG_CRITICAL_INFO(CHIP_ID, "Device powered ON %d", gsPluginInfo.power_count);
            if (gsPluginInfo.first_poweron != TRUE)
            {
				LOG_CRITICAL_INFO(CHIP_ID, "Device powered on after off");
				disp_infras_display_chain_control(gsPluginInfo.hI2CFileDes, DISPLAY_CHAIN_CTRL_ON);
            } else {
                gsPluginInfo.first_poweron = FALSE;
            }
            gsPluginInfo.power_count ++;

       pUserInfo->pPhysicalContext->bPowerEnable = TRUE;

       //wakeup the timer in case it is in sleep
       sem_post(&mutex_sem);

    } else {

       pUserInfo->pPhysicalContext->bPowerEnable = FALSE;
       LOG_CRITICAL_INFO(CHIP_ID, "Device powered OFF");
       disp_infras_display_chain_control(gsPluginInfo.hI2CFileDes, DISPLAY_CHAIN_CTRL_OFF);
       
        //reset error poll state
        gsPluginInfo.bIsRxDetected = FALSE;
        gsPluginInfo.linkup_counter = 0;
        gsPluginInfo.linkdown_counter = 0;       

    }
  }
  else
  {

    }

fail:
	if (bUnlockMutex)
	{
		pUserInfo->uDirtyBits = 0;
		BridgeChip_OSAL_UnLockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	}

	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

/****************************************************************************
 *
 ** FUNCTION: bridge_ds90uh981q_ub988q_dev_reg_cb()
 */
/*!
 * \brief
 *   The \b bridge_ds90uh981q_ub988q_dev_reg_cb lets clients to register a callback for
 *   events associated with a bridge chip. To de-register the callback, client needs to
 *   use a NULL callback function.
 *   In case of interrupts, the interrupt will be masked until callback is processed.
 *   Interrupt will be unmasked as soon as the callback function is returned.
 *   Each client can register a single callback function for all event notifications.
 *
 * \param [in]  hHandle        - Pointer to the handle.
 * \param [in]  pCbRegInfo     - Pointer to the structure containing callback register information.
 * \retval BridgeChip_StatusType
 *
 ****************************************************************************/
BridgeChip_StatusType bridge_ds90uh981q_ub988q_dev_reg_cb(BridgeChip_HandleType hHandle,
		BridgeChip_Plugin_CbInfo *pCbRegInfo)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;
	BridgeChip_Plugin_UserCtxtInfo *pUserInfo = NULL;
	bool32 bUnlockMutex = FALSE;

	LOG_TRACE(CHIP_ID, "ENTER");

	pUserInfo = (BridgeChip_Plugin_UserCtxtInfo *) hHandle;

	if ((NULL == pUserInfo) || (BRIDGE_DS90UH981Q_UB988Q_MAGIC_NUM != pUserInfo->uMagicNumCheck)
			|| (NULL == pCbRegInfo))
	{
		LOG_ERROR(CHIP_ID, "Bad Params hHandle = %p, pCbRegInfo = %p", hHandle, pCbRegInfo);
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
		goto fail;
	}

	eStatus = BridgeChip_OSAL_LockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	if (BRIDGECHIP_STATUS_SUCCESS != eStatus)
	{
		LOG_ERROR(CHIP_ID, "Failed to lock mutex (%d)", eStatus);
		goto fail;
	}

	bUnlockMutex = TRUE;

	LOG_INFO(CHIP_ID, "Client = %p, uEventMask = 0x%x", pUserInfo, pCbRegInfo->sCbRegInfo.uEventMask);

	pUserInfo->sCallbackInfo = *pCbRegInfo;

fail:
	if (bUnlockMutex)
	{
		BridgeChip_OSAL_UnLockMutex(pUserInfo->pPhysicalContext->sHwMutex);
	}

	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

BridgeChip_StatusType bridge_ds90uh981q_ub988t_11_Install(BridgeChip_PluginFunctionTableType *pFxnTable)
{
	BridgeChip_StatusType eStatus = BRIDGECHIP_STATUS_SUCCESS;

	(void) BridgeChip_Logger_Init();

	LOG_TRACE(CHIP_ID, "ENTER");

	if (pFxnTable)
	{
		BridgeChip_OSAL_Memset(pFxnTable, 0x00, sizeof(BridgeChip_PluginFunctionTableType));
		BridgeChip_OSAL_Memset(&gsPluginInfo, 0x00, sizeof(gsPluginInfo));

		pFxnTable->pBridgeChip_Plugin_GetCapabilities = bridge_ds90uh981q_ub988q_get_capabilities;
		pFxnTable->pBridgeChip_Plugin_Open = bridge_ds90uh981q_ub988q_dev_open;
		pFxnTable->pBridgeChip_Plugin_Close = bridge_ds90uh981q_ub988q_dev_close;
		pFxnTable->pBridgeChip_Plugin_SetProperty = bridge_ds90uh981q_ub988q_dev_set_prop;
		pFxnTable->pBridgeChip_Plugin_GetProperty = bridge_ds90uh981q_ub988q_dev_get_prop;
		pFxnTable->pBridgeChip_Plugin_Commit = bridge_ds90uh981q_ub988q_dev_commit;
		pFxnTable->pBridgeChip_Plugin_RegisterEventCallback = bridge_ds90uh981q_ub988q_dev_reg_cb;
	}
	else
	{
		LOG_ERROR(CHIP_ID, "Bad Params");
		eStatus = BRIDGECHIP_STATUS_BAD_PARAMS;
	}

	LOG_TRACE(CHIP_ID, "EXIT");

	return eStatus;
}

#ifdef __cplusplus
}
#endif

