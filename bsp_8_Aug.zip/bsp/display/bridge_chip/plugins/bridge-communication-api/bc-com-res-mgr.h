/**
 * @file       bc-communication-res-mgr.h
 * @brief      Sync point for bridge i2c communication
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __BC_COMMUNICATION_RES_MGR_H__
#define __BC_COMMUNICATION_RES_MGR_H__

#include "bc-com-ioctl.h"
#include "bc-com-types.h"

BridgeChip_StatusType bc_com_init(bc_com_i2c_st_t *bc_com_i2c, char *bc_name,
        char *api_dev_node);
BridgeChip_StatusType bc_com_deinit(void);

#endif /* __BC_COMMUNICATION_RES_MGR_H__ */

