/**
 * @file       bc-com-ioctl.h
 * @brief      Common IOCTL API
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __BC_COM_IOCTL_H__
#define __BC_COM_IOCTL_H__

#include "bc-com-cmd.h"
#include "bc-com-types.h"

int bc_com_ioctl(bc_com_st_t *bc_com, int cmd, bc_com_ioctl_data_st_t *data,
        int32_t rcvid);

int init_operation_lock(bc_com_st_t *bc_com);
void destroy_operation_lock(bc_com_st_t *bc_com);

int operation_lock(bc_com_st_t *bc_com, char *lock_owner);
int operation_unlock(bc_com_st_t *bc_com, char *lock_owner);

int bc_serve_clients(bc_com_i2c_st_t *bc_com_i2c, int operations_cnt,
        unsigned int operation_duration_ms);

#endif /* __BC_COM_IOCTL_H__ */

