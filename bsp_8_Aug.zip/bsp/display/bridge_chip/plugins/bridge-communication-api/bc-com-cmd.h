/**
 * @file       bc-com-cmd.h
 * @brief      IOCTL commands, types and API
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __BC_COM_CMD_H__
#define __BC_COM_CMD_H__

#include <devctl.h>
#include <stdint.h>

typedef struct ioctl_data {
        uint32_t id;
        uint32_t page;
        uint32_t reg;
        uint32_t size;
        uint32_t value;
        uint32_t rc;
} bc_com_ioctl_data_st_t;

#define IOCTL_CREATE(x) __DIOTF(_DCMD_MISC, (x), bc_com_ioctl_data_st_t)

#define BC_IOCTL_CMD_I2C_READ                IOCTL_CREATE(1)
#define BC_IOCTL_CMD_I2C_WRITE               IOCTL_CREATE(2)
#define BC_IOCTL_CMD_I2C_READ_IND            IOCTL_CREATE(3)
#define BC_IOCTL_CMD_I2C_WRITE_IND           IOCTL_CREATE(4)
#define BC_IOCTL_CMD_I2C_READ_APB            IOCTL_CREATE(5)
#define BC_IOCTL_CMD_I2C_WRITE_APB           IOCTL_CREATE(6)

#endif /* __BC_COM_CMD_H__ */

