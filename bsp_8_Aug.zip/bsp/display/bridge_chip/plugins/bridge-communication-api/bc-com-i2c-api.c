/**
 * @file       bc-com-i2c-api.c
 * @brief      I2C API implementation
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#include "bc-com-i2c-api.h"

#include "i2c_client.h"

#define FIRST_BYTE(x)                   ((x) & 0x000000FF)
#define SECOND_BYTE(x)                  (((x) & 0x0000FF00) >> 8)
#define THIRD_BYTE(x)                   (((x) & 0x00FF0000) >> 16)
#define FOURTH_BYTE(x)                  (((x) & 0xFF000000) >> 24)

#define USEC_IN_MSEC                    ((uint32_t)1000U)
#define MS_TO_US(x)                     ((x) * USEC_IN_MSEC)

#define UINT8_ARRAY_TO_UNIT32(array)    ((array)[3] << 24 |                     \
                                         (array)[2] << 16 |                     \
                                         (array)[1] << 8 |                      \
                                         (array)[0] << 0)

#define TO_SECOND_BYTE(x)               (uint32_t)((x) << 8)

/* PAGES info */
#define DS98X_REG_IND_CTL               0x40
#define DS98X_REG_IND_ADDR              0x41
#define DS98X_REG_IND_DATA              0x42
#define DS98X_IND_READ                  BIT(0)
#define DS98X_IND_AUTO_INC              BIT(1)

#define DS98X_REG_APB_CTL               0x48
#define DS98X_REG_APB_ADDR0             0x49
#define DS98X_REG_APB_ADDR1             0x4A
#define DS98X_REG_APB_DATA0             0x4B
#define DS98X_REG_APB_DATA1             0x4C
#define DS98X_REG_APB_DATA2             0x4D
#define DS98X_REG_APB_DATA3             0x4E
#define DS98X_APB_ENABLE                BIT(0)
#define DS98X_APB_READ                  BIT(1)

static inline
int ind_lock(const bc_com_st_t *bc_com)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = pthread_mutex_lock((pthread_mutex_t *)&bc_com->i2c_ind_ctl.mutex);
        if (EOK != rc) {
                log_err("Can't obtain the mutex: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return rc;
}

static inline
int ind_unlock(const bc_com_st_t *bc_com)
{
        int rc;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = pthread_mutex_unlock((pthread_mutex_t *)
                                  &bc_com->i2c_ind_ctl.mutex);
        if (EOK != rc) {
                log_err("Can't release the mutex: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return EOK;
}

static inline
int apb_lock(const bc_com_st_t *bc_com)
{
        int rc;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = pthread_mutex_lock((pthread_mutex_t *)&bc_com->i2c_apb_ctl.mutex);
        if (EOK != rc) {
                log_err("Can't obtain the mutex: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return EOK;
}

static inline
int apb_unlock(const bc_com_st_t *bc_com)
{
        int rc;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = pthread_mutex_unlock((pthread_mutex_t *)
                                  &bc_com->i2c_apb_ctl.mutex);
        if (EOK != rc) {
                log_err("Can't release the mutex: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return EOK;
}

int internal_i2c_write(const bc_com_st_t *bc_com, uint8_t reg, uint8_t data)
{
        uint8_t buf[] = {reg, data};
        uint8_t size = 0;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        size = i2c_write(bc_com->bc_com_i2c->i2c_fd, buf, ARRAY_SIZE(buf));
        if (ARRAY_SIZE(buf) != size) {
                log_err("I2C write failed: processed %d bytes\n", size);

                return -EAGAIN;
        }

        usleep(MS_TO_US(bc_com->bc_com_i2c->i2c_sleep_ms));

        return EOK;
}

int internal_i2c_read(const bc_com_st_t *bc_com, uint8_t reg, uint8_t *data)
{
        uint8_t wb = reg;
        uint8_t size = 0;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        size = i2c_combined_writeread(bc_com->bc_com_i2c->i2c_fd, &wb,
                                      sizeof(uint8_t), data, sizeof(uint8_t));
        if (sizeof(uint8_t) != size) {
                log_err("I2C read failed: read %d bytes\n", size);

                return -EAGAIN;
        }

        usleep(MS_TO_US(bc_com->bc_com_i2c->i2c_sleep_ms));

        return EOK;
}

int bc_com_i2c_write(const bc_com_st_t *bc_com, reg_st_t *data)
{
        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        return internal_i2c_write(bc_com, data->reg, data->value);
}

int bc_com_i2c_read(const bc_com_st_t *bc_com, reg_st_t *data)
{
        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        return internal_i2c_read(bc_com, data->reg, (uint8_t *)&data->value);
}

int bc_com_init_indirect_api(bc_com_st_t *bc_com, indirect_i2c_st_t *ind_ctl)
{
        int rc = EOK;

        if (NULL == bc_com || NULL == ind_ctl) {
                log_err("Invalid input: bc_com = %p, ind_ctl = %p\n", bc_com,
                        ind_ctl);

                return -EINVAL;
        }

        bc_com->i2c_ind_ctl = *ind_ctl;

        rc = pthread_mutex_init(&bc_com->i2c_ind_ctl.mutex, NULL);
        if (EOK != rc) {
                log_err("Can't init IND mutex. Error: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return EOK;
}

int bc_com_i2c_write_ind_1b(const bc_com_st_t *bc_com, uint8_t page,
        uint8_t reg, uint32_t data)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = ind_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        rc = internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.ctrl_reg, page);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.addr_reg, reg);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 FIRST_BYTE(data));

        if (EOK != rc) {
                log_err("Write to indirect register: [P%d] 0x%X -> 0x%X\n",
                        page, data, reg);
        }

        rc |= ind_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int bc_com_i2c_write_ind_2b(const bc_com_st_t *bc_com, uint8_t page,
        uint8_t reg, uint32_t data)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = ind_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        rc = internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.ctrl_reg,
                                page | bc_com->i2c_ind_ctl.auto_inc);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.addr_reg, reg);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 FIRST_BYTE(data));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 SECOND_BYTE(data));

        if (EOK != rc) {
                log_err("Write to indirect register: [P%d] 0x%X -> 0x%X\n",
                        page, data, reg);
        }

        rc |= ind_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int bc_com_i2c_write_ind_3b(const bc_com_st_t *bc_com, uint8_t page,
        uint8_t reg, uint32_t data)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = ind_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        rc = internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.ctrl_reg,
                                page | bc_com->i2c_ind_ctl.auto_inc);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.addr_reg, reg);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 FIRST_BYTE(data));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 SECOND_BYTE(data));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                 THIRD_BYTE(data));

        if (EOK != rc) {
                log_err("Write to indirect register: [P%d] 0x%X -> 0x%X\n",
                        page, data, reg);
        }

        rc |= ind_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int bc_com_i2c_read_ind_1b(const bc_com_st_t *bc_com,
        uint8_t page, uint8_t reg, uint8_t *data)
{
        int rc = EOK;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        rc = ind_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        rc = internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.ctrl_reg,
                                page | bc_com->i2c_ind_ctl.read_enable);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.addr_reg, reg);

        rc |= internal_i2c_read(bc_com, bc_com->i2c_ind_ctl.data_reg, data);

        if (EOK != rc) {
                log_err("Read from indirect register: [P%d] 0x%X <- 0x%X\n",
                        page, *data, reg);
        }

        rc |= ind_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int bc_com_i2c_read_ind_2b(const bc_com_st_t *bc_com,
        uint8_t page, uint8_t reg, uint16_t *data)
{
        int rc = EOK;
        uint8_t read_data = 0;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        rc = ind_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.ctrl_reg,
                                 page | bc_com->i2c_ind_ctl.read_enable |
                                 bc_com->i2c_ind_ctl.auto_inc);

        rc |= internal_i2c_write(bc_com, bc_com->i2c_ind_ctl.addr_reg, reg);

        rc |= internal_i2c_read(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                &read_data);
        *data = read_data;

        rc |= internal_i2c_read(bc_com, bc_com->i2c_ind_ctl.data_reg,
                                &read_data);
        *data |= TO_SECOND_BYTE(read_data);

        if (EOK != rc) {
                log_err("Read from indirect register: [P%d] 0x%X <- 0x%X\n",
                        page, *data, reg);
        }

        rc |= ind_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock indirect pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int bc_com_i2c_write_ind(const bc_com_st_t *bc_com, reg_st_t *data)
{
        int rc = EOK;
        uint32_t page = 0;
        uint32_t reg = 0;
        uint32_t value = 0;
        uint32_t size = 0;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p",
                        bc_com, data);

                return -EINVAL;
        }

        page = data->page;
        reg = data->reg;
        value = data->value;
        size = data->size;

        switch (size) {
        case 1:
                rc = bc_com_i2c_write_ind_1b(bc_com, page, reg, value);

                break;
        case 2:
                rc = bc_com_i2c_write_ind_2b(bc_com, page, reg, value);

                break;
        case 3:
                rc = bc_com_i2c_write_ind_3b(bc_com, page, reg, value);

                break;
        default:
                log_err("Incorrect indirect reg size provided: %d", size);
        }

        return rc;
}

int bc_com_i2c_read_ind(const bc_com_st_t *bc_com, reg_st_t *data)
{
        int rc = EOK;
        uint32_t page = 0;
        uint32_t reg = 0;
        uint32_t *value = NULL;
        uint32_t size = 0;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p",
                        bc_com, data);

                return -EINVAL;
        }

        page = data->page;
        reg = data->reg;
        value = &data->value;
        size = data->size;

        switch (size) {
        case 1:
                rc = bc_com_i2c_read_ind_1b(bc_com, page, reg,
                                            (uint8_t *)value);

                break;
        case 2:
                rc = bc_com_i2c_read_ind_2b(bc_com, page, reg,
                                            (uint16_t *)value);

                break;
        default:
                log_err("Incorrect indirect reg size provided: %d", size);
        }

        return rc;
}

int bc_com_init_apb(bc_com_st_t *bc_com, apb_i2c_st_t *apb_control)
{
        int rc = EOK;

        if (NULL == bc_com || NULL == apb_control) {
                log_err("Invalid inputs: bc_com = %p, apb = %p\n", bc_com,
                        apb_control);

                return -EINVAL;
        }

        bc_com->i2c_apb_ctl = *apb_control;

        rc = pthread_mutex_init(&bc_com->i2c_apb_ctl.mutex, NULL);
        if (EOK != rc) {
                log_err("Can't init APB mutex. Error: %s\n", strerror(rc));

                return -EAGAIN;
        }

        return EOK;
}

int bc_com_i2c_apb_read(const bc_com_st_t *bc_com, reg_st_t *data)
{
        int rc = EOK;
        uint8_t read_value[sizeof(uint32_t)] = {0};

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n", bc_com,
                        data);

                return -EINVAL;
        }

        rc = apb_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock APB pages: %s\n", strerror(errno));

                return rc;
        }

        /* Write to the APB_ADR0 and APB_ADR1 registers to set
         * the register offset */
        rc = internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.addr0_reg,
                                FIRST_BYTE(data->reg));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.addr1_reg,
                                 SECOND_BYTE(data->reg));

        /* Write to the APB_CTL register to select the desired register block,
         * enable the APB interface, and start APB read */
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.ctrl_reg,
                                 bc_com->i2c_apb_ctl.read_enable);

        /* Read the register value from the APB_DATA0, APB_DATA1, APB_DATA2,
         * and APB_DATA3 registers */
        rc |= internal_i2c_read(bc_com, bc_com->i2c_apb_ctl.data0_reg,
                                &read_value[0]);
        rc |= internal_i2c_read(bc_com, bc_com->i2c_apb_ctl.data1_reg,
                                &read_value[1]);
        rc |= internal_i2c_read(bc_com, bc_com->i2c_apb_ctl.data2_reg,
                                &read_value[2]);
        rc |= internal_i2c_read(bc_com, bc_com->i2c_apb_ctl.data3_reg,
                                &read_value[3]);

        if (EOK != rc) {
                log_err("Read from APB register: 0x%X <- 0x%X\n",
                        data->value, data->reg);
        }

        rc |= apb_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock APB pages: %s\n", strerror(errno));

                return rc;
        }

        data->value = UINT8_ARRAY_TO_UNIT32(read_value);

        return rc;
}

int bc_com_i2c_apb_write(const bc_com_st_t *bc_com, reg_st_t *data)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = apb_lock(bc_com);
        if (EOK != rc) {
                log_err("Can't lock APB pages: %s\n", strerror(errno));

                return rc;
        }

        /* Write to the APB_ADR0 and APB_ADR1 registers to set
         * the register offset */
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.addr0_reg,
                                 FIRST_BYTE(data->reg));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.addr1_reg,
                                 SECOND_BYTE(data->reg));

        /* Write to the APB_CTL register to select the desired register block
         * and enable the APB interface */
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.ctrl_reg,
                                 bc_com->i2c_apb_ctl.write_enable);

        /* Write the register value to the APB_DATA0, APB_DATA1, APB_DATA2,
         * and APB_DATA3 registers */
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.data0_reg,
                                 FIRST_BYTE(data->value));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.data1_reg,
                                 SECOND_BYTE(data->value));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.data2_reg,
                                 THIRD_BYTE(data->value));
        rc |= internal_i2c_write(bc_com, bc_com->i2c_apb_ctl.data3_reg,
                                 FOURTH_BYTE(data->value));

        if (EOK != rc) {
                log_err("Write to APB register: 0x%X -> 0x%X\n",
                        data->value, data->reg);
        }

        rc |= apb_unlock(bc_com);
        if (EOK != rc) {
                log_err("Can't unlock APB pages: %s\n", strerror(errno));

                return rc;
        }

        return rc;
}

int init_i2c_api(bc_com_st_t *bc_com)
{
        int rc = EOK;

        indirect_i2c_st_t ind_control = {
                .ctrl_reg    = DS98X_REG_IND_CTL,
                .addr_reg    = DS98X_REG_IND_ADDR,
                .data_reg    = DS98X_REG_IND_DATA,
                .auto_inc    = DS98X_IND_AUTO_INC,
                .read_enable = DS98X_IND_READ,
        };

        apb_i2c_st_t apb_control = {
                .ctrl_reg     = DS98X_REG_APB_CTL,
                .addr0_reg    = DS98X_REG_APB_ADDR0,
                .addr1_reg    = DS98X_REG_APB_ADDR1,
                .data0_reg    = DS98X_REG_APB_DATA0,
                .data1_reg    = DS98X_REG_APB_DATA1,
                .data2_reg    = DS98X_REG_APB_DATA2,
                .data3_reg    = DS98X_REG_APB_DATA3,
                .read_enable  = DS98X_APB_ENABLE | DS98X_APB_READ,
                .write_enable = DS98X_APB_ENABLE
        };

        rc = bc_com_init_indirect_api(bc_com, &ind_control);
        if (EOK != rc) {
                log_err("Can't init i2c indirect API\n");

                return rc;
        }

        rc = bc_com_init_apb(bc_com, &apb_control);
        if (EOK != rc) {
                log_err("Can't init i2c APB API\n");

                pthread_mutex_destroy(&bc_com->i2c_ind_ctl.mutex);

                return rc;
        }

        return rc;
}

int select_i2c_bridge(bc_com_st_t *bc_com, uint8_t i2c_dev_addr)
{
        int rc = EOK;

        rc = i2c_set_slave_addr(bc_com->bc_com_i2c->i2c_fd, i2c_dev_addr,
                                I2C_ADDRFMT_7BIT);
        if (EOK != rc) {
                log_err("Can't select bridge with id: %d\n", i2c_dev_addr);

                return -EAGAIN;
        }

        return EOK;
}

int bc_com_init_i2c(bc_com_st_t *bc_com)
{
        int rc = EOK;

        bc_com_i2c_st_t *bc_com_i2c = NULL;
        uint32_t ospeed = 0;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        bc_com_i2c = bc_com->bc_com_i2c;

        bc_com_i2c->i2c_fd = i2c_open(bc_com_i2c->i2c_dev_name);
        if (bc_com_i2c->i2c_fd <= 0) {
                log_err("Can't open i2c device : %s\n",
                        bc_com_i2c->i2c_dev_name);

                return -EAGAIN;
        }

        rc = i2c_set_bus_speed(bc_com_i2c->i2c_fd, I2C_SPEED_STANDARD,
                               &ospeed);
        if (EOK != rc) {
                log_err("Can't set bus speed\n");

                /* No return as that error is not critical */
        }

        /* No i2c set slave address here, as it will be provided during
         * IOCTL request
         */

        log_trace("Host i2c initialized: dev = %s, fd = %d\n",
                  bc_com_i2c->i2c_dev_name, bc_com_i2c->i2c_fd);

        rc = init_i2c_api(bc_com);
        if (EOK != rc) {
                log_err("Can't init I2C API\n");

                goto close_i2c;
        }

        return rc;

close_i2c:
        i2c_close(bc_com->bc_com_i2c->i2c_fd);

        return rc;
}

int bc_com_deinit_i2c(bc_com_st_t *bc_com)
{
        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        pthread_mutex_destroy(&bc_com->i2c_ind_ctl.mutex);
        pthread_mutex_destroy(&bc_com->i2c_apb_ctl.mutex);

        if (NULL != bc_com->bc_com_i2c) {
                i2c_close(bc_com->bc_com_i2c->i2c_fd);
        }

        return EOK;
}

