/**
 * @file       bc-com-ioctl.c
 * @brief      IOCTL handler routines
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#include <stdatomic.h>
#include <stdbool.h>
#include <string.h>

#include "bc-com-cmd.h"
#include "bc-com-i2c-api.h"
#include "bc-com-ioctl.h"
#include "bc-com-types.h"

#define API_ITERATION_SLEEP_US  (100 * 1000)
#define USEC_IN_MSEC            1000
#define SHARED                  1
#define SEM_COUNT               1

static atomic_int operations_left;

int init_operation_lock(bc_com_st_t *bc_com)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        rc = sem_init(&bc_com->ops_lock, 0, SEM_COUNT);
        if (EOK != rc) {
                log_err("Can't init lock. Error: %d\n", rc);

                return rc;
        }

        log_trace("Mutex initialized");

        return rc;
}

void destroy_operation_lock(bc_com_st_t *bc_com)
{
        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return;
        }

        sem_destroy(&bc_com->ops_lock);
}

int operation_lock(bc_com_st_t *bc_com, char *lock_owner)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        log_trace("Try to obtain lock from: \"%s\"\n", lock_owner);

        do {
                rc = sem_wait(&bc_com->ops_lock);
        } while (rc != EOK && errno == EINTR);

        if (EOK != rc) {
                log_err("Can't lock operation for \"%s\". Error: %s\n",
                        lock_owner, strerror(rc));
                log_err("Lock operation errno: %s\n", strerror(errno));

                return rc;
        }

        log_trace("Lock obtained from: \"%s\"\n", lock_owner);

        return rc;
}

int operation_unlock(bc_com_st_t *bc_com, char *lock_owner)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return -EINVAL;
        }

        log_trace("Try to unlock from: \"%s\"\n", lock_owner);

        rc = sem_post(&bc_com->ops_lock);
        if (EOK != rc) {
                log_err("Can't unlock operation for \"%s\". Error: %s\n",
                        lock_owner, strerror(rc));

                return rc;
        }

        log_trace("Lock released from: \"%s\"\n", lock_owner);

        return rc;
}

int bc_serve_clients(bc_com_i2c_st_t *bc_com_i2c, int operations_cnt,
        unsigned int operation_duration_ms)
{
        bc_com_st_t *bc_com = NULL;
        int rc = EOK;

        if (NULL == bc_com_i2c) {
                log_err("Invalid input: bc_com_i2c = %p", bc_com_i2c);

                return -EINVAL;
        }

        bc_com = (bc_com_st_t *)bc_com_i2c->ctx;
        if (NULL == bc_com) {
                log_err("Operation is not permitted: Resource manager"
                        " is not initialized!");

                return -EPERM;
        }

        log_trace("%s: Start serving %d clients operations",
                  bc_com_i2c->i2c_dev_name, operations_cnt);

        operations_left = operations_cnt;

        /* First unlock will fail because of no lock before. It's fine */
        rc = operation_unlock(bc_com, "Serve I2C requests");
        if (EOK != rc) {
                log_err("Can't release IPC lock (tid = %d). Error: %s\n",
                        gettid(), strerror(rc));
        }

        (void)usleep(operation_duration_ms * USEC_IN_MSEC);

        /* Force operations left set zero, so in case lock is not obtained
         * operations are still not allowed by the 'counter' limit
         */
        operations_left = 0;

        rc = operation_lock(bc_com, "Stop serving I2C requests");

        log_trace("%s: Stop serving clients operations. Rc = %s",
                  bc_com_i2c->i2c_dev_name, strerror(rc));

        return EOK;
}

static
int process_request(bc_com_st_t *bc_com, int cmd, bc_com_ioctl_data_st_t *data)
{
        int rc = EOK;
        reg_st_t bridge_reg = {0};

        rc = select_i2c_bridge(bc_com, data->id);
        if (EOK != rc) {
                log_err("Can't select bridge");

                return rc;
        }

        bridge_reg.page = data->page;
        bridge_reg.reg = data->reg;
        bridge_reg.size = data->size;
        bridge_reg.value = data->value;

        switch (cmd) {
        case BC_IOCTL_CMD_I2C_READ:
                rc = bc_com_i2c_read(bc_com, &bridge_reg);

                log_trace("Called i2c read for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                break;
        case BC_IOCTL_CMD_I2C_WRITE:
                log_trace("Called i2c write for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                rc = bc_com_i2c_write(bc_com, &bridge_reg);

                break;
        case BC_IOCTL_CMD_I2C_READ_IND:
                rc = bc_com_i2c_read_ind(bc_com, &bridge_reg);

                log_trace("Called i2c read ind for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                break;
        case BC_IOCTL_CMD_I2C_WRITE_IND:
                rc = bc_com_i2c_write_ind(bc_com, &bridge_reg);

                log_trace("Called i2c write ind for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                break;
        case BC_IOCTL_CMD_I2C_READ_APB:
                rc = bc_com_i2c_apb_read(bc_com, &bridge_reg);

                log_trace("Called i2c read apb for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                break;
        case BC_IOCTL_CMD_I2C_WRITE_APB:
                rc = bc_com_i2c_apb_write(bc_com, &bridge_reg);

                log_trace("Called i2c write apb for device 0x%X [0x%X] -> 0x%X",
                          data->id, bridge_reg.reg, bridge_reg.value);

                break;
        }

        data->page = bridge_reg.page;
        data->reg = bridge_reg.reg;
        data->size = bridge_reg.size;
        data->value = bridge_reg.value;

        data->rc = rc;

        return rc;
}

int bc_com_ioctl(bc_com_st_t *bc_com, int cmd,
        bc_com_ioctl_data_st_t *data, int32_t rcvid)
{
        int rc = EOK;

        if (NULL == bc_com || NULL == data) {
                log_err("Invalid input: bc_com = %p, data = %p\n",
                        bc_com, data);

                return -EINVAL;
        }

        log_trace("Operations left: %d", operations_left);

        while (true) {
                rc = operation_lock(bc_com, "IOCTL");
                if (EOK != rc) {
                        log_err("Can't lock request\n");

                        return rc;
                }

                if (operations_left > 0) {
                        operations_left--;
                        rc = process_request(bc_com, cmd, data);
                        operation_unlock(bc_com, "IOCTL");

                        break;
                }

                /* Release lock for bridgechip */
                operation_unlock(bc_com, "IOCTL");
                (void)usleep(API_ITERATION_SLEEP_US);
        }

        return rc;
}

