/**
 * @file       bc-com-res-mgr.c
 * @brief      Sync point for bridge i2c communication
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#include "bc-com-cmd.h"
#include "bc-com-i2c-api.h"
#include "bc-com-ioctl.h"
#include "bc-com-res-mgr.h"

static bc_com_st_t *bc_com_context;

#define RES_MGR_PERMS           0664
#define MAX_BLOCKED_THR         4
#define MIN_READY_THR           2
#define MAX_THR_CNT             50

int bc_com_io_open(resmgr_context_t *res_mgr_ctx, io_open_t *msg,
        RESMGR_HANDLE_T *handle, void *extra)
{
        ioattr_device_t *attr_ctx = (ioattr_device_t *)handle;

        log_trace("Try to open devnode");

        return iofunc_open_default(res_mgr_ctx, msg, &attr_ctx->attr, extra);
}

int bc_com_io_devctl(resmgr_context_t *res_mgr_ctx, io_devctl_t *msg,
        RESMGR_OCB_T *ocb)
{
        int status;
        int32_t rcvid;
        int nbytes = 0;
        ioattr_device_t *attr_ctx;
        bc_com_st_t *bc_com;
        bc_com_ioctl_data_st_t *data;
        int rc;
        size_t size;
        iofunc_ocb_t *resmgr_ocb = ocb;

        if (NULL == res_mgr_ctx || NULL == msg || NULL == ocb) {
                log_err("Invalid input: res_mgr_ctx = %p, msg = %p, ocb = %p\n",
                        res_mgr_ctx, msg, ocb);

                return -EINVAL;
        }

        status = iofunc_devctl_default(res_mgr_ctx, msg, ocb);
        if (_RESMGR_DEFAULT != status) {
                log_err("Can't set default res mgr\n");

                return status;
        }

        size = (res_mgr_ctx->size - sizeof(msg->i));
        if (sizeof(bc_com_ioctl_data_st_t) != size) {
                log_err("Invalid data received. Wrong size %lu. Expected %lu\n",
                        res_mgr_ctx->size - sizeof(msg->i),
                        sizeof(bc_com_ioctl_data_st_t));

                return -EINVAL;
        }

        rcvid = res_mgr_ctx->rcvid;
        attr_ctx = resmgr_ocb->attr;
        bc_com = attr_ctx->bc_com;

        data = _DEVCTL_DATA(msg->i);

        rc = bc_com_ioctl(bc_com, msg->i.dcmd, data, rcvid);
        if (EOK != rc) {
                log_err("Can't process IOCTL cmd 0x%x \n", msg->i.dcmd);
        }

        /* we always return the bc_com ioctl data */
        nbytes = sizeof(bc_com_ioctl_data_st_t);

        msg->o.nbytes = nbytes;

        return _RESMGR_PTR(res_mgr_ctx, &msg->o, sizeof(msg->o) + nbytes);
}

void deinit_resmgr(bc_com_st_t *bc_com)
{
        int rc = EOK;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return;
        }

        rc = thread_pool_destroy(bc_com->res_mgr.thr_pool_ctx);
        if (rc != EOK) {
                log_err("Can't destroy threadpool. Error: %s",
                        strerror(rc));
        }

        rc = resmgr_detach(bc_com->res_mgr.dispatch, bc_com->res_mgr.id,
                           _RESMGR_DETACH_ALL);
        if (rc != EOK) {
                log_err("Can't detach resmgr \"%s\". Error: %s",
                        bc_com->bc_com_api_dev_path, strerror(errno));
        }

        rc = dispatch_destroy(bc_com->res_mgr.dispatch);
        if (rc != EOK) {
                log_err("Can't destroy dispatch. Error: %s", strerror(errno));
        }
}

void *res_mgr_init(void *ctx)
{
        bc_com_st_t *bc_com = (bc_com_st_t *)ctx;
        dispatch_t *dispatch_ptr = NULL;
        thread_pool_t *thr_pool_ptr;
        thread_pool_attr_t pool_attr = {0};
        bc_com_res_mgr_st_t *res_mgr = NULL;
        int id;

        if (NULL == bc_com) {
                log_err("Invalid input: bc_com = %p\n", bc_com);

                return NULL;
        }

        res_mgr = &bc_com->res_mgr;

        /* initialize dispatch interface */
        dispatch_ptr = dispatch_create();
        if (NULL == dispatch_ptr) {
                log_err("Can't create dispatch\n");

                goto init_failed;
        }

        bc_com->res_mgr.dispatch = dispatch_ptr;

        iofunc_func_init(_RESMGR_CONNECT_NFUNCS, &res_mgr->connect_funcs,
                         _RESMGR_IO_NFUNCS, &res_mgr->io_funcs);

        res_mgr->connect_funcs.open = bc_com_io_open;
        res_mgr->io_funcs.devctl = bc_com_io_devctl;

        /* initialize attribute structure used by the device */
        iofunc_attr_init(&res_mgr->device_attr.attr,
                         S_IFNAM | RES_MGR_PERMS, 0, 0);

        res_mgr->device_attr.bc_com = bc_com;
        res_mgr->device_attr.attr.nbytes = sizeof(bc_com_ioctl_data_st_t);

        log_trace("Try to attach res mgr to node: \"%s\"",
                  bc_com->bc_com_api_dev_path);

        /* attach our device name */
        id = resmgr_attach(dispatch_ptr,
                           &bc_com->res_mgr.resmgr_attr,
                           bc_com->bc_com_api_dev_path,
                           _FTYPE_ANY,
                           _RESMGR_FLAG_DIR,
                           &bc_com->res_mgr.connect_funcs,
                           &bc_com->res_mgr.io_funcs,
                           &bc_com->res_mgr.device_attr);
        if (-1 == id) {
                log_err("Unable to attach resmgr\n");

                goto init_failed;
        }

        bc_com->res_mgr.dispatch = dispatch_ptr;

        /* initialize thread pool attributes */
        /* TODO: Investigate callback signature override */
        pool_attr.handle = dispatch_ptr;
        pool_attr.context_alloc = dispatch_context_alloc;
        pool_attr.block_func = dispatch_block;
        pool_attr.unblock_func = dispatch_unblock;
        pool_attr.handler_func = dispatch_handler;
        pool_attr.context_free = dispatch_context_free;

        /* initialize thread pool capacity attributes */
        pool_attr.lo_water = MIN_READY_THR;
        pool_attr.hi_water = MAX_BLOCKED_THR;
        pool_attr.increment = 1;
        pool_attr.maximum = MAX_THR_CNT;

        /* allocate a thread pool handle */
        thr_pool_ptr = thread_pool_create(&pool_attr, POOL_FLAG_EXIT_SELF);
        if (NULL == thr_pool_ptr) {
                log_err("Unable to initialize thread pool\n");

                goto init_failed;
        }

        bc_com->res_mgr.thr_pool_ctx = thr_pool_ptr;

        /* start the threads, will not return */
        log_trace("start thread pool for '%s'\n", bc_com->bc_plugin_name);
        thread_pool_start(thr_pool_ptr);

init_failed:
        log_err("Thread pool creation for '%s' failed\n",
                bc_com->bc_plugin_name);

        deinit_resmgr(bc_com_context);

        return NULL;
}

BridgeChip_StatusType bc_com_init(bc_com_i2c_st_t *bc_com_i2c, char *bc_name,
        char *api_dev_node)
{
        int rc = EOK;

        if (NULL == bc_com_i2c || NULL == bc_name || NULL == api_dev_node) {
                log_err("Invalid input: bc_com_i2c = %p\n, bc_name = %p, "
                        "api_dev_node = %p\n", bc_com_i2c, bc_name,
                        api_dev_node);

                return BRIDGECHIP_STATUS_BAD_PARAMS;
        }

        bc_com_context = alloc_data(1, bc_com_st_t);
        if (NULL == bc_com_context) {
                log_err("Can't allocate bridge chip context\n");

                return BRIDGECHIP_STATUS_NO_RESOURCES;
        }

        bc_com_i2c->ctx = bc_com_context;
        bc_com_context->bc_plugin_name = bc_name;
        bc_com_context->bc_com_i2c = bc_com_i2c;
        bc_com_context->bc_com_api_dev_path = api_dev_node;

        rc = init_operation_lock(bc_com_context);
        if (EOK != rc) {
                log_err("Can't init operation mutex\n");

                goto lock_initialization_failed;
        }

        rc = bc_com_init_i2c(bc_com_context);
        if (EOK != rc) {
                log_err("Can't init i2c. Error: %d\n", rc);

                goto i2c_initialization_failed;
        }

        rc = operation_lock(bc_com_context, "Init phase");
        if (EOK != rc) {
                log_err("Can't lock operations for bridgechip. Error: %d\n",
                        rc);

                goto lock_operation_failed;
        }

        rc = pthread_create(&bc_com_context->res_mgr.init_thr, NULL,
                            res_mgr_init, (void *)bc_com_context);
        if (EOK != rc) {
                log_err("Can't create resource manager thread. Error: %s\n",
                        strerror(rc));

                goto pthread_detach_failed;
        }

        rc = pthread_detach(bc_com_context->res_mgr.init_thr);
        if (EOK != rc) {
                log_err("Can't detach resource manager thread. Error: %s\n",
                        strerror(rc));

                goto pthread_detach_failed;
        }

        log_trace("Resource manager is initialized");

        return BRIDGECHIP_STATUS_SUCCESS;

pthread_detach_failed:
        deinit_resmgr(bc_com_context);
        pthread_kill(bc_com_context->res_mgr.init_thr, SIGINT);

lock_operation_failed:
        bc_com_deinit_i2c(bc_com_context);

i2c_initialization_failed:
        destroy_operation_lock(bc_com_context);

lock_initialization_failed:
        clear_data(&bc_com_context);

        return BRIDGECHIP_STATUS_FAILED;
}

BridgeChip_StatusType bc_com_deinit(void)
{
        /* Stop resmgr */
        deinit_resmgr(bc_com_context);

        destroy_operation_lock(bc_com_context);
        bc_com_deinit_i2c(bc_com_context);

        if (NULL != bc_com_context &&
            NULL != bc_com_context->bc_com_i2c) {
                bc_com_context->bc_com_i2c->ctx = NULL;
        }

        clear_data(&bc_com_context);

        return BRIDGECHIP_STATUS_SUCCESS;
}

