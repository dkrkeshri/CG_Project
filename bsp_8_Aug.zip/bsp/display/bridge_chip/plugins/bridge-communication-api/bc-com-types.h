/**
 * @file       bc-com-type.h
 * @brief      bridge i2c communication types
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __BC_I2C_COM_TYPES_H__
#define __BC_I2C_COM_TYPES_H__

#include <semaphore.h>
#include <stdlib.h>
#include <string.h>

#include "bridgechip_logger.h"

struct ioattr_device;
#define IOFUNC_ATTR_T           struct ioattr_device

#define THREAD_POOL_PARAM_T     dispatch_context_t

#include <sys/dispatch.h>
#include <sys/iofunc.h>

#define PREFIX                  "bc_com_ipc"

#define log_err(...)            LOG_ERROR(PREFIX, __VA_ARGS__)
#define log_info(...)           LOG_INFO(PREFIX, __VA_ARGS__)
#define log_trace(...)          LOG_TRACE(PREFIX, __VA_ARGS__)

#define BIT(n)                  (1 << n)
#define ARRAY_SIZE(x)           (sizeof(x) / sizeof(x[0]))

/* Memory API */
#define alloc_data(count, type) (type *)calloc((count), sizeof(type))

static
inline void clear_data(void *buf)
{
        void **ptr = (void **)buf;

        if (NULL == ptr) {
                return;
        }

        free(*ptr);
        *ptr = NULL;
}

struct bc_com;
typedef struct bc_com bc_com_st_t;

typedef struct ioattr_device {
        iofunc_attr_t attr;
        struct bc_com *bc_com;
} ioattr_device_t;

typedef struct bc_com_i2c {
        void     *ctx;
        char     *i2c_dev_name;
        uint32_t i2c_sleep_ms;
        int      i2c_fd;
} bc_com_i2c_st_t;

typedef struct bc_com_res_mgr {
        int                    id;
        dispatch_t             *dispatch;
        resmgr_connect_funcs_t connect_funcs;
        resmgr_io_funcs_t      io_funcs;
        ioattr_device_t        device_attr;
        resmgr_attr_t          resmgr_attr;
        pthread_t              init_thr;
        thread_pool_t          *thr_pool_ctx;
} bc_com_res_mgr_st_t;

typedef struct indirect_i2c {
        uint8_t         ctrl_reg;
        uint8_t         addr_reg;
        uint8_t         data_reg;
        uint8_t         auto_inc;
        uint8_t         read_enable;
        pthread_mutex_t mutex;
} indirect_i2c_st_t;


typedef struct aux_i2c {
        uint16_t        cmd_reg;
        uint16_t        addr_reg;
        uint16_t        write_reg;
        uint16_t        read_reg;
        uint32_t        read_cmd;
        uint32_t        write_cmd;
        pthread_mutex_t mutex;
} aux_i2c_st_t;

typedef struct apb_i2c {
        uint8_t         ctrl_reg;
        uint8_t         addr0_reg;
        uint8_t         addr1_reg;
        uint8_t         data0_reg;
        uint8_t         data1_reg;
        uint8_t         data2_reg;
        uint8_t         data3_reg;
        uint8_t         read_enable;
        uint8_t         write_enable;
        pthread_mutex_t mutex;
} apb_i2c_st_t;

typedef struct reg_st {
        uint32_t page;
        uint32_t reg;
        uint32_t size;
        uint32_t value;
} reg_st_t;

typedef struct bc_com {
        char                *bc_plugin_name;
        char                *bc_com_api_dev_path;
        pthread_mutex_t     i2c_lock;
        bc_com_res_mgr_st_t res_mgr;
        sem_t               ops_lock;

        bc_com_i2c_st_t     *bc_com_i2c;
        struct indirect_i2c i2c_ind_ctl;
        struct apb_i2c      i2c_apb_ctl;
        struct aux_i2c      i2c_aux_ctl;
} bc_com_st_t;

#endif /* __BC_I2C_COM_TYPES_H__ */

