/**
 * @file       bc-com-i2c-api.h
 * @brief      Sync point for bridge i2c communication
 *
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __BC_COM_I2C_API__
#define __BC_COM_I2C_API__

#include "bc-com-ioctl.h"
#include "bc-com-types.h"

int select_i2c_bridge(bc_com_st_t *bc_com, uint8_t i2c_dev_addr);

int bc_com_i2c_write(const bc_com_st_t *bc_com, reg_st_t *data);
int bc_com_i2c_read(const bc_com_st_t *bc_com, reg_st_t *data);

int bc_com_i2c_write_ind(const bc_com_st_t *bc_com, reg_st_t *data);
int bc_com_i2c_read_ind(const bc_com_st_t *bc_com, reg_st_t *data);

int bc_com_i2c_apb_read(const bc_com_st_t *bc_com, reg_st_t *data);
int bc_com_i2c_apb_write(const bc_com_st_t *bc_com, reg_st_t *data);

int bc_com_init_i2c(bc_com_st_t *bc_com);
int bc_com_deinit_i2c(bc_com_st_t *bc_com);

#endif /* __BC_COM_I2C__API_ */

