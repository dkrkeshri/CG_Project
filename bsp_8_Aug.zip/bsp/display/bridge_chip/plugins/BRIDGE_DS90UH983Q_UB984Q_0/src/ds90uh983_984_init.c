/* =========================================================================

   @file    ds90uh983_initializer.c
   @brief   Application, configure ds90ub883 serializer.

   Copyright (c) 2019 by ROBERT BOSCH CAR MULTIMEDIA GMBH.  All Rights Reserved.

   $Header$

   ============================================================================ */
#ifdef __cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <hw/inout.h>
#include <fcntl.h>
#include <ctype.h>
#include <math.h>
#include <amss/i2c_client.h>
#include "bridgechip_plugin.h"
#include "bridgechip_osal.h"
#include "bridgechip_logger.h"

static int32 verbosedebug = 0;
#define MODULE_NAME "FREEFORM_DS90UH983_ES1.1"

#define DEBUG_PRINT(name, _str_, ...)               \
    do { \
        if (verbosedebug) { \
            LOG_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define CRITICAL_PRINT(name, _str_, ...)               \
    do { \
        if (1) { \
            LOG_CRITICAL_INFO(name, _str_ , ##__VA_ARGS__); \
        } \
    } while(0)

#define RX_LOCK_DETECT_BIT 6
#define LINK_DETECT_BIT    0

#define PCLK_FREQ  535.9
#define THW   9760
#define TVW   1408
#define AHW   8960
#define AVW   1320
#define HBP   320
#define VBP   40
#define HSW   80
#define VSW   8

#define lower_byte(in_data) (in_data & 0xFF)
#define upper_byte(in_data) ((in_data & 0xFF00)>>8)
#define PAGE_REG   0x40
#define PAGE_ADDR  0x41
#define PAGE_DATA  0x42

struct reg_val {
    uint8 reg;
    uint8 val;
};

struct abp_reg_val {
    uint32 offset;
    uint32 val;
};

static struct reg_val ser_983_flat_1[]=
{
    {0x40, 0x04},// Page 1
    // De-Emphasis Settings
    //Lane 0 TX
    {0x41, 0x00},
    {0x42, 0x03},
    {0x41, 0x01},
    {0x42, 0x00},
    {0x41, 0x02},
    {0x42, 0x00},
    {0x41, 0x0A},
    {0x42, 0x03},
    {0x41, 0x0B},
    {0x42, 0x00},
    {0x41, 0x0C},
    {0x42, 0x00},

    //Lane 1 TX
    {0x41, 0x20},
    {0x42, 0x03},
    {0x41, 0x21},
    {0x42, 0x00},
    {0x41, 0x22},
    {0x42, 0x00},
    {0x41, 0x2A},
    {0x42, 0x03},
    {0x41, 0x2B},
    {0x42, 0x00},
    {0x41, 0x2C},
    {0x42, 0x00},
    // Setting TX-PLL_P0 to 10.8GHz
    {0x40, 0x08},// Page 2 on 983
    {0x41, 0x0e},
    {0x42, 0xC3},// SELECT VCO1
    {0x41, 0x05},
    {0x42, 0x64},// NCount [7:0]
    {0x41, 0x06},
    {0x42, 0x00},// NCount [15:8]
    {0x41, 0x1e},
    {0x42, 0x00},// NUM_MASH [7:0]
    {0x41, 0x1f},
    {0x42, 0x00},// NUM_MASH [15:8]
    {0x41, 0x20},
    {0x42, 0x00},// NUM_MASH [23:16]
    {0x41, 0x18},
    {0x42, 0xf6},// DEN_MASH [7:0]
    {0x41, 0x19},
    {0x42, 0xff},// DEN_MASH [15:8]
    {0x41, 0x1a},
    {0x42, 0xff},// DEN_MASH [23:16]
    {0x41, 0x04},
    {0x42, 0x01},// integer mode
    {0x41, 0x13},
    {0x42, 0x80},// VCO Auto Disable and DivSelect

    // Setting TX-PLL_P1 to 10.8GHz
    {0x40, 0x08},// Page 2 on 983
    {0x41, 0x4e},
    {0x42, 0xC3},// SELECT VCO1
    {0x41, 0x45},
    {0x42, 0x64},// NCount [7:0]
    {0x41, 0x46},
    {0x42, 0x00},// NCount [15:8]
    {0x41, 0x5e},
    {0x42, 0x00},// NUM_MASH [7:0]
    {0x41, 0x5f},
    {0x42, 0x00},// NUM_MASH [15:8]
    {0x41, 0x60},
    {0x42, 0x00},// NUM_MASH [23:16]
    {0x41, 0x58},
    {0x42, 0xf6},// DEN_MASH [7:0]
    {0x41, 0x59},
    {0x42, 0xff},// DEN_MASH [15:8]
    {0x41, 0x5a},
    {0x42, 0xff},// DEN_MASH [23:16]
    {0x41, 0x44},
    {0x42, 0x01},// integer mode
    {0x41, 0x53},
    {0x42, 0x80},// VCO Auto Disable and DivSelect
};

static int32 write_reg(int32 fd, uint8 reg, uint8 val)
{
    uint8 writedata[2];
    int32 iRetVal;
    writedata[0] = reg;
    writedata[1] = val;
    iRetVal = i2c_write(fd, writedata, 2);

    if(iRetVal != 2) {
        CRITICAL_PRINT(MODULE_NAME, "%s 0x%x : 0x%x", __func__, reg, val);
        LOG_ERROR(MODULE_NAME, "i2c_write() FAILED, iRetVal=%d", iRetVal);
    }
    return  0;
}

static int32 read_reg(int32 fd, uint8 reg, uint8 *retval)
{
    uint32 write_data[2];

    write_data[0] = reg;
    int32 iRetVal = i2c_combined_writeread(fd, write_data, 1, retval, 1);

    if (iRetVal != 1)
        LOG_ERROR(MODULE_NAME, "i2c_combined_writeread() FAILED, iRetVal=%d", iRetVal);

    return 0;
}

static int32 config_regs(int32 fd, struct reg_val *regs, int32 cnt)
{
    int32 i = 0;
    int32 err = 0;

    for (i = 0; i < cnt; i++) {
        err = write_reg(fd, regs[i].reg, regs[i].val);
        if (err < 0) {
            err = EXIT_FAILURE;
            LOG_ERROR(MODULE_NAME, "config_regs FAILED, error=%d", err);
            return err;
        }
        DEBUG_PRINT(MODULE_NAME,
                "reg: 0x%02x <--> value: 0x%02x", regs[i].reg, regs[i].val);
    }

    return EXIT_SUCCESS;
}

#define APB_CTL   0x48
#define APB_ADR0  0x49
#define APB_ADR1  0x4A
#define APB_DATA0 0x4B
#define APB_DATA1 0x4C
#define APB_DATA2 0x4D
#define APB_DATA3 0x4E
#if 0
static uint32 apb_read_reg(int32 fd, uint8 channel, uint16 offset, uint32 *apb_data)
{
    uint8  addr16b_lsb;
    uint8  addr16b_msb;
    uint8  wr_val;
    uint8  apb_data0;
    uint8  apb_data1;
    uint8  apb_data2;
    uint8  apb_data3;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    if (channel == 0) {
        wr_val = 0x03;
    } else if (channel == 1) {
        wr_val = 0x0B;
    } else {
        wr_val = 0x03;
    }

    write_reg(fd, APB_CTL, wr_val);

    read_reg(fd, APB_DATA0, &apb_data0);
    read_reg(fd, APB_DATA1, &apb_data1);
    read_reg(fd, APB_DATA2, &apb_data2);
    read_reg(fd, APB_DATA3, &apb_data3);
    *apb_data =  ((apb_data3 << 24) | (apb_data2 << 16) | (apb_data1 << 8) | apb_data0);

    return EXIT_SUCCESS;
}
#endif

static int32 apb_write_reg(int32 fd, uint8 channel, uint16 offset, uint32 apb_data)
{
    uint8 addr16b_lsb;
    uint8 addr16b_msb;
    uint8 wr_val;
    uint8 apb_data0;
    uint8 apb_data1;
    uint8 apb_data2;
    uint8 apb_data3;

    addr16b_lsb = offset & 0xff;
    addr16b_msb = (offset & 0xff00) >> 8;

    write_reg(fd, APB_ADR0, addr16b_lsb);
    write_reg(fd, APB_ADR1, addr16b_msb);

    apb_data0 = apb_data & 0xff;
    apb_data1 = (apb_data >> 8) & 0xff;
    apb_data2 = (apb_data >> 16) & 0xff;
    apb_data3 = (apb_data >> 24) & 0xff;

    write_reg(fd, APB_DATA0, apb_data0);
    write_reg(fd, APB_DATA1, apb_data1);
    write_reg(fd, APB_DATA2, apb_data2);
    write_reg(fd, APB_DATA3, apb_data3);

    if (channel == 0) {
        wr_val = 0x01;
    } else if (channel == 1) {
        wr_val = 0x09;
    } else {
        wr_val = 0x01;
    }
    write_reg(fd, APB_CTL, wr_val);

    return EXIT_SUCCESS;
}

static int32 dser_984_dp_display_config(int32 fd, uint8 channel)
{
    write_reg(fd, 0x0E, 0x01);
    write_reg(fd, 0xB1, 0x01);
    write_reg(fd, 0xB2, 0x5C);
    write_reg(fd, 0xB3, 0x2D);
    write_reg(fd, 0xB4, 0x08);
    write_reg(fd, 0xB5, 0x40);
    write_reg(fd, 0xB6, 0x70);
    write_reg(fd, 0xB7, 0x31);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x20);
    write_reg(fd, 0x42, 0x81);
    write_reg(fd, 0x41, 0x29);
    write_reg(fd, 0x42, 0x81);
    write_reg(fd, 0x41, 0x2A);
    write_reg(fd, 0x42, 0x90);
    write_reg(fd, 0x41, 0x2F);
    write_reg(fd, 0x42, 0x40);
    write_reg(fd, 0x41, 0x30);
    write_reg(fd, 0x42, 0x50);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x02);

    apb_write_reg(fd, 0, 0x4, 0x4);
    // Port ,channel,: Setting 24-bit bpc
    apb_write_reg(fd, 0, 0x1A4, 0x20);
    apb_write_reg(fd, 0, 0x1B8, 0x4);
    apb_write_reg(fd, 0, 0x180, 0x2620);
    apb_write_reg(fd, 0, 0x184, 0x580);
    apb_write_reg(fd, 0, 0x1AC, 0x54AF);
    apb_write_reg(fd, 0, 0x1B4, 0x8000);
    apb_write_reg(fd, 0, 0x1C8, 0x00);
    apb_write_reg(fd, 0, 0x1B0, 0x120024) ;
    apb_write_reg(fd, 0, 0x0C8, 0x4004);
    apb_write_reg(fd, 0, 0x1BC, 0x1A40);
    apb_write_reg(fd, 0, 0x1C0, 0x00);
    apb_write_reg(fd, 0, 0x1C4, 0x0F);
    apb_write_reg(fd, 0, 0x084, 0x01);
    write_reg(fd, 0x40, 0x50);
    write_reg(fd, 0x41, 0x32);
    write_reg(fd, 0x42, 0x00);

    return 0;
}

static int32 ser_983_vp_config(int32 fd)
{
    int32 m_value=16262;
    float m_value_f;
    int32 n_value = 15;
    int32 src_dp_h_active = AHW;
    int32 src_v_front = TVW - AVW - VBP - VSW;
    uint8 regval;
    int32 iscs20_chip = 0;

    //  Config video processor
    write_reg(fd, 0x2D, 0x01);  //# write Port select to port 0 initially.
    write_reg(fd, 0x40, 0x32);  // # choose page 12, set auto-increment
    write_reg(fd, 0x41, 0x02);  // # dp_h_active
    write_reg(fd, 0x42, lower_byte(src_dp_h_active));  //
    write_reg(fd, 0x42, upper_byte(src_dp_h_active));  //
    write_reg(fd, 0x41, 0x10);  // # h_active
    write_reg(fd, 0x42, lower_byte(AHW));  //
    write_reg(fd, 0x42, upper_byte(AHW));  //
    write_reg(fd, 0x42, lower_byte(HBP));  //
    write_reg(fd, 0x42, upper_byte(HBP));  //
    write_reg(fd, 0x42, lower_byte(HSW));  //
    write_reg(fd, 0x42, upper_byte(HSW));  //
    write_reg(fd, 0x42, lower_byte(THW));  //
    write_reg(fd, 0x42, upper_byte(THW));  //
    write_reg(fd, 0x42, lower_byte(AVW));  //
    write_reg(fd, 0x42, upper_byte(AVW));  //
    write_reg(fd, 0x42, lower_byte(VBP));  //
    write_reg(fd, 0x42, upper_byte(VBP));  //
    write_reg(fd, 0x42, lower_byte(VSW));  //
    write_reg(fd, 0x42, upper_byte(VSW));  //
    write_reg(fd, 0x42, lower_byte(src_v_front));  //
    write_reg(fd, 0x42, upper_byte(src_v_front));  //

    read_reg(fd, 0x30, &regval);
    if ((regval & 0xF0) == 0x50) {
        iscs20_chip = 1;
        // forward channel rate
        int fc_freq = 10800;// #bps
        float src_pclk_freq = 535.9;
        m_value_f = src_pclk_freq / 4.0 * (1 <<  n_value) / (fc_freq / 40.0);
        m_value = (uint16)round(m_value_f);
        CRITICAL_PRINT(MODULE_NAME, "CS2.0 chip:  Overwrite m_value = %d",  m_value);
    } else {

        CRITICAL_PRINT(MODULE_NAME, "use m_value = %d",  m_value);

    }

    // set m/n value for video processor 0
    write_reg(fd, 0x41, 0x23);
    write_reg(fd, 0x42, lower_byte(m_value));
    write_reg(fd, 0x42, upper_byte(m_value));
    write_reg(fd, 0x42, n_value);
    // main page: set number of video streams
    write_reg(fd, 0x43, 0x00);
    // Enable patgen
    // write_reg(fd,0x41,0x28);
    // write_reg(fd,0x42,0x95);
    // enable video processor 0
    write_reg(fd, 0x44, 0x01);
    // choose page 11, set auto-increment
    write_reg(fd, 0x40, 0x2E);
    // enable link layer 0, stream 0
    write_reg(fd, 0x41, 0x01);
    write_reg(fd, 0x42, 0x01);
    // assign 60 slots to each link layer stream
    write_reg(fd, 0x41, 0x06);
    write_reg(fd, 0x42, 0x3D);
    // enable link layer 0
    write_reg(fd, 0x41, 0x00);
    write_reg(fd, 0x42, 0x03);

    /*
    // GPIO5- VSYNC out, GPIO4-HSYNC out
    write_reg(fd, 0x40, 0x24);
    write_reg(fd, 0x41, 0xC0);
    write_reg(fd, 0x42, 0x80);
    write_reg(fd, 0x41, 0xC1);
    write_reg(fd, 0x42, 0x05);
    write_reg(fd, 0x41, 0xC2);
    write_reg(fd, 0x42, 0x01);
    */
    
    if (iscs20_chip == 0) {
        apb_write_reg(fd, 0, 0xA18, 0x05);
        apb_write_reg(fd, 0, 0xA18, 0x05);
        apb_write_reg(fd, 0, 0xA18, 0x05);
        apb_write_reg(fd, 0, 0xA28, 0x3E20);
    }

    return 0;
}

BridgeChip_StatusType link_set_983_flat(int32 fd, uint8 des_address, int32 mode)
{
    int32 err = EXIT_SUCCESS;
    uint8 regval;

    write_reg(fd, 0x01, 0x02);
    (void)usleep(10*1000);
    write_reg(fd, 0x5, 0x28);
    read_reg(fd, 0x05, &regval);
    CRITICAL_PRINT(MODULE_NAME, "FPDLINK MODE 0x%x", regval);
    err = config_regs(fd, ser_983_flat_1,
            sizeof(ser_983_flat_1)/sizeof(ser_983_flat_1[0]));
    if (err != EXIT_SUCCESS) {
        CRITICAL_PRINT(MODULE_NAME, "config ser_983_flat_1 failed\n");
        return BRIDGECHIP_STATUS_FAILED;
    }


    if(mode == 0)
    {
        (void)usleep(1000);
        write_reg(fd, 0x2D, 0x03);
        write_reg(fd, 0x6A, 0x4A);
        CRITICAL_PRINT(MODULE_NAME,
                "pooling the link status: SET 0x6A, 0x4A......");
        // for 983 CS2.0
        read_reg(fd, 0x30, &regval);
        if ((regval & 0xF0) == 0x50)
        {
            write_reg(fd, 0x6E, 0x80);
            CRITICAL_PRINT(MODULE_NAME, "CS2.0 chip:  set 0x6e=0x80 for 983 CS2.0");
        }
    }

    // SOFT RESET
    write_reg(fd, 0x01, 0x01);
    (void)usleep(5*1000);
    CRITICAL_PRINT(MODULE_NAME, "SET SLAVE_ID 0x%x\n", des_address);
    write_reg(fd, 0x70, des_address);// SLAVE_ID[0]
    write_reg(fd, 0x78, des_address);// SLAVE_ALIAS[0]
    write_reg(fd, 0x88, 0x00);// SLAVE_DEST[0]

    //  error = config_regs(fd, ser_983_flat_BC_settings,
    //  sizeof(ser_983_flat_BC_settings)/sizeof(ser_983_flat_BC_settings[0]));
    //  if (error != EXIT_SUCCESS) {
    //      CRITICAL_PRINT(MODULE_NAME, "config ser_983_flat_BC_settings failed\n");
    //      return error;
    //  }

    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0c, &regval);

    CRITICAL_PRINT(MODULE_NAME,
            "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x\n",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0c, &regval);
    CRITICAL_PRINT(MODULE_NAME,
            "Port1: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x\n",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));
    CRITICAL_PRINT(MODULE_NAME, "Enable I2C Passthrough\n");
    write_reg(fd, 0x2D, 0x01);
    write_reg(fd, 0x07,0x88);

    read_reg(fd, 0x08, &regval);
    CRITICAL_PRINT(MODULE_NAME, "DES_ID 0x%x", regval);


    ser_983_vp_config(fd);

    write_reg(fd, 0x71, 0x24);
    write_reg(fd, 0x79, 0x24);
    write_reg(fd, 0x72, 0x48);
    write_reg(fd, 0x7a, 0x48);
    //write_reg(fd, 0x17, 0x40);

    return BRIDGECHIP_STATUS_SUCCESS;
}

BridgeChip_StatusType get_983_vp_status(int32 fd)
{
    uint8 regval;
    read_reg(fd, 0x45, &regval);

    if ((regval & 0x01))
    {
        return BRIDGECHIP_STATUS_SUCCESS;
    }
    else
    {
        return BRIDGECHIP_STATUS_FAILED;
    }
}

BridgeChip_StatusType get_983_link_status(int32 fd)
{
    uint8 regval=0;
    int32 port0_link = 0;
    int32 port1_link = 0;

    write_reg(fd, 0x2D, 0x01);
    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) &&
       (((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 ) )
    port0_link = 1;

    DEBUG_PRINT(MODULE_NAME,
            "Port0: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x\n",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));

    regval=0;
    write_reg(fd, 0x2D, 0x12);
    read_reg(fd, 0x0c, &regval);

    if ( (((regval>>LINK_DETECT_BIT) & 0x01) == 1 ) &&
       (((regval>>RX_LOCK_DETECT_BIT) & 0x01) == 1 ) )
    port1_link = 1;

    DEBUG_PRINT(MODULE_NAME,
            "Port1: LINK_LOST_FLAG: 0x%x, BC_CRC_ERROR_FLAG:0x%x,LINK_DETECT:0x%x\n",
            (regval >>4)&0x01,(regval >>1)&0x01, (regval & 0x01));

    if ((port0_link == 1) && (port1_link == 1))
        return BRIDGECHIP_STATUS_SUCCESS;
    else
        return BRIDGECHIP_STATUS_FAILED;
}

void overwrite_984_apb_0x184(int32 fd)
{
    apb_write_reg(fd, 0, 0x180, 0x2620);
}

BridgeChip_StatusType link_set_984_flat(int32 fd)
{
    uint8 regval;

    //set address to 984 FIRST
    write_reg(fd, 0x40,0x2C);
    write_reg(fd, 0x0E,0x01);

    read_reg(fd, 0x00, &regval);
    DEBUG_PRINT(MODULE_NAME, "link_set_984_flat  read 0x00 : 0x%x\n", regval);
    if(regval != 0) {
        write_reg(fd, 0x0E,0x01);
        write_reg(fd, 0x01,0x02);
        (void)usleep(50*1000);
        CRITICAL_PRINT(MODULE_NAME, "Turn off daisy chain output\n");
        write_reg(fd, 0x40, 0x0C);
        write_reg(fd, 0x41, 0x1c);
        write_reg(fd, 0x42, 0x20);
        write_reg(fd, 0x41, 0x1b);
        write_reg(fd, 0x42, 0x00);
        write_reg(fd, 0x40, 0x0C);
        write_reg(fd, 0x41, 0x5C);
        write_reg(fd, 0x42, 0x20);
        write_reg(fd, 0x41, 0x5B);
        write_reg(fd, 0x42, 0x00);

        write_reg(fd, 0x01, 0x01);

        (void)usleep(50*1000);
        // Main Link Status Registers
        CRITICAL_PRINT(MODULE_NAME, "Main Link Status Registers:\n");
        write_reg(fd, 0x0E, 0x01);
        write_reg(fd, 0x05, 0xE0);
        write_reg(fd, 0x05, 0xC0);
        read_reg(fd, 0x53, &regval);
        (void)usleep(50*1000);
        read_reg(fd, 0x53, &regval);
        (void)usleep(50*1000);
        read_reg(fd, 0x53, &regval);
        CRITICAL_PRINT(MODULE_NAME,
                "Lock Status Port 0 (expect 0x01): 0x%x\n", regval);

        write_reg(fd,0x0E,0x12);
        write_reg(fd,0x05,0xE0);
        write_reg(fd,0x05,0xC0);
        read_reg(fd, 0x53, &regval);
        (void)usleep(50*1000);
        read_reg(fd, 0x53, &regval);
        (void)usleep(50*1000);
        read_reg(fd, 0x53, &regval);
        CRITICAL_PRINT(MODULE_NAME,
                "Lock Status Port 1 (expect 0x01): 0x%x\n", regval);
        write_reg(fd, 0x0E, 0x12);

        write_reg(fd, 0x46, 0x00);
        write_reg(fd, 0x0E, 0x01);
        write_reg(fd, 0x40, 0x50);
        write_reg(fd, 0x41, 0x32);
        write_reg(fd, 0x42, 0x02);

        CRITICAL_PRINT(MODULE_NAME, "Main-Link  RESET Applied\n");
        write_reg(fd, 0x01, 0x40);

        write_reg(fd, 0xD0, 0x0C);
        write_reg(fd, 0xD6, 0x00);
        if (dser_984_dp_display_config(fd, 0) == 0)
            return BRIDGECHIP_STATUS_SUCCESS;
    }

    return BRIDGECHIP_STATUS_FAILED;
}
#ifdef __cplusplus
}
#endif
