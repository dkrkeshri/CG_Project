#!/usr/bin/env bash
cd "$(dirname "$0")"

source test/utest/setenv_x86_64.sh

rm coverage.info
rm -rf Report

cd api/lib_tdaemon/utest
rm *.gc* UT_lib_tdeamon1 UT_lib_tdeamon2
make test

cd ../../public/utest
rm *.gc* UT_public_library_functions
make test

cd ../../../fidm_binder/fidm_binder_lib/utest
rm *.gc* UT_fidm_binder_library_functions
make test

cd ../../../display_susd_pm/utest
rm *.gc* display_susd_pm_unit_test
make test

cd ../../configuration-provider/libconfig-provider/utest
rm *.gc* UT_libconfig_provider__library_functions
make test

cd ../../providers/utest
rm *.gc* UT_provider_library_functions
make test

cd ../../../
./code_coverage.sh
#exit 0
cd configuration-provider/providers/utest
rm *.gc* UT_provider_library_functions
cd ../../libconfig-provider/utest
rm *.gc* UT_libconfig_provider__library_functions
cd ../../../display_susd_pm/utest
rm *.gc* display_susd_pm_unit_test
cd ../../fidm_binder/fidm_binder_lib/utest
rm *.gc* UT_fidm_binder_library_functions

cd ../../../api/public/utest
rm *.gc* UT_public_library_functions
cd ../../lib_tdaemon/utest
rm *.gc* UT_lib_tdeamon1 UT_lib_tdeamon2
rm temp_file.txt
cd ../../../
rm coverage.info



