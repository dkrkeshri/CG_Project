##########################################################
# Internal definitions.
# Do not touch unless strictly required
#
G_OPENWFD_SERVER_CONFIG="/etc/system/config/display/qcdisplaycfg.xml"
G_LOCAL_CONFIGS_DIR="configs/"
G_LOCAL_DS90UX9XX_DRV="ds90ux9xx-bash-drv/ds90ux9xx.sh"
G_BASH_DRIVER_CMD="${G_VIDEO_OUTPUTS_DIR}/${G_LOCAL_DS90UX9XX_DRV}"

FN_Find_Config_File()
{
	local l_file_name="${1}"

	local l_has_slash=$(echo "${l_file_name}" | grep '/' -q 2>&1 && echo "true")
	if [ "${l_has_slash}" == "true" ] ; then
		echo "${l_file_name}"
		return
	fi

	echo "${G_VIDEO_CONFIGS_DIR}/${l_file_name}"
}

FN_Get_OpenWFD_Config_Src()
{
	local l_has_slash=$(echo "${G_CUSTOM_OPENWFD_SERVER_CONFIG}" | grep '/' -q 2>&1 && echo "true")
	if [ "${l_has_slash}" == "true" ] ; then
		echo "${G_CUSTOM_OPENWFD_SERVER_CONFIG}"
		return
	fi

	echo "${G_VIDEO_OUTPUTS_DIR}/${G_LOCAL_CONFIGS_DIR}/${G_CUSTOM_OPENWFD_SERVER_CONFIG}"
}

FN_Show_StartupInfo()
{
	echo "[Video Output][INFO]: Video service XML:"
	echo "[Video Output][INFO]:     Source path:            ${G_CUSTOM_OPENWFD_SERVER_CONFIG_SRC}"
	echo "[Video Output][INFO]:     system path:            ${G_OPENWFD_SERVER_CONFIG}"
	echo " "

	if [ "${G_DISPLAY_1_EXISTS}" == "true" ] ; then
		echo "[Video Output][INFO]: Display 1:"
		echo "[Video Output][INFO]:     Type:             ${G_DISPLAY_1_TYPE}"
		echo "[Video Output][INFO]:     Panel driver:     ${G_DISPLAY_1_PANEL_DRIVER}"
		echo "[Video Output][INFO]:     Bridge driver:    ${G_DISPLAY_1_BRIDGE_DRIVER}"
		echo "[Video Output][INFO]:     OS Affinity:      ${G_DISPLAY_1_OS_AFFINITY}"
		echo "[Video Output][INFO]:  "
	fi

	if [ "${G_DISPLAY_2_EXISTS}" == "true" ] ; then
		echo "[Video Output][INFO]: Display 2:"
		echo "[Video Output][INFO]:     Type:             ${G_DISPLAY_2_TYPE}"
		echo "[Video Output][INFO]:     Panel driver:     ${G_DISPLAY_2_PANEL_DRIVER}"
		echo "[Video Output][INFO]:     Bridge driver:    ${G_DISPLAY_2_BRIDGE_DRIVER}"
		echo "[Video Output][INFO]:     OS Affinity:      ${G_DISPLAY_2_OS_AFFINITY}"
		echo "[Video Output][INFO]:  "
	fi
}

FN_Start_DS90UH983_Native_Driver()
{
	if [ "${G_DISPLAY_1_TYPE}" == "GM-HD1080" ] ; then
		local l_mode="FHD"
	elif [ "${G_DISPLAY_1_TYPE}" == "Bosch" ] ; then
		local l_mode="HD"
	fi

	echo "[Video Output][INFO]: Initializing DS90UB983 Serializer Link rate ${G_DISPLAY_1_DP_LINK_RATE} for ${l_mode}..."
	ds90uh983_initializer /dev/i2c5 0x0c "${l_mode}" "${G_DISPLAY_1_DP_LINK_RATE}" > /dev/null 2>&1
}

FN_Start_DS90UX9XX_Drivers()
{
	rm  /tmp/no-display-i2c-access > /dev/null 2>&1 || true

	if [ "${G_DISPLAY_1_BRIDGE_DRIVER}" == "DS90UH983-BASH" ] ; then
		FN_Start_DS90UH983_Native_Driver
	fi

	if [ "${G_USE_BRIDGE_CHIP_SERVER}" == "true" ] ; then
		echo "[Video Output][INFO]: Starting Bridgechip Server..."
		bridgechip_server 2>&1
	fi

	if [ ! -z "${G_DISPLAY_1_BASH_DRIVER_CFG}" ] ; then
		ksh "${G_BASH_DRIVER_CMD}" "${G_DISPLAY_1_BASH_DRIVER_CFG}" &
	fi

	if [ ! -z "${G_DISPLAY_2_BASH_DRIVER_CFG}" ] ; then
		ksh "${G_BASH_DRIVER_CMD}" "${G_DISPLAY_2_BASH_DRIVER_CFG}" &
	fi

}

FN_Get_BoardId()
{
	local boardid=$(read_board_info -e0)
	l_board_name="B1"

	echo $boardid | grep 03050*03 -q > /dev/null 2>&1 && l_board_name="A1"
	echo $boardid | grep 03050*04 -q > /dev/null 2>&1 && l_board_name="B1"
	echo $boardid | grep 03050*05 -q > /dev/null 2>&1 && l_board_name="B1"
	echo $boardid | grep 03050*41 -q > /dev/null 2>&1 && l_board_name="LowAPPs-A1"
	echo $boardid | grep 03050*42 -q > /dev/null 2>&1 && l_board_name="LowAPPs-B1"

	echo "${l_board_name}"
}

FN_Get_SelectedDisplay()
{
	if [ ! -z "${PREFERED_DISPLAY_ENV}" ] ; then
		echo "${PREFERED_DISPLAY_ENV}"
		return
	fi

	local l_board="$(FN_Get_BoardId)"

	l_display_selection_file="${G_VIDEO_OUTPUTS_DIR}/configs/default-displays.txt"
	if [ ! -f "${l_display_selection_file}" ] ; then
		echo ""
		return
	fi

	local l_display_env=$(cat "${l_display_selection_file}" | grep -e "^${l_board}:" | cut -d ':' -f 2)
	local l_display_env="${G_VIDEO_OUTPUTS_DIR}/configs/${l_display_env}"
	if [ ! -f "${l_display_env}" ] ; then
		echo ""
		return
	fi

	echo "${l_display_env}"
}

FN_Copy_Config()
{
	local l_source="$1"
	local l_target="$2"

	echo "[Video Output][INFO]: Copying ${l_source} to ${l_target}..."
	cp "${l_source}" "${l_target}"
}

FN_Prepare_ConfigFiles()
{
	echo "[Video Output][INFO]: Selecting OpenWFD server configuration..."
	cp "${G_CUSTOM_OPENWFD_SERVER_CONFIG_SRC}" "${G_OPENWFD_SERVER_CONFIG}"

	if [ -z "${G_CUSTOM_CONFIG_FILES}" ] ; then
		return
	fi

	echo "[Video output][INFO]: Preparing other configuration files..."

	export IFS=";"
	for l_copy_spec in $G_CUSTOM_CONFIG_FILES; do

		if [ -z "${l_copy_spec}" ] ; then
			continue
		fi

		local l_target=$(echo ${l_copy_spec} | cut -d '=' -f 1 | sed 's/[ \t]*//g')
		local l_source=$(echo ${l_copy_spec} | cut -d '=' -f 2 | sed 's/[ \t]*//g')
		local l_source=$(FN_Find_Config_File "${l_source}")

		FN_Copy_Config "${l_source}" "${l_target}"

	done
}

FN_Set_Gpio()
{
	local l_gpio_params="${1}"

	local l_gpio_index=$(echo ${l_gpio_params} | cut -d '=' -f 1 | sed 's/[ \t]*//g')
	local l_gpio_value=$(echo ${l_gpio_params} | cut -d '=' -f 2 | sed 's/[ \t]*//g')

	tlmm_gpio_set_config "${l_gpio_index}"
        echo "${l_gpio_value}" > /dev/gpio/tlmm/${l_gpio_index}/value
}

FN_Enable_Serializers()
{
	if [ ! -z "${G_DISPLAY_1_GPIO_EN}" ] ; then
		echo "[Video Output][INFO]: Enabling serializer for Display 1..."
		FN_Set_Gpio "${G_DISPLAY_1_GPIO_EN}"
	fi

	if [ ! -z "${G_DISPLAY_2_GPIO_EN}" ] ; then
		echo "[Video Output][INFO]: Enabling serializer for Display 2..."
		FN_Set_Gpio "${G_DISPLAY_2_GPIO_EN}"
	fi
}

FN_Activate_VideoOutput()
{
	local l_display_env="${1}"
	. ${l_display_env}
	local l_board="$(FN_Get_BoardId)"

	l_display_config="$(FN_Get_OpenWFD_Config_Src)"
	G_CUSTOM_OPENWFD_SERVER_CONFIG_SRC=${l_display_config}

	echo "[Video Output][INFO]: Preparing displays for GM-VCU ${G_BOARD}..."
	echo "[Video Output][INFO]:  "

	FN_Show_StartupInfo

	FN_Prepare_ConfigFiles

	if [ "${l_board}" == "LowAPPs-A1" ] || [ "${l_board}" == "LowAPPs-B1" ] ; then
		FN_Enable_Serializers
	fi

	echo "[Video Output][INFO]: Starting DS90UX9XX drivers..."
	FN_Start_DS90UX9XX_Drivers
	
	echo "[Video Output][INFO]: Starting OpenWFD Server..."
	openwfd_server
	kgsl &
	waitfor /dev/kgsl-3D
	waitfor /dev/openwfd_server

	if [ "${G_DISPLAY_1_BRIDGE_DRIVER}" == "DS90UH983-BASH" ] ; then
		echo "[Video Output][INFO]: Starting to commit DP mode..."
		ds90uh983_initializer /dev/i2c5 0x0c HD "${G_DISPLAY_1_DP_LINK_RATE}" r
	fi
	echo " "
}

FN_enable_by_default_i2c()
{
	sed -i "/#DSI I2C and interrupt/ {n;s/^#*//g;n;s/^#*//g;n;s/^#*//g}" $1
	sed -i "/#DP I2C and interrupt/ {n;s/^#*//g;n;s/^#*//g;n;s/^#*//g}" $1
}

FN_Stop_Local_I2C_Activities()
{
	local l_display_env="${1}"
	. ${l_display_env}

	local l_board_config
	local l_board="$(FN_Get_BoardId)"

	if [ "${l_board}" == "LowAPPs-A1" ] || [ "${l_board}" == "LowAPPs-B1" ] ; then
		l_board_config="linux-la-lowappsA1B1.config"
	else
		l_board_config="linux-la-mid${l_board}.config"
	fi

	local l_board_conf_path="/vm/images"

	local l_config="${l_board_conf_path}/${l_board_config}"

	FN_enable_by_default_i2c $l_config

	if [ ! -z "${G_DISPLAY_1_USES_SHARED_I2C}" -o "${G_DISPLAY_2_USES_SHARED_I2C}" ] ; then
		echo "[Video Output][INFO]: Releasing shared I2C buses..."
		sleep 5
		touch /tmp/no-display-i2c-access
	fi

	if [ -z "${G_DISPLAY_1_USES_SHARED_I2C}" ]; then
		echo "DP I2C is NOT shared"
		sed -i "/#DP I2C and interrupt/,+3s/^#*/#/g" ${l_config}
		# sleep for 5s even if there is no I2C sharing between host and gvm
	        # this is a workaround to fix BT audio issue.
		# delay in android startup is required to fix the issue.
		sleep 5
	fi


	if [ -z "${G_DISPLAY_2_USES_SHARED_I2C}" ]; then
		echo "DSI I2C is NOT shared"
		sed -i "/#DSI I2C and interrupt/,+3s/^#*/#/g" ${l_config}
	fi
}

