# !/bin/ksh

SELECT_CONF_FILE="/scripts/video-outputs/select.conf"
G_DISPLAY_CFG_ADDRESS=400

G_ENV_FIELD_INDEX=4
DFL_BOARD_NAME="Bosch_GM_VCU_MID_B1"

DEFAULT_CFG="0"

CALIBRATION_FILE_PATH="/data/calibration/overrides/DISPLAY_CONFIGURATION_MAPPING.override"
GM_CALIBRATION_PREFIX="DISPLAY_CONFIGURATION_MAPPING"

### Args ###
option=${1}
requested_preset=${2}

### Element getter ###
PRESET_TYPE_POS=1
PRESET_ID_POS=2
UUID_POS=3
BOARD_NAME_POS=4
DESCRIPTION_POS=5

### Bitmasks ###
developer_shift=$((8*3))
developer_mask=$((0xFF << $developer_shift))
secondary_shift=$((8))
secondary_mask=$((0xFF << $secondary_shift))
primary_shift=$((0))
primary_mask=$((0xFF << $primary_shift))


get_element()
{
	local line=$1
	local pos=$2
	element=$(echo -n $line | cut -d ';' -f $pos | sed  's/\n//g')
}

parse_line()
{
	line=${1}
	get_element "$line" $PRESET_TYPE_POS; l_preset_type=$element
	get_element "$line" $PRESET_ID_POS; l_preset_id=$element
	get_element "$line" $UUID_POS; l_preset_uuid=$element
	get_element "$line" $BOARD_NAME_POS; l_board_names=$element
	get_element "$line" $DESCRIPTION_POS; l_description=$element
}

print_preset_info_by_line()
{
	line=${1}
	parse_line "$line"
	echo -e "\tPreset type: $l_preset_type"
	echo -e "\tPreset Id: $l_preset_id"
	echo -e "\tPreset uuid: $l_preset_uuid"
	echo -e "\tDescription: $l_description"
	echo -e "\tSupported bards: $l_board_names"
	echo ""
}

to_calibration_data_dec()
{
	preset_type=${1}
	preset_id=${2}

	if [ $preset_type == "production" ] || [ $preset_type == "recovery" ] ; then
		primary=`echo "$preset_id" | awk -F ":" '{print $1}'`
		secondary=`echo "$preset_id" | awk -F ":" '{print $2}'`
		developer="0"
	elif [ $preset_type == "developer" ]; then
		primary="0"
		secondary="0"
		developer=`echo "$preset_id" | awk -F ":" '{print $1}'`
	else
		echo "Preset type $preset_type is not supported"
		exit
	fi

	dec_calib_data=$((($developer << $developer_shift) | \
	                  ($secondary << $secondary_shift) | \
	                  ($primary << $primary_shift)))

	echo $dec_calib_data
}

FN_Get_BoardId()
{
	local boardid=$(read_board_info -e0)
	current_board_name="Bosch_GM_VCU_MID_B1"

	echo $boardid | grep 03050*03 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_A1"
	echo $boardid | grep 03050*04 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_MID_B1"
	echo $boardid | grep 03050*05 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_MID_B2"
	echo $boardid | grep 03050*05 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_MID_B3"
	echo $boardid | grep 03050*06 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_MID_C1"
	echo $boardid | grep 03050*41 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_LOW_A1"
	echo $boardid | grep 03050*42 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_LOW_B1"
	echo $boardid | grep 03050*51 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_HIGH_A1"
	echo $boardid | grep 03050*52 -q > /dev/null 2>&1 && current_board_name="Bosch_GM_VCU_HIGH_C1"

	echo "${current_board_name}"
}

FN_Analyze_Calibration_Data()
{
	calibration_data=${1}

	raw_developer=$((($calibration_data & $developer_mask) >> $developer_shift))
	raw_secondary=$((($calibration_data & $secondary_mask) >> $secondary_shift))
	raw_primary=$((($calibration_data & $primary_mask) >> $primary_shift))

	developer=`echo $raw_developer | awk '{printf("%03d\n", $1)}'`
	secondary=`echo $raw_secondary | awk '{printf("%03d\n", $1)}'`
	primary=`echo $raw_primary | awk '{printf("%03d\n", $1)}'`

	echo "Found such preset id:"
	echo -e "\t developer: $developer"
	echo -e "\t production/recovery: $primary:$secondary"
}

FN_Select_Display()
{
	local requested_preset=${1}

	if [[ "$requested_preset" == *"-"* ]] ; then
		echo "Searching preset by UUID: $requested_preset"
		CRITERIA_POS=$UUID_POS
	else
		echo "Searching preset by calibration data: $requested_preset"
		CRITERIA_POS=$PRESET_ID_POS
	fi

	while read line; do
		get_element "$line" $BOARD_NAME_POS; board_names=$element
		get_element "$line" $PRESET_TYPE_POS; preset_type=$element
		get_element "$line" $CRITERIA_POS; candidate=$element

		for l_board_name in $board_names; do
			if [ "$l_board_name" != "$G_BOARD_NAME" ] ||
			   [ "$candidate" != "$requested_preset" ] ||
			   [ "$preset_type" == "pv" ]; then
				continue
			fi

			if [ $CRITERIA_POS == $UUID_POS ]; then
				echo "Getting calibration data for preset with uuid: $candidate"
				get_element "$line" $PRESET_ID_POS; candidate=$element
			fi

			echo "Found apropriate preset. Applying preset:"
			print_preset_info_by_line "$line"

			calibration_data=`to_calibration_data_dec $preset_type $candidate`
			echo "$GM_CALIBRATION_PREFIX:$calibration_data" > "$CALIBRATION_FILE_PATH"
			sync
			echo "Done"
			exit 0
		done
	done < $SELECT_CONF_FILE

	echo "No preset found by: $requested_preset"
	exit 1

}

FN_List_Matching_Configs()
{
	option_number=0
	while read line; do
		get_element "$line" $BOARD_NAME_POS; board_names=$element
		get_element "$line" $PRESET_TYPE_POS; preset_type=$element
		for l_board_name in $board_names; do
			if [ $l_board_name != $G_BOARD_NAME ] ||
			   [ "$preset_type" == "pv" ]; then
				continue
			fi

			option_number=$((option_number + 1))
			echo -e "OPTION $option_number"
			print_preset_info_by_line "$line"
		done
	done < $SELECT_CONF_FILE
}

G_BOARD_NAME="$(FN_Get_BoardId)"

if [ "$option" == "-r" ] ; then
	echo "$GM_CALIBRATION_PREFIX:$DEFAULT_CFG" > "$CALIBRATION_FILE_PATH"
	sync

	result=`cat $CALIBRATION_FILE_PATH`
	if [ "$result" == "$GM_CALIBRATION_PREFIX:$DEFAULT_CFG" ] ; then
		echo "Reset was successful"
	else
		echo "Reset FAILED"
	fi

	exit 0
fi

if [ "$option" == "-l" ] ; then
	FN_List_Matching_Configs
	exit 0
fi

if [ "$option" == "-s" ] ; then
	if [ -z "$requested_preset" ] ; then
		echo "Error: No display preset given" 1>&2
		exit 1
	fi

	FN_Select_Display $requested_preset

	#code should not reach here
	exit 1
fi

if [ "$option" == "-c" ] ; then
	raw_data=`cat $CALIBRATION_FILE_PATH`

	if [ -z $raw_data ]; then
		echo "Display config corrupted! Could not find valid data"
		exit 1
	fi

	calib_data=`echo "$raw_data" | awk -F ":" '{print $2}'`
	echo -e "Trying to find active calibration data\n"
	FN_Analyze_Calibration_Data $calib_data
	exit 0
fi

FN_Show_Select_Help()
{
	echo "select.sh - Select or examine current display configuration"
	echo ""
	echo "  Examine available displays:"
	echo "    -l"
	echo "       list displays available for the current board"
	echo ""
	echo "  Selecting a display configuration:"
	echo "    -s <UUID>"
	echo "       select a display configurationfor the next boot using env file"
	echo ""
	echo "    -s <PRESET ID>"
	echo "       select a display configurationfor the next boot using preset id"
	echo ""
	echo "    -r"
	echo "       reset display to the board-defaults"
	echo ""
	echo "    -c"
	echo "       show current display settings"
	echo ""
	echo "  Examples:"
	echo "    Listing displays:"
	echo "        # /scripts/video-outputs/select.sh -l"
	echo "        OPTION 1"
	echo "            Preset type: production"
	echo "            Preset Id: 013:000"
	echo "            Preset uuid: c2af42d8-b8c7-11eb-97aa-9b8bb3105d47"
	echo "            Description: Topology: 13"
	echo "            Supported bards: Bosch_GM_VCU_MID_B1 Bosch_GM_VCU_MID_B2"
	echo "        #"
	echo ""
	echo "    Reset to defaults:"
	echo "        # /scripts/video-outputs/select.sh -r             "
	echo "         Reset was successful"
	echo "        # "
	echo ""
	echo "    Show current:"
	echo "        # /scripts/video-outputs/select.sh -c "
	echo "        Found such calibration data:"
	echo "        	 developer: 000"
	echo "        	 production/recovery: 200:001"
	echo "        # "
	echo ""
	echo "    Select new:"
	echo "        # /scripts/video-outputs/select.sh -s 255"
	echo "        Searching preset by calibration data: 255"
	echo "        Found apropriate preset. Applying preset:"
	echo "        	Preset type: developer"
	echo "        	Preset Id: 255"
	echo "        	Preset uuid: c2af42d8-b8c7-11eb-97aa-9b8bb3105d47"
	echo "        	Description: FPD4 PV Bist topology"
	echo "        	Supported bards: Bosch_GM_VCU_MID_B1 Bosch_GM_VCU_MID_B2"
	echo "        "
	echo "        Done"
	echo "        # "
	echo "        "
	echo "        OR "
	echo "        "
	echo "        # /scripts/video-outputs/select.sh -s 67bb2ab2-ce08-11eb-ac6f-afe86705cd61"
	echo "        Searching preset by UUID: c2af42d8-b8c7-11eb-97aa-9b8bb3105d47"
	echo "        Getting calibration data for preset with uuid: c2af42d8-b8c7-11eb-97aa-9b8bb3105d47"
	echo "        Found apropriate preset. Applying preset:"
	echo "        	Preset type: developer"
	echo "        	Preset Id: 255"
	echo "        	Preset uuid: c2af42d8-b8c7-11eb-97aa-9b8bb3105d47"
	echo "        	Description: FPD4 PV Bist topology"
	echo "        	Supported bards: Bosch_GM_VCU_MID_B1 Bosch_GM_VCU_MID_B2"
	echo ""
	echo "        Done"
	echo "        # "
}

if [ "${1}" == "-h" ] ; then
	FN_Show_Select_Help
	exit 0
fi

echo "No options given"
FN_Show_Select_Help

exit 0
