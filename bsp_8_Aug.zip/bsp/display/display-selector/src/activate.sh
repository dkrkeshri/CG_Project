# !/bin/ksh


###############################################################
# First decide where the script is running and locate common.sh
G_DEFAULT_QNX_VIDEO_OUTPUTS_DIR='/scripts/video-outputs/'
if [ -z "${VIDEO_OUTPUTS_DIR}" ] ; then
	G_UNAME=$(uname)
	if [ "${G_UNAME}" == "Linux" ] ; then
		G_VIDEO_OUTPUTS_DIR="$(pwd)"
	else
		G_VIDEO_OUTPUTS_DIR="${G_DEFAULT_QNX_VIDEO_OUTPUTS_DIR}"
	fi
else
	G_VIDEO_OUTPUTS_DIR="${VIDEO_OUTPUTS_DIR}"
fi

if [ -z "${VIDEO_CONFIGS_DIR}" ] ; then
	G_VIDEO_CONFIGS_DIR="${G_VIDEO_OUTPUTS_DIR}/configs"
else
	G_VIDEO_CONFIGS_DIR="${VIDEO_CONFIGS_DIR}"
fi

###############################################################
# Check for common.sh and source it
G_COMMON_SCRIPT="${G_VIDEO_OUTPUTS_DIR}/common.sh"
if [ ! -e ${G_COMMON_SCRIPT} ] ; then
	echo "[Video Output][ERROR]: common.sh script not found at ${G_COMMON_SCRIPT}"
	echo "[Video Output][ERROR]: Current VIDEO_OUTPUTS_DIR is <${G_VIDEO_OUTPUTS_DIR}>"
	echo "[Video Output][ERROR]: No displays are activated"
fi
. "${G_COMMON_SCRIPT}"


##############################################################
# Ensure some display(s) are selected
G_SELECTED_DISPLAY_ENV=$(FN_Get_SelectedDisplay)

if [ -z "${G_SELECTED_DISPLAY_ENV}" ] ; then
	echo "[Video Output][WARNING]: No displays are selected"
	echo "[Video Output][WARNING]: To list available options run ${G_VIDEO_OUTPUTS_DIR}/select.sh -l"
	echo "[Video Output][WARNING]: To select displays run ${G_VIDEO_OUTPUTS_DIR}/select.sh -s <display-set>"
	exit 0
fi

if [ -z "${1}" -o "${1}" == "--activate-all" ] ; then
	# Activate the selected display(s)
	FN_Activate_VideoOutput "${G_SELECTED_DISPLAY_ENV}"
	exit 0
fi

if [ "${1}" == "--release-shared-i2c-buses" ] ; then
	FN_Stop_Local_I2C_Activities "${G_SELECTED_DISPLAY_ENV}"
	exit 0
fi

