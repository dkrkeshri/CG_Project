#pragma once

/**
 * This file (h/cpp file) contains the main part of the wakeup-daemon.
 * It has the functions that communicate the INC and perform the wakeup
 * function. It is called from the command_proc code.
 * The command-proc calls a mutex to protect this code from
 * double asychronous calls. But it might be called from different 
 * threads!
 *
 */

#include <string>
#include <vector>

enum PwrState
{
	PWR_OFF = 0,
	PWR_ON = 1,
	PWR_UNKNOWN = 2
};

class WakeupChain
{
public:
	std::string name;
	unsigned short id;
	PwrState on;
};

extern std::vector<WakeupChain*> chains;


int switch_to_online(std::string *out_errtxt);
void switch_to_offline();

int wakeup_init(std::string *out_errtxt);
void wakeup_uninit();
bool wakeup_bIsOnline();
int wakeup_set_option(const char *option_name,const char *value,std::string *out_errtxt);
int wakeup_get_option(const char *option_name,std::string *out_value,std::string *out_errtxt);

int wakeup_set_powerstate(WakeupChain *chn,bool on,std::string *out_errtxt);

bool wakeup_get_info(int num,const char **out_name,unsigned short *out_id,bool *out_state_on);

