/**
 * @file       logger.c
 * @brief      slog logger wrapper
 *
 * @author     Vasyl Khursa <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#include <sys/slog2.h>

#define SLOG_NUMBER_PAGES   8

/* log macros */
slog2_buffer_t buffer_handle = NULL;
/* log buffer */
slog2_buffer_set_config_t buffer_config;

extern char *__progname;

int slogger_init(void)
{
    int rc = 0;

    buffer_config.buffer_set_name = __progname;
    buffer_config.num_buffers = 1;
    buffer_config.verbosity_level = SLOG2_INFO;
    buffer_config.buffer_config[0].buffer_name = "wakeup_daemon_logging";
    buffer_config.buffer_config[0].num_pages = SLOG_NUMBER_PAGES;

    rc = slog2_register(&buffer_config, &buffer_handle, 0);
    if (-1 == rc) {
        return rc;
    }

    return 0;
}
