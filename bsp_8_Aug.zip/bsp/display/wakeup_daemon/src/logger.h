/**
 * @file       logger.h
 * @brief      slog logger wrapper
 *
 * @author     Vasyl Khursa <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __LOGGER_H__
#define __LOGGER_H__

#include <sys/slog2.h>

#define LOG_INFO(format, ...)                                                   \
    LOG_WAKEUP_DAEMON(SLOG2_INFO, format, ##__VA_ARGS__)
#define LOG_WARNING(format, ...)                                                   \
    LOG_WAKEUP_DAEMON(SLOG2_WARNING, format, ##__VA_ARGS__)
#define LOG_ERR(format, ...)                                                    \
    LOG_WAKEUP_DAEMON(SLOG2_ERROR, format, ##__VA_ARGS__)
#define LOG_DBG(format, ...)                                                    \
    LOG_WAKEUP_DAEMON(SLOG2_DEBUG1, format, ##__VA_ARGS__)

#define LOG_WAKEUP_DAEMON(level, format, ...)                                 \
    slog2f(buffer_handle, 0, level, "%s: " format, __func__, ##__VA_ARGS__)

extern slog2_buffer_t buffer_handle;

int slogger_init(void);

#endif /* __LOGGER_H__ */
