#include "resmgr_wkup.h"
#include "daemon.h"
#include "logger.h"
#include "wakeup_ctl.h"


ResMgrWKup::ResMgrWKup(const char *path,bool is_control)
 : ResMgrBase(path,"type_wakeup_daemon")
{
}

ResMgrWKup::~ResMgrWKup()
{
}

bool ResMgrWKup::start(std::string *out_err,ResManagerDispatchloop *dispatcher)
{
	LOG_WAKEUP_DAEMON(SLOG2_INFO,"ResMgrWKup %s ...\n", __func__);
	if(!ResMgrBase::start(out_err,dispatcher))
	{
		LOG_WAKEUP_DAEMON(SLOG2_ERROR,"%s failed!", __func__);
		return false;
	}

	return true;
}

void ResMgrWKup::stop()
{
	LOG_WAKEUP_DAEMON(SLOG2_INFO,"ResMgrWKup %s ...\n", __func__);
	ResMgrBase::stop();
}

bool ResMgrWKup::process_command(const char *command)
{
	char cmdword[16];
	const char *cmdarg;
	int i;

	// skip leading whitespace
	while( *command==' ' || *command=='\t' )command++;

	// copy command-word
	for(i=0;i+1<(int)sizeof(cmdword);i++)
	{
		char b = command[i];
		if(b==0||b==' '||b=='\t'||b=='\n'||b=='\r')
			break;
		cmdword[i]=b;
	}
	cmdword[i]=0;
	cmdarg = command+i;
	// skip whitespace
	while( *cmdarg==' ' || *cmdarg=='\t' )cmdarg++;

	// check command.
	if(!strcmp(cmdword,"list"))
	{
		process_command_list(cmdarg);
	}else if(!strcmp(cmdword,"ctrl"))
	{
		process_command_ctrl(cmdarg);
	}else if(!strcmp(cmdword,"version"))
	{
		process_command_version(cmdarg);
#if RESMGR_GLOBAL_STATE
		printrep("(warning: DEBUGmode. global state enabled!)\n");
#endif
	}else if(!strcmp(cmdword,"status"))
	{
		process_command_status(cmdarg);
	}else if(!strcmp(cmdword,"statusget"))
	{
		process_command_status(cmdarg);
	}else if(!strcmp(cmdword,"quit"))
	{
		process_command_quit(cmdarg);
	}else{
		// unknown command.
		printrep("%d\nunknown command '%s'\n",(int)EINVAL,cmdword);
	}

	return true;
}

void ResMgrWKup::process_command_list(const char *command)
{
	printrep("0\n");
	// list names of all fidms to output.
	for( int i=0 ;; i++ )
	{
		const char *name;
		unsigned short id;
		bool is_on;
		if(!wakeup_get_info(i,&name,&id,&is_on))
			break;
		printrep("%d %s %s\n",i,name,(is_on?"on":"off"));
	}
}

void ResMgrWKup::process_command_ctrl(const char *command)
{
	/* control command. first arg is the name (no quotes, no space),
	 * the second arg is the data value, quoted */
	const char *c;
	int ret;
	std::string err;
	std::string ctrl,value;

	c = command;
	// get control keyword
	ret = get_quot_string(&c,&ctrl);
	if(ret)
	{
		printrep("%d\nctrl command needs a properly quoted 'command' argument.\n",ret);
		return;
	}

	// get value keyword
	ret = get_quot_string(&c,&value);
	if(ret)
	{
		printrep("%d\nctrl command needs a properly quoted value argument.\n",ret);
		return;
	}

	// pass to wakeup_ctl
	ret = wakeup_set_option(ctrl.c_str(),value.c_str(),&err);

	if(ret==0)
	{
		printrep("0\n");
	}else{
		printrep("%d\nset_option failed:  %s\n",(int)ret,err.c_str());
	}
}

void ResMgrWKup::process_command_status(const char *command)
{
	/* status. Argument is the value to query.
	 * Currently, only 'online' is supported. */
	const char *c;
	int ret;
	std::string err;

	/* get quoted argument */
	std::string value;
	c = command;
	ret = get_quot_string(&c,&value);
	if(ret)
	{
		printrep("%d\nstatus command needs a properly quoted value argument.\n",ret);
		return;
	}

	// check which keyword.
	// check 'online'.
	if(!strcmp(value.c_str(),"online"))
	{
		const char *sta="off";
		if(wakeup_bIsOnline())
			sta = "on";
		printrep("0\n%s\n",sta);
		return;
	}

	if( !strncmp(value.c_str(),"list",4) )
	{
		std::vector<class WakeupChain*>::const_iterator it;

		printrep("0\n");
		for( it=chains.begin() ; it!=chains.end() ; ++it )
		{
			const char *n = (*it)->name.c_str();
			printrep("%s\n",n);
		}
		return;
	}

	// is it the name of one of the wakeup-chains?
	for( std::vector<WakeupChain*>::const_iterator it=chains.begin() ; it!=chains.end() ; ++it )
	{
		const WakeupChain *wc = *it;
		const char *n = wc->name.c_str();
		if(!strcmp(n,value.c_str()))
		{
			// match. Return this item's online status (as far as we know)
			if(wc->on)
				printrep("0\non\n");
			else
				printrep("0\noff\n");
			return;
		}
	}

	// invalid.
	printrep("%d\nUnknown status query '%s'\n",(int)EINVAL,value.c_str());
}

void ResMgrWKup::process_command_version(const char *command)
{
	printrep("0\n%s\n",WAKEUP_DAEMON_VERSION);

}

void ResMgrWKup::process_command_quit(const char *command)
{
	if(!allow_commandQuit)
	{
		printrep("%d\nQuit command forbidden through config.\n",EPERM);
		return;
	}
	printrep("0\n"); // the client will not be able to pick this up in time...
	LOG_WAKEUP_DAEMON(SLOG2_INFO,"client command 'quit' received.\n");
	(void)raise(SIGINT);
}
