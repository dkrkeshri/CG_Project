#pragma once
#include <vector>
#include <string>
#include "txt_resmgr_base.h"


class ConfData
{
public:
	int blah;
	std::string logfile;
	bool use_slog2;
	unsigned char debuglevel;
	bool allow_quit;
	std::string control_path;
	std::string status_path;
	int inc_channel_id;

	class WkupChain
	{
	public:
		std::string name;
		int vip_chain_id;	// value to be used in the INC message.
	};

	std::vector<WkupChain> chaindata;


	static ConfData *load_config(const char *filename,errPrintfFunc errfunc);
	void debug_print_data(void);
	bool get_item(const char *itemname,std::string *out_result,const char *defaultvalue);
	bool get_item(const char *itemname,char *out_result,int result_buffersize,const char *defaultvalue);

private:
	ConfData();
	bool extract_data_from_json(class JSDataNodeObject *js,std::string *out_err);
	bool extract_wakeupchain_from_json(class JSDataNodeObject *js,std::string *out_err,WkupChain *out_inhere);

	bool get_inc_config(class JSDataNodeObject *js,std::string *out_err);

};



