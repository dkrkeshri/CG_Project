#pragma once
#include "txt_resmgr_base.h"


class ResMgrWKup : public ResMgrBase
{
public:
	ResMgrWKup(const char *path,bool is_control);
	virtual ~ResMgrWKup();

	virtual bool start(std::string *out_err,ResManagerDispatchloop *dispatcher);
	virtual void stop();

protected:
	virtual bool process_command(const char *command);


private:
	void process_command_list(const char *command);
	void process_command_ctrl(const char *command);
	void process_command_status(const char *command);
	void process_command_version(const char *command);
	void process_command_quit(const char *command);

};


