//#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/procmgr.h>
#include "logger.h"
#include "daemon.h"
#include "logoutput.h"
#include "resmgr_wkup.h"
#include "configfile_data.h"
#include "wakeup_ctl.h"


#define TMPSTR_SIZE 128

extern "C" {
static void sigINTHandler(int dummy);
static void sigUSR1Handler(int dummy);

static volatile char run;
}

ResMgrWKup *qnx_res_manager_c = 0;
ResMgrWKup *qnx_res_manager_s = 0;
ResManagerDispatchloop *qnx_dispatcher = 0;


class ConfData *config;


int main(int numargs,char *const* args)
{
	int ret;
	int opt;
	int retcode;
	bool slog2_reg_status = false;
	char tempstr[TMPSTR_SIZE];
	std::string err;
	std::string logfilename;
	std::vector<std::string> config_json_filelist;

	const char *configFile;

	qnx_res_manager_c = 0;
	qnx_res_manager_s = 0;
	qnx_dispatcher = 0;
	retcode = 0;
	logfile = new LogOutput(DAEMON_PROGNAME);
	// parse args
	bNoDaemonize = false;
	debuglevel = 0;
	allow_commandQuit = 1;
	configFile = NULL;
	config = 0;

	while((opt=getopt(numargs,args,"dvc:h"))!=-1)
	{
		switch(opt)
		{
		case 'c':
			configFile = optarg;
			break;
		case 'd':
			bNoDaemonize = true;
			debuglevel += 1;
			break;
		case 'v':
			debuglevel += 1;
			break;
		case 'h':
			printf("valid options:\n");
			printf(" -c <filename>     Specify config file.\n");
			printf(" -d                Do not daemonize, add debuglevel\n");
			printf(" -v                add debuglevel\n");
			printf(" -h                show list of options.\n");
			goto leave;
		default:
			retcode = 1; // not need for errormessage, was already printed by getopt().
			printf("for list of valid options, use '-h'.\n");
			goto leave;
		}
	}

	if (slogger_init()) {
	    slog2_reg_status = false;
	    fprintf(stderr, "slogger_init failed! slog can't be printed from now on!");
	} else {
	    slog2_reg_status = true;
	}

	if(!configFile)
	{
		fprintf(stderr,"need to have a configfile to start the daemon. Use option -c .\n");
		retcode=1;
		goto leave;
	}

	LOG_WAKEUP_DAEMON(SLOG2_INFO, "loading wakeup_daemon config file!\n");
	// load and parse config file (Do this before daemonizing).
	// cannot log yet, so report errors on stderr (path of logfile is in configfile)
	config = ConfData::load_config(configFile,err_to_stderr);
	if(!config)
	{
		retcode=1;
		goto leave;
	}

	// get some items from config
	if(config->logfile.size()<=0)
	{
		printf("no logfile specified. Not generating any outputs in daemonized mode. Use 'logfile' in config file.\n");
		logfilename = "";
	}else
		logfilename = config->logfile;

	if(logfilename.size()>0)
	{
		// If opening the log fails after daemonizing, we cannot report the problem.
		// So try it here temporarily.
		bool log_can_open;
		log_can_open = logfile->init(logfilename.c_str(),false);
		if(!log_can_open)
		{
			// if not opened, logfile will redirect to stderr. So we can still use it here.
			logfile->printf("Cannot create or open the logfile '%s'. errno = %d.\n",logfilename.c_str(),(int)errno);
			goto leave;
		}
		// But do not hold a filehandle while daemonizing, so just open briefly for testing.
		logfile->uninit();
	}

	if( config->debuglevel > debuglevel )
		debuglevel = config->debuglevel;

	if(!bNoDaemonize)
	{
		// daemonize. QNX has a helper function here, so not doing
		// the regular fork-setsid-close-fork as in linux.
		ret = procmgr_daemon(0, (PROCMGR_DAEMON_NOCHDIR | PROCMGR_DAEMON_NODEVNULL));
		if (-1 == ret) {
			LOG_WAKEUP_DAEMON(SLOG2_ERROR, "Failed to daemonize. Error: %s\n", strerror(errno));
			retcode = 2;
			goto leave;
		}

		LOG_WAKEUP_DAEMON(SLOG2_INFO,"Daemonized\n");
	}

	signal(SIGINT,sigINTHandler);
	signal(SIGUSR1,sigUSR1Handler);

	// Now really open the logfile.
	if(logfilename.size()>0)
	{
		if(!logfile->init( logfilename.c_str() , config->use_slog2 ))
		{
			// Oops. Cannot report this error. stderr is closed, and the logfile failed to open the second time ...
			// The only way to safely prevent this is using a valid logfile name which will not fail
			// opening after a brief open/close. Or hoping slogger2 never fails.
			logfile->printf("failed to init logging.");  // maybe stderr does go somewhere?
			retcode = 1;
			goto leave;
		}
	}

	// show name and version.
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "wakeup-daemon version '%s'\n",WAKEUP_DAEMON_VERSION);

#if RESMGR_GLOBAL_STATE
	LOG_WAKEUP_DAEMON(SLOG2_WARNING, "(warning: DEBUGmode. global state enabled!)\n");
#endif

	// Debug print the config.
	if(debuglevel>0)
	{
		LOG_WAKEUP_DAEMON(SLOG2_INFO, "configuration file data:\n");
		config->debug_print_data();
	}

	// Pick up our items from the config.

	// switch if 'quit' command is forbidden.
	config->get_item("forbid_cmd_quit",tempstr,sizeof(tempstr),"0");
	if(atoi(tempstr)>0)
		allow_commandQuit=0;


//	// Check for unused items in config (normally typos). Will be sent as warnings to the log.
// ..... 	conffile_check_all_queried(config,check_unused_cb,tempstr);


	// init the wakeup-part
	ret = wakeup_init(&err);
	if(ret)
	{
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "Error initializing wakeup: %s\n",err.c_str());
		retcode = 2;
		goto leave;
	}

	// create the qnx dispatcher
	qnx_dispatcher = new ResManagerDispatchloop();

	LOG_WAKEUP_DAEMON(SLOG2_INFO, "creating wakeup_daemon control node %s:\n", config->control_path.c_str());
	// create the qnx resource manager node.
	qnx_res_manager_c = new ResMgrWKup(config->control_path.c_str(),true);
	if(!qnx_res_manager_c->start(&err,qnx_dispatcher))
	{
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "Error creating qnx resource manager (ctl): %s\n",err.c_str());
		retcode = 2;
		goto leave;
	}

	LOG_WAKEUP_DAEMON(SLOG2_INFO, "creating wakeup_daemon status node %s:\n", config->status_path.c_str());
	// create the qnx resource manager node.
	qnx_res_manager_s = new ResMgrWKup(config->status_path.c_str(),false);
	if(!qnx_res_manager_s->start(&err,qnx_dispatcher))
	{
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "Error creating qnx resource manager (stat): %s\n",err.c_str());
		retcode = 2;
		goto leave;
	}

	run=1;
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "starting daemon. (send sig 15 to exit)\n");
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "interface paths:\n");
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "    status : '%s'\n",config->status_path.c_str());
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "    control: '%s'\n",config->control_path.c_str());
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "(send sig 15 to exit)\n");


	// into the messagepump.
//	qnx_res_manager_c->run_messageloop(&err);

	// run the message-loop with this mainthread.
	if(!qnx_dispatcher->run_messagepump(&err))
	{
		retcode = 2;
		goto leave;
	}


	LOG_WAKEUP_DAEMON(SLOG2_INFO, "exiting daemon.\n");

	if (true == slog2_reg_status) {
	    ret = slog2_reset();
	    if (-1 == ret) {
	        fprintf(stderr, "slog2_reset() failed!");
	    }
	}

leave:

	LOG_WAKEUP_DAEMON(SLOG2_ERROR, "go to leave! retcode:%d\n", retcode);
	delete qnx_res_manager_c;
	qnx_res_manager_c = NULL;

	delete qnx_res_manager_s;
	qnx_res_manager_s = NULL;

	delete qnx_dispatcher;
	qnx_dispatcher = NULL;

	wakeup_uninit();

	delete config;

	return retcode;
}



// handler for Ctrl-C (sig 15).
static void sigINTHandler(int dummy)
{
	run=0;
	if(qnx_dispatcher)
		qnx_dispatcher->async_hint_stop();
}

static void sigUSR1Handler(int dummy)
{
}
