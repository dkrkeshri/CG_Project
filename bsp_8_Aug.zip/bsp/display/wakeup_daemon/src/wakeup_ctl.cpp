#include "wakeup_ctl.h"
#include <errno.h>
#include <fcntl.h>
#include <vector>
#include <sys/types.h>
#include "inc_lib.h"	// broken include file, needs to have sys/types included first.
#include "configfile_data.h"
#include "daemon.h"
#include "logger.h"

/**
 * wakeup_ctl
 *
 * The 'wakeup_ctl' contains the main part of the daemon:
 * the logic that sends the packets on the INC.
 *
 * CM/ESO2 Achim Dahlhoff.
 */

// about the INC stuff:
// libpath:   ../../../../gm/prebuilts/inc_router/lib64/
// the lib folder of 'inc_router' contains several libs:
//     gmconfig
//     incivi
//     incmem
//     incrtos
//     incvdataext
//     incvdataparser
//     incvdata

// which channel to use on INC (defined in inc_lib.h)
#define INC_CHANNEL_ID ((inc_channel)(config->inc_channel_id))
// #define INC_CHANNEL_ID INC_CH_DISPLAY_PWR   // channel #32
// #define INC_CHANNEL_ID INC_CH_LCM    // channel #30

// 'priority' value to use with the open call for INC.
// This value comes from the SFS_105_VCU_Message_Dispatching_v1.3

//   doc here:  https://sites.inside-share.bosch.com/sites/070976/_layouts/15/WopiFrame2.aspx?sourcedoc=/sites/070976/Documents/04.Work_Products/02.SW_Architecture/07. Documents from GM/SFS_105_VCU_Message_Dispatching_v1.3-draft.docx
#define INC_OPEN_PRIORITY 2

// set this to 1 to completely stuf-off the INC functionality.
#define INC_STUBB 0

std::vector<WakeupChain*> chains;


// global vars to track state.
// no need to mutex-lock, the caller of these functions serializes the calls.
static inc_handle *INChandle = 0;
static inc_callback_handle *INCcallback = 0;

static bool is_keyword_on(const char *value);
static bool is_keyword_off(const char *value);
static void inc_router_callbackfunction(inc_router_status router_status);

int switch_to_online(std::string *out_errtxt);
void switch_to_offline();


int wakeup_init(std::string *out_errtxt)
{
	INChandle = 0;
	if(chains.size()<=0)
	{
		std::vector<ConfData::WkupChain>::const_iterator it;
		for( it=config->chaindata.begin() ; it!=config->chaindata.end() ; ++it )
		{
			WakeupChain *chn;
			chn = new WakeupChain();
			chn->name = it->name;
			chn->on = PWR_UNKNOWN;  // before sending the first switch command, we do not know the state.
			chn->id = (unsigned short)it->vip_chain_id;
			chains.push_back(chn);
		}
	}
	return 0;
}

void wakeup_uninit()
{
	switch_to_offline();
	if(INChandle)
	{

	}
	while(chains.size()>0)
	{
		delete (chains[0]);
		chains.erase(chains.begin());
	}
}

bool wakeup_bIsOnline()
{
	return !!INChandle;
}

/**
 * Set an option. Currently only supports 'online'.
 */
int wakeup_set_option(const char *option_name,const char *value,std::string *out_errtxt)
{
	// Todo. ..... implement the options. Which are those?
	// keywords found in sample-client program:
	// 'online'
	// any key a user enters as 'chain-name'

	LOG_WAKEUP_DAEMON(SLOG2_INFO, "setting option_name:%s value:%s\n", option_name, value);
	if(!strcmp(option_name,"online"))
	{
		// requesting to change on/off state.
		if(!strcmp(value,"online")||!strcmp(value,"1"))
		{
			LOG_WAKEUP_DAEMON(SLOG2_INFO, "switching to online to open INC channel!\n");
			return switch_to_online(out_errtxt);
		}
		if(!strcmp(value,"offline")||!strcmp(value,"0"))
		{
			LOG_WAKEUP_DAEMON(SLOG2_INFO, "switching to offline to close INC channel!\n");
			switch_to_offline();
			return 0;
		}
		*out_errtxt = "command 'online' with unknown option value '";
		*out_errtxt += value;
		*out_errtxt += "'";
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());

		return -EINVAL;
	}

	// might be 'list-chains'. If so, return a list of the names of all chains.
	if(!strcmp(option_name,"list-chains"))
	{
		// ..... cannot return string here.
	}

	// Otherwise, the control keyword might name one of the wakeup-chains. Find it.
	for(
		std::vector<WakeupChain*>::iterator it=chains.begin() ;
		it!=chains.end() ;
		it++ )
	{
		if( !strcmp( (*it)->name.c_str() , option_name ) )
		{

			// found it.
			bool switchon;
			std::string er;
			int ret;
			if( is_keyword_on(value) )
				switchon = true;
			else if( is_keyword_off(value) )
				switchon = false;
			else{
				*out_errtxt = "invalid command for chain. Use 'on' or 'off'.";
				LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());
				return -EINVAL;
			}

			LOG_WAKEUP_DAEMON(SLOG2_INFO, "wakeup_daemon is going to set powerstate: %d\n", switchon);
			// now do switch.
			ret = wakeup_set_powerstate(*it,switchon, &er);
			if(ret)
			{
				*out_errtxt = "Cannot set powerstate for '";
				*out_errtxt += option_name;
				*out_errtxt += ": ";
				*out_errtxt += er;
				LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());
				return ret;
			}
			return 0;
		}
	}

	*out_errtxt = "option '";
	*out_errtxt += option_name;
	*out_errtxt += "' not implemented.";
	LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());

	return -EINVAL;
}

/**
 * Query an option. Currently only supports 'online'.
 */
int wakeup_get_option(const char *option_name,std::string *out_value,std::string *out_errtxt)
{
	if(!strcmp(option_name,"online"))
	{
		if(wakeup_bIsOnline())
			*out_value="online";
		else
			*out_value="offline";
		return 0;
	}

	*out_errtxt = "option '";
	*out_errtxt += option_name;
	*out_errtxt += "' not implemented.";
	LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s", out_errtxt->c_str());
	return -EINVAL;
}

#define INC_MSIZE 6
int wakeup_set_powerstate(WakeupChain *chn,bool on,std::string *out_errtxt)
{
	char msg[INC_MSIZE];
	int stat,ret;

	if(!INChandle)
	{
		// not open. Reject. Caller will have to switch to 'online' first.
		*out_errtxt="not connected to INC.";
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());
		return EINVAL;
	}

	// put together the message.
	/**
	 * Format according to the INC message format documentation.
	 * Found it here: https://sites.inside-share.bosch.com/sites/070976/_layouts/15/WopiFrame2.aspx?sourcedoc=/sites/070976/Documents/04.Work_Products/03.Main_Workpackages/21.Main_Workpackage_LCM/00.Common/02.Documents_working/INC_Dispatcher/GM-VCU_INC_Message_Catalogue_LCM.docx
	 */
	msg[0] = 0x66;	// messageID: LCM_SUPPLYMGMT_C_SET_STATE
	msg[1] = 0x03;	// LCM Header data. MsgCounter(Byte 1) & Subchannel(Byte 0)
	msg[2] = 0x01;
	msg[3] = 0x32;	// MsgID      0x32
	msg[4] = chn->id;	// DISPLAY0 is 0x0D, DISPLAY1 is 0x0E. The value comes from "vip-chain-id" of the config file.
	msg[5] = ( on ? 1 : 0 );	// SupplyState:  0=OFF, 1=ON, 255=SUPPLYSTATE_INVALID
	stat = 0;
	chn->on = ( on ? PWR_ON : PWR_OFF );

#if INC_STUBB
	// when stubbed, just return ok.
	LOG_WAKEUP_DAEMON(SLOG2_WARNING, "INC part stubbed off. Change state to '%s'.\n",on?"on":"off");
	ret=0;
#else
	LOG_WAKEUP_DAEMON(SLOG2_INFO, "Sending INC MsgID:0x%x, SupplyID:0x%x, SupplyState:%s\n", msg[3], msg[4], on?"on":"off");
	ret = vcu_inc_send(INChandle,INC_ROUTE_VIP,msg,INC_MSIZE,&stat);
#endif
	if(ret)
	{
		char en[12];
		// not open. Reject. Caller will have to switch to 'online' first.
		*out_errtxt="error sending INC message. err ";
		ret = errno;
		if(!ret)ret=EIO;
		snprintf(en,sizeof(en),"%d",ret);
		*out_errtxt += en;
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s", out_errtxt->c_str());

		return ret;
	}

	return 0;
}

bool wakeup_get_info(int num,const char **out_name,unsigned short *out_id,bool *out_state_on)
{
	const WakeupChain *chn;

	if( num<0 || (unsigned int)num>=chains.size() )
		return false;

	chn = chains[num];
	*out_name = chn->name.c_str();
	*out_id = chn->id;
	*out_state_on = chn->on;
	return true;
}

/**
 * The 'switch_to_online' functions enables the INC link.
 *
 * If it is not switched to 'online' mode, it will refuse all other
 * commands.
 */
int switch_to_online(std::string *out_errtxt)
{
	// already there?
	if(INChandle)
		return 0;

	// open
	errno = 0;
#if INC_STUBB == 0
	// link the callback for the INC state-changes.
	INCcallback = vcu_inc_register_status_notification(inc_router_callbackfunction);
	if(!INCcallback)
	{
		*out_errtxt="error setting INC router status callback.";
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());
		return EIO;
	}

	// open the handle on the INC router.
	INChandle = vcu_inc_open(INC_CHANNEL_ID,INC_OPEN_PRIORITY,O_RDWR);

	if(!INChandle)
	{
		char en[12];
		int ret = errno;
		if(!ret)ret=-1;
		*out_errtxt="error opening INC channel. err ";
		snprintf(en,sizeof(en),"%d",ret);
		*out_errtxt += en;
		LOG_WAKEUP_DAEMON(SLOG2_ERROR, "%s\n", out_errtxt->c_str());
		vcu_inc_unregister_status_notification(INCcallback);
		INCcallback = 0;
		return ret;
	}
#else
	// stub. set dummy-value so test if INChandle==0 shows  'online'.
	INChandle = (inc_handle*)(void*)(uintptr_t)(0x1000);
#endif

	return 0;
}

void switch_to_offline()
{
	if(!INChandle)
		return;

	// going 'offline' means closing the handle.
#if INC_STUBB == 0
	vcu_inc_unregister_status_notification(INCcallback);
	vcu_inc_close(INChandle);
#endif
	INCcallback = 0;
	INChandle = 0;
}



static bool is_keyword_on(const char *value)
{
	if(!strcmp(value,"on"))
		return true;
	if(!strcmp(value,"1"))
		return true;
	if(!strcmp(value,"true"))
		return true;
	if(!strcmp(value,"True"))
		return true;
	return false;
}

static bool is_keyword_off(const char *value)
{
	if(!strcmp(value,"off"))
		return true;
	if(!strcmp(value,"0"))
		return true;
	if(!strcmp(value,"false"))
		return true;
	if(!strcmp(value,"False"))
		return true;
	return false;
}

static void inc_router_callbackfunction(inc_router_status router_status)
{
}
