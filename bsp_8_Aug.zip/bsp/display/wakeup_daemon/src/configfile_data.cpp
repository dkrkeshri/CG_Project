#include "configfile_data.h"

/**
 * config file parser
 *
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "daemon.h"
#include "smalljs.h"
#include "logger.h"


static void out_to_stdout(const char *msg,...);

/**
 * Load and parse a config file, create the ConfData item,
 * and place all usable values from the config inside it.
 *
 */
ConfData *ConfData::load_config(const char *filename,errPrintfFunc errfunc)
{
	ConfData *res = 0;
	int err;
	bool success = false;
	std::string errtxt;
	JSDataNode *js = 0;
	char *buffer = 0;

	if(!errfunc)
		errfunc = out_to_stdout;

	err = 0;
	buffer = load_textfile(filename,&err);
	if(!buffer)
	{
		LOG_ERR("error loading config file '%s', errno=%d\n",filename,err);
		goto leave;
	}


	// have file. send to json parser.
	js = parse_json(buffer,&errtxt);
	if(!js)
	{
		if(errtxt.size()>0)
			LOG_ERR("error parsing config json data:  %s\n",errtxt.c_str());
		else
			LOG_ERR("error parsing config json data\n");
		goto leave;
	}

	// top level shall be an object
	if(js->type!=JSTYPE_object)
	{
		LOG_ERR("top level of json config file shall be an 'object'.\n");
		goto leave;
	}

	// create res
	res = new ConfData();

	// peel out parts we need.
	errtxt="";
	if(!res->extract_data_from_json((JSDataNodeObject*)js,&errtxt))
	{
		LOG_ERR("failed to parse config file:  %s\n",errtxt.c_str());
		goto leave;
	}



	success = true;

	res->blah = 42;


leave:
	if(buffer)
		free(buffer);
	if(js)
		delete js;
	if( res && !success )
	{
		delete res;
		res=0;
	}

	return res;
}

void ConfData::debug_print_data(void)
{
	LOG_INFO("Status devpath: %s\n",status_path.c_str());
	LOG_INFO("Control devpath: %s\n",control_path.c_str());
	LOG_INFO("INC channel id:  %d\n",inc_channel_id);
	LOG_INFO("Logfile path: '%s'\n",logfile.c_str());
	LOG_INFO("Debuglevel: '%d'\n",(int)debuglevel);
	LOG_INFO("Allow 'quit' cmd:  %s\n",(allow_quit?"True":"False"));
}

bool ConfData::get_item(const char *itemname,std::string *out_result,const char *defaultvalue)
{
	// todo: .....
	return false;
}

bool ConfData::get_item(const char *itemname,char *out_result,int result_buffersize,const char *defaultvalue)
{
	std::string tmp;
	int ln;
	if(!get_item(itemname,&tmp,defaultvalue))
		return false;
	ln = tmp.size();
	if(ln>=result_buffersize)
		ln = result_buffersize-1;
	if(ln>0)
	{
		memcpy(out_result,tmp.c_str(),ln);
		out_result[ln]=0;
	}
	return true;
}

ConfData::ConfData()
{
	use_slog2 = true;
	blah = 0;
	debuglevel = 0;
	allow_quit = false;
	inc_channel_id = 0;
}

/**
 * Process the parsed json data from the config file.
 * All usable values found are placed into the fields in 
 * the class' instance.
 *
 * In case failure, the string *out_err is filled with 
 * a meaningful error message such as which field is missing.
 *
 * Return true if successful.
 */
bool ConfData::extract_data_from_json(class JSDataNodeObject *js,std::string *out_err)
{
	JSDataNode *ch;
	JSDataNodeObject *cho;
	JSDataNodeArray *cha;

	// get 'logfile'
	ch = js->get("logfile");
	if(ch)
	{
		if( ch->type!=JSTYPE_string )
		{
			*out_err = "config section 'logfile', if present, shall be a string.";
			LOG_ERR("%s\n", out_err->c_str());
			return false;
		}
		logfile = ((JSDataNodeString*)ch)->text;
	}

	// get 'slog2'
	ch = js->get("slog2");
	if(ch)
	{
		if( ch->type!=JSTYPE_bool )
		{
			*out_err = "config section 'slog2', if present, shall be a boolean.";
			LOG_ERR("%s\n", out_err->c_str());
			return false;
		}
		use_slog2 = ((JSDataNodeBool*)ch)->flag;
	}

	// get 'device-nodes'
	ch = js->get("device-nodes");
	if(!ch)
	{
		*out_err = "config file needs 'device-nodes' on top level.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	cho = (JSDataNodeObject*)ch;

	// in 'device-nodes', get 'status'
	ch = cho->get("status");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section 'device-nodes' shall have a string named 'status'.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	status_path = ((JSDataNodeString*)ch)->text;

	// in 'device-nodes', get 'control'
	ch = cho->get("control");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section 'device-nodes' shall have a string named 'control'.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	control_path = ((JSDataNodeString*)ch)->text;

	// get 'inc'
	ch = js->get("inc");
	if(!ch)
	{
		*out_err = "config file needs 'inc' on top level.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	if(!get_inc_config((JSDataNodeObject*)ch,out_err))
		return false;

	// get and parse data for wakeup chains.
	ch = js->get("wakeup-chains");
	if( !ch || ch->type!=JSTYPE_array || ((JSDataNodeArray*)ch)->count()<1 )
	{
		*out_err = "config section 'wakeup-chains' shall exist and be an non-empty array.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	chaindata.clear();
	cha = (JSDataNodeArray*)ch;
	for(unsigned int i=0;i<cha->count();i++)
	{
		WkupChain chdata;

		ch = cha->get(i);
		if( !ch || ch->type!=JSTYPE_object )
		{
			*out_err = "config items under 'wakeup-chains' shall be objects.";
			LOG_ERR("%s\n", out_err->c_str());
			return false;
		}

		if(!extract_wakeupchain_from_json((JSDataNodeObject*)ch,out_err,&chdata))
			return false;
		chaindata.push_back(chdata);
	}

	return true;
}

bool ConfData::extract_wakeupchain_from_json(class JSDataNodeObject *js,std::string *out_err,WkupChain *out_inhere)
{
	JSDataNode *ch;
	const char *val;
	char *e;

	// in wakeup-chain, get 'name'
	ch = js->get("name");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section for a wakeup-chain must have a 'name'.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	out_inhere->name = ((JSDataNodeString*)ch)->text;

	// in wakeup-chain, get 'vip-chain-id'
	ch = js->get("vip-chain-id");
	if( !ch || ch->type!=JSTYPE_string )
	{
		*out_err = "config section for a wakeup-chain must have a 'vip-chain-id'.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	val = ((JSDataNodeString*)ch)->text.c_str();
	errno = 0;
	out_inhere->vip_chain_id = strtol(val,&e,0);
	if( errno || *e || out_inhere->vip_chain_id<0 || out_inhere->vip_chain_id>254 )
	{
		*out_err = "config section value 'vip-chain-id' must be a number, in range 0..254 .";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}

	return true;
}

/**
 * Process the 'inc' subsection of the config file.
 *
 * Return true if successful.
 */
bool ConfData::get_inc_config(class JSDataNodeObject *js,std::string *out_err)
{
	JSDataNode *ch;

	// in 'inc', get 'channel-id'
	ch = js->get("channel-id");
	if( !ch || ch->type!=JSTYPE_number )
	{
		*out_err = "config section 'inc' shall have a number field named 'channel-id'.";
		LOG_ERR("%s\n", out_err->c_str());
		return false;
	}
	inc_channel_id = (int) ((JSDataNodeNumber*)ch)->number;

	return true;
}

char* load_textfile(const char *filename,int *out_errno)
{
	int fh;
	int tmp;
	off_t fsize;
	char *res;

	// open filehandle.
	fh = open(filename,O_RDONLY);
	if(fh<0)
	{
		*out_errno = errno;
		if(!*out_errno)
			*out_errno = EINVAL;
		return 0;
	}
	// get filesize
	fsize = lseek(fh,0,SEEK_END);
	if( fsize==-1 && errno!=0 )
	{
		close(fh);
		*out_errno = errno;
		return 0;
	}
	lseek(fh,0,SEEK_SET);

	if( fsize>0x100000 || fsize<1 )
	{
		close(fh);
		*out_errno = -EINVAL;
		return 0;
	}

	/* alloc space for data. */
	res = (char*)malloc(fsize+3);
	if(!res)
	{
		close(fh);
		*out_errno = ENOMEM;
		return 0;
	}
	memset( res+fsize , 0 , 3 ); /* append 3 null bytes */

	/* load file data */
	fsize -= read(fh,res,fsize);
	tmp = errno;
	close(fh);fh=0;

	if(fsize)
	{
		free(res);
		*out_errno = tmp;
		if(!tmp)
			*out_errno = EIO;
		return 0;
	}

	return res;
}

static void out_to_stdout(const char *msg,...)
{
	va_list val;
	va_start(val,msg);

	(void)vprintf(msg,val);
	printf("\n");

	va_end(val);
}

