#include <dcmd_pm.h>
#include <devctl.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dispatch.h>
#include <sys/types.h>
#include <unistd.h>

#define TEST_PREPARE_PULSE (_PULSE_CODE_MINAVAIL)
#define TEST_SUSPEND_PULSE (_PULSE_CODE_MINAVAIL + 1)
#define TEST_RESUME_PULSE (_PULSE_CODE_MINAVAIL + 2)

int max_count = -1;

void signal_handler(int signo)
{
    printf("dispinfra_pm_client: signal_handler called\n");
    max_count = 0;
}

void display_help()
{
    printf("Usage: dispinfra_pm_client -f [PM DEV NAME]  [option]\n");
    printf("\n");
    printf("Description:\n");
    printf(" Test client for FIDM PM device\n");
    printf("\n");
    printf(" options:\n");
    printf("        -f [PM DEV PATH] path for the fidm pm device\n");
    printf("        -i               makes application interactive\n");
    printf("        -e               send an error code(EAGAIN) in "
           "acknowledgment\n");
    printf("        -n <number>      Exit after <number> pulses.\n");
    printf("        -t <time>        time (in ms) before sending "
           "acknowledgement\n");
    printf("\n");
    printf("Examples:\n");
    printf("        dispinfra_pm_client -f /dev/fidm-1-pm/touch-pm -t 15000\n");
    printf("\n");
}

int main(int argc, char **argv)
{
    struct pm_register_s pm_reg;
    int chid;
    struct _pulse pulse;
    int dispinfra_pm_fd = -1;
    struct pm_ack_s ack = {.rc = EOK };
    int ret = -1;
    long int tmpval;
    char *endp;
    char dev_pm_path[PATH_MAX] = { 0 };
    bool is_interactive = false;
    bool send_err = false;
    int timeout_ms = 2000;
    char response;
    int opt;

    dev_pm_path[0] = 0;

    while ((opt = getopt(argc, argv, ":f:t:n:eih")) != -1) {
        switch (opt) {
            case 'f':
                /*TODO: Add check for valid file path*/
                memset(dev_pm_path, 0, PATH_MAX);
                strncpy(dev_pm_path, optarg, PATH_MAX);
                dev_pm_path[PATH_MAX - 1] = '\0';
                break;

            case 'i':
                is_interactive = true;
                break;

            case 't':
                errno = 0;
                tmpval = strtol(optarg, &endp, 10);
                if (errno || *endp || tmpval < 0 || tmpval > 60000) {
                    fprintf(stderr, "invalid argument for -t : ('%s') shall be "
                                    "a integer, 0 to 60000: delay in ms.\n",
                            optarg);
                    return EXIT_FAILURE;
                }
                timeout_ms = (int) tmpval;
                break;

            case 'n':
                errno = 0;
                tmpval = strtol(optarg, &endp, 10);
                if (errno || *endp || tmpval <= 0 || tmpval > 1000000) {
                    fprintf(stderr, "invalid argument for -n : ('%s') shall be "
                                    "an integer 1..1000000.\n",
                            optarg);
                    return EXIT_FAILURE;
                }
                max_count = (int) tmpval;
                break;

            case 'h':
                display_help();
                return EOK;
                break;

            case 'e':
                send_err = true;
                break;

            case '?':
                printf("unknown option: %c\n", optopt);
                display_help();
                return EXIT_FAILURE;
                break;

            case ':':
                printf("please provide path after -%c\n", optopt);
                display_help();
                return EXIT_FAILURE;
                break;

            default:
                printf("unknown argument: %c\n", optopt);
                display_help();
                return EXIT_FAILURE;
                break;
        }
    }

    signal(SIGINT, signal_handler);

    if (dev_pm_path[0] == '\0') {
        fprintf(stderr, "No device path specified. Use -f option.\n");
        return EXIT_FAILURE;
    }

    printf("Starting client...\n");

    chid = ChannelCreate(_NTO_CHF_DISCONNECT | _NTO_CHF_UNBLOCK);
    if (chid == -1) {
        ret = errno;
        fprintf(stderr, "ChannelCreate failed (%d)\n", ret);
        return ret;
    }
    dispinfra_pm_fd = open(dev_pm_path, O_RDWR | O_CLOEXEC);
    if (dispinfra_pm_fd < 0) {
        ret = errno;
        fprintf(stderr, "could not open %s (%d)\n", dev_pm_path, ret);
        return ret;
    }

    memset(&pm_reg, 0x0, sizeof(struct pm_register_s));
    INIT_PM_REGISTER_STRUCT(&pm_reg);

    strlcpy(pm_reg.name, argv[0], sizeof(pm_reg.name));
    pm_reg.pulse_codes[PM_STATE_PREPARE] = TEST_PREPARE_PULSE;
    pm_reg.pulse_codes[PM_STATE_SUSPEND] = TEST_SUSPEND_PULSE;
    pm_reg.pulse_codes[PM_STATE_RESUME] = TEST_RESUME_PULSE;
    pm_reg.priority = PM_PRIO_LEVEL_2;
    pm_reg.flags = 0;
    pm_reg.chid = chid;

    if ((ret = devctl(dispinfra_pm_fd, DCMD_PM_REGISTER, &pm_reg,
                      sizeof(struct pm_register_s), NULL)) != EOK) {
        fprintf(stderr, "devctl(DCMD_PM_REGISTER) failed (%d)\n", ret);
        if (dispinfra_pm_fd > 0)
            close(dispinfra_pm_fd);
        dispinfra_pm_fd = -1;
        ChannelDestroy(chid);
        return ret;
    }

    while (max_count != 0) {
        if (send_err == true) {
            ack.rc = EAGAIN;
        } else {
            ack.rc = EOK;
        }
        printf("%s client: Waiting for a pulse...\n", dev_pm_path);
        ret = MsgReceivePulse(pm_reg.chid, &pulse, sizeof(pulse), NULL);
        if (ret == -1) {
            ret = errno;
            printf("Receive failed\n");
            return ret;
        }

        switch (pulse.code) {
            case TEST_PREPARE_PULSE:
                printf("dispinfra_pm_client : %s : prepare received\n",
                       dev_pm_path);
                ack.state = PM_STATE_PREPARE;
                break;

            case TEST_SUSPEND_PULSE:
                printf("dispinfra_pm_client : %s : suspened received\n",
                       dev_pm_path);
                // actual work for suspend
                ack.state = PM_STATE_SUSPEND;
                break;

            case TEST_RESUME_PULSE:
                printf("dispinfra_pm_client : %s : resume received\n",
                       dev_pm_path);
                ack.state = PM_STATE_RESUME;
                break;

            default:
                printf(
                    "dispinfra_pm_client : %s : unexpected pulse %d received\n",
                    dev_pm_path, pulse.code);
                return EXIT_FAILURE;
        }

        if (is_interactive == true) {
            printf("Send Failure? y/n\n");
            scanf(" %c", &response);
            if (response == 'y') {
                ack.rc = EAGAIN;
            }
        } else {
            if (timeout_ms > 0)
                usleep(timeout_ms * 1000);
        }
        if (ack.rc != EOK) {
            printf("dispinfra_pm_client : %s : sending error code %d\n",
                   dev_pm_path, ack.rc);
        }
        ret = devctl(dispinfra_pm_fd, DCMD_PM_ACK, &ack, sizeof(ack), NULL);
        if (ret) {
            fprintf(stderr, "devctl(DCMD_PM_ACK) failed. ret = %d\n", ret);
        }

        if (max_count > 0)
            max_count--;
    }
    close(dispinfra_pm_fd);

    return ret;
}
