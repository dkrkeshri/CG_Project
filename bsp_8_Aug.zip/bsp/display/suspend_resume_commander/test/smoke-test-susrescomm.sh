#!/bin/ksh
#set -o xtrace

LOGFILE=/tmp/testsusres.log
PASS=0
FAIL=0
#FN_SEND_PULSE
# Description: sends pulse to a client
# Arguments:
#  $1 : display type. vcd/ipd
#  $2 : client type. touch/faceplate/brightness
#  $3 : pulse type. prepare/suspend/resume/complete
FN_SEND_PULSE()
{
#	 echo "exodus sending $3 pulse to vcd-$2-pm of $1 display"
	./susrescomm-ctl -c /dev/$1/suspend-resume-commander/control\
		-n $1-$2-pm -p $3 >> $LOGFILE 2>&1
	local retval=$?
	if [ $retval != 0 ]; then
		echo "sending" $3 "pulse to vcd-$2-pm of $1 display\
			failed" >> LOGFILE
	fi
	return $retval
}

#FN_EXPECT_EQ()
# Description: Validate equality
# Arguments:
#  $1 : value to check
#  $2 : value to check equality with
#  $3 : test name
FN_EXPECT_EQ()
{
	if [ $1 == $2 ] #EBUSY
	then
		PASS=$(($PASS + 1))
		echo "$3... :Passed"
	else
		FAIL=$(($FAIL + 1))
		echo "$3... : Failed"
	fi
}


#FN_EXPECT_NEQ()
# Description: Validate equality
# Arguments:
#  $1 : value to check
#  $2 : value to check equality with
#  $3 : test name
FN_EXPECT_NEQ()
{
	if [ $1 != $2 ] #EBUSY
	then
		echo $3 "... : Passed"
	else
		echo $3 "... :  Failed"
	fi
}

#FN_INIT()
# Description: Change current directory and start the suspend
#              resume commander daemon
FN_INIT()
{
	pidin|grep sus_res_commander;
	if [ $? == 0 ] ; then
		echo "\nAn instance of suspend resume commander already running. Close it to start the test\n"
		exit 1
	fi
	cd /tmp/
	#start the daemon
	./sus_res_commander -ddc example-config.json  >> $LOGFILE 2>&1 &
	daemon_pid=$!
	#let the daemon finish initialization
	sleep 1;
}


#TEST 1: check if multiple client can open same device path
#Descrition:
# Display infrastructre PM device should allow only one client
# to connect. If another client wants to connect with an already
# opened PM node. It should fail
FN_TEST_1()
{
	#start a client
	./dispinfra_pm_client -f /dev/vcd/touch/pm  >> $LOGFILE 2>&1 &
	local client_pid=$!

	./dispinfra_pm_client -f /dev/vcd/touch/pm >> $LOGFILE 2>&1 &
	wait $!
	FN_EXPECT_EQ $? 16 "TEST 1: Check multiple open" #16=EBUSY

	#kill the client
	kill -2 $client_pid #2 = SIGINT
}

#TEST 2: send pulse in sequence
#send suspend pulse
FN_TEST_2()
{
	#start a client which sends EOK ack after 100ms
	./dispinfra_pm_client -f /dev/vcd/touch/pm -t 100 >> $LOGFILE 2>&1 &
	local client_pid=$!
	ret=0
	#send prepare pulse
	FN_SEND_PULSE vcd touch "prepare"
	ret=$?

#	 ./susrescomm-ctl -c /dev/vcd/suspend-resume-commander/control -n vcd-touch-pm -p 'suspend'
	#send_suspend_pulse
	FN_SEND_PULSE vcd touch 'suspend'
	ret=$?

	#send resume pulse
	FN_SEND_PULSE vcd touch "resume"
	ret=$?

	#send complete pulse
	FN_SEND_PULSE vcd touch "complete"
	ret=$?

	FN_EXPECT_EQ $ret 0 "TEST 2: Send an STR sequence to client"
	kill -2 $client_pid #2 = SIGINT
}

#TEST 3 Check for sending a wrong pulse
#Description:
# If the server side sends an invalid pulse, it
# should be handled
#
FN_TEST_3()
{
	FN_SEND_PULSE vcd touch foobar
	FN_EXPECT_EQ $? 22 "TEST 3: Send Invalid pulse" #22=EINVAL
}

#TEST 4 Check handling of wrong device name
#Description:
# Check if wrong device names are handled
FN_TEST_4()
{
	FN_SEND_PULSE vcd foobar 'prepare'
	FN_EXPECT_EQ $? 2 "TEST 4: Use invalid device name" #2=ENOENT
}


#TEST 5 Check sending pulse to a device which has no client
#Description:
# A PM device may not have any clients connected to it. Check
# if the daemon handles it correctly
FN_TEST_5()
{
	FN_SEND_PULSE vcd touch prepare
	FN_EXPECT_EQ $? 19 "TEST 5: Send pulse to node without client" #19=ENODEV
}

#TEST 6 Check error code from client
#Description:
# Daemon must bubble out client side errors to the server side
# check this functionality
FN_TEST_6()
{
	#start a client which returns EAGAIN error as an ack and exits after sending 1 ack
	./dispinfra_pm_client -f /dev/vcd/faceplate/pm -t 100 -e -n 1 >> $LOGFILE 2>&1 &
	FN_SEND_PULSE vcd faceplate prepare
	FN_EXPECT_EQ $? 11 "TEST 6: Check Error Code from client" #11=EAGAIN
}

#TEST 7 Check Timeout Handling
# Description:
#  The daemon should not hang the server application indefinitely.
#  Check timeout functionality
#
FN_TEST_7()
{
	#start a client which replies after 11 seconds and receives only 1 pulse before exiting
	./dispinfra_pm_client -f /dev/vcd/brightness/pm -t 11000 -n 1 >> $LOGFILE 2>&1 &
	pid=$!
	FN_SEND_PULSE vcd brightness prepare
	FN_EXPECT_EQ $? 4 "TEST 7: Check Timeout Handling" #4=260 && 0xFF
	#260=ETIMEDOUT
	#shell script can only return 1 byte error code
	#So FF mask is used to get the 1 byte error code
	wait $pid
}

FN_TEST_8()
{
	#start clients for all available PM nodes
	./dispinfra_pm_client -f /dev/vcd/touch/pm -t 5 >> $LOGFILE 2>&1 &
	local client_pids=$!
	./dispinfra_pm_client -f /dev/vcd/faceplate/pm -t 5 -e >> $LOGFILE 2>&1 &
	client_pids="$client_pid $!"
	./dispinfra_pm_client -f /dev/vcd/brightness/pm -t 5 >> $LOGFILE 2>&1 &
	client_pids="$client_pid $!"
	./dispinfra_pm_client -f /dev/ipd/faceplate/pm -t 5 >> $LOGFILE 2>&1 &
	client_pids="$client_pid $!"
	./dispinfra_pm_client -f /dev/ipd/brightness/pm -t 5 >> $LOGFILE 2>&1 &
	client_pids="$client_pid $!"
	sleep 1
	ret=0
	#send prepare pulse
	FN_SEND_PULSE vcd touch prepare
	ret=$?

	FN_SEND_PULSE vcd faceplate prepare
	ret=$?

	FN_SEND_PULSE vcd brightness prepare
	ret=$?

	FN_SEND_PULSE ipd faceplate prepare
	ret=$?

	FN_SEND_PULSE ipd brightness prepare
	ret=$?

	#send suspend
	FN_SEND_PULSE vcd touch 'suspend'
	ret=$?

	FN_SEND_PULSE vcd faceplate 'suspend'
	ret=$?

	FN_SEND_PULSE vcd brightness 'suspend'
	ret=$?

	FN_SEND_PULSE ipd faceplate 'suspend'
	ret=$?

	FN_SEND_PULSE ipd brightness 'suspend'
	ret=$?

	#send resume
	FN_SEND_PULSE vcd touch resume
	ret=$?

	FN_SEND_PULSE vcd faceplate resume
	ret=$?

	FN_SEND_PULSE vcd brightness resume
	ret=$?

	FN_SEND_PULSE ipd faceplate resume
	ret=$?

	FN_SEND_PULSE ipd brightness resume
	ret=$?


	#send complete
	FN_SEND_PULSE vcd touch complete
	ret=$?

	FN_SEND_PULSE vcd faceplate complete
	ret=$?

	FN_SEND_PULSE vcd brightness complete
	ret=$?

	FN_SEND_PULSE ipd faceplate complete
	ret=$?

	FN_SEND_PULSE ipd brightness complete
	ret=$?
	sleep 5
	FN_EXPECT_EQ $ret 0 "TEST 8: Send an STR sequence to all client"
	kill -2 $client_pids #2 = SIGINT

}

#cleanup
FN_DEINIT()
{
	#close the daemon
	kill -2 $daemon_pid
}

FN_RESULTS()
{
	echo "========================================="
	echo "PASSED TEST: $PASS  |  FAILED TEST: $FAIL"
	echo "========================================="
}

#perform all tests
FN_INIT
FN_TEST_1
FN_TEST_2
FN_TEST_3
FN_TEST_4
FN_TEST_5
FN_TEST_6
FN_TEST_7
FN_TEST_8
FN_DEINIT
FN_RESULTS
