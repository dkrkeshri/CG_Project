#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include "sus_res_comm_lib.h"

void display_help(const char *self)
{
    printf("%s [options]\n", self);
    printf("options:\n");
    printf("   -c [fidm-pm control path]     Select display chain to send "
           "pulse to a registered client.\n");
    printf("                                 Must be used with -n and -p "
           "options\n");
    printf("   -s [fidm-pm status path]      Select display chain to get "
           "current status of a registered client.\n");
    printf("                                 Must be used with -n option\n");
    printf("   -n [pm device name]           Select fidm-pm device. Must be "
           "used with -c or -s\n");
    printf("   -p [pulse name]               Send pulse \"pulse name\" to "
           "registered client.\n");
    printf("                                 Must be used with -c and -n "
           "options\n");
    printf("   -l [fidm-pm status path]      List all fidm pm devices on a "
           "display chain\n");
    printf("   -v                            Verbose\n");
    printf("   -h                            Print help-text.\n");
    printf("Examples:\n");
    printf("\nList all available fidm-pm devices available on a control "
           "path:\n\n");
    printf("   %s -l /dev/fidm-1-pm/status\n", self);
    printf("\nSend a pulse to a particular device:\n\n");
    printf("   %s -c /dev/fidm-1-pm/control -n dev-pm-touch -p suspend\n",
           self);
    printf("\nget the status of the client registered to a path:\n\n");
    printf("   %s -s /dev/fidm-1-pm/status -n dev-pm-touch\n\n", self);
}

void list_all(const char *dev)
{
    char buf[4096];
    int handle = sus_res_comm_open_status(dev);
    if (handle < 0) {
        printf("Error: Could not open device %s (%d)\n", dev, handle);
        return;
    }
    int ret = sus_res_comm_list_all(handle, buf, 4096);
    if (ret < 0) {
        printf("sus_res_comm_list_all failed (%d)", ret);
        return;
    }
    printf("List of device:\n%s\n", buf);
    sus_res_comm_close(handle);
}

int print_client_state(const char *status_dev, const char *pm_dev_name)
{
    char *buf = NULL;
    int handle = sus_res_comm_open_status(status_dev);
    if (handle < 0) {
        printf("Error: Could not open device %s (%d)\n", status_dev, handle);
        return handle;
    }
    int ret = sus_res_comm_get_status(handle, pm_dev_name, &buf);
    if (ret != 0) {
        sus_res_comm_close(handle);
        printf("sus_res_comm_get_status failed (%d)\n", ret);
        return ret;
    }
    printf("Status of client registered to %s : \"%s\"\n", pm_dev_name, buf);
    if (buf) {
        free(buf);
    }
    sus_res_comm_close(handle);
    return 0;
}

int main(int numargs, char *const *args)
{
    const char *errtxt;
    char errtxtbuf[1024];
    int ret;
    int opt;
    int hdl;
    bool is_get = false;
    char debuglevel;
    char *display_chain_path = NULL;
    char *dev_pm_name = NULL;
    char *pulse = NULL;

    debuglevel = 0;
    hdl = -1;
    errtxt = 0;
    ret = 0;

    while ((opt = getopt(numargs, args, ":d:p:l:c:n:s:hv")) != -1) {
        switch (opt) {
            case 'v':
                debuglevel++;
                break;

            case 'h':
                display_help(args[0]);
                return 0;
                break;

            case 'l':
                list_all(optarg);
                return 0;
                break;

            case 'c':
                display_chain_path = optarg;
                break;

            case 'n':
                dev_pm_name = optarg;
                break;

            case 'p':
                pulse = optarg;
                break;

            case 's':
                is_get = true;
                display_chain_path = optarg;
                break;

            case ':':
                printf("please provide argument after -%c\n", optopt);
                display_help(args[0]);
                return EXIT_FAILURE;
                break;

            default:
                printf("unknown argument: %c\n", optopt);
                display_help(args[0]);
                return EXIT_FAILURE;
                break;
        }
    }
    if (optind < numargs) {
        display_help(args[0]);
        ret = 1;
        goto leave;
    }

    if (is_get) {
        if (display_chain_path && dev_pm_name) {
            ret = print_client_state(display_chain_path, dev_pm_name);
            goto leave;
        } else {
            display_help(args[0]);
            ret = 1;
            goto leave;
        }
    }

    // start setting
    if (!display_chain_path && !dev_pm_name && !pulse) {
        ret = 1;
        goto leave;
    }

    // start ok.
    hdl = sus_res_comm_open_control(display_chain_path);
    if (hdl < 0) {
        snprintf(errtxtbuf, sizeof(errtxtbuf), "failed to open %s: ret=%d",
                 display_chain_path, hdl);
        errtxt = errtxtbuf;
        ret = hdl;
        goto leave;
    }

    // set online
    ret = sus_res_comm_set_online(hdl);
    if (ret) {
        snprintf(errtxtbuf, sizeof(errtxtbuf),
                 "failed to set to online mode. ret=%d", ret);
        errtxt = errtxtbuf;
        goto leave;
    }

    // send suspend command.
    printf("sending %s pulse to %s...\n", pulse, dev_pm_name);
    ret = sus_res_comm_ctrl_set(hdl, pulse, dev_pm_name);
    if (ret) {
        snprintf(errtxtbuf, sizeof(errtxtbuf), "%s command failed. ret=%d",
                 pulse, ret);
        errtxt = errtxtbuf;
        goto leave;
    }

leave:
    if (hdl >= 0) {
        sus_res_comm_set_offline(hdl);
        sus_res_comm_close(hdl);
    }

    if (errtxt) {
        fprintf(stderr, "Error: %s\n", errtxt);
    }

    return ret;
}
