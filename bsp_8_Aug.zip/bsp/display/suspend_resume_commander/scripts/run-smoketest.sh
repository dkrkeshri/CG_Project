#./build_copy_daemon.sh
#if [ $? -neq 0 ]; then
#	exit 1;
#fi
#
#./build_copy_PM_client.sh
#if [ $? -neq 0 ]; then
#	exit 1;
#fi
#
#./build_copy_susrescomm-ctl.sh
#if [ $? -neq 0 ]; then
#	exit 1;
#fi
#check if target is reachable
ping -c 2 -i 0.25 -W 0.2 -w 1 192.168.211.100
if [ $? -ne 0 ] ; then
          echo 192.168.211.100 not reachable
            exit 1
fi

scp ../test/smoke-test-susrescomm.sh root@192.168.211.100:/tmp

ssh root@192.168.211.100 'cd /tmp; ./smoke-test-susrescomm.sh'

