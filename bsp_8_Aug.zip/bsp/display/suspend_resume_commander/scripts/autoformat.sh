uncrustify -c .uncrustify --replace --no-backup ../daemon/src/configfile_data.*
uncrustify -c .uncrustify --replace --no-backup ../daemon/src/daemon*
uncrustify -c .uncrustify --replace --no-backup ../daemon/src/dispinfra*
uncrustify -c .uncrustify --replace --no-backup ../daemon/src/logoutput.*
uncrustify -c .uncrustify --replace --no-backup ../daemon/src/main.cpp
uncrustify -c .uncrustify --replace --no-backup ../daemon/src/resmgr_susrescomm.*
uncrustify -c .uncrustify --replace --no-backup ../test/susrescomm-ctl/*.c
uncrustify -c .uncrustify --replace --no-backup ../test/testPMclient/*c
uncrustify -c .uncrustify --replace --no-backup   ../../api/public/sus_res_comm_lib/public/*h
uncrustify -c .uncrustify --replace --no-backup   ../../api/public/sus_res_comm_lib/src/*h
uncrustify -c .uncrustify --replace --no-backup   ../../api/public/sus_res_comm_lib/src/*c
clang-format -i --style=file  ../daemon/src/configfile_data.*
clang-format -i --style=file  ../daemon/src/daemon*
clang-format -i --style=file  ../daemon/src/dispinfra*
clang-format -i --style=file  ../daemon/src/logoutput.*
clang-format -i --style=file  ../daemon/src/main.cpp
clang-format -i --style=file  ../daemon/src/resmgr_susrescomm.*
clang-format -i --style=file ../test/susrescomm-ctl/*.c
clang-format -i --style=file ../test/testPMclient/*c
clang-format -i --style=file ../../api/public/sus_res_comm_lib/public/*h
clang-format -i --style=file ../../api/public/sus_res_comm_lib/src/*h
clang-format -i --style=file ../../api/public/sus_res_comm_lib/src/*c
