#ifndef _DISPINFRA_PM_RES_MGR_H_
#define _DISPINFRA_PM_RES_MGR_H_

#include <sys/iofunc.h>
#include <sys/resmgr.h>
#include <sys/dispatch.h>
#include <limits.h>
#include <dcmd_pm.h>
#include <errno.h>
#include <time.h>
#include "dispinfra_pm_log.h"
#include "resmgr_susrescomm.h"

#define PM_STATE_INVALID PM_STATE_MAX
#define TIMEOUT_MS 10000
#define REPLY_SIZE 32

typedef struct dispinfra_pm_client {
    char name[64];
    int8_t pulse_codes[PM_STATE_MAX];
    int coid;
    bool waiting_for_ack;
    // bool consumed[PM_STATE_MAX];
    enum pm_state current_state;
} dispinfra_pm_client_t;

class DispinfraPMResMgr;

typedef struct dispinfra_pm_dev {
    iofunc_attr_t
        io_attr; /*!< The first member must be the default io attribute */
    dispatch_t *dp;
    int resmgr_id;
    resmgr_attr_t resmgr_attr;
    resmgr_connect_funcs_t connect_funcs;
    resmgr_io_funcs_t io_funcs;
    char path[PATH_MAX];
    bool is_open;
    DispinfraPMResMgr *self;
    dispinfra_pm_client_t *client;
    enum pm_state last_pulse_sent;
    ResMgrSusResComm *control_interface;
    timer_t timerID;
    int timerPulseCode;
    int timerCoid;
} dispinfra_pm_dev_t;

class DispinfraPMResMgr
{
  public:
    DispinfraPMResMgr(const char *path, std::string devname,
                      ResMgrSusResComm *ctrlIF);
    ~DispinfraPMResMgr();
    bool start(ResManagerDispatchloop *dispatcher);
    void stop();
    std::string get_client_name() const;
    // std::string get_resmgr_path_name() const;
    std::string get_device_name() const;
    std::string get_client_state() const;
    int send_pulse_to_client(std::string pulse);

  private:
    std::string dispinfra_pm_device_name;
    dispinfra_pm_dev_t *dispinfra_pm_dev;
    static const char *pm_state_to_string[];
    bool timer_pulse_init(ResManagerDispatchloop *dispatcher);
    bool start_timer(unsigned int msec);
    void stop_timer(void);

    static int timeout_handler(message_context_t *ctp, int code, uint32_t flags,
                               void *handle);
    static enum pm_state string_to_pm_state(std::string state);
    static int register_client(dispinfra_pm_client_t **client,
                               const struct pm_register_s *req, pid_t pid);
    static int dispinfra_pm_devctl(resmgr_context_t *ctp, io_devctl_t *msg,
                                   RESMGR_OCB_T *ocb);
    static int dispinfra_pm_open(resmgr_context_t *ctp, io_open_t *msg,
                                 RESMGR_HANDLE_T *handle, void *extra);
    static int dispinfra_pm_close(resmgr_context_t *ctp, void *reserved,
                                  RESMGR_OCB_T *ocb);
    DispinfraPMResMgr(); /*Do not allow default constructor*/
};

#endif
