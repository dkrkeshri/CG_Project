#pragma once
#include <vector>
#include <string>
#include "daemon.h"

class ConfData
{
  public:
    virtual ~ConfData();

    std::string logfile;
    bool use_slog2;
    unsigned char debuglevel;
    bool allow_quit;

    class IfaceMgrNode
    {
      public:
        std::string name;
        std::string pm_resmgr;
    };

    class DeviceSetting
    {
      public:
        std::string name;

        std::string dev_control;
        std::string dev_status;

        std::vector<IfaceMgrNode> pm_devices;
    };

    std::vector<DeviceSetting *> displays;

    static ConfData *load_config(const char *filename, errPrintfFunc errfunc);
    void debug_print_data(errPrintfFunc printffunc) const;
    bool get_item(const char *itemname, std::string *out_result,
                  const char *defaultvalue);
    bool get_item(const char *itemname, char *out_result, int result_buffersize,
                  const char *defaultvalue);

  private:
    ConfData();
    void drop_data();
    bool extract_data_from_json(class JSDataNodeObject *js,
                                std::string *out_err);
    DeviceSetting *extract_devicedata_from_json(class JSDataNodeObject *js,
                                                std::string *out_err);

    bool check_all_devpaths(std::string *failed_name) const;
    static bool check_devpath(const char *name);
    static bool check_devpath(const std::string &name);

    bool get_string_item(class JSDataNodeObject *js, std::string *out_val,
                         const char *name, const char *def_value);
};
