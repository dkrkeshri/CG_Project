//#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include "daemon.h"
#include "logoutput.h"
#include "configfile_data.h"
#include "dispinfra-pm-resmgr.h"
#include "resmgr_susrescomm.h"

#define TMPSTR_SIZE 128

extern "C" {
static void sigINTHandler(int dummy);
static void sigUSR1Handler(int dummy);

static volatile char run;
}

// display states, this contains the pointers to the res-managers.
std::vector<DisplayState *> d_state;

class ConfData *config;

ResManagerDispatchloop *qnx_dispatcher = 0;

int main(int numargs, char *const *args)
{
    int ret;
    int opt;
    int retcode;
    char tempstr[TMPSTR_SIZE];
    std::string err;
    std::string logfilename;
    std::vector<std::string> config_json_filelist;

    const char *configFile;

    qnx_dispatcher = 0;
    retcode = 0;
    logfile = new LogOutput(PM_DAEMON_PROGNAME);
    // parse args
    bNoDaemonize = false;
    debuglevel = 0;
    allow_commandQuit = 1;
    configFile = 0;
    config = 0;

    while ((opt = getopt(numargs, args, "dvc:h")) != -1) {
        switch (opt) {
            case 'c':
                configFile = optarg;
                break;

            case 'd':
                bNoDaemonize = true;
                debuglevel += 1;
                break;

            case 'v':
                debuglevel += 1;
                break;

            case 'h':
                printf("valid options:\n");
                printf(" -c <filename>     Specify config file.\n");
                printf(" -d                Do not daemonize, add debuglevel\n");
                printf(" -v                add debuglevel\n");
                printf(" -h                show list of options.\n");
                goto leave;

            default:
                retcode = 1; // not need for errormessage, was already printed
                             // by getopt().
                printf("for list of valid options, use '-h'.\n");
                goto leave;
        }
    }

    if (!configFile) {
        fprintf(
            stderr,
            "need to have a configfile to start the daemon. Use option -c .\n");
        retcode = 1;
        goto leave;
    }

    // load and parse config file (Do this before daemonizing).
    // cannot log yet, so report errors on stderr (path of logfile is in
    // configfile)
    config = ConfData::load_config(configFile, err_to_stderr);
    if (!config) {
        retcode = 1;
        goto leave;
    }

    // get some items from config
    if (config->logfile.size() <= 0) {
        printf("no logfile specified. Not generating any outputs in daemonized "
               "mode. Use 'logfile' in config file.\n");
        logfilename = "";
    } else
        logfilename = config->logfile;

    if (logfilename.size() > 0) {
        // If opening the log fails after daemonizing, we cannot report the
        // problem.
        // So try it here temporarily.
        bool log_can_open;
        log_can_open = logfile->init(logfilename.c_str(), false);
        if (!log_can_open) {
            // if not opened, logfile will redirect to stderr. So we can still
            // use it here.
            logfile->printf(
                "Cannot create or open the logfile '%s'. errno = %d.\n",
                logfilename.c_str(), (int) errno);
            goto leave;
        }
        // But do not hold a filehandle while daemonizing, so just open briefly
        // for testing.
        logfile->uninit();
    }

    if (config->debuglevel > debuglevel)
        debuglevel = config->debuglevel;

    // sanity checks on config
    if (config->displays.size() < 1) {
        logfile->printf("no displays configured.\n");
        goto leave;
    }

    if (!bNoDaemonize) {
        // daemonize. QNX has a helper function here, so not doing
        // the regular fork-setsid-close-fork as in linux.
        // This will close the stdin/stdout/stderr,
        // so cannot do regular printf after this point.
        ret = daemon(1, 0);

        if (ret) {
            fprintf(stderr, "call to daemon() failed.\n");
            retcode = 2;
            goto leave;
        }
    } else {
        // if not daemonized, and debuglevel>0, output all to stdout
        if (debuglevel > 0)
            logfile->enable_additional_stdout(true);
    }

    signal(SIGINT, sigINTHandler);
    signal(SIGUSR1, sigUSR1Handler);

    // Now really open the logfile.
    if (logfilename.size() > 0) {
        if (!logfile->init(logfilename.c_str(), config->use_slog2)) {
            // Oops. Cannot report this error. stderr is closed, and the logfile
            // failed to open the second time ...
            // The only way to safely prevent this is using a valid logfile name
            // which will not fail
            // opening after a brief open/close. Or hoping slogger2 never fails.
            logfile->printf(
                "failed to init logging."); // maybe stderr does go somewhere?
            retcode = 1;
            goto leave;
        }
    }

    // show name and version.
    line_to_logfile("FIDM-pm daemon version '%s'\n", PM_DAEMON_VERSION);
#if RESMGR_GLOBAL_STATE
    line_to_logfile("(warning: DEBUGmode. global state enabled!)\n");
#endif

    // Debug print the config.
    if (debuglevel > 0) {
        line_to_logfile("configuration file data:\n");
        config->debug_print_data(line_to_logfile);
        line_to_logfile("\n");
    }

    // Pick up our items from the config.

    // switch if 'quit' command is forbidden.
    config->get_item("forbid_cmd_quit", tempstr, sizeof(tempstr), "0");
    if (atoi(tempstr) > 0)
        allow_commandQuit = 0;

    //	// Check for unused items in config (normally typos). Will be sent as
    // warnings to the log.
    // .....        conffile_check_all_queried(config,check_unused_cb,tempstr);

    line_to_logfile("\n");

    // create the qnx dispatcher
    qnx_dispatcher = new ResManagerDispatchloop();

    // create the resource-managers.
    for (unsigned int i = 0; i < config->displays.size(); i++) {
        ConfData::DeviceSetting *sett;
        DisplayState *ds;
        ResMgrSusResComm *rm;
        DispinfraPMResMgr *rmp;
        const char *cpath, *spath;

        sett = config->displays[i];
        cpath = sett->dev_control.c_str();
        spath = sett->dev_status.c_str();

        ds = new DisplayState();
        d_state.push_back(ds);
        if (sett->name.size() > 0) {
            ds->name = sett->name;
        } else {
            char n[24];
            snprintf(n, sizeof(n), "display#%u", i + 1);
            ds->name = n;
        }
        printf("DEBUGG:::  getting name '%s'\n", sett->name.c_str());

        // start resource-manager for control
        rm = new ResMgrSusResComm(cpath, true, i);
        ds->resmgr_im_ctl = rm;
        if (!rm->start(&err, qnx_dispatcher)) {
            line_to_logfile(
                "error creating qnx resource manager for '%s' : %s\n", cpath,
                err.c_str());
            goto leave;
        }
        // start resource-manager for status
        rm = new ResMgrSusResComm(spath, false, i);
        ds->resmgr_im_sta = rm;
        if (!rm->start(&err, qnx_dispatcher)) {
            line_to_logfile(
                "error creating qnx resource manager for '%s' : %s\n", spath,
                err.c_str());
            goto leave;
        }

        // start power-management end resource-manager
        for (unsigned int j = 0; j < sett->pm_devices.size(); j++) {
            const ConfData::IfaceMgrNode *pmif;

            pmif = &(sett->pm_devices[j]);
            rmp = new DispinfraPMResMgr(pmif->pm_resmgr.c_str(), pmif->name,
                                        ds->resmgr_im_ctl);
            ds->resmgr_pm.push_back(rmp);
            if (rmp->start(qnx_dispatcher) == false) {
                line_to_logfile(
                    "error creating qnx resource manager for '%s'\n",
                    pmif->pm_resmgr.c_str());
                goto leave;
            }
        }
    }
    //	// create the qnx resource manager node.
    //	commandproc_s = new CmdProcWakeup();
    //	qnx_res_manager_s = new
    // ResMgrBase(config->status_path.c_str(),commandproc_s);
    //	if(!qnx_res_manager_s->start(&err,qnx_dispatcher))
    //	{
    //		line_to_logfile("Error creating qnx resource manager (stat):
    //%s\n",err.c_str());
    //		retcode = 2;
    //		goto leave;
    //	}

    run = 1;
    line_to_logfile("starting daemon. (send sig 15 to exit)\n");
    line_to_logfile("interface paths:\n");
    for (unsigned int i = 0; i < config->displays.size(); i++) {
        line_to_logfile("    status : '%s'\n",
                        config->displays[i]->dev_status.c_str());
        line_to_logfile("    control: '%s'\n",
                        config->displays[i]->dev_control.c_str());
    }
    line_to_logfile("(send sig 15 to exit)\n");

    // into the messagepump.
    //	qnx_res_manager_c->run_messageloop(&err);

    // run the message-loop with this mainthread.
    if (!qnx_dispatcher->run_messagepump(&err)) {
        retcode = 2;
        goto leave;
    }

    line_to_logfile("exiting daemon.\n");

leave:

    // stop/remove all resource-managers
    for (unsigned int i = 0; i < d_state.size(); i++) {
        DisplayState *ds = d_state[i];

        delete ds;
    }
    d_state.clear();

    // delete the dispatcher (should be free now)
    if (qnx_dispatcher)
        delete qnx_dispatcher;
    qnx_dispatcher = 0;

    // drop all our config data.
    if (config)
        delete config;

    if (logfile)
        delete logfile;
    logfile = 0;

    return retcode;
}

// handler for Ctrl-C (sig 15).
static void sigINTHandler(int dummy)
{
    run = 0;
    if (qnx_dispatcher)
        qnx_dispatcher->async_hint_stop();
}

static void sigUSR1Handler(int dummy)
{
}
