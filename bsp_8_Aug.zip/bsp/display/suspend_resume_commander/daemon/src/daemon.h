#ifndef SRC_DAEMON_H
#define SRC_DAEMON_H
/**
 * shared items header file for FIDM wakeup daemon
 *
 * This header declares some functions and global variables used across
 * different source files of the daemon process.
 *
 * CM/ESO2 Achim Dahlhoff.
 */
#include <map>
#include <string>
#include <vector>

#define PM_DAEMON_PROGNAME "sus_res_commander"
// version string.
#define PM_DAEMON_VERSION "0.1b"

#define DO_LOG_ALL_COMMANDS                                                    \
    0 // choose if all commands shall be sent to the log. If 0 and debuglevel is
      // 0, they are not logged.

// forward declarations
class ResMgrBase;
class ResMgrSusResComm;
class DispinfraPMResMgr;
class CmdProcPm;

// struct for holding all relevand handles for a display.
class DisplayState
{
  public:
    DisplayState();
    virtual ~DisplayState();

    // name of the display.
    std::string name;

    /* flag indicating if we are 'online' */
    bool is_online;

    // resource-managers for 'left' end, the instance-manager end of the daemon.
    ResMgrSusResComm *resmgr_im_ctl;
    ResMgrSusResComm *resmgr_im_sta;

    // resource-managers for 'right' end, the power-management end of the
    // daemon.
    std::vector<DispinfraPMResMgr *> resmgr_pm;
};

/**
 * Replybuffers are not pre-filehandle, but global.
 * This setting is only for testing. It breaks threadsafety.
 * It allows using from bash, where it is hard to send a line,
 * keep the filehandle open and read a reply from that filehandle.
 */
#define RESMGR_GLOBAL_STATE 0

class BoardIDdata;
class LogOutput;

/* properties taken from config file. */
extern class ConfData *config;

/* all our display states */
extern std::vector<DisplayState *> d_state;

extern "C" { // These two functions shall be passed to C APIs.
typedef void (*errPrintfFunc)(const char *msg, ...);

void err_to_stderr(const char *msg, ...);

// send some output to the daemon's logfile, and if '-d' is active, also to
// stdout.
void line_to_logfile(const char *msg, ...);

char *load_textfile(const char *filename, int *out_errno);
}

#endif
