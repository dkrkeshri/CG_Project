#include "daemon.h"
/**
 * display configuration daemon
 *
 * This file contains some generic helper functions and framework.
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "dispinfra-pm-resmgr.h"
#include "logoutput.h"
#include "resmgr_susrescomm.h"


bool is_online = false;

DisplayState::DisplayState()
{
    resmgr_im_ctl = 0;
    resmgr_im_sta = 0;
    is_online = false;
}

DisplayState::~DisplayState()
{
    for (unsigned int i = 0; i < resmgr_pm.size(); i++) {
        delete (resmgr_pm[i]);
    }
    resmgr_pm.clear();
    if (resmgr_im_ctl)
        delete resmgr_im_ctl;
    resmgr_im_ctl = 0;
    if (resmgr_im_sta)
        delete resmgr_im_sta;
    resmgr_im_sta = 0;
}

