#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include "dispinfra-pm-resmgr.h"

/*
 * This array contains string values for PM States
 * */

const char *DispinfraPMResMgr::pm_state_to_string[] =
    {[PM_STATE_PREPARE] = "prepare", [PM_STATE_SUSPEND] = "suspend",
     [PM_STATE_RESUME] = "resume", [PM_STATE_COMPLETE] = "complete",
     "", "", [PM_STATE_INVALID] = "invalid",};

/*
 * @brief Function to register a new client
 * @param[out] client Address of a pointer to type dispinfra_pm_client_t
 *                    This is where the new client will be stored
 * @param[in]  reg_data    A structure of type pm_register_s sent by the client
 * @param[in]  pid    PID of the client who wants to register
 * @return EOK on success and errno on failure
 */

int DispinfraPMResMgr::register_client(dispinfra_pm_client_t **client,
                                       const struct pm_register_s *reg_data,
                                       pid_t pid)
{
    DISPINFRA_PM_PRINT_DEBUG("register_client\n");
    if (reg_data->priority >= PM_PRIO_LEVEL_MAX) {
        return EINVAL;
    }

    /*Validate the pulse codes for duplicates*/
    for (unsigned i = 0; i < PM_STATE_MAX; i++) {
        if (reg_data->pulse_codes[i] == -1) {
            // ignore if client is not interested
            continue;
        }

        if (reg_data->pulse_codes[i] < _PULSE_CODE_MINAVAIL ||
            reg_data->pulse_codes[i] > _PULSE_CODE_MAXAVAIL) {
            DISPINFRA_PM_PRINT_ERROR("Pulse code %d out of range (%d,%d)\n",
                                     reg_data->pulse_codes[i],
                                     _PULSE_CODE_MINAVAIL,
                                     _PULSE_CODE_MAXAVAIL);
            return EINVAL;
        }

        for (unsigned j = i + 1; j < PM_STATE_MAX; j++) {
            if (reg_data->pulse_codes[i] == reg_data->pulse_codes[j]) {
                DISPINFRA_PM_PRINT_ERROR(
                    "Duplicate pulse code for \"%s(%d)\" and \"%s(%d)\"\n",
                    pm_state_to_string[i], reg_data->pulse_codes[i],
                    pm_state_to_string[j], reg_data->pulse_codes[j]);
                return EINVAL;
            }
        }
    }
    // TODO: C++ style casting
    dispinfra_pm_client_t *new_client =
        (dispinfra_pm_client_t *) calloc(1, sizeof(dispinfra_pm_client_t));
    if (!new_client) {
        return ENOMEM;
    }

    snprintf(new_client->name, sizeof(new_client->name), "%s:%d:%d",
             reg_data->name, pid, reg_data->chid);

    for (unsigned i = 0; i < PM_STATE_MAX; i++) {
        new_client->pulse_codes[i] = reg_data->pulse_codes[i];
    }

    new_client->coid = ConnectAttach(0, pid, reg_data->chid, _NTO_SIDE_CHANNEL,
                                     _NTO_COF_CLOEXEC);
    if (new_client->coid == -1) {
        DISPINFRA_PM_PRINT_ERROR(
            "ConnectAttach(pid=%d,chid=%d) failed, err=%d\b", pid,
            reg_data->chid, errno);
        free(new_client);
        return EINVAL;
    }

    new_client->current_state = PM_STATE_INVALID;

    *client = new_client;

    // TODO: Send an initial pulse to prepare/suspend

    DISPINFRA_PM_PRINT_DEBUG("Registered client= \"%s\" succesfully\n",
                             (*client)->name);

    return EOK;
}

/*
 * @brief Function to open a context of fidm-pm. This function registers
 *        as open call for the resource manager
 *
 */

int DispinfraPMResMgr::dispinfra_pm_open(resmgr_context_t *ctp, io_open_t *msg,
                                         RESMGR_HANDLE_T *handle, void *extra)
{
    dispinfra_pm_dev_t *dev = (dispinfra_pm_dev_t *) handle;
    int ret;

    if (dev->is_open == true) {
        return EBUSY;
    }

    ret = iofunc_open_default(ctp, msg, handle, extra);
    if (ret == EOK) {
        dev->is_open = true;
    }

    return ret;
}

/*
 * @brief Function to close a context of fidm-pm. This function registers
 *        as close for the resource manager
 *
 */

int DispinfraPMResMgr::dispinfra_pm_close(resmgr_context_t *ctp, void *reserved,
                                          RESMGR_OCB_T *ocb)
{
    dispinfra_pm_dev_t *dev = (dispinfra_pm_dev_t *) ocb->attr;
    // TODO: Do something
    if ((dev->client) && (dev->client->coid != -1)) {
        ConnectDetach(dev->client->coid);
    }
    free(dev->client);
    dev->client = NULL;
    dev->is_open = false;

    return EOK;
}

/*
 * @brief Function to perform devctl of fidm-pm resource manager. This function
 * registers
 *        as devctl/ioctl for the resource manager
 */

int DispinfraPMResMgr::dispinfra_pm_devctl(resmgr_context_t *ctp,
                                           io_devctl_t *msg, RESMGR_OCB_T *ocb)
{
    // TODO: Use C++ style casting
    dispinfra_pm_dev_t *dev = (dispinfra_pm_dev_t *) ocb->attr;
    int rc = iofunc_devctl_default(ctp, msg, (iofunc_ocb_t *) ocb);
    if (rc != _RESMGR_DEFAULT) {
        DISPINFRA_PM_PRINT_ERROR("devctl_default verify failed : %d", errno);
        return rc;
    }

    rc = iofunc_devctl_verify(
        ctp, msg, (IOFUNC_OCB_T *) ocb,
        _IO_DEVCTL_VERIFY_LEN | _IO_DEVCTL_VERIFY_MSG_LEN |
            _IO_DEVCTL_VERIFY_OCB_READ | _IO_DEVCTL_VERIFY_OCB_WRITE);
    if (rc != EOK) {
        DISPINFRA_PM_PRINT_ERROR("devctl_verify verify failed : %d\n", errno);
        return rc;
    }

    const int dcmd = msg->i.dcmd;
    switch (dcmd) {
        case DCMD_PM_REGISTER: {
            struct pm_register_s const *client_reg_data;

            if (msg->i.nbytes != sizeof(struct pm_register_s)) {
                return EINVAL;
            }

            client_reg_data = (struct pm_register_s *) _DEVCTL_DATA(msg->i);
            DISPINFRA_PM_PRINT_DEBUG("%s:%d wants to register with %s\n",
                                     client_reg_data->name, ctp->info.pid,
                                     dev->self->dispinfra_pm_device_name.c_str());
            return register_client(
                &dev->client, (struct pm_register_s *) _DEVCTL_DATA(msg->i),
                ctp->info.pid);
        } break;

        case DCMD_PM_ACK: {
            struct pm_ack_s *ack = (struct pm_ack_s *) _DEVCTL_DATA(msg->i);

            DISPINFRA_PM_PRINT_DEBUG("DCMD_PM_ACK with rc %d\n", ack->rc);
            if (ack->state < PM_STATE_PREPARE || ack->state >= PM_STATE_MAX) {
                return EINVAL;
            }

            if (dev->client->waiting_for_ack == false) {
                /*TODO: revisit*/
                return EOK;
            }
            DISPINFRA_PM_PRINT_DEBUG("DCMD_PM_ACK to be processed\n");
            dev->client->current_state = ack->state;
            dev->control_interface->finish_io__code(ack->rc);
            dev->self->stop_timer();
            dev->client->waiting_for_ack = false;
            // TODO: Revisit
        } break;

        default:
            DISPINFRA_PM_PRINT_ERROR("Wrong devctl received %d\n", dcmd);
            return ENOSYS;
    }
    return 0;
}

/*
 * @brief Constructor
 */

DispinfraPMResMgr::DispinfraPMResMgr(const char *path, std::string devname,
                                     ResMgrSusResComm *ctrlIF)
{
    dispinfra_pm_dev = new dispinfra_pm_dev_t();
    // TODO: error handling, smart pointers, use string??
    memset(dispinfra_pm_dev, 0, sizeof(*dispinfra_pm_dev));
    strncpy(dispinfra_pm_dev->path, path, sizeof(dispinfra_pm_dev->path));
    dispinfra_pm_dev->path[PATH_MAX - 1] = '\0';
    dispinfra_pm_dev->resmgr_id = -1;
    dispinfra_pm_dev->self = this;
    // TODO:throw exception if not valid pointer
    dispinfra_pm_dev->control_interface = ctrlIF;
    dispinfra_pm_dev->last_pulse_sent = PM_STATE_INVALID;
    dispinfra_pm_dev->timerID = -1;
    dispinfra_pm_dev->timerPulseCode = -1;
    dispinfra_pm_dev->timerCoid = -1;
    dispinfra_pm_device_name = devname;
}

/*
 * @brief destructor
 */
DispinfraPMResMgr::~DispinfraPMResMgr()
{
    if (dispinfra_pm_dev->client) {
        free(dispinfra_pm_dev->client);
    }

    delete dispinfra_pm_dev;
    dispinfra_pm_dev = nullptr;
}

bool DispinfraPMResMgr::start_timer(unsigned int msec)
{
    struct itimerspec tm;

    if (dispinfra_pm_dev->timerID < 0) {
        return false;
    }

    // set timer to one-shot, 2.5 seconds.
    if (msec < 1u) {
        msec = 1u;
    }
    tm.it_value.tv_sec = msec / 1000u;
    tm.it_value.tv_nsec = (msec % 1000u) * 1000000u;
    tm.it_interval.tv_sec = 0;
    tm.it_interval.tv_nsec = 0;
    timer_settime(dispinfra_pm_dev->timerID, 0, &tm, 0);

    return true;
}

void DispinfraPMResMgr::stop_timer()
{
    itimerspec itm;

    if (dispinfra_pm_dev->timerID < 0) {
        return;
    }

    memset(&itm, 0, sizeof(itm));
    timer_settime(dispinfra_pm_dev->timerID, 0, &itm, 0);
}

int DispinfraPMResMgr::timeout_handler(message_context_t *ctp, int code,
                                       uint32_t flags, void *handle)
{
    dispinfra_pm_dev_t *dev = (dispinfra_pm_dev_t *) handle;

    DISPINFRA_PM_PRINT_ERROR("Client on %s TIMEDOUT waiting ack for: %s\n",
                             dev->self->dispinfra_pm_device_name.c_str(),
                             pm_state_to_string[dev->last_pulse_sent]);
    dev->control_interface->finish_io__timedout();

    return 0;
}

bool DispinfraPMResMgr::timer_pulse_init(ResManagerDispatchloop *dispatcher)
{
    struct sigevent event;
    dispatch_t *dp = (dispatch_t *) dispatcher->get_dispatch_handle();

    dispinfra_pm_dev->timerPulseCode = pulse_attach(
        dp, MSG_FLAG_ALLOC_PULSE, 1, &timeout_handler, dispinfra_pm_dev);
    if (dispinfra_pm_dev->timerPulseCode == -1) {
        DISPINFRA_PM_PRINT_ERROR("pulse_attach() failed, err=%s\n", strerror(errno));
        return false;
    }

    dispinfra_pm_dev->timerCoid = message_connect(dp, MSG_FLAG_SIDE_CHANNEL);
    if (dispinfra_pm_dev->timerCoid == -1) {
        DISPINFRA_PM_PRINT_ERROR("message connect failed %s\n", strerror(errno));
        return false;
    }

    event.sigev_priority = SIGEV_PULSE_PRIO_INHERIT;
    event.sigev_notify = SIGEV_PULSE;
    event.sigev_code = (short) dispinfra_pm_dev->timerPulseCode;
    event.sigev_value.sival_ptr = NULL;
    event.sigev_coid = dispinfra_pm_dev->timerCoid;

    if (EOK !=
        timer_create(CLOCK_REALTIME, &event, &dispinfra_pm_dev->timerID)) {
        DISPINFRA_PM_PRINT_ERROR("timer_create() failed, err=%s", strerror(errno));
        return false;
    }

    return true;
}

/*
 * @brief initialize resource manager data structures and attach with an
 *        exiting dispatch handle
 */
bool DispinfraPMResMgr::start(ResManagerDispatchloop *dispatcher)
{
    //	printf("ENTRY\n");
    // TODO: c++ stype casting
    int ret;
    dispinfra_pm_dev->dp = (dispatch_t *) dispatcher->get_dispatch_handle();
    if (NULL == dispinfra_pm_dev->dp) {
        DISPINFRA_PM_PRINT_ERROR("Unable to get dispatach handle\n");
        return false;
    }

    ret = timer_pulse_init(dispatcher);
    if (ret == false) {
        DISPINFRA_PM_PRINT_ERROR("Unable to create timer\n");
        stop();
        return false;
    }
    memset(&dispinfra_pm_dev->resmgr_attr, 0, sizeof(resmgr_attr_t));
    dispinfra_pm_dev->resmgr_attr.nparts_max = 1;
    dispinfra_pm_dev->resmgr_attr.msg_max_size = 2048;

    iofunc_func_init(_RESMGR_CONNECT_NFUNCS, &dispinfra_pm_dev->connect_funcs,
                     _RESMGR_IO_NFUNCS, &dispinfra_pm_dev->io_funcs);
    iofunc_attr_init(&dispinfra_pm_dev->io_attr, 0666, NULL, NULL);

    /*ovewrite default functions*/
    dispinfra_pm_dev->connect_funcs.open = dispinfra_pm_open;
    dispinfra_pm_dev->io_funcs.devctl = dispinfra_pm_devctl;
    dispinfra_pm_dev->io_funcs.close_ocb = dispinfra_pm_close;

    dispinfra_pm_dev->resmgr_id = resmgr_attach(
        dispinfra_pm_dev->dp, &dispinfra_pm_dev->resmgr_attr,
        dispinfra_pm_dev->path, _FTYPE_ANY, 0, &dispinfra_pm_dev->connect_funcs,
        &dispinfra_pm_dev->io_funcs, (RESMGR_HANDLE_T *) dispinfra_pm_dev);

    if (-1 == dispinfra_pm_dev->resmgr_id) {
        DISPINFRA_PM_PRINT_ERROR("resmgr_attach FAILED: %d\n", errno);
        stop();
        return false;
    }

    return true;
}

/*
 * @brief de-initialize resource manager data structures
 */
void DispinfraPMResMgr::stop()
{
    if (dispinfra_pm_dev->timerCoid != -1) {
        ConnectDetach_r(dispinfra_pm_dev->timerCoid);
        dispinfra_pm_dev->timerCoid = -1;
    }

    if ((dispinfra_pm_dev->timerPulseCode != -1) && dispinfra_pm_dev->dp) {
        pulse_detach(dispinfra_pm_dev->dp, dispinfra_pm_dev->timerPulseCode, 0);
        dispinfra_pm_dev->timerPulseCode = -1;
    }
    if (dispinfra_pm_dev->timerID != -1) {
        timer_delete(dispinfra_pm_dev->timerID);
        dispinfra_pm_dev->timerID = -1;
    }

    if ((dispinfra_pm_dev->resmgr_id != -1) && (dispinfra_pm_dev->dp)) {
        resmgr_detach(dispinfra_pm_dev->dp, dispinfra_pm_dev->resmgr_id,
                      _RESMGR_DETACH_ALL);
        dispinfra_pm_dev->resmgr_id = -1;
    }

    dispinfra_pm_dev->dp = NULL;
}

/*
 * @brief gets the client name
 */
std::string DispinfraPMResMgr::get_client_name() const
{
    std::string client_name = "";
    if (dispinfra_pm_dev->client) {
        client_name = dispinfra_pm_dev->client->name;
    }
    return client_name;
}

/*
 * @brief gets the fidm pm resource manager path
 */
/*
std::string DispinfraPMResMgr::get_resmgr_path_name() const
{
        std::string path_name = "";
        if(dispinfra_pm_dev){
                path_name = dispinfra_pm_dev->path;
        }
        return path_name;
}
*/
/*
 * @brief gets the fidm pm device name
 */
std::string DispinfraPMResMgr::get_device_name() const
{
    return dispinfra_pm_device_name;
}

/*
 * @brief gets the current state of the registered client.
 *        returns a empty string if no client is registered
 */

std::string DispinfraPMResMgr::get_client_state() const
{
    enum pm_state cur_state;
    std::string client_state = "uninitialized";

    if (dispinfra_pm_dev->client) {
        cur_state = dispinfra_pm_dev->client->current_state;
        client_state = pm_state_to_string[cur_state];
    }

    return client_state;
}

/*
 * @brief This function converts string PM state to enum
 */

enum pm_state DispinfraPMResMgr::string_to_pm_state(std::string state)
{
    if (state == "prepare") {
        return PM_STATE_PREPARE;
    } else if (state == "suspend") {
        return PM_STATE_SUSPEND;
    } else if (state == "resume") {
        return PM_STATE_RESUME;
    } else if (state == "complete") {
        return PM_STATE_COMPLETE;
    } else {
        return PM_STATE_INVALID;
    }
}

/*
 * @brief send pulse to client
 * @param[in] state string representing a PM state
 */

int DispinfraPMResMgr::send_pulse_to_client(std::string state)
{
    int ret = -1;
    dispinfra_pm_client_t *client = dispinfra_pm_dev->client;
    enum pm_state pulse = string_to_pm_state(state);

    if (client == NULL) {
        DISPINFRA_PM_PRINT_ERROR("No registered client with %s",
                                 dispinfra_pm_dev->path);
        return ENODEV;
    }

    if (pulse == PM_STATE_INVALID) {
        DISPINFRA_PM_PRINT_ERROR("Invalid Argument: %s\n", state.c_str());
        return EINVAL;
    }

    if (client->pulse_codes[pulse] == -1) {
        DISPINFRA_PM_PRINT_DEBUG("Warning! Client %s "
                                 "did not register for \"%s\" pulse\n",
                                 client->name, state.c_str());
        /*TODO: Revisit*/
        return EOK;
    }

    if (client->waiting_for_ack == true) {
        DISPINFRA_PM_PRINT_DEBUG(
            "Awaiting previous acknowledgement from %s"
            "cannot send \"%s\" pulse\n"
            "last pulse sent %s\n",
            client->name, state.c_str(),
            pm_state_to_string[dispinfra_pm_dev->last_pulse_sent]);
        return EBUSY;
    }

    DISPINFRA_PM_PRINT_DEBUG("send_pulse_to_client %s %s\n", client->name,
                             state.c_str());

    ret = MsgSendPulse_r(client->coid, -1, client->pulse_codes[pulse], 0);
    if (ret == EOK) {
        start_timer(TIMEOUT_MS);
        dispinfra_pm_dev->control_interface->stall_io();
        dispinfra_pm_dev->last_pulse_sent = pulse;
        client->waiting_for_ack = true;
    } else {
        DISPINFRA_PM_PRINT_ERROR("MsgSendPulse failed: %s\n", strerror(ret));
    }

    return ret;
}
