#include "configfile_data.h"

/**
 * config file parser
 *
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <set>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "daemon.h"
#include "smalljs.h"

static void out_to_stdout(const char *msg, ...);

ConfData::~ConfData()
{
    drop_data();
}

/**
 * Load and parse a config file, create the ConfData item,
 * and place all usable values from the config inside it.
 *
 */
ConfData *ConfData::load_config(const char *filename, errPrintfFunc errfunc)
{
    ConfData *res = 0;
    int err;
    bool success = false;
    std::string errtxt;
    JSDataNode *js = 0;
    char *buffer = 0;

    if (!errfunc)
        errfunc = out_to_stdout;

    err = 0;
    buffer = load_textfile(filename, &err);
    if (!buffer) {
        errfunc("error loading config file '%s', errno=%d\n", filename, err);
        goto leave;
    }

    // have file. send to json parser.
    js = parse_json(buffer, &errtxt);
    if (!js) {
        if (errtxt.size() > 0)
            errfunc("error parsing config json data:  %s\n", errtxt.c_str());
        else
            errfunc("error parsing config json data\n");
        goto leave;
    }

    // top level shall be an object
    if (js->type != JSTYPE_object) {
        errfunc("top level of json config file shall be an 'object'.\n");
        goto leave;
    }

    // create res
    res = new ConfData();

    // peel out parts we need.
    errtxt = "";
    if (!res->extract_data_from_json((JSDataNodeObject *) js, &errtxt)) {
        errfunc("failed to parse config file:  %s\n", errtxt.c_str());
        goto leave;
    }

    success = true;

leave:
    if (buffer)
        free(buffer);
    if (js)
        delete js;
    if (res && !success) {
        delete res;
        res = 0;
    }

    return res;
}

void ConfData::debug_print_data(errPrintfFunc printffunc) const
{
    std::vector<DeviceSetting *>::const_iterator it;

    for (it = displays.begin(); it != displays.end(); ++it) {
        const DeviceSetting *s;
        std::vector<IfaceMgrNode>::const_iterator it2;

        s = *it;
        printffunc("display: '%s'\n", s->name.c_str());
        printffunc("  dev_control: '%s'\n", s->dev_control.c_str());
        printffunc("  dev_status: '%s'\n", s->dev_status.c_str());
        for (it2 = s->pm_devices.begin(); it2 != s->pm_devices.end(); ++it2) {
            printffunc("  pm-device '%s'\n", it2->name.c_str());
            printffunc("    pm-resmgr: '%s'\n", it2->pm_resmgr.c_str());
        }
    }
}

bool ConfData::get_item(const char *itemname, std::string *out_result,
                        const char *defaultvalue)
{
    // todo: .....
    return false;
}

bool ConfData::get_item(const char *itemname, char *out_result,
                        int result_buffersize, const char *defaultvalue)
{
    std::string tmp;
    int ln;
    if (!get_item(itemname, &tmp, defaultvalue))
        return false;
    ln = tmp.size();
    if (ln >= result_buffersize)
        ln = result_buffersize - 1;
    if (ln > 0) {
        memcpy(out_result, tmp.c_str(), ln);
        out_result[ln] = 0;
    }
    return true;
}

ConfData::ConfData()
{
    use_slog2 = true;
    debuglevel = 0;
    allow_quit = false;
}

void ConfData::drop_data()
{
    std::vector<DeviceSetting *>::iterator it;

    for (it = displays.begin(); it != displays.end(); ++it) {
        delete *it;
    }
    displays.clear();
}

/**
 * Process the parsed json data from the config file.
 * All usable values found are placed into the fields in
 * the class' instance.
 *
 * In case failure, the string *out_err is filled with
 * a meaningful error message such as which field is missing.
 *
 * Return true if successful.
 */
bool ConfData::extract_data_from_json(class JSDataNodeObject *js,
                                      std::string *out_err)
{
    JSDataNode *ch;
    JSDataNodeArray *cha;
    std::string tmps;

    drop_data();

    // get 'logfile'
    ch = js->get("logfile");
    if (ch) {
        if (ch->type != JSTYPE_string) {
            *out_err =
                "config section 'logfile', if present, shall be a string.";
            return false;
        }
        logfile = ((JSDataNodeString *) ch)->text;
    }

    // get 'slog2'
    ch = js->get("slog2");
    if (ch) {
        if (ch->type != JSTYPE_bool) {
            *out_err =
                "config section 'slog2', if present, shall be a boolean.";
            return false;
        }
        use_slog2 = ((JSDataNodeBool *) ch)->flag;
    }

    // get 'devices'
    ch = js->get("devices");
    if (!ch || ch->type != JSTYPE_array ||
        ((JSDataNodeArray *) ch)->count() < 1) {
        *out_err =
            "config section 'devices' shall exist and be an non-empty array.";
        return false;
    }
    cha = (JSDataNodeArray *) ch;
    for (unsigned int i = 0; i < cha->count(); i++) {
        DeviceSetting *data;

        ch = cha->get(i);
        if (!ch || ch->type != JSTYPE_object) {
            *out_err = "config items under 'devices' shall be objects.";
            return false;
        }
        data = extract_devicedata_from_json((JSDataNodeObject *) ch, out_err);
        if (!data)
            return false;
        displays.push_back(data);
    }

    // after all reading, check if paths are consistent.
    if (!check_all_devpaths(&tmps)) {
        *out_err = "invalid path '";
        *out_err += tmps;
        *out_err += "'. name must be dev-path, and all dev-paths in config "
                    "must be unique.";
        return false;
    }

    return true;
}

ConfData::DeviceSetting *ConfData::extract_devicedata_from_json(
    class JSDataNodeObject *js, std::string *out_err)
{
    DeviceSetting *res;
    JSDataNode *ch;
    JSDataNodeObject *cho;
    JSDataNodeArray *cha;

    res = new DeviceSetting();

    // get 'name'
    if (!get_string_item(js, &(res->name), "name", "")) {
        *out_err =
            "config section for 'name' of a device shall be of type string.";
        delete res;
        return 0;
    }

    // device-nodes
    ch = js->get("device-nodes");
    if (!ch || ch->type != JSTYPE_object) {
        *out_err =
            "config section 'device-nodes' must be present and an object.";
        delete res;
        return 0;
    }
    cho = (JSDataNodeObject *) ch;

    // status and control
    if (!get_string_item(cho, &(res->dev_status), "status", 0)) {
        *out_err =
            "config section 'device-nodes' must contain a string 'status'.";
        delete res;
        return 0;
    }
    if (!get_string_item(cho, &(res->dev_control), "control", 0)) {
        *out_err =
            "config section 'device-nodes' must contain a string 'control'.";
        delete res;
        return 0;
    }

    // exported-pm-devices
    ch = js->get("exported-pm-devices");
    if (!ch || ch->type != JSTYPE_array ||
        ((JSDataNodeArray *) ch)->count() < 1) {
        *out_err = "config section 'exported-pm-devices' must be present and "
                   "an array with at least one item.";
        delete res;
        return 0;
    }
    cha = (JSDataNodeArray *) ch;

    for (unsigned int i = 0; i < cha->count(); i++) {
        IfaceMgrNode data;

        ch = cha->get(i);
        if (!ch || ch->type != JSTYPE_object) {
            *out_err =
                "config items under 'exported-pm-devices' shall be objects.";
            delete res;
            return 0;
        }
        cho = (JSDataNodeObject *) ch;

        // name and dev-node
        if (!get_string_item(cho, &(data.name), "name", 0)) {
            *out_err = "config sections under 'exported-pm-devices' must each "
                       "contain a string 'name'.";
            delete res;
            return 0;
        }
        if (!get_string_item(cho, &(data.pm_resmgr), "path", 0)) {
            *out_err = "config sections under 'exported-pm-devices' must each "
                       "contain a string 'path'.";
            delete res;
            return 0;
        }

        res->pm_devices.push_back(data);
    }

    return res;
}

bool ConfData::check_all_devpaths(std::string *failed_name) const
{
    std::set<std::string> co;
    std::vector<DeviceSetting *>::const_iterator it;
    const std::string *n;

    for (it = displays.begin(); it != displays.end(); ++it) {
        const DeviceSetting *s;
        std::vector<IfaceMgrNode>::const_iterator it2;

        s = *it;

        n = &(s->dev_control);
        if (!check_devpath(*n) || co.find(*n) != co.end()) {
            *failed_name = *n;
            return false;
        }
        n = &(s->dev_status);
        if (!check_devpath(*n) || co.find(*n) != co.end()) {
            *failed_name = *n;
            return false;
        }
        for (it2 = s->pm_devices.begin(); it2 != s->pm_devices.end(); ++it2) {
            n = &(it2->pm_resmgr);
            if (!check_devpath(*n) || co.find(*n) != co.end()) {
                *failed_name = *n;
                return false;
            }
        }
    }
    return true;
}

bool ConfData::check_devpath(const char *name)
{
    int l;

    // not empty, start witn '/'.
    if (!name)
        return false;
    l = strlen(name);
    if (*name != '/')
        return false;
    // do not end with '/'.
    if (name[l - 1] == '/')
        return false;
    // todo: must start with '/dev/' ?
    // ok.
    return true;
}

bool ConfData::check_devpath(const std::string &name)
{
    return ConfData::check_devpath(name.c_str());
}

bool ConfData::get_string_item(class JSDataNodeObject *js, std::string *out_val,
                               const char *name, const char *def_value)
{
    JSDataNode *ch;

    // get item
    ch = js->get(name);
    if (ch) // item is found.
    {
        if (ch->type != JSTYPE_string)
            return false;
        *out_val = ((JSDataNodeString *) ch)->text;
    } else {
        // item is not found.
        if (!def_value) // no item and no default-value is an error.
            return false;
        *out_val = def_value;
    }
    return true;
}

char *load_textfile(const char *filename, int *out_errno)
{
    int fh;
    int tmp;
    off_t fsize;
    char *res;

    // open filehandle.
    fh = open(filename, O_RDONLY);
    if (fh < 0) {
        *out_errno = errno;
        if (!*out_errno)
            *out_errno = EINVAL;
        return 0;
    }
    // get filesize
    fsize = lseek(fh, 0, SEEK_END);
    if (fsize == -1 && errno != 0) {
        close(fh);
        *out_errno = errno;
        return 0;
    }
    lseek(fh, 0, SEEK_SET);

    if (fsize > 0x100000 || fsize < 1) {
        close(fh);
        *out_errno = -EINVAL;
        return 0;
    }

    /* alloc space for data. */
    res = (char *) malloc(fsize + 3);
    if (!res) {
        close(fh);
        *out_errno = ENOMEM;
        return 0;
    }
    memset(res + fsize, 0, 3); /* append 3 null bytes */

    /* load file data */
    fsize -= read(fh, res, fsize);
    tmp = errno;
    close(fh);
    fh = 0;

    if (fsize) {
        free(res);
        *out_errno = tmp;
        if (!tmp)
            *out_errno = EIO;
        return 0;
    }

    return res;
}

static void out_to_stdout(const char *msg, ...)
{
    va_list val;
    va_start(val, msg);

    (void)vprintf(msg, val);
    printf("\n");

    va_end(val);
}
