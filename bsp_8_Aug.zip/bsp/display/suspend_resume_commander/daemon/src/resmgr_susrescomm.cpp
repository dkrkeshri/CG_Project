#include "resmgr_susrescomm.h"

#include "daemon.h"
#include "dispinfra-pm-resmgr.h"

/**
 * This class handles commands received by the resource-manager frontend.
 *
 * For the commands and how they are interpreted, check the README file.
 *
 * CM/ESOS2 Achim Dahlhoff
 */

static class DispinfraPMResMgr *find_pm_end(int displaynum, const char *name);

ResMgrSusResComm::ResMgrSusResComm(const char *path, bool is_control,
                                   int display_number)
    : ResMgrBase(path, "type fidm-pm")
{
    timerID = -1;
    timerPCode = -1;
    timerPcoid = -1;
    dsp_number = display_number;
    is_control_rmgr = is_control;
}

ResMgrSusResComm::~ResMgrSusResComm()
{
    stop_timer(true);
}

bool ResMgrSusResComm::start(std::string *out_err,
                             ResManagerDispatchloop *dispatcher)
{
    int ret;
    dispatch_t *dpp;

    if (!ResMgrBase::start(out_err, dispatcher))
        return false;

    dpp = (dispatch_t *) dispatcher->get_dispatch_handle();
    ret = pulse_attach(
        dpp, MSG_FLAG_ALLOC_PULSE, 1,
        (int (*)(message_context_t *, int, unsigned, void *)) timer_callback,
        this);
    if (ret < 0) {
        *out_err = "could not allocate a pulse for timers with pulse_attach().";
        stop();
        return false;
    }
    timerPCode = ret;

    // 'connect' to get a coid.
    errno = 0;
    ret = message_connect(dpp, 0);
    if (ret == -1) {
        *out_err = "cannot message_connect() to self for timer.";
        stop();
        return false;
    }
    timerPcoid = ret;

    return true;
}

void ResMgrSusResComm::stop()
{
    stop_timer(true);

    if (timerPcoid >= 0)
        ConnectDetach_r(timerPcoid);
    timerPcoid = -1;

    if (get_dispatcher()) {
        dispatch_t *dpp;
        dpp = (dispatch_t *) get_dispatcher()->get_dispatch_handle();

        if (timerPCode >= 0 && dpp)
            pulse_detach(dpp, timerPCode, 0);
    }
    timerPCode = -1;

    ResMgrBase::stop();
}

void ResMgrSusResComm::stall_io()
{
    mark_process_cmd_hang();
}

void ResMgrSusResComm::finish_io__code(int retval)
{
    char rep[512];
    int l;
    l = snprintf(rep, sizeof(rep) - 1, "%d\nClient Return Code\n", retval);
    if (l < 0)
        l = sizeof(rep) - 1;
    rep[l] = 0;
    mark_process_finished(rep);
}

void ResMgrSusResComm::finish_io__timedout()
{
    char rep[512];
    int l;
    l = snprintf(rep, sizeof(rep) - 1, "%d\nclient timed out.\n",
                 (int) ETIMEDOUT);
    if (l < 0)
        l = sizeof(rep) - 1;
    rep[l] = 0;
    mark_process_finished(rep);
}

bool ResMgrSusResComm::process_command(const char *command)
{
    char cmdword[16];
    const char *cmdarg;
    int i;

    // skip leading whitespace
    while (*command == ' ' || *command == '\t')
        command++;

    // copy command-word
    for (i = 0; i + 1 < (int) sizeof(cmdword); i++) {
        char b = command[i];
        if (b == 0 || b == ' ' || b == '\t' || b == '\n' || b == '\r')
            break;
        cmdword[i] = b;
    }
    cmdword[i] = 0;
    cmdarg = command + i;
    // skip whitespace
    while (*cmdarg == ' ' || *cmdarg == '\t')
        cmdarg++;

    // check command.
    if (!strcmp(cmdword, "list")) {
        process_command_list(cmdarg);
    } else if (!strcmp(cmdword, "version")) {
        process_command_version(cmdarg);
#if RESMGR_GLOBAL_STATE
        printfn(printfn_ctx, "(warning: DEBUGmode. global state enabled!)\n");
#endif
    } else if (!strcmp(cmdword, "prepare")) {
        process_command_prepare(cmdarg);
    } else if (!strcmp(cmdword, "suspend")) {
        process_command_suspend(cmdarg);
    } else if (!strcmp(cmdword, "resume")) {
        process_command_resume(cmdarg);
    } else if (!strcmp(cmdword, "complete")) {
        process_command_complete(cmdarg);
    } else if (!strcmp(cmdword, "status")) {
        process_command_status(cmdarg);
    } else if (!strcmp(cmdword, "online")) {
        process_command_online(cmdarg);
    } else if (!strcmp(cmdword, "quit")) {
        process_command_quit(cmdarg);
    } else {
        // unknown command.
        printrep("%d\nunknown daemon command '%s'\n", (int) EINVAL, cmdword);
    }

    return true;
}

int ResMgrSusResComm::get_display_num() const
{
    return dsp_number;
}

bool ResMgrSusResComm::get_is_control() const
{
    return is_control_rmgr;
}

void ResMgrSusResComm::process_command_list(const char *command)
{
    std::vector<DispinfraPMResMgr *>::const_iterator it;
    const DisplayState *dstat;
    dstat = d_state[dsp_number];

    printrep("0\n");

    for (it = dstat->resmgr_pm.begin(); it != dstat->resmgr_pm.end(); ++it) {
        std::string name = (*it)->get_device_name();
        printrep("%s\n", name.c_str());
    }
}

void ResMgrSusResComm::process_command_prepare(const char *command)
{
    std::string name;
    class DispinfraPMResMgr *pm;
    int dnum;
    DisplayState *dstat;
    int ret;

    if (get_quot_string(&command, &name)) {
        printrep("%d\n'prepare' needs a quoted id as argument.\n", EINVAL);
        return;
    }

    dnum = get_display_num();
    pm = find_pm_end(dnum, name.c_str());
    if (!pm) {
        printrep("%d\npm name '%s' not found.\n", ENOENT, name.c_str());
        return;
    }

    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }

    dstat = d_state[dnum];

    if (!dstat->is_online) {
        printrep("%d\ndaemon not switched to online.\n", EINVAL);
        return;
    }

    ret = pm->send_pulse_to_client("prepare");
    if (ret != EOK) {
        printrep("%d\ncould not send pulse to client.\n", ret);
        return;
    }
    printrep("0\nSuccess.\n");
    ;
}

void ResMgrSusResComm::process_command_suspend(const char *command)
{
    std::string name;
    class DispinfraPMResMgr *pm;
    int dnum;
    DisplayState *dstat;
    int ret;

    if (get_quot_string(&command, &name)) {
        printrep("%d\n'suspend' needs a quoted id as argument.\n", EINVAL);
        return;
    }

    dnum = get_display_num();
    pm = find_pm_end(dnum, name.c_str());
    if (!pm) {
        printrep("%d\npm name '%s' not found.\n", ENOENT, name.c_str());
        return;
    }

    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }

    dstat = d_state[dnum];

    if (!dstat->is_online) {
        printrep("%d\ndaemon not switched to online.\n", EINVAL);
        return;
    }

    ret = pm->send_pulse_to_client("suspend");
    if (ret != EOK) {
        printrep("%d\ncould not send pulse to client.\n", ret);
        return;
    }
    printrep("0\nSuccess.\n");
}

void ResMgrSusResComm::process_command_resume(const char *command)
{
    std::string name;
    class DispinfraPMResMgr *pm;
    int dnum;
    DisplayState *dstat;
    int ret;

    if (get_quot_string(&command, &name)) {
        printrep("%d\n'resume' needs a quoted id as argument.\n", EINVAL);
        return;
    }

    dnum = get_display_num();
    pm = find_pm_end(dnum, name.c_str());
    if (!pm) {
        printrep("%d\npm name '%s' not found.\n", ENOENT, name.c_str());
        return;
    }

    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }

    dstat = d_state[dnum];

    if (!dstat->is_online) {
        printrep("%d\ndaemon not switched to online.\n", EINVAL);
        return;
    }

    ret = pm->send_pulse_to_client("resume");
    if (ret != EOK) {
        printrep("%d\ncould not send pulse to client.\n", ret);
        return;
    }
    printrep("0\nSuccess.\n");
}

void ResMgrSusResComm::process_command_complete(const char *command)
{
    std::string name;
    class DispinfraPMResMgr *pm;
    int dnum;
    DisplayState *dstat;
    int ret;

    if (get_quot_string(&command, &name)) {
        printrep("%d\n'complete' needs a quoted id as argument.\n", EINVAL);
        return;
    }

    dnum = get_display_num();
    pm = find_pm_end(dnum, name.c_str());
    if (!pm) {
        printrep("%d\npm name '%s' not found.\n", ENOENT, name.c_str());
        return;
    }

    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }

    dstat = d_state[dnum];

    if (!dstat->is_online) {
        printrep("%d\ndaemon not switched to online.\n", EINVAL);
        return;
    }

    ret = pm->send_pulse_to_client("complete");
    if (ret != EOK) {
        printrep("%d\ncould not send pulse to client.\n", ret);
        return;
    }
    printrep("0\nSuccess.\n");
}

void ResMgrSusResComm::process_command_status(const char *command)
{
    std::string name;
    std::string status_str;
    class DispinfraPMResMgr *pm;
    int dnum;
    DisplayState *dstat;

    if (get_quot_string(&command, &name)) {
        printrep("%d\n'status' needs a quoted id as argument.\n", EINVAL);
        return;
    }

    dnum = get_display_num();

    if (!strcmp(name.c_str(), "online")) {
        dstat = d_state[dnum];
        if (dstat->is_online)
            printrep("0\non\n");
        else
            printrep("0\noff\n");
        return;
    }

    pm = find_pm_end(dnum, name.c_str());
    if (!pm) {
        printrep("%d\npm name '%s' not found.\n", ENOENT, name.c_str());
        return;
    }

    status_str = pm->get_client_state();
    if (status_str.size() < 1) {
        printrep("-1\nError getting status (empty string).\n");
        return;
    }

    printrep("0\n%s\n", status_str.c_str());
}

void ResMgrSusResComm::process_command_online(const char *command)
{
    // argument is '0' or '1' or 'off' or 'on' or 'false' or 'true'.
    DisplayState *dstat;
    int val = -1;

    if (!*command) {
        printrep("%d\nonline command needs an argument.\n\n", EINVAL);
        return;
    }

    if (!strncmp(command, "0", 1) || !strncmp(command, "off", 3) ||
        !strncmp(command, "false", 5) || !strncmp(command, "False", 5))
        val = 0;
    if (!strncmp(command, "1", 1) || !strncmp(command, "on", 2) ||
        !strncmp(command, "true", 4) || !strncmp(command, "True", 4))
        val = 1;

    if (val < 0) {
        printrep(
            "%d\ninvalid value '%s' for online command. use 'off' or 'on'.\n\n",
            EINVAL, command);
        return;
    }

    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }

    dstat = d_state[get_display_num()];

    dstat->is_online = (val > 0);
    printrep("0\n%s", (dstat->is_online ? "on" : "off"));
}

void ResMgrSusResComm::process_command_version(const char *command)
{
    printrep("0\n%s\n", PM_DAEMON_VERSION);
}

void ResMgrSusResComm::process_command_quit(const char *command)
{
    if (!allow_commandQuit) {
        printrep("%d\nQuit command forbidden through config.\n", EPERM);
        return;
    }
    if (!is_control_rmgr) {
        printrep("%d\ncommand not valid on status-handle.\n", (int) EPERM);
        return;
    }
    printrep("0\n"); // the client will not be able to pick this up in time...
    line_to_logfile("client command 'quit' received.\n");
    (void)raise(SIGINT);
}

bool ResMgrSusResComm::start_timer(unsigned int msec)
{
    struct itimerspec tm;

    // if timer is not yet created, do it now.
    if (timerID < 0) {
        struct sigevent ev;
        memset(&ev, 0, sizeof(ev));
        SIGEV_SET_TYPE(&ev, SIGEV_PULSE);
        ev.sigev_coid = timerPcoid;
        ev.sigev_priority = SIGEV_PULSE_PRIO_INHERIT;
        ev.sigev_code = timerPCode;
        ev.sigev_value.sival_ptr = (void *) (uintptr_t) 666; // not used.
        if (timer_create(CLOCK_MONOTONIC, &ev, &timerID)) {
            timerID = -1;
            return false;
        }
    }

    // set timer to one-shot, 2.5 seconds.
    if (msec < 1u)
        msec = 1u;
    tm.it_value.tv_sec = msec / 1000u;
    tm.it_value.tv_nsec = (msec % 1000u) * 1000000u;
    tm.it_interval.tv_sec = 0;
    tm.it_interval.tv_nsec = 0;
    timer_settime(timerID, 0, &tm, 0);

    return true;
}

void ResMgrSusResComm::stop_timer(bool deallocate)
{
    itimerspec itm;

    if (timerID < 0)
        return;

    memset(&itm, 0, sizeof(itm));
    timer_settime(timerID, 0, &itm, 0);

    if (deallocate) {
        timer_delete(timerID);
        timerID = -1;
    }
}

int ResMgrSusResComm::timer_callback(void *_ctp, int code, unsigned flags,
                                     void *handle)
{
    ResMgrSusResComm *self;

    self = (ResMgrSusResComm *) handle;

    printf("DEBUG: PMtimer ended.  code=%d\n", code);

    // is timeout.
    self->mark_process_finished("-1\ntimed out.\n");

    return 0;
}

static class DispinfraPMResMgr *find_pm_end(int displaynum, const char *name)
{
    std::vector<DispinfraPMResMgr *>::const_iterator it;
    const DisplayState *dstat;
    dstat = d_state[displaynum];

    for (it = dstat->resmgr_pm.begin(); it != dstat->resmgr_pm.end(); ++it) {
        std::string nam = (*it)->get_device_name();
        if (!strcmp(nam.c_str(), name))
            return (*it);
    }
    return 0;
}
