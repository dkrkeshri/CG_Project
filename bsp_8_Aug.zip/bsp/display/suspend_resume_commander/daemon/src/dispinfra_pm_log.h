#ifndef _DISPINFRA_PM_LOG_H_
#define _DISPINFRA_PM_LOG_H_
#include "daemon.h"

#define DISPINFRA_PM_PRINT_ERROR(...) line_to_logfile(__VA_ARGS__)
#define DISPINFRA_PM_PRINT_DEBUG(...) line_to_logfile(__VA_ARGS__)

#endif
