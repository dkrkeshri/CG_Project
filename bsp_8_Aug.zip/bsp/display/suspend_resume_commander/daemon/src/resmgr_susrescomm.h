#pragma once

#include "txt_resmgr_base.h"

class ResMgrSusResComm : public ResMgrBase
{
  public:
    ResMgrSusResComm(const char *path, bool is_control, int display_number);
    virtual ~ResMgrSusResComm();

    virtual bool start(std::string *out_err,
                       ResManagerDispatchloop *dispatcher);
    virtual void stop();

    void stall_io();
    void finish_io__code(int retval);
    void finish_io__timedout();

  protected:
    virtual bool process_command(const char *command);

    int get_display_num() const;
    bool get_is_control() const;

  private:
    void process_command_list(const char *command);
    void process_command_prepare(const char *command);
    void process_command_suspend(const char *command);
    void process_command_resume(const char *command);
    void process_command_complete(const char *command);
    void process_command_status(const char *command);
    void process_command_online(const char *command);
    void process_command_version(const char *command);
    void process_command_quit(const char *command);

    bool start_timer(unsigned int msec);
    void stop_timer(bool deallocate);

    static int timer_callback(void *_ctp, int code, unsigned flags,
                              void *handle);

  private:
    int dsp_number;
    bool is_control_rmgr;

    int timerPCode;
    int timerPcoid;
    timer_t timerID;
};
