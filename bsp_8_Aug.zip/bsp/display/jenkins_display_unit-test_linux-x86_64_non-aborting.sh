#!/usr/bin/env bash
######################################################################
#FILE: jenkins_display_unit-test_linux-x86_64_non-aborting.sh
#SW-COMPONENT: Tooling
#DESCRIPTION: Generate and execute unit tests of the component in non
#             aborting mode
#COPYRIGHT: (C) 2021 Robert Bosch GmbH
#
#The reproduction, distribution and utilization of this file as
#well as the communication of its contents to others without express
#authorization is prohibited. Offenders will be held liable for the
#payment of damages. All rights reserved in the event of the grant
#of a patent, utility model or design.
######################################################################

set -eu

export DS_MOCKS_GENERATION=false
$(dirname "$0")/display_unit-test_linux-x86_64.sh -c
