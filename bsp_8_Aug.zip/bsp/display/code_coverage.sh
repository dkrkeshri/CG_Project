#!/bin/bash
rm -rf Report/
mkdir Report
mock_exclude="$(pwd)"
lcov --directory . --capture --output-file coverage.info --rc lcov_branch_coverage=1
lcov --remove coverage.info '/usr/include/*' '/usr/lib/*' $PWD"/utest/*" \
        $PWD"/api/lib_tdaemon/utest/src_test/*"   \
        $PWD"/api/public/utest/*"   \
        $PWD"/api/public/utest/src_test/*"   \
        $PWD"/api/public/fidm_parameter_provider_lib/src/*"	\
        $PWD"/api/public/sus_res_comm_lib/src/*"	\
        $PWD"/ds90ux9xx-drivers/utest/mocks/sys/*" \
        $PWD"/configuration-provider/libconfig-provider/utest/src_test/*" \
        $PWD"/configuration-provider/providers/utest/src_test/*" \
        $PWD"/display_susd_pm/utest/src_test/*" \
        $PWD"/instance-manager/utest/mocks/sys/*" \
        $PWD"/utest/src_test/*" \
        ${mock_exclude}"/test/utest/mock/display_utest_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/display_utest_mock/inc/*" \
        ${mock_exclude}"/test/utest/mock/ipc_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/ipc_mock/inc/*" \
        ${mock_exclude}"/test/utest/mock/i2c_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/i2c_mock/inc/*" \
        ${mock_exclude}"/test/utest/mock/slog2_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/posix_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/screen_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/screen_mock/inc/*" \
        ${mock_exclude}"/test/utest/mock/json_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/json_mock/inc/*" \
        ${mock_exclude}"/test/utest/mock/err_mem/src/*" \
        ${mock_exclude}"/test/utest/mock/err_mem/inc/*" \
        ${mock_exclude}"/fidm_binder/fidm_binder_lib/utest/src_test/*" \
        ${mock_exclude}"/test/utest/mock/posix_mock/inc/*" --rc lcov_branch_coverage=1 -o coverage.info
genhtml coverage.info -t Dispaly_API --branch-coverage --output-directory Report/