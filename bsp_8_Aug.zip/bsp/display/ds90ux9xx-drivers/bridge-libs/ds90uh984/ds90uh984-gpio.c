/**
 * @file       ds90uh984-gpio.c
 * @brief      ds90ub984 / ds90uh984 GPIO settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90uh984-gpio-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh984-gpio.h"
#endif /* UNITTEST */

typedef struct ds90uh984_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t stat_reg;
        const uint8_t input;
} ds984_pins_st_t;

#define DS984_GPIO(gpio_name, gpio_reg_addr, gpio_stat_reg, gpio_in_crtl_reg)   \
        {                                                                       \
                .name = (gpio_name),                                            \
                .reg = (gpio_reg_addr),                                         \
                .stat_reg = (gpio_stat_reg),                                    \
                .input = (gpio_in_crtl_reg),                                    \
        }

static ds984_pins_st_t ds984_gpios[DS984_GPIO_COUNT] = {
        DS984_GPIO("gpio0",
                   DS984_REG_GPIO_0,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio1",
                   DS984_REG_GPIO_1,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio2",
                   DS984_REG_GPIO_2,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio3",
                   DS984_REG_GPIO_3,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio4",
                   DS984_REG_GPIO_4,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio5",
                   DS984_REG_GPIO_5,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio6",
                   DS984_REG_GPIO_6,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio7",
                   DS984_REG_GPIO_7,
                   DS984_REG_GPIO_STS1,
                   DS984_REG_GPIO_INPUT_ENABLE_0),
        DS984_GPIO("gpio8",
                   DS984_REG_GPIO_8,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
        DS984_GPIO("gpio9",
                   DS984_REG_GPIO_9,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
        DS984_GPIO("gpio10",
                   DS984_REG_GPIO_10,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
        DS984_GPIO("gpio11",
                   DS984_REG_GPIO_11,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
        DS984_GPIO("gpio12",
                   DS984_REG_GPIO_12,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
        DS984_GPIO("gpio13",
                   DS984_REG_GPIO_13,
                   DS984_REG_GPIO_STS2,
                   DS984_REG_GPIO_INPUT_ENABLE_1),
};

static
ds90ux9xx_err_t is_wrong_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS984_GPIO_COUNT) {
                log_err("Incorrect gpio number %d\n", num);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t is_wrong_bc_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS984_GPIO_REMOTE_BC_CNT) {
                log_err("Incorrect BC gpio number %d\n", num);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t check_fc_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS984_GPIO_REMOTE_FC_CNT) {
                log_err("Incorrect FC gpio number %d\n", num);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
inline ds90ux9xx_err_t gpio_input(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds984_gpios[num].input, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ENABLE == state) {
                val |= DS984_GPIO_INPUT_EN(num);
        } else {
                val &= ~DS984_GPIO_INPUT_EN(num);
        }

        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[num].input, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
inline ds90ux9xx_err_t gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DISABLE == state) {
                val = DS984_GPIO_OUTPUT_DISABLE;
        } else {
                if (GPIO_LOW == value) {
                        val = DS984_GPIO_OUTPUT_LOW;
                }

                if (GPIO_HIGH == value) {
                        val = DS984_GPIO_OUTPUT_HIGH;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[num].reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
uint8_t gpio_function_to_reg_val(ds90ux9xx_gpio_st_t *gpio)
{
        uint8_t val = FUNC_WRONG;

        if (NULL == gpio) {
                log_err("Invalid input: gpio = %p\n", gpio);

                return val;
        }

        switch (gpio->function) {
        case FUNC_RX_LOCK_DEV_STS:
                val = DS984_GPIO_FUNC_RX_LOCK_DEV_STS;
                break;
        case FUNC_RX_LOCK_AND:
                val = DS984_GPIO_FUNC_RX_LOCK_AND;
                break;
        case FUNC_RX_LOCK_OR:
                val = DS984_GPIO_FUNC_RX_LOCK_OR;
                break;
        case FUNC_REMOTE_IRQ:
                val = DS984_GPIO_FUNC_REMOTE_IRQ;
                break;
        case FUNC_RX_LOCK_DETECT:
                val = DS984_GPIO_FUNC_RX_LOCK;
                break;
        case FUNC_FPD_TX_IRQ:
                if (GPIO_LOW == gpio->value) {
                        val = DS984_GPIO_FUNC_FPD_TX_IRQ_LOW;
                } else if (GPIO_HIGH == gpio->value) {
                        val = DS984_GPIO_FUNC_FPD_TX_IRQ_HIGH;
                }

                break;
        default:
                log_err("Incorrect function value\n");
        }

        return val;
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t val;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: dev = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds984_gpios[num].stat_reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *value = !!(val & DS984_GPIO_STAT(num));

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
fpd_port_t get_port(uint8_t reg_val, gpio_function_t function)
{
        fpd_port_t port = PORT_0;

        switch (function) {
        case FUNC_REMOTE_FC:
                if (TO_DS984_FC_PORT(reg_val)) {
                        port = PORT_1;
                }

                break;
        case FUNC_REMOTE_BC:
        case FUNC_REMOTE_IRQ:
        case FUNC_RX_LOCK_DETECT:
        case FUNC_FPD_TX_IRQ:
                if (TO_DS984_BC_PORT(reg_val)) {
                        port = PORT_1;
                }

                break;
        default:
                port = NOT_SPECIFIED;
        }

        return port;
}

static
ds90ux9xx_err_t get_gpio_port(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, fpd_port_t *port)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == dev || NULL == port) {
                log_err("Invalid input: dev = %p, port = %p\n", dev, port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (function) {
        case FUNC_GPIO_INPUT:
        case FUNC_GPIO_OUTPUT:
        case FUNC_RX_LOCK_DEV_STS:
        case FUNC_RX_LOCK_AND:
        case FUNC_RX_LOCK_OR:
                *port = NOT_SPECIFIED;

                return DS90UX9XX_SUCCESS;
        default:
                break;
        }

        reg = ds984_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *port = get_port(val, function);

        log_dbg("Got FPD port %d for GPIO_%d\n", *port, num);

        return rc;
}

static
gpio_function_t get_function(uint8_t ctrl_out, uint8_t ctrl_in)
{
        if (0 != ctrl_in) {
                return FUNC_GPIO_INPUT;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_FUNC_FC, ctrl_out)) {
                return FUNC_REMOTE_FC;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_FUNC_RX_LOCK_AND, ctrl_out)) {
                return FUNC_RX_LOCK_AND;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_FUNC_RX_LOCK_OR, ctrl_out)) {
                return FUNC_RX_LOCK_OR;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_GET_REMOTE(DS984_GPIO_FPD_TX_IRQ),
                                ctrl_out)) {
                return FUNC_FPD_TX_IRQ;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_GET_REMOTE(DS984_GPIO_FUNC_RX_LOCK),
                                ctrl_out)) {
                return FUNC_RX_LOCK_DETECT;
        }

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        if (IS_FUNCTION_PRESENT(DS984_GPIO_GET_REMOTE(
                                DS984_GPIO_FUNC_REMOTE_IRQ), ctrl_out)) {
                return FUNC_REMOTE_IRQ;
        }
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        if (IS_FUNCTION_PRESENT(DS984_GPIO_FUNC_RX_LOCK_DEV_STS, ctrl_out)) {
                return FUNC_RX_LOCK_DEV_STS;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_OUTPUT, ctrl_out)) {
                return FUNC_GPIO_OUTPUT;
        }

        if (IS_FUNCTION_PRESENT(DS984_GPIO_FUNC_BC, ctrl_out)) {
                return FUNC_REMOTE_BC;
        }

        return FUNC_WRONG;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t ctrl_out, ctrl_in;

        if (NULL == dev || NULL == function) {
                log_err("Invalid input: dev = %p, function = %p\n",
                        dev, function);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds984_gpios[num].reg, &ctrl_out);

        rc |= ds90ux9xx_i2c_read(dev, ds984_gpios[num].input, &ctrl_in);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *function = get_function(ctrl_out, DS984_GPIO_INPUT_EN(num) & ctrl_in);

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_ctrl;

        if (NULL == dev || NULL == remote) {
                log_err("Invalid input: dev = %p, remote = %p\n",
                        dev, remote);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds984_gpios[num].reg, &reg_ctrl);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        switch (function) {
        case FUNC_REMOTE_BC:
                *remote = reg_ctrl & DS984_GPIO_BC_ANY;
                break;
        case FUNC_REMOTE_FC:
                *remote = reg_ctrl & DS984_GPIO_FC_ANY;
                break;
        default:
                *remote = NOT_SPECIFIED;

                log_dbg("No GPIO remote configuration\n");

                return rc;
        }

        log_dbg("Got remote %d for GPIO_%d\n", *remote, num);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_input(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_output(dev, num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, num, ENABLE);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, num, DISABLE);
        rc |= gpio_output(dev, num, ENABLE, value);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_disable(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, num, DISABLE);
        rc |= gpio_output(dev, num, DISABLE, GPIO_LOW);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_rx_lock(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_val;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        reg_val = gpio_function_to_reg_val(gpio);
        if (FUNC_WRONG == reg_val) {
                log_err("Incorrect gpio->function value\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_remote_irq(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;
        uint8_t reg_val = 0;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        if (NOT_SPECIFIED == gpio->port) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg_val = gpio_function_to_reg_val(gpio);
        if (FUNC_WRONG == reg_val) {
                log_err("Incorrect gpio->function value\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg_val = DS984_GPIO_SET_REMOTE(gpio->port, reg_val);

        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_back_channel(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_val;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_bc_gpio_number(gpio->remote);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        if (NOT_SPECIFIED == gpio->port) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, gpio->num, DISABLE);

        reg_val = DS984_GPIO_SET_REMOTE(gpio->port, gpio->remote);

        /* enable remote */
        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_forward_channel(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_val;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = check_fc_gpio_number(gpio->remote);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        rc = gpio_input(dev, gpio->num, DISABLE);

        reg_val = DS984_GPIO_SET_FC(gpio->port, gpio->remote);

        /* enable remote */
        rc = ds90ux9xx_i2c_write(dev, ds984_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh984_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                rc = set_gpio_input(dev, gpio->num);
                break;
        case FUNC_GPIO_OUTPUT:
                rc = set_gpio_output(dev, gpio->num, gpio->value);
                break;
        case FUNC_RX_LOCK_DEV_STS:
        case FUNC_RX_LOCK_OR:
        case FUNC_RX_LOCK_AND:
                rc = set_gpio_rx_lock(dev, gpio);
                break;
        case FUNC_REMOTE_IRQ:
        case FUNC_RX_LOCK_DETECT:
        case FUNC_FPD_TX_IRQ:
                rc = set_gpio_remote_irq(dev, gpio);
                break;
        case FUNC_REMOTE_BC:
                rc = set_gpio_back_channel(dev, gpio);
                break;
        case FUNC_REMOTE_FC:
                rc = set_gpio_forward_channel(dev, gpio);
                break;
        case FUNC_DISABLE:
                rc = set_gpio_disable(dev, gpio->num);
                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh984_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        rc = get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_port(dev, gpio->num, gpio->function, &gpio->port);
        rc |= get_gpio_remote(dev, gpio->num, gpio->function, &gpio->remote);
        rc |= get_gpio_value(dev, gpio->num, &gpio->value);

        return rc;
}

