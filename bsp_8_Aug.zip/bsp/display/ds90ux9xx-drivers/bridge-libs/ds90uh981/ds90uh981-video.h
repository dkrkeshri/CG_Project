/**
 * @file       ds90uh981-video.h
 * @brief      ds90ub981 / ds90uh981 video configuration API
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH981_VIDEO_H__
#define __DS90UH981_VIDEO_H__

#include "ds90uh981.h"

ds90ux9xx_err_t set_fpd3_mode(const ds90ux9xx_st_t *dev, const char *fpd_mode);
ds90ux9xx_err_t set_fpd4_mode(const ds90ux9xx_st_t *dev, const char *fpd_mode,
        uint8_t port);
ds90ux9xx_err_t vp_configure(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp);
ds90ux9xx_err_t vp_enable_all(const ds90ux9xx_st_t *dev);
ds90ux9xx_err_t vp_get_resolution(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp);
ds90ux9xx_video_core_st_t *vp_init(uint8_t id);
ds90ux9xx_video_core_st_t *vp_get_by_id(ds90ux9xx_st_t *dev, uint8_t id);
ds90ux9xx_err_t pll_init(const ds90ux9xx_st_t *dev);
ds90ux9xx_err_t configure_video_subsystem(const ds90ux9xx_st_t *dev);

#endif /* __DS90UH981_VIDEO_H__ */

