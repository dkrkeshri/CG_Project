/**
 * @file       ds90uh981-video.c
 * @brief      ds90ub981 / ds90uh981 video configuration routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include <math.h>

#ifdef UNITTEST
#include "UT-ds90uh981-video-mock.h"
#include "UT-ds90ux9xx-bridge-libraries-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh981-video.h"
#include "ds90ux9xx-bridge-libraries.h"
#endif /* UNITTEST */

static
ds90ux9xx_err_t vp_get_count(const ds90ux9xx_st_t *dev, uint8_t *vp_count)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t vp_mask_state = 0;

        if (NULL == dev || NULL == vp_count) {
                log_err("Invalid input: dev = %p, vp_count = %p\n",
                        dev, vp_count);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS981_REG_VP_ENABLE_REG,
                                &vp_mask_state);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("I2C read error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        COUNT_BITS(*vp_count, vp_mask_state);

        return rc;
}

static
ds90ux9xx_err_t ds981_get_fpd_bandwidth(const ds90ux9xx_st_t *dev,
        fpd_port_t port, uint64_t *bandwidth)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int64_t bandwidth_tmp = 0;

        if (NULL == dev || NULL == bandwidth) {
                log_err("Invalid input: dev = %p, bandwidth = %p\n", dev,
                        bandwidth);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds_get_fpd_bandwidth(dev, port, &bandwidth_tmp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (NOT_SPECIFIED == bandwidth_tmp) {
                bandwidth_tmp = MHZ_TO_HZ(DS981_LINE_RATE_10P8MBPS);
        }

        *bandwidth = bandwidth_tmp;

        log_dbg("FPD Bandwidth (port %d): %llu\n", port, *bandwidth);

        return DS90UX9XX_SUCCESS;
}

static
uint8_t to_fpd3_pdiv(uint8_t post_divider)
{
        switch (post_divider) {
        case PLL_VCO_DIV_2:
                return DS981_PLL_FPD3_DIV_2_CODE;
        case PLL_VCO_DIV_8:
                return DS981_PLL_FPD3_DIV_8_CODE;
        case PLL_VCO_DIV_16:
                return DS981_PLL_FPD3_DIV_16_CODE;
        case PLL_VCO_DIV_4:
        default:
                return DS981_PLL_FPD3_DIV_4_CODE;
        }
}

static inline
uint8_t vco_match_fpd3_divider(uint32_t half_fpd_clk)
{
        uint8_t divider = PLL_VCO_DIV_2;

        do {
                if ((half_fpd_clk * divider > DS981_PLL_FPD3_VCO_MIN_FREQ) &&
                    (half_fpd_clk * divider < DS981_PLL_FPD3_VCO_MAX_FREQ)) {
                        return divider;
                }

                divider = divider << 1;
        } while (divider <= PLL_VCO_DIV_16);

        return 0;
}

static
uint8_t to_fpd4_pdiv(uint8_t post_divider)
{
        switch (post_divider) {
        case PLL_VCO_DIV_1:
                return DS981_PLL_FPD4_DIV_1_CODE;
        case PLL_VCO_DIV_2:
                return DS981_PLL_FPD4_DIV_2_CODE;
        case PLL_VCO_DIV_4:
                return DS981_PLL_FPD4_DIV_4_CODE;
        case PLL_VCO_DIV_8:
                return DS981_PLL_FPD4_DIV_8_CODE;
        default:
                return DS981_PLL_FPD4_DIV_1_CODE;
        }
}

static
ds90ux9xx_err_t port_backward_channel_init(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t bc_configuration = 0;
        uint64_t bandwidth = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds981_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        if (bandwidth == MHZ_TO_HZ(DS981_LINE_RATE_10P8MBPS)) {
                bc_configuration = DS981_DATAPATH_BC_FC_168P75MBPS;
        } else {
                bc_configuration = DS981_DATAPATH_BC_FC_135MBPS;
        }

        rc = set_tx_port(dev, port);
        rc |= ds90ux9xx_i2c_write(dev, DS981_REG_DATAPATH_BC_FC,
                                  bc_configuration);
        rc |= ds90ux9xx_i2c_write(dev, DS981_REG_BC_DOWN_SAMPLING_RATE,
                                  DS981_BC_DOWN_SAMPLING_RATE_1);

        log_dbg("Backward channel setup completed [port = %d]: %s\n", port,
                ds90ux9xx_err2str(rc));

        return rc;
}

static
ds90ux9xx_err_t backward_channel_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        fpd_port_t port = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (port = 0; port < dev->fpd.ports_cnt; port++) {
                rc |= port_backward_channel_init(dev, port);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't initialize backward channel [port %d]\n",
                                port, ds90ux9xx_err2str(rc));
                }
        }

        return rc;
}

ds90ux9xx_video_core_st_t *vp_init(uint8_t id)
{
        ds90ux9xx_video_core_st_t *vp = NULL;

        vp = alloc_data(1, ds90ux9xx_video_core_st_t);
        if (NULL == vp) {
                log_err("Failed to allocate ds90ux9xx_video_core_st_t\n");

                return NULL;
        }

        vp->id = id;

        return vp;
}

ds90ux9xx_video_core_st_t *vp_get_by_id(ds90ux9xx_st_t *dev, uint8_t id)
{
        ds90ux9xx_video_core_st_t *vp = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return NULL;
        }

        if (id >= DS981_MAX_VP_COUNT) {
                log_err("Invalid VP requested: id = %d\n", id);

                return NULL;
        }

        log_dbg("Search VP configuration for VP %d\n", id);

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (vp->id == id) {
                        log_dbg("VP %d configuration found\n", id);

                        return vp;
                }
        }

        vp = vp_init(id);
        if (NULL == vp) {
                log_err("Can't allocate bridge VP data\n");

                return NULL;
        }

        /* Add VP in list so it will be destoyed on bridge deinitialization */
        list_add_tail(&dev->video_settings.vp_list, &vp->node);

        return vp;
}

static
bool vp_is_fpd3_stream_map_valid(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        uint8_t mapped_vp;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return false;
        }

        /* In the case when no VP or one is enabled it can be mapped on any
         * port without any checking. Cause there aren't VPs that can conflict
         * with enabled VP.
         */
        if (vp_count <= DS981_SINGLE_VP) {
                return true;
        }

        /* TODO: check if that is a valid assumption */
        if (EQUAL != strcmp(dev->fpd.fpd_tx_mode, INDEPENDENT_FPD_MODE)) {
                return false;
        }

        /* Check that opposite port is not configured for the same vp */
        if (PORT_1 == vp->port) {
                rc = set_tx_port(dev, PORT_0);
        } else {
                rc = set_tx_port(dev, PORT_1);
        }

        rc |= ds90ux9xx_i2c_read(dev, DS981_REG_FPD3_STREAM_SEL, &mapped_vp);
        if (DS90UX9XX_SUCCESS != rc) {
                return false;
        }

        if (vp->id != mapped_vp) {
                return true;
        }

        return false;
}

static
ds90ux9xx_err_t vp_map_fpd3_stream(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == vp_is_fpd3_stream_map_valid(dev, vp, vp_count)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_tx_port(dev, vp->port);
        rc |= ds90ux9xx_i2c_write(dev, DS981_REG_FPD3_STREAM_SEL, vp->id);

        return rc;
}

static
ds90ux9xx_err_t vp_map_stream(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                return vp_map_fpd3_stream(dev, vp, vp_count);
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t vp_set_stream(const ds90ux9xx_st_t *dev, uint8_t vp_count)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90ux9xx_i2c_write(dev, DS981_REG_VP_CONFIG_REG,
                                   VP_STREAMS_COUNT(vp_count));
}

static
ds90ux9xx_err_t vp_check_state(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t vp_count = 0;
        uint8_t max_vp_count = DS981_MAX_VP_COUNT;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* We can disable VP without any checks */
        if (DISABLE == vp->state) {
                log_err("VP disable state is always allowed\n");

                return DS90UX9XX_SUCCESS;
        }

        rc = vp_get_count(dev, &vp_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get VP count. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                max_vp_count = DS981_MAX_VP_COUNT_FPD3;
        }

        /*
         * Check that current quantity of enabled VP + the 1 VP
         * that will be enabled is not more then maximum VP quantity
         */
        if ((vp_count + 1) > max_vp_count) {
                log_err("Exceeded maximum VP count\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_map_stream(dev, vp, vp_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map VP stream. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t vp_enable_all(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t regval_vp = 0;
        uint8_t vp_enabled = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                log_dbg("Set VP[%d] state %x\n", vp->id, vp->state);

                if (ENABLE == vp->state) {
                        rc = vp_check_state(dev, vp);
                        if (DS90UX9XX_SUCCESS != rc) {
                                log_err("Can't enable VP %d\n", vp->id);

                                return DS90UX9XX_INVALID_PARAMETER;
                        }

                        regval_vp |= DS981_VP_ENABLE(vp->id);
                        vp_enabled++;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, DS981_REG_VP_ENABLE_REG, regval_vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable VPs\n");

                return rc;
        }

        return vp_set_stream(dev, vp_enabled);
}

static
ds90ux9xx_err_t vp_disable_all(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, DS981_REG_VP_ENABLE_REG,
                                 DS981_DISABLE_ALL_VP);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write to DS981_REG_VP_ENABLE_REG. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        log_dbg("Disable ALL VP\n");

        return rc;
}

static
ds90ux9xx_err_t vp_set_resolution(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        const ds90ux9xx_video_resolution_st_t *resolution = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == vp->video_resolution.set) {
                log_dbg("VP[%d]: No need to set resolution\n", vp->id);

                return rc;
        }

        resolution = &vp->video_resolution;

        log_dbg("Configuring resolution %dx%d\n",
                resolution->h_active, resolution->v_active);

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_DP_H_ACTIVE0, vp->id),
                resolution->h_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_ACTIVE0, vp->id),
                resolution->h_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_BACK0, vp->id),
                resolution->h_back_porch);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_WIDTH0, vp->id),
                resolution->h_pulse_width);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_TOTAL0, vp->id),
                resolution->h_total);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_ACTIVE0, vp->id),
                resolution->v_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_BACK0, vp->id),
                resolution->v_back_porch);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_WIDTH0, vp->id),
                resolution->v_pulse_width);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_FRONT0, vp->id),
                resolution->v_front_porch);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        log_dbg("\nResolution set:\n"
                "H total        : %d\n"
                "H active       : %d\n"
                "H back porch   : %d\n"
                "H front porch  : %d\n"
                "H width        : %d\n"
                "V total        : %d\n"
                "V active       : %d\n"
                "V back porch   : %d\n"
                "V fron porch   : %d\n"
                "V width        : %d\n",
                resolution->h_total,
                resolution->h_active,
                resolution->h_back_porch,
                resolution->h_total - resolution->h_active -
                resolution->h_pulse_width - resolution->h_back_porch,
                resolution->h_pulse_width,
                resolution->v_total,
                resolution->v_active,
                resolution->v_back_porch,
                resolution->v_front_porch,
                resolution->v_pulse_width);

        log_dbg("Resolution settings are applied\n");

        return rc;
}

ds90ux9xx_err_t vp_get_resolution(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_video_resolution_st_t *resolution = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        resolution = &vp->video_resolution;

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_ACTIVE0, vp->id),
                &resolution->h_active);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_BACK0, vp->id),
                &resolution->h_back_porch);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_WIDTH0, vp->id),
                &resolution->h_pulse_width);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_H_TOTAL0, vp->id),
                &resolution->h_total);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_ACTIVE0, vp->id),
                &resolution->v_active);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_BACK0, vp->id),
                &resolution->v_back_porch);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_WIDTH0, vp->id),
                &resolution->v_pulse_width);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_VID_V_FRONT0, vp->id),
                &resolution->v_front_porch);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read resolution. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        resolution->h_front_porch = resolution->h_total -
                                    resolution->h_active -
                                    resolution->h_pulse_width -
                                    resolution->h_back_porch;

        resolution->v_total = resolution->v_active +
                              resolution->v_front_porch +
                              resolution->v_back_porch +
                              resolution->v_pulse_width;

        log_dbg("\nResolution get:\n"
                "H total        : %d\n"
                "H active       : %d\n"
                "H back porch   : %d\n"
                "H front porch  : %d\n"
                "H width        : %d\n"
                "V total        : %d\n"
                "V active       : %d\n"
                "V back porch   : %d\n"
                "V fron porch   : %d\n"
                "V width        : %d\n",
                resolution->h_total,
                resolution->h_active,
                resolution->h_back_porch,
                resolution->h_front_porch,
                resolution->h_pulse_width,
                resolution->v_total,
                resolution->v_active,
                resolution->v_back_porch,
                resolution->v_front_porch,
                resolution->v_pulse_width);

        return rc;
}

static
ds90ux9xx_err_t vp_set_cropping(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        const ds90ux9xx_video_cropping_st_t *cropping = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t regval_state = DS981_VP_DISABLE_CROPPING;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == vp->video_cropping.set) {
                log_dbg("VP[%d]: No need to set cropping\n", vp->id);

                return rc;
        }

        cropping = &vp->video_cropping;

        if (ENABLE == cropping->state) {
                regval_state = DS981_VP_ENABLE_CROPPING;
        }

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_CROP_START_X0, vp->id),
                cropping->start_x);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_CROP_START_Y0, vp->id),
                cropping->start_y);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_CROP_STOP_X0, vp->id),
                cropping->stop_x);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_CROP_STOP_Y0, vp->id),
                cropping->stop_y);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_12,
                TO_VP_REG(DS981_IND_REG_VP_CTL, vp->id),
                regval_state);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        return rc;
}

static
ds90ux9xx_err_t vp_map_source_stream(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = 0;
        uint8_t value = 0;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = TO_VP_REG(DS981_IND_REG_VP_CFG, vp->id);

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS981_IND_PAGE_12, reg, &value);

        value &= VP_SRC_SELECT_CLEAR;
        value |= vp->stream;

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_12, reg, value);

        return rc;
}

static
ds90ux9xx_err_t vp_set_frequency(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint64_t bandwidth = 0;
        float vp_ref_clk = 0;
        uint32_t pclk_M = 0;
        uint8_t pclk_N = DS981_VP_FPD4_PCLK_N_DEFAULT;
        float vp_clk = 0;
        float pclk = 0;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                log_dbg("No need to setup VP frequency in FPD3 mode\n");

                return rc;
        }

        rc = ds981_get_fpd_bandwidth(dev, vp->port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("VP[%d]: Configure VP frequency\n", vp->id);

        pclk = HZ_TO_MHZ(vp->video_resolution.h_total *
                         vp->video_resolution.v_total *
                         vp->video_resolution.fps);

        vp_clk = FPD4_PCLK_TO_VP_CLK(pclk);

        vp_ref_clk = FPD4_FREQ_TO_VP_REF_CLK(HZ_TO_MHZ(bandwidth));

        log_dbg("pclk        : %f Mhz\n", pclk);
        log_dbg("vp_clk      : %f Mhz\n", vp_clk);
        log_dbg("vp_ref_clk  : %f Mhz\n", vp_ref_clk);

        pclk_M = (uint32_t)ceil(vp_clk * pow(2, pclk_N) / vp_ref_clk);

        log_dbg("pclk_N      : %d\n", pclk_N);
        log_dbg("pclk_M      : %d\n", pclk_M);

        rc = ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_12,
                                        TO_VP_REG(DS981_IND_REG_VP_PCLK_GEN_N,
                                                  vp->id),
                                        pclk_N);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_12,
                                         TO_VP_REG(DS981_IND_REG_VP_PCLK_GEN_M,
                                                   vp->id),
                                         pclk_M);

        log_dbg("VP[%d]: VP frequency configured\n", vp->id);

        return rc;
}

ds90ux9xx_err_t vp_select_dphy_input(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = 0;
        uint8_t value = 0;

        /* TODO: Investigate how to get proper channel */
        uint8_t virtual_channel = 0;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = VP_TO_DPHY_SEL_REG(vp->id);

        rc = ds90ux9xx_i2c_read(dev, reg, &value);

        value &= CLEAR_VP_DPHY_MAPPING(vp->id);
        value |= MAP_VP_TO_DPHY(vp->id, vp->dphy_port, virtual_channel);

        rc |= ds90ux9xx_i2c_write(dev, reg, value);

        return rc;
}

ds90ux9xx_err_t vp_configure(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_select_dphy_input(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't select PHY input. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = vp_set_resolution(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP resolution\n", vp->id);

                return rc;
        }

        rc = vp_set_cropping(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP cropping\n", vp->id);

                return rc;
        }

        rc = vp_map_source_stream(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't map VP source stream. Error: %s\n",
                        vp->id, ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = vp_set_frequency(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP frequency\n", vp->id);

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t vp_init_subsystem(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                log_dbg("VP[%d] Trying configure\n", vp->id);

                rc = vp_configure(dev, vp);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("VP[%d] Configuration failed\n", vp->id);
                        break;
                }
        }

        return rc;
}

static
void vp_calculate_timeslots(ds90ux9xx_video_core_st_t *vp)
{
        float stream_bandwidth = 0.0;
        float pclk = 0.0;
        float bandwidth_rate = 0.0;

        if (NULL == vp) {
                log_err("Invalid input: vp = %p\n", vp);

                return;
        }

        pclk = vp->video_resolution.h_total *
               vp->video_resolution.v_total *
               vp->video_resolution.fps;

        stream_bandwidth = HZ_TO_GHZ(pclk * vp->video_resolution.bpp);
        bandwidth_rate = stream_bandwidth / DS981_MAX_BANDWIDTH_10_47GHZ;
        vp->timeslots = ceil(DS981_TIMESLOTS_LIMIT * bandwidth_rate);

        log_dbg("VP[%d] PCLK      = %f Hz\n", vp->id, pclk);
        log_dbg("VP[%d] Bandwidth = %f GHz\n", vp->id, stream_bandwidth);
        log_dbg("VP[%d] rate      = %f\n", vp->id, bandwidth_rate);
        log_dbg("VP[%d] timeslots = %d\n", vp->id, vp->timeslots);
}

static
ds90ux9xx_err_t calculate_timeslots(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t timeslots_port0 = 0;
        uint8_t timeslots_port1 = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state) {
                        continue;
                }

                vp_calculate_timeslots(vp);

                if (PORT_1 == vp->port) {
                        timeslots_port1 += vp->timeslots;
                } else {
                        timeslots_port0 += vp->timeslots;
                }
        }

        log_dbg("Total TIMESLOTS: port0: %d; port1: %d\n",
                timeslots_port0, timeslots_port1);

        if (timeslots_port0 > DS981_TIMESLOTS_LIMIT ||
            timeslots_port1 > DS981_TIMESLOTS_LIMIT) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t link_layer_configure_stream_timeslots(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t streams_port0 = 0;
        uint8_t streams_port1 = 0;
        uint8_t reg = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Enable streams and set timeslots */
        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state) {
                        continue;
                }

                if (vp->stream >= DS981_MAX_LINK_LAYER_STREAMS) {
                        log_err("VP[%d] Incorrect stream id %d\n",
                                vp->id, vp->stream);

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                if (PORT_1 == vp->port) {
                        streams_port1 |= BIT(vp->stream);
                } else {
                        streams_port0 |= BIT(vp->stream);
                }

                log_dbg("Set timeslots %d for VP %d at port %d stream %d\n",
                        vp->timeslots, vp->id, vp->port, vp->stream);

                reg = GET_STREAM_SLOT_REG(vp->port, vp->stream);
                rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                                 reg,
                                                 vp->timeslots);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set timeslots. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        /* Enable streams on link layer 0 */
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                         DS981_IND_REG_LINK0_STREAM_ENABLE,
                                         streams_port0);

        /* Enable streams on link layer 1 */
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                         DS981_IND_REG_LINK1_STREAM_ENABLE,
                                         streams_port1);

        return rc;
}

static
ds90ux9xx_err_t map_stream_timeslots(const ds90ux9xx_st_t *dev,
        uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t streams01 = 0;
        uint8_t streams23 = 0;
        bool streams01_set = false;
        bool streams23_set = false;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (port >= DS981_MAX_FPD_PORTS) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state || vp->port != port) {
                        continue;
                }

                if (vp->stream < DS981_VP_MAP_STREAM_COUNT_IN_REG) {
                        streams01 |= MAP_VP_TO_STREAM(vp->id, vp->stream);
                        streams01_set = true;
                } else {
                        streams23 |= MAP_VP_TO_STREAM(vp->id, vp->stream);
                        streams23_set = true;
                }

                log_dbg("Map link[%d] VP[%d] to stream %d\n",
                        vp->port, vp->id, vp->stream);
        }

        if (false == streams01_set) {
                log_dbg("Nothing to configure\n");

                return rc;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                         DS981_IND_REG_LINK_MAP_STREAM_0_1,
                                         streams01);

        /* Skip configuration for streams 2, 3 if mapping is not populated
         * as 0 there means VP0 on both streams.
         * The default value 0x32 will be populated in this case
         */
        if (false == streams23_set) {
                return rc;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                         DS981_IND_REG_LINK_MAP_STREAM_2_3,
                                         streams23);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map VPs to layer %d. Error: %s\n",
                        port, ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t link_layer_map_stream_timeslots(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t port = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (port = 0; port < DS981_MAX_FPD_PORTS; port++) {
                rc |= map_stream_timeslots(dev, port);
        }

        return rc;
}

static inline
ds90ux9xx_err_t link_layer_disable(const ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                          DS981_IND_REG_LINK_LAYER_CTL,
                                          DS981_LINK_LAYERS_DISABLE);
}

static inline
ds90ux9xx_err_t link_layer_enable(const ds90ux9xx_st_t *dev)
{
        uint8_t layer_ctrl = DS981_LINK_LAYERS_ENABLE;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (EQUAL == strcmp(dev->fpd.fpd_tx_mode, DUAL_FPD_MODE) ||
            EQUAL == strcmp(dev->fpd.fpd_tx_mode, SINGLE_FPD_MODE)) {
                layer_ctrl = DS981_LINK_LAYER_0_ENABLE;
        }

        return ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_11,
                                          DS981_IND_REG_LINK_LAYER_CTL,
                                          layer_ctrl);
}

static
ds90ux9xx_err_t link_layer_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                return rc;
        }

        rc = link_layer_disable(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't disable link layer: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = calculate_timeslots(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't calculate timeslots\n");

                return rc;
        }

        rc = link_layer_configure_stream_timeslots(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't configure streams\n");

                return rc;
        }

        rc = link_layer_map_stream_timeslots(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map timeslots\n");

                return rc;
        }

        rc = link_layer_enable(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable Link Layers\n");
        }

        return rc;
}

ds90ux9xx_err_t set_fpd3_mode(const ds90ux9xx_st_t *dev,
        const char *fpd_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS981_REG_FPD3_MODE_CTL;
        uint8_t val = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n",
                        dev, fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("fpd mode %s\n", fpd_mode);

        /* disable fpd4 */
        rc |= ds90ux9xx_i2c_read(dev, DS981_REG_FPD4_CFG, &val);
        val &= DS981_FPD3_BOTH_PORTS_ENABLE_MASK;
        rc |= ds90ux9xx_i2c_write(dev, DS981_REG_FPD4_CFG, val);

        /* Prepare to set fpd3 mode */
        rc = ds90ux9xx_i2c_write(dev, DS981_REG_FPD3_FIFO_CFG,
                                 DS981_FPD3_FIFO_DRAIN |
                                 DS981_FPD3_ALIGN_ERR_THR |
                                 DS981_ENABLE_FPD3_FIFO);

        /* enable fpd halfrate mode, required for fpd3 */
        rc |= ds90ux9xx_i2c_write(dev, DS981_REG_GENERAL_CFG2,
                                  DS981_DPRX_EN | DS981_FPD_HALFRATE_MODE);

        /* set fpd3 mode */
        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS981_FPD3_TX_MODE;

        if (EQUAL == strcmp(fpd_mode, SINGLE_FPD_MODE)) {
                val |= DS981_FPD3_TX_MODE_SINGLE_PORT_0;
        } else if (EQUAL == strcmp(fpd_mode, DUAL_FPD_MODE)) {
                val |= DS981_FPD3_TX_MODE_DUAL;
        } else if (EQUAL == strcmp(fpd_mode, INDEPENDENT_FPD_MODE)) {
                val |= DS981_FPD3_TX_MODE_INDEPENDENT;
        } else if (EQUAL == strcmp(fpd_mode, SPLITTER_FPD_MODE)) {
                val |= DS981_FPD3_TX_MODE_SPLITTER;
        } else {
                log_err("Unsupported mode '%s'\n", fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

ds90ux9xx_err_t set_fpd4_mode(const ds90ux9xx_st_t *dev,
        const char *fpd_mode, uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS981_REG_FPD4_CFG;
        uint64_t bandwidth = 0;
        uint8_t val = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n",
                        dev, fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds981_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("set FPD port %d mode '%s'\n", port, fpd_mode);

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS981_FPD4_TX_MODE(port, DS981_FPD4_CLEAN_TX_MODE);

        if (EQUAL == strcmp(fpd_mode, SINGLE_FPD_MODE)) {
                val |= DS981_FPD4_TX_MODE(port, DS981_FPD4_TX_MODE_SINGLE);
        } else if (EQUAL == strcmp(fpd_mode, DUAL_FPD_MODE)) {
                val |= DS981_FPD4_TX_MODE(port, DS981_FPD4_TX_MODE_DUAL);
        } else if (EQUAL == strcmp(fpd_mode, INDEPENDENT_FPD_MODE)) {
                val |= DS981_FPD4_TX_MODE(port, DS981_FPD4_TX_MODE_INDEPENDENT);
        } else {
                log_err("Unsupported mode '%s'\n", fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        if (bandwidth == MHZ_TO_HZ(DS981_LINE_RATE_3P375MBPS)) {
                /* disable FPD halfrate mode, required for 3P375MBPS */
                rc |= ds90ux9xx_i2c_update(dev, DS981_REG_GENERAL_CFG2,
                                           DS981_FPD_HALFRATE_MODE_MANUAL_MASK,
                                           DS981_FPD_HALFRATE_MODE_MANUAL);

                rc |= ds90ux9xx_i2c_update(dev, DS981_REG_GENERAL_CFG2,
                                           DS981_FPD_HALFRATE_MODE_MASK,
                                           DS981_FPD_HALFRATE_MODE_DISABLE);
        }

        return rc;
}

static
ds90ux9xx_err_t pll_reset_channel(const ds90ux9xx_st_t *dev, uint8_t channel)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reset_mask;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (channel) {
        case PLL_CH0:
                reset_mask = DS981_RESET_PLL_CH0;
                break;
        case PLL_CH1:
                reset_mask = DS981_RESET_PLL_CH1;
                break;
        case PLL_CH0_CH1:
        default:
                reset_mask = DS981_RESET_PLL_CH0 | DS981_RESET_PLL_CH1;
        }

        rc = bridge_reset(dev, reset_mask);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Reset pll channel failed. Reset_mask = '0x%x'\n",
                        reset_mask);
        }

        return rc;
}

static
ds90ux9xx_err_t pll_set_fpd3(const ds90ux9xx_st_t *dev, fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        float fpd_clk;
        float fpd_bandwidth;
        float pclk = 0;
        float vco_clk;
        uint32_t N_divider;
        uint32_t numerator;
        uint8_t vco_num = DS981_FPD3_VCO_NUM_DEFAULT;
        uint8_t reg;
        uint8_t pdiv;
        uint8_t post_divider;
        uint32_t denominator;
        uint32_t ref_clk = PLL_REFCLK_27MHZ;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint32_t pixel_count = 0;
        uint32_t curr_pixel_count = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (port < PORT_0 || port >= DS981_MAX_FPD_PORTS) {
                log_err("Invalid input: port = %d\n", port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                curr_pixel_count = vp->video_resolution.h_total *
                                   vp->video_resolution.v_total *
                                   vp->video_resolution.fps;
                if (curr_pixel_count > pixel_count) {
                        pixel_count = curr_pixel_count;
                }
        }

        pclk = HZ_TO_MHZ(pixel_count);
        fpd_bandwidth = pclk * PLL_FPD3_PCLK_COEF;

        log_dbg("pclk          : %f MHz\n", pclk);
        log_dbg("fpd_bandwidth : %f MHz\n", fpd_bandwidth);

        /* Get FPD clock rate */
        fpd_clk = fpd_bandwidth / 2;

        post_divider = vco_match_fpd3_divider(fpd_clk);
        if (0 == post_divider) {
                log_dbg("Can't find correct VCO\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Calculate parameters */
        log_dbg("post_divider: %d\n", post_divider);

        vco_clk = fpd_clk * post_divider;
        log_dbg("vco_clk     : %f MHz\n", vco_clk);

        ref_clk = ref_clk * PLL_REFCLK_COEF;
        log_dbg("ref_clk * 2 : %d MHz\n", ref_clk);

        N_divider = vco_clk / ref_clk;
        log_dbg("N_div (calc): %d\n", N_divider);

        denominator = PLL_MAX_DENOMINATOR;
        numerator = (vco_clk - N_divider * ref_clk) * (denominator / ref_clk);
        log_dbg("numerator   : %d\n", numerator);
        log_dbg("denominator : %d\n", denominator);
        log_dbg("vco_num     : %d\n", vco_num);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_PDIV, port);
        pdiv = DS981_PLL_VCO_AUTO_SELECT | to_fpd3_pdiv(post_divider);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         pdiv);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_VCO, port);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         TO_PLL_VCO(vco_num));

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_MASH_ORDER, port);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         DS981_PLL_MASH_FPD3);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_NDIV, port);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         N_divider);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_DEN, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         denominator);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_NUM, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         numerator);

        return rc;
}

static
ds90ux9xx_err_t pll_fpd4_match_dividers(uint64_t fpd_freq, uint32_t *n_divider,
        uint32_t *post_divider)
{
        uint32_t p_div = 0;
        uint32_t n_div = 0;
        int i = 0;

        if (NULL == n_divider || NULL == post_divider) {
                log_err("Invalid input: n_divider = %p, post_divider = %p\n",
                        n_divider, post_divider);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < ARRAY_SIZE(PLL_VCO_FPD4_N_DIVS); i++) {
                p_div = PLL_VCO_FPD4_N_DIVS[i];
                n_div = DS981_CALCULATE_PLL_N_DIV(fpd_freq, p_div);

                if (n_div > PLL_VCO_N_DIV_MIN) {
                        *n_divider = n_div;
                        *post_divider = p_div;

                        return DS90UX9XX_SUCCESS;
                }
        }

        log_err("post_divider and n_divider can't be found\n");

        return DS90UX9XX_INVALID_PARAMETER;
}

static
ds90ux9xx_err_t pll_set_fpd4(const ds90ux9xx_st_t *dev, fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint64_t bandwidth = 0;
        uint64_t fpd_freq = 0;
        uint32_t post_divider = 0;
        uint32_t n_divider = 0;
        uint8_t reg = 0;
        uint8_t val = 0;
        uint8_t vco = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds981_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        fpd_freq = bandwidth / DS981_FPD_BITS_PER_CLOCK;

        rc = pll_fpd4_match_dividers(fpd_freq, &n_divider, &post_divider);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't match dividers: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        if (bandwidth == MHZ_TO_HZ(DS981_LINE_RATE_3P375MBPS)) {
                post_divider = DS981_PLL_VCO_DIV_3P375GBPS;
        }

        log_dbg("bandwidth   : %llu\n", bandwidth);
        log_dbg("fpd_freq    : %llu\n", fpd_freq);
        log_dbg("VCO         : %d\n", DS981_PLL_FPD4_VCO_DEFAULT);
        log_dbg("post_divider: %d\n", post_divider);
        log_dbg("post_div_reg: 0x%x\n", to_fpd4_pdiv(post_divider));
        log_dbg("MASH        : 0x%x\n", DS981_PLL_FPD4_MASH_ORDER);
        log_dbg("NDIV        : %d\n", n_divider);
        log_dbg("Numerator   : %d\n", DS981_PLL_FPD4_NUMERATOR_DEFAULT);
        log_dbg("Denominator : %d\n", DS981_PLL_FPD4_DENOMINATOR_DEFAULT);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_MASH_ORDER, port);

        rc = ds90ux9xx_i2c_write_ind_1b(dev,
                                        DS981_IND_PAGE_2,
                                        reg,
                                        DS981_PLL_FPD4_MASH_ORDER);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_VCO, port);
        vco = TO_PLL_VCO(DS981_PLL_FPD4_VCO_DEFAULT);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         vco);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_NDIV, port);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         n_divider);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_DEN, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         DS981_PLL_FPD4_DENOMINATOR_DEFAULT);

        reg = TO_PLL_PORT_REG(DS981_IND_REG_PLL_PDIV, port);
        val = to_fpd4_pdiv(post_divider) | DS981_PLL_VCO_AUTO_SELECT;

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS981_IND_PAGE_2,
                                         reg,
                                         val);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't setup PLL on port %d. %s\n", port,
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

ds90ux9xx_err_t pll_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->fpd.port ||
            dev->fpd.ports_cnt <= 0 ||
            dev->fpd.ports_cnt > DS981_MAX_FPD_PORTS) {
                log_err("Invalid input: fpd.ports_cnt = %p, fpd.port = %p\n",
                        dev->fpd.ports_cnt, dev->fpd.port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < dev->fpd.ports_cnt; i++) {
                if (true == dev->settings.backward_compatibility) {
                        log_dbg("Init PLL in FPD3 mode for port %d\n",
                                dev->fpd.port[i].id);

                        rc |= pll_set_fpd3(dev, dev->fpd.port[i].id);
                } else {
                        log_dbg("Init PLL in FPD4 mode for port %d\n",
                                dev->fpd.port[i].id);

                        rc |= pll_set_fpd4(dev, dev->fpd.port[i].id);
                }
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't setup PLL. %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        /* reset both PLL channels */
        rc = pll_reset_channel(dev, PLL_CH0_CH1);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't reset both PLL channels. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return DS90UX9XX_INIT_FAILURE;
        }

        log_dbg("PLL init done\n");

        return rc;
}

ds90ux9xx_err_t configure_video_subsystem(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_disable_all(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't disable VP\n");

                return rc;
        }

        rc = vp_init_subsystem(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init VP subsystem\n");

                return rc;
        }

        rc = backward_channel_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init backward channel: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = pll_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init PLL\n");

                return rc;
        }

        rc = init_fpd_ports(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't initialize fpd port: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = link_layer_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init timeslots\n");

                return rc;
        }

        rc = bridge_reset(dev, DS981_RESET_NO_REGS);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't do soft reset (no regs)\n");

                return rc;
        }

        log_dbg("FPD ports init done\n");

        rc = vp_enable_all(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable VPs\n");

                return rc;
        }

        return rc;
}

