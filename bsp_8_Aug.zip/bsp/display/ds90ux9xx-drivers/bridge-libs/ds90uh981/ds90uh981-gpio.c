/**
 * @file       ds90uh981-gpio.c
 * @brief      ds90ub981 / ds90uh981 GPIO settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90uh981-gpio-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh981-gpio.h"
#endif /* UNITTEST */

#define FC_GPIO_FIXED_0         0x0E
#define FC_GPIO_FIXED_1         0x0F

#define BYTE_HIGH_MASK          0xF0
#define BYTE_LOW_MASK           0x0F
#define BYTE_HIGH_SHIFT         4
#define BYTE_LOW_SHIFT          0

/* FC GPIO number */
#define FC_GPIO_0               0
#define FC_GPIO_1               1

#define FPD4_FC_NO_GPIOS        0
#define FPD4_FC_1_GPIO          BIT(0)
#define FPD4_FC_2_GPIOS         BIT(1)
#define FPD4_FC_ALL_GPIOS       (BIT(0) | BIT(1))

typedef struct ds90uh981_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t stat_reg;
        const uint8_t input;
} ds981_pins_st_t;

typedef struct ds90ub981_fc_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t offset;
        const uint8_t mask;
} ds90ub981_fc_pins_st_t;

#define IS_FUNCTION_PRESENT(val, function) ((function) == ((val) & (function)))

#define DS981_GPIO(gpio_name, gpio_reg_addr, gpio_stat_reg, gpio_in_crtl_reg)   \
        {                                                                       \
                .name = (gpio_name),                                            \
                .reg = (gpio_reg_addr),                                         \
                .stat_reg = (gpio_stat_reg),                                    \
                .input = (gpio_in_crtl_reg),                                    \
        }

#define DS981_FC_GPIO(gpio_name, gpio_reg_addr, gpio_offset, gpio_mask)         \
        {                                                                       \
                .name = (gpio_name),                                            \
                .reg = (gpio_reg_addr),                                         \
                .offset = (gpio_offset),                                        \
                .mask = (gpio_mask),                                            \
        }

static ds90ub981_fc_pins_st_t ds981_fc_gpios[DS981_GPIO_FC_COUNT] = {
        DS981_FC_GPIO("fc_gpio0",
                      DS981_REG_GPIO_FC_CTRL0,
                      BYTE_LOW_SHIFT,
                      BYTE_LOW_MASK),
        DS981_FC_GPIO("fc_gpio1",
                      DS981_REG_GPIO_FC_CTRL0,
                      BYTE_HIGH_SHIFT,
                      BYTE_HIGH_MASK),
        DS981_FC_GPIO("fc_gpio2",
                      DS981_REG_GPIO_FC_CTRL1,
                      BYTE_LOW_SHIFT,
                      BYTE_LOW_MASK),
        DS981_FC_GPIO("fc_gpio3",
                      DS981_REG_GPIO_FC_CTRL1,
                      BYTE_HIGH_SHIFT,
                      BYTE_HIGH_MASK),
};

static ds981_pins_st_t ds981_gpios[DS981_GPIO_COUNT] = {
        DS981_GPIO("gpio0",
                   DS981_REG_GPIO_0,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio1",
                   DS981_REG_GPIO_1,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio2",
                   DS981_REG_GPIO_2,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio3",
                   DS981_REG_GPIO_3,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio4",
                   DS981_REG_GPIO_4,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio5",
                   DS981_REG_GPIO_5,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio6",
                   DS981_REG_GPIO_6,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio7",
                   DS981_REG_GPIO_7,
                   DS981_REG_GPIO_STS1,
                   DS981_REG_GPIO_INPUT_ENABLE_0),
        DS981_GPIO("gpio8",
                   DS981_REG_GPIO_8,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
        DS981_GPIO("gpio9",
                   DS981_REG_GPIO_9,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
        DS981_GPIO("gpio10",
                   DS981_REG_GPIO_10,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
        DS981_GPIO("gpio11",
                   DS981_REG_GPIO_11,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
        DS981_GPIO("gpio12",
                   DS981_REG_GPIO_12,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
        DS981_GPIO("gpio13",
                   DS981_REG_GPIO_13,
                   DS981_REG_GPIO_STS2,
                   DS981_REG_GPIO_INPUT_ENABLE_1),
};

static
ds90ux9xx_err_t is_wrong_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS981_GPIO_COUNT) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t is_wrong_bc_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS981_GPIO_BC_COUNT) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t check_fc_gpio_number(const ds90ux9xx_st_t *dev, int fc_num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t available_gpios_count = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (fc_num <= NOT_SPECIFIED ||
            fc_num >= DS981_GPIO_FC_COUNT) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS981_REG_FPD4_DATAPATH_CTL,
                                &available_gpios_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD4_DATAPATH_CTL register\n");

                return rc;
        }

        if (FPD4_FC_NO_GPIOS == available_gpios_count) {
                log_err("No FC_GPIOs are available\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FPD4_FC_1_GPIO == available_gpios_count &&
            FC_GPIO_0 != fc_num) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FPD4_FC_2_GPIOS == available_gpios_count &&
            FC_GPIO_0 != fc_num && FC_GPIO_1 != fc_num) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
inline ds90ux9xx_err_t is_wrong_fc_gpio_remote(gpio_remote_t remote)
{
        return is_wrong_gpio_number(remote);
}

static
ds90ux9xx_err_t check_fc_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = check_fc_gpio_number(dev, gpio->fc_num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong forward channel GPIO number: gpio.fc_num = %d\n",
                        gpio->fc_num);

                return rc;
        }

        /*
         * check FC_GPIOx with fixed value
         * if not - check remote for GPIO num
         */
        if (NOT_SPECIFIED != gpio->value) {
                return DS90UX9XX_SUCCESS;
        }

        rc = is_wrong_fc_gpio_remote(gpio->remote);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong forward channel GPIO remote: gpio.remote = %d\n",
                        gpio->remote);
        }

        return rc;
}

static
inline ds90ux9xx_err_t gpio_input(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong GPIO number: num = %u\n", num);

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_gpios[num].input, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ENABLE == state) {
                val |= GPIO_INPUT_EN(num);
        } else {
                val &= ~GPIO_INPUT_EN(num);
        }

        rc = ds90ux9xx_i2c_write(dev, ds981_gpios[num].input, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
inline ds90ux9xx_err_t gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong GPIO number: num = %u\n", num);

                return rc;
        }

        if (DISABLE == state) {
                val = GPIO_DISABLE_OUTPUT;
        } else {
                if (GPIO_LOW == value) {
                        val = DS981_GPIO_OUTPUT_LOW;
                }

                if (GPIO_HIGH == value) {
                        val = DS981_GPIO_OUTPUT_HIGH;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, ds981_gpios[num].reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_input(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_output(dev, gpio->num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, gpio->num, ENABLE);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_output(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, gpio->num, DISABLE);
        rc |= gpio_output(dev, gpio->num, ENABLE, gpio->value);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_disable(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, num, DISABLE);
        rc |= gpio_output(dev, num, DISABLE, GPIO_LOW);

        return rc;
}

static
uint8_t gpio_function_to_reg_val(ds90ux9xx_gpio_st_t *gpio)
{
        uint8_t val = FUNC_WRONG;

        if (NULL == gpio) {
                log_err("Invalid input: gpio = %p\n", gpio);

                return val;
        }

        switch (gpio->function) {
        case FUNC_REMOTE_IRQ:
                val = GPIO_REMOTE_IRQ;
                break;
        case FUNC_RX_LOCK_DETECT:
                val = GPIO_RX_LOCK;
                break;
        case FUNC_FPD_TX_IRQ:
                if (GPIO_LOW == gpio->value) {
                        val = GPIO_FPD_TX_IRQ_LOW;
                }

                if (GPIO_HIGH == gpio->value) {
                        val = GPIO_FPD_TX_IRQ_HIGH;
                }

                break;
        default:
                log_err("Incorrect function value\n");
        }

        return val;
}

static
ds90ux9xx_err_t set_gpio_remote_irq(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;
        uint8_t reg_val = 0;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong GPIO number: gpio.num = %d\n", gpio->num);

                return rc;
        }

        if (NOT_SPECIFIED == gpio->port) {
                log_err("GPIO port is not specified\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg_val = gpio_function_to_reg_val(gpio);
        if (FUNC_WRONG == reg_val) {
                log_err("Incorrect gpio->function value\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, gpio->num, DISABLE);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");

                return rc;
        }

        reg_val = DS981_GPIO_SET_REM_IRQ(gpio->port, reg_val);

        rc = ds90ux9xx_i2c_write(dev, ds981_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_back_channel(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_val;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong GPIO number: gpio.num = %d\n", gpio->num);

                return rc;
        }

        rc = is_wrong_bc_gpio_number(gpio->remote);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Wrong back channel GPIO number: gpio.remote = %d\n",
                        gpio->remote);

                return rc;
        }

        if (NOT_SPECIFIED == gpio->port) {
                log_err("GPIO port is not specified\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, gpio->num, DISABLE);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");

                return rc;
        }

        reg_val = DS981_GPIO_SET_BC(gpio->port, gpio->remote);

        log_dbg("The gpio %d with BC GPIO%d port=%d set: 0%x\n",
                gpio->num, gpio->remote, gpio->port, reg_val);

        rc = ds90ux9xx_i2c_write(dev, ds981_gpios[gpio->num].reg, reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update GPIO register\n");
        }

        return rc;
}

static
void fc_gpio_value_to_reg_val(gpio_value_t fc_value, uint8_t *val)
{
        if (NULL == val) {
                log_err("Invalid input: val = %p\n", val);

                return;
        }

        if (GPIO_LOW == fc_value) {
                *val = FC_GPIO_FIXED_0;
        } else if (GPIO_HIGH == fc_value) {
                *val = FC_GPIO_FIXED_1;
        } else {
                log_err("Incorrect GPIO value\n");
        }
}

static
ds90ux9xx_err_t set_gpio_forward_channel(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;
        uint8_t val = 0;
        uint8_t reg_val = 0;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = check_fc_gpio(dev, gpio);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Incorrect FC_GPIO%d\n", gpio->fc_num);

                return rc;
        }

        if (NOT_SPECIFIED != gpio->value) {
                fc_gpio_value_to_reg_val(gpio->value, &val);
        } else {
                /*
                 * Notice: the GPIO pin (linked to FC_GPIOx)
                 * must be programmed for input mode
                 */
                rc = gpio_input(dev, gpio->remote, ENABLE);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't update GPIO register\n");

                        return rc;
                }

                val = gpio->remote;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_fc_gpios[gpio->fc_num].reg,
                                &reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FC_GPIO register\n");

                return rc;
        }

        val = DS981_GPIO_SET_FC(val, reg_val, ds981_fc_gpios[gpio->fc_num]);

        rc = ds90ux9xx_i2c_write(dev, ds981_fc_gpios[gpio->fc_num].reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't update FC_GPIO register\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh981_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                rc = set_gpio_input(dev, gpio);
                break;
        case FUNC_GPIO_OUTPUT:
                rc = set_gpio_output(dev, gpio);
                break;
        case FUNC_REMOTE_IRQ:
        case FUNC_RX_LOCK_DETECT:
        case FUNC_FPD_TX_IRQ:
                rc = set_gpio_remote_irq(dev, gpio);
                break;
        case FUNC_REMOTE_BC:
                rc = set_gpio_back_channel(dev, gpio);
                break;
        case FUNC_REMOTE_FC:
                rc = set_gpio_forward_channel(dev, gpio);
                break;
        case FUNC_DISABLE:
                rc = set_gpio_disable(dev, gpio->num);
                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
gpio_remote_t to_gpio_remote(uint8_t reg_ctrl, uint8_t num)
{
        reg_ctrl = DS981_GPIO_FC(reg_ctrl, ds981_fc_gpios[num]);

        if (FC_GPIO_FIXED_0 == reg_ctrl ||
            FC_GPIO_FIXED_1 == reg_ctrl) {
                return NOT_SPECIFIED;
        }

        return reg_ctrl;
}

static
gpio_value_t to_gpio_value(uint8_t reg_ctrl, uint8_t num)
{
        reg_ctrl = DS981_GPIO_FC(reg_ctrl, ds981_fc_gpios[num]);

        if (FC_GPIO_FIXED_0 == reg_ctrl) {
                return GPIO_LOW;
        }

        if (FC_GPIO_FIXED_1 == reg_ctrl) {
                return GPIO_HIGH;
        }

        return NOT_SPECIFIED;
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t val;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: dev = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_gpios[num].stat_reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *value = !!(val & GPIO_STAT(num));

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
ds90ux9xx_err_t get_fc_gpio_value(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t reg_val;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: dev = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_fc_gpios[num].reg, &reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FC GPIO register\n");

                return rc;
        }

        *value = to_gpio_value(reg_val, num);

        log_dbg("Got value %d for FC_GPIO_%d\n", *value, num);

        return rc;
}

static
gpio_function_t get_function(uint8_t ctl_out, uint8_t ctl_in)
{
        if (ctl_in) {
                return FUNC_GPIO_INPUT;
        }

        if (true == IS_FUNCTION_PRESENT(ctl_out,
                                        DS981_GPIO_REM_IRQ(GPIO_FPD_TX_IRQ))) {
                return FUNC_FPD_TX_IRQ;
        }

        if (true == IS_FUNCTION_PRESENT(ctl_out,
                                        DS981_GPIO_REM_IRQ(GPIO_RX_LOCK))) {
                return FUNC_RX_LOCK_DETECT;
        }

        if (true == IS_FUNCTION_PRESENT(ctl_out,
                                        DS981_GPIO_REM_IRQ(GPIO_REMOTE_IRQ))) {
                return FUNC_REMOTE_IRQ;
        }

        if (true == IS_FUNCTION_PRESENT(ctl_out, DS981_GPIO_OUTPUT)) {
                return FUNC_GPIO_OUTPUT;
        }

        if (true == IS_FUNCTION_PRESENT(ctl_out, DS981_GPIO_BC)) {
                return FUNC_REMOTE_BC;
        }

        return FUNC_GPIO_INPUT;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t ctrl_out = 0;
        uint8_t ctrl_in = 0;

        if (NULL == dev || NULL == function) {
                log_err("Invalid input: dev = %p, function = %p\n",
                        dev, function);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_gpios[num].reg, &ctrl_out);

        rc |= ds90ux9xx_i2c_read(dev, ds981_gpios[num].input, &ctrl_in);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *function = get_function(ctrl_out, GPIO_INPUT_EN(num) & ctrl_in);

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

static
fpd_port_t get_port(uint8_t reg_val)
{
        if (TO_DS981_TX_PORT(reg_val)) {
                return PORT_1;
        }

        return PORT_0;
}

static
ds90ux9xx_err_t get_gpio_port(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, fpd_port_t *port)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == dev || NULL == port) {
                log_err("Invalid input: dev = %p, port = %p\n", dev, port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FUNC_GPIO_INPUT == function ||
            FUNC_GPIO_OUTPUT == function) {
                *port = NOT_SPECIFIED;

                return DS90UX9XX_SUCCESS;
        }

        reg = ds981_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *port = get_port(val);

        log_dbg("Got FPD port %d for GPIO_%d\n", *port, num);

        return rc;
}

static
ds90ux9xx_err_t get_fc_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        if (NULL == dev || NULL == function) {
                log_err("Invalid input: dev = %p, function = %p\n",
                        dev, function);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        *function = FUNC_REMOTE_FC;

        log_dbg("Got function %d for FC_GPIO_%d\n", *function, num);

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t get_bc_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_remote_t *remote)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_ctrl;

        if (NULL == dev || NULL == remote) {
                log_err("Invalid input: dev = %p, remote = %p\n", dev, remote);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_gpios[num].reg, &reg_ctrl);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return DS90UX9XX_I2C_RW_ERROR;
        }

        *remote = reg_ctrl & DS981_GPIO_BC_ANY;

        log_dbg("Got remote %d for GPIO_%d\n", *remote, num);

        return rc;
}

static
ds90ux9xx_err_t get_fc_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_ctrl;

        if (NULL == dev || NULL == remote) {
                log_err("Invalid input: dev = %p, remote = %p\n", dev, remote);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds981_fc_gpios[num].reg, &reg_ctrl);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FC GPIO register\n");

                return DS90UX9XX_I2C_RW_ERROR;
        }

        *remote = to_gpio_remote(reg_ctrl, num);

        log_dbg("Got remote %d for FC_GPIO_%d\n", *remote, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == remote) {
                log_err("Invalid input: dev = %p, remote = %p\n", dev, remote);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (function) {
        case FUNC_REMOTE_BC:
                rc = get_bc_remote(dev, num, remote);
                break;
        case FUNC_REMOTE_FC:
                rc = get_fc_remote(dev, num, function, remote);
                break;
        default:
                *remote = NOT_SPECIFIED;

                log_dbg("No GPIO remote configuration\n");
        }

        return rc;
}

static
ds90ux9xx_err_t get_fc_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_fc_gpio_function(dev, gpio->fc_num, &gpio->function);
        rc |= get_gpio_remote(dev, gpio->fc_num, gpio->function, &gpio->remote);
        rc |= get_fc_gpio_value(dev, gpio->fc_num, &gpio->value);

        return rc;
}

static
ds90ux9xx_err_t get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_port(dev, gpio->num, gpio->function, &gpio->port);
        rc |= get_gpio_remote(dev, gpio->num, gpio->function, &gpio->remote);
        rc |= get_gpio_value(dev, gpio->num, &gpio->value);

        return rc;
}

ds90ux9xx_err_t ds90uh981_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_INVALID_PARAMETER;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = is_wrong_gpio_number(gpio->num);
        if (DS90UX9XX_SUCCESS == rc) {
                rc = get_gpio(dev, gpio);

                return rc;
        }

        rc = check_fc_gpio_number(dev, gpio->fc_num);
        if (DS90UX9XX_SUCCESS == rc) {
                rc = get_fc_gpio(dev, gpio);

                return rc;
        }

        log_err("Wrong GPIO number: gpio.num = %d, gpio.fc_num = %d\n",
                gpio->num, gpio->fc_num);

        return rc;
}

