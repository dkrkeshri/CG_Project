/**
 * @file       ds90uh981-adc.c
 * @brief      ds90uh981 ADC settings API
 *
 * @author     Serhii Bura <external.serhii.bura@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90uh981-adc-mock.h"
#include "UT-ds90uh981-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh981.h"
#include "ds90uh981-adc.h"
#include "ds90uh981-adc-internal.h"
#endif /* UNITTEST */

static
ds90ux9xx_err_t adc_write_settings(ds90ux9xx_st_t *dev,
        adc_settings_st_t *settings)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == settings) {
                log_err("Invalid input: dev = %p, settings = %p\n", dev,
                        settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_14,
                                         DS981_IND_REG_SAR_ADC_SETTINGS,
                                         settings->adc_enable);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS981_IND_PAGE_14,
                                         DS981_IND_REG_SAR_ADC_CLK_DIV_SEL,
                                         settings->clk);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS981_IND_PAGE_14,
                                         DS981_IND_REG_SAR_ADC_INPUT_EN_LSB,
                                         settings->input_enable);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup SAR ADC. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t adc_read_settings(ds90ux9xx_st_t *dev,
        adc_settings_st_t *settings)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == settings) {
                log_err("Invalid input: dev = %p, settings = %p\n", dev,
                        settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS981_IND_PAGE_14,
                                        DS981_IND_REG_SAR_ADC_SETTINGS,
                                        &settings->adc_enable);
        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS981_IND_PAGE_14,
                                        DS981_IND_REG_SAR_ADC_CLK_DIV_SEL,
                                        &settings->clk);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS981_IND_PAGE_14,
                                        DS981_IND_REG_SAR_ADC_INPUT_EN_LSB,
                                        &settings->input_enable);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t adc_enable_input(ds90ux9xx_st_t *dev, adc_type_t adc_type)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        adc_settings_st_t adc_settings = {
                .adc_enable   = DS90UH981_ADC_ENABLE,
                .clk          = DS90UH981_ADC_CLK_DIVIDER_8_33_HZ |
                                DS90UH981_ADC_CLK_AVG_4_SAMPLES,
                .input_enable = (uint16_t)adc_type
        };

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = adc_write_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup SAR ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        ds_usleep(DS90UH981_ADC_TIMEOUT_2MS);

        return rc;
}

static
ds90ux9xx_err_t adc_read_temperature(ds90ux9xx_st_t *dev, uint32_t *temperature)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t value = 0;

        if (NULL == dev || NULL == temperature) {
                log_err("Invalid input: dev = %p, temperature = %p\n", dev,
                        temperature);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS981_IND_PAGE_14,
                                       DS981_IND_REG_TEMP_FINAL, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read temperature. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *temperature = value;

        log_dbg("ADC temperature readed: %u\n", *temperature);

        return rc;
}

ds90ux9xx_err_t ds90uh981_adc_get_temperature(ds90ux9xx_st_t *dev,
        uint32_t *temperature)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        adc_settings_st_t adc_settings = {0};

        if (NULL == dev || NULL == temperature) {
                log_err("Invalid input: dev = %p, temperature = %p\n", dev,
                        temperature);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = adc_read_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to save ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = adc_enable_input(dev, TEMPERATURE);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup ADC. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                goto restore_settings;
        }

        rc = adc_read_temperature(dev, temperature);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read temperature. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

restore_settings:
        rc |= adc_write_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to restore ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

ds90ux9xx_err_t ds90uh981_adc_get_shortage(ds90ux9xx_st_t *dev,
        uint32_t *shortage)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == shortage) {
                log_err("Invalid input: dev = %p, shortage = %p\n", dev,
                        shortage);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /*
         * TODO: Implement function
         */

        log_info("API not impemented\n");

        return rc;
}

