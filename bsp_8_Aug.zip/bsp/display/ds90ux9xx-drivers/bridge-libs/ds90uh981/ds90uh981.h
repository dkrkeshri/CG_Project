/**
 * @file       ds90uh981.h
 * @brief      ds90ub981 / ds90uh981 specific registers, configurations
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH981_H__
#define __DS90UH981_H__

#include "ds90ux9xx-core.h"

#ifdef UNITTEST
#include "UT-ds90ux9xx-i2c-mock.h"
#else /* aarch64 */
#include "ds90ux9xx-i2c.h"
#endif /* UNITTEST */

#define DEVICE_ID                           "_UH981"
#define DEVICE_ID_LEN                       6
#define DS981_I2C_SLAVE_COUNT               8
#define DS981_MAX_I2C_COUNT                 2
#define DS981_SINGLE_VP                     1
#define DS981_MAX_VP_COUNT                  4
#define DS981_MAX_VP_COUNT_FPD3             2
#define DS981_MAX_FPD_PORTS                 2
#define DS981_MAX_PHY_PORTS                 2
#define DS981_MAX_VCO_COUNT                 4

/* i2c slave routing */
#define DS981_MAX_REMOTE_I2C_COUNT          2
#define DS981_MAX_I2C_DEPTH                 3

#define DS981_I2C_DEPTH_OFFSET              5
#define DS981_I2C_DEST_ADDR_SHIFT           5

#define DS981_I2C_DEST_ADDR(n)              ((n) << DS981_I2C_DEST_ADDR_SHIFT)
#define TO_I2C_DEPTH(depth)                 (DS981_I2C_DEPTH_OFFSET - (depth))
#define DS981_I2C_DEPTH_PORT(depth, port)   ((port) << TO_I2C_DEPTH(depth))

/* ds90uh981 registers */

#define DS981_REG_I2C_DEV_ID                0x0
#define DS981_REG_RESET_CTL                 0x01
#define DS981_REG_GENERAL_CFG2              0x02
#define DS981_REG_FPD4_CFG                  0x05
#define DS981_REG_GEN_STATUS2               0x06
#define DS981_REG_FPD4_DATAPATH_CTL         0x0D

#define DS981_REG_GEN_STATUS_0              0x0C
#define DS981_REG_GEN_STATUS_1              0x06
#define DS981_REG_GENERAL_CFG               0x07
#define DS981_REG_DES_ID                    0x08

#define DS981_REG_CRC_ERROR0                0x0A
#define DS981_REG_CRC_ERROR1                0x0B

#define DS981_REG_BIST_BC_ERRORS            0x0F
#define DS981_REG_TX_BIST_CTL               0x14

#define DS981_REG_CHIP_REV                  0x30

#define DS981_REG_IND_CTL                   0x40
#define DS981_REG_IND_ADDR                  0x41
#define DS981_REG_IND_DATA                  0x42

#define DS981_REG_VP_CONFIG_REG             0x43
#define DS981_REG_VP_ENABLE_REG             0x44
#define DS981_REG_VP_GLOBAL_STS             0x45
#define DS981_REG_VP_GLOBAL_ISR             0x46
#define DS981_REG_TX_PORT_SEL               0x2D
#define DS981_REG_BRIDGE_CTL                0x4F
#define DS981_REG_INTERRUPT_CTL             0x51
#define DS981_REG_FPD3_STREAM_SEL           0x57
#define DS981_REG_FPD3_MODE_CTL             0x59
#define DS981_REG_FPD3_FIFO_CFG             0x5B
#define DS981_REG_BC_DOWN_SAMPLING_RATE     0x6A
#define DS981_REG_DATAPATH_BC_FC            0x6E

#define DS981_REG_SLAVE_ID_0                0x70
#define DS981_REG_SLAVE_ID_1                0x71
#define DS981_REG_SLAVE_ID_2                0x72
#define DS981_REG_SLAVE_ID_3                0x73
#define DS981_REG_SLAVE_ID_4                0x74
#define DS981_REG_SLAVE_ID_5                0x75
#define DS981_REG_SLAVE_ID_6                0x76
#define DS981_REG_SLAVE_ID_7                0x77

#define DS981_REG_SLAVE_ALIAS_0             0x78
#define DS981_REG_SLAVE_ALIAS_1             0x79
#define DS981_REG_SLAVE_ALIAS_2             0x7A
#define DS981_REG_SLAVE_ALIAS_3             0x7B
#define DS981_REG_SLAVE_ALIAS_4             0x7C
#define DS981_REG_SLAVE_ALIAS_5             0x7D
#define DS981_REG_SLAVE_ALIAS_6             0x7E
#define DS981_REG_SLAVE_ALIAS_7             0x7F

#define DS981_REG_SLAVE_DEST_0              0x88
#define DS981_REG_SLAVE_DEST_1              0x89
#define DS981_REG_SLAVE_DEST_2              0x8A
#define DS981_REG_SLAVE_DEST_3              0x8B
#define DS981_REG_SLAVE_DEST_4              0x8C
#define DS981_REG_SLAVE_DEST_5              0x8D
#define DS981_REG_SLAVE_DEST_6              0x8E
#define DS981_REG_SLAVE_DEST_7              0x8F

#define DS981_REG_GPIO_FC_CTRL0             0x15
#define DS981_REG_GPIO_FC_CTRL1             0x16
#define DS981_REG_GPIO_0                    0x17
#define DS981_REG_GPIO_1                    0x18
#define DS981_REG_GPIO_2                    0x19
#define DS981_REG_GPIO_3                    0x1A
#define DS981_REG_GPIO_4                    0x1B
#define DS981_REG_GPIO_5                    0x1C
#define DS981_REG_GPIO_6                    0x1D
#define DS981_REG_GPIO_7                    0x1E
#define DS981_REG_GPIO_8                    0x1F
#define DS981_REG_GPIO_9                    0x20
#define DS981_REG_GPIO_10                   0x21
#define DS981_REG_GPIO_11                   0x22
#define DS981_REG_GPIO_12                   0x23
#define DS981_REG_GPIO_13                   0x24
#define DS981_REG_GPIO_STS1                 0x25
#define DS981_REG_GPIO_STS2                 0x26
#define DS981_REG_GPIO_INPUT_ENABLE_1       0x3E
#define DS981_REG_GPIO_INPUT_ENABLE_0       0x3F

#define DS981_REG_DSI_ERROR                 0xB1

#define DS981_REG_VP_DPHY_SEL0              0xBD
#define DS981_REG_VP_DPHY_SEL1              0xBE

#define DS981_REG_DEV_ID                    0xF0

/* Indirect registers page 2 (PLL control) */
#define DS981_IND_REG_PLL_MASH_ORDER        0x04
#define DS981_IND_REG_PLL_NDIV              0x05
#define DS981_IND_REG_PLL_VCO               0x0E
#define DS981_IND_REG_PLL_PDIV              0x13
#define DS981_IND_REG_PLL_DEN               0x18
#define DS981_IND_REG_PLL_NUM               0x1E

/* Indirect registers page 4/6 (DPHY) */
#define DS981_IND_REG_DSI_DPHY_ERR_CNT      0x29
#define DS981_IND_REG_DPHY_STATUS           0x0F

#define DS981_IND_REG_PLL_CH1_SHIFT         0x40

#define TO_PLL_PORT_REG(reg, port)          ((reg) +                            \
                                             DS981_IND_REG_PLL_CH1_SHIFT *      \
                                             (port))

/* Indirect registers page 11 (link layers) */
#define DS981_IND_REG_LINK_LAYER_CTL        0x00
#define DS981_IND_REG_LINK0_STREAM_ENABLE   0x01
#define DS981_IND_REG_LINK_MAP_STREAM_0_1   0x02
#define DS981_IND_REG_LINK_MAP_STREAM_2_3   0x03
#define DS981_IND_REG_LINK0_SLOT_STREAM0    0x06
#define DS981_IND_REG_LINK1_STREAM_ENABLE   0x11
#define DS981_IND_REG_LINK1_SLOT_STREAM0    0x16

/* Indirect registers page 12 (Video processor) */
#define DS981_IND_REG_VP_CTL                0x00
#define DS981_IND_REG_VP_CFG                0x01
#define DS981_IND_REG_VP_DP_H_ACTIVE0       0x02
#define DS981_IND_REG_VP_CROP_START_X0      0x08
#define DS981_IND_REG_VP_CROP_START_X1      0x09
#define DS981_IND_REG_VP_CROP_START_Y0      0x0A
#define DS981_IND_REG_VP_CROP_START_Y1      0x0B
#define DS981_IND_REG_VP_CROP_STOP_X0       0x0C
#define DS981_IND_REG_VP_CROP_STOP_X1       0x0D
#define DS981_IND_REG_VP_CROP_STOP_Y0       0x0E
#define DS981_IND_REG_VP_CROP_STOP_Y1       0x0F
#define DS981_IND_REG_VP_VID_H_ACTIVE0      0x10
#define DS981_IND_REG_VP_VID_H_BACK0        0x12
#define DS981_IND_REG_VP_VID_H_WIDTH0       0x14
#define DS981_IND_REG_VP_VID_H_TOTAL0       0x16
#define DS981_IND_REG_VP_VID_V_ACTIVE0      0x18
#define DS981_IND_REG_VP_VID_V_BACK0        0x1A
#define DS981_IND_REG_VP_VID_V_WIDTH0       0x1C
#define DS981_IND_REG_VP_VID_V_FRONT0       0x1E
#define DS981_IND_REG_VP_PCLK_GEN_M         0x23
#define DS981_IND_REG_VP_PCLK_GEN_N         0x25
#define DS981_IND_REG_VP_STS                0x30
#define DS981_IND_REG_VP_ISR_BASE           0x31
#define DS981_IND_REG_VP_ICR                0x33

/* Indirect registers page 14 (Temperature / Voltage) */
#define DS981_IND_REG_SAR_ADC_CLK_DIV_SEL   0x04
#define DS981_IND_REG_SAR_ADC_INPUT_EN_LSB  0x07
#define DS981_IND_REG_SAR_ADC_INPUT_EN_MSB  0x08
#define DS981_IND_REG_SAR_ADC_SETTINGS      0x0D
#define DS981_IND_REG_TEMP_FINAL            0x13
#define DS981_IND_REG_LINE_FAULT0_FINAL     0x1D
#define DS981_IND_REG_LINE_FAULT1_FINAL     0x1E
#define DS981_IND_REG_LINE_FAULT2_FINAL     0x1F
#define DS981_IND_REG_LINE_FAULT3_FINAL     0x20

/* ds90uh981 General Status Register 0 bits (0x0C) */
#define DS981_LINK_DETECT                   BIT(0)
#define DS981_BC_CRC_ERROR                  BIT(1)
#define DS981_BIST_CRC_ERROR                BIT(3)
#define DS981_LINK_LOST                     BIT(4)
#define DS981_TX_LOCK_DETECT                BIT(6)

/* ds90uh981 bits and descriptions */
#define DS981_I2C_DEV_ID_SET                BIT(0)
#define DS981_IND_READ                      BIT(0)
#define DS981_IND_AUTO_INC                  BIT(1)
#define IND_PAGE_SHIFT                      2
#define TO_IND_PAGE(page)                   ((page) << IND_PAGE_SHIFT)
#define DS981_IND_PAGE_0                    TO_IND_PAGE(0)
#define DS981_IND_PAGE_2                    TO_IND_PAGE(2)
#define DS981_IND_PAGE_4                    TO_IND_PAGE(4)
#define DS981_IND_PAGE_6                    TO_IND_PAGE(6)
#define DS981_IND_PAGE_9                    TO_IND_PAGE(9)
#define DS981_IND_PAGE_11                   TO_IND_PAGE(11)
#define DS981_IND_PAGE_12                   TO_IND_PAGE(12)
#define DS981_IND_PAGE_14                   TO_IND_PAGE(14)
#define DS981_IND_PAGE_MAX                  DS981_IND_PAGE_14

/***********************************/
/* TX port selection configuration */
/***********************************/
#define DS981_TX_PORT_0_WRITE               BIT(0)
#define DS981_TX_PORT_1_WRITE               BIT(1)
#define DS981_TX_PORT_1_READ                BIT(4)

/* read port 0 is set by deafult as the value for that is 0 */
#define DS981_TX_PORT_0_ENABLE              DS981_TX_PORT_0_WRITE
#define DS981_TX_PORT_1_ENABLE              (DS981_TX_PORT_1_WRITE |            \
                                             DS981_TX_PORT_1_READ)

#define DS981_I2C_PASS_THROUGH              BIT(3)
#define DS981_I2C_PASS_THROUGH_MASK         DS981_I2C_PASS_THROUGH
#define DS981_RX_CRC_CHECKER_ENABLE         BIT(7)
#define DS981_RX_CRC_CHECKER_MASK           DS981_RX_CRC_CHECKER_ENABLE

#define DS981_DSI_INPUT_DISABLE             BIT(3)

#define DS981_DSI_HS_CLK                    BIT(7)
#define DS981_DSI_LANES_SHIFT               2
#define DS981_DSI_LANES_MASK                (BIT(3) | BIT(2))
#define DS981_DSI_LANES_CLEAR               ~DS981_DSI_LANES_MASK
#define DS981_DSI_LANES(x)                  (((x) - 1) << DS981_DSI_LANES_SHIFT)

#define DS981_FPD3_TX_MODE                  (BIT(2) | BIT(1) | BIT(0))
#define DS981_FPD3_TX_MODE_SINGLE_PORT_0    BIT(0)
#define DS981_FPD3_TX_MODE_DUAL             (BIT(1) | BIT(0))
#define DS981_FPD3_TX_MODE_INDEPENDENT      (BIT(2) | BIT(0))
#define DS981_FPD3_TX_MODE_SPLITTER         (BIT(2) | BIT(1) | BIT(0))
#define DS981_FPD4_PORT0_SHIFT              2
#define DS981_FPD4_PORT1_SHIFT              4
#define DS981_FPD4_TX_MODE_FPD3             0
#define DS981_FPD4_TX_MODE_SINGLE           BIT(0)
#define DS981_FPD4_TX_MODE_DUAL             BIT(1)
#define DS981_FPD4_TX_MODE_INDEPENDENT      (BIT(1) | BIT(0))
#define DS981_FPD4_CLEAN_TX_MODE            (BIT(1) | BIT(0))
#define DS981_FPD4_TX_MODE_MASK             DS981_FPD4_CLEAN_TX_MODE

#define DS981_FPD4_TX_MODE(port, mode)                                          \
        ((mode) << ((port) ? DS981_FPD4_PORT1_SHIFT : DS981_FPD4_PORT0_SHIFT))
#define DS981_FPD4_PORT_TX_MODE(port, val)                                      \
        (((val) >> ((port) ? DS981_FPD4_PORT1_SHIFT : DS981_FPD4_PORT0_SHIFT))  \
         & DS981_FPD4_TX_MODE_MASK)

/* fpd3 backward compatibility based on script/errata
 * DS981_FPD3_FIFO_CONFIG and DS981_FPD3_GENERAL_CFG2
 * values are provided by TI
 */
#define DS981_FPD3_FIFO_CONFIG              0x2B
#define DS981_FPD3_GENERAL_CFG2             (BIT(7) | BIT(6) | BIT(4))

#define DS981_DATAPATH_BC_FC_135MBPS        0x80
#define DS981_DATAPATH_BC_FC_168P75MBPS     0x86

#define DS981_BC_DOWN_SAMPLING_RATE_1       0x0A
#define DS981_BC_DOWN_SAMPLING_RATE_4       0x4A

/* PLL */
#define DS981_MAX_VCO                       4
#define DS981_PLL_FPD3_VCO_MIN_FREQ         3500
#define DS981_PLL_FPD3_VCO_MAX_FREQ         7500
#define PLL_MAX_DENOMINATOR                 16777206
#define PLL_REFCLK_27MHZ                    27
#define VCO_OFFSET                          2
#define DS981_VCO_BASE_CODE                 0xC3
#define DS981_FPD3_VCO_NUM_DEFAULT          0
#define TO_PLL_VCO(vco_num)                 (DS981_VCO_BASE_CODE |              \
                                             ((vco_num) << (VCO_OFFSET)))

/* set max denominator value that multiple ref_clk */
#define PLL_SET_MAX_DENOMINATOR(ref_clk)                                        \
        (PLL_MAX_DENOMINATOR / (ref_clk) * (ref_clk))
#define PLL_FPD3_PCLK_COEF                  35
#define PLL_REFCLK_COEF                     2
#define PLL_CH0                             0
#define PLL_CH1                             1
#define PLL_CH0_CH1                         2
#define DS981_PLL_POST_DIV_FPD3_4           (BIT(5) | BIT(6))
#define DS981_PLL_MASH_ORDER_FRACTIONAL     BIT(3)
#define DS981_PLL_MASH_ORDER_INTEGER        0x0
#define DS981_PLL_MASH_FPD3                 (DS981_PLL_MASH_ORDER_FRACTIONAL |  \
                                             BIT(0))
#define DS981_PLL_FPD4_MASH_ORDER           (DS981_PLL_MASH_ORDER_INTEGER |     \
                                             BIT(0))

#define DS981_CRC_ERR_CLEAN                 BIT(5)
#define DS981_BIST_ENABLE                   BIT(0)

#define PLL_VCO_DIV_1                       1
#define PLL_VCO_DIV_2                       2
#define PLL_VCO_DIV_4                       4
#define PLL_VCO_DIV_8                       8
#define PLL_VCO_DIV_16                      16

#define PLL_VCO_N_DIV_MIN                   63

#define DS981_PLL_FPD4_DIV_1_CODE           0x00
#define DS981_PLL_FPD4_DIV_2_CODE           0x10
#define DS981_PLL_FPD4_DIV_4_CODE           0x20
#define DS981_PLL_FPD4_DIV_8_CODE           0x30

#define DS981_PLL_FPD3_DIV_16_CODE          0x40
#define DS981_PLL_FPD3_DIV_2_CODE           0x50
#define DS981_PLL_FPD3_DIV_4_CODE           0x60
#define DS981_PLL_FPD3_DIV_8_CODE           0x70

#define DS981_PLL_FPD4_VCO_DEFAULT          1
#define DS981_PLL_FPD4_NDIV_DEFAULT         125
#define DS981_PLL_FPD4_NUMERATOR_DEFAULT    0
#define DS981_PLL_FPD4_DENOMINATOR_DEFAULT  PLL_MAX_DENOMINATOR

#define DS981_PLL_VCO_AUTO_SELECT           BIT(7)
#define DS981_PLL_FPD4_PDIV_DEFAULT         (DS981_PLL_VCO_AUTO_SELECT |        \
                                             DS981_PLL_FPD4_DIV_2_CODE)

#define DS981_PLL_PFD_FREQUENCY             (MHZ_TO_HZ(PLL_REFCLK_27MHZ) * 2)

#define DS981_PLL_VCO_DIV_3P375GBPS         PLL_VCO_DIV_2

#define DS981_FPD_BITS_PER_CLOCK            2

#define DS981_CALCULATE_PLL_N_DIV(f, div)   floor(((double)(f) /                \
                                                  DS981_PLL_PFD_FREQUENCY) *    \
                                                  (div))

/* reset bits */
#define DS981_RESET_NO_REGS                 BIT(0)
#define DS981_RESET_WITH_REGS               BIT(1)
#define DS981_RESET_PLL_CH0                 BIT(4)
#define DS981_RESET_PLL_CH1                 BIT(5)
#define DS981_RESET_NORMAL_OPERATION        0

/*
 * Unfortunately we can't reset 981 completely (reset autoload).
 * So RESET_ALL resets just clocks & regs
 */
#define DS981_RESET_ALL                     DS981_RESET_WITH_REGS

#define DS981_PLL_REFCLK_VALID              BIT(3)
#define DS981_XO_REFCLK_VALID               BIT(4)

#define DS981_FPD4_MODE_P0_MASK             (BIT(3) | BIT(2))
#define DS981_FPD4_MODE_P1_MASK             (BIT(5) | BIT(4))
#define DS981_FPD3_BOTH_PORTS_ENABLE_MASK   ~(DS981_FPD4_MODE_P0_MASK |         \
                                              DS981_FPD4_MODE_P1_MASK)

#define DS981_FPD3_FIFO_DRAIN               (BIT(0) | BIT(1))
#define DS981_ENABLE_FPD3_FIFO              BIT(3)
#define DS981_FPD3_ALIGN_ERR_THR            BIT(5)
#define DS981_DPRX_EN                       BIT(4)
#define DS981_FPD_HALFRATE_MODE_CH0         BIT(6)
#define DS981_FPD_HALFRATE_MODE_CH1         BIT(7)
#define DS981_FPD_HALFRATE_MODE             (DS981_FPD_HALFRATE_MODE_CH0 |      \
                                             DS981_FPD_HALFRATE_MODE_CH1)

#define DS981_FPD_HALFRATE_MODE_MANUAL      BIT(0)
#define DS981_FPD_HALFRATE_MODE_MANUAL_MASK DS981_FPD_HALFRATE_MODE_MANUAL

#define DS981_FPD_HALFRATE_MODE_DISABLE     0
#define DS981_FPD_HALFRATE_MODE_MASK        DS981_FPD_HALFRATE_MODE

/* Page 11 bits and operations */
#define DS981_MAX_LINK_LAYER_STREAMS        4
#define DS981_VP_MAP_STREAM_COUNT_IN_REG    2
#define MAP_SHIFT                           4
#define MAP_VP_TO_STREAM(vp, stream)        ((vp) << (MAP_SHIFT * (stream % 2)))
#define GET_STREAM_REG(port)                (((port) == PORT_0) ?               \
                                             DS981_IND_REG_LINK0_SLOT_STREAM0 : \
                                             DS981_IND_REG_LINK1_SLOT_STREAM0)
#define GET_STREAM_SLOT_REG(port, stream)   (GET_STREAM_REG(port) + (stream))
#define LINK_LAYER_0_ENABLE                 BIT(0)
#define LINK_LAYER_0_TIMESLOT_ENABLE        BIT(1)
#define LINK_LAYER_1_ENABLE                 BIT(2)
#define LINK_LAYER_1_TIMESLOT_ENABLE        BIT(3)
#define DS981_LINK_LAYER_0_ENABLE           (LINK_LAYER_0_ENABLE |              \
                                             LINK_LAYER_0_TIMESLOT_ENABLE)
#define DS981_LINK_LAYER_1_ENABLE           (LINK_LAYER_1_ENABLE |              \
                                             LINK_LAYER_1_TIMESLOT_ENABLE)
#define DS981_LINK_LAYERS_DISABLE           0
#define DS981_LINK_LAYERS_ENABLE            (DS981_LINK_LAYER_0_ENABLE |        \
                                             DS981_LINK_LAYER_1_ENABLE)
#define DS981_TIMESLOTS_LIMIT               65
#define DS981_MAX_BANDWIDTH_10_47GHZ        10.47

/* Page 12 bits and operations */
#define DS981_IND_REG_VP_REG_SHIFT          0x40
#define TO_VP_REG(base, vp_num)             ((base) + (vp_num) *                \
                                             DS981_IND_REG_VP_REG_SHIFT)
#define DS981_VP_ENABLE_CROPPING            BIT(2)
#define DS981_VP_DISABLE_CROPPING           0
#define DS981_VP_STATUS_CHANGE              BIT(0)
#define DS981_VP_ENABLE(n)                  (1 << (n))
#define DS981_DISABLE_ALL_VP                0
#define DS981_LINE_RATE_10P8MBPS            10800
#define DS981_LINE_RATE_6P75MBPS            6750
#define DS981_LINE_RATE_3P375MBPS           3375
#define DS981_FPD4_RATE_DIVIDER             40.0
#define DS981_VP_FPD4_PCLK_N_DEFAULT        15
#define DS981_VP_FPD4_PCLK_M_DEFAULT        8768
#define DS981_VP_REF_CLK_MHZ                (DS981_LINE_RATE_10P8MBPS /         \
                                             DS981_FPD4_RATE_DIVIDER)
#define DS981_VP_FPD4_PCLK_QUAD             4
#define FPD4_PCLK_TO_VP_CLK(x)              ((x) / DS981_VP_FPD4_PCLK_QUAD)
#define FPD4_FREQ_TO_VP_REF_CLK(x)          ((x) / DS981_FPD4_RATE_DIVIDER)

#define VP_STREAMS_COUNT(x)                 ((x) - 1)
#define VP_MASK_BY_ID(id)                   (1 << (id))

#define VP_SRC_SELECT_CLEAR                  ~(BIT(1) | BIT(0))

/* For passing validation for u*H*981, when u*B*981 is used */
#define DS981_SKIP_HB_BYTE                  2
#define DS981_HDCP_BYTE                     5

/* Interrupt bits */
#define DS981_IRQ_ENABLE                    BIT(7)
#define DS981_IRQ_VP                        BIT(6)
#define DS981_IRQ_DPHY                      BIT(4)
#define DS981_IRQ_FPD_PORT1                 BIT(1)
#define DS981_IRQ_FPD_PORT0                 BIT(0)

#define REV_ID_SHIFT                        4
#define CS2P0_REVISION                      BIT(REV_ID_SHIFT + 1)

static
const uint32_t PLL_VCO_FPD4_N_DIVS[] = {
        PLL_VCO_DIV_1,
        PLL_VCO_DIV_2,
        PLL_VCO_DIV_4,
        PLL_VCO_DIV_8
};

enum slave_state {
        FREE = 0,
        OCCUPIED,
};

typedef struct ds981_irq_config {
        irq_type_t type;
        uint8_t    mask;
} ds981_irq_config_st_t;

struct ds90ux9xx_i2c_slave_regs {
        const uint8_t slave_reg[DS981_I2C_SLAVE_COUNT];
        const uint8_t alias_reg[DS981_I2C_SLAVE_COUNT];
        const uint8_t route_reg[DS981_I2C_SLAVE_COUNT];
};

struct ds90ux9xx_i2c_slave_control {
        pthread_mutex_t i2c_state_lock[DS981_MAX_I2C_COUNT];
        uint8_t         state[DS981_MAX_I2C_COUNT][DS981_I2C_SLAVE_COUNT];
};

#define GPIO_DISABLE_OUTPUT             0x0
#define GPIO_OUTPUT                     BIT(7)
#define GPIO_DEV_STATUS                 BIT(6)

#define GPIO_REMOTE_IRQ                 BIT(4)
#define GPIO_RX_LOCK                    (BIT(4) | BIT(0))
#define GPIO_FPD_TX_IRQ                 (BIT(4) | BIT(1))
#define GPIO_FPD_TX_IRQ_HIGH            (GPIO_FPD_TX_IRQ | GPIO_HIGH)
#define GPIO_FPD_TX_IRQ_LOW             (GPIO_FPD_TX_IRQ | GPIO_LOW)

/* TODO: the port base is 4, but there is additional BIT(6) must be set
 *       for the BC_GPIO8-15 and other functions
 */
#define DS981_GPIO_PORT_BASE            4

#define DS981_GPIO_PORT(port)           ((port) << DS981_GPIO_PORT_BASE)
#define TO_DS981_TX_PORT(reg_val)       (!!((reg_val) &                         \
                                            BIT(DS981_GPIO_PORT_BASE)))

#define DS981_GPIO_OUTPUT               (GPIO_OUTPUT | GPIO_DEV_STATUS)
#define DS981_GPIO_OUTPUT_HIGH          (DS981_GPIO_OUTPUT | GPIO_HIGH)
#define DS981_GPIO_OUTPUT_LOW           (DS981_GPIO_OUTPUT | GPIO_LOW)

#define GPIOS_IN_REG                    8
#define GPIO_STAT(n)                    (1 << ((n) % GPIOS_IN_REG))
#define GPIO_INPUT_EN(n)                (1 << ((n) % GPIOS_IN_REG))

#define DS981_GPIO_SET_REM_IRQ(port, n) (GPIO_OUTPUT |                          \
                                         DS981_GPIO_PORT(port) |                \
                                         (n))
#define DS981_GPIO_SET_BC(port, n)      DS981_GPIO_SET_REM_IRQ(port, n)
#define DS981_GPIO_SET_FC(val, reg_val, fc_pin)                                 \
        ((~((fc_pin).mask) & (reg_val)) | ((val) << ((fc_pin).offset)))

#define DS981_GPIO_REM_IRQ(n)           (GPIO_OUTPUT |                          \
                                         GPIO_REMOTE_IRQ |                      \
                                         (n))
#define DS981_GPIO_BC                   GPIO_OUTPUT
#define DS981_GPIO_FC(reg_val, fc_pin)  (((reg_val) & (fc_pin).mask) >>         \
                                         (fc_pin).offset)

#define DS981_GPIO_COUNT                14
#define DS981_GPIO_BC_COUNT             16
#define DS981_GPIO_FC_COUNT             4

#define DS981_GPIO_BC_ANY               (DS981_GPIO_BC_COUNT - 1)
#define DS981_GPIO_FC_ANY               (DS981_GPIO_FC_COUNT - 1)

/* Select DPHY for VP bits & ops */
#define DPHY_SELECT_FIELD_SIZE          3

#define VP_TO_DPHY_SEL_REG(vp_id)       ((vp_id) >= 2)                          \
                                        ? DS981_REG_VP_DPHY_SEL0                \
                                        : DS981_REG_VP_DPHY_SEL1

#define VP_DPHY_SELECT_MASK             (BIT(2) | BIT(1) | BIT(0))
#define VP_TO_DPHY_SEL_OFFSET(vp_id)    (DPHY_SELECT_FIELD_SIZE * ((vp_id) % 2))
#define DPHY_PORT_TO_BIT(port)          ((port) << 2)

#define MAP_VP_TO_DPHY(vp_id, port, vchid)                                      \
        (((vchid) | DPHY_PORT_TO_BIT(port)) << VP_TO_DPHY_SEL_OFFSET(vp_id))

#define CLEAR_VP_DPHY_MAPPING(vp_id)                                            \
        (~(VP_DPHY_SELECT_MASK << VP_TO_DPHY_SEL_OFFSET(vp_id)))

ds90ux9xx_err_t bridge_reset(const ds90ux9xx_st_t *dev, int reset_mode);
ds90ux9xx_err_t set_tx_port(const ds90ux9xx_st_t *dev, fpd_port_t port);
ds90ux9xx_err_t init_fpd_ports(const ds90ux9xx_st_t *dev);

#endif /* __DS90UH981_H__ */

