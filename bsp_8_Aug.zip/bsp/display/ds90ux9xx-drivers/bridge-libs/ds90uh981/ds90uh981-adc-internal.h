/**
 * @file       ds90uh981-adc-internal.h
 * @brief      ds90uh981 ADC specific settings (bits, register, layouts, etc.)
 *
 * @author     Khursa Vasyl <external.vasyl.khursa@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH981_ADC_INTERNAL_H__
#define __DS90UH981_ADC_INTERNAL_H__

#define DS90UH981_ADC_ENABLE              0x0

#define DS90UH981_ADC_TIMEOUT_2MS         2000

#define ADC_CLK_DIV_SHIFT                 4
#define TO_ADC_CLK_DIV(x)                 ((x) << ADC_CLK_DIV_SHIFT)

#define DS90UH981_ADC_CLK_DIVIDER_25_HZ   TO_ADC_CLK_DIV(0)
#define DS90UH981_ADC_CLK_DIVIDER_12_5_HZ TO_ADC_CLK_DIV(1)
#define DS90UH981_ADC_CLK_DIVIDER_8_33_HZ TO_ADC_CLK_DIV(2)
#define DS90UH981_ADC_CLK_DIVIDER_6_25_HZ TO_ADC_CLK_DIV(3)

#define ADC_CLK_SAMPLE_SHIFT              6
#define TO_ADC_CLK_SAMPLE(x)              ((x) << ADC_CLK_SAMPLE_SHIFT)

#define DS90UH981_ADC_CLK_AVG_NO_SAMPLE   TO_ADC_CLK_SAMPLE(0)
#define DS90UH981_ADC_CLK_AVG_2_SAMPLES   TO_ADC_CLK_SAMPLE(1)
#define DS90UH981_ADC_CLK_AVG_4_SAMPLES   TO_ADC_CLK_SAMPLE(2)
#define DS90UH981_ADC_CLK_AVG_8_SAMPLES   TO_ADC_CLK_SAMPLE(3)

typedef enum {
        TEMPERATURE        = BIT(0),
        EXTERNAL_VOLTAGE_0 = BIT(8),
        EXTERNAL_VOLTAGE_1 = BIT(9),
        LINE_FAULT_0       = BIT(10),
        LINE_FAULT_1       = BIT(11),
        LINE_FAULT_2       = BIT(12),
        LINE_FAULT_3       = BIT(13),
} adc_type_t;

typedef struct sar_adc_settings {
        uint8_t  adc_enable;
        uint8_t  clk;
        uint16_t input_enable;
} adc_settings_st_t;

#endif /*__DS90UH981_ADC_INTERNAL_H__*/

