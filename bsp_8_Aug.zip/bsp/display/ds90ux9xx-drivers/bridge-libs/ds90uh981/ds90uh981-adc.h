/**
 * @file       ds90uh981-adc.h
 * @brief      ds90uh981 ADC settings API
 *
 * @author     Serhii Bura <external.serhii.bura@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH981_ADC_H__
#define __DS90UH981_ADC_H__

#ifdef UNITTEST
#include "UT-ds90ux9xx-bridge-libraries-mock.h"
#include "UT-ds90ux9xx-error-mock.h"
#else /* aarch64 */
#include "ds90ux9xx-bridge-libraries.h"
#include "ds90ux9xx-error.h"
#endif /* UNITTEST */

ds90ux9xx_err_t ds90uh981_adc_get_temperature(ds90ux9xx_st_t *dev,
        uint32_t *temperature);
ds90ux9xx_err_t ds90uh981_adc_get_shortage(ds90ux9xx_st_t *dev,
        uint32_t *shortage);

#endif /*__DS90UH981_ADC_H__*/

