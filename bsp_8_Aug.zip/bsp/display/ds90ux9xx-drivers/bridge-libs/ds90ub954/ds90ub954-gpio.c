/**
 * @file       ds90ub954-gpio.c
 * @brief      ds90ub954 GPIO settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include "ds90ub954-gpio.h"

#define DS954_GPIO_COUNT        7

typedef struct ds90ub954_pin {
        const char    *name;
        const uint8_t reg;
} ds954_pins_st_t;

#define IS_FUNCTION_PRESENT(mask, val, check) ((mask) == ((val) & (check)))

#define DS954_GPIO(gpio_name, reg_addr)                                         \
        {                                                                       \
                .name = gpio_name,                                              \
                .reg = reg_addr,                                                \
        }

static ds954_pins_st_t ds954_gpios[DS954_GPIO_COUNT] = {
        DS954_GPIO("gpio0", DS954_REG_GPIO0_PIN_CTL),
        DS954_GPIO("gpio1", DS954_REG_GPIO1_PIN_CTL),
        DS954_GPIO("gpio2", DS954_REG_GPIO2_PIN_CTL),
        DS954_GPIO("gpio3", DS954_REG_GPIO3_PIN_CTL),
        DS954_GPIO("gpio4", DS954_REG_GPIO4_PIN_CTL),
        DS954_GPIO("gpio5", DS954_REG_GPIO5_PIN_CTL),
        DS954_GPIO("gpio6", DS954_REG_GPIO6_PIN_CTL),
};

static
int is_wrong_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS954_GPIO_COUNT) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
inline ds90ux9xx_err_t gpio_input(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        rc = ds90ux9xx_i2c_read(dev, DS954_REG_GPIO_INPUT_CTL, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ENABLE == state) {
                val |= DS954_GPIO_INPUT_EN(num);
        } else {
                val &= ~DS954_GPIO_INPUT_EN(num);
        }

        rc = ds90ux9xx_i2c_write(dev, DS954_REG_GPIO_INPUT_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
inline ds90ux9xx_err_t gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;

        if (DISABLE == state) {
                val = DS954_GPIO_OUTPUT_DISABLE;
        } else {
                if (GPIO_LOW == value) {
                        val = DS954_GPIO_OUTPUT_LOW;
                }

                if (GPIO_HIGH == value) {
                        val = DS954_GPIO_OUTPUT_HIGH;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, ds954_gpios[num].reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_input(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        rc = gpio_output(dev, num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, num, ENABLE);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        rc = gpio_input(dev, num, DISABLE);
        rc |= gpio_output(dev, num, ENABLE, value);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_disable(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        rc = gpio_output(dev, num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, num, DISABLE);

        return rc;
}

ds90ux9xx_err_t ds90ub954_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                log_dbg("Function - input for GPIO_%d\n", gpio->num);
                rc = set_gpio_input(dev, gpio->num);
                break;
        case FUNC_GPIO_OUTPUT:
                log_dbg("Function - output for GPIO_%d\n", gpio->num);
                rc = set_gpio_output(dev, gpio->num, gpio->value);
                break;
        case FUNC_DISABLE:
                rc = set_gpio_disable(dev, gpio->num);
                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_function_t function, gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t val;

        if (NULL == value) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FUNC_GPIO_INPUT == function) {
                rc = ds90ux9xx_i2c_read(dev, DS954_REG_GPIO_PIN_STS, &val);
        } else {
                rc = ds90ux9xx_i2c_read(dev, ds954_gpios[num].reg, &val);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (FUNC_GPIO_INPUT == function) {
                *value = !!(val & DS954_GPIO_INPUT_READ(num));
        } else {
                *value = !!(val & ~DS954_GPIO_OUTPUT_MASK);
        }

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
gpio_function_t get_function(uint8_t ctrl_out, uint8_t ctrl_in)
{
        if (ctrl_in) {
                return FUNC_GPIO_INPUT;
        }

        if (true == IS_FUNCTION_PRESENT(DS954_GPIO_OUTPUT_ENABLE,
                                        ctrl_out,
                                        DS954_GPIO_OUTPUT_MASK)) {
                return FUNC_GPIO_OUTPUT;
        }

        log_err("No valid GPIO function found\n");

        return DS90UX9XX_INVALID_PARAMETER;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t ctrl_out, ctrl_in;

        if (NULL == function) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds954_gpios[num].reg, &ctrl_out);

        rc |= ds90ux9xx_i2c_read(dev, DS954_REG_GPIO_INPUT_CTL, &ctrl_in);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        *function = get_function(ctrl_out,
                                 (DS954_GPIO_INPUT_EN(num) & ctrl_in));

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        if (NULL == remote) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        *remote = NOT_SPECIFIED;

        log_dbg("No GPIO remote configuration\n");

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub954_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == gpio) {
                log_err("GPIO data is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_value(dev, gpio->num, gpio->function, &gpio->value);
        rc |= get_gpio_remote(dev, gpio->num, gpio->function, &gpio->remote);

        return rc;
}

