/**
 * @file       ds90ub954.h
 * @brief      ds90ub954 specific registers, configurations
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UB954_H__
#define __DS90UB954_H__

#include "ds90ux9xx-core.h"
#include "ds90ux9xx-i2c.h"

#define DEVICE_ID                       "_UB954"
#define DEVICE_ID_LEN                   6

/* DS90UB954 registers */

#define DS954_REG_I2C_DEV_ID            0x0
#define DS954_REG_RESET                 0x01

#define DS954_REG_DEVICE_STS            0x04

#define DS954_REG_RX_PORT_CTL           0x0C
#define DS954_REG_GPIO_PIN_STS          0x0E
#define DS954_REG_GPIO_INPUT_CTL        0x0F

#define DS954_REG_GPIO0_PIN_CTL         0x10
#define DS954_REG_GPIO1_PIN_CTL         0x11
#define DS954_REG_GPIO2_PIN_CTL         0x12
#define DS954_REG_GPIO3_PIN_CTL         0x13
#define DS954_REG_GPIO4_PIN_CTL         0x14
#define DS954_REG_GPIO5_PIN_CTL         0x15
#define DS954_REG_GPIO6_PIN_CTL         0x16

#define DS954_REG_FPD3_PORT_SEL         0x4C
#define DS954_REG_RX_PORT_STS1          0x4D

#define DS954_REG_BIST_ERR_COUNT        0x57
#define DS954_REG_BCC_CONFIG            0x58

#define DS954_REG_PORT_CONFIG           0x6D

#define DS954_REG_BIST_CTL              0xB3

#define DS954_REG_DEV_ID                0xF0

/* ds90ub954 RX Port status 1 Register bits (0x4D) */
#define DS954_FPD3_RX_LOCK_STS          BIT(0)
#define DS954_LOCK_STS_CHG              BIT(4)
#define DS954_BCC_CRC_ERROR             BIT(5)

/* DS90UH954 bits and descriptions */
#define DS954_I2C_DEV_ID_SET            BIT(0)
#define DS954_I2C_PASS_THROUGH          BIT(6)
#define DS954_I2C_PASS_THROUGH_MASK     DS954_I2C_PASS_THROUGH

#define DS954_TX_PORT_0_WRITE           BIT(0)
#define DS954_TX_PORT_1_WRITE           BIT(1)
#define DS954_TX_PORT_1_READ            BIT(4)

#define DS954_DEVICE_LOCK               BIT(2)

#define DS954_RESTART_AUTOLOAD          BIT(2)
#define DS954_RESET_CLK_WITH_REGS       BIT(1)
#define DS954_RESET_CLK_NO_REGS         BIT(0)
#define DS954_RESET_ALL                 (DS954_RESTART_AUTOLOAD |               \
                                         DS954_RESET_CLK_WITH_REGS)
#define DS954_RESET_NORMAL_OPERATION    0

#define DS954_FPD3_MODE_CSI             0
#define DS954_FPD3_MODE_RAW12_50MHZ     BIT(1)
#define DS954_FPD3_MODE_RAW12_75MHZ     BIT(2)
#define DS954_FPD3_MODE_RAW10_100MHZ    (BIT(2) | BIT(1))

#define DS954_FPD3_MODE                 (BIT(2) | BIT(1))
#define DS954_FPD3_MODE_CLEAN           (~DS954_FPD3_MODE)
#define DS954_GET_FPD3_MODE(reg_val)    ((reg_val) & DS954_FPD3_MODE)

/* GPIO bits & functions */
#define DS954_GPIO_DEV_STATUS           BIT(4)

#define DS954_GPIOS_IN_REG              8

#define DS954_GPIO_INPUT_EN(n)          (1 << ((n) % DS954_GPIOS_IN_REG))
#define DS954_GPIO_INPUT_READ(n)        (1 << ((n) % DS954_GPIOS_IN_REG))

/* Don't use output simultaineously with input. First disable input in 0x0F */
#define DS954_GPIO_OUTPUT               BIT(0)
#define DS954_GPIO_OUTPUT_DISABLE       0x0
#define DS954_GPIO_OUTPUT_ENABLE        (DS954_GPIO_DEV_STATUS |                \
                                         DS954_GPIO_OUTPUT)

#define DS954_SET_VALUE(val)            (val << 1)

#define DS954_GPIO_OUTPUT_HIGH          (DS954_GPIO_OUTPUT_ENABLE |             \
                                         DS954_SET_VALUE(GPIO_HIGH))
#define DS954_GPIO_OUTPUT_LOW           (DS954_GPIO_OUTPUT_ENABLE |             \
                                         DS954_SET_VALUE(GPIO_LOW))
#define DS954_GPIO_OUTPUT_MASK          ~BIT(1)

#define DS954_RX_LOCK_SEL_MASK          ~(BIT(3) | BIT(2))
#define DS954_RX_LOCK_PORT_0            0
#define DS954_RX_LOCK_PORT_1            BIT(2)

#define DS954_RX_PASS_SEL_MASK          ~(BIT(5) | BIT(4))
#define DS954_RX_PASS_PORT_0            0
#define DS954_RX_PASS_PORT_1            BIT(4)

#define DS954_FPD_PORTS_COUNT           2

#endif /* __DS90UB954_H__ */

