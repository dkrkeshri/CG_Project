/**
 * @file       ds90ub954.c
 * @brief      Driver for 954 bridges that performs actual work with the bridge
 *             and provides callbacks for the bridge driver
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include <ctype.h>

#include "ds90ux9xx-bridge-libraries.h"

#include "ds90ub954.h"
#include "ds90ub954-gpio.h"

static
ds90ux9xx_err_t validate_ds90ub954(const ds90ux9xx_st_t *dev)
{
        uint8_t val = 0;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        for (int i = 0; i < DEVICE_ID_LEN; i++) {
                rc = ds90ux9xx_i2c_read(dev, DS954_REG_DEV_ID + i, &val);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't read 0x%x device ID register\n",
                                DS954_REG_DEV_ID + i);

                        return rc;
                }

                log_dbg("Read : 0x%x = 0x%x \n", DS954_REG_DEV_ID + i, val);

                if (val != DEVICE_ID[i]) {
                        return DS90UX9XX_WRONG_CHIP;
                }
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t map_dev_id(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to unmap\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_map);

        rc = ds90ux9xx_i2c_write(dev, DS954_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS954_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS954_I2C_DEV_ID_SET,
                        DS954_REG_I2C_DEV_ID);

                return rc;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_map,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t ds90ub954_map_fpd_i2c_slave(ds90ux9xx_st_t *dev,
        ds90ux9xx_slave_st_t *slave)
{
        /* TODO: complete stub */
        return DS90UX9XX_SUCCESS;
}

/*
 * TBD: Now it is just static function, that will be called on online and will
 * reset bridge completely.
 * But 0x01 reg of 954 has some reset bits such as:
 * [7:3] reserved
 * [2] Restart Auto-load
 * [1] Digital Reset the entire digital block including registers
 * [0] Resets the entire digital block except registers.
 * So if needed we can make it avaliable outside as API, and reset not all
 * bridge, but in any way listed above
 */
static
ds90ux9xx_err_t bridge_reset(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        log_dbg("Attempt to reset bridge with 0x%x value on 0x%x i2c address\n",
                reset_mode, dev->i2c_dev->i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS954_REG_RESET, reset_mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS954_REG_RESET, reset_mode);
        }

        return rc;
}

static
ds90ux9xx_err_t init_bridge_limits(ds_bridge_limits_st_t *limits)
{
        if (NULL == limits) {
                log_err("Invalid input: limits = %p\n", limits);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        limits->fpd_ports_count = DS954_FPD_PORTS_COUNT;

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub954_init_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = map_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map i2c dev id failed\n");
        }

        return rc;
}

static
ds90ux9xx_err_t unmap_dev_id(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to unmap\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_addr);

        log_dbg("new_i2c_addr: 0x%x\n", new_i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS954_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS954_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS954_I2C_DEV_ID_SET,
                        DS954_REG_I2C_DEV_ID);

                return rc;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_addr,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_deinit_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = unmap_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Unmap i2c dev id failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_reset_device(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int mode = DS954_RESET_NORMAL_OPERATION;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (INITIAL_RESET == reset_mode) {
                mode = DS954_RESET_ALL;
        }

        rc = bridge_reset(dev, mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge reset failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_validate_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = validate_ds90ub954(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge validation failed\n");
        }

        return rc;
}

static
ds90ux9xx_err_t pass_through_enable(ds90ux9xx_st_t *dev)
{
        return ds90ux9xx_i2c_update(dev, DS954_REG_BCC_CONFIG,
                                    DS954_I2C_PASS_THROUGH_MASK,
                                    DS954_I2C_PASS_THROUGH);
}

static
ds90ux9xx_err_t pass_through_disable(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS954_REG_BCC_CONFIG;
        uint8_t val = 0;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS954_I2C_PASS_THROUGH;
        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

ds90ux9xx_err_t ds90ub954_set_pass_through(ds90ux9xx_st_t *dev, state_t state)
{
        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DISABLE == state) {
                return pass_through_disable(dev);
        } else {
                return pass_through_enable(dev);
        }
}

ds90ux9xx_err_t ds90uh954_get_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t *port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_val = 0;

        if (NULL == dev || NULL == port) {
                log_err("Invalid input: dev = %p, port = %p\n", dev, port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS954_REG_FPD3_PORT_SEL, &reg_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read DS954_REG_FPD3_PORT_SEL reg. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (reg_val & DS954_TX_PORT_1_READ) {
                *port = PORT_1;
        } else {
                *port = PORT_0;
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_set_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (port) {
        case PORT_0:
                rc = ds90ux9xx_i2c_write(dev, DS954_REG_FPD3_PORT_SEL,
                                         DS954_TX_PORT_0_WRITE);

                break;
        case PORT_1:
                rc = ds90ux9xx_i2c_write(dev, DS954_REG_FPD3_PORT_SEL,
                                         DS954_TX_PORT_1_WRITE |
                                         DS954_TX_PORT_1_READ);

                break;
        default:
                log_err("Invalid input: port = %d\n", port);
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
ds90ux9xx_err_t set_link_status_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS954_REG_RX_PORT_CTL, &val);

        /* Reset selection. This automatically set port 0 */
        val &= (DS954_RX_LOCK_SEL_MASK & DS954_RX_PASS_SEL_MASK);

        if (PORT_1 == port) {
                val |= DS954_RX_LOCK_PORT_1 | DS954_RX_PASS_PORT_1;
        }

        rc |= ds90ux9xx_i2c_write(dev, DS954_REG_RX_PORT_CTL, val);

        return rc;
}

ds90ux9xx_err_t ds90ub954_get_fpd_link(ds90ux9xx_st_t *dev,
        ds_fpd_link_st_t *fpd_link)
{
        ds90ux9xx_err_t rc;
        uint8_t status0 = 0;
        uint8_t status1 = 0;

        if (NULL == dev || NULL == fpd_link) {
                log_err("Invalid input: dev = %p, fpd_link = %p\n", dev,
                        fpd_link);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_link_status_port(dev, fpd_link->port);
        rc |= ds90ux9xx_i2c_read(dev, DS954_REG_DEVICE_STS, &status0);
        rc |= ds90ux9xx_i2c_read(dev, DS954_REG_RX_PORT_STS1, &status1);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read link status. %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        /* DS954_REG_DEVICE_STS */
        if (true == !!(status0 & DS954_DEVICE_LOCK)) {
                fpd_link->detect = DS_DETECTED;
        } else {
                fpd_link->detect = DS_NOT_DETECTED;
        }

        /* DS954_REG_RX_PORT_STS1 */
        if (true == !!(status1 & DS954_FPD3_RX_LOCK_STS)) {
                fpd_link->rx_lock = DS_LOCKED;
        } else {
                fpd_link->rx_lock = DS_NOT_LOCKED;
        }

        if (true == !!(status1 & DS954_LOCK_STS_CHG)) {
                fpd_link->status_change = DS_DETECTED;
        } else {
                fpd_link->status_change = DS_NOT_DETECTED;
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_get_fpd_mode(const ds90ux9xx_st_t *dev,
        char *fpd_mode)
{
        ds90ux9xx_err_t rc;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == fpd_mode) {
                log_err("fpd_mode pointer is invalid\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS954_REG_PORT_CONFIG, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't access PORT CONFIG register\n");

                return rc;
        }

        val = DS954_GET_FPD3_MODE(val);

        switch(val) {
        case DS954_FPD3_MODE_CSI:
                strcpy(fpd_mode, CSI_MODE);
                break;
        case DS954_FPD3_MODE_RAW12_50MHZ:
                strcpy(fpd_mode, RAW_12_50MHZ);
                break;
        case DS954_FPD3_MODE_RAW12_75MHZ:
                strcpy(fpd_mode, RAW_12_75MHZ);
                break;
        case DS954_FPD3_MODE_RAW10_100MHZ:
                strcpy(fpd_mode, RAW_10_100MHZ);
                break;
        }

        log_dbg("FPD mode: %s\n", fpd_mode);

        return rc;
}

ds90ux9xx_err_t ds90ub954_set_fpd_mode(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_fpd_st_t *fpd, fpd_port_t port_id)
{
        ds90ux9xx_err_t rc;
        uint8_t reg = DS954_REG_PORT_CONFIG;
        uint8_t val = 0;

        /* TODO: Add port id usage */
        (void)port_id;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == fpd || NULL == fpd->fpd_tx_mode) {
                log_err("fpd or fpd_mode is NOT set\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't access PORT CONFIG register\n");

                return rc;
        }

        val &= DS954_FPD3_MODE_CLEAN;

        if (EQUAL == strcmp(fpd->fpd_tx_mode, CSI_MODE)) {
                val |= DS954_FPD3_MODE_CSI;
        } else if (EQUAL == strcmp(fpd->fpd_tx_mode, RAW_12_50MHZ)) {
                val |= DS954_FPD3_MODE_RAW12_50MHZ;
        } else if (EQUAL == strcmp(fpd->fpd_tx_mode, RAW_12_75MHZ)) {
                val |= DS954_FPD3_MODE_RAW12_75MHZ;
        } else if (EQUAL == strcmp(fpd->fpd_tx_mode, RAW_10_100MHZ)) {
                val |= DS954_FPD3_MODE_RAW10_100MHZ;
        } else {
                log_err("Unsupported FPD mode '%s'\n", fpd->fpd_tx_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

/*
 * TBD:
 * Following settings might be configured in future
 * [0]   - BIST_EN
 * [2:1] - BIST_CLOCK_SOURCE
 * [3]   - BIST_PIN_CONFIG
 * [7:6] - BIST_OUT_MODE
 */
ds90ux9xx_err_t ds90ub954_set_bist_state(const ds90ux9xx_st_t *dev,
        state_t bist_state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t bist_control = bist_state;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("Input: bist state: 0x%x\n", bist_control);

        rc = ds90ux9xx_i2c_write(dev, DS954_REG_BIST_CTL, bist_control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS954_REG_BIST_CTL, bist_control);
        }

        return rc;
}

ds90ux9xx_err_t ds90ub954_get_bist_result(ds90ux9xx_st_t *dev,
        bist_result_st_t *bist_result)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == bist_result) {
                log_err("bist result ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS954_REG_BIST_ERR_COUNT,
                                &bist_result->bist_err_count);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't read 0x%x\n", DS954_REG_BIST_ERR_COUNT);

                return rc;
        }

        bist_result->bist_err_count_is_avaliable = 1;

        return rc;
}

ds90ux9xx_err_t ds90ub954_read_reg(const ds90ux9xx_st_t *dev,
        ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == reg_data) {
                log_err("Invalid dev or reg_data ptr\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s request read: type %d; reg 0x%x\n", dev->name,
                reg_data->type, reg_data->reg);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                if (reg_data->reg > MAX_MAIN_PAGE_REGISTER) {
                        log_err("Requested reg is out of range\n");

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                rc = ds90ux9xx_i2c_read(dev, reg_data->reg,
                                        (uint8_t *)&reg_data->value);
                break;
        default:
                log_dbg("Unsupported type\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Read: type %d; reg 0x%x = 0x%x\n", dev->name,
                reg_data->type, reg_data->reg, reg_data->value);

        return rc;
}

static
ds90ux9xx_err_t ds90ub954_write_reg(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Write: type %d; reg 0x%x, value 0x%x\n", dev->name,
                reg_data->type, reg_data->reg, reg_data->value);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                rc = ds90ux9xx_i2c_write(dev, reg_data->reg, reg_data->value);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh954_get_bridge_revision(ds90ux9xx_st_t *dev,
        ds90ux9xx_revision_t *bridge_revision)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        /**
         * TODO: Implement
         */

        return rc;
}

ds90ux9xx_err_t library_deinit(ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        ds90ux9xx_logger_deinit();

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t library_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->ops.lib_deinit = (operation_fp_t)library_deinit;

        rc = ds90ux9xx_logger_init(dev->bridge_type);
        if (DS90UX9XX_SUCCESS != rc) {
                return DS90UX9XX_INIT_FAILURE;
        }

        rc = init_bridge_limits(&dev->bridge_limits);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to init bridge limits. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                return DS90UX9XX_INIT_FAILURE;
        }

        rc = init_generic_operations(&dev->ops);
        if (DS90UX9XX_SUCCESS != rc || false == dev->ops.is_initialized) {
                log_err("Can't init bridge operations. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        dev->ops.device[DEINIT_DEVICE] =
                (operation_fp_t)ds90ub954_deinit_device;
        dev->ops.device[GET_BRIDGE_REVISION] =
                (operation_fp_t)ds90uh954_get_bridge_revision;
        dev->ops.device[INIT_DEVICE] =
                (operation_fp_t)ds90ub954_init_device;
        dev->ops.device[RESET_DEVICE] =
                (operation_fp_t)ds90ub954_reset_device;
        dev->ops.device[VALIDATE_DEVICE] =
                (operation_fp_t)ds90ub954_validate_device;

        dev->ops.bist[GET_BIST_RESULT] =
                (operation_fp_t)ds90ub954_get_bist_result;
        dev->ops.bist[SET_BIST_STATE] =
                (operation_fp_t)ds90ub954_set_bist_state;

        dev->ops.fpd[GET_FPD_MODE] =
                (operation_fp_t)ds90ub954_get_fpd_mode;
        dev->ops.fpd[GET_FPD_LINK] =
                (operation_fp_t)ds90ub954_get_fpd_link;
        dev->ops.fpd[GET_TX_PORT] =
                (operation_fp_t)ds90uh954_get_tx_port;
        dev->ops.fpd[SET_FPD_MODE] =
                (operation_fp_t)ds90ub954_set_fpd_mode;
        dev->ops.fpd[SET_TX_PORT] =
                (operation_fp_t)ds90ub954_set_tx_port;

        dev->ops.gpio[SET_GPIO] =
                (operation_fp_t)ds90ub954_set_gpio;
        dev->ops.gpio[GET_GPIO] =
                (operation_fp_t)ds90ub954_get_gpio;

        dev->ops.i2c[READ_REGISTER] =
                (operation_fp_t)ds90ub954_read_reg;
        dev->ops.i2c[MAP_I2C_SLAVE] =
                (operation_fp_t)ds90ub954_map_fpd_i2c_slave;
        dev->ops.i2c[SET_PASS_THROUGH] =
                (operation_fp_t)ds90ub954_set_pass_through;
        dev->ops.i2c[WRITE_REGISTER] =
                (operation_fp_t)ds90ub954_write_reg;

        log_dbg("Initialized successfully\n");

        return rc;

init_failed:
        ds90ux9xx_logger_deinit();

        return rc;
}

