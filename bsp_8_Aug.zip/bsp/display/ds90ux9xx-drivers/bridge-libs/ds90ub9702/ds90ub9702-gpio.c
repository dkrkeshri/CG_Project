/**
 * @file       ds90ub9702-gpio.c
 * @brief      ds90ub9702 GPIO settings routines
 *
 * @author     Daniil Petrov <external.Daniil.Petrov@de.bosch.com>
 * @author     Oleg Kofman <external.oleg.kofman@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90ub9702-gpio-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90ub9702-gpio.h"
#endif /* UNITTEST */

#define DS9702_GPIO_0                   0
#define DS9702_GPIO_8                   8
#define DS9702_GPIO_9                   9
#define DS9702_GPIO_10                  10
#define DS9702_GPIO_COUNT               sizeof(ds9702_gpios)

#define DS9702_REG_UNDEFINED            0xFF

#define IS_FUNCTION_PRESENT(val, mask)  ((mask) == ((val) & (mask)))

#define GPIO_GET_VALUE_INPUT(val, num)                                          \
        ((val & DS9702_GPIO_INPUT_READ(num)) ? GPIO_HIGH : GPIO_LOW)

#define GPIO_GET_VALUE_OUTPUT(val)                                              \
        ((val & DS9702_GPIO_OUTPUT_MASK) ? GPIO_HIGH : GPIO_LOW)

#define DS9702_GPIO(gpio_name, reg_addr, input_ctl)                             \
        {                                                                       \
                .name = gpio_name,                                              \
                .reg = reg_addr,                                                \
                .input_ctl_reg = input_ctl,                                     \
        }

typedef struct ds90ub9702_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t input_ctl_reg;
} ds9702_pins_st_t;

static ds9702_pins_st_t ds9702_gpios[] = {
        DS9702_GPIO("gpio0",  DS9702_REG_GPIO_0,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio1",  DS9702_REG_GPIO_1,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio2",  DS9702_REG_GPIO_2,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio3",  DS9702_REG_GPIO_3,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio4",  DS9702_REG_GPIO_4,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio5",  DS9702_REG_GPIO_5,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio6",  DS9702_REG_GPIO_6,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio7",  DS9702_REG_GPIO_7,    DS9702_REG_GPIO_INPUT_CTL),
        DS9702_GPIO("gpio8",  DS9702_REG_UNDEFINED, DS9702_REG_UNDEFINED),
        DS9702_GPIO("gpio9",  DS9702_REG_GPIO_9,    DS9702_REG_GPIO_INPUT_CTL2),
        DS9702_GPIO("gpio10", DS9702_REG_GPIO_10,   DS9702_REG_GPIO_INPUT_CTL2)
};

static
ds90ux9xx_err_t check_gpio_num(int num)
{
        if (num < DS9702_GPIO_0 ||
            num >= DS9702_GPIO_COUNT ||
            num == DS9702_GPIO_8) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
bool input_not_supported(int num)
{
        if (num == DS9702_GPIO_9 || num == DS9702_GPIO_10) {
                return true;
        }

        return false;
}

static
ds90ux9xx_err_t gpio_input(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds9702_gpios[num].input_ctl_reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (ENABLE == state) {
                val |= DS9702_GPIO_INPUT_EN(num);
        } else {
                val &= ~DS9702_GPIO_INPUT_EN(num);
        }

        rc = ds90ux9xx_i2c_write(dev, ds9702_gpios[num].input_ctl_reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't process GPIO register: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, state_t state, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DISABLE == state) {
                val = DS9702_GPIO_OUTPUT_DISABLE;
        } else {
                if (GPIO_LOW == value) {
                        val = DS9702_GPIO_OUTPUT_LOW;
                } else {
                        val = DS9702_GPIO_OUTPUT_HIGH;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, ds9702_gpios[num].reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write GPIO register: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return rc;
}

static
ds90ux9xx_err_t set_gpio_input(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_output(dev, num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, num, ENABLE);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_output(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_input(dev, num, DISABLE);
        rc |= gpio_output(dev, num, ENABLE, value);

        return rc;
}

static
ds90ux9xx_err_t set_gpio_disable(const ds90ux9xx_st_t *dev, uint8_t num)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = gpio_output(dev, num, DISABLE, GPIO_LOW);
        rc |= gpio_input(dev, num, DISABLE);

        return rc;
}

ds90ux9xx_err_t ds90ub9702_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = check_gpio_num(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Invalid input: gpio number = %d\n", gpio->num);

                return rc;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                log_dbg("Function - input for GPIO_%d\n", gpio->num);
                rc = set_gpio_input(dev, gpio->num);

                break;
        case FUNC_GPIO_OUTPUT:
                log_dbg("Function - output for GPIO_%d\n", gpio->num);
                rc = set_gpio_output(dev, gpio->num, gpio->value);

                break;
        case FUNC_DISABLE:
                log_dbg("Function - disable for GPIO_%d\n", gpio->num);
                rc = set_gpio_disable(dev, gpio->num);

                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_function_t function, gpio_value_t *value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: device = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == input_not_supported(num) &&
            FUNC_GPIO_INPUT == function) {
                log_err("Reading from the pin = %d is not supported\n", num);

                return DS90UX9XX_NOT_SUPPORTED;
        }

        if (FUNC_GPIO_INPUT == function) {
                rc = ds90ux9xx_i2c_read(dev, DS9702_REG_GPIO_PIN_STS, &val);
        } else {
                rc = ds90ux9xx_i2c_read(dev, ds9702_gpios[num].reg, &val);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (FUNC_GPIO_INPUT == function) {
                *value = GPIO_GET_VALUE_INPUT(val, num);
        } else {
                *value = GPIO_GET_VALUE_OUTPUT(val);
        }

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t ctrl_out = 0;
        uint8_t ctrl_in = 0;

        if (NULL == dev || NULL == function) {
                log_err("Invalid input: device = %p, function = %p\n",
                        dev, function);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, ds9702_gpios[num].input_ctl_reg, &ctrl_in);
        rc |= ds90ux9xx_i2c_read(dev, ds9702_gpios[num].reg, &ctrl_out);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *function = FUNC_DISABLE;

        if (IS_FUNCTION_PRESENT(ctrl_out, DS9702_GPIO_OUTPUT_ENABLE)) {
                *function = FUNC_GPIO_OUTPUT;
        }

        if (ctrl_in & DS9702_GPIO_INPUT_EN(num)) {
                *function = FUNC_GPIO_INPUT;
        }

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

ds90ux9xx_err_t ds90ub9702_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == gpio) {
                log_err("Invalid input: dev = %p, gpio = %p\n", dev, gpio);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = check_gpio_num(gpio->num);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Invalid input: gpio number = %d\n", gpio->num);

                return rc;
        }

        rc = get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_value(dev, gpio->num, gpio->function, &gpio->value);

        return rc;
}

