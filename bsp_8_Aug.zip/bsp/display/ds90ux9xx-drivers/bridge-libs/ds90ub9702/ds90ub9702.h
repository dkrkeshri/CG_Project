/**
 * @file       ds90ub9702.h
 * @brief      ds90ub9702 specific registers, configurations
 *
 * @author     Daniil Petrov <external.Daniil.Petrov@de.bosch.com>
 * @author     Serhii Bura  <external.Serhii.Bura@de.bosch.com>
 * @author     Oleg Kofman <external.oleg.kofman@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UB9702_H__
#define __DS90UB9702_H__

#include "ds90ux9xx-core.h"

#ifdef UNITTEST
#include "UT-ds90ux9xx-i2c-mock.h"
#else /* aarch64 */
#include "ds90ux9xx-i2c.h"
#endif /* UNITTEST */

/* DS90UB9702 registers */
#define DS9702_REG_I2C_DEV_ID            0x0

#define DEVICE_ID                        "_UB9702"
#define DEVICE_ID_LEN                    (sizeof(DEVICE_ID) - 1)

/* DS90UB9702 registers */
#define DS9702_REG_I2C_DEV_ID            0x0
#define DS9702_REG_RESET                 0x01

/* DS90UB9702 GPIO registers */
#define DS9702_REG_GPIO_PIN_STS          0x0E
#define DS9702_REG_GPIO_INPUT_CTL        0x0F

#define DS9702_REG_GPIO_0                0x10
#define DS9702_REG_GPIO_1                0x11
#define DS9702_REG_GPIO_2                0x12
#define DS9702_REG_GPIO_3                0x13
#define DS9702_REG_GPIO_4                0x14
#define DS9702_REG_GPIO_5                0x15
#define DS9702_REG_GPIO_6                0x16
#define DS9702_REG_GPIO_7                0x17

#define DS9702_REG_FPD3_PORT_SEL         0x4C
#define DS9702_REG_RX_PORT_STS1          0x4D

#define DS9702_REG_BIST_ERR_COUNT        0x57
#define DS9702_REG_BCC_CONFIG            0x58

/* DS90UB9702 GPIO (ext set) registers */
#define DS9702_REG_GPIO_9                0x89
#define DS9702_REG_GPIO_10               0x8A
#define DS9702_REG_GPIO_INPUT_CTL2       0x8B

#define DS9702_REG_IND_ACC_CTL           0xB0
#define DS9702_REG_IND_ACC_ADDR          0xB1
#define DS9702_REG_IND_ACC_DATA          0xB2

#define DS9702_REG_BIST_CTL              0xB3

#define DS9702_REG_CHANNEL_MODE          0xE4

#define DS9702_REG_DEV_ID                0xF0

/* DS90UH9702 bits and descriptions */
#define DS9702_I2C_DEV_ID_SET            BIT(0)

#define DS9702_RESTART_AUTOLOAD          BIT(2)
#define DS9702_RESET_WITH_REGS           BIT(1)
#define DS9702_RESET_NO_REGS             BIT(0)
#define DS9702_RESET_ALL                 (DS9702_RESTART_AUTOLOAD |             \
                                          DS9702_RESET_WITH_REGS)
#define DS9702_RESET_NORMAL_OPERATION    0

#define DS9702_RX_PORT_0_READ            0
#define DS9702_RX_PORT_0_WRITE           BIT(0)
#define DS9702_RX_PORT_1_WRITE           BIT(1)
#define DS9702_RX_PORT_1_READ            BIT(4)
#define DS9702_RX_PORT_2_WRITE           BIT(2)
#define DS9702_RX_PORT_2_READ            BIT(5)
#define DS9702_RX_PORT_3_WRITE           BIT(3)
#define DS9702_RX_PORT_3_READ            (BIT(5) | BIT(4))

/* ds90ub9702 RX port status Register 0 bits (0x4D) */
#define DS9702_LOCK_STS                  BIT(0)
#define DS9702_LOCK_STS_CHG              BIT(4)
#define DS9702_BC_CRC_ERORR              BIT(5)

#define DS9702_FPD_MODE                  (BIT(2) | BIT(1) | BIT(0))
#define DS9702_FPD_MODE_CLEAN            (~DS9702_FPD_MODE)
#define DS9702_GET_FPD_MODE(reg_val)     ((reg_val) & DS9702_FPD_MODE)

#define DS9702_FPD4_MODE_SYNC            0
#define DS9702_FPD4_MODE_ASYNC           BIT(0)
#define DS9702_FPD3_MODE_CSI             BIT(1)
#define DS9702_FPD3_MODE_RAW_12_HF       BIT(2)
#define DS9702_FPD3_MODE_RAW_10          (BIT(2) | BIT(0))
#define DS9702_FPD3_MODE_RAW_12_LF       (BIT(2) | BIT(1))

#define DS9702_IND_READ                  BIT(0)
#define DS9702_IND_AUTO_INC              BIT(1)
#define IND_PAGE_SHIFT                   2
#define TO_IND_PAGE(page)                ((page) << IND_PAGE_SHIFT)
#define DS9702_IND_PAGE_0                TO_IND_PAGE(0)
#define DS9702_IND_PAGE_1                TO_IND_PAGE(1)
#define DS9702_IND_PAGE_2                TO_IND_PAGE(2)
#define DS9702_IND_PAGE_4                TO_IND_PAGE(4)
#define DS9702_IND_PAGE_5                TO_IND_PAGE(5)
#define DS9702_IND_PAGE_8                TO_IND_PAGE(8)
#define DS9702_IND_PAGE_9                TO_IND_PAGE(9)
#define DS9702_IND_PAGE_10               TO_IND_PAGE(10)
#define DS9702_IND_PAGE_MAX              DS9702_IND_PAGE_10

#define DS9702_I2C_PASS_THROUGH          BIT(6)
#define DS9702_I2C_PASS_THROUGH_MASK     DS9702_I2C_PASS_THROUGH

#define DS9702_BIST_ENABLE               BIT(0)
#define DS9702_BIST_PIN_CONFIG           BIT(3)

/* GPIO bits & functions */
#define DS9702_GPIO_DEV_STATUS           BIT(4)
#define DS9702_GPIO_OUTPUT               BIT(0)

#define DS9702_GPIO_MOD                  9

#define DS9702_GPIO_INPUT_EN(n)          BIT((n) % DS9702_GPIO_MOD)
#define DS9702_GPIO_INPUT_READ(n)        BIT((n) % DS9702_GPIO_MOD)

#define DS9702_GPIO_OUTPUT_DISABLE       0x0
#define DS9702_GPIO_OUTPUT_ENABLE        (DS9702_GPIO_DEV_STATUS |              \
                                          DS9702_GPIO_OUTPUT)
#define DS9702_GPIO_OUTPUT_MASK          BIT(1)
#define DS9702_GPIO_OUTPUT_HIGH          (DS9702_GPIO_OUTPUT_ENABLE |           \
                                          DS9702_GPIO_OUTPUT_MASK)
#define DS9702_GPIO_OUTPUT_LOW           DS9702_GPIO_OUTPUT_ENABLE

#define DS9702_FPD_PORTS_COUNT           4

#endif /* __DS90UB9702_H__ */

