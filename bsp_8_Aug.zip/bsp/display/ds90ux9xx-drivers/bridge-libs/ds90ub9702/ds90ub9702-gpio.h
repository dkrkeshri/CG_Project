/**
 * @file       ds90ub9702-gpio.h
 * @brief      ds90ub9702 GPIO settings API
 *
 * @author     Daniil Petrov <external.Daniil.Petrov@de.bosch.com>
 * @author     Oleg Kofman <external.oleg.kofman@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UB9702_GPIO_H__
#define __DS90UB9702_GPIO_H__

#ifdef UNITTEST
#include "UT-ds90ub9702-mock.h"
#else /* aarch64 */
#include "ds90ub9702.h"
#endif /* UNITTEST */

ds90ux9xx_err_t ds90ub9702_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);
ds90ux9xx_err_t ds90ub9702_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);

#endif /* __DS90UB9702_GPIO_H__ */

