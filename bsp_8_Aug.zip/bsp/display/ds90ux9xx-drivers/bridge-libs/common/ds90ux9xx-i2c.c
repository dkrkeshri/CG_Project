/**
 * @file       ds90ux9xx-i2c.c
 * @brief      Bridge i2c client usage common for all bridge libraries
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90ux9xx-i2c-mock.h"
#include "UT-pthread-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90ux9xx-i2c.h"
#endif /* UNITTEST */

#define UINT8_ARRAY_TO_UNIT32(array)    ((array)[3] << 24 |                     \
                                         (array)[2] << 16 |                     \
                                         (array)[1] << 8 |                      \
                                         (array)[0] << 0)

static inline
ds90ux9xx_err_t ind_lock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_lock((pthread_mutex_t *)&dev->i2c_ind_ctl.mutex);
        if (EOK != err) {
                log_err("Can't obtain the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t ind_unlock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_unlock((pthread_mutex_t *)&dev->i2c_ind_ctl.mutex);
        if (EOK != err) {
                log_err("Can't release the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t apb_lock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_lock((pthread_mutex_t *)&dev->i2c_apb_ctl.mutex);
        if (EOK != err) {
                log_err("Can't obtain the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t apb_unlock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_unlock((pthread_mutex_t *)&dev->i2c_apb_ctl.mutex);
        if (EOK != err) {
                log_err("Can't release the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t aux_lock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_lock((pthread_mutex_t *)&dev->i2c_aux_ctl.mutex);
        if (EOK != err) {
                log_err("Can't obtain the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t aux_unlock(const ds90ux9xx_st_t *dev)
{
        int err;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_unlock((pthread_mutex_t *)&dev->i2c_aux_ctl.mutex);
        if (EOK != err) {
                log_err("Can't release the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ux9xx_i2c_write(const ds90ux9xx_st_t *dev, uint8_t reg,
        uint8_t data)
{
        uint8_t buf[] = {reg, data};
        uint8_t size = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        size = i2c_write(dev->i2c_dev->i2c_fd, buf, ARRAY_SIZE(buf));
        if (ARRAY_SIZE(buf) != size) {
                log_err("I2C write failed: processed %d bytes\n", size);

                return DS90UX9XX_I2C_RW_ERROR;
        }

        ds_usleep(MS_TO_US(dev->i2c_dev->i2c_sleep_ms));

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ux9xx_i2c_read(const ds90ux9xx_st_t *dev, uint8_t reg,
        uint8_t *data)
{
        uint8_t wb = reg;
        uint8_t size = 0;

        if (NULL == dev || NULL == data) {
                log_err("Invalid input: dev = %p, data = %p\n", dev, data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        size = i2c_combined_writeread(dev->i2c_dev->i2c_fd, &wb,
                                      sizeof(uint8_t), data, sizeof(uint8_t));
        if (sizeof(uint8_t) != size) {
                log_err("I2C read failed: read %d bytes\n", size);

                return DS90UX9XX_I2C_RW_ERROR;
        }

        ds_usleep(MS_TO_US(dev->i2c_dev->i2c_sleep_ms));

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ux9xx_i2c_update(const ds90ux9xx_st_t *dev,
        uint8_t reg, uint8_t mask, uint8_t data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t old_val = 0;
        uint8_t new_val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read(dev, reg, &old_val);
        new_val = (old_val & ~mask) | (data & mask);
        rc |= ds90ux9xx_i2c_write(dev, reg, new_val);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_init_indirect_api(ds90ux9xx_st_t *dev,
        indirect_i2c_st_t *ind_ctl)
{
        if (NULL == dev || NULL == ind_ctl) {
                log_err("Invalid input: dev = %p, ind_ctl = %p\n", dev,
                        ind_ctl);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == ind_ctl->validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        ind_ctl->validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->i2c_ind_ctl = *ind_ctl;

        if (EOK != pthread_mutex_init(&dev->i2c_ind_ctl.mutex, NULL)) {
                log_err("Can't init mutex\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_1b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_ind_ctl.validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        dev->i2c_ind_ctl.validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = dev->i2c_ind_ctl.validate_page(page);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Incorrect page requested\n");

                return rc;
        }

        rc = ind_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock indirect pages: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.ctrl_reg, page);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  FIRST_BYTE(data));

        ind_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_2b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_ind_ctl.validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        dev->i2c_ind_ctl.validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = dev->i2c_ind_ctl.validate_page(page);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Incorrect page requested\n");

                return rc;
        }

        rc = ind_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock indirect pages: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.ctrl_reg,
                                  page | dev->i2c_ind_ctl.auto_inc);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  FIRST_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  SECOND_BYTE(data));

        ind_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_3b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_ind_ctl.validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        dev->i2c_ind_ctl.validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = dev->i2c_ind_ctl.validate_page(page);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Incorrect page requested\n");

                return rc;
        }

        rc = ind_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock indirect pages: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.ctrl_reg,
                                  page | dev->i2c_ind_ctl.auto_inc);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  FIRST_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  SECOND_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.data_reg,
                                  THIRD_BYTE(data));

        ind_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_i2c_read_ind_1b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint8_t *data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == data) {
                log_err("Invalid input: dev = %p, data = %p\n", dev, data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_ind_ctl.validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        dev->i2c_ind_ctl.validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = dev->i2c_ind_ctl.validate_page(page);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Incorrect page requested\n");

                return rc;
        }

        rc = ind_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock indirect pages: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.ctrl_reg,
                                  page | dev->i2c_ind_ctl.read_enable);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_ind_ctl.data_reg, data);

        ind_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_i2c_read_ind_2b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint16_t *data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t read_data = 0;

        if (NULL == dev || NULL == data) {
                log_err("Invalid input: dev = %p, data = %p\n", dev, data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_ind_ctl.validate_page) {
                log_err("Invalid input: validate_page = %p\n",
                        dev->i2c_ind_ctl.validate_page);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = dev->i2c_ind_ctl.validate_page(page);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Incorrect page requested\n");

                return rc;
        }

        rc = ind_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock indirect pages: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.ctrl_reg,
                                  page | dev->i2c_ind_ctl.read_enable |
                                  dev->i2c_ind_ctl.auto_inc);

        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_ind_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_ind_ctl.data_reg, &read_data);

        *data = read_data;

        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_ind_ctl.data_reg, &read_data);

        *data |= TO_SECOND_BYTE(read_data);

        ind_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_init_apb(ds90ux9xx_st_t *dev,
        apb_i2c_st_t *apb_control)
{
        if (NULL == dev || NULL == apb_control) {
                log_err("Invalid inputs: dev = %p, apb = %p\n", dev,
                        apb_control);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->i2c_apb_ctl = *apb_control;

        if (EOK != pthread_mutex_init(&dev->i2c_apb_ctl.mutex, NULL)) {
                log_err("Can't init mutex\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds_init_aux(ds90ux9xx_st_t *dev, aux_i2c_st_t *aux_control)
{
        if (NULL == dev || NULL == aux_control) {
                log_err("Invalid inputs: dev = %p, aux_control = %p\n", dev,
                        aux_control);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->i2c_aux_ctl = *aux_control;

        if (EOK != pthread_mutex_init(&dev->i2c_aux_ctl.mutex, NULL)) {
                log_err("Can't init mutex\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ux9xx_i2c_apb_read(const ds90ux9xx_st_t *dev, uint16_t reg,
        uint32_t *data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t read_value[sizeof(uint32_t)];

        if (NULL == dev || NULL == data) {
                log_err("Invalid input: dev = %p, data = %p\n", dev, data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = apb_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock APB pages: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        /* Write to the APB_ADR0 and APB_ADR1 registers to set
         * the register offset */
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.addr0_reg,
                                  FIRST_BYTE(reg));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.addr1_reg,
                                  SECOND_BYTE(reg));

        /* Write to the APB_CTL register to select the desired register block,
         * enable the APB interface, and start APB read */
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.ctrl_reg,
                                  dev->i2c_apb_ctl.read_enable |
                                  dev->i2c_apb_ctl.apb_port);

        /* Read the data value from the APB_DATA0, APB_DATA1, APB_DATA2,
         * and APB_DATA3 registers */
        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_apb_ctl.data0_reg,
                                 &read_value[0]);
        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_apb_ctl.data1_reg,
                                 &read_value[1]);
        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_apb_ctl.data2_reg,
                                 &read_value[2]);
        rc |= ds90ux9xx_i2c_read(dev, dev->i2c_apb_ctl.data3_reg,
                                 &read_value[3]);

        apb_unlock(dev);

        *data = UINT8_ARRAY_TO_UNIT32(read_value);

        return rc;
}

ds90ux9xx_err_t ds90ux9xx_i2c_apb_write(const ds90ux9xx_st_t *dev, uint16_t reg,
        uint32_t data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = apb_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock APB pages: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        /* Write to the APB_CTL register to select the desired register block
         * and enable the APB interface */
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.ctrl_reg,
                                  dev->i2c_apb_ctl.write_enable |
                                  dev->i2c_apb_ctl.apb_port);

        /* Write to the APB_ADR0 and APB_ADR1 registers to set
         * the register offset */
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.addr0_reg,
                                  FIRST_BYTE(reg));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.addr1_reg,
                                  SECOND_BYTE(reg));

        /* Write the data value to the APB_DATA0, APB_DATA1, APB_DATA2,
         * and APB_DATA3 registers */
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.data0_reg,
                                  FIRST_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.data1_reg,
                                  SECOND_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.data2_reg,
                                  THIRD_BYTE(data));
        rc |= ds90ux9xx_i2c_write(dev, dev->i2c_apb_ctl.data3_reg,
                                  FOURTH_BYTE(data));

        apb_unlock(dev);

        return rc;
}

ds90ux9xx_err_t ds_i2c_read_aux(const ds90ux9xx_st_t *dev, uint32_t reg,
        uint32_t *value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: dev = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = aux_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock I2C AUX: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_apb_write(dev, dev->i2c_aux_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_apb_write(dev, dev->i2c_aux_ctl.cmd_reg,
                                      dev->i2c_aux_ctl.read_cmd);

        rc |= ds90ux9xx_i2c_apb_read(dev, dev->i2c_aux_ctl.read_reg, value);

        aux_unlock(dev);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read from the AUX channel: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

ds90ux9xx_err_t ds_i2c_write_aux(const ds90ux9xx_st_t *dev, uint32_t reg,
        uint32_t value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = aux_lock(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't lock I2C AUX: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        rc |= ds90ux9xx_i2c_apb_write(dev, dev->i2c_aux_ctl.addr_reg, reg);

        rc |= ds90ux9xx_i2c_apb_write(dev, dev->i2c_aux_ctl.write_reg, value);

        rc |= ds90ux9xx_i2c_apb_write(dev, dev->i2c_aux_ctl.cmd_reg,
                                      dev->i2c_aux_ctl.write_cmd);

        aux_unlock(dev);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write to the AUX channel: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

