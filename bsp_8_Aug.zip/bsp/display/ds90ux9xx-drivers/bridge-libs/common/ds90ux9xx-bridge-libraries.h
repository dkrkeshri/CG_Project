/**
 * @file       ds90ux9xx-bridge-libraries.h
 * @brief      Common API for bridge libraries
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UX9XX_BRIDGE_LIBRARIES__
#define __DS90UX9XX_BRIDGE_LIBRARIES__

#include "ds90ux9xx-core.h"

#define MAX_MAIN_PAGE_REGISTER  0xFF

#define HZ_TO_KHZ(x)            ((double)(x) / 1000)
#define HZ_TO_MHZ(x)            (HZ_TO_KHZ(x) / 1000)
#define HZ_TO_GHZ(x)            (HZ_TO_MHZ(x) / 1000)
#define MHZ_TO_HZ(x)            ((uint64_t)(x) * 1000000)

#define COUNT_BITS(count, value)                                                \
        do {                                                                    \
                uint8_t tmp_mask = (value);                                     \
                                                                                \
                while (tmp_mask) {                                              \
                        (count) += tmp_mask % 2;                                \
                        tmp_mask >>= 1;                                         \
                }                                                               \
        } while (0);

#define UPDATE_IRQ_TYPE(type_value, type_supported, type_requested)             \
        do {                                                                    \
                if ((type_requested)->irqs_requested &                          \
                    (type_supported).type) {                                    \
                        if ((type_requested)->irqs_enabled &                    \
                            (type_supported).type) {                            \
                                (type_value) |= ((type_supported).mask);        \
                        } else {                                                \
                                (type_value) &= ~((type_supported).mask);       \
                        }                                                       \
                }                                                               \
        } while (0);

#define UPDATE_IRQ_TYPES(types_value, types_supported, types_requested)         \
        do {                                                                    \
                for (int i = 0; i < ARRAY_SIZE(types_supported); i++) {         \
                        UPDATE_IRQ_TYPE((types_value), (types_supported[i]),    \
                                        (types_requested));                     \
                }                                                               \
        } while (0);

#define UPDATE_IRQ_SUBTYPE(irq_subtype, subtype_supported, subtype_requested)   \
        do {                                                                    \
                if ((subtype_requested)->subtypes_requested &                   \
                    (subtype_supported).type) {                                 \
                        if ((subtype_requested)->subtypes_enabled &             \
                            (subtype_supported).type) {                         \
                                (irq_subtype) |= ((subtype_supported).mask);    \
                        } else {                                                \
                                (irq_subtype) &= ~((subtype_supported).mask);   \
                        }                                                       \
                }                                                               \
        } while (0);

#define UPDATE_IRQ_SUBTYPES(subtypes, bridge_supported, subtypes_requested)     \
        do {                                                                    \
                for (int i = 0; i < ARRAY_SIZE(bridge_supported); i++) {        \
                        UPDATE_IRQ_SUBTYPE((subtypes), (bridge_supported[i]),   \
                                           (subtypes_requested));               \
                }                                                               \
        } while (0);

typedef struct ds9xx_irq_config {
        irq_type_t type;
        irq_type_t mask;
} ds9xx_irq_config_st_t;

ds90ux9xx_err_t init_interrupt(ds90ux9xx_st_t *dev, irq_type_t type,
        uint8_t port, irq_subtype_t subtypes);
void ds90ux9xx_global_interrupts_deinit(ds90ux9xx_st_t *dev);
irq_st_t *irq_get_entry(ds90ux9xx_st_t *dev, irq_type_t type, uint8_t id);
void debug_extended_isr_data(irq_common_st_t *irq);

/* Bridge API initialization */
ds90ux9xx_err_t api_not_implemented_generic(void);
ds90ux9xx_err_t api_not_supported_generic(void);

int init_operation_group(operation_fp_t *ops_group, int ops_len,
        operation_fp_t callback);
ds90ux9xx_err_t init_generic_operations(ds_ops_st_t *ops);

ds90ux9xx_err_t ds_get_fpd_bandwidth(const ds90ux9xx_st_t *dev, fpd_port_t port,
        int64_t *bandwidth);

#endif /* __DS90UX9XX_BRIDGE_LIBRARIES__ */

