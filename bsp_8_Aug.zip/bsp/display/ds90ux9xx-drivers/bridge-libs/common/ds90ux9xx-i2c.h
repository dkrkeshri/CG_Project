/**
 * @file       ds90ux9xx-i2c.h
 * @brief      I2C read/write common API
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UX9XX_I2C_H__
#define __DS90UX9XX_I2C_H__

#include "ds90ux9xx-core.h"

#ifdef UNITTEST
#include "UT-i2c_client-mock.h"
#else /* aarch64 */
#include "i2c_client.h"
#endif /* UNITTEST */

#define FIRST_BYTE(x)   ((x) & 0x000000FF)
#define SECOND_BYTE(x)  (((x) & 0x0000FF00) >> 8)
#define THIRD_BYTE(x)   (((x) & 0x00FF0000) >> 16)
#define FOURTH_BYTE(x)  (((x) & 0xFF000000) >> 24)

#define U8_MASK         (uint8_t)0xFF

struct ds90ux9xx;
typedef struct ds90ux9xx ds90ux9xx_st_t;

struct indirect_i2c;
typedef struct indirect_i2c indirect_i2c_st_t;

struct apb_i2c;
typedef struct apb_i2c apb_i2c_st_t;

ds90ux9xx_err_t ds90ux9xx_i2c_write(const ds90ux9xx_st_t *dev, uint8_t reg,
        uint8_t data);
ds90ux9xx_err_t ds90ux9xx_i2c_read(const ds90ux9xx_st_t *dev, uint8_t reg,
        uint8_t *data);
ds90ux9xx_err_t ds90ux9xx_i2c_update(const ds90ux9xx_st_t *dev, uint8_t reg,
        uint8_t mask, uint8_t data);

/* Indirect Access API */
ds90ux9xx_err_t ds90ux9xx_init_indirect_api(ds90ux9xx_st_t *dev,
        indirect_i2c_st_t *ind_ctl);

ds90ux9xx_err_t ds90ux9xx_i2c_read_ind_1b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint8_t *data);
ds90ux9xx_err_t ds90ux9xx_i2c_read_ind_2b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint16_t *data);

ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_1b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data);
ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_2b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data);
ds90ux9xx_err_t ds90ux9xx_i2c_write_ind_3b(const ds90ux9xx_st_t *dev,
        uint8_t page, uint8_t reg, uint32_t data);

/* APB API */
ds90ux9xx_err_t ds90ux9xx_init_apb(ds90ux9xx_st_t *dev, apb_i2c_st_t *apb_ctrl);
ds90ux9xx_err_t ds90ux9xx_i2c_apb_read(const ds90ux9xx_st_t *dev, uint16_t reg,
        uint32_t *data);
ds90ux9xx_err_t ds90ux9xx_i2c_apb_write(const ds90ux9xx_st_t *dev, uint16_t reg,
        uint32_t data);

/* AUX API */
ds90ux9xx_err_t ds_init_aux(ds90ux9xx_st_t *dev, aux_i2c_st_t *aux_control);
ds90ux9xx_err_t ds_i2c_read_aux(const ds90ux9xx_st_t *dev, uint32_t reg,
        uint32_t *value);
ds90ux9xx_err_t ds_i2c_write_aux(const ds90ux9xx_st_t *dev, uint32_t reg,
        uint32_t value);

#endif /* __DS90UX9XX_I2C_H__ */

