/**
 * @file       ds90ux9xx-bridge-libraries.c
 * @brief      Common bridge libraries routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include "ds90ux9xx-bridge-libraries.h"

ds90ux9xx_err_t init_interrupt(ds90ux9xx_st_t *dev, irq_type_t type,
        uint8_t port, irq_subtype_t subtypes)
{
        irq_st_t *irq;

        irq = alloc_data(1, irq_st_t);
        if (NULL == irq) {
                return DS90UX9XX_OOM;
        }

        irq->port = port;
        irq->type = type;
        irq->subtypes_supported = subtypes;

        list_add_tail(&dev->global_irqs.irq_list, &irq->node);

        return DS90UX9XX_SUCCESS;
}

void ds90ux9xx_global_interrupts_deinit(ds90ux9xx_st_t *dev)
{
        irq_st_t *irq = NULL;
        irq_st_t *tmp_irq = NULL;

        list_for_every_entry_safe(&dev->global_irqs.irq_list,
                                  irq,
                                  tmp_irq,
                                  irq_st_t,
                                  node) {
                list_delete(&irq->node);
                clear_data(&irq);
        }
}

irq_st_t *irq_get_entry(ds90ux9xx_st_t *dev, irq_type_t type, uint8_t id)
{
        irq_st_t *current = NULL;

        list_for_every_entry(&dev->global_irqs.irq_list, current, irq_st_t,
                             node) {
                if (type == current->type &&
                    id == current->id) {
                        return current;
                }
        }

        return NULL;
}

void debug_extended_isr_data(irq_common_st_t *irq)
{
#if (CONFIG_VERBOSE_LEVEL > 3)
        irq_st_t *current = NULL;

        log_dbg("EXTENDED IRQ INFO\n");
        log_dbg("IRQ group supported: 0x%x\n", irq->irqs_supported);
        log_dbg("IRQ group enabled  : 0x%x\n", irq->irqs_enabled);
        log_dbg("IRQ group triggered: 0x%x\n", irq->irqs_triggered);
        log_dbg("Type : Subtype : Id : Status:\n");

        list_for_every_entry(&irq->irq_list, current, irq_st_t,
                             node) {
                log_dbg("0x%x : 0x%x : %d : 0x%x\n",
                        current->type, current->subtypes_supported,
                        current->id, current->subtypes_triggered);
        }
#endif
}

/* Bridge library callback initialization */
inline
ds90ux9xx_err_t api_not_implemented_generic(void)
{
        log_dbg("%s\n", ds90ux9xx_err2str(DS90UX9XX_API_UNAVAILABLE));

        return DS90UX9XX_API_UNAVAILABLE;
}

inline
ds90ux9xx_err_t api_not_supported_generic(void)
{
        log_dbg("%s\n", ds90ux9xx_err2str(DS90UX9XX_NOT_SUPPORTED));

        return DS90UX9XX_NOT_SUPPORTED;
}

int init_operation_group(operation_fp_t *ops_group, int ops_len,
        operation_fp_t callback)
{
        int i = 0;

        if (NULL == ops_group) {
                log_err("Invalid args: ops_group = %p\n", ops_group);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < ops_len; i++) {
                ops_group[i] = callback;
        }

        return i;
}

ds90ux9xx_err_t init_generic_operations(ds_ops_st_t *ops)
{
        operation_fp_t generic_calback = NULL;

        if (NULL == ops) {
                log_err("Invalid args: ops = %p\n", ops);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        generic_calback = (operation_fp_t)api_not_implemented_generic;

        init_operation_group(ops->device, DEVICE_OPS_CNT, generic_calback);
        init_operation_group(ops->adc, ADC_OPS_CNT, generic_calback);
        init_operation_group(ops->bist, BIST_OPS_CNT, generic_calback);
        init_operation_group(ops->dphy, DPHY_OPS_CNT, generic_calback);
        init_operation_group(ops->fpd, FPD_OPS_CNT, generic_calback);
        init_operation_group(ops->gpio, GPIO_OPS_CNT, generic_calback);
        init_operation_group(ops->i2c, I2C_OPS_CNT, generic_calback);
        init_operation_group(ops->irq, IRQ_OPS_CNT, generic_calback);
        init_operation_group(ops->video, VIDEO_OPS_CNT, generic_calback);

        ops->is_initialized = true;

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds_get_fpd_bandwidth(const ds90ux9xx_st_t *dev, fpd_port_t port,
        int64_t *bandwidth)
{
        if (NULL == dev || NULL == bandwidth) {
                log_err("Invalid input: dev = %p, bandwidth = %p\n", dev,
                        bandwidth);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (port >= dev->fpd.ports_cnt) {
                log_err("Invalid port: port = %d, ports_cnt = %d\n", port,
                        dev->fpd.ports_cnt);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        *bandwidth = dev->fpd.port[port].bandwidth;

        return DS90UX9XX_SUCCESS;
}

