/**
 * @file       ds90uh948-gpio.h
 * @brief      ds90ub948 / ds90uh948 GPIO settings API
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH948_GPIO_H__
#define __DS90UH948_GPIO_H__

#include "ds90uh948.h"

ds90ux9xx_err_t ds90uh948_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);
ds90ux9xx_err_t ds90uh948_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);

#endif /* __DS90UH948_GPIO_H__ */

