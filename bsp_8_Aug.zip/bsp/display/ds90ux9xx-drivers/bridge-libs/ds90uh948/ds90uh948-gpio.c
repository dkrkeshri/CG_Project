/**
 * @file       ds90uh948-gpio.c
 * @brief      ds90ub948 / ds90uh948 GPIO settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include "ds90uh948-gpio.h"

#define DS948_GPIO_COUNT        (9 + 1) /* reserve for gpio4 */
#define HIGH_HALF               0xF0
#define LOW_HALF                0x0F
#define HIGH_OFFSET             4

#define UNDEFINED               0xFF
#define GPIO4                   4
#define DS948_REMOTE_GPIOS_CNT  4

typedef struct DS90UH948_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t mask;
} ds948_pins_st_t;

#define DS948_GPIO(gpio_name, reg_addr, mask_byte)                              \
        {                                                                       \
                .name = gpio_name,                                              \
                .reg = reg_addr,                                                \
                .mask = mask_byte,                                              \
        }

static ds948_pins_st_t ds948_gpios[DS948_GPIO_COUNT] = {
        DS948_GPIO("gpio0",     DS948_REG_GPIO_0,   LOW_HALF),
        DS948_GPIO("gpio1",     DS948_REG_GPIO_1_2, LOW_HALF),
        DS948_GPIO("gpio2",     DS948_REG_GPIO_1_2, HIGH_HALF),
        DS948_GPIO("gpio3",     DS948_REG_GPIO_3,   LOW_HALF),
        DS948_GPIO("undefined", UNDEFINED,          UNDEFINED),
        DS948_GPIO("gpio5",     DS948_REG_GPIO_5_6, LOW_HALF),
        DS948_GPIO("gpio6",     DS948_REG_GPIO_5_6, HIGH_HALF),
        DS948_GPIO("gpio7",     DS948_REG_GPIO_7_8, LOW_HALF),
        DS948_GPIO("gpio8",     DS948_REG_GPIO_7_8, HIGH_HALF),
        DS948_GPIO("gpio9",     DS948_REG_GPIO_9,   LOW_HALF),
};

static
inline int is_absent(int num)
{
        return num == GPIO4;
}

static
int is_wrong_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS948_GPIO_COUNT ||
            is_absent(num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh948_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;
        uint8_t reg, val, orig_val;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                val = DS948_GPIO_INPUT;
                break;
        case FUNC_GPIO_OUTPUT:
                if (GPIO_HIGH == gpio->value) {
                        val = DS948_GPIO_OUTPUT_HIGH;
                } else {
                        val = DS948_GPIO_OUTPUT_LOW;
                }

                break;
        case FUNC_REMOTE:
                if (gpio->num >= DS948_REMOTE_GPIOS_CNT) {
                        return DS90UX9XX_INVALID_PARAMETER;
                }

                val = DS948_GPIO_OUTPUT_REMOTE;
                break;
        case FUNC_I2S:
                val = DS948_GPIO_NORMAL_OPERATION;
                break;
        case FUNC_DISABLE:
                val = DS948_GPIO_TRI_STATE;
                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds948_gpios[gpio->num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &orig_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read original gpio value\n");

                return rc;
        }

        if (ds948_gpios[gpio->num].mask == HIGH_HALF) {
                val <<= HIGH_OFFSET;
                val |= orig_val & LOW_HALF;
        } else {
                val |= orig_val & HIGH_HALF;
        }

        return ds90ux9xx_i2c_write(dev, reg, val);
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == value) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds948_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ds948_gpios[num].mask == HIGH_HALF) {
                val = ((val & HIGH_HALF) >> HIGH_OFFSET);
        }

        *value = !!(val & DS948_GPIO_HIGH);

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
gpio_function_t get_function(uint8_t reg_val)
{
        if (!(reg_val & DS948_GPIO_ENABLE)) {
                return FUNC_I2S;
        }

        if (reg_val & DS948_GPIO_OUTPUT_REMOTE) {
                return FUNC_REMOTE;
        }

        if (reg_val & DS948_GPIO_INPUT) {
                return FUNC_GPIO_INPUT;
        }

        return FUNC_GPIO_OUTPUT;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t *function)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == function) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds948_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ds948_gpios[num].mask == HIGH_HALF) {
                val >>= HIGH_OFFSET;
        } else {
                val &= LOW_HALF;
        }

        *function = get_function(val);

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        if (NULL == remote) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FUNC_REMOTE == function) {
                *remote = num;

                log_dbg("Got remote %d for GPIO_%d\n", *remote, num);
        } else {
                *remote = NOT_SPECIFIED;

                log_dbg("No GPIO remote configuration\n");
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh948_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == gpio) {
                log_err("gpio is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_gpio_value(dev, gpio->num, &gpio->value);
        rc |= get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_remote(dev, gpio->num, gpio->function, &gpio->remote);

        return rc;
}

