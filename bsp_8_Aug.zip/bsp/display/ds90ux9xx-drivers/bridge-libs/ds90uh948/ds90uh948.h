/**
 * @file       ds90uh948.h
 * @brief      ds90ub948 / ds90uh948 specific registers, configurations
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH948_H__
#define __DS90UH948_H__

#include "ds90ux9xx-core.h"
#include "ds90ux9xx-i2c.h"

#define DEVICE_ID                       "_UH948"
#define DEVICE_ID_LEN                   6

/* DS90UH948 registers */

#define DS948_REG_I2C_DEV_ID            0x0
#define DS948_REG_RESET                 0x01

#define DS948_REG_GEN_STATUS            0x1C

#define DS948_REG_GPIO_9                0x1A
#define DS948_REG_GPIO_0                0x1D
#define DS948_REG_GPIO_1_2              0x1E
#define DS948_REG_GPIO_3                0x1F
#define DS948_REG_GPIO_5_6              0x20
#define DS948_REG_GPIO_7_8              0x21

#define DS948_REG_BIST_CTL              0x24
#define DS948_REG_BIST_ERRORS           0x25

#define DS948_REG_DUAL_RX_CTL           0x34

#define DS948_REG_MAP_SEL               0x49

#define DS948_REG_DEV_ID                0xF0


/* DS90UH948 bits and descriptions */
#define DS948_I2C_DEV_ID_SET            BIT(0)

/* ds90uh948 General Status Register 0 bits (0x1C) */
#define DS948_DES_LOCK                  BIT(0)
#define DS948_SIGNAL_DETECT             BIT(1)
#define DS948_DUAL_RX_STS               BIT(4)
#define DS948_DUAL_TX_STS               BIT(5)

#define DS948_MAP_SEL_FROM_REG          BIT(6)
#define DS948_MAP_SEL_MSB               BIT(5)
#define DS948_RX_PORT0_SEL              BIT(0)
#define DS948_RX_PORT1_SEL              BIT(1)
#define DS948_BIST_ENABLE               BIT(0)
#define DS948_BIST_DISABLE              0

/* For passing validation for u*H*948, when u*B*948 is used */
#define DS948_SKIP_HB_BYTE              2
#define DS948_HDCP_BYTE                 5

#define DS948_GPIO_NORMAL_OPERATION     0
#define DS948_GPIO_TRI_STATE            BIT(1)

#define DS948_GPIO_ENABLE               BIT(0)
#define DS948_GPIO_INPUT_ENABLE         BIT(1)
#define DS948_GPIO_REMOTE               BIT(2)
#define DS948_GPIO_HIGH                 BIT(3)

#define DS948_GPIO_OUTPUT_REMOTE        (DS948_GPIO_ENABLE | DS948_GPIO_REMOTE)
#define DS948_GPIO_OUTPUT_HIGH          (DS948_GPIO_ENABLE | DS948_GPIO_HIGH)
#define DS948_GPIO_OUTPUT_LOW           (DS948_GPIO_ENABLE)
#define DS948_GPIO_INPUT                (DS948_GPIO_ENABLE |                    \
                                         DS948_GPIO_INPUT_ENABLE)

#define DS948_RESET_CLK_WITH_REGS       BIT(1)
#define DS948_RESET_CLK_NO_REGS         BIT(0)
#define DS948_RESET_NORMAL_OPERATION    0

/*
 * Unfortunately we can't reset 941 completely (reset autoload).
 * So RESET_ALL resets just clocks & regs
 */
#define DS948_RESET_ALL                 DS948_RESET_CLK_WITH_REGS

#define DS948_MSB                       "msb"

#define DS948_FPD_PORTS_COUNT           2

#endif /* __DS90UH948_H__ */

