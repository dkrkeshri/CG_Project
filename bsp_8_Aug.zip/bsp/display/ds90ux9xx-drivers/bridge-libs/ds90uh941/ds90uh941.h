/**
 * @file       ds90uh941.h
 * @brief      ds90uh941 specific registers, configurations
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH941_H__
#define __DS90UH941_H__

#include "ds90ux9xx-core.h"
#include "ds90ux9xx-i2c.h"

/* registers */
#define DS941_REG_I2C_DEV_ID            0x00
#define DS941_REG_RESET                 0x01
#define DS941_REG_DES_ID                0x06
#define DS941_REG_GEN_CFG               0x03
#define DS941_REG_MODE_SELECT           0x04
#define DS941_REG_GEN_STATUS            0x0C
#define DS941_REG_TX_BIST_CTL           0x14
#define DS941_REG_BIST_BC_ERRORS        0x1B
#define DS941_REG_TX_PORT_SEL           0x1E

#define DS941_REG_GPIO_0                0x0D
#define DS941_REG_GPIO_1_2              0x0E
#define DS941_REG_GPIO_3                0x0F
#define DS941_REG_GPIO_5_6              0x10
#define DS941_REG_GPIO_7_8              0x11

#define DS941_REG_IND_CTL               0x40
#define DS941_REG_IND_ADDR              0x41
#define DS941_REG_IND_DATA              0x42
#define DS941_REG_BRIDGE_CTL            0x4F
#define DS941_REG_DUAL_CTL1             0x5B

#define DS941_REG_SLAVE_0               0x07
#define DS941_REG_SLAVE_1               0x70
#define DS941_REG_SLAVE_2               0x71
#define DS941_REG_SLAVE_3               0x72
#define DS941_REG_SLAVE_4               0x73
#define DS941_REG_SLAVE_5               0x74
#define DS941_REG_SLAVE_6               0x75
#define DS941_REG_SLAVE_7               0x76

#define DS941_REG_ALIAS_0               0x08
#define DS941_REG_ALIAS_1               0x77
#define DS941_REG_ALIAS_2               0x78
#define DS941_REG_ALIAS_3               0x79
#define DS941_REG_ALIAS_4               0x7A
#define DS941_REG_ALIAS_5               0x7B
#define DS941_REG_ALIAS_6               0x7C
#define DS941_REG_ALIAS_7               0x7D

#define DS941_REG_IRQ_CTL               0xC6
#define DS941_REG_DEV_ID                0xF0

#define IND_PAGE_SHIFT                  2
#define TO_IND_PAGE(page)               ((page) << IND_PAGE_SHIFT)
#define DS941_IND_PAGE_0                TO_IND_PAGE(0)
#define DS941_IND_PAGE_1                TO_IND_PAGE(1)
#define DS941_IND_PAGE_2                TO_IND_PAGE(2)
#define DS941_IND_PAGE_MAX              DS941_IND_PAGE_2

/* ds90uh941 General Status Register 0 bits (0x1C) */
#define DS941_LINK_DETECT               BIT(0)
#define DS941_BC_CRC_ERROR              BIT(1)
#define DS941_PCLK_DETECT               BIT(2)
#define DS941_BIST_CRC_ERROR            BIT(3)
#define DS941_LINK_LOST                 BIT(4)

/* bits and operations */
#define DS941_IND_READ                  BIT(0)
#define DS941_IND_AUTO_INC              BIT(1)
#define DS941_I2C_DEV_ID_SET            BIT(0)
#define DS941_DSI_CONTINUOUS_CLK        BIT(7)
#define DS941_PASS_THROUGH_EN           BIT(3)
#define DS941_PASS_THROUGH_MASK         DS941_PASS_THROUGH_EN
#define DS941_PCLK_DETECT               BIT(2)
#define DS941_IRQ_GLOBAL                BIT(0)
#define DS941_CRC_ERR_CLEAN             BIT(5)
#define DS941_BIST_ENABLE               BIT(0)

#define DS941_GPIO_NORMAL_OPERATION     0
#define DS941_GPIO_TRI_STATE            BIT(1)

#define DS941_GPIO_ENABLE               BIT(0)
#define DS941_GPIO_INPUT_ENABLE         BIT(1)
#define DS941_GPIO_REMOTE               BIT(2)
#define DS941_GPIO_HIGH                 BIT(3)

#define DS941_GPIO_OUTPUT_REMOTE        (DS941_GPIO_ENABLE | DS941_GPIO_REMOTE)
#define DS941_GPIO_OUTPUT_HIGH          (DS941_GPIO_ENABLE | DS941_GPIO_HIGH)
#define DS941_GPIO_OUTPUT_LOW           (DS941_GPIO_ENABLE)
#define DS941_GPIO_INPUT                (DS941_GPIO_ENABLE |                    \
                                         DS941_GPIO_INPUT_ENABLE)

#define DS941_DSI_LANES_OFFSET          2
#define DS941_DSI_LANES(x)              (((x) - 1) << DS941_DSI_LANES_OFFSET)

#define DEVICE_ID                       "_UH941"
#define DEVICE_ID_LEN                   6

#define DS941_I2C_SLAVE_COUNT           8

#define DS941_TX_PORT_1                 BIT(1)
#define DS941_TX_PORT_0                 BIT(0)

#define DS941_FPD3_TX_MODE              (BIT(2) | BIT(1) | BIT(0))
#define DS941_SINGLE_FPD                BIT(0)
#define DS941_DUAL_FPD                  (BIT(1) | BIT(0))
#define DS941_INDEPENDENT_FPD           (BIT(2) | BIT(0))
#define DS941_SPLITTER_FPD              (BIT(2) | BIT(1) | BIT(0))

#define DS941_RESET_CLK_WITH_REGS       BIT(1)
#define DS941_RESET_CLK_NO_REGS         BIT(0)
#define DS941_RESET_NORMAL_OPERATION    0

#define DS941_FPD_PORTS_COUNT           2
#define DS941_PHY_PORTS_COUNT           2

/*
 * Unfortunately we can't reset 941 completely (reset autoload).
 * So RESET_ALL resets just clocks & regs
 */
#define DS941_RESET_ALL                 DS941_RESET_CLK_WITH_REGS

enum slave_state {
        FREE = 0,
        OCCUPIED,
};

#endif /* __DS90UH941_H__ */

