/**
 * @file       ds90uh941.c
 * @brief      Driver for 941 bridges that performs actual work with the bridge
 *             and provides callbacks for the bridge driver
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include "ds90ux9xx-bridge-libraries.h"

#include "ds90uh941.h"
#include "ds90uh941-gpio.h"

struct ds90ux9xx_i2c_data {
        const uint8_t   slave_reg[DS941_I2C_SLAVE_COUNT];
        const uint8_t   alias_reg[DS941_I2C_SLAVE_COUNT];
        uint8_t         state[DS941_I2C_SLAVE_COUNT];
        pthread_mutex_t i2c_state_lock;
};

struct ds90ux9xx_i2c_data ds90uh941_slaves = {
        .slave_reg = {
                DS941_REG_SLAVE_0,
                DS941_REG_SLAVE_1,
                DS941_REG_SLAVE_2,
                DS941_REG_SLAVE_3,
                DS941_REG_SLAVE_4,
                DS941_REG_SLAVE_5,
                DS941_REG_SLAVE_6,
                DS941_REG_SLAVE_7,
        },
        .alias_reg = {
                DS941_REG_ALIAS_0,
                DS941_REG_ALIAS_1,
                DS941_REG_ALIAS_2,
                DS941_REG_ALIAS_3,
                DS941_REG_ALIAS_4,
                DS941_REG_ALIAS_5,
                DS941_REG_ALIAS_6,
                DS941_REG_ALIAS_7,
        },
        .state     = {FREE},
};

ds9xx_irq_config_st_t ds941_irqs[] = {
        {IRQ_GLOBAL, DS941_IRQ_GLOBAL},
};

ds90ux9xx_err_t ds90uh941_get_des_id(const ds90ux9xx_st_t *dev, uint8_t *des_id)
{
        ds90ux9xx_err_t rc = DS90UX9XX_INVALID_PARAMETER;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return rc;
        }

        if (NULL == des_id) {
                log_err("des_id ptr is NULL\n");

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_DES_ID, des_id);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't access DES_ID. Status: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *des_id = FROM_I2C_7B(*des_id);

        return rc;
}

static
int validate_ds90uh941(ds90ux9xx_st_t *dev)
{
        uint8_t val;

        for (int i = 0; i < DEVICE_ID_LEN; i++) {
                ds90ux9xx_i2c_read(dev, DS941_REG_DEV_ID + i, &val);
                if (val != DEVICE_ID[i]) {
                        return DS90UX9XX_WRONG_CHIP;
                }
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t pass_through_enable(ds90ux9xx_st_t *dev)
{
        return ds90ux9xx_i2c_update(dev, DS941_REG_GEN_CFG,
                                    DS941_PASS_THROUGH_MASK,
                                    DS941_PASS_THROUGH_EN);
}

static
ds90ux9xx_err_t pass_through_disable(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS941_REG_GEN_CFG;
        uint8_t val = 0;

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS941_PASS_THROUGH_EN;
        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

static
ds90ux9xx_err_t ds90uh941_set_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (port) {
        case PORT_0:
                rc = ds90ux9xx_i2c_write(dev, DS941_REG_TX_PORT_SEL,
                                         DS941_TX_PORT_0);

                break;
        case PORT_1:
                rc = ds90ux9xx_i2c_write(dev, DS941_REG_TX_PORT_SEL,
                                         DS941_TX_PORT_1);

                break;
        default:
                log_err("Invalid input: port = %d\n", port);

                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
ds90ux9xx_err_t set_dsi_lanes(ds90ux9xx_st_t *dev,
        ds_io_phy_port_settings_st_t *port_settings)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS941_REG_BRIDGE_CTL;
        uint8_t val = 0;

        if (NULL == dev || NULL == port_settings) {
                log_err("Invalid input: dev = %p, port_settings = %p\n", dev,
                        port_settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val |= DS941_DSI_LANES(port_settings->lanes);
        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("DSI lanes setting failed: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t configure_phy(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t port_cnt = 0;
        int i = 0;
        ds_io_phy_port_settings_st_t *phy_port_settings = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        phy_port_settings = dev->video_settings.io_phy_settings.port_settings;
        if (NULL == phy_port_settings) {
                log_err("Invalid input: io_phy_settings.port_settings = %p\n",
                        phy_port_settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        port_cnt = dev->video_settings.io_phy_settings.port_cnt;
        if (port_cnt > DS941_PHY_PORTS_COUNT) {
                log_err("Invalid port count = %d. Supported: %d\n", port_cnt,
                        DS941_PHY_PORTS_COUNT);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < port_cnt; i++) {
                rc = ds90uh941_set_tx_port(dev, phy_port_settings[i].port);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("TX port setting failed: %s\n",
                                ds90ux9xx_err2str(rc));

                        return rc;
                }

                rc = set_dsi_lanes(dev, &phy_port_settings[i]);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("DSI lanes setting failed: %s\n",
                                ds90ux9xx_err2str(rc));

                        return rc;
                }
        }

        return rc;
}

static
ds90ux9xx_err_t init_bridge_limits(ds_bridge_limits_st_t *limits)
{
        if (NULL == limits) {
                log_err("Invalid input: limits = %p\n", limits);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        limits->fpd_ports_count = DS941_FPD_PORTS_COUNT;

        return DS90UX9XX_SUCCESS;
}

/* TODO add multiple i2c support */
ds90ux9xx_err_t ds90uh941_map_fpd_i2c_slave(ds90ux9xx_st_t *dev,
        ds90ux9xx_slave_st_t *slave)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        pthread_mutex_lock(&ds90uh941_slaves.i2c_state_lock);

        while (i < DS941_I2C_SLAVE_COUNT &&
               OCCUPIED == ds90uh941_slaves.state[i]) {
                i++;
        }

        if (i >= DS941_I2C_SLAVE_COUNT) {
                log_err("Can't map slave %d\n", i);
                rc = DS90UX9XX_INVALID_PARAMETER;
                goto fail;
        }

        rc |= ds90ux9xx_i2c_write(dev, ds90uh941_slaves.slave_reg[i],
                                  TO_I2C_7B(slave->i2c_addr));
        rc |= ds90ux9xx_i2c_write(dev, ds90uh941_slaves.alias_reg[i],
                                  TO_I2C_7B(slave->i2c_map));

        if (DS90UX9XX_SUCCESS == rc) {
                ds90uh941_slaves.state[i] = OCCUPIED;
        }

fail:
        pthread_mutex_unlock(&ds90uh941_slaves.i2c_state_lock);

        return rc;
}

ds90ux9xx_err_t ds90uh941_init_fpd_port(ds90ux9xx_st_t *dev,
        ds90ux9xx_fpd_port_st_t *port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == port) {
                log_err("ds90ux9xx fpd port ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_init_fpd_mode(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS941_REG_DUAL_CTL1;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS941_FPD3_TX_MODE;

        if (EQUAL == strcmp(dev->fpd.fpd_tx_mode, SINGLE_FPD_MODE)) {
                val |= DS941_SINGLE_FPD;
        } else if (EQUAL == strcmp(dev->fpd.fpd_tx_mode, DUAL_FPD_MODE)) {
                val |= DS941_DUAL_FPD;
        } else if (EQUAL == strcmp(dev->fpd.fpd_tx_mode,
                                   INDEPENDENT_FPD_MODE)) {
                val |= DS941_INDEPENDENT_FPD;
        } else if (EQUAL == strcmp(dev->fpd.fpd_tx_mode, SPLITTER_FPD_MODE)) {
                val |= DS941_SPLITTER_FPD;
        }

        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

ds90ux9xx_err_t ds90uh941_init_fpd_ports(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DS90UX9XX_SUCCESS != ds90uh941_init_fpd_mode(dev)) {
                log_err("Can't init FPD mode\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        if (EOK != pthread_mutex_init(&ds90uh941_slaves.i2c_state_lock, NULL)) {
                log_err("Can't init mutex\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t map_dev_id(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid dev ptr\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to map\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_map);

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS941_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS941_I2C_DEV_ID_SET,
                        DS941_REG_I2C_DEV_ID);
                goto map_dev_error;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_map,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

map_dev_error:

        return rc;
}

static
ds90ux9xx_err_t bridge_reset(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        log_dbg("Attempt to reset bridge with 0x%x value on 0x%x i2c address\n",
                reset_mode, dev->i2c_dev->i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_RESET, reset_mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS941_REG_RESET, reset_mode);
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_init_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid dev ptr\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = pass_through_enable(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable pass-through\n");

                return rc;
        }

        rc = configure_phy(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't configure PHY: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = ds90uh941_set_tx_port(dev, PORT_0);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set FPD port: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = ds90uh941_init_fpd_ports(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't initialize FPD i2c slaves\n");

                return rc;
        }

        rc = map_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map i2c dev id failed\n");
        }

        return rc;
}

static
ds90ux9xx_err_t unmap_dev_id(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid dev ptr\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to unmap\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_addr);

        log_dbg("new_i2c_addr: 0x%x\n", new_i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS941_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS941_I2C_DEV_ID_SET,
                        DS941_REG_I2C_DEV_ID);

                return rc;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_addr,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_deinit_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = unmap_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Unmap i2c dev id failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_reset_device(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int mode = DS941_RESET_NORMAL_OPERATION;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (INITIAL_RESET == reset_mode) {
                mode = DS941_RESET_ALL;
        }

        rc = bridge_reset(dev, mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge reset failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_validate_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = validate_ds90uh941(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge validation failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_get_clk_status(ds90ux9xx_st_t *dev,
        ds_clk_status_st_t *clk_status)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t value = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_GEN_STATUS, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get PCLK status. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        clk_status->pixel_clk = !!(value & DS941_PCLK_DETECT);

        return rc;
}

ds90ux9xx_err_t ds90uh941_get_fpd_link(ds90ux9xx_st_t *dev,
        ds_fpd_link_st_t *fpd_link)
{
        uint8_t val;
        ds90ux9xx_err_t rc;

        if (NULL == dev || NULL == fpd_link) {
                log_err("Invalid input: dev = %p, fpd_link = %p\n", dev,
                        fpd_link);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_GEN_STATUS, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read link status. %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (true == !!(val & DS941_LINK_DETECT)) {
                fpd_link->detect = DS_DETECTED;
        } else {
                fpd_link->detect = DS_NOT_DETECTED;
        }

        if (true == !!(val & DS941_BC_CRC_ERROR)) {
                fpd_link->bc_crc_error = DS_ERROR_DETECTED;
        } else {
                fpd_link->bc_crc_error = DS_ERROR_NOT_DETECTED;
        }

        if (true == !!(val & DS941_BIST_CRC_ERROR)) {
                fpd_link->bist_crc_error = DS_ERROR_DETECTED;
        } else {
                fpd_link->bist_crc_error = DS_ERROR_NOT_DETECTED;
        }

        if (true == !!(val & DS941_LINK_LOST)) {
                fpd_link->lost = DS_DETECTED;
        } else {
                fpd_link->lost = DS_NOT_DETECTED;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_set_pass_through(ds90ux9xx_st_t *dev, state_t state)
{
        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DISABLE == state) {
                return pass_through_disable(dev);
        } else {
                return pass_through_enable(dev);
        }
}

ds90ux9xx_err_t ds90uh941_set_irq(ds90ux9xx_st_t *dev, irq_common_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val;
        irq_state_t request_enable = irq->irqs_enabled & irq->irqs_requested;
        irq_state_t request_disable = ~irq->irqs_enabled & irq->irqs_requested;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read(dev, DS941_REG_IRQ_CTL, &val);

        UPDATE_IRQ_TYPES(val, ds941_irqs, irq);

        rc |= ds90ux9xx_i2c_write(dev, DS941_REG_IRQ_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't write IRQ types parameters\n");

                return rc;
        }

        /* update interrupts state */
        dev->global_irqs.irqs_enabled &= ~(request_disable &
                                           dev->global_irqs.irqs_supported);
        dev->global_irqs.irqs_enabled |= (request_enable &
                                          dev->global_irqs.irqs_supported);

        return rc;
}

static
ds90ux9xx_err_t validate_ind_page(uint8_t page)
{
        if (page <= DS941_IND_PAGE_MAX) {
                return DS90UX9XX_SUCCESS;
        }

        return DS90UX9XX_INVALID_PARAMETER;
}

static
ds90ux9xx_err_t ds90uh941_write_reg(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Write: type %d; reg 0x%x, value 0x%x\n", dev->name,
                reg_data->type, reg_data->reg, reg_data->value);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                rc = ds90ux9xx_i2c_write(dev, reg_data->reg, reg_data->value);
                break;
        case DS9XX_PAGE_1:
        case DS9XX_PAGE_2:
                rc = ds90ux9xx_i2c_write_ind_1b(dev,
                                                TO_IND_PAGE(reg_data->type),
                                                reg_data->reg,
                                                reg_data->value);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

static
ds90ux9xx_err_t reset_crc_errors(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_MODE_SELECT, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x\n", DS941_REG_MODE_SELECT);

                return rc;
        }

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_MODE_SELECT,
                                 val | DS941_CRC_ERR_CLEAN);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n", DS941_REG_MODE_SELECT,
                        val | DS941_CRC_ERR_CLEAN);

                return rc;
        }

        /* DS941_REG_MODE_SELECT isn't self-clearing, need to clear it */
        val &= ~DS941_CRC_ERR_CLEAN;

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_MODE_SELECT, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS941_REG_MODE_SELECT, val);

                return rc;
        }

        log_dbg("CRC error counters have been reset\n");

        return rc;
}

static
ds90ux9xx_err_t set_bist_disable(const ds90ux9xx_st_t *dev,
        uint8_t tx_bist_ctl_val)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = tx_bist_ctl_val & ~DS941_BIST_ENABLE;

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_TX_BIST_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS941_REG_TX_BIST_CTL, val);

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_TX_BIST_CTL, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x\n", DS941_REG_TX_BIST_CTL);

                return rc;
        }

        if (val & DS941_BIST_ENABLE) {
                log_dbg("BIST can't be disabled on 941 bridge\n");
        } else {
                log_dbg("BIST has been disabled on 941 bridge\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_bist_enable(const ds90ux9xx_st_t *dev,
        uint8_t tx_bist_ctl_val)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = tx_bist_ctl_val | DS941_BIST_ENABLE;

        rc = ds90ux9xx_i2c_write(dev, DS941_REG_TX_BIST_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS941_REG_TX_BIST_CTL, val);

                return rc;
        }

        log_dbg("BIST has been enabled by 941 bridge\n");

        return reset_crc_errors(dev);
}

ds90ux9xx_err_t ds90uh941_set_bist_state(const ds90ux9xx_st_t *dev,
        state_t bist_state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_INVALID_PARAMETER;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_TX_BIST_CTL, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x\n", DS941_REG_TX_BIST_CTL);

                return rc;
        }

        if (ENABLE == bist_state) {
                rc = set_bist_enable(dev, val);
        } else if (DISABLE == bist_state) {
                rc = set_bist_disable(dev, val);
        }

        return rc;
}

ds90ux9xx_err_t ds90uh941_get_bist_result(ds90ux9xx_st_t *dev,
        bist_result_st_t *bist_result)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == bist_result) {
                log_err("bist result ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS941_REG_BIST_BC_ERRORS,
                                &bist_result->bist_err_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x\n", DS941_REG_BIST_BC_ERRORS);

                return rc;
        }

        bist_result->bist_err_count_is_avaliable = 1;

        return rc;
}

ds90ux9xx_err_t ds90uh941_get_bridge_revision(ds90ux9xx_st_t *dev,
        ds90ux9xx_revision_t *bridge_revision)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        /**
         * TODO: Implement
         */

        return rc;
}

ds90ux9xx_err_t library_deinit(ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        pthread_mutex_destroy(&dev->i2c_ind_ctl.mutex);

        ds90ux9xx_logger_deinit();

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t library_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        indirect_i2c_st_t ind_control = {
                .ctrl_reg      = DS941_REG_IND_CTL,
                .addr_reg      = DS941_REG_IND_ADDR,
                .data_reg      = DS941_REG_IND_DATA,
                .auto_inc      = DS941_IND_AUTO_INC,
                .read_enable   = DS941_IND_READ,
                .validate_page = validate_ind_page
        };

        if (NULL == dev) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->ops.lib_deinit = (operation_fp_t)library_deinit;

        rc = ds90ux9xx_logger_init(dev->bridge_type);
        if (DS90UX9XX_SUCCESS != rc) {
                return DS90UX9XX_INIT_FAILURE;
        }

        rc = init_bridge_limits(&dev->bridge_limits);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to init bridge limits. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                return DS90UX9XX_INIT_FAILURE;
        }

        rc = ds90ux9xx_init_indirect_api(dev, &ind_control);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't init Indirect Access API\n");
                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        rc = init_generic_operations(&dev->ops);
        if (DS90UX9XX_SUCCESS != rc || false == dev->ops.is_initialized) {
                log_err("Can't init bridge operations. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        dev->ops.device[DEINIT_DEVICE] =
                (operation_fp_t)ds90uh941_deinit_device;
        dev->ops.device[GET_BRIDGE_REVISION] =
                (operation_fp_t)ds90uh941_get_bridge_revision;
        dev->ops.device[INIT_DEVICE] =
                (operation_fp_t)ds90uh941_init_device;
        dev->ops.device[RESET_DEVICE] =
                (operation_fp_t)ds90uh941_reset_device;
        dev->ops.device[VALIDATE_DEVICE] =
                (operation_fp_t)ds90uh941_validate_device;

        dev->ops.bist[GET_BIST_RESULT] =
                (operation_fp_t)ds90uh941_get_bist_result;
        dev->ops.bist[SET_BIST_STATE] =
                (operation_fp_t)ds90uh941_set_bist_state;

        dev->ops.dphy[GET_CLK_STATUS] =
                (operation_fp_t)ds90uh941_get_clk_status;

        dev->ops.fpd[GET_FPD_LINK] =
                (operation_fp_t)ds90uh941_get_fpd_link;
        dev->ops.fpd[SET_TX_PORT] =
                (operation_fp_t)ds90uh941_set_tx_port;

        dev->ops.gpio[SET_GPIO] =
                (operation_fp_t)ds90uh941_set_gpio;
        dev->ops.gpio[GET_GPIO] =
                (operation_fp_t)ds90uh941_get_gpio;

        dev->ops.i2c[GET_REMOTE_ID] =
                (operation_fp_t)ds90uh941_get_des_id;
        dev->ops.i2c[MAP_I2C_SLAVE] =
                (operation_fp_t)ds90uh941_map_fpd_i2c_slave;
        dev->ops.i2c[SET_PASS_THROUGH] =
                (operation_fp_t)ds90uh941_set_pass_through;
        dev->ops.i2c[WRITE_REGISTER] =
                (operation_fp_t)ds90uh941_write_reg;

        dev->ops.irq[SET_IRQ] =
                (operation_fp_t)ds90uh941_set_irq;

        log_dbg("Initialized successfully\n");

        return rc;

init_failed:
        ds90ux9xx_logger_deinit();

        return rc;
}

