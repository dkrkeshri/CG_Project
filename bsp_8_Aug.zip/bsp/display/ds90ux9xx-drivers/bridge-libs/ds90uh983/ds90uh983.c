/**
 * @file       ds90uh983.c
 * @brief      Driver for 983 bridges that performs actual work with the bridge
 *             and provides callbacks for the bridge driver
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Leonid Chebenko <external.leonid.chebenko@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include <math.h>

#ifdef UNITTEST
#include "UT-ds90uh983-adc-mock.h"
#include "UT-ds90uh983-gpio-mock.h"
#include "UT-ds90uh983-irq-mock.h"
#include "UT-ds90uh983-mock.h"
#include "UT-ds90ux9xx-bridge-libraries-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh983.h"
#include "ds90ux9xx-bridge-libraries.h"

#include "ds90uh983-adc.h"
#include "ds90uh983-gpio.h"
#include "ds90uh983-irq.h"
#endif /* UNITTEST */

#define WATER_FREEZING_TEMPERATURE_KELVIN 273
#define ADC_TEMPERATURE_RESOLUTION        2

#define VP_STREAMS_COUNT(x)         ((x) - 1)

struct ds90ux9xx_i2c_slave_regs ds90uh983_slaves = {
        .slave_reg = {
                DS983_REG_SLAVE_ID_0,
                DS983_REG_SLAVE_ID_1,
                DS983_REG_SLAVE_ID_2,
                DS983_REG_SLAVE_ID_3,
                DS983_REG_SLAVE_ID_4,
                DS983_REG_SLAVE_ID_5,
                DS983_REG_SLAVE_ID_6,
                DS983_REG_SLAVE_ID_7,
        },
        .alias_reg = {
                DS983_REG_SLAVE_ALIAS_0,
                DS983_REG_SLAVE_ALIAS_1,
                DS983_REG_SLAVE_ALIAS_2,
                DS983_REG_SLAVE_ALIAS_3,
                DS983_REG_SLAVE_ALIAS_4,
                DS983_REG_SLAVE_ALIAS_5,
                DS983_REG_SLAVE_ALIAS_6,
                DS983_REG_SLAVE_ALIAS_7,
        },
        .route_reg = {
                DS983_REG_SLAVE_DEST_0,
                DS983_REG_SLAVE_DEST_1,
                DS983_REG_SLAVE_DEST_2,
                DS983_REG_SLAVE_DEST_3,
                DS983_REG_SLAVE_DEST_4,
                DS983_REG_SLAVE_DEST_5,
                DS983_REG_SLAVE_DEST_6,
                DS983_REG_SLAVE_DEST_7,
        }
};

struct ds90ux9xx_i2c_slave_control ds90uh983_slave_ctrl = {0};

static
ds90ux9xx_err_t ds90uh983_i2c_write_array(const ds90ux9xx_st_t *dev,
        ds90uh983_write_array_t *write_array, uint32_t size)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev || NULL == write_array) {
                log_err("Invalid input: dev = %p, write_array = %p\n",
                        dev, write_array);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < size; i++) {
                rc |= ds90ux9xx_i2c_write(dev, write_array[i].reg,
                                          write_array[i].data);
        }

        return rc;
}

static
ds90ux9xx_err_t vp_preconfiguration(const ds90ux9xx_st_t *dev)
{
        static ds90uh983_write_array_t fpd4_vp_init_sequence[] =
                DS90UH983_FPD4_VP_PRECONFIG;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90uh983_i2c_write_array(dev, fpd4_vp_init_sequence,
                                         ARRAY_SIZE(fpd4_vp_init_sequence));
}

static
ds90ux9xx_err_t bridge_preconfiguration(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_preconfiguration(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP preconfiguration failed: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t dev_id_map(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_map);

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS983_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write new DEV ID to reg 0x%x\n",
                        DS983_REG_I2C_DEV_ID);
                goto map_dev_error;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_map,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set new id for the i2c\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

map_dev_error:

        return rc;
}

static
ds90ux9xx_err_t unmap_dev_id(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to unmap\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_addr);

        log_dbg("new_i2c_addr: 0x%x\n", new_i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS983_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS983_I2C_DEV_ID_SET,
                        DS983_REG_I2C_DEV_ID);

                return rc;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_addr,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t init_bridge_limits(ds_bridge_limits_st_t *limits)
{
        if (NULL == limits) {
                log_err("Invalid input: limits = %p\n", limits);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        limits->fpd_ports_count = DS983_MAX_FPD_PORTS;
        limits->video_cores_count = DS983_MAX_VP_COUNT;
        limits->crc_types_mask = FORWARD_CHANNEL;

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh983_get_des_id(const ds90ux9xx_st_t *dev, uint8_t *des_id)
{
        ds90ux9xx_err_t rc = DS90UX9XX_INVALID_PARAMETER;

        if (NULL == dev || NULL == des_id) {
                log_err("Invalid input: dev = %p, des_id = %p\n", dev, des_id);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_DES_ID, des_id);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't access DES_ID. Status: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *des_id = FROM_I2C_7B(*des_id);

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t *port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == port) {
                log_err("Invalid input: dev = %p, port = %p\n", dev, port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_TX_PORT_SEL, (uint8_t *)port);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read DS983_REG_TX_PORT_SEL register\n");
        }

        *port = TO_DS983_TX_PORT(*port);

        return rc;
}

static
ds90ux9xx_err_t set_tx_port(const ds90ux9xx_st_t *dev, fpd_port_t port)
{
        uint8_t reg_val = DS983_TX_PORT_0_ENABLE;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Enable port 0 by default */
        if (PORT_1 == port) {
                reg_val = DS983_TX_PORT_1_ENABLE;
        }

        return ds90ux9xx_i2c_write(dev, DS983_REG_TX_PORT_SEL, reg_val);
}

ds90ux9xx_err_t ds90uh983_set_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (PORT_0 != port &&
            PORT_1 != port) {
                log_err("Incorrect TX port provided\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return set_tx_port(dev, port);
}

static
ds90ux9xx_err_t bridge_reset(const ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("Attempt to reset bridge with 0x%x value on 0x%x i2c address\n",
                reset_mode, dev->i2c_dev->i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_RESET_CTL, reset_mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS983_REG_RESET_CTL, reset_mode);
        }

        return rc;
}

static
ds90ux9xx_err_t reset_crc_errors(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_GENERAL_CFG2, &val);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't read 0x%x\n", DS983_REG_GENERAL_CFG2);

                return rc;
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_GENERAL_CFG2,
                                 val | DS983_CRC_ERR_CLEAN);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n", DS983_REG_GENERAL_CFG2,
                        val | DS983_CRC_ERR_CLEAN);

                return rc;
        }

        /* DS983_REG_MODE_SELECT isn't self-clearing, need to clear it */
        val &= ~DS983_CRC_ERR_CLEAN;

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_GENERAL_CFG2, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS983_REG_GENERAL_CFG2, val);

                return rc;
        }

        log_dbg("CRC error counters have been reset\n");

        return rc;
}

static
ds90ux9xx_err_t reset_pll_channel(const ds90ux9xx_st_t *dev, uint8_t channel)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reset_mask;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (channel) {
        case PLL_CH0:
                reset_mask = DS983_RESET_PLL_CH0;
                break;
        case PLL_CH1:
                reset_mask = DS983_RESET_PLL_CH1;
                break;
        case PLL_CH0_CH1:
        default:
                reset_mask = DS983_RESET_PLL_CH0 | DS983_RESET_PLL_CH1;
        }

        rc = bridge_reset(dev, reset_mask);
        if (DS90UX9XX_SUCCESS != rc) {
                log_dbg("Reset pll failed. reset_mask = '0x%x'\n", reset_mask);
        }

        return rc;
}

static
ds90ux9xx_err_t pass_through_enable(ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90ux9xx_i2c_update(dev, DS983_REG_GENERAL_CFG, U8_MASK,
                                    DS983_I2C_PASS_THROUGH |
                                    DS983_RX_CRC_CHECKER_ENABLE);
}

static
ds90ux9xx_err_t pass_through_disable(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS983_REG_GENERAL_CFG;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS983_I2C_PASS_THROUGH;
        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

static
ds90ux9xx_err_t ds983_get_fpd_bandwidth(const ds90ux9xx_st_t *dev,
        fpd_port_t port, uint64_t *bandwidth)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int64_t bandwidth_tmp = 0;

        if (NULL == dev || NULL == bandwidth) {
                log_err("Invalid input: dev = %p, bandwidth = %p\n", dev,
                        bandwidth);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds_get_fpd_bandwidth(dev, port, &bandwidth_tmp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (NOT_SPECIFIED == bandwidth_tmp) {
                bandwidth_tmp = MHZ_TO_HZ(DS983_LINE_RATE_13P5MBPS);
        }

        *bandwidth = bandwidth_tmp;

        log_dbg("FPD Bandwidth (port %d): %llu\n", port, *bandwidth);

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t vp_resolution_set(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        const ds90ux9xx_video_resolution_st_t *resolution = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == vp->video_resolution.set) {
                log_dbg("VP[%d]: No need to set resolution\n", vp->id);

                return rc;
        }

        resolution = &vp->video_resolution;

        log_dbg("Configuring resolution %dx%d\n",
                resolution->h_active, resolution->v_active);

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_DP_H_ACTIVE0, vp->id),
                resolution->h_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_ACTIVE0, vp->id),
                resolution->h_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_BACK0, vp->id),
                resolution->h_back_porch);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_WIDTH0, vp->id),
                resolution->h_pulse_width);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_TOTAL0, vp->id),
                resolution->h_total);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_ACTIVE0, vp->id),
                resolution->v_active);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_BACK0, vp->id),
                resolution->v_back_porch);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_WIDTH0, vp->id),
                resolution->v_pulse_width);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_FRONT0, vp->id),
                resolution->v_front_porch);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        log_dbg("\nResolution set:\n"
                "H active       : %d\n"
                "H back porch   : %d\n"
                "H front porch  : %d\n"
                "H width        : %d\n"
                "V active       : %d\n"
                "V back porch   : %d\n"
                "V fron porch   : %d\n"
                "V width        : %d\n",
                resolution->h_active,
                resolution->h_back_porch,
                resolution->h_total - resolution->h_active -
                resolution->h_pulse_width - resolution->h_back_porch,
                resolution->h_pulse_width,
                resolution->v_active,
                resolution->v_back_porch,
                resolution->v_front_porch,
                resolution->v_pulse_width);

        log_dbg("Resolution settings are applied\n");

        return rc;
}

static
ds90ux9xx_err_t vp_get_resolution(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_video_resolution_st_t *resolution = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        resolution = &vp->video_resolution;

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_ACTIVE0, vp->id),
                &resolution->h_active);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_BACK0, vp->id),
                &resolution->h_back_porch);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_WIDTH0, vp->id),
                &resolution->h_pulse_width);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_H_TOTAL0, vp->id),
                &resolution->h_total);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_ACTIVE0, vp->id),
                &resolution->v_active);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_BACK0, vp->id),
                &resolution->v_back_porch);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_WIDTH0, vp->id),
                &resolution->v_pulse_width);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_VID_V_FRONT0, vp->id),
                &resolution->v_front_porch);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read resolution. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        resolution->h_front_porch = resolution->h_total -
                                    resolution->h_active -
                                    resolution->h_pulse_width -
                                    resolution->h_back_porch;

        resolution->v_total = resolution->v_active +
                              resolution->v_front_porch +
                              resolution->v_back_porch +
                              resolution->v_pulse_width;

        log_dbg("\nResolution get:\n"
                "H total        : %d\n"
                "H active       : %d\n"
                "H back porch   : %d\n"
                "H front porch  : %d\n"
                "H width        : %d\n"
                "V total        : %d\n"
                "V active       : %d\n"
                "V back porch   : %d\n"
                "V fron porch   : %d\n"
                "V width        : %d\n",
                resolution->h_total,
                resolution->h_active,
                resolution->h_back_porch,
                resolution->h_front_porch,
                resolution->h_pulse_width,
                resolution->v_total,
                resolution->v_active,
                resolution->v_back_porch,
                resolution->v_front_porch,
                resolution->v_pulse_width);

        return rc;
}

static
ds90ux9xx_err_t vp_frequency_set(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint64_t bandwidth = 0;
        float vp_ref_clk = 0;
        uint32_t pclk_M = 0;
        uint8_t pclk_N = DS983_VP_FPD4_PCLK_N_DEFAULT;
        float vp_clk = 0;
        float pclk = 0;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                log_dbg("No need to setup VP frequency in FPD3 mode\n");

                return rc;
        }

        rc = ds983_get_fpd_bandwidth(dev, vp->port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("VP[%d]: Configure VP frequency\n", vp->id);

        pclk = HZ_TO_MHZ(vp->video_resolution.h_total *
                         vp->video_resolution.v_total *
                         vp->video_resolution.fps);

        vp_clk = FPD4_PCLK_TO_VP_CLK(pclk);

        vp_ref_clk = FPD4_FREQ_TO_VP_REF_CLK(HZ_TO_MHZ(bandwidth));

        log_dbg("pclk        : %f Mhz\n", pclk);
        log_dbg("vp_clk      : %f Mhz\n", vp_clk);
        log_dbg("vp_ref_clk  : %f Mhz\n", vp_ref_clk);

        pclk_M = (uint32_t)ceil(vp_clk * pow(2, pclk_N) / vp_ref_clk);

        log_dbg("pclk_N      : %d\n", pclk_N);
        log_dbg("pclk_M      : %d\n", pclk_M);

        rc = ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_12,
                                        TO_VP_REG(DS983_IND_REG_VP_PCLK_GEN_N,
                                                  vp->id), pclk_N);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                                         TO_VP_REG(DS983_IND_REG_VP_PCLK_GEN_M,
                                                   vp->id), pclk_M);

        log_dbg("VP[%d]: VP frequency configured\n", vp->id);

        return rc;
}

static
ds90ux9xx_err_t vp_cropping_set(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        const ds90ux9xx_video_cropping_st_t *cropping = NULL;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t regval_state = DS983_VP_DISABLE_CROPPING;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == vp->video_cropping.set) {
                log_dbg("VP[%d]: No need to set cropping\n", vp->id);

                return rc;
        }

        cropping = &vp->video_cropping;

        if (ENABLE == cropping->state) {
                regval_state = DS983_VP_ENABLE_CROPPING;
        }

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_CROP_START_X0, vp->id),
                cropping->start_x);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_CROP_START_Y0, vp->id),
                cropping->start_y);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_CROP_STOP_X0, vp->id),
                cropping->stop_x);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_CROP_STOP_Y0, vp->id),
                cropping->stop_y);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_12,
                TO_VP_REG(DS983_IND_REG_VP_CTL, vp->id),
                regval_state);
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

        return rc;
}

static
ds90ux9xx_err_t vp_map_source_stream(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = 0;
        uint8_t value = 0;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = TO_VP_REG(DS983_IND_REG_VP_CFG, vp->id);

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_12, reg, &value);

        value &= VP_SRC_SELECT_CLEAR;
        value |= vp->stream;

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_12, reg, value);

        return rc;
}

static
ds90ux9xx_err_t vp_configure(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_resolution_set(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP resolution\n", vp->id);

                return rc;
        }

        rc = vp_cropping_set(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP cropping\n", vp->id);

                return rc;
        }

        rc = vp_map_source_stream(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't map VP source stream. Error: %s\n",
                        vp->id, ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = vp_frequency_set(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VP[%d]: Can't set VP frequency\n", vp->id);

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_video_core_st_t *init_vp(uint8_t id)
{
        ds90ux9xx_video_core_st_t *vp = NULL;

        vp = alloc_data(1, ds90ux9xx_video_core_st_t);
        if (NULL == vp) {
                log_err("Failed to allocate ds90ux9xx_video_core_st_t\n");

                return NULL;
        }

        vp->id = id;

        return vp;
}

static
ds90ux9xx_err_t get_vp_count(const ds90ux9xx_st_t *dev, uint8_t *vp_count)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t vp_mask_state = 0;

        if (NULL == dev || NULL == vp_count) {
                log_err("Invalid input: dev = %p, vp_count = %p\n", dev,
                        vp_count);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_VP_ENABLE_REG, &vp_mask_state);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("I2C read error: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        COUNT_BITS(*vp_count, vp_mask_state);

        return rc;
}

static
ds90ux9xx_video_core_st_t *vp_get_by_id(ds90ux9xx_st_t *dev, uint8_t id)
{
        ds90ux9xx_video_core_st_t *vp = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return NULL;
        }

        if (id >= DS983_MAX_VP_COUNT) {
                log_err("Invalid VP requested: id = %d\n", id);

                return NULL;
        }

        log_dbg("Search VP configuration for VP %d\n", id);

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (vp->id == id) {
                        log_dbg("VP %d configuration found\n", id);

                        return vp;
                }
        }

        vp = init_vp(id);
        if (NULL == vp) {
                log_err("Can't allocate bridge VP data\n");

                return NULL;
        }

        /* Add VP in list so it will be destoyed on bridge deinitialization */
        list_add_tail(&dev->video_settings.vp_list, &vp->node);

        return vp;
}

static
bool is_vp_stream_map_valid_fpd3(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return false;
        }

        uint8_t mapped_vp;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (vp_count < DS983_MAX_VP_COUNT_FPD3) {
                return true;
        }

        /* TODO: check if that is a valid assumption */
        if (EQUAL != strcmp(dev->fpd.fpd_tx_mode, INDEPENDENT_FPD_MODE)) {
                return false;
        }

        /* Check that opposite port is not configured for the same vp */
        if (PORT_1 == vp->port) {
                rc = set_tx_port(dev, PORT_0);
        } else {
                rc = set_tx_port(dev, PORT_1);
        }

        rc |= ds90ux9xx_i2c_read(dev, DS983_FPD3_STREAM_SEL, &mapped_vp);
        if (DS90UX9XX_SUCCESS != rc) {
                return false;
        }

        if (vp->id != mapped_vp) {
                return true;
        }

        return false;
}

static
ds90ux9xx_err_t vp_stream_map_fpd3(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == is_vp_stream_map_valid_fpd3(dev, vp, vp_count)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_tx_port(dev, vp->port);
        rc |= ds90ux9xx_i2c_write(dev, DS983_FPD3_STREAM_SEL, vp->id);

        return rc;
}

static
ds90ux9xx_err_t vp_stream_map(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp, uint8_t vp_count)
{
        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                return vp_stream_map_fpd3(dev, vp, vp_count);
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t vp_check_state(const ds90ux9xx_st_t *dev,
        ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t vp_count = 0;
        uint8_t max_vp_count = DS983_MAX_VP_COUNT;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* We can disable VP without any checks */
        if (DISABLE == vp->state) {
                log_err("VP disable state is always allowed\n");

                return DS90UX9XX_SUCCESS;
        }

        rc = get_vp_count(dev, &vp_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get VP count. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                max_vp_count = DS983_MAX_VP_COUNT_FPD3;
        }

        /* Include our VP in validation */
        if ((vp_count + 1) > max_vp_count) {
                log_err("Exceeded maximum VP count\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = vp_stream_map(dev, vp, vp_count);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map VP stream. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t bridge_vp_update(ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_video_core_st_t *bridge_vp = NULL;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        bridge_vp = vp_get_by_id(dev, vp->id);
        if (NULL == bridge_vp) {
                log_err("Can't find and allocate bridge VP %d data\n", vp->id);

                return DS90UX9XX_OOM;
        }

        log_dbg("Update vp core %d\n", vp->id);

        bridge_vp->port = vp->port;
        bridge_vp->state = vp->state;
        bridge_vp->stream = vp->stream;

        /* fill resolution */
        if (true == vp->video_resolution.set) {
                memcpy(&bridge_vp->video_resolution, &vp->video_resolution,
                       sizeof(struct ds90ux9xx_video_resolution));

                log_dbg("Resolution settings are updated\n");
        }

        /* fill cropping */
        if (true == vp->video_cropping.set) {
                memcpy(&bridge_vp->video_cropping, &vp->video_cropping,
                       sizeof(struct ds90ux9xx_video_cropping));

                log_dbg("Cropping settings are updated\n");
        }

        return DS90UX9XX_SUCCESS;
}

static inline
ds90ux9xx_err_t vp_streams_set(const ds90ux9xx_st_t *dev, uint8_t vp_count)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90ux9xx_i2c_write(dev, DS983_REG_VP_CONFIG_REG,
                                   VP_STREAMS_COUNT(vp_count));
}

static
ds90ux9xx_err_t vp_disable_all(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_VP_ENABLE_REG,
                                 DS983_DISABLE_ALL_VP);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write to DS983_REG_VP_ENABLE_REG. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        log_dbg("Disable ALL VP\n");

        return rc;
}

static
ds90ux9xx_err_t vp_enable_all(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t regval_vp = 0;
        uint8_t vp_enabled = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                log_dbg("Set VP[%d] state %x\n", vp->id, vp->state);

                if (ENABLE == vp->state) {
                        rc = vp_check_state(dev, vp);
                        if (DS90UX9XX_SUCCESS != rc) {
                                log_err("Can't enable VP %d\n", vp->id);

                                return DS90UX9XX_INVALID_PARAMETER;
                        }

                        regval_vp |= DS983_VP_ENABLE(vp->id);
                        vp_enabled++;
                }
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_VP_ENABLE_REG, regval_vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable VPs\n");

                return rc;
        }

        return vp_streams_set(dev, vp_enabled);
}

static
uint8_t to_fpd4_pdiv(uint8_t post_divider)
{
        switch (post_divider) {
        case PLL_VCO_DIV_1:
                return DS983_PLL_FPD4_DIV_1_CODE;
        case PLL_VCO_DIV_2:
                return DS983_PLL_FPD4_DIV_2_CODE;
        case PLL_VCO_DIV_4:
                return DS983_PLL_FPD4_DIV_4_CODE;
        case PLL_VCO_DIV_8:
                return DS983_PLL_FPD4_DIV_8_CODE;
        default:
                return DS983_PLL_FPD4_DIV_1_CODE;
        }
}

static
ds90ux9xx_err_t pll_fpd4_match_dividers(uint64_t fpd_freq, uint32_t *n_divider,
        uint32_t *post_divider)
{
        uint32_t p_div = 0;
        uint32_t n_div = 0;
        int i = 0;

        if (NULL == n_divider || NULL == post_divider) {
                log_err("Invalid input: n_divider = %p, post_divider = %p\n",
                        n_divider, post_divider);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < ARRAY_SIZE(PLL_VCO_FPD4_N_DIVS); i++) {
                p_div = PLL_VCO_FPD4_N_DIVS[i];
                n_div = DS983_CALCULATE_PLL_N_DIV(fpd_freq, p_div);

                if (n_div > PLL_VCO_N_DIV_MIN) {
                        *n_divider = n_div;
                        *post_divider = p_div;

                        return DS90UX9XX_SUCCESS;
                }
        }

        log_err("post_divider and n_divider can't be found\n");

        return DS90UX9XX_INVALID_PARAMETER;
}

static
ds90ux9xx_err_t pll_set_fpd4(const ds90ux9xx_st_t *dev, fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint64_t bandwidth = 0;
        uint64_t fpd_freq = 0;
        uint32_t post_divider = 0;
        uint32_t n_divider = 0;
        uint8_t reg = 0;
        uint8_t val = 0;
        uint8_t vco = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds983_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        fpd_freq = bandwidth / DS983_FPD_BITS_PER_CLOCK;

        rc = pll_fpd4_match_dividers(fpd_freq, &n_divider, &post_divider);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't match dividers: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        if (bandwidth == MHZ_TO_HZ(DS983_LINE_RATE_3P375MBPS)) {
                post_divider = DS983_PLL_VCO_DIV_3P375GBPS;
        }

        log_dbg("bandwidth   : %llu\n", bandwidth);
        log_dbg("fpd_freq    : %llu\n", fpd_freq);
        log_dbg("VCO         : %d\n", DS983_PLL_FPD4_VCO_DEFAULT);
        log_dbg("post_divider: %d\n", post_divider);
        log_dbg("post_div_reg: 0x%x\n", to_fpd4_pdiv(post_divider));
        log_dbg("MASH        : 0x%x\n", DS983_PLL_FPD4_MASH_ORDER);
        log_dbg("NDIV        : %d\n", n_divider);
        log_dbg("Numerator   : %d\n", DS983_PLL_FPD4_NUMERATOR_DEFAULT);
        log_dbg("Denominator : %d\n", DS983_PLL_FPD4_DENOMINATOR_DEFAULT);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_VCO, port);
        vco = TO_PLL_VCO(DS983_PLL_FPD4_VCO_DEFAULT);

        rc = ds90ux9xx_i2c_write_ind_1b(dev,
                                        DS983_IND_PAGE_2,
                                        reg,
                                        vco);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_MASH_ORDER, port);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         DS983_PLL_FPD4_MASH_ORDER);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_NDIV, port);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         n_divider);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_DEN, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         DS983_PLL_FPD4_DENOMINATOR_DEFAULT);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_PDIV, port);
        val = to_fpd4_pdiv(post_divider) | DS983_PLL_VCO_AUTO_SELECT;

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         val);

        log_dbg("FPD 4 PLL initialization done with a result: %s\n",
                ds90ux9xx_err2str(rc));

        return rc;
}

static
uint8_t to_fpd3_pdiv(uint8_t post_divider)
{
        switch (post_divider) {
        case PLL_VCO_DIV_2:
                return DS983_PLL_FPD3_DIV_2_CODE;
        case PLL_VCO_DIV_8:
                return DS983_PLL_FPD3_DIV_8_CODE;
        case PLL_VCO_DIV_16:
                return DS983_PLL_FPD3_DIV_16_CODE;
        case PLL_VCO_DIV_4:
        default:
                return DS983_PLL_FPD3_DIV_4_CODE;
        }
}

static
uint8_t vco_match_fpd3_divider(uint32_t half_fpd_clk)
{
        uint8_t divider = PLL_VCO_DIV_2;

        do {
                if ((half_fpd_clk * divider > DS983_PLL_FPD3_VCO_MIN_FREQ) &&
                    (half_fpd_clk * divider < DS983_PLL_FPD3_VCO_MAX_FREQ)) {
                        return divider;
                }

                divider = divider << 1;
        } while (divider <= PLL_VCO_DIV_16);

        return 0;
}

static
ds90ux9xx_err_t pll_set_fpd3(const ds90ux9xx_st_t *dev, fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg;
        uint8_t pdiv;
        uint8_t vco;
        float fpd_clk;
        float pclk = 0;
        float vco_clk;
        uint32_t N_divider;
        uint32_t numerator;
        uint8_t vco_num;
        uint8_t post_divider;
        uint32_t denominator;
        uint32_t ref_clk = PLL_REFCLK_27MHZ;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint32_t pixel_count = 0, curr_pixel_count = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                curr_pixel_count = vp->video_resolution.h_total *
                                   vp->video_resolution.v_total *
                                   vp->video_resolution.fps;
                if (curr_pixel_count > pixel_count) {
                        pixel_count = curr_pixel_count;
                }
        }

        pclk = HZ_TO_MHZ(pixel_count);
        fpd_clk = pclk * DS983_PLL_FPD3_PCLK_BITS;

        log_dbg("pclk        : %f MHz\n", pclk);
        log_dbg("fpd_clk     : %f MHz\n", fpd_clk);

        /* Get half of the FPD clk rate*/
        fpd_clk = fpd_clk / 2;

        /* search compatible vco */
        for (vco_num = 0; vco_num < DS983_MAX_VCO_COUNT; vco_num++) {
                post_divider = vco_match_fpd3_divider(fpd_clk);
                if (0 != post_divider) {
                        break;
                }
        }

        if (DS983_MAX_VCO_COUNT == vco_num) {
                log_dbg("Can't find correct VCO\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Calculate parameters */
        log_dbg("post_divider: %d\n", post_divider);

        vco_clk = fpd_clk * post_divider;
        log_dbg("vco_clk     : %f MHz\n", vco_clk);

        ref_clk = ref_clk * DS983_PLL_FPD3_REFCLK_COEF;
        log_dbg("ref_clk * 2 : %d MHz\n", ref_clk);

        N_divider = vco_clk / ref_clk;
        log_dbg("N_div (calc): %d\n", N_divider);

        denominator = DS983_PLL_MAX_DENOMINATOR;
        numerator = (vco_clk - N_divider * ref_clk) * (denominator / ref_clk);
        log_dbg("numerator   : %d\n", numerator);
        log_dbg("denominator : %d\n", denominator);
        log_dbg("vco_num     : %d\n", vco_num);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_PDIV, port);
        pdiv = DS983_PLL_VCO_AUTO_SELECT | to_fpd3_pdiv(post_divider);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         pdiv);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_VCO, port);
        vco = TO_PLL_VCO(vco_num);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS983_IND_PAGE_2,
                                         DS983_IND_REG_PLL_VCO,
                                         vco);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_MASH_ORDER, port);

        rc |= ds90ux9xx_i2c_write_ind_1b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         DS983_PLL_MASH_FPD3);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_NDIV, port);

        rc |= ds90ux9xx_i2c_write_ind_2b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         N_divider);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_DEN, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev, DS983_IND_PAGE_2,
                                         reg,
                                         denominator);

        reg = TO_PLL_PORT_REG(DS983_IND_REG_PLL_NUM, port);

        rc |= ds90ux9xx_i2c_write_ind_3b(dev,
                                         DS983_IND_PAGE_2,
                                         reg,
                                         numerator);

        return rc;
}

static
ds90ux9xx_err_t pll_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->fpd.port ||
            dev->fpd.ports_cnt <= 0 ||
            dev->fpd.ports_cnt > DS983_MAX_FPD_PORTS) {
                log_err("Invalid input: fpd.ports_cnt = %p, fpd.port = %p\n",
                        dev->fpd.ports_cnt, dev->fpd.port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < dev->fpd.ports_cnt; i++) {
                if (true == dev->settings.backward_compatibility) {
                        log_dbg("Init PLL in FPD3 mode for port %d\n",
                                dev->fpd.port[i].id);

                        rc |= pll_set_fpd3(dev, dev->fpd.port[i].id);
                } else {
                        log_dbg("Init PLL in FPD4 mode for port %d\n",
                                dev->fpd.port[i].id);

                        rc |= pll_set_fpd4(dev, dev->fpd.port[i].id);
                }
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't setup PLL. %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = reset_pll_channel(dev, PLL_CH0_CH1);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't do digital reset. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("Reset PLL done\n");

        return rc;
}

static
ds90ux9xx_err_t port_backward_channel_init(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t down_sampling_rate = 0;
        uint8_t bc_configuration = 0;
        uint64_t bandwidth = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds983_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        if (bandwidth == MHZ_TO_HZ(DS983_LINE_RATE_10P8MBPS)) {
                bc_configuration = DS983_DATAPATH_BC_FC_168P75MBPS;
        } else {
                bc_configuration = DS983_DATAPATH_BC_FC_135MBPS;
        }

        if (bandwidth == MHZ_TO_HZ(DS983_LINE_RATE_12P528MBPS)) {
                down_sampling_rate = DS983_BC_DOWN_SAMPLING_RATE_2;
        } else {
                down_sampling_rate = DS983_BC_DOWN_SAMPLING_RATE_1;
        }

        rc |= set_tx_port(dev, port);
        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_DATAPATH_BC_FC,
                                  bc_configuration);
        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_BC_DOWN_SAMPLING_RATE,
                                  down_sampling_rate);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set backward channel. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("Backward channel setup finished:  bc_configuration = %u,"
                "down_sampling_rate = %u\n",
                bc_configuration, down_sampling_rate);

        return rc;
}

static
ds90ux9xx_err_t backward_channel_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        fpd_port_t port;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (port = 0; port < dev->fpd.ports_cnt; port++) {
                rc |= port_backward_channel_init(dev, port);
        }

        return rc;
}

static
void vp_timeslots_calculate(ds90ux9xx_video_core_st_t *vp, int64_t bandwidth,
        const char *fpd_tx_mode)
{
        double throughput_multiplier = DS983_DEFAULT_FPD_THROUGPUT_MULT;
        double stream_bandwidth = 0.0;
        double bandwidth_rate = 0.0;
        double fpd_throughput = 0.0;
        double pclk = 0.0;

        if (NULL == vp || NULL == fpd_tx_mode) {
                log_err("Invalid input: vp = %p, fpd_tx_mode = %p\n",
                        vp, fpd_tx_mode);

                return;
        }

        if (EQUAL == strcmp(fpd_tx_mode, DUAL_FPD_MODE)) {
                throughput_multiplier = DS983_DUAL_FPD_THROUGPUT_MULT;
        }

        pclk = vp->video_resolution.h_total *
               vp->video_resolution.v_total *
               vp->video_resolution.fps;

        stream_bandwidth = HZ_TO_GHZ(pclk * vp->video_resolution.bpp);
        fpd_throughput = throughput_multiplier * HZ_TO_GHZ((double)bandwidth) *
                         DS983_FPD4_THROUGPUT_COEFFICIENT;
        bandwidth_rate = stream_bandwidth / fpd_throughput;
        vp->timeslots = ceil(DS983_TIMESLOTS_LIMIT * bandwidth_rate);

        log_dbg("VP[%d] Stream PCLK          = %.0f Hz\n",
                vp->id, pclk);
        log_dbg("VP[%d] Requested throughput = %f GHz\n",
                vp->id, stream_bandwidth);
        log_dbg("VP[%d] Available throughput = %f GHz\n",
                vp->id, fpd_throughput);
        log_dbg("VP[%d] Bandwith taken       = %3.2f %%\n",
                vp->id, bandwidth_rate * 100);
        log_dbg("VP[%d] timeslots            = %d\n",
                vp->id, vp->timeslots);
}

static
ds90ux9xx_err_t timeslots_calculate(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        /* TODO: update namings: change ports to link layers */
        uint8_t timeslots_port0 = 0;
        uint8_t timeslots_port1 = 0;
        int64_t bandwidth = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state) {
                        continue;
                }

                rc = ds_get_fpd_bandwidth(dev, vp->port, &bandwidth);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't obtain bandwidth: vp->port = %u. "
                                "Error: %s\n", vp->port, ds90ux9xx_err2str(rc));

                        return rc;
                }

                vp_timeslots_calculate(vp, bandwidth, dev->fpd.fpd_tx_mode);

                if (PORT_1 == vp->port) {
                        timeslots_port1 += vp->timeslots;
                } else {
                        timeslots_port0 += vp->timeslots;
                }
        }

        log_dbg("Total TIMESLOTS: port0: %d; port1: %d\n",
                timeslots_port0, timeslots_port1);

        if (timeslots_port0 > DS983_TIMESLOTS_LIMIT ||
            timeslots_port1 > DS983_TIMESLOTS_LIMIT) {
                log_err("Too much timeslots allocated:\n");
                log_err("timeslots_port0 = %u, timeslots_port1 = %u, "
                        "DS983_TIMESLOTS_LIMIT = %d\n", timeslots_port0,
                        timeslots_port1, DS983_TIMESLOTS_LIMIT);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t timeslots_stream_configure(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t streams_port0 = 0;
        uint8_t streams_port1 = 0;
        uint8_t reg = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Enable streams and set timeslots */
        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state) {
                        continue;
                }

                if (vp->stream >= DS983_MAX_LINK_LAYER_STREAMS) {
                        log_err("VP[%d] Incorrect stream id %d\n",
                                vp->id, vp->stream);

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                if (PORT_1 == vp->port) {
                        streams_port1 |= BIT(vp->stream);
                } else {
                        streams_port0 |= BIT(vp->stream);
                }

                log_dbg("Set timeslots %d for VP %d at port %d stream %d\n",
                        vp->timeslots, vp->id, vp->port, vp->stream);

                reg = GET_STREAM_SLOT_REG(vp->port, vp->stream);
                rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                                 reg,
                                                 vp->timeslots);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set timeslots. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        /* Enable streams on link layer 0 */
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                         DS983_IND_REG_LINK0_STREAM_ENABLE,
                                         streams_port0);

        /* Enable streams on link layer 1 */
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                         DS983_IND_REG_LINK1_STREAM_ENABLE,
                                         streams_port1);

        return rc;
}

static
ds90ux9xx_err_t timeslots_stream_map_layer(const ds90ux9xx_st_t *dev,
        uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;
        uint8_t streams01 = 0;
        uint8_t streams23 = 0;
        bool streams01_set = false;
        bool streams23_set = false;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (port >= DS983_MAX_FPD_PORTS) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                if (DISABLE == vp->state || vp->port != port) {
                        continue;
                }

                if (vp->stream < DS983_VP_MAP_STREAM_COUNT_IN_REG) {
                        streams01 |= MAP_VP_TO_STREAM(vp->id, vp->stream);
                        streams01_set = true;
                } else {
                        streams23 |= MAP_VP_TO_STREAM(vp->id, vp->stream);
                        streams23_set = true;
                }

                log_dbg("Map link[%d] VP[%d] to stream %d\n",
                        vp->port, vp->id, vp->stream);
        }

        if (false == streams01_set) {
                log_dbg("Nothing to configure\n");

                return rc;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                         DS983_IND_REG_LINK_MAP_STREAM_0_1,
                                         streams01);

        /* Skip configuration for streams 2, 3 if mapping is not populated
         * as 0 there means VP0 on both streams.
         * The default value 0x32 will be populated in this case
         */
        if (false == streams23_set) {
                return rc;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                         DS983_IND_REG_LINK_MAP_STREAM_2_3,
                                         streams23);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map VPs to layer %d. Error: %s\n",
                        port, ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t timeslots_stream_map(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t port = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (port = 0; port < DS983_MAX_FPD_PORTS; port++) {
                rc |= timeslots_stream_map_layer(dev, port);
        }

        return rc;
}

static inline
ds90ux9xx_err_t timeslots_link_layer_disable(const ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                          DS983_IND_REG_LINK_LAYER_CTL,
                                          DS983_LINK_LAYERS_DISABLE);
}

static inline
ds90ux9xx_err_t timeslots_link_layer_enable(const ds90ux9xx_st_t *dev)
{
        uint8_t layer_ctrl = DS983_LINK_LAYERS_ENABLE;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (EQUAL == strcmp(dev->fpd.fpd_tx_mode, DUAL_FPD_MODE) ||
            EQUAL == strcmp(dev->fpd.fpd_tx_mode, SINGLE_FPD_MODE)) {
                layer_ctrl = DS983_LINK_LAYER_0_ENABLE;
        }

        return ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_11,
                                          DS983_IND_REG_LINK_LAYER_CTL,
                                          layer_ctrl);
}

static
ds90ux9xx_err_t timeslots_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                return rc;
        }

        rc = timeslots_link_layer_disable(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't disable link layer: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = timeslots_calculate(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't calculate timeslots\n");

                return rc;
        }

        rc = timeslots_stream_configure(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't configure streams\n");

                return rc;
        }

        rc = timeslots_stream_map(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't map timeslots\n");

                return rc;
        }

        rc = timeslots_link_layer_enable(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable Link Layers\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_vp_configure(ds90ux9xx_st_t *dev,
        const ds90ux9xx_video_core_st_t *vp)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp) {
                log_err("Invalid input: dev = %p, vp = %p\n", dev, vp);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* load configuration to the bridge */
        rc = bridge_vp_update(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Update video configuration failed. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = vp_configure(dev, vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Set video configuration failed. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = pll_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("PLL setup failed. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = vp_enable_all(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("VPs states setup failed. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t validate_ds90uh983(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (int i = 0; i < DEVICE_ID_SIZE; i++) {
                rc |= ds90ux9xx_i2c_read(dev, DS983_REG_TX_ID + i, &val);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("I2C read error\n");

                        return rc;
                }

                if (val != DEVICE_ID[i]) {
                        log_err("Comparison error\n");

                        return DS90UX9XX_WRONG_CHIP;
                }
        }

        return rc;
}

static
ds90ux9xx_err_t slave_routing_to_reg(ds_slave_routing_st_t *routing,
        uint8_t *route_reg)
{
        int i = I2C_ROUTING_DEPTH_1;

        if (NULL == routing ||
            NULL == route_reg ||
            routing->depth > DS983_MAX_I2C_DEPTH ||
            routing->i2c_bus_id >= DS983_MAX_REMOTE_I2C_COUNT) {
                log_err("Incorrect routing data\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* depth 0 contains bridge outgoing port
         * It is not included in DC routing and used in the alias[0] reg instead
         */
        for (; i < routing->depth + I2C_ROUTING_DEPTH_1; i++) {
                if (routing->depth_port[i] >= DS983_MAX_FPD_PORTS) {
                        log_err("Incorrect routing data: port_number = %d, "
                                "depth_port = %d\n", i, routing->depth_port[i]);

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                *route_reg |= DS983_I2C_DEPTH_PORT(i, routing->depth_port[i]);
        }

        *route_reg |= DS983_I2C_DEPTH_COUNT(routing->depth);
        *route_reg |= routing->i2c_bus_id;

        log_dbg("Route register prepared: %x\n", *route_reg);

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh983_map_fpd_i2c_slave(ds90ux9xx_st_t *dev,
        ds90ux9xx_slave_st_t *slave)
{
        ds90ux9xx_err_t rc;
        ds_slave_routing_st_t *i2c_routing = NULL;
        uint8_t route_regval = 0;
        uint8_t alias_regval = 0;
        int err = 0;
        int i = 0;
        int i2c_id = 0;

        if (NULL == dev || NULL == slave) {
                log_err("Invalid input: dev = %p, slave = %p\n", dev, slave);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        i2c_id = slave->i2c_bus_id;
        if (i2c_id >= DS983_MAX_I2C_COUNT) {
                log_err("Incorrect i2c id provided\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        err = pthread_mutex_lock(&ds90uh983_slave_ctrl.i2c_state_lock);
        if (EOK != err) {
                log_err("Can't obtain the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        log_dbg("Try to map slave %x to %x\n", slave->i2c_addr, slave->i2c_map);
        log_dbg("The host id=%d\n", i2c_id);

        while (i < DS983_I2C_SLAVE_COUNT &&
               OCCUPIED == ds90uh983_slave_ctrl.state[i2c_id][i]) {
                log_dbg("State for %d bus and slave %d is %d\n",
                        i2c_id, i, ds90uh983_slave_ctrl.state[i2c_id][i]);
                i++;
        }

        if (i >= DS983_I2C_SLAVE_COUNT) {
                log_err("Can't map slave %d\n", i);
                rc = DS90UX9XX_INVALID_PARAMETER;
                goto fail;
        }

        i2c_routing = &slave->i2c_routing;
        rc = slave_routing_to_reg(i2c_routing, &route_regval);

        alias_regval = TO_I2C_7B(slave->i2c_map);
        alias_regval |= i2c_routing->depth_port[I2C_ROUTING_DEPTH_0];

        log_dbg("Available slave %d on bus %d\n", i, i2c_id);

        rc |= ds90ux9xx_i2c_write(dev, ds90uh983_slaves.slave_reg[i],
                                  TO_I2C_7B(slave->i2c_addr));
        rc |= ds90ux9xx_i2c_write(dev, ds90uh983_slaves.alias_reg[i],
                                  alias_regval);
        rc |= ds90ux9xx_i2c_write(dev, ds90uh983_slaves.route_reg[i],
                                  route_regval);

        if (DS90UX9XX_SUCCESS == rc) {
                ds90uh983_slave_ctrl.state[i2c_id][i] = OCCUPIED;
        }

fail:
        err = pthread_mutex_unlock(&ds90uh983_slave_ctrl.i2c_state_lock);
        if (EOK != err) {
                log_err("Can't release the mutex: %s\n", strerror(err));

                return DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t set_fpd4_mode(const ds90ux9xx_st_t *dev,
        const char *fpd_mode, uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS983_REG_FPD4_CFG;
        uint64_t bandwidth = 0;
        uint8_t val = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n", dev,
                        fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds983_get_fpd_bandwidth(dev, port, &bandwidth);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get bandwidth: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("set FPD port %d mode '%s'\n", port, fpd_mode);

        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS983_FPD4_TX_MODE(port, DS983_FPD4_CLEAN_TX_MODE);

        if (EQUAL == strcmp(fpd_mode, SINGLE_FPD_MODE)) {
                val |= DS983_FPD4_TX_MODE(port, DS983_FPD4_TX_MODE_SINGLE);
        } else if (EQUAL == strcmp(fpd_mode, DUAL_FPD_MODE)) {
                val |= DS983_FPD4_TX_MODE(port, DS983_FPD4_TX_MODE_DUAL);
        } else if (EQUAL == strcmp(fpd_mode, INDEPENDENT_FPD_MODE)) {
                val |= DS983_FPD4_TX_MODE(port, DS983_FPD4_TX_MODE_INDEPENDENT);
        } else {
                log_err("Unsupported mode '%s'\n", fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        if (bandwidth == MHZ_TO_HZ(DS983_LINE_RATE_3P375MBPS)) {
                /* disable FPD halfrate mode, required for 3P375MBPS */
                rc |= ds90ux9xx_i2c_update(dev, DS983_REG_GENERAL_CFG2,
                                           DS983_FPD_HALFRATE_MODE_MANUAL_MASK,
                                           DS983_FPD_HALFRATE_MODE_MANUAL);

                rc |= ds90ux9xx_i2c_update(dev, DS983_REG_GENERAL_CFG2,
                                           DS983_FPD_HALFRATE_MODE_MASK,
                                           DS983_FPD_HALFRATE_MODE_DISABLE);
        }

        return rc;
}

static
ds90ux9xx_err_t set_fpd3_mode(const ds90ux9xx_st_t *dev,
        const char *fpd_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS983_REG_FPD3_MODE_CTL;
        uint8_t val = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n", dev,
                        fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("fpd mode %s\n", fpd_mode);

        /* disable fpd4 */
        rc |= ds90ux9xx_i2c_read(dev, DS983_REG_FPD4_CFG, &val);
        val &= DS983_FPD3_BOTH_PORTS_ENABLE_MASK;
        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_FPD4_CFG, val);

        /* Prepare to set fpd3 mode */
        rc = ds90ux9xx_i2c_write(dev, DS983_REG_FPD3_FIFO_CFG,
                                 DS983_FPD3_FIFO_DRAIN |
                                 DS983_FPD3_ALIGN_ERR_THR |
                                 DS983_ENABLE_FPD3_FIFO);

        /* enable fpd halfrate mode, required for fpd3 */
        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_GENERAL_CFG2,
                                  DS983_DPRX_EN | DS983_FPD_HALFRATE_MODE);

        /* set fpd3 mode */
        rc |= ds90ux9xx_i2c_read(dev, reg, &val);
        val &= ~DS983_FPD3_TX_MODE;

        if (EQUAL == strcmp(fpd_mode, SINGLE_FPD_MODE)) {
                val |= DS983_FPD3_TX_MODE_SINGLE_PORT_0;
        } else if (EQUAL == strcmp(fpd_mode, DUAL_FPD_MODE)) {
                val |= DS983_FPD3_TX_MODE_DUAL_FPD3;
        } else if (EQUAL == strcmp(fpd_mode, INDEPENDENT_FPD_MODE)) {
                val |= DS983_FPD3_TX_MODE_INDEPENDENT_FPD3;
        } else if (EQUAL == strcmp(fpd_mode, SPLITTER_FPD_MODE)) {
                val |= DS983_FPD3_TX_MODE_SPLITTER_FPD3;
        } else {
                log_err("Unsupported mode '%s'\n", fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write(dev, reg, val);

        return rc;
}

ds90ux9xx_err_t ds90uh983_set_fpd_mode(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_fpd_st_t *fpd, fpd_port_t port_id)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == fpd) {
                log_err("Invalid input: dev = %p, fpd = %p\n", dev, fpd);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == fpd->fpd_tx_mode) {
                log_err("Invalid input: fpd_tx_mode = %p\n", fpd->fpd_tx_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                rc = set_fpd3_mode(dev, fpd->fpd_tx_mode);
        } else {
                rc = set_fpd4_mode(dev, fpd->fpd_tx_mode, port_id);
        }

        rc |= set_tx_port(dev, PORT_0);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set FPD mode. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t get_fpd3_mode(const ds90ux9xx_st_t *dev,
        char *fpd_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n", dev,
                        fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_FPD3_MODE_CTL, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD mode\n");

                return rc;
        }

        log_dbg("reg 0x%x, val 0x%x\n", DS983_REG_FPD3_MODE_CTL, val);

        val &= DS983_FPD3_TX_MODE;

        switch (val) {
        case DS983_FPD3_TX_MODE_SINGLE_PORT_0:
                strcpy(fpd_mode, SINGLE_FPD_MODE);
                break;
        case DS983_FPD3_TX_MODE_DUAL_FPD3:
                strcpy(fpd_mode, DUAL_FPD_MODE);
                break;
        case DS983_FPD3_TX_MODE_INDEPENDENT_FPD3:
                strcpy(fpd_mode, INDEPENDENT_FPD_MODE);
                break;
        case DS983_FPD3_TX_MODE_SPLITTER_FPD3:
                strcpy(fpd_mode, SPLITTER_FPD_MODE);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("FPD mode: %s\n", fpd_mode);

        return rc;
}

static
ds90ux9xx_err_t get_fpd4_mode(const ds90ux9xx_st_t *dev,
        char *fpd_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;
        fpd_port_t port;
        uint8_t mode = 0;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n", dev,
                        fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->fpd.port) {
                log_err("Invalid input: fpd port = %p\n", dev->fpd.port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (dev->fpd.port->id >= DS983_MAX_FPD_PORTS) {
                log_err("Invalid input: fpd port = %d\n", dev->fpd.port->id);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        port = dev->fpd.port->id;

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_FPD4_CFG, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD mode\n");

                return rc;
        }

        log_dbg("reg 0x%x, val 0x%x\n", DS983_REG_FPD4_CFG, val);

        mode = DS983_FPD4_PORT_TX_MODE(port, val);

        switch (mode) {
        case DS983_FPD4_TX_MODE_SINGLE:
                strcpy(fpd_mode, SINGLE_FPD_MODE);
                break;
        case DS983_FPD4_TX_MODE_DUAL:
                strcpy(fpd_mode, DUAL_FPD_MODE);
                break;
        case DS983_FPD4_TX_MODE_INDEPENDENT:
                strcpy(fpd_mode, INDEPENDENT_FPD_MODE);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("FPD mode: %s\n", fpd_mode);

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_fpd_mode(const ds90ux9xx_st_t *dev,
        char *fpd_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == fpd_mode) {
                log_err("Invalid input: dev = %p, fpd_mode = %p\n", dev,
                        fpd_mode);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                rc = get_fpd3_mode(dev, fpd_mode);
        } else {
                rc = get_fpd4_mode(dev, fpd_mode);
        }

        return rc;
}

static
ds90ux9xx_err_t fpd_ports_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->fpd.port) {
                log_err("Invalid input: dev->fpd.port = %p\n", dev->fpd.port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < dev->fpd.ports_cnt; i++) {
                rc = ds90uh983_set_fpd_mode(dev, &dev->fpd,
                                            dev->fpd.port[i].id);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't init FPD mode\n");

                        return DS90UX9XX_INIT_FAILURE;
                }
        }

        if (EOK != pthread_mutex_init(&ds90uh983_slave_ctrl.i2c_state_lock,
                                      NULL)) {
                log_err("Can't init mutex\n");

                return DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t common_settings(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_tx_port(dev, PORT_0);
        rc |= reset_crc_errors(dev);
        rc |= pass_through_enable(dev);

        return rc;
}

static
ds90ux9xx_err_t master_i2c_port_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int primary_i2c_id = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (false == dev->settings.map_i2c_to_primary) {
                log_dbg("No master i2c to slave i2c routing\n");

                return rc;
        }

        if (false == dev->i2c_dev->primary_bus) {
                log_err("Bridge not on the primary bus\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        primary_i2c_id = dev->i2c_dev->host_id;
        if (primary_i2c_id >= DS983_MAX_I2C_COUNT) {
                log_err("Invalid i2c id set for primary bus\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_I2C_MASTER_CHAIN_CTL1,
                                 DS983_SET_SLAVE0(primary_i2c_id) |
                                 DS983_SET_SLAVE1(primary_i2c_id));
        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_I2C_MASTER_CHAIN_CTL2,
                                  DS983_SET_SLAVE2(primary_i2c_id));

        log_dbg("Route slave i2c to master i2c %d. Result: %s\n",
                primary_i2c_id, ds90ux9xx_err2str(rc));

        return rc;
}

static
ds90ux9xx_err_t vp_subsystem_init(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_core_st_t *vp = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(&dev->video_settings.vp_list,
                             vp,
                             ds90ux9xx_video_core_st_t,
                             node) {
                log_dbg("VP[%d] Trying configure\n", vp->id);

                rc = vp_configure(dev, vp);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("VP[%d] Configuration failed\n", vp->id);
                        break;
                }
        }

        return rc;
}

static
ds90ux9xx_err_t reset_lane_configuration(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t page = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* TODO: clarify all operations with new revisions of TI datasheet */
        page = DS983_IND_PAGE_4;
        rc = ds90ux9xx_i2c_write_ind_1b(dev, page, 0x30, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x4C, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x50, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x56, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xB0, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xCC, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xD0, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xD6, 0);

        page = DS983_IND_PAGE_5;
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x30, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x4C, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x50, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0x56, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xB0, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xCC, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xD0, 0);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, 0xD6, 0);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to reset lane configuration. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
bool is_link_training_done(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint32_t apb_dpcd_lane01_status = 0;
        uint32_t apb_dpcd_lane23_status = 0;
        uint32_t apb_dpcd_link_bw_set = 0;
        uint32_t apb_dpcd_lane_count_set = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return false;
        }

        rc = ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_DPCD_LANE01_STATUS,
                                    &apb_dpcd_lane01_status);
        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_DPCD_LANE23_STATUS,
                                     &apb_dpcd_lane23_status);
        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_DPCD_LINK_BW_SET,
                                     &apb_dpcd_link_bw_set);
        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_DPCD_LANE_COUNT_SET,
                                     &apb_dpcd_lane_count_set);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to get lane status. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return false;
        }

        log_dbg("APB DPCD LANE 01 STATUS: 0x%x\n", apb_dpcd_lane01_status);
        log_dbg("APB DPCD LANE 23 STATUS: 0x%x\n", apb_dpcd_lane23_status);
        log_dbg("APB DPCD LINK BW SET   : 0x%x\n", apb_dpcd_link_bw_set);
        log_dbg("APB DPCD LANE COUNT SET: 0x%x\n", apb_dpcd_lane_count_set);

        if (DS983_APB_DCPD_LANE01_STATUS_LOCKED == apb_dpcd_lane01_status &&
            DS983_APB_DCPD_LANE23_STATUS_LOCKED == apb_dpcd_lane23_status) {
                log_info("Lanes [0, 1, 2, 3] are locked\n");

                return true;
        }

        return false;
}

static
ds90ux9xx_err_t start_link_training(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_LINK_ENABLE,
                                     DS983_APB_LINK_DISABLE);
        rc |= ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_MAX_LINK_RATE,
                                      DS983_APB_MAX_LINK_RATE);
        rc |= ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_MAX_LANE_COUNT,
                                      DS983_APB_MAX_LANE_COUNT);
        rc |= ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_MIN_VOLTAGE_SWING,
                                      DS983_APB_MIN_VOLTAGE_SWING);

        rc |= reset_lane_configuration(dev);

        rc |= ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_LINE_RESET,
                                      DS983_APB_LINE_RESET_VS0);
        rc |= ds90ux9xx_i2c_apb_write(dev, DS983_APB_REG_LINK_ENABLE,
                                      DS983_APB_LINK_ENABLE);

        return rc;
}

static
ds90ux9xx_err_t try_link_training(const ds90ux9xx_st_t *dev, bool *locked,
        int tries)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int i = 0;

        if (NULL == dev || NULL == locked) {
                log_err("Invalid input: dev = %p, locked = %p\n", dev, locked);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = start_link_training(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to start link training. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        for (i = 0; i < tries; i++) {
                ds_usleep(DS983_LT_RESULT_WAIT_TIME_US);

                log_dbg("Link training results obtaining. Attempt: %d\n", i);

                *locked = is_link_training_done(dev);
                if (true == *locked) {
                        log_dbg("Link training done. Lock: %d\n", *locked);

                        break;
                }
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh983_link_training(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        bool locked = false;
        int i = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (i = 0; i < DS983_LT_MAX_TRIES && false == locked; i++) {
                rc = try_link_training(dev, &locked, DS983_LT_LOCK_CHECK_TRIES);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Link training failed. Error: %s\n",
                                ds90ux9xx_err2str(rc));

                        return rc;
                }
        }

        if (false == locked) {
                log_err("Link training failed. Lock = %d\n", locked);
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t video_subsystem_configure(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = bridge_preconfiguration(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Common bridge pre-configuration FAILED\n");

                return rc;
        }

        rc = vp_disable_all(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't disable VP\n");

                return rc;
        }

        rc = start_link_training(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to start link training\n");

                return rc;
        }

        rc = vp_subsystem_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init VP subsystem\n");

                return rc;
        }

        rc = backward_channel_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't initialize backward channel: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = pll_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init PLL\n");

                return rc;
        }

        rc = fpd_ports_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't initialize fpd port: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        log_dbg("FPD ports init done\n");

        rc = bridge_reset(dev, DS983_RESET_NO_REGS);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't do soft reset (no regs)\n");

                return rc;
        }

        ds_usleep(dev->init_time_us);

        rc = timeslots_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init timeslots\n");

                return rc;
        }

        rc = vp_enable_all(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't enable VPs\n");

                return rc;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        /* Start initialization from PORT 0 */
        rc = set_tx_port(dev, PORT_0);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set port 0 to configure the bridge\n");

                return rc;
        }

        rc = video_subsystem_configure(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't configure bridge video subsystem\n");

                return rc;
        }

        rc = common_settings(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Common settings have been failed: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = dev_id_map(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map i2c dev id failed error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = master_i2c_port_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Master i2c routing failed: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh983_deinit_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = unmap_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Unmap i2c dev id failed\n");
        }

        /* Mark all slave states with FREE, so their corresponding registers
         * will be available for the new mapping on device init
         */
        memset(ds90uh983_slave_ctrl.state,
               FREE,
               DS983_I2C_SLAVE_COUNT * ARRAY_SIZE(ds90uh983_slave_ctrl.state));

        return rc;
}

ds90ux9xx_err_t ds90uh983_reset_device(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int mode = DS983_RESET_NORMAL_OPERATION;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (INITIAL_RESET == reset_mode) {
                mode = DS983_RESET_WITH_REGS;
        }

        rc = bridge_reset(dev, mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge reset failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_validate_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = validate_ds90uh983(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge validation failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_clk_status(ds90ux9xx_st_t *dev,
        ds_clk_status_st_t *clk_status)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t value = 0;

        if (NULL == dev || NULL == clk_status) {
                log_err("Invalid input: dev = %p, clk_status = %p\n", dev,
                        clk_status);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_GEN_STATUS2, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get CLK status. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        clk_status->pll_clk = !!(value & DS983_PLL_REFCLK_VALID);
        clk_status->ext_clk = !!(value & DS983_XO_REFCLK_VALID);

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_fpd_link(ds90ux9xx_st_t *dev,
        ds_fpd_link_st_t *fpd_link)
{
        uint8_t val;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == fpd_link) {
                log_err("Invalid input: dev = %p, fpd_link = %p\n", dev,
                        fpd_link);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_GEN_STATUS, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read link status: %s\n", ds90ux9xx_err2str(rc));

                return rc;
        }

        if (true == !!(val & DS983_LINK_DETECT)) {
                fpd_link->detect = DS_DETECTED;
        } else {
                fpd_link->detect = DS_NOT_DETECTED;
        }

        if (true == !!(val & DS983_BC_CRC_ERROR)) {
                fpd_link->bc_crc_error = DS_ERROR_DETECTED;
        } else {
                fpd_link->bc_crc_error = DS_ERROR_NOT_DETECTED;
        }

        if (true == !!(val & DS983_BIST_CRC_ERROR)) {
                fpd_link->bist_crc_error = DS_ERROR_DETECTED;
        } else {
                fpd_link->bist_crc_error = DS_ERROR_NOT_DETECTED;
        }

        if (true == !!(val & DS983_LINK_LOST)) {
                fpd_link->lost = DS_DETECTED;
        } else {
                fpd_link->lost = DS_NOT_DETECTED;
        }

        if (true == !!(val & DS983_TX_LOCK_DETECT)) {
                fpd_link->tx_lock = DS_LOCKED;
        } else {
                fpd_link->tx_lock = DS_NOT_LOCKED;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_set_pass_through(ds90ux9xx_st_t *dev, state_t state)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (DISABLE == state) {
                return pass_through_disable(dev);
        } else {
                return pass_through_enable(dev);
        }
}

ds90ux9xx_err_t ds90uh983_get_vp_status(ds90ux9xx_st_t *dev,
        vp_data_st_t *vp_data)
{
        uint8_t val;
        uint8_t sts_reg = 0;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == vp_data) {
                log_err("Invalid input: dev = %p, vp_data = %p\n", dev,
                        vp_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        sts_reg = TO_VP_REG(DS983_IND_REG_VP_STS, vp_data->vp.id);

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_VP_ENABLE_REG, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read VP state. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (val & BIT(vp_data->vp.id)) {
                vp_data->vp.state = ENABLE;
        } else {
                vp_data->vp.state = DISABLE;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_12, sts_reg,
                                       &vp_data->extended_status);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read VP extended status. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_VP_GLOBAL_STS_REG, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read DVP_GLOBAL_STS register. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        vp_data->vp.timing_sync = !!(val & BIT(vp_data->vp.id));

        rc = vp_get_resolution(dev, &vp_data->vp);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to get vp %d resolution. Error: %s\n",
                        vp_data->vp.id, ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t get_phy_resolution(ds90ux9xx_st_t *dev,
        dphy_data_st_t *dphy_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds90ux9xx_video_resolution_st_t *resolution = NULL;
        uint32_t h_start = 0;
        uint32_t v_start = 0;
        uint32_t reg_value = 0;

        if (NULL == dev || NULL == dphy_data) {
                log_err("Invalid input: dev = %p, dphy_data = %p\n", dev,
                        dphy_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (PORT_0 != dphy_data->port) {
                log_dbg("Port doesn't supported: dphy_data->port = %d\n",
                        dphy_data->port);

                return DS90UX9XX_SUCCESS;
        }

        resolution = &dphy_data->resolution;

        rc = ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_HRES, &reg_value);
        resolution->h_active = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_HSPOL, &reg_value);
        resolution->h_sync_active_low = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_HSWIDTH,
                                     &reg_value);
        resolution->h_pulse_width = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_HSTART, &h_start);

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_HTOTAL, &reg_value);
        resolution->h_total = reg_value;

        resolution->h_back_porch = h_start - resolution->h_pulse_width;
        resolution->h_front_porch = resolution->h_total - h_start -
                                    resolution->h_active;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_VRES, &reg_value);
        resolution->v_active = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_VSPOL, &reg_value);
        resolution->v_sync_active_low = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_VSWIDTH,
                                     &reg_value);
        resolution->v_pulse_width = reg_value;

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_VSTART, &v_start);

        rc |= ds90ux9xx_i2c_apb_read(dev, DS983_APB_REG_MSA_VTOTAL, &reg_value);
        resolution->v_total = reg_value;

        resolution->v_back_porch = v_start - resolution->v_pulse_width;
        resolution->v_front_porch = resolution->v_total - v_start -
                                    resolution->v_active;

        log_dbg("H active      : %u\n"
                "H active low  : %u\n"
                "H back porch  : %u\n"
                "H front porch : %u\n"
                "H pulse width : %u\n"
                "H total       : %u\n"
                "V active      : %u\n"
                "V active low  : %u\n"
                "V back porch  : %u\n"
                "V front porch : %u\n"
                "V pulse width : %u\n"
                "V total       : %u\n",
                dphy_data->resolution.h_active,
                dphy_data->resolution.h_sync_active_low,
                dphy_data->resolution.h_back_porch,
                dphy_data->resolution.h_front_porch,
                dphy_data->resolution.h_pulse_width,
                dphy_data->resolution.h_total,
                dphy_data->resolution.v_active,
                dphy_data->resolution.v_sync_active_low,
                dphy_data->resolution.v_back_porch,
                dphy_data->resolution.v_front_porch,
                dphy_data->resolution.v_pulse_width,
                dphy_data->resolution.v_total);

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read PHY resolution: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_phy(ds90ux9xx_st_t *dev,
        dphy_data_st_t *dphy_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == dphy_data) {
                log_err("Invalid input: dev = %p, dphy_data = %p\n", dev,
                        dphy_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dphy_data->status = false;

        if (PORT_0 != dphy_data->port) {
                log_dbg("Port doesn't supported: dphy_data->port = %d\n",
                        dphy_data->port);

                return DS90UX9XX_SUCCESS;
        }

        rc = get_phy_resolution(dev, dphy_data);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read resolution. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (dphy_data->resolution.h_active > 0 &&
            dphy_data->resolution.v_active > 0) {
                log_dbg("PHY status on the port %d is active: "
                        "h_active = %d, v_active = %d\n",
                        dphy_data->resolution.h_active,
                        dphy_data->resolution.v_active);

                dphy_data->status = true;
        }

        return rc;
}

static
ds90ux9xx_err_t get_lane_cnt_by_port(const ds90ux9xx_st_t *dev,
        ds_phy_port_t port, uint8_t *lane_cnt)
{
        uint8_t port_cnt = 0;
        ds_io_phy_port_settings_st_t *phy_port_settings = NULL;

        if (NULL == dev || NULL == lane_cnt) {
                log_err("Invalid input: dev = %p, lane_cnt = %p\n", dev,
                        lane_cnt);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        phy_port_settings = dev->video_settings.io_phy_settings.port_settings;
        if (NULL == phy_port_settings) {
                log_err("Invalid input: io_phy_settings.port_settings = %p\n",
                        phy_port_settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        port_cnt = dev->video_settings.io_phy_settings.port_cnt;
        if (port_cnt > DS983_MAX_PHY_PORTS) {
                log_err("Invalid port count = %d. Supported: %d\n", port_cnt,
                        DS983_MAX_PHY_PORTS);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        for (int i = 0; i < port_cnt; i++) {
                if (phy_port_settings[i].port == port) {
                        *lane_cnt = phy_port_settings[i].lanes;

                        log_dbg("Obtained port_%d, lane count: %d\n", port,
                                *lane_cnt);

                        return DS90UX9XX_SUCCESS;
                }
        }

        log_err("No data for port_%d specified\n", port);

        return DS90UX9XX_INVALID_PARAMETER;
}

ds90ux9xx_err_t ds90uh983_set_dp_lanes_polarity(const ds90ux9xx_st_t *dev,
        const dphy_data_st_t *dphy_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t page = 0;
        uint8_t reg = 0;
        uint8_t value = 0;
        uint8_t lane_cnt = 0;

        if (NULL == dev || NULL == dphy_data) {
                log_err("Invalid input: dev = %p, dphy_data = %p\n", dev,
                        dphy_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_lane_cnt_by_port(dev, PHY_PORT_0, &lane_cnt);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Lane count by port obtained failed: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        for (int lane = 0; lane < lane_cnt; lane++) {
                switch (lane) {
                case 0:
                        page = DS983_IND_PAGE_4;
                        reg = DS983_IND_REG_DP_LN0_2_POL;

                        break;
                case 1:
                        page = DS983_IND_PAGE_4;
                        reg = DS983_IND_REG_DP_LN1_3_POL;

                        break;
                case 2:
                        page = DS983_IND_PAGE_5;
                        reg = DS983_IND_REG_DP_LN0_2_POL;

                        break;
                case 3:
                        page = DS983_IND_PAGE_5;
                        reg = DS983_IND_REG_DP_LN1_3_POL;

                        break;
                default:
                        log_err("Unsupported lane count: %d\n", lane);

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                value = !!(dphy_data->lane_inversion & BIT(lane));
                rc |= ds90ux9xx_i2c_write_ind_1b(dev, page, reg, value);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set DP lanes polarity. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return rc;
}

static
ds90ux9xx_err_t validate_ind_page(uint8_t page)
{
        if (page <= DS983_IND_PAGE_MAX) {
                return DS90UX9XX_SUCCESS;
        }

        return DS90UX9XX_INVALID_PARAMETER;
}

static
ds90ux9xx_err_t ds90uh983_write_reg(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == reg_data) {
                log_err("Invalid input: dev = %p, reg_data = %p\n", dev,
                        reg_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Write: type=%d, page=%d, reg=0x%x, value=0x%x\n", dev->name,
                reg_data->type, reg_data->page, reg_data->reg, reg_data->value);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                rc = ds90ux9xx_i2c_write(dev, reg_data->reg, reg_data->value);
                break;
        case DS9XX_APB:
                rc = ds90ux9xx_i2c_apb_write(dev, reg_data->reg,
                                             reg_data->value);
                break;
        case DS9XX_IND:
                rc = ds90ux9xx_i2c_write_ind_1b(dev,
                                                TO_IND_PAGE(reg_data->page),
                                                reg_data->reg,
                                                reg_data->value);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_read_reg(const ds90ux9xx_st_t *dev,
        ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == reg_data) {
                log_err("Invalid input: dev = %p, reg_data = %p\n", dev,
                        reg_data);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s request read: type=%d, page=%d, reg=0x%x\n", dev->name,
                reg_data->type, reg_data->page, reg_data->reg);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                if (reg_data->reg > MAX_MAIN_PAGE_REGISTER) {
                        log_err("Requested reg is out of range\n");

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                rc = ds90ux9xx_i2c_read(dev, reg_data->reg,
                                        (uint8_t *)&reg_data->value);
                break;
        case DS9XX_APB:
                rc = ds90ux9xx_i2c_apb_read(dev, reg_data->reg,
                                            &reg_data->value);
                break;
        case DS9XX_IND:
                rc = ds90ux9xx_i2c_read_ind_1b(dev,
                                               TO_IND_PAGE(reg_data->page),
                                               reg_data->reg,
                                               (uint8_t *)&reg_data->value);
                break;
        default:
                log_dbg("Unsupported type\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Read: type %d; reg 0x%x = 0x%x\n", dev->name,
                reg_data->type, reg_data->reg, reg_data->value);

        return rc;
}

static
ds90ux9xx_err_t set_bist_disable(const ds90ux9xx_st_t *dev,
        uint8_t tx_bist_ctl_val)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = tx_bist_ctl_val & ~DS983_BIST_ENABLE;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_TX_BIST_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS983_REG_TX_BIST_CTL, val);

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_TX_BIST_CTL, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x\n", DS983_REG_TX_BIST_CTL);

                return rc;
        }

        if (val & DS983_BIST_ENABLE) {
                log_dbg("BIST can't be disabled on 983 bridge\n");
        } else {
                log_dbg("BIST has been disabled on 983 bridge\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_bist_enable(const ds90ux9xx_st_t *dev,
        uint8_t tx_bist_ctl_val)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = tx_bist_ctl_val | DS983_BIST_ENABLE;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_TX_BIST_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS983_REG_TX_BIST_CTL, val);

                return rc;
        }

        log_dbg("BIST has been enabled by 983 bridge\n");

        return reset_crc_errors(dev);
}

ds90ux9xx_err_t ds90uh983_set_bist_state(const ds90ux9xx_st_t *dev,
        state_t bist_state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_INVALID_PARAMETER;
        uint8_t val = 0;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_TX_BIST_CTL, &val);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't read 0x%x\n", DS983_REG_TX_BIST_CTL);

                return rc;
        }

        if (ENABLE == bist_state) {
                rc = set_bist_enable(dev, val);
        } else if (DISABLE == bist_state) {
                rc = set_bist_disable(dev, val);
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_bist_result(ds90ux9xx_st_t *dev,
        bist_result_st_t *bist_result)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == bist_result) {
                log_err("Invalid input: dev = %p, bist_result = %p\n",
                        dev, bist_result);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_BIST_BC_ERRORS,
                                &bist_result->bist_err_count);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't read 0x%x\n", DS983_REG_BIST_BC_ERRORS);

                return rc;
        }

        bist_result->bist_err_count_is_avaliable = 1;

        return rc;
}

static
ds90ux9xx_err_t process_set_fpd_link_version(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_tx_port(dev, PORT_0);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set port 0 to configure the bridge\n");

                return rc;
        }

        rc = video_subsystem_configure(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't re-configure video subsystem\n");

                return rc;
        }

        rc = common_settings(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Common settings have been failed: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh983_set_fpd_link_version(ds90ux9xx_st_t *dev,
        const uint8_t fpd_link_version)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (fpd_link_version) {
        case FPD_4:
                dev->settings.backward_compatibility = DISABLE;
                break;
        case FPD_3:
                dev->settings.backward_compatibility = ENABLE;
                break;
        default:
                log_err("Wrong input: %d\n", fpd_link_version);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("Set fpd_link_version: %d\n", fpd_link_version);
        log_dbg("backward_compatibility: %d\n",
                dev->settings.backward_compatibility);

        return process_set_fpd_link_version(dev);
}

ds90ux9xx_err_t ds90uh983_get_bridge_revision(ds90ux9xx_st_t *dev,
        ds90ux9xx_revision_t *bridge_revision)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev || NULL == bridge_revision) {
                log_err("Invalid input: dev = %p, bridge_revision = %p\n", dev,
                        bridge_revision);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_CHIP_REV, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read DS983_REG_CHIP_REV register\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *bridge_revision = TO_DS983_REVISION(val);

        log_dbg("Bridge revision: 0x%x\n", *bridge_revision);

        return rc;
}

static
ds90ux9xx_err_t get_fc_crc_error(ds90ux9xx_st_t *dev,
        ds_crc_error_st_t *crc_error)
{
        uint8_t value = 0;
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == crc_error) {
                log_err("Invalid input: dev = %p, crc_error = %p\n", dev,
                        crc_error);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_CRC_ERROR0, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read CRC_ERROR register. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        crc_error->errors_cnt = value;

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_CRC_ERROR1, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read CRC_ERROR register. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        crc_error->errors_cnt |= TO_SECOND_BYTE(value);

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_crc_error(ds90ux9xx_st_t *dev,
        ds_crc_error_st_t *crc_error)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == crc_error) {
                log_err("Invalid input: dev = %p, crc_error = %p\n", dev,
                        crc_error);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (crc_error->type) {
        case FORWARD_CHANNEL:
                rc = get_fc_crc_error(dev, crc_error);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Failed to get forward crc error. Error %s\n",
                                ds90ux9xx_err2str(rc));

                        break;
                }

                log_dbg("Forward crc error readed: errors_count %d\n",
                        crc_error->errors_cnt);

                break;
        default:
                log_err("Unsupported crc error type %d\n", crc_error->type);

                rc = DS90UX9XX_NOT_SUPPORTED;

                break;
        }

        return rc;
}

static inline
int32_t convert_temperature(uint32_t reg_val)
{
        return ((ADC_TEMPERATURE_RESOLUTION * reg_val) -
                WATER_FREEZING_TEMPERATURE_KELVIN);
}

ds90ux9xx_err_t ds90uh983_get_temperature(ds90ux9xx_st_t *dev,
        int32_t *temperature)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint32_t adc_temperature = 0;

        if (NULL == dev || NULL == temperature) {
                log_err("Invalid input: dev = %p, temperature = %p\n", dev,
                        temperature);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90uh983_adc_get_temperature(dev, &adc_temperature);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read ADC temperature. Error %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *temperature = convert_temperature(adc_temperature);

        log_dbg("Temperature readed: %d\n", *temperature);

        return rc;
}

ds90ux9xx_err_t library_deinit(ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        ds90ux9xx_global_interrupts_deinit(dev);

        pthread_mutex_destroy(&dev->i2c_ind_ctl.mutex);
        pthread_mutex_destroy(&dev->i2c_apb_ctl.mutex);
        pthread_mutex_destroy(&ds90uh983_slave_ctrl.i2c_state_lock);

        ds90ux9xx_logger_deinit();

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t library_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        indirect_i2c_st_t ind_control = {
                .ctrl_reg      = DS983_REG_IND_CTL,
                .addr_reg      = DS983_REG_IND_ADDR,
                .data_reg      = DS983_REG_IND_DATA,
                .auto_inc      = DS983_IND_AUTO_INC,
                .read_enable   = DS983_IND_READ,
                .validate_page = validate_ind_page
        };

        apb_i2c_st_t apb_control = {
                .ctrl_reg     = DS983_REG_APB_CTL,
                .addr0_reg    = DS983_REG_APB_ADDR0,
                .addr1_reg    = DS983_REG_APB_ADDR1,
                .data0_reg    = DS983_REG_APB_DATA0,
                .data1_reg    = DS983_REG_APB_DATA1,
                .data2_reg    = DS983_REG_APB_DATA2,
                .data3_reg    = DS983_REG_APB_DATA3,
                .read_enable  = DS983_APB_ENABLE | DS983_APB_READ,
                .write_enable = DS983_APB_ENABLE,
                .apb_port     = DS983_APB_PORT0
        };

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->ops.lib_deinit = (operation_fp_t)library_deinit;

        rc = ds90ux9xx_logger_init(dev->bridge_type);
        if (DS90UX9XX_SUCCESS != rc) {
                return DS90UX9XX_INIT_FAILURE;
        }

        rc = init_bridge_limits(&dev->bridge_limits);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to init bridge limits. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        dev->video_settings.vp_count = DS983_MAX_VP_COUNT;

        rc = ds90ux9xx_init_indirect_api(dev, &ind_control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init Idirect Access API\n");
                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        rc = ds90ux9xx_init_apb(dev, &apb_control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init APB API\n");
                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        rc = ds90uh983_global_interrupts_init(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't init IRQ structs\n");
                ds90ux9xx_global_interrupts_deinit(dev);
                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        rc = init_generic_operations(&dev->ops);
        if (DS90UX9XX_SUCCESS != rc || false == dev->ops.is_initialized) {
                log_err("Can't init bridge operations. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        dev->ops.device[DEINIT_DEVICE] =
                (operation_fp_t)ds90uh983_deinit_device;
        dev->ops.device[GET_BRIDGE_REVISION] =
                (operation_fp_t)ds90uh983_get_bridge_revision;
        dev->ops.device[INIT_DEVICE] =
                (operation_fp_t)ds90uh983_init;
        dev->ops.device[RESET_DEVICE] =
                (operation_fp_t)ds90uh983_reset_device;
        dev->ops.device[VALIDATE_DEVICE] =
                (operation_fp_t)ds90uh983_validate_device;

        dev->ops.adc[GET_FPD_LINE_STATUS] =
                (operation_fp_t)ds90uh983_get_fpd_line_status;
        dev->ops.adc[GET_TEMPERATURE] =
                (operation_fp_t)ds90uh983_get_temperature;

        dev->ops.bist[GET_BIST_RESULT] =
                (operation_fp_t)ds90uh983_get_bist_result;
        dev->ops.bist[SET_BIST_STATE] =
                (operation_fp_t)ds90uh983_set_bist_state;

        dev->ops.dphy[GET_PHY] =
                (operation_fp_t)ds90uh983_get_phy;
        dev->ops.dphy[GET_CLK_STATUS] =
                (operation_fp_t)ds90uh983_get_clk_status;

        dev->ops.dphy[LINK_TRAINING] =
                (operation_fp_t)ds90uh983_link_training;
        dev->ops.dphy[SET_DP_LANES_POLARITY] =
                (operation_fp_t)ds90uh983_set_dp_lanes_polarity;

        dev->ops.fpd[GET_CRC_ERROR] =
                (operation_fp_t)ds90uh983_get_crc_error;
        dev->ops.fpd[GET_FPD_MODE] =
                (operation_fp_t)ds90uh983_get_fpd_mode;
        dev->ops.fpd[GET_FPD_LINK] =
                (operation_fp_t)ds90uh983_get_fpd_link;
        dev->ops.fpd[GET_TX_PORT] =
                (operation_fp_t)ds90uh983_get_tx_port;
        dev->ops.fpd[SET_FPD_LINK_VERSION] =
                (operation_fp_t)ds90uh983_set_fpd_link_version;
        dev->ops.fpd[SET_FPD_MODE] =
                (operation_fp_t)ds90uh983_set_fpd_mode;
        dev->ops.fpd[SET_TX_PORT] =
                (operation_fp_t)ds90uh983_set_tx_port;

        dev->ops.gpio[SET_GPIO] =
                (operation_fp_t)ds90uh983_set_gpio;
        dev->ops.gpio[GET_GPIO] =
                (operation_fp_t)ds90uh983_get_gpio;

        dev->ops.i2c[READ_REGISTER] =
                (operation_fp_t)ds90uh983_read_reg;
        dev->ops.i2c[GET_REMOTE_ID] =
                (operation_fp_t)ds90uh983_get_des_id;
        dev->ops.i2c[MAP_I2C_SLAVE] =
                (operation_fp_t)ds90uh983_map_fpd_i2c_slave;
        dev->ops.i2c[SET_PASS_THROUGH] =
                (operation_fp_t)ds90uh983_set_pass_through;
        dev->ops.i2c[WRITE_REGISTER] =
                (operation_fp_t)ds90uh983_write_reg;

        dev->ops.irq[GET_IRQ] =
                (operation_fp_t)ds90uh983_get_irq;
        dev->ops.irq[SET_IRQ] =
                (operation_fp_t)ds90uh983_set_irq;

        dev->ops.video[GET_VP_STATUS] =
                (operation_fp_t)ds90uh983_get_vp_status;
        dev->ops.video[SET_VP_STATE] =
                (operation_fp_t)ds90uh983_vp_configure;

        log_dbg("Initialized successfully\n");

        return rc;

init_failed:
        ds90ux9xx_logger_deinit();

        return rc;
}

