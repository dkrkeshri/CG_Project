/**
 * @file       ds90uh983-adc.c
 * @brief      ds90uh983 ADC settings API
 *
 * @author     Serhii Bura <external.serhii.bura@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90uh983-adc-mock.h"
#include "UT-ds90uh983-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh983.h"
#include "ds90uh983-adc.h"
#include "ds90uh983-adc-internal.h"
#endif /* UNITTEST */

static
ds90ux9xx_err_t adc_write_settings(ds90ux9xx_st_t *dev,
        adc_settings_st_t *settings)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == settings) {
                log_err("Invalid input: dev = %p, settings = %p\n",
                        dev, settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_14,
                                         DS983_IND_REG_SAR_ADC_SETTINGS,
                                         settings->adc_enable);
        rc |= ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_14,
                                         DS983_IND_REG_SAR_ADC_CLK_DIV_SEL,
                                         settings->clk);
        rc |= ds90ux9xx_i2c_write_ind_2b(dev, DS983_IND_PAGE_14,
                                         DS983_IND_REG_SAR_ADC_INPUT_EN_LSB,
                                         settings->input_enable);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup SAR ADC. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t adc_read_settings(ds90ux9xx_st_t *dev,
        adc_settings_st_t *settings)
{
        if (NULL == dev || NULL == settings) {
                log_err("Invalid input: dev = %p, settings = %p\n",
                        dev, settings);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_14,
                                        DS983_IND_REG_SAR_ADC_SETTINGS,
                                        &settings->adc_enable);
        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_14,
                                        DS983_IND_REG_SAR_ADC_CLK_DIV_SEL,
                                        &settings->clk);
        rc |= ds90ux9xx_i2c_read_ind_2b(dev, DS983_IND_PAGE_14,
                                        DS983_IND_REG_SAR_ADC_INPUT_EN_LSB,
                                        &settings->input_enable);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds90ux9xx_err_t adc_enable_input(ds90ux9xx_st_t *dev, adc_type_t adc_type)
{
        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        adc_settings_st_t adc_settings = {
                .adc_enable   = DS90UH983_ADC_ENABLE,
                .clk          = DS90UH983_ADC_CLK_DIVIDER_8_33_HZ |
                                DS90UH983_ADC_CLK_AVG_4_SAMPLES,
                .input_enable = (uint16_t)adc_type
        };

        rc = adc_write_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup SAR ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        ds_usleep(DS90UH983_ADC_INIT_TIME_2MS);

        return rc;
}

static
ds90ux9xx_err_t adc_read_temperature(ds90ux9xx_st_t *dev, uint32_t *temperature)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t value = 0;

        if (NULL == dev || NULL == temperature) {
                log_err("Invalid input: dev = %p, temperature = %p\n",
                        dev, temperature);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_14,
                                       DS983_IND_REG_TEMP_FINAL, &value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read temperature. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        *temperature = value;

        log_dbg("ADC temperature readed: %u\n", *temperature);

        return rc;
}

ds90ux9xx_err_t ds90uh983_adc_get_temperature(ds90ux9xx_st_t *dev,
        uint32_t *temperature)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        adc_settings_st_t adc_settings = {0};

        if (NULL == dev || NULL == temperature) {
                log_err("Invalid input: dev = %p, temperature = %p\n",
                        dev, temperature);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = adc_read_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to save ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = adc_enable_input(dev, TEMPERATURE);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup ADC. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                goto restore_settings;
        }

        rc = adc_read_temperature(dev, temperature);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read temperature. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

restore_settings:
        rc |= adc_write_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to restore ADC settings. Error: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
adc_type_t fpd_line_to_adc_type(ds_fpd_line_t line)
{
        switch (line) {
        case DS_LINE_0:
                return LINE_FAULT_0;
        case DS_LINE_1:
                return LINE_FAULT_1;
        case DS_LINE_2:
                return LINE_FAULT_2;
        case DS_LINE_3:
                return LINE_FAULT_3;
        default:
                log_err("Invalid input: %d\n", line);

                return INVALID_ADC_TYPE;
        }
}

static
ds90ux9xx_err_t fpd_port_to_lines(fpd_port_t port, ds_fpd_line_t *positive,
        ds_fpd_line_t *negative)
{
        if (NULL == positive || NULL == negative) {
                log_err("Invalid input: positive = %p, negative = %p\n",
                        positive, negative);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (port) {
        case PORT_0:
                *positive = DS_LINE_0;
                *negative = DS_LINE_1;

                break;
        case PORT_1:
                *positive = DS_LINE_2;
                *negative = DS_LINE_3;

                break;
        default:
                log_err("Invalid input: port = %d\n", port);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t read_line_status_value(ds90ux9xx_st_t *dev, ds_fpd_line_t line,
        uint8_t *value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = 0;

        if (NULL == dev || NULL == value) {
                log_err("Invalid input: dev = %p, value = %p\n", dev, value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (line) {
        case DS_LINE_0:
                reg = DS983_IND_REG_LINE_FAULT0_FINAL;

                break;
        case DS_LINE_1:
                reg = DS983_IND_REG_LINE_FAULT1_FINAL;

                break;
        case DS_LINE_2:
                reg = DS983_IND_REG_LINE_FAULT2_FINAL;

                break;
        case DS_LINE_3:
                reg = DS983_IND_REG_LINE_FAULT3_FINAL;

                break;
        default:
                log_err("Invalid input: line = %d\n", line);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_14, reg, value);

        return rc;
}

static
ds90ux9xx_err_t get_line_status_value(ds90ux9xx_st_t *dev, ds_fpd_line_t line,
        uint8_t *line_adc_value)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        adc_settings_st_t adc_settings = {0};
        adc_type_t adc_type;

        if (NULL == dev || NULL == line_adc_value) {
                log_err("Invalid input: dev = %p, line_adc_value = %p\n",
                        dev, line_adc_value);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        adc_type = fpd_line_to_adc_type(line);
        if (INVALID_ADC_TYPE == adc_type) {
                log_err("Invalid input: line = %d\n", line);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = adc_read_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to save ADC settings: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = adc_enable_input(dev, line);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to setup ADC: %s\n", ds90ux9xx_err2str(rc));

                goto restore_settings;
        }

        rc = read_line_status_value(dev, line, line_adc_value);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read line fault thresholds: %s\n",
                        ds90ux9xx_err2str(rc));

                goto restore_settings;
        }

restore_settings:
        rc |= adc_write_settings(dev, &adc_settings);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to restore ADC settings: %s\n",
                        ds90ux9xx_err2str(rc));
        }

        return rc;
}

static
ds_line_status_t to_positive_line_status(uint8_t value)
{
        log_dbg("value = 0x%x\n", value);

        if (DS983_LINE_N_NORMAL_OPERATION_LOW <= value &&
            value <= DS983_LINE_P_NORMAL_OPERATION_MAX) {
                log_dbg("Lane status: NORMAL_OPERATION\n");

                return NORMAL_OPERATION;
        }

        if (DS983_LINE_P_SHORT_EACH_OTHER_MIN <= value &&
            value <= DS983_LINE_P_SHORT_EACH_OTHER_MAX) {
                log_dbg("Lane status: SHORT_TO_EACH_OTHER\n");

                return SHORT_TO_EACH_OTHER;
        }

        if (DS983_LINE_P_SHORT_GND_MIN <= value &&
            value <= DS983_LINE_P_SHORT_GND_MAX) {
                log_dbg("Lane status: SHORT_TO_GROUND\n");

                return SHORT_TO_GROUND;
        }

        if (value <= DS983_LINE_P_UNKNOWN_MAX) {
                log_dbg("Lane status: UNDEFINED\n");

                return UNDEFINED;
        }

        log_dbg("Lane status: UNDEFINED\n");

        return UNDEFINED;
}

static
ds_line_status_t to_negative_line_status(uint8_t value)
{
        log_dbg("value = 0x%x\n", value);

        if (DS983_LINE_N_SHORT_1P8_MIN <= value &&
            value <= DS983_LINE_N_SHORT_1P8_MAX) {
                log_dbg("Lane status: SHORT_TO_1p8V\n");

                return SHORT_TO_1p8V;
        }

        if (value <= DS983_LINE_N_OPEN_MAX) {
                log_dbg("Lane status: OPEN\n");

                return OPEN;
        }

        log_dbg("Lane status: UNDEFINED\n");

        return UNDEFINED;
}

ds90ux9xx_err_t ds90uh983_get_fpd_line_status(ds90ux9xx_st_t *dev,
        fpd_port_t port, ds_line_status_t *line_status)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        ds_fpd_line_t positive;
        ds_fpd_line_t negative;
        uint8_t positive_line_adc_val;
        uint8_t negative_line_adc_val;
        ds_line_status_t positive_status;
        ds_line_status_t negative_status;

        if (NULL == dev || NULL == line_status) {
                log_err("Invalid input: dev = %p, line_status = %p\n",
                        dev, line_status);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = fpd_port_to_lines(port, &positive, &negative);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't convert port to lines: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = get_line_status_value(dev, positive, &positive_line_adc_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get positive line status value: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        rc = get_line_status_value(dev, negative, &negative_line_adc_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't get negative line status value: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        positive_status = to_positive_line_status(positive_line_adc_val);
        log_dbg("Positive line status: %d\n", positive_line_adc_val);

        negative_status = to_negative_line_status(negative_line_adc_val);
        log_dbg("Negative line status: %d\n", negative_line_adc_val);

        /* ds90ux9xx-driver structure handle line status per port, not per line.
         * Because of this we need to accumulate faults from 2 lines into
         * one variable */
        if (NORMAL_OPERATION != positive_status) {
                *line_status = positive_status;
        } else {
                *line_status = negative_status;
        }

        return rc;
}
