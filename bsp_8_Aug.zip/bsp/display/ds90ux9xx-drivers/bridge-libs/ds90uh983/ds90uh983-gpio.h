/**
 * @file       ds90uh983-gpio.h
 * @brief      ds90uh983 GPIO settings API
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH983_GPIO_H__
#define __DS90UH983_GPIO_H__

#ifdef UNITTEST
#include "UT-ds90uh983-mock.h"
#else /* aarch64 */
#include "ds90uh983.h"
#endif /* UNITTEST */

ds90ux9xx_err_t ds90uh983_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);
ds90ux9xx_err_t ds90uh983_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio);

#endif /* __DS90UH983_GPIO_H__ */

