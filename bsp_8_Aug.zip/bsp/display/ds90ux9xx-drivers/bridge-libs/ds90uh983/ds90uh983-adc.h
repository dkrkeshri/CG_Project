/**
 * @file       ds90uh983-adc.h
 * @brief      ds90uh983 ADC settings API
 *
 * @author     Serhii Bura <external.serhii.bura@de.bosch.com>
 *
 * @copyright  (c) 2021 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH983_ADC_H__
#define __DS90UH983_ADC_H__

#ifdef UNITTEST
#include "UT-ds90ux9xx-bridge-libraries-mock.h"
#include "UT-ds90ux9xx-error-mock.h"
#else /* aarch64 */
#include "ds90ux9xx-bridge-libraries.h"
#include "ds90ux9xx-error.h"
#endif /* UNITTEST */

ds90ux9xx_err_t ds90uh983_adc_get_temperature(ds90ux9xx_st_t *dev,
        uint32_t *temperature);
ds90ux9xx_err_t ds90uh983_get_fpd_line_status(ds90ux9xx_st_t *dev,
        fpd_port_t port, ds_line_status_t *line_status);

#endif /*__DS90UH983_ADC_H__*/

