/**
 * @file       ds90uh983.h
 * @brief      ds90uh983 specific registers, configurations, sequences
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 * @author     Oleksandr Kholiavko <external.oleksandr.kholiavko@de.bosch.com>
 * @author     Leonid Chebenko <external.leonid.chebenko@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH983_H__
#define __DS90UH983_H__

#include "ds90ux9xx-core.h"

#ifdef UNITTEST
#include "UT-ds90ux9xx-i2c-mock.h"
#else /* aarch64 */
#include "ds90ux9xx-i2c.h"
#endif /* UNITTEST */

#define DEVICE_ID                           "_UH983"
#define DEVICE_ID_SIZE                      6
#define DS983_LT_LOCK_CHECK_TRIES           3
#define DS983_LT_MAX_TRIES                  5
#define DS983_LT_RESULT_WAIT_TIME_US        250
#define DS983_1_STREAM                      1
#define DS983_MAX_FPD_PORTS                 2
#define DS983_MAX_PHY_PORTS                 1
#define DS983_MAX_VP_COUNT                  4
#define DS983_MAX_VP_COUNT_FPD3             2
#define DS983_MAX_VCO_COUNT                 4
#define DS983_MAX_I2C_COUNT                 3
#define DS983_I2C_SLAVE_COUNT               8
#define DS983_MAX_LANES_CNT_PER_PORT        4

/* Main registers */
#define DS983_REG_I2C_DEV_ID                0x0
#define DS983_REG_RESET_CTL                 0x01
#define DS983_REG_GENERAL_CFG2              0x02
#define DS983_REG_FPD4_CFG                  0x05
#define DS983_REG_GEN_STATUS2               0x06
#define DS983_REG_GENERAL_CFG               0x07
#define DS983_REG_DES_ID                    0x08
#define DS983_REG_CRC_ERROR0                0x0A
#define DS983_REG_CRC_ERROR1                0x0B
#define DS983_REG_GEN_STATUS                0x0C
#define DS983_REG_FPD4_DATAPATH_CTL         0x0D
#define DS983_REG_BIST_BC_ERRORS            0x0F
#define DS983_REG_TX_BIST_CTL               0x14

#define DS983_REG_GPIO_FC_CTL0              0x15
#define DS983_REG_GPIO_FC_CTL1              0x16
#define DS983_REG_GPIO_0                    0x17
#define DS983_REG_GPIO_1                    0x18
#define DS983_REG_GPIO_2                    0x19
#define DS983_REG_GPIO_3                    0x1A
#define DS983_REG_GPIO_4                    0x1B
#define DS983_REG_GPIO_5                    0x1C
#define DS983_REG_GPIO_6                    0x1D
#define DS983_REG_GPIO_7                    0x1E
#define DS983_REG_GPIO_8                    0x1F
#define DS983_REG_GPIO_9                    0x20
#define DS983_REG_GPIO_10                   0x21
#define DS983_REG_GPIO_11                   0x22
#define DS983_REG_GPIO_12                   0x23
#define DS983_REG_GPIO_13                   0x24
#define DS983_REG_GPIO_STS1                 0x25
#define DS983_REG_GPIO_STS2                 0x26
#define DS983_REG_TX_PORT_SEL               0x2D

#define DS983_REG_CHIP_REV                  0x30
#define DS983_REG_I2C_MASTER_CHAIN_CTL1     0x38
#define DS983_REG_I2C_MASTER_CHAIN_CTL2     0x39
#define DS983_REG_GPIO_INPUT_ENABLE_HIGH    0x3E
#define DS983_REG_GPIO_INPUT_ENABLE_LOW     0x3F
#define DS983_REG_IND_CTL                   0x40
#define DS983_REG_IND_ADDR                  0x41
#define DS983_REG_IND_DATA                  0x42
#define DS983_REG_VP_CONFIG_REG             0x43
#define DS983_REG_VP_ENABLE_REG             0x44
#define DS983_REG_VP_GLOBAL_STS_REG         0x45
#define DS983_REG_VP_GLOBAL_ISR             0x46
#define DS983_REG_APB_CTL                   0x48
#define DS983_REG_APB_ADDR0                 0x49
#define DS983_REG_APB_ADDR1                 0x4A
#define DS983_REG_APB_DATA0                 0x4B
#define DS983_REG_APB_DATA1                 0x4C
#define DS983_REG_APB_DATA2                 0x4D
#define DS983_REG_APB_DATA3                 0x4E
#define DS983_REG_BRIDGE_CTL                0x4F
#define DS983_REG_INTERRUPT_CTL             0x51
#define DS983_REG_INTERRUPT_STS             0x52
#define DS983_FPD3_STREAM_SEL               0x57
#define DS983_REG_FPD3_MODE_CTL             0x59
#define DS983_REG_FPD3_FIFO_CFG             0x5B
#define DS983_REG_BC_DOWN_SAMPLING_RATE     0x6A
#define DS983_REG_DATAPATH_BC_FC            0x6E

#define DS983_REG_SLAVE_ID_0                0x70
#define DS983_REG_SLAVE_ID_1                0x71
#define DS983_REG_SLAVE_ID_2                0x72
#define DS983_REG_SLAVE_ID_3                0x73
#define DS983_REG_SLAVE_ID_4                0x74
#define DS983_REG_SLAVE_ID_5                0x75
#define DS983_REG_SLAVE_ID_6                0x76
#define DS983_REG_SLAVE_ID_7                0x77
#define DS983_REG_SLAVE_ALIAS_0             0x78
#define DS983_REG_SLAVE_ALIAS_1             0x79
#define DS983_REG_SLAVE_ALIAS_2             0x7A
#define DS983_REG_SLAVE_ALIAS_3             0x7B
#define DS983_REG_SLAVE_ALIAS_4             0x7C
#define DS983_REG_SLAVE_ALIAS_5             0x7D
#define DS983_REG_SLAVE_ALIAS_6             0x7E
#define DS983_REG_SLAVE_ALIAS_7             0x7F

#define DS983_REG_SLAVE_DEST_0              0x88
#define DS983_REG_SLAVE_DEST_1              0x89
#define DS983_REG_SLAVE_DEST_2              0x8A
#define DS983_REG_SLAVE_DEST_3              0x8B
#define DS983_REG_SLAVE_DEST_4              0x8C
#define DS983_REG_SLAVE_DEST_5              0x8D
#define DS983_REG_SLAVE_DEST_6              0x8E
#define DS983_REG_SLAVE_DEST_7              0x8F

#define DS983_REG_FPD3_ICR                  0xC6
#define DS983_REG_FPD3_ISR                  0xC7
#define DS983_REG_TX_ID                     0xF0

/* APB registers */
#define DS983_APB_REG_LINK_ENABLE           0x00
#define DS983_APB_REG_MAX_LANE_COUNT        0x70
#define DS983_APB_REG_MAX_LINK_RATE         0x74
#define DS983_APB_REG_MIN_VOLTAGE_SWING     0x214
#define DS983_APB_REG_MIN_PRE_EMPHASIS      0x218
#define DS983_APB_REG_DPCD_LINK_BW_SET      0x400
#define DS983_APB_REG_DPCD_LANE_COUNT_SET   0x404
#define DS983_APB_REG_DPCD_LANE01_STATUS    0x43C
#define DS983_APB_REG_DPCD_LANE23_STATUS    0x440
#define DS983_APB_REG_MSA_HRES              0x500
#define DS983_APB_REG_MSA_HSPOL             0x504
#define DS983_APB_REG_MSA_HSWIDTH           0x508
#define DS983_APB_REG_MSA_HSTART            0x50C
#define DS983_APB_REG_MSA_HTOTAL            0x510
#define DS983_APB_REG_MSA_VRES              0x514
#define DS983_APB_REG_MSA_VSPOL             0x518
#define DS983_APB_REG_MSA_VSWIDTH           0x51C
#define DS983_APB_REG_MSA_VSTART            0x520
#define DS983_APB_REG_MSA_VTOTAL            0x524
/* TODO: clarify naming with new revisions of TI datasheet */
#define DS983_APB_REG_LINE_RESET            0xA0C

/* ds90uh983 General Status Register 0 bits (0x0C) */
#define DS983_LINK_DETECT                   BIT(0)
#define DS983_BC_CRC_ERROR                  BIT(1)
#define DS983_BIST_CRC_ERROR                BIT(3)
#define DS983_LINK_LOST                     BIT(4)
#define DS983_TX_LOCK_DETECT                BIT(6)

/* Bits and operations */
#define DS983_I2C_DEV_ID_SET                BIT(0)
#define DS983_APB_ENABLE                    BIT(0)
#define DS983_APB_PORT0                     0
#define DS983_APB_LINK_ENABLE               BIT(0)
#define DS983_APB_LINK_DISABLE              0
/* TODO: clarify naming with new revisions of TI datasheet */
#define DS983_APB_LINE_RESET_VS0            BIT(0)
#define DS983_APB_READ                      BIT(1)
#define DS983_APB_AUTO_INC                  BIT(2)
#define DS983_IND_READ                      BIT(0)
#define DS983_IND_AUTO_INC                  BIT(1)
#define IND_PAGE_SHIFT                      2
#define TO_IND_PAGE(page)                   ((page) << IND_PAGE_SHIFT)
#define DS983_IND_PAGE_0                    TO_IND_PAGE(0)
#define DS983_IND_PAGE_1                    TO_IND_PAGE(1)
#define DS983_IND_PAGE_2                    TO_IND_PAGE(2)
#define DS983_IND_PAGE_4                    TO_IND_PAGE(4)
#define DS983_IND_PAGE_5                    TO_IND_PAGE(5)
#define DS983_IND_PAGE_8                    TO_IND_PAGE(8)
#define DS983_IND_PAGE_9                    TO_IND_PAGE(9)
#define DS983_IND_PAGE_11                   TO_IND_PAGE(11)
#define DS983_IND_PAGE_12                   TO_IND_PAGE(12)
#define DS983_IND_PAGE_14                   TO_IND_PAGE(14)
#define DS983_IND_PAGE_MAX                  DS983_IND_PAGE_14
#define DS983_FPD3_FIFO_DRAIN               (BIT(0) | BIT(1))
#define DS983_FPD_HALFRATE_MODE_MANUAL      BIT(0)
#define DS983_FPD_HALFRATE_MODE_MANUAL_MASK DS983_FPD_HALFRATE_MODE_MANUAL
#define DS983_ENABLE_FPD3_FIFO              BIT(3)
#define DS983_FPD3_ALIGN_ERR_THR            BIT(5)
#define DS983_DPRX_EN                       BIT(4)
#define DS983_FPD_HALFRATE_MODE_CH0         BIT(6)
#define DS983_FPD_HALFRATE_MODE_CH1         BIT(7)
#define DS983_FPD_HALFRATE_MODE             (DS983_FPD_HALFRATE_MODE_CH0 |      \
                                             DS983_FPD_HALFRATE_MODE_CH1)
#define DS983_FPD_HALFRATE_MODE_DISABLE     0
#define DS983_FPD_HALFRATE_MODE_MASK        DS983_FPD_HALFRATE_MODE
#define DS983_I2C_PASS_THROUGH              BIT(3)
#define DS983_I2C_PASS_THROUGH_MASK         DS983_I2C_PASS_THROUGH
#define DS983_RX_CRC_CHECKER_ENABLE         BIT(7)
#define DS981_RX_CRC_CHECKER_MASK           DS983_RX_CRC_CHECKER_ENABLE
#define DS983_FPD3_TX_MODE_SINGLE_PORT_0    BIT(0)
#define DS983_FPD3_TX_MODE_DUAL_FPD3        (BIT(1) | BIT(0))
#define DS983_FPD3_TX_MODE_INDEPENDENT_FPD3 (BIT(2) | BIT(0))
#define DS983_FPD3_TX_MODE_SPLITTER_FPD3    (BIT(2) | BIT(1) | BIT(0))
#define DS983_FPD3_TX_MODE                  (BIT(2) | BIT(1) | BIT(0))
#define DS983_FPD4_PORT0_SHIFT              2
#define DS983_FPD4_PORT1_SHIFT              4
#define DS983_FPD4_TX_MODE(port, mode)                                          \
        ((mode) << ((port) ? DS983_FPD4_PORT1_SHIFT : DS983_FPD4_PORT0_SHIFT))
#define DS983_FPD4_PORT_TX_MODE(port, val)                                      \
        (((val) >> ((port) ? DS983_FPD4_PORT1_SHIFT : DS983_FPD4_PORT0_SHIFT))  \
         & DS983_FPD4_TX_MODE_MASK)
#define DS983_FPD4_TX_MODE_FPD3             0
#define DS983_FPD4_TX_MODE_SINGLE           BIT(0)
#define DS983_FPD4_TX_MODE_DUAL             BIT(1)
#define DS983_FPD4_TX_MODE_INDEPENDENT      (BIT(1) | BIT(0))
#define DS983_FPD4_CLEAN_TX_MODE            (BIT(1) | BIT(0))
#define DS983_FPD4_TX_MODE_MASK             DS983_FPD4_CLEAN_TX_MODE

/***********************************/
/* TX port selection configuration */
/***********************************/
#define DS983_TX_PORT_0_WRITE               BIT(0)
#define DS983_TX_PORT_1_WRITE               BIT(1)
#define DS983_TX_PORT_1_READ                BIT(4)

/* read port 0 is set by deafult as the value for that is 0 */
#define DS983_TX_PORT_0_ENABLE              DS983_TX_PORT_0_WRITE
#define DS983_TX_PORT_1_ENABLE              (DS983_TX_PORT_1_WRITE |            \
                                             DS983_TX_PORT_1_READ)


#define DS983_NUM_VID_STREAMS_1_STREAM      0
#define DS983_NUM_VID_STREAMS_2_STREAMS     1
#define DS983_VP0_ENABLE                    BIT(0)
#define DS983_VP1_ENABLE                    BIT(1)
#define DS983_VP2_ENABLE                    BIT(2)
#define DS983_VP3_ENABLE                    BIT(3)
#define DS983_DISABLE_ALL_VP                0

/* reset bits */
#define DS983_RESET_NO_REGS                 BIT(0)
#define DS983_RESET_WITH_REGS               BIT(1)
#define DS983_RESET_PLL_CH0                 BIT(5)
#define DS983_RESET_PLL_CH1                 BIT(4)
#define DS983_RESET_NORMAL_OPERATION        0

#define DS983_PLL_REFCLK_VALID              BIT(3)
#define DS983_XO_REFCLK_VALID               BIT(4)
#define DS983_FPD3_COMPATIBILITY            1
#define DS983_FPD4_MODE_P0_MASK             (BIT(3) | BIT(2))
#define DS983_FPD4_MODE_P1_MASK             (BIT(5) | BIT(4))
#define DS983_FPD3_BOTH_PORTS_ENABLE_MASK   ~(DS983_FPD4_MODE_P0_MASK |         \
                                              DS983_FPD4_MODE_P1_MASK)
#define DS983_CRC_ERR_CLEAN                 BIT(5)
#define DS983_BIST_ENABLE                   BIT(0)

/* i2c routing */
#define DS983_SLAVE1_SHIFT                  4
#define SET_I2C_SLAVE(i2c_id)               (BIT(0) << (i2c_id))

#define DS983_SET_SLAVE0(i2c_id)            SET_I2C_SLAVE(i2c_id)
#define DS983_SET_SLAVE1(i2c_id)            (SET_I2C_SLAVE(i2c_id) <<           \
                                             DS983_SLAVE1_SHIFT)
#define DS983_SET_SLAVE2(i2c_id)            SET_I2C_SLAVE(i2c_id)

/* i2c slave routing */
#define DS983_MAX_REMOTE_I2C_COUNT          2
#define DS983_MAX_I2C_DEPTH                 3
#define DS983_MIN_BCC_DEPTH                 1

/* min depth in DC is 1, so decreasing offeset to 2 */
#define DS983_I2C_DEPTH_OFFSET              2
#define DS983_I2C_DEPTH_COUNT_SHIFT         6

#define DS983_I2C_DEPTH_COUNT(n)            ((n) << DS983_I2C_DEPTH_COUNT_SHIFT)
#define TO_I2C_DEPTH(depth)                 ((depth) + DS983_I2C_DEPTH_OFFSET)
#define DS983_I2C_DEPTH_PORT(depth, port)   ((port) << TO_I2C_DEPTH(depth))

/* Interrupt bits */
#define DS983_IRQ_ENABLE                    BIT(7)
#define DS983_IRQ_VP                        BIT(6)
#define DS983_IRQ_DP                        BIT(4)
#define DS983_IRQ_FPD_PORT1                 BIT(1)
#define DS983_IRQ_FPD_PORT0                 BIT(0)

/* GPIO bits and operations */
#define GPIOS_IN_REG                        8
#define GPIO_STAT(n)                        (1 << ((n) % GPIOS_IN_REG))
#define GPIO_INPUT_EN(n)                    (1 << ((n) % GPIOS_IN_REG))

#define GPIO_DISABLE                        0x0
#define GPIO_OUTPUT                         BIT(7)
#define GPIO_DEV_STATUS                     BIT(5)
#define GPIO_REMOTE_IRQ                     BIT(3)
#define GPIO_RX_LOCK                        (GPIO_REMOTE_IRQ | BIT(0))
#define GPIO_FPD_TX_IRQ                     (GPIO_REMOTE_IRQ | BIT(1))
#define GPIO_FPD_TX_IRQ_HIGH                (GPIO_FPD_TX_IRQ | GPIO_HIGH)
#define GPIO_FPD_TX_IRQ_LOW                 (GPIO_FPD_TX_IRQ | GPIO_LOW)

#define GPIO_MAIN_IRQ                       BIT(1)
#define GPIO_VP_IRQ_LOW                     (BIT(1) | BIT(0))
#define GPIO_VP_IRQ_HIGH                    BIT(2)
#define GPIO_DP_IRQ_LOW                     (BIT(2) | BIT(0))
#define GPIO_DP_IRQ_HIGH                    (BIT(2) | BIT(1))

#define DS983_GPIO_PORT_BASE                4
#define DS983_GPIO_PORT(port)               ((port) << DS983_GPIO_PORT_BASE)
#define TO_DS983_TX_PORT(reg_port)          !!((reg_port) &                     \
                                               BIT(DS983_GPIO_PORT_BASE))

#define DS983_GPIO_OUTPUT                   (GPIO_OUTPUT | GPIO_DEV_STATUS)
#define DS983_GPIO_OUTPUT_HIGH              (DS983_GPIO_OUTPUT | GPIO_HIGH)
#define DS983_GPIO_OUTPUT_LOW               (DS983_GPIO_OUTPUT | GPIO_LOW)

#define DS983_GPIO_MAIN_IRQ                 (DS983_GPIO_OUTPUT |                \
                                             GPIO_MAIN_IRQ)
#define DS983_GPIO_VP_IRQ_LOW               (DS983_GPIO_OUTPUT |                \
                                             GPIO_VP_IRQ_LOW)
#define DS983_GPIO_VP_IRQ_HIGH              (DS983_GPIO_OUTPUT |                \
                                             GPIO_VP_IRQ_HIGH)
#define DS983_GPIO_DP_IRQ_LOW               (DS983_GPIO_OUTPUT |                \
                                             GPIO_DP_IRQ_LOW)
#define DS983_GPIO_DP_IRQ_HIGH              (DS983_GPIO_OUTPUT |                \
                                             GPIO_DP_IRQ_HIGH)

#define DS983_GPIO_SET_REM_IRQ(port, func)  (GPIO_OUTPUT |                      \
                                             DS983_GPIO_PORT(port) |            \
                                             (func))
#define DS983_GPIO_SET_BC(port, n)          DS983_GPIO_SET_REM_IRQ(port, n)
#define DS983_GPIO_SET_FC(val, reg_val, fc_pin)                                 \
        ((~((fc_pin).mask) & (reg_val)) | ((val) << ((fc_pin).offset)))

#define DS983_GPIO_GET_REM_IRQ(func)        (GPIO_OUTPUT | (func))
#define DS983_GPIO_BC                       GPIO_OUTPUT
#define DS983_GPIO_FC(reg_val, fc_pin)      (((reg_val) & (fc_pin).mask) >>     \
                                             (fc_pin).offset)

#define DS983_GPIO_COUNT                    14
#define DS983_GPIO_FC_COUNT                 4
#define DS983_GPIO_BC_COUNT                 8
#define DS983_GPIO_BC_ANY                   (DS983_GPIO_BC_COUNT - 1)

#define DS983_DATAPATH_BC_FC_135MBPS        0x80
#define DS983_DATAPATH_BC_FC_168P75MBPS     0x86

#define DS983_BC_DOWN_SAMPLING_RATE_1       0x0A
#define DS983_BC_DOWN_SAMPLING_RATE_2       0x4A

/* APB bits and operations */
#define DS983_APB_MAX_LANE_COUNT            0x04
#define DS983_APB_MAX_LINK_RATE             0x1E
#define DS983_APB_DCPD_LANE01_STATUS_LOCKED 0x377
#define DS983_APB_DCPD_LANE23_STATUS_LOCKED 0x377
#define DS983_APB_MIN_VOLTAGE_SWING         0x2

/* Page 2: FPD PLL regs and bits */
#define DS983_IND_REG_PLL_MASH_ORDER        0x04
#define DS983_IND_REG_PLL_NDIV              0x05
#define DS983_IND_REG_PLL_VCO               0x0E
#define DS983_IND_REG_PLL_PDIV              0x13
#define DS983_IND_REG_PLL_DEN               0x18
#define DS983_IND_REG_PLL_NUM               0x1E

#define DS983_IND_REG_PLL_CH1_SHIFT         0x40

#define TO_PLL_PORT_REG(reg, port)          ((reg) +                            \
                                             DS983_IND_REG_PLL_CH1_SHIFT *      \
                                             (port))

#define DS983_PLL_MAX_DENOMINATOR           16777206
#define PLL_REFCLK_27MHZ                    27
#define DS983_PLL_FPD3_VCO_MIN_FREQ         3500
#define DS983_PLL_FPD3_VCO_MAX_FREQ         7500


#define DS983_PLL_MASH_ORDER_FRACTIONAL     BIT(3)
#define DS983_PLL_MASH_ORDER_INTEGER        0x0
#define DS983_PLL_MASH_FPD3                 (DS983_PLL_MASH_ORDER_FRACTIONAL |  \
                                             BIT(0))
#define DS983_PLL_FPD4_MASH_ORDER           (DS983_PLL_MASH_ORDER_INTEGER |     \
                                             BIT(0))
#define DS983_PLL_VCO_AUTO_SELECT           BIT(7)

#define VCO_OFFSET                          2
#define DS983_VCO_BASE_CODE                 0xC3
#define TO_PLL_VCO(vco_num)                 (DS983_VCO_BASE_CODE |              \
                                             ((vco_num) << (VCO_OFFSET)))

#define PLL_VCO_DIV_1                       1
#define PLL_VCO_DIV_2                       2
#define PLL_VCO_DIV_4                       4
#define PLL_VCO_DIV_8                       8
#define PLL_VCO_DIV_16                      16

#define PLL_VCO_N_DIV_MIN                   63

#define DS983_PLL_FPD4_PDIV_DEFAULT         (DS983_PLL_VCO_AUTO_SELECT |        \
                                             DS983_PLL_FPD4_DIV_2_CODE)

#define DS983_PLL_VCO_DIV_3P375GBPS         PLL_VCO_DIV_2

#define DS983_PLL_FPD4_DIV_1_CODE           0x00
#define DS983_PLL_FPD4_DIV_2_CODE           0x10
#define DS983_PLL_FPD4_DIV_4_CODE           0x20
#define DS983_PLL_FPD4_DIV_8_CODE           0x30

#define DS983_PLL_FPD3_DIV_16_CODE          0x40
#define DS983_PLL_FPD3_DIV_2_CODE           0x50
#define DS983_PLL_FPD3_DIV_4_CODE           0x60
#define DS983_PLL_FPD3_DIV_8_CODE           0x70

#define DS983_PLL_FPD3_PCLK_BITS            35
#define DS983_PLL_FPD4_PCLK_BITS            40

#define DS983_PLL_FPD3_REFCLK_COEF          2

#define DS983_PLL_PFD_FREQUENCY             (MHZ_TO_HZ(PLL_REFCLK_27MHZ) * 2)

#define PLL_CH0                             0
#define PLL_CH1                             1
#define PLL_CH0_CH1                         2

#define DS983_PLL_FPD4_VCO_DEFAULT          1
#define DS983_PLL_FPD4_NDIV_DEFAULT         125
#define DS983_PLL_FPD4_NUMERATOR_DEFAULT    0
#define DS983_PLL_FPD4_DENOMINATOR_DEFAULT  DS983_PLL_MAX_DENOMINATOR

#define DS983_FPD_BITS_PER_CLOCK            2

#define DS983_CALCULATE_PLL_N_DIV(f, div)   floor(((double)(f) /                \
                                                  DS983_PLL_PFD_FREQUENCY) *    \
                                                  (div))

/* Indirect registers page 4-5 (DP) */
#define DS983_IND_REG_DP_LN0_2_POL          0x29
#define DS983_IND_REG_DP_LN1_3_POL          0xA9

/* Indirect registers page 9 (FPD) */
#define DS983_IND_REG_FPD4_PORT0_ISR        0x8D
#define DS983_IND_REG_FPD4_PORT1_ISR        0x9D
#define DS983_IND_REG_FPD4_PORT0_ICR        0x8C
#define DS983_IND_REG_FPD4_PORT1_ICR        0x9C
#define DS983_IND_REG_DPHY_ICR              0x3E
#define DS983_IND_REG_DPHY_ISR              0x3F

/* Indirect registers page 11 (link layers) */
#define DS983_IND_REG_LINK_LAYER_CTL        0x00
#define DS983_IND_REG_LINK0_STREAM_ENABLE   0x01
#define DS983_IND_REG_LINK_MAP_STREAM_0_1   0x02
#define DS983_IND_REG_LINK_MAP_STREAM_2_3   0x03

#define DS983_IND_REG_LINK0_SLOT_STREAM0    0x06
#define DS983_IND_REG_LINK1_STREAM_ENABLE   0x11
#define DS983_IND_REG_LINK1_MAP             0x12
#define DS983_IND_REG_LINK1_SLOT_STREAM0    0x16

/* Indirect registers page 12 (Video processor) */
#define DS983_IND_REG_VP_CTL                0x00
#define DS983_IND_REG_VP_CFG                0x01
#define DS983_IND_REG_VP_DP_H_ACTIVE0       0x02
#define DS983_IND_REG_VP_CROP_START_X0      0x08
#define DS983_IND_REG_VP_CROP_START_X1      0x09
#define DS983_IND_REG_VP_CROP_START_Y0      0x0A
#define DS983_IND_REG_VP_CROP_START_Y1      0x0B
#define DS983_IND_REG_VP_CROP_STOP_X0       0x0C
#define DS983_IND_REG_VP_CROP_STOP_X1       0x0D
#define DS983_IND_REG_VP_CROP_STOP_Y0       0x0E
#define DS983_IND_REG_VP_CROP_STOP_Y1       0x0F
#define DS983_IND_REG_VP_VID_H_ACTIVE0      0x10
#define DS983_IND_REG_VP_VID_H_BACK0        0x12
#define DS983_IND_REG_VP_VID_H_WIDTH0       0x14
#define DS983_IND_REG_VP_VID_H_TOTAL0       0x16
#define DS983_IND_REG_VP_VID_V_ACTIVE0      0x18
#define DS983_IND_REG_VP_VID_V_BACK0        0x1A
#define DS983_IND_REG_VP_VID_V_WIDTH0       0x1C
#define DS983_IND_REG_VP_VID_V_FRONT0       0x1E
#define DS983_IND_REG_VP_PCLK_GEN_M         0x23
#define DS983_IND_REG_VP_PCLK_GEN_N         0x25
#define DS983_IND_REG_VP_STS                0x30
#define DS983_IND_REG_VP_ISR_BASE           0x31
#define DS983_IND_REG_VP_ICR                0x33

/* Indirect registers page 14 (Temperature / Voltage) */
#define DS983_IND_REG_SAR_ADC_CLK_DIV_SEL   0x04
#define DS983_IND_REG_SAR_ADC_INPUT_EN_LSB  0x07
#define DS983_IND_REG_SAR_ADC_INPUT_EN_MSB  0x08
#define DS983_IND_REG_SAR_ADC_SETTINGS      0x0D
#define DS983_IND_REG_TEMP_FINAL            0x13
#define DS983_IND_REG_LINE_FAULT0_FINAL     0x1D
#define DS983_IND_REG_LINE_FAULT1_FINAL     0x1E
#define DS983_IND_REG_LINE_FAULT2_FINAL     0x1F
#define DS983_IND_REG_LINE_FAULT3_FINAL     0x20

/* Page 9 bits and operations */
#define DS983_FPD_LOCK_DET_INT              BIT(6)
#define DS983_FPD_REM_INT                   BIT(5)
#define DS983_FPD4_DES_INT                  BIT(4)
#define DS983_DP_RX_CORE_INT                BIT(2)
#define DS983_DP_LINK_TRAINING_DONE         BIT(1)
#define DS983_DP_LINK_LOST                  BIT(0)

/* Page 12: VP bits and operations */
#define DS983_LINE_RATE_13P5MBPS            13500
#define DS983_LINE_RATE_12P528MBPS          12528
#define DS983_LINE_RATE_10P8MBPS            10800
#define DS983_LINE_RATE_6P75MBPS            6750
#define DS983_LINE_RATE_3P375MBPS           3375
#define DS983_FPD4_RATE_DIVIDER             40.0

#define DS983_VP_REF_CLK_MHZ                (DS983_LINE_RATE_13P5MBPS /         \
                                             DS983_FPD4_RATE_DIVIDER)
#define DS983_VP_FPD4_PCLK_QUAD             4
#define FPD4_PCLK_TO_VP_CLK(x)              ((x) / DS983_VP_FPD4_PCLK_QUAD)
#define FPD4_FREQ_TO_VP_REF_CLK(x)          ((x) / DS983_FPD4_RATE_DIVIDER)

#define DS983_VP_FPD4_PCLK_N_DEFAULT        15
#define DS983_VP_FPD4_PCLK_M_DEFAULT        8768

#define DS983_IND_REG_VP_REG_SHIFT          0x40
#define TO_VP_REG(base, vp_num)             ((base) + (vp_num) *                \
                                             DS983_IND_REG_VP_REG_SHIFT)

#define DS983_VP_ENABLE_CROPPING            BIT(2)
#define DS983_VP_DISABLE_CROPPING           0
#define DS983_VP_STATUS_CHANGE              BIT(0)
#define DS983_VP_ENABLE(n)                  (1 << (n))

/* Page 11 bits and operations */
#define DS983_MAX_LINK_LAYER_STREAMS        4
#define DS983_VP_MAP_STREAM_COUNT_IN_REG    2
#define MAP_SHIFT                           4

#define MAP_VP_TO_STREAM(vp, stream)        ((vp) << (MAP_SHIFT * (stream % 2)))
#define GET_STREAM_REG(port)                (((port) == PORT_0) ?               \
                                             DS983_IND_REG_LINK0_SLOT_STREAM0 : \
                                             DS983_IND_REG_LINK1_SLOT_STREAM0)

#define VP_SRC_SELECT_CLEAR                  ~(BIT(1) | BIT(0))

#define GET_STREAM_SLOT_REG(port, stream)   (GET_STREAM_REG(port) + (stream))

#define LINK_LAYER_0_ENABLE                 BIT(0)
#define LINK_LAYER_0_TIMESLOT_ENABLE        BIT(1)
#define LINK_LAYER_1_ENABLE                 BIT(2)
#define LINK_LAYER_1_TIMESLOT_ENABLE        BIT(3)

#define DS983_LINK_LAYER_0_ENABLE           (LINK_LAYER_0_ENABLE |              \
                                             LINK_LAYER_0_TIMESLOT_ENABLE)
#define DS983_LINK_LAYER_1_ENABLE           (LINK_LAYER_1_ENABLE |              \
                                             LINK_LAYER_1_TIMESLOT_ENABLE)

#define DS983_LINK_LAYERS_DISABLE           0
#define DS983_LINK_LAYERS_ENABLE            (DS983_LINK_LAYER_0_ENABLE |        \
                                             DS983_LINK_LAYER_1_ENABLE)
#define DS983_TIMESLOTS_LIMIT               65

#define DS983_FPD4_DATA_SIZE                132.0
#define DS983_FPD4_RGB_DATA_SIZE            128.0
#define DS983_FPD4_THROUGPUT_COEFFICIENT    (DS983_FPD4_RGB_DATA_SIZE /         \
                                             DS983_FPD4_DATA_SIZE)
#define DS983_DEFAULT_FPD_THROUGPUT_MULT    1
#define DS983_DUAL_FPD_THROUGPUT_MULT       2

#define REV_ID_SHIFT                        4
#define TO_DS983_REVISION(x)                ((x) >> REV_ID_SHIFT)

static
const uint32_t PLL_VCO_FPD4_N_DIVS[] = {
        PLL_VCO_DIV_1,
        PLL_VCO_DIV_2,
        PLL_VCO_DIV_4,
        PLL_VCO_DIV_8
};

typedef struct {
        uint8_t reg;
        uint8_t data;
} ds90uh983_write_array_t;

typedef struct ds983_irq_config {
        irq_type_t type;
        irq_type_t mask;
} ds983_irq_config_st_t;

typedef enum ds983_vp_irq {
        DS983_CROP_VERT_ERR   = IRQ_SUBTYPE(6),
        DS983_CROP_HOR_ERR    = IRQ_SUBTYPE(5),
        DS983_TIMING_DATA_ERR = IRQ_SUBTYPE(4),
        DS983_TIMING_LINE_ERR = IRQ_SUBTYPE(3),
        DS983_TIMING_STRT_ERR = IRQ_SUBTYPE(2),
        DS983_VP_VBUF_ERR     = IRQ_SUBTYPE(1),
        DS983_VP_STATUS       = IRQ_SUBTYPE(0),
} ds983_vp_irq_t;

enum slave_state {
        FREE = 0,
        OCCUPIED,
};

struct ds90ux9xx_i2c_slave_regs {
        const uint8_t slave_reg[DS983_I2C_SLAVE_COUNT];
        const uint8_t alias_reg[DS983_I2C_SLAVE_COUNT];
        const uint8_t route_reg[DS983_I2C_SLAVE_COUNT];
};

struct ds90ux9xx_i2c_slave_control {
        pthread_mutex_t i2c_state_lock;
        uint8_t         state[DS983_MAX_I2C_COUNT][DS983_I2C_SLAVE_COUNT];
};

ds90ux9xx_err_t ds90uh983_set_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port);

#define DS90UH983_FPD4_VP_PRECONFIG                                             \
        {                                                                       \
                {0x40, 0x10},                                                   \
                {0x41, 0x4C},                                                   \
                {0x42, 0x00},                                                   \
                {0x41, 0x50},                                                   \
                {0x42, 0x80},                                                   \
                {0x41, 0x25},                                                   \
                {0x42, 0x35},                                                   \
                {0x41, 0x24},                                                   \
                {0x42, 0x25},                                                   \
                {0x41, 0x0A},                                                   \
                {0x42, 0x77},                                                   \
                {0x41, 0x28},                                                   \
                {0x42, 0x30},                                                   \
                {0x40, 0x10},                                                   \
                {0x41, 0xCC},                                                   \
                {0x42, 0x00},                                                   \
                {0x41, 0xD0},                                                   \
                {0x42, 0x80},                                                   \
                {0x41, 0xA5},                                                   \
                {0x42, 0x35},                                                   \
                {0x41, 0xA4},                                                   \
                {0x42, 0x25},                                                   \
                {0x41, 0x8A},                                                   \
                {0x42, 0x77},                                                   \
                {0x41, 0xA8},                                                   \
                {0x42, 0x30},                                                   \
                {0x40, 0x14},                                                   \
                {0x41, 0x4C},                                                   \
                {0x42, 0x00},                                                   \
                {0x41, 0x50},                                                   \
                {0x42, 0x80},                                                   \
                {0x41, 0x25},                                                   \
                {0x42, 0x35},                                                   \
                {0x41, 0x24},                                                   \
                {0x42, 0x25},                                                   \
                {0x41, 0x0A},                                                   \
                {0x42, 0x77},                                                   \
                {0x41, 0x28},                                                   \
                {0x42, 0x30},                                                   \
                {0x40, 0x14},                                                   \
                {0x41, 0xCC},                                                   \
                {0x42, 0x00},                                                   \
                {0x41, 0xD0},                                                   \
                {0x42, 0x80},                                                   \
                {0x41, 0xA5},                                                   \
                {0x42, 0x35},                                                   \
                {0x41, 0xA4},                                                   \
                {0x42, 0x25},                                                   \
                {0x41, 0x8A},                                                   \
                {0x42, 0x77},                                                   \
                {0x41, 0xA8},                                                   \
                {0x42, 0x30},                                                   \
        }

#endif /* __DS90UH983_H__ */

