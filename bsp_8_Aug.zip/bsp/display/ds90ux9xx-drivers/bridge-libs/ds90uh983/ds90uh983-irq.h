/**
 * @file       ds90uh983-irq.h
 * @brief      ds90uh983 IRQ settings API
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UH983_IRQ_H__
#define __DS90UH983_IRQ_H__

#ifdef UNITTEST
#include "UT-ds90uh983-mock.h"
#include "UT-ds90ux9xx-bridge-libraries-mock.h"
#else /* aarch64 */
#include "ds90uh983.h"
#include "ds90ux9xx-bridge-libraries.h"
#endif /* UNITTEST */

ds90ux9xx_err_t ds90uh983_global_interrupts_init(ds90ux9xx_st_t *dev);

ds90ux9xx_err_t ds90uh983_set_irq(ds90ux9xx_st_t *dev, irq_common_st_t *irq);
ds90ux9xx_err_t ds90uh983_get_irq(ds90ux9xx_st_t *dev,
        bool subtypes_info);

#endif /* __DS90UH983_IRQ_H__ */

