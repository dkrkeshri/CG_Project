/**
 * @file       ds90uh983-irq.c
 * @brief      ds90uh983 irq settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifdef UNITTEST
#include "UT-ds90uh983-irq-mock.h"

#include "UT-ds90ux9xx-src-common.h"
#else /* aarch64 */
#include "ds90uh983-irq.h"
#endif /* UNITTEST */

#define DS983_IRQ_AVAILABLE             (IRQ_GLOBAL |                           \
                                         IRQ_DPHY |                             \
                                         IRQ_FPD_TX |                           \
                                         IRQ_VP)

#define DS983_VP_IRQ_AVAILABLE          (IRQ_VP_STATUS |                        \
                                         IRQ_VP_VBUF_ERR |                      \
                                         IRQ_TIMING_STRT_ERR |                  \
                                         IRQ_TIMING_LINE_ERR |                  \
                                         IRQ_TIMING_DATA_ERR |                  \
                                         IRQ_CROP_HOR_ERR |                     \
                                         IRQ_CROP_VERT_ERR)

#define DS983_FPD_IRQ_AVAILABLE         (IRQ_FPD_LOCK_DET_INT |                 \
                                         IRQ_FPD_REM_INT |                      \
                                         IRQ_FPD_DES_INT)

#define DS983_DPHY_IRQ_AVAILABLE        (IRQ_DPHY_CORE_INT |                    \
                                         IRQ_DPHY_LINK_TRAINING_DONE |          \
                                         IRQ_DPHY_LINK_LOST)

ds9xx_irq_config_st_t ds983_irqs[] = {
        {IRQ_GLOBAL, DS983_IRQ_ENABLE                         },
        {IRQ_FPD_TX, DS983_IRQ_FPD_PORT0 | DS983_IRQ_FPD_PORT1},
        {IRQ_VP,     DS983_IRQ_VP                             },
        {IRQ_DPHY,   DS983_IRQ_DP                             },
};

ds9xx_irq_config_st_t ds983_subtypes_vp[] = {
        {IRQ_CROP_VERT_ERR,   DS983_CROP_VERT_ERR  },
        {IRQ_CROP_HOR_ERR,    DS983_CROP_HOR_ERR   },
        {IRQ_TIMING_DATA_ERR, DS983_TIMING_DATA_ERR},
        {IRQ_TIMING_LINE_ERR, DS983_TIMING_LINE_ERR},
        {IRQ_TIMING_STRT_ERR, DS983_TIMING_STRT_ERR},
        {IRQ_VP_VBUF_ERR,     DS983_VP_VBUF_ERR    },
        {IRQ_VP_STATUS,       DS983_VP_STATUS      },
};

ds9xx_irq_config_st_t ds983_subtypes_fpd4[] = {
        {IRQ_FPD_LOCK_DET_INT, DS983_FPD_LOCK_DET_INT},
        {IRQ_FPD_REM_INT,      DS983_FPD_REM_INT     },
        {IRQ_FPD_DES_INT,      DS983_FPD4_DES_INT    },
};

ds9xx_irq_config_st_t ds983_subtypes_fpd3[] = {
        {IRQ_FPD_LOCK_DET_INT, DS983_FPD_LOCK_DET_INT},
        {IRQ_FPD_REM_INT,      DS983_FPD_REM_INT     },
};

ds9xx_irq_config_st_t ds983_subtypes_dphy[] = {
        {IRQ_DPHY_CORE_INT,           DS983_DP_RX_CORE_INT       },
        {IRQ_DPHY_LINK_TRAINING_DONE, DS983_DP_LINK_TRAINING_DONE},
        {IRQ_DPHY_LINK_LOST,          DS983_DP_LINK_LOST         },
};

ds90ux9xx_err_t ds90uh983_global_interrupts_init(ds90ux9xx_st_t *dev)
{
        uint8_t i;
        ds90ux9xx_err_t rc;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->global_irqs.irqs_supported = DS983_IRQ_AVAILABLE;

        for (i = 0; i < DS983_MAX_FPD_PORTS; i++) {
                rc = init_interrupt(dev, IRQ_FPD_TX, i,
                                    DS983_FPD_IRQ_AVAILABLE);
                if (DS90UX9XX_SUCCESS != rc) {
                        return rc;
                }
        }

        for (i = 0; i < DS983_MAX_VP_COUNT; i++) {
                rc = init_interrupt(dev, IRQ_VP, i, DS983_VP_IRQ_AVAILABLE);
                if (DS90UX9XX_SUCCESS != rc) {
                        return rc;
                }
        }

        rc = init_interrupt(dev, IRQ_DPHY, NOT_SPECIFIED,
                            DS983_DPHY_IRQ_AVAILABLE);

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype_vp(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t control = 0;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_12,
                                       TO_VP_REG(DS983_IND_REG_VP_ICR, irq->id),
                                       &control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't read VP IRQ parameters\n");

                return rc;
        }

        UPDATE_IRQ_SUBTYPES(control, ds983_subtypes_vp, irq);

        rc = ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_12,
                                        TO_VP_REG(DS983_IND_REG_VP_ICR,
                                                  irq->id),
                                        control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't write VP IRQ parameters\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype_dphy(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t control = 0;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                       DS983_IND_REG_DPHY_ICR, &control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read DPHY parameters\n");

                return rc;
        }

        UPDATE_IRQ_SUBTYPES(control, ds983_subtypes_dphy, irq);

        rc = ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_9,
                                        DS983_IND_REG_DPHY_ICR, control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write DPHY parameters\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype_fpd4(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t control = 0;
        uint8_t reg_ctrl;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (PORT_0 == irq->port) {
                reg_ctrl = DS983_IND_REG_FPD4_PORT0_ICR;
        } else if (PORT_1 == irq->port) {
                reg_ctrl = DS983_IND_REG_FPD4_PORT0_ICR;
        } else {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                       reg_ctrl, &control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD parameters\n");

                return rc;
        }

        UPDATE_IRQ_SUBTYPES(control, ds983_subtypes_fpd4, irq);

        rc = ds90ux9xx_i2c_write_ind_1b(dev, DS983_IND_PAGE_9,
                                        reg_ctrl, control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write FPD parameters\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype_fpd3(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t control = 0;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90uh983_set_tx_port(dev, irq->port);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't set FPD port\n");

                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_FPD3_ICR, &control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD parameters\n");

                return rc;
        }

        UPDATE_IRQ_SUBTYPES(control, ds983_subtypes_fpd3, irq);

        rc = ds90ux9xx_i2c_write(dev, DS983_REG_FPD3_ICR, control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write FPD parameters\n");
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype_fpd(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == dev->settings.backward_compatibility) {
                rc = set_irq_subtype_fpd3(dev, irq);
        } else {
                rc = set_irq_subtype_fpd4(dev, irq);
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtype(ds90ux9xx_st_t *dev, irq_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (irq->type) {
        case IRQ_FPD_TX:
                log_dbg("983: setup FPD interrupt\n");

                rc = set_irq_subtype_fpd(dev, irq);
                break;
        case IRQ_VP:
                log_dbg("983: setup VP interrupt\n");

                rc = set_irq_subtype_vp(dev, irq);
                break;
        case IRQ_DPHY:
                log_dbg("983: setup DPHY interrupt\n");

                rc = set_irq_subtype_dphy(dev, irq);
                break;
        default:
                log_err("983: not supported\n");
                rc = DS90UX9XX_NOT_SUPPORTED;
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_subtypes(ds90ux9xx_st_t *dev, struct list_node *list)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        irq_st_t *requested_irq = NULL;
        irq_st_t *dev_irq = NULL;
        irq_state_t request_enable;
        irq_state_t request_disable;

        if (NULL == dev || NULL == list) {
                log_err("Invalid input: dev = %p, list = %p\n", dev, list);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        list_for_every_entry(list, requested_irq, irq_st_t, node) {
                dev_irq = irq_get_entry(dev, requested_irq->type,
                                        requested_irq->id);
                if (NULL == dev_irq) {
                        log_err("Entry not found for IRQ type 0x%x\n",
                                requested_irq->type);

                        return DS90UX9XX_INVALID_PARAMETER;
                }

                rc |= set_irq_subtype(dev, requested_irq);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("IRQ subtypes for type 0x%x not applied\n",
                                requested_irq->type);
                        break;
                }

                log_dbg("IRQ subtypes for type 0x%x applied\n",
                        requested_irq->type);

                /* Update bridge irq struct */
                request_enable = requested_irq->subtypes_enabled &
                                 requested_irq->subtypes_requested;
                request_disable = ~requested_irq->subtypes_enabled &
                                  requested_irq->subtypes_requested;

                dev_irq->subtypes_enabled &= ~(request_disable &
                                               dev_irq->subtypes_supported);
                dev_irq->subtypes_enabled |= (request_enable &
                                              dev_irq->subtypes_supported);
        }

        return rc;
}

static
ds90ux9xx_err_t set_irq_types(ds90ux9xx_st_t *dev, irq_common_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t val = 0;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_INTERRUPT_CTL, &val);

        UPDATE_IRQ_TYPES(val, ds983_irqs, irq);

        rc |= ds90ux9xx_i2c_write(dev, DS983_REG_INTERRUPT_CTL, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't write IRQ parameters\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_set_irq(ds90ux9xx_st_t *dev, irq_common_st_t *irq)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        irq_state_t request_enable;
        irq_state_t request_disable;

        if (NULL == dev || NULL == irq) {
                log_err("Invalid input: dev = %p, irq = %p\n", dev, irq);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        request_enable = irq->irqs_enabled & irq->irqs_requested;
        request_disable = ~irq->irqs_enabled & irq->irqs_requested;

        if (true == irq->subtypes_info) {
                rc = set_irq_subtypes(dev, &irq->irq_list);
        }

        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't write IRQ subtypes parameters\n");

                return rc;
        }

        rc = set_irq_types(dev, irq);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Cant't write IRQ types parameters\n");

                return rc;
        }

        /* update interrupts state */
        dev->global_irqs.irqs_enabled &= ~(request_disable &
                                           dev->global_irqs.irqs_supported);
        dev->global_irqs.irqs_enabled |= (request_enable &
                                          dev->global_irqs.irqs_supported);

        debug_extended_isr_data(&dev->global_irqs);

        return rc;
}

static
ds90ux9xx_err_t get_irq_vp(ds90ux9xx_st_t *dev, bool subtypes_info)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t vp_id = 0;
        uint8_t vp_isr = 0;
        uint8_t status = 0;
        uint8_t control = 0;
        irq_st_t *irq_vp = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->global_irqs.irqs_triggered |= IRQ_VP;

        if (false == subtypes_info) {
                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_VP_GLOBAL_ISR, &vp_isr);
        if (DS90UX9XX_SUCCESS != rc) {
                return rc;
        }

        log_dbg("reg 0x%x: global_vp_isr = 0x%x\n",
                DS983_REG_VP_GLOBAL_ISR, vp_isr);

        for (vp_id = 0; vp_id < DS983_MAX_VP_COUNT; vp_id++) {
                if (0 == (vp_isr & ENABLE)) {
                        continue;
                }

                irq_vp = irq_get_entry(dev, IRQ_VP, vp_id);
                if (NULL == irq_vp) {
                        log_err("IRQ entry not available\n");

                        return DS90UX9XX_INVALID_PARAMETER;
                }

/* *DISABLE FORMATTER* - DO NOT REMOVE. Formatter rule exception! */
                rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_12,
                        TO_VP_REG(DS983_IND_REG_VP_ICR, vp_id), &control);

                /* read from reg reset vp[x] irq */
                rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_12,
                        TO_VP_REG(DS983_IND_REG_VP_ISR_BASE, vp_id), &status);
                if (DS90UX9XX_SUCCESS != rc) {
                        log_err("Can't read VP registers\n");
                        break;
                }
/* *ENABLE FORMATTER* - DO NOT REMOVE. End of formatter rule exception! */

                status = status & control;

                log_dbg("INTERRUPT on VP[%d]:0x%x\n", vp_id, status);

                irq_vp->subtypes_triggered = IRQ_NONE;

                if (status & DS983_CROP_VERT_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_CROP_VERT_ERR;
                }

                if (status & DS983_CROP_HOR_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_CROP_HOR_ERR;
                }

                if (status & DS983_TIMING_DATA_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_TIMING_DATA_ERR;
                }

                if (status & DS983_TIMING_LINE_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_TIMING_LINE_ERR;
                }

                if (status & DS983_TIMING_STRT_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_TIMING_STRT_ERR;
                }

                if (status & DS983_VP_VBUF_ERR) {
                        irq_vp->subtypes_triggered |= IRQ_VP_VBUF_ERR;
                }

                if (status & DS983_VP_STATUS) {
                        irq_vp->subtypes_triggered |= IRQ_VP_STATUS;
                }

                vp_isr = vp_isr >> 1;
        }

        return rc;
}

static
ds90ux9xx_err_t get_irq_fpd4(ds90ux9xx_st_t *dev, uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg_sts = 0;
        uint8_t reg_ctrl = 0;
        uint8_t status = 0;
        uint8_t control = 0;
        irq_st_t *irq_fpd = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (PORT_0 == port) {
                reg_sts = DS983_IND_REG_FPD4_PORT0_ISR;
                reg_ctrl = DS983_IND_REG_FPD4_PORT0_ICR;
        } else if (PORT_1 == port) {
                reg_sts = DS983_IND_REG_FPD4_PORT1_ISR;
                reg_ctrl = DS983_IND_REG_FPD4_PORT0_ICR;
        } else {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        irq_fpd = irq_get_entry(dev, IRQ_FPD_TX, port);
        if (NULL == irq_fpd) {
                log_err("IRQ entry not available\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                       reg_ctrl, &control);
        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                        reg_sts, &status);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD registers\n");

                return rc;
        }

        log_dbg("INTERRUPT on FPD4[%d]:reg 0x%x = 0x%x\n",
                port, reg_sts, status);

        irq_fpd->subtypes_triggered = IRQ_NONE;
        status &= control;

        if (DS983_FPD_LOCK_DET_INT & status) {
                irq_fpd->subtypes_triggered |= IRQ_FPD_LOCK_DET_INT;
        }

        if (DS983_FPD_REM_INT & status) {
                irq_fpd->subtypes_triggered |= IRQ_FPD_REM_INT;
        }

        if (DS983_FPD4_DES_INT & status) {
                irq_fpd->subtypes_triggered |= IRQ_FPD_DES_INT;
        }

        return rc;
}

static
ds90ux9xx_err_t get_irq_fpd3(ds90ux9xx_st_t *dev, uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t status = 0;
        uint8_t control = 0;
        irq_st_t *irq_fpd = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        irq_fpd = irq_get_entry(dev, IRQ_FPD_TX, port);
        if (NULL == irq_fpd) {
                log_err("IRQ entry not available\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_FPD3_ICR, &control);
        rc |= ds90ux9xx_i2c_read(dev, DS983_REG_FPD3_ISR, &status);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read FPD registers\n");

                return rc;
        }

        log_dbg("INTERRUPT on FPD3[%d]:reg 0x%x = 0x%x\n",
                port, DS983_REG_FPD3_ISR, status);

        irq_fpd->subtypes_triggered = IRQ_NONE;
        status &= control;

        if (DS983_FPD_LOCK_DET_INT & status) {
                irq_fpd->subtypes_triggered |= IRQ_FPD_LOCK_DET_INT;
        }

        if (DS983_FPD_REM_INT & status) {
                irq_fpd->subtypes_triggered |= IRQ_FPD_REM_INT;
        }

        return rc;
}

static
ds90ux9xx_err_t get_irq_fpd(ds90ux9xx_st_t *dev, bool subtypes_info,
        uint8_t port)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->global_irqs.irqs_triggered |= IRQ_FPD_TX;

        if (false == subtypes_info) {
                return rc;
        }

        if (true == dev->settings.backward_compatibility) {
                rc = ds90uh983_set_tx_port(dev, port);
                rc |= get_irq_fpd3(dev, port);
        } else {
                rc = get_irq_fpd4(dev, port);
        }

        return rc;
}

static
ds90ux9xx_err_t get_irq_dphy(ds90ux9xx_st_t *dev, bool subtypes_info)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t status = 0;
        uint8_t control = 0;
        irq_st_t *irq_dphy = NULL;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->global_irqs.irqs_triggered |= IRQ_DPHY;

        if (false == subtypes_info) {
                return rc;
        }

        irq_dphy = irq_get_entry(dev, IRQ_DPHY, NOT_SPECIFIED);
        if (NULL == irq_dphy) {
                log_err("IRQ entry not available\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                       DS983_IND_REG_DPHY_ICR, &control);
        rc |= ds90ux9xx_i2c_read_ind_1b(dev, DS983_IND_PAGE_9,
                                        DS983_IND_REG_DPHY_ISR, &status);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read DPHY registers\n");

                return rc;
        }

        log_dbg("INTERRUPT on DPHY:reg 0x%x:0x%x\n",
                DS983_IND_REG_DPHY_ISR, status);

        irq_dphy->subtypes_triggered = IRQ_NONE;
        status &= control;

        if (DS983_DP_RX_CORE_INT & status) {
                irq_dphy->subtypes_triggered |= IRQ_DPHY_CORE_INT;
        }

        if (DS983_DP_LINK_TRAINING_DONE & status) {
                irq_dphy->subtypes_triggered |= IRQ_DPHY_LINK_TRAINING_DONE;
        }

        if (DS983_DP_LINK_LOST & status) {
                irq_dphy->subtypes_triggered |= IRQ_DPHY_LINK_LOST;
        }

        return rc;
}

ds90ux9xx_err_t ds90uh983_get_irq(ds90ux9xx_st_t *dev, bool subtypes_info)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t status = 0;
        uint8_t control = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx dev ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS983_REG_INTERRUPT_CTL, &control);
        rc |= ds90ux9xx_i2c_read(dev, DS983_REG_INTERRUPT_STS, &status);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read IRQ state. Error: %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        dev->global_irqs.irqs_triggered = IRQ_NONE;

        status &= control;
        if (status & DS983_IRQ_ENABLE) {
                log_dbg("983: GLOBAL interrupt\n");
                dev->global_irqs.irqs_triggered |= IRQ_GLOBAL;
        } else {
                log_dbg("983: No interrupts are set\n");

                return rc;
        }

        if (status & DS983_IRQ_FPD_PORT0) {
                log_dbg("983: TX0 interrupt\n");

                rc |= get_irq_fpd(dev, subtypes_info, PORT_0);
        }

        if (status & DS983_IRQ_FPD_PORT1) {
                log_dbg("983: TX1 interrupt\n");

                rc |= get_irq_fpd(dev, subtypes_info, PORT_1);
        }

        if (status & DS983_IRQ_DP) {
                log_dbg("983: DP interrupt\n");

                rc |= get_irq_dphy(dev, subtypes_info);
        }

        if (status & DS983_IRQ_VP) {
                log_dbg("983: VP interrupt\n");

                rc |= get_irq_vp(dev, subtypes_info);
        }

        debug_extended_isr_data(&dev->global_irqs);

        return rc;
}

