/**
 * @file       ds90ub928-gpio.c
 * @brief      ds90ub928 / ds90uh928 GPIO settings routines
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include "ds90ub928-gpio.h"

#define DS928_GPIO_COUNT        (8 + 1) /* reserve for gpio4 */
#define HIGH_HALF               0xF0
#define LOW_HALF                0x0F
#define HIGH_OFFSET             4

#define UNDEFINED               0xFF
#define GPIO4                   4
#define DS928_REMOTE_GPIOS_CNT  4

typedef struct ds90ub928_pin {
        const char    *name;
        const uint8_t reg;
        const uint8_t mask;
} ds928_pins_st_t;

#define DS928_GPIO(gpio_name, reg_addr, mask_byte)                              \
        {                                                                       \
                .name = gpio_name,                                              \
                .reg = reg_addr,                                                \
                .mask = mask_byte,                                              \
        }

static ds928_pins_st_t ds928_gpios[DS928_GPIO_COUNT] = {
        DS928_GPIO("gpio0",     DS928_REG_GPIO_0,   LOW_HALF),
        DS928_GPIO("gpio1",     DS928_REG_GPIO_1_2, LOW_HALF),
        DS928_GPIO("gpio2",     DS928_REG_GPIO_1_2, HIGH_HALF),
        DS928_GPIO("gpio3",     DS928_REG_GPIO_3,   LOW_HALF),
        DS928_GPIO("undefined", UNDEFINED,          UNDEFINED),
        DS928_GPIO("gpio5",     DS928_REG_GPIO_5_6, LOW_HALF),
        DS928_GPIO("gpio6",     DS928_REG_GPIO_5_6, HIGH_HALF),
        DS928_GPIO("gpio7",     DS928_REG_GPIO_7_8, LOW_HALF),
        DS928_GPIO("gpio8",     DS928_REG_GPIO_7_8, HIGH_HALF),
};

static
inline int is_absent(int num)
{
        return num == GPIO4;
}

static
int is_wrong_gpio_number(int num)
{
        if (num <= NOT_SPECIFIED ||
            num >= DS928_GPIO_COUNT ||
            is_absent(num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub928_set_gpio(ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;
        uint8_t reg, val, orig_val;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        switch (gpio->function) {
        case FUNC_GPIO_INPUT:
                val = DS928_GPIO_INPUT;
                break;
        case FUNC_GPIO_OUTPUT:
                if (GPIO_HIGH == gpio->value) {
                        val = DS928_GPIO_OUTPUT_HIGH;
                } else {
                        val = DS928_GPIO_OUTPUT_LOW;
                }

                break;
        case FUNC_REMOTE:
                if (gpio->num >= DS928_REMOTE_GPIOS_CNT) {
                        return DS90UX9XX_INVALID_PARAMETER;
                }

                val = DS928_GPIO_OUTPUT_REMOTE;
                break;
        case FUNC_I2S:
        case FUNC_DISABLE:
                val = DS928_GPIO_NORMAL_OPERATION;
                break;
        default:
                log_err("Incorrect GPIO function is used\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds928_gpios[gpio->num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &orig_val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read original gpio value\n");

                return rc;
        }

        if (ds928_gpios[gpio->num].mask == HIGH_HALF) {
                val <<= HIGH_OFFSET;
                val |= orig_val & LOW_HALF;
        } else {
                val |= orig_val & HIGH_HALF;
        }

        return ds90ux9xx_i2c_write(dev, reg, val);
}

static
ds90ux9xx_err_t get_gpio_value(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_value_t *value)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == value) {
                log_err("value ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds928_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ds928_gpios[num].mask == HIGH_HALF) {
                val = ((val & HIGH_HALF) >> HIGH_OFFSET);
        }

        *value = !!(val & DS928_GPIO_HIGH);

        log_dbg("Got value %d for GPIO_%d\n", *value, num);

        return rc;
}

static
gpio_function_t get_function(uint8_t reg_val)
{
        if (0 == (reg_val & DS928_GPIO_ENABLE)) {
                return FUNC_I2S;
        }

        if (reg_val & DS928_GPIO_OUTPUT_REMOTE) {
                return FUNC_REMOTE;
        }

        if (reg_val & DS928_GPIO_INPUT) {
                return FUNC_GPIO_INPUT;
        }

        return FUNC_GPIO_OUTPUT;
}

static
ds90ux9xx_err_t get_gpio_function(const ds90ux9xx_st_t *dev,
        uint8_t num, gpio_function_t *function)
{
        ds90ux9xx_err_t rc;
        uint8_t reg;
        uint8_t val;

        if (NULL == function) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        reg = ds928_gpios[num].reg;

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read GPIO register\n");

                return rc;
        }

        if (ds928_gpios[num].mask == HIGH_HALF) {
                val >>= HIGH_OFFSET;
        } else {
                val &= LOW_HALF;
        }

        *function = get_function(val);

        log_dbg("Got function %d for GPIO_%d\n", *function, num);

        return rc;
}

static
ds90ux9xx_err_t get_gpio_remote(const ds90ux9xx_st_t *dev, uint8_t num,
        gpio_function_t function, gpio_remote_t *remote)
{
        if (NULL == remote) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (FUNC_REMOTE == function) {
                *remote = num;

                log_dbg("Got remote %d for GPIO_%d\n", *remote, num);
        } else {
                *remote = NOT_SPECIFIED;

                log_dbg("No GPIO remote configuration\n");
        }

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub928_get_gpio(const ds90ux9xx_st_t *dev,
        ds90ux9xx_gpio_st_t *gpio)
{
        ds90ux9xx_err_t rc;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == gpio) {
                log_err("gpio is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (true == is_wrong_gpio_number(gpio->num)) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = get_gpio_value(dev, gpio->num, &gpio->value);
        rc |= get_gpio_function(dev, gpio->num, &gpio->function);
        rc |= get_gpio_remote(dev, gpio->num, gpio->function, &gpio->remote);

        return rc;
}

