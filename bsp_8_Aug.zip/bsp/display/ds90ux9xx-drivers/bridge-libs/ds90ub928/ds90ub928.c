/**
 * @file       ds90ub928.c
 * @brief      Driver for 928 bridges that performs actual work with the bridge
 *             and provides callbacks for the bridge driver
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#include <ctype.h>

#include "ds90ux9xx-bridge-libraries.h"

#include "ds90ub928.h"
#include "ds90ub928-gpio.h"

static
ds90ux9xx_err_t set_map_select(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t reg = DS928_REG_MAP_SEL;
        uint8_t val = 0;
        char *bit_order = dev->video_settings.io_phy_settings.bit_order;

        if (0 == dev->map_sel) {
                return rc;
        }

        rc = ds90ux9xx_i2c_read(dev, reg, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't read 0x%x \n", reg);
                goto exit_map_select;
        }

        val |= DS928_MAP_SEL_FROM_REG;

        if (EQUAL == strcmp(bit_order, DS928_MSB)) {
                val |= DS928_MAP_SEL_MSB;
        } else {
                val &= ~DS928_MAP_SEL_MSB;
        }

        rc = ds90ux9xx_i2c_write(dev, reg, val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n", reg, val);
        }

exit_map_select:

        return rc;
}

static
ds90ux9xx_err_t validate_ds90ub928(ds90ux9xx_st_t *dev)
{
        uint8_t val;

        for (int i = 0; i < DEVICE_ID_LEN; i++) {
                ds90ux9xx_i2c_read(dev, DS928_REG_DEV_ID + i, &val);
                log_dbg("Read : 0x%x = 0x%x \n", DS928_REG_DEV_ID + i, val);

                if (i == DS928_SKIP_HB_BYTE) {
                        dev->bridge_type[DS928_HDCP_BYTE] = tolower(val);
                        continue;
                }

                if (val != DEVICE_ID[i]) {
                        return DS90UX9XX_WRONG_CHIP;
                }
        }

        return DS90UX9XX_SUCCESS;
}

static
ds90ux9xx_err_t map_dev_id(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_map);

        rc = ds90ux9xx_i2c_write(dev, DS928_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS928_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write new DEV ID to reg 0x%x\n",
                        DS928_REG_I2C_DEV_ID);
                goto map_dev_error;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_map,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set new id for the i2c\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

map_dev_error:

        return rc;
}

static
ds90ux9xx_err_t unmap_dev_id(const ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t new_i2c_addr;

        if (NULL == dev) {
                log_err("Invalid input: dev = %p\n", dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == dev->i2c_dev) {
                log_err("Invalid input: dev->i2c_dev = %p\n", dev->i2c_dev);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (0 == dev->i2c_dev->i2c_map ||
            dev->i2c_dev->i2c_addr == dev->i2c_dev->i2c_map) {
                log_dbg("Mapping was not provided. No need to unmap\n");

                return DS90UX9XX_SUCCESS;
        }

        new_i2c_addr = TO_I2C_7B(dev->i2c_dev->i2c_addr);

        log_dbg("new_i2c_addr: 0x%x\n", new_i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS928_REG_I2C_DEV_ID,
                                 new_i2c_addr | DS928_I2C_DEV_ID_SET);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map failed. Can't write (0x%x) to reg 0x%x\n",
                        new_i2c_addr | DS928_I2C_DEV_ID_SET,
                        DS928_REG_I2C_DEV_ID);

                return rc;
        }

        if (-1 == i2c_set_slave_addr(dev->i2c_dev->i2c_fd,
                                     dev->i2c_dev->i2c_addr,
                                     I2C_ADDRFMT_7BIT)) {
                log_err("Can't set slave i2c addr\n");
                rc = DS90UX9XX_INIT_FAILURE;
        }

        return rc;
}

static
ds90ux9xx_err_t bridge_reset(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        log_dbg("Attempt to reset bridge with 0x%x value on 0x%x i2c address\n",
                reset_mode, dev->i2c_dev->i2c_addr);

        rc = ds90ux9xx_i2c_write(dev, DS928_REG_RESET, reset_mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS928_REG_RESET, reset_mode);
        }

        return rc;
}

static
ds90ux9xx_err_t init_bridge_limits(ds_bridge_limits_st_t *limits)
{
        if (NULL == limits) {
                log_err("Invalid input: limits = %p\n", limits);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        limits->fpd_ports_count = DS928_FPD_PORTS_COUNT;

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub928_init_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = set_map_select(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map select apply failed\n");
                goto error_init;
        }

        rc = map_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Map i2c dev id failed\n");
        }

error_init:

        return rc;
}

ds90ux9xx_err_t ds90ub928_deinit_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = unmap_dev_id(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Unmap i2c dev id failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90ub928_reset_device(ds90ux9xx_st_t *dev, int reset_mode)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        int mode = DS928_RESET_NORMAL_OPERATION;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (INITIAL_RESET == reset_mode) {
                mode = DS928_RESET_ALL;
        }

        rc = bridge_reset(dev, mode);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge reset failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90ub928_validate_device(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = validate_ds90ub928(dev);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Bridge validation failed\n");
        }

        return rc;
}

ds90ux9xx_err_t ds90ub928_set_tx_port(const ds90ux9xx_st_t *dev,
        fpd_port_t port)
{
        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90ub928_get_fpd_link(ds90ux9xx_st_t *dev,
        ds_fpd_link_st_t *fpd_link)
{
        uint8_t val = 0;
        ds90ux9xx_err_t rc;

        if (NULL == dev || NULL == fpd_link) {
                log_err("Invalid input: dev = %p, fpd_link = %p\n", dev,
                        fpd_link);

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS928_REG_GEN_STATUS, &val);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to read link status. %s\n",
                        ds90ux9xx_err2str(rc));

                return rc;
        }

        if (true == !!(val & DS928_DES_DETECTED)) {
                fpd_link->detect = DS_DETECTED;
        } else {
                fpd_link->detect = DS_NOT_DETECTED;
        }

        return rc;
}

static
ds90ux9xx_err_t ds90ub928_write_reg(const ds90ux9xx_st_t *dev,
        const ds90ux9xx_reg_st_t *reg_data)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("%s Write: type %d; reg 0x%x, value 0x%x\n", dev->name,
                reg_data->type, reg_data->reg, reg_data->value);

        switch (reg_data->type) {
        case DS9XX_MAIN:
                rc = ds90ux9xx_i2c_write(dev, reg_data->reg, reg_data->value);
                break;
        default:
                rc = DS90UX9XX_INVALID_PARAMETER;
        }

        return rc;
}

/*
 * TBD:
 * Following settings might be configured in future
 * [0]   - BIST_EN
 * [2:1] - BIST_CLOCK_SOURCE
 * [3]   - BIST_PIN_CONFIG
 * [7:6] - Reserved
 */
ds90ux9xx_err_t ds90ub928_set_bist_state(const ds90ux9xx_st_t *dev,
        state_t bist_state)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;
        uint8_t bist_control = 0;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        log_dbg("Input: bist state: 0x%x\n", bist_state);

        if (ENABLE == bist_state) {
                bist_control = DS928_BIST_ENABLE;
        } else {
                bist_control = DS928_BIST_DISABLE;
        }

        rc = ds90ux9xx_i2c_write(dev, DS928_REG_BIST_CTL, bist_control);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Can't write 0x%x = 0x%x\n",
                        DS928_REG_BIST_CTL, bist_control);
        }

        return rc;
}

ds90ux9xx_err_t ds90ub928_get_bist_result(ds90ux9xx_st_t *dev,
        bist_result_st_t *bist_result)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        if (NULL == bist_result) {
                log_err("bist result ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        rc = ds90ux9xx_i2c_read(dev, DS928_REG_BIST_ERRORS,
                                &bist_result->bist_err_count);
        if (rc != DS90UX9XX_SUCCESS) {
                log_err("Can't read 0x%x\n", DS928_REG_BIST_ERRORS);

                return rc;
        }

        bist_result->bist_err_count_is_avaliable = 1;

        return rc;
}

ds90ux9xx_err_t library_deinit(ds90ux9xx_st_t *dev)
{
        if (NULL == dev) {
                log_err("ds90ux9xx ptr is NULL\n");

                return DS90UX9XX_INVALID_PARAMETER;
        }

        ds90ux9xx_logger_deinit();

        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh928_map_fpd_i2c_slave(ds90ux9xx_st_t *dev,
        ds90ux9xx_slave_st_t *slave)
{
        /* TODO: Add i2c mapping functionality */
        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh928_set_pass_through(ds90ux9xx_st_t *dev, state_t state)
{
        /* TODO: Add pass_through functionality */
        return DS90UX9XX_SUCCESS;
}

ds90ux9xx_err_t ds90uh928_get_bridge_revision(ds90ux9xx_st_t *dev,
        ds90ux9xx_revision_t *bridge_revision)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        /**
         * TODO: Implement
         */

        return rc;
}

ds90ux9xx_err_t library_init(ds90ux9xx_st_t *dev)
{
        ds90ux9xx_err_t rc = DS90UX9XX_SUCCESS;

        if (NULL == dev) {
                return DS90UX9XX_INVALID_PARAMETER;
        }

        dev->ops.lib_deinit = (operation_fp_t)library_deinit;

        rc = ds90ux9xx_logger_init(dev->bridge_type);
        if (DS90UX9XX_SUCCESS != rc) {
                return DS90UX9XX_INIT_FAILURE;
        }

        rc = init_bridge_limits(&dev->bridge_limits);
        if (DS90UX9XX_SUCCESS != rc) {
                log_err("Failed to init bridge limits. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        rc = init_generic_operations(&dev->ops);
        if (DS90UX9XX_SUCCESS != rc || false == dev->ops.is_initialized) {
                log_err("Can't init bridge operations. Err: %s\n",
                        ds90ux9xx_err2str(rc));

                rc = DS90UX9XX_INIT_FAILURE;
                goto init_failed;
        }

        dev->ops.device[DEINIT_DEVICE] =
                (operation_fp_t)ds90ub928_deinit_device;
        dev->ops.device[GET_BRIDGE_REVISION] =
                (operation_fp_t)ds90uh928_get_bridge_revision;
        dev->ops.device[INIT_DEVICE] =
                (operation_fp_t)ds90ub928_init_device;
        dev->ops.device[RESET_DEVICE] =
                (operation_fp_t)ds90ub928_reset_device;
        dev->ops.device[VALIDATE_DEVICE] =
                (operation_fp_t)ds90ub928_validate_device;

        dev->ops.bist[GET_BIST_RESULT] =
                (operation_fp_t)ds90ub928_get_bist_result;
        dev->ops.bist[SET_BIST_STATE] =
                (operation_fp_t)ds90ub928_set_bist_state;

        dev->ops.fpd[GET_FPD_LINK] =
                (operation_fp_t)ds90ub928_get_fpd_link;
        dev->ops.fpd[SET_TX_PORT] =
                (operation_fp_t)ds90ub928_set_tx_port;

        dev->ops.gpio[SET_GPIO] =
                (operation_fp_t)ds90ub928_set_gpio;
        dev->ops.gpio[GET_GPIO] =
                (operation_fp_t)ds90ub928_get_gpio;

        dev->ops.i2c[MAP_I2C_SLAVE] =
                (operation_fp_t)ds90uh928_map_fpd_i2c_slave;
        dev->ops.i2c[SET_PASS_THROUGH] =
                (operation_fp_t)ds90uh928_set_pass_through;
        dev->ops.i2c[WRITE_REGISTER] =
                (operation_fp_t)ds90ub928_write_reg;

        log_dbg("Initialized successfully\n");

        return rc;

init_failed:
        ds90ux9xx_logger_deinit();

        return rc;
}

