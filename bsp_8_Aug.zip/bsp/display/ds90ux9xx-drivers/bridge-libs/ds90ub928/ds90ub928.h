/**
 * @file       ds90ub928.h
 * @brief      ds90ub928 / ds90uh928 specific registers, configurations
 *
 * @author     Iurii Demchenko <external.iurii.demchenko@de.bosch.com>
 * @author     Mykyta Opaniuk <external.mykyta.opaniuk@de.bosch.com>
 * @author     Roman Kolisnyk <external.roman.kolisnyk@de.bosch.com>
 * @author     Serhii Surazhskyi <external.serhii.surazhskyi@de.bosch.com>
 *
 * @copyright  (c) 2020 Robert Bosch GmbH, Hildesheim
 */

#ifndef __DS90UB928_H__
#define __DS90UB928_H__

#include "ds90ux9xx-core.h"
#include "ds90ux9xx-i2c.h"

#define DEVICE_ID                       "_UB928"
#define DEVICE_ID_LEN                   6

/* DS90UB928 registers */

#define DS928_REG_I2C_DEV_ID            0x0
#define DS928_REG_RESET                 0x1

#define DS928_REG_GEN_STATUS            0x1C

#define DS928_REG_GPIO_0                0x1D
#define DS928_REG_GPIO_1_2              0x1E
#define DS928_REG_GPIO_3                0x1F
#define DS928_REG_GPIO_5_6              0x20
#define DS928_REG_GPIO_7_8              0x21

#define DS928_REG_BIST_CTL              0x24
#define DS928_REG_BIST_ERRORS           0x25

#define DS928_REG_MAP_SEL               0x49

#define DS928_REG_DEV_ID                0xF0

/* DS90UB928 bits and descriptions */
#define DS928_I2C_DEV_ID_SET            BIT(0)

#define DS928_BC_ENABLE                 BIT(2)
#define DS928_RESET_REGISTERS           BIT(1)
#define DS928_NORMAL_OPERATION          0
#define DS928_RESET_ALL                 (DS928_BC_ENABLE |                      \
                                         DS928_RESET_REGISTERS)
#define DS928_RESET_NORMAL_OPERATION    (DS928_BC_ENABLE |                      \
                                         DS928_NORMAL_OPERATION)

#define DS928_DES_DETECTED              BIT(0)
#define DS928_MAP_SEL_FROM_REG          BIT(6)
#define DS928_MAP_SEL_MSB               BIT(5)
#define DS928_BIST_ENABLE               BIT(0)
#define DS928_BIST_DISABLE              0

/* For passing validation for u*H*928, when u*B*928 is used */
#define DS928_SKIP_HB_BYTE              2
#define DS928_HDCP_BYTE                 5

#define DS928_GPIO_NORMAL_OPERATION     0

#define DS928_GPIO_ENABLE               BIT(0)
#define DS928_GPIO_INPUT_ENABLE         BIT(1)
#define DS928_GPIO_REMOTE               BIT(2)
#define DS928_GPIO_HIGH                 BIT(3)

#define DS928_GPIO_OUTPUT_REMOTE        (DS928_GPIO_ENABLE | DS928_GPIO_REMOTE)
#define DS928_GPIO_OUTPUT_HIGH          (DS928_GPIO_ENABLE | DS928_GPIO_HIGH)
#define DS928_GPIO_OUTPUT_LOW           (DS928_GPIO_ENABLE)
#define DS928_GPIO_INPUT                (DS928_GPIO_ENABLE |                    \
                                         DS928_GPIO_INPUT_ENABLE)

#define DS928_MSB                       "msb"

#define DS928_FPD_PORTS_COUNT           1

#endif /* __DS90UB928_H__ */

