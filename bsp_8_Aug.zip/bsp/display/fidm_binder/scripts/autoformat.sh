#!/bin/bash

uncrustify -c .uncrustify --replace --no-backup fidm_binder_lib/src/*.c
uncrustify -c .uncrustify --replace --no-backup fidm_swupdate_test/*.c
uncrustify -c .uncrustify --replace --no-backup fidm_binder_lib/inc/*.h
clang-format -i --style=file ./fidm_binder_lib/src/*.c
clang-format -i --style=file ./fidm_binder_lib/inc/*.h
clang-format -i --style=file ./fidm_swupdate_test/*.c
