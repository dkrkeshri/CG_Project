/**
* @swcomponent fidm firmware update library
* @{
* @file fidmupdate_lib.c
* @brief provide interface for updating display firmware
* @copyright (C) 2020 Robert Bosch GmbH.
*          The reproduction, distribution and utilization of this file as
*          well as the communication of its contents to others without express
*          authorization is prohibited. Offenders will be held liable for the
*          payment of damages. All rights reserved in the event of the grant
*          of a patent, utility model or design.
* @}
*/
#ifdef UNIT_TEST
#include "i2c_header.h"
#else
#include <amss/i2c_client.h>
#endif
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "fidm_binder_common.h"
#include "fidm_binder.h"

#define I2C_READ_1_BYTE_LENGTH   1
#define I2C_READ_2_BYTE_LENGTH   2

#define DEFAULT_I2C_SLAVE_ADDR   0x12
#define DEFAULT_I2C_FIDM_ID      "/dev/i2c3"

/*FIDM　I2C Data Address */
#define FIDM_I2C_RESET_COUNTER         0x2D
#define FIDM_I2C_POWERUP_COUNTER       0x2F
#define FIDM_I2C_DIAGNOSTIC_STATUS_1   0x16
#define FIDM_I2C_DIAGNOSTIC_STATUS_2   0x1C

#define FIDM_DIAG_STATUS_1_DATA_LENGTH	6
#define FIDM_DIAG_STATUS_2_DATA_LENGTH	4
#define FIDM_DIAG_STATUS_1_BYTE_POS     3
#define FIDM_DIAG_STATUS_2_BYTE_POS     2

#define MAX_FIDM_BINDER_DIAG_HANDELS 16

#define GET_STATUS_BIT(var, bit)	(((var) >> (bit)) & 1)

typedef struct {
    fidm_binder_diagnosis_handle handle;
    uint32_t i2c_fd;
    char i2cbusid[20];
    uint8_t slaveaddr;
} fidm_binder_diagnosis;

static fidm_binder_diagnosis handle_map[MAX_FIDM_BINDER_DIAG_HANDELS];
static bool handle_map_initialized = false;
pthread_mutex_t pmutex = PTHREAD_MUTEX_INITIALIZER;

static fidm_binder_diagnosis_handle handle_cnt = 1;

static fidm_binder_diagnosis *fidm_binder_diagnosis_alloc_instance(
    fidm_binder_diagnosis_handle *handle)
{
    /* The complete logic shall be protected with a pmutex */
    fidm_binder_diagnosis *udp_tmp = NULL;
    pthread_mutex_lock(&pmutex);

    if (!handle_map_initialized) {
        memset(handle_map, 0, sizeof(handle_map));
        handle_map_initialized = 1;
    }

    for (int32_t i = 0; i < MAX_FIDM_BINDER_DIAG_HANDELS; i++) {
        if (!handle_map[i].handle) {
            *handle = handle_cnt;
            handle_map[i].handle = handle_cnt;
            handle_cnt++;
            udp_tmp = &handle_map[i];
            break;
        }
    }
    pthread_mutex_unlock(&pmutex);
    return udp_tmp;
}

static fidm_binder_diagnosis *fidm_binder_diagnosis_find_instance(
    fidm_binder_diagnosis_handle handle)
{
    int32_t i;

    if (!handle_map_initialized) {
        return NULL;
    }

    for (i = 0; i < MAX_FIDM_BINDER_DIAG_HANDELS; i++) {
        if (handle_map[i].handle == handle)
            return &handle_map[i];
    }

    return NULL;
}

#ifdef UNIT_TEST
void fidm_binder_diagnosis_dealloc_instance(
    fidm_binder_diagnosis_handle handle)
#else
static void fidm_binder_diagnosis_dealloc_instance(
    fidm_binder_diagnosis_handle handle)
#endif
{
    fidm_binder_diagnosis *upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd)
        return;

    upd->handle = 0;
}

/**
 * @brief Function to init the diagnosis client
 *
 * @param [in] Handle to be passed to fidm_binder_diagnosis_client_init.
 * @return ::EOK if getting the display info successfully and error code
 * otherwise.
 */
EXPORT_API fidm_binder_diagnosis_handle fidm_binder_diagnosis_client_init(
    const char *devnode_status, const char *devnode_control)
{
    fidm_binder_diagnosis *upd = NULL;
    fidm_binder_diagnosis_handle handle = 0;

    upd = fidm_binder_diagnosis_alloc_instance(&handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "No free instnces found");
        return -1;
    }
    snprintf(upd->i2cbusid, sizeof(upd->i2cbusid), devnode_status);
    upd->slaveaddr = atoi(devnode_control);
    upd->i2c_fd = i2c_open(upd->i2cbusid);
    if (-1 == upd->i2c_fd) {
        /* Lets mark this instance as freely available once again and
         * return a failure result */
        fidm_binder_diagnosis_dealloc_instance(handle);
        DEBUG_PRINT(stderr, "i2c_open() FAILED, iRetVal=%d\n", upd->i2c_fd);
        return -1;
    }

    return handle;
}

EXPORT_API int32_t fidm_binder_diagnosis_query_blob(
           fidm_binder_diagnosis_handle handle,uint16_t base_address,
           char *buf,size_t buf_size)
{
    fidm_binder_diagnosis *upd;
    int32_t ret = 0;
    uint8_t *diag_val = NULL;

    if(!buf)
    {
        return FIDM_UPDATE_PEC_Err_BufNull;
    }

    diag_val = (uint8_t *)buf;

    /* Let us find an instance by its handle */
    upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", handle);
        return -1;
    }

    ret = i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read Diagnostic status 1 */
    if(FIDM_I2C_DIAGNOSTIC_STATUS_1 == base_address)
    {

           ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DIAGNOSTIC_STATUS_1, diag_val,
                        FIDM_DIAG_STATUS_1_DATA_LENGTH);
           if (ret < 0) {
               DEBUG_PRINT(stderr, "i2c read diagnostic status 1 failed, iRetVal=%d\n",
                           ret);
               return ret;
           }

    }

    /* Read Diagnostic status 2 */
    if(FIDM_I2C_DIAGNOSTIC_STATUS_2 == base_address)
    {
           ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DIAGNOSTIC_STATUS_2, diag_val,
                        FIDM_DIAG_STATUS_2_DATA_LENGTH);
           if (ret < 0) {
               DEBUG_PRINT(stderr, "i2c read diagnostic status 2 failed, iRetVal=%d\n",
                           ret);
               return ret;
           }

    }

    return buf_size;
}

EXPORT_API int32_t fidm_binder_diagnosis_query_details(
           fidm_binder_diagnosis_handle handle, FidmDiagnosisDetails *details)
{
    fidm_binder_diagnosis *upd;
    int32_t ret = 0;
    uint8_t diag1_buf[FIDM_DIAG_STATUS_1_DATA_LENGTH] = {0};
    uint8_t diag2_buf[FIDM_DIAG_STATUS_2_DATA_LENGTH] = {0};
    uint8_t ReceivedCRC = 0, ComputedCRC = 0;

    /* Let us find an instance by its handle */
    upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", handle);
        return -1;
    }

    ret = i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read Diagnostic status 1 */
       ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DIAGNOSTIC_STATUS_1, diag1_buf,
                        FIDM_DIAG_STATUS_1_DATA_LENGTH);
       if (ret < 0) {
           DEBUG_PRINT(stderr, "i2c read diagnostic status 1 failed, iRetVal=%d\n",
                       ret);
           return ret;
       } 


    ReceivedCRC = diag1_buf[0]; /* 8 bit CRC value computed over next 5 bytes */
    /* Compute Checksum for next 5 bytes */
    ComputedCRC = fidm_compute_CRC8_SAE_J180((diag1_buf+1), (sizeof(diag1_buf)-1));

    if(ComputedCRC == ReceivedCRC)
    {
        details->oldi_edp_error              = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],0);
        details->display_error               = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],1);
        details->display_temporary_shutoff   = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],2);
        details->gate_source_driver_error    = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],3);
        details->watchdog_or_mcu_reset_error = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],4);
        details->abnormal_poweron_reset      = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],5);
        details->i2c_management_error        = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],6);
        details->lvds_link_lock_error        = GET_STATUS_BIT(diag1_buf[FIDM_DIAG_STATUS_1_BYTE_POS],7);
    }
    else
    {
        DEBUG_PRINT(stderr, "CRC checksum error for Diagnostic status 1\n");
        return -1;
    }

    /* Read Diagnostic status 2 */
       ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DIAGNOSTIC_STATUS_2, diag2_buf,
                        FIDM_DIAG_STATUS_2_DATA_LENGTH);
       if (ret < 0) {
           DEBUG_PRINT(stderr, "i2c read diagnostic status 2 failed, iRetVal=%d\n",
                       ret);
           return ret;
       }


    ReceivedCRC = diag2_buf[0]; /* 8 bit CRC value computed over next 3 bytes */
    /* Compute Checksum for next 3 bytes */
    ComputedCRC = fidm_compute_CRC8_SAE_J180((diag2_buf+1), (sizeof(diag2_buf)-1));

    if(ComputedCRC == ReceivedCRC)
    {
        details->backlight_error              = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],0);
        details->backlight_led_fault          = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],1);
        details->backlight_over_voltage       = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],2);
        details->backlight_under_voltage      = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],3);
        details->backlight_over_current       = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],4);
        details->backlight_temperature_high   = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],5);
        details->backlight_temperature_low    = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],6);
        details->backlight_error_occurred     = GET_STATUS_BIT(diag2_buf[FIDM_DIAG_STATUS_2_BYTE_POS],7);
    }
    else
    {
        DEBUG_PRINT(stderr, "CRC checksum error for Diagnostic status 2\n");
        return -1;
    }

    return ret;
}

/**
 * @brief Function to query the FIDM reset count
 *
 * @param [in] Handle to be passed to fidm_binder_diagnosis_query_powerup_count
 * @param [out] Return the FIDM reset count
 * @return ::EOK if getting the display info successfully and error code
 * otherwise.
 */
EXPORT_API int32_t fidm_binder_diagnosis_query_reset_count(
           fidm_binder_diagnosis_handle handle,uint16_t *count)
{
    fidm_binder_diagnosis *upd;
    uint8_t val[2];
    int32_t ret = 0;

    /* Let us find an instance by its handle */
    upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", handle);
        return -1;
    }

    ret = i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read Reset Counter */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_RESET_COUNTER, val,
                        I2C_READ_2_BYTE_LENGTH);
    if (ret < 0) {
        DEBUG_PRINT(stderr, "i2c read firmware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        *count = val[0] | (val[1] << 8);
    }

    return 0;
}

/**
 * @brief Function to query the FIDM powerup count
 *
 * @param [in] Handle to be passed to fidm_binder_diagnosis_query_powerup_count
 * @param [out] Return the FIDM powerup count
 * @return ::EOK if getting the display info successfully and error code
 * otherwise.
 */
EXPORT_API int32_t fidm_binder_diagnosis_query_powerup_count(
           fidm_binder_diagnosis_handle handle,uint16_t *count)
{
    fidm_binder_diagnosis *upd;
    uint8_t val[2];
    int32_t ret = 0;

    /* Let us find an instance by its handle */
    upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", handle);
        return -1;
    }

    ret = i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read Powerup Counter */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_POWERUP_COUNTER, val,
                        I2C_READ_2_BYTE_LENGTH);
    if (ret < 0) {
        DEBUG_PRINT(stderr, "i2c read firmware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        *count = val[0] | (val[1] << 8);
    }

    return 0;
}

/**
 * @brief Function to deinit the FIDM binder diagnosis clinet
 *
 * @param [in] Handle to be passed to fidm_binder_diagnosis_client_deinit.
 * @return ::NULL.
 */

EXPORT_API void fidm_binder_diagnosis_client_deinit(fidm_binder_diagnosis_handle handle)
{
    fidm_binder_diagnosis *upd;

    upd = fidm_binder_diagnosis_find_instance(handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", handle);
        return;
    }

    i2c_close(upd->i2c_fd);
    fidm_binder_diagnosis_dealloc_instance(handle);
}
