/**
* @swcomponent fidm firmware update library
* @{
* @file fidmupdate_lib.c
* @brief provide interface for updating display firmware
* @copyright (C) 2020 Robert Bosch GmbH.
*          The reproduction, distribution and utilization of this file as
*          well as the communication of its contents to others without express
*          authorization is prohibited. Offenders will be held liable for the
*          payment of damages. All rights reserved in the event of the grant
*          of a patent, utility model or design.
* @}
*/
#ifdef UNIT_TEST
#include "i2c_header.h"
#else
#include <amss/i2c_client.h>
#endif
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "fidm_binder_common.h"
#include "fidm_binder.h"

#define I2C_BUS_ID_MAX_LENGTH 0x10
#define I2C_WRITE_2_BYTE_LENGTH 2
#define I2C_WRITE_MAX_LENGTH 72
#define I2C_READ_1_BYTE_LENGTH 1
#define I2C_READ_2_BYTE_LENGTH 2
#define I2C_READ_8_BYTE_LENGTH 8

#define DEFAULT_I2C_SLAVE_ADDR 0x12
#define DEFAULT_I2C_FIDM_ID "/dev/i2c5"
#define SER_ID_7BIT   0x0C
#define GENERAL_STS 0x0C
#define DISP_ID_INNOLUX_8_IPD       0x0
#define DISP_ID_INNOLUX_11_IPD      0x02
#define DISP_ID_INNULUX_11_VCD      0x05
#define DISP_ID_INNULUX_34_VCD      0x08
#define DISP_ID_BUICK_FF            0x09

/*FIDM　REGISTERS BITS */
#define FIDM_I2C_HARDWARE_VERSION          0x00
#define FIDM_I2C_FIRMWARE_VERSION          0x02
#define FIDM_I2C_TOUCH_ID                  0x04
#define FIDM_I2C_DISPLAY_ID                0x05
#define FIDM_I2C_HVAC_SWITCH_PACK_PRESENT  0x06
#define FIDM_I2C_SOFTWARE_PART_NUMBER      0x60
#define FIDM_I2C_HARDWARE_PART_NUMBER      0x68
#define FIDM_I2C_FORCE_RESET               0x31
#define FIDM_I2C_PROGRAM_UPDATE            0x34
#define FIDM_I2C_BOOTLOADER_STATUS1        0x80
#define FIDM_I2C_BOOTLOADER_STATUS2        0x81
#define FIDM_I2C_CMD_LOCK_MEMORY           0x84
#define FIDM_I2C_CMD_ERASE_MEMORY          0x88
#define FIDM_I2C_CMD_WRITE_FLASH           0x8D
#define FIDM_FLASH_BASEADDRESS_INNOLUX      0x3000
#define FIDM_FLASH_BASEADDRESS_AUO          0x4000

#define FIDM_ACCESSKEY0 0x55AA
#define FIDM_ACCESSKEY1 0x33CC
// if the application is invalid (CRC32 does not match)
// and a POR occurs the Session Key is set to zero.
#define FIDM_SESSIONKEY0 0x0000
#define FIDM_SESSIONKEY1 0xFFFF // any non-zero value
#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80

#define MAX_FIDM_UPDATER_HANDELS 16


typedef struct {
    fidm_update_handle handle;
    uint32_t i2c_fd;
    char i2cbusid[20];
    uint8_t slaveaddr;
    FidmVersionInfo info;
} fidm_update_private;

static fidm_update_private handle_map[MAX_FIDM_UPDATER_HANDELS];
static bool handle_map_initialized = false;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

static fidm_update_handle handle_cnt = 1;

static fidm_update_private *fidm_swupdater_alloc_instance(
    fidm_update_handle *handle)
{
    /* The complete logic shall be protected with a mutex */
    fidm_update_private *udp_tmp = NULL;
    pthread_mutex_lock(&mutex);

    if (!handle_map_initialized) {
        memset(handle_map, 0, sizeof(handle_map));
        handle_map_initialized = 1;
    }

    for (int32_t i = 0; i < MAX_FIDM_UPDATER_HANDELS; i++) {
        if (!handle_map[i].handle) {
            *handle = handle_cnt;
            handle_map[i].handle = handle_cnt;
            handle_cnt++;
            udp_tmp = &handle_map[i];
            break;
        }
    }
    pthread_mutex_unlock(&mutex);
    return udp_tmp;
}

static fidm_update_private *fidm_swupdater_find_instance(
    fidm_update_handle handle)
{
    int32_t i;

    if (!handle_map_initialized) {
        return NULL;
    }

    for (i = 0; i < MAX_FIDM_UPDATER_HANDELS; i++) {
        if (handle_map[i].handle == handle)
            return &handle_map[i];
    }

    return NULL;
}
#ifdef UNIT_TEST
void fidm_swupdater_dealloc_instance(
    fidm_update_handle handle)
#else
static void fidm_swupdater_dealloc_instance(
    fidm_update_handle handle)
#endif
{
    fidm_update_private *upd = fidm_swupdater_find_instance(handle);
    if (!upd)
        return;

    upd->handle = 0;
}

int32_t fidm_swupdater_status_check(uint32_t status,FIDM_BootLoaderStatus eBLStatus)
{
    int32_t ret = 0;
    if (eBLStatus == FIDM_Default) {
      if (((eBLStatus << status ) & status) == 0)
          ret = 1;
    } else {
       /*if case of no bootloader status error */
       if (eBLStatus & status)
          ret = 1;
       else
          ret = 0;
    }
    return ret;
}

int32_t fidm_swupdater_status_loop(int32_t i2c_fd,FIDM_BootLoaderStatus eBLStatus)
{
	uint8_t readdata[1] = { 0 };
	int32_t i;
	int32_t ret;
	for (i = 0; i < 50; i++) {
		ret = fidm_i2c_read(i2c_fd, FIDM_I2C_BOOTLOADER_STATUS1, &readdata[0],
		I2C_READ_1_BYTE_LENGTH);
               if(ret < 0)
               {
                   DEBUG_PRINT(stderr, "fidm i2c read read failed ret:%d\n",ret);
               }
		ret = fidm_swupdater_status_check(readdata[0], eBLStatus);
		if (1 != ret)
			(void) usleep(100 * 1000);
		else
                        break;
	}
	DEBUG_PRINT(stderr, "%s: Readed 0x80 = 0x%02x", __func__, readdata[0]);
	return ret;
}

/**
 * @brief Function to init the swupdater clinet
 *
 * @param [in] Handle to be passed to fidm_swupdater_client_init.
 * @return ::EOK if getting the display info successfully and error code
 * otherwise.
 */
EXPORT_API fidm_update_handle fidm_swupdater_client_init(
    const char *devnode_status, const char *devnode_control)
{
    fidm_update_private *upd = NULL;
    fidm_update_handle handle = 0;

    upd = fidm_swupdater_alloc_instance(&handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "No free instnces found");
        return FIDM_UPDATE_PEC_Err_Instance;
    }
    snprintf(upd->i2cbusid, sizeof(upd->i2cbusid), devnode_status);
    upd->slaveaddr = atoi(devnode_control);
    upd->i2c_fd = i2c_open(upd->i2cbusid);
    if (-1 == upd->i2c_fd) {
        /* Lets mark this instance as freely available once again and
         * return a failure result */
        fidm_swupdater_dealloc_instance(handle);
        DEBUG_PRINT(stderr, "i2c_open() FAILED, iRetVal=%d\n", upd->i2c_fd);
        return FIDM_UPDATE_PEC_Err_Instance;
    }
    DEBUG_PRINT(stderr, "client init, i2c bus=%s slaveaddr=0x%02x\n", upd->i2cbusid,upd->slaveaddr);
    return handle;
}

/**
 * @brief Function to get the FIDM display info
 *
 * @param [in] Handle to be passed to fidm_swupdater_client_get_info.
 * @return ::EOK if getting the display info successfully and error code
 * otherwise.
 */
EXPORT_API int32_t fidm_swupdater_client_get_info(
    fidm_update_handle fidm_handle, FidmVersionInfo *FidmVersionInfo)
{
    fidm_update_private *upd;
    uint8_t val[2];
    int32_t ret = FIDM_UPDATE_PEC_NO_Error;

    /* Let us find an instance by its handle */
    upd = fidm_swupdater_find_instance(fidm_handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", fidm_handle);
        return FIDM_UPDATE_PEC_Err_Instance;
    }

    ret = i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return FIDM_UPDATE_PEC_Err_Instance;
    }

    /* Read Display ID */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DISPLAY_ID, &val[0],
                        I2C_READ_1_BYTE_LENGTH);
    FidmVersionInfo[0].DisplayID = val[0];

    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read hardware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }

    /* Read Hardware version */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_HARDWARE_VERSION, val,
                        I2C_READ_2_BYTE_LENGTH);
    FidmVersionInfo[0].HardwareVer = val[0] | (val[1] << 8);

    if (FIDM_UPDATE_PEC_Err_DuringRead == ret) {
        DEBUG_PRINT(stderr, "i2c read hardware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }

    /* Read Firmware version */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_FIRMWARE_VERSION, val,
                        I2C_READ_2_BYTE_LENGTH);
    FidmVersionInfo[0].FirmwareVer = val[0] | (val[1] << 8);

    if (FIDM_UPDATE_PEC_Err_DuringRead == ret) {
        DEBUG_PRINT(stderr, "i2c read firmware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }

    return ret;
}

/**
 * @brief Function to do the firmware update
 *
 * @param [in] Handle to be passed to the update funtion.
 * @param [in] the information need to update.
 * @return ::EOK if firmware is updated successfully and error code otherwise.
 */
EXPORT_API int32_t fidm_swupdater_client_do_update(
    fidm_update_handle fidm_handle, const DisplayUpdateParams *update_params)
{
    uint8_t cmd_bl[2] = {0}, cmd_softreset[1] = {2}, cmd_unlock[4] = {0}, cmd_erase[5] = {0},
        cmd_update[71] = {0},val[2] = {0};
    uint16_t crc_send;
    uint8_t readdata[2] = {0};
    uint32_t fidm_sessionkey = FIDM_SESSIONKEY1;
    uint32_t fidm_flash_address = 0;
    float fraction;
    uint8_t *firmware = NULL;
    fidm_update_private *upd;
    int32_t size;
    int32_t ret = 0;
    int32_t i = 0;

    bool is_bootloadermode = false;

    /* Let us find an instance by its handle */
    upd = fidm_swupdater_find_instance(fidm_handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", fidm_handle);
        return FIDM_UPDATE_PEC_Err_Instance;
    }

    size = fidm_get_binsize(update_params->fw_filename);
    if (FIDM_UPDATE_PEC_Err_FileOpen == size) {
        DEBUG_PRINT(stderr, "get the firmware bin size error: %d", size);
        return FIDM_UPDATE_PEC_Err_FileOpen;
    }
    DEBUG_PRINT(stderr, "do_update, bin size=%d name=%s\n", size,update_params->fw_filename);

    firmware = (uint8_t *) calloc(sizeof(uint8_t), size);
    if (!firmware) {
        DEBUG_PRINT(stderr, "Memory error!\n");
        free(firmware);
        return FIDM_UPDATE_PEC_Err_Insufficientvirtualmemory;
    }
    // get all the binary value from FIDM_1080p_10IN_HW4MIN_SW*.bin to
    // firmware[]
    ret = fidm_read_bin(update_params->fw_filename, firmware, size);
    if (FIDM_UPDATE_PEC_Err_FileOpen == ret) {
        DEBUG_PRINT(stderr, "read the firmware bin error: %d", size);
        free(firmware);
        return FIDM_UPDATE_PEC_Err_FileOpen;
    }

    i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
    
    /*read display id to choose fidm_flash_address*/
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_DISPLAY_ID, &val[0],
                        I2C_READ_1_BYTE_LENGTH);

    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read display id FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }
    switch (val[0])
    {
      case DISP_ID_INNOLUX_8_IPD:
      case DISP_ID_INNOLUX_11_IPD:
      case DISP_ID_INNULUX_11_VCD:
      case DISP_ID_INNULUX_34_VCD:
           fidm_flash_address = FIDM_FLASH_BASEADDRESS_INNOLUX;
           break;
      case DISP_ID_BUICK_FF:
           fidm_flash_address = FIDM_FLASH_BASEADDRESS_AUO;
           break;
      default:
           break;
    }

    /* Looks like the next block could be extracted to a function... */
    ret = fidm_i2c_read(upd->i2c_fd, FIDM_I2C_BOOTLOADER_STATUS1, &readdata[0],
                  I2C_READ_2_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read bootloader status FAIL, iRetVal=%d\n",
                    ret);
        free(firmware);
        return ret;
    }
    if (FIDM_BLModeActive == readdata[0]) {
        is_bootloadermode = true;
        DEBUG_PRINT(stderr, "FIDM is in bootloader mode val=%d\n",readdata[0]);
    }
    if (is_bootloadermode) {
        fidm_sessionkey = FIDM_SESSIONKEY0;
    } else {
        DEBUG_PRINT(stderr, "FIDM is not in bootloader mode val=%d\n",readdata[0]);
        fidm_sessionkey = FIDM_SESSIONKEY1;
        cmd_bl[0] = FIDM_ACCESSKEY0 & 0xFF;
        cmd_bl[1] = (FIDM_ACCESSKEY0 & 0xFF00) >> 8;
        fidm_i2c_write(upd->i2c_fd, FIDM_I2C_PROGRAM_UPDATE, cmd_bl,
                       sizeof(cmd_bl) + 1);

        cmd_bl[0] = FIDM_ACCESSKEY1 & 0xFF;
        cmd_bl[1] = (FIDM_ACCESSKEY1 & 0xFF00) >> 8;
        fidm_i2c_write(upd->i2c_fd, FIDM_I2C_PROGRAM_UPDATE, cmd_bl,
                       sizeof(cmd_bl) + 1);

        cmd_bl[0] = fidm_sessionkey & 0xFF;
        cmd_bl[1] = (fidm_sessionkey & 0xFF00) >> 8;
        fidm_i2c_write(upd->i2c_fd, FIDM_I2C_PROGRAM_UPDATE, cmd_bl,
                       sizeof(cmd_bl) + 1);

        cmd_softreset[0] = 0x02;
        fidm_i2c_write(upd->i2c_fd, FIDM_I2C_FORCE_RESET, cmd_softreset,
                       sizeof(cmd_softreset) + 1);
        /*need to check if the FIDM can display and the communication is OK*/
        (void)sleep(12);
        i2c_set_slave_addr(upd->i2c_fd, SER_ID_7BIT, 0);
        ret = fidm_98x_link(upd->i2c_fd);
        if (true != ret) {
            DEBUG_PRINT(stderr, "FIDM link error, Data=0x%x\n", ret);
            free(firmware);
            return FIDM_UPDATE_PEC_Err_DuringRead;
        }
        i2c_set_slave_addr(upd->i2c_fd, upd->slaveaddr, 0);
        ret = fidm_swupdater_status_loop(upd->i2c_fd,FIDM_BLModeActive);
        if (true != ret) {
            DEBUG_PRINT(stderr, "FIDM_BLMODE FAILED\n");
            free(firmware);
            return FIDM_UPDATE_PEC_Err_ProgramException;
        }
    }

    cmd_unlock[0] = fidm_sessionkey & 0xFF;
    cmd_unlock[1] = (fidm_sessionkey & 0xFF00) >> 8;
    crc_send = fidm_crc16_xmodem(cmd_unlock, sizeof(cmd_unlock) - 2);
    cmd_unlock[2] = crc_send;
    cmd_unlock[3] = crc_send >> 8;
    fidm_i2c_write(upd->i2c_fd, FIDM_I2C_CMD_LOCK_MEMORY, cmd_unlock,
                   sizeof(cmd_unlock) + 1);

    ret = fidm_swupdater_status_loop(upd->i2c_fd,FIDM_AppUnlocked);

    if (true != ret) {
        DEBUG_PRINT(stderr, "FIDM_AppUnlocked FAILED\n");
        free(firmware);
        return FIDM_UPDATE_PEC_Err_ProgramException;
    }

    cmd_erase[0] = fidm_sessionkey & 0xFF;
    cmd_erase[1] = (fidm_sessionkey & 0xFF00) >> 8;
    cmd_erase[2] = 0xA5;
    crc_send = fidm_crc16_xmodem(cmd_erase, sizeof(cmd_erase) - 2);
    cmd_erase[3] = crc_send;
    cmd_erase[4] = crc_send >> 8;
    fidm_i2c_write(upd->i2c_fd, FIDM_I2C_CMD_ERASE_MEMORY, cmd_erase,
                   sizeof(cmd_erase) + 1);

    ret = fidm_swupdater_status_loop(upd->i2c_fd,FIDM_AppErased);
    if (true != ret) {
        DEBUG_PRINT(stderr, "FIDM_AppErased FAILED");
        free(firmware);
        return FIDM_UPDATE_PEC_Err_EraseSW;
    }

    for (int32_t icount = 0; icount < size; icount = icount + 64) {
        cmd_update[0] = fidm_sessionkey & 0xFF;
        cmd_update[1] = (fidm_sessionkey & 0xFF00) >> 8;
        cmd_update[2] = fidm_flash_address & 0xff;
        cmd_update[3] = (fidm_flash_address & 0xff00) >> 8;
        cmd_update[4] = (fidm_flash_address & 0xff0000) >> 16;
        for (int32_t jcount = 5; jcount < 69; jcount++)
            cmd_update[jcount] = firmware[jcount - 5 + icount];

        crc_send = fidm_crc16_xmodem(cmd_update, sizeof(cmd_update) - 2);
        cmd_update[69] = crc_send;
        cmd_update[70] = crc_send >> 8;
        for (i = 0; i < 5; i++) {
            fidm_i2c_write(upd->i2c_fd, FIDM_I2C_CMD_WRITE_FLASH, cmd_update,
                    sizeof(cmd_update) + 1);
            (void) usleep(40 * 1000);
            ret = fidm_swupdater_status_loop(upd->i2c_fd, FIDM_WriteSucceed);
            if (true == ret)
                break;
        }
        if (i == 5) {
            free(firmware);
            return FIDM_UPDATE_PEC_Err_ProgramException;
        }

        fidm_flash_address += 0x40; // offset 64 bytes
        fraction = ((icount+64)*1.0)/size;
        update_params->show_progress(fraction,100);
    }
    free(firmware);
    /* reset FIDM after completing the firmware updating */
    fidm_i2c_write(upd->i2c_fd, FIDM_I2C_FORCE_RESET, cmd_softreset,
                   sizeof(cmd_softreset) + 1);
    (void)sleep(5);
    /*TBD - I think here we need to check bootloader status check 2*/
    /*Byte1:Bootloader Status2 - 0: Programming Error, 1: Unknown Error*/
    ret = fidm_swupdater_status_loop(upd->i2c_fd,FIDM_Default);
    if (true != ret) {
            DEBUG_PRINT(stderr, "Reset FIDM controler FAILED");
            return FIDM_UPDATE_PEC_Err_ProgramException;
    }
    DEBUG_PRINT(stderr, "FIDM SW update completed Data=%d\n",ret);
    
    return FIDM_UPDATE_PEC_NO_Error;
}

/**
 * @brief Function to deinit the swupdater clinet
 *
 * @param [in] Handle to be passed to fidm_swupdater_client_deinit.
 * @return ::NULL.
 */

EXPORT_API void fidm_swupdater_client_deinit(fidm_update_handle fidm_handle)
{
    fidm_update_private *upd;

    upd = fidm_swupdater_find_instance(fidm_handle);
    if (!upd) {
        DEBUG_PRINT(stderr, "Instance not found for <%d> handle", fidm_handle);
        return;
    }

    i2c_close(upd->i2c_fd);
    fidm_swupdater_dealloc_instance(fidm_handle);
    DEBUG_PRINT(stderr, "client de init \n");
}

/**
 * @brief Function to get the FIDM query device info
 *
 * @param [in] devnode_status - I2C bus id to be passed.
 *        [in] devnode_control - I2C slave address to be passed.
 *        [out] fidm_device_info - FIDM device information related information
 * @return : EOK if getting the device info successfully
 *           and error code otherwise.
 */

EXPORT_API int32_t fidm_binder_query_device_info(
    const char *devnode_status, const char *devnode_control,FidmDeviceInfo *fidm_device_info)
{
    uint32_t i2c_fd = 0;
    char i2cbusid[20] = {0};
    uint8_t slaveaddr = 0;
    uint8_t val[8] = {0,0};
    int32_t ret = 0;
    uint8_t *hardware_part = &(fidm_device_info->hardware_part[0]);
    uint8_t *software_part = &(fidm_device_info->software_part[0]);

    snprintf(i2cbusid, sizeof(i2cbusid), devnode_status);
    slaveaddr = atoi(devnode_control);

    /* I2C open */
    i2c_fd = i2c_open(i2cbusid);
    if (-1 == i2c_fd) {
        /* Lets mark this instance as freely available once again and
         * return a failure result */
        DEBUG_PRINT(stderr, "i2c_open() FAILED, iRetVal=%d \n", i2c_fd);
        return -1;
    }

    /* I2C set slave address */
    ret = i2c_set_slave_addr(i2c_fd, slaveaddr, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read Display ID */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_DISPLAY_ID, &val[0],
                        I2C_READ_1_BYTE_LENGTH);

    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read display id FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        fidm_device_info->display_id = val[0];
    }

    /* Read touch ID */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_TOUCH_ID, &val[0],
                        I2C_READ_1_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read touch id FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        fidm_device_info->touch_id = val[0];
    }

    /* Read Hardware part number */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_HARDWARE_PART_NUMBER, hardware_part,
                        I2C_READ_8_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read hardware part FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }

    /* Read Software part number */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_SOFTWARE_PART_NUMBER, software_part,
                        I2C_READ_8_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read software part FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    }

    /* Read Hardware version */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_HARDWARE_VERSION, val,
                        I2C_READ_2_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read hardware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        fidm_device_info->hardware_version = val[0] | (val[1] << 8);
    }

    /* Read Firmware version */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_FIRMWARE_VERSION, val,
                        I2C_READ_2_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read firmware version FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        fidm_device_info->firmware_version = val[0] | (val[1] << 8);
    }

    /* Read hvac switch pack present status */
    ret = fidm_i2c_read(i2c_fd, FIDM_I2C_HVAC_SWITCH_PACK_PRESENT, &val[0],
                        I2C_READ_1_BYTE_LENGTH);
    if (1 == ret) {
        DEBUG_PRINT(stderr, "i2c read hvac switch pack status FAIL, iRetVal=%d\n",
                    ret);
        return ret;
    } else {
        fidm_device_info->hvac_switch_pack_present = val[0];
    }

    /* I2C close */
    i2c_close(i2c_fd);
    return ret;
}

EXPORT_API int32_t fidm_binder_query_device_link(
    const char *devnode_status,uint16_t serializer_i2c_address)
{
    uint32_t i2c_fd = 0;
    int8_t i2cbusid[20] = {0};
    uint8_t val[2] = {0,0};
    int32_t ret = 0;

    snprintf((char *)i2cbusid, sizeof(i2cbusid), devnode_status);

    /* I2C open */
    i2c_fd = i2c_open(i2cbusid);
    if (-1 == i2c_fd) {
        /* Lets mark this instance as freely available once again and
         * return a failure result */
        DEBUG_PRINT(stderr, "i2c_open() FAILED, iRetVal=%d \n", i2c_fd);
        return -1;
    }

    /* I2C set slave address */
    ret = i2c_set_slave_addr(i2c_fd, serializer_i2c_address, 0);
    if (-1 == ret) {
        DEBUG_PRINT(stderr, "Set slave addr FAILED, iRetVal=%d\n", ret);
        return ret;
    }

    /* Read link detect */
    ret = fidm_i2c_read(i2c_fd, GENERAL_STS, &val[0],
                        I2C_READ_1_BYTE_LENGTH);

    if (0 == ret) {
        ret = (val[0] & 0x01);
      } else {
        ret = -1;
    }
    
    /* I2C close */
    i2c_close(i2c_fd);

    return ret;
}
