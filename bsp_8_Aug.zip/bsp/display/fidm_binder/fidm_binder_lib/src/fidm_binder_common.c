/*! \file */
/*
   ===========================================================================

FILE:  fidm_common.c

$File: $

===========================================================================
Copyright (c) 2020 Bosch Automotive Products (Suzhou) Co.,Ltd(RBAC).
All Rights Reserved.
RBAC Proprietary and Confidential.
===========================================================================
*/

/* -----------------------------------------------------------------------
 ** Includes
 ** ----------------------------------------------------------------------- */
#ifdef UNIT_TEST
#include "i2c_header.h"
#include "slog2_header.h"
#include <errno.h>
#else
#include <amss/i2c_client.h>
#include <sys/slog2.h>
#endif
#include <stdlib.h>
#include <stdbool.h>
#include "fidm_binder_common.h"

#define FIDM_I2C_STATUS_OK 0
#define FIDM_I2C_STATUS_ERROR -1
#define FIDM_BUFFER_NAME  "top_level_fidm_api"
/*------------------------------------------------------------------------------
 * Prototypes
 *----------------------------------------------------------------------------*/
static slog2_buffer_set_config_t sfidmBufferConfig;
static slog2_buffer_t pfidmBufferHandle[1];
static bool fidm_slog_initialized = false;

void fidm_logger_init(void)
{
    int ret ;

    if (!fidm_slog_initialized) {
        // Create buffers for slog2
        sfidmBufferConfig.buffer_set_name = FIDM_BUFFER_NAME;
        sfidmBufferConfig.num_buffers = 1;
        sfidmBufferConfig.verbosity_level = SLOG2_INFO;

        sfidmBufferConfig.buffer_config[0].buffer_name = "fidm";
        sfidmBufferConfig.buffer_config[0].num_pages = 1;
        ret = slog2_register(&sfidmBufferConfig, pfidmBufferHandle, 0);
        if (- 1 == ret) {
            fprintf(stderr, "%s Failed to register slogger2 buffer[%d]\n",
                    __FUNCTION__,ret);
        } else {
            fidm_slog_initialized = true;
            DEBUG_PRINT(stdout,"%s register slogger2 buffer[%d] succcess\n",
                    __FUNCTION__,ret);
        }
    }

    return ;
}

void fidm_printf(FILE *fp, const char *format, ...)
{
    va_list args;
    va_start(args, format);
    if (!fidm_slog_initialized){
	fidm_logger_init();
    }
    if (fidm_slog_initialized) {
        vslog2f(pfidmBufferHandle[0], 0, SLOG2_INFO, format, args);
    } else {
        fprintf(fp, format, args);
    }
    va_end(args);
}


int32_t fidm_read_bin(const char *path, uint8_t *buf, uint32_t size)
{
    FILE *infile;
    size_t rc;

    if ((infile = fopen(path, "rb")) == NULL) {
        DEBUG_PRINT(stderr,"Can not open the path: %s \n", path);
        return FIDM_UPDATE_PEC_Err_FileOpen;
    }

    for (int icount = 0; icount < size; icount++) {
        rc = fread(&buf[icount], 1, 1, infile);
    	if(rc<=0){
            DEBUG_PRINT(stderr, "file read completed or read err");
            break;
        }
    }
	    

    fclose(infile);
    return FIDM_UPDATE_PEC_NO_Error;
}

int32_t fidm_get_binsize(const char *filename)
{
    int32_t siz = 0;
    FILE *fp = fopen(filename, "rb");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        siz = ftell(fp);
        if(siz<0){
            DEBUG_PRINT(stderr, "file binsize Err[%d]",errno);
            siz = 0;
        }
        fclose(fp);
    } else
        return FIDM_UPDATE_PEC_Err_FileOpen;
    return siz;
}

uint16_t fidm_crc16_xmodem(uint8_t *meg, uint32_t length)
{
    uint16_t wCRCin = 0x0000;
    uint16_t wCPoly = 0x1021;
    uint8_t wChar = 0;
    while (length--) {
        wChar = *(meg++);
        wCRCin ^= (wChar << 8);
        for (int i = 0; i < 8; i++) {
            if (wCRCin & 0x8000)
                wCRCin = (wCRCin << 1) ^ wCPoly;
            else
                wCRCin = wCRCin << 1;
        }
    }
    return (wCRCin);
}

uint8_t fidm_compute_CRC8_SAE_J180(uint8_t *mesg, uint8_t length)
{
    uint8_t poly_val = 0x1D;
    uint8_t crc_val  = 0, i = 0;

    for(i=0; i<length; i++)
    {
        crc_val ^= mesg[i]; /* XOR the next input byte */

        for (int i = 0; i < 8; i++)
        {
            if ((crc_val & 0x80) != 0)
            {
                crc_val = (uint8_t)((crc_val << 1) ^ poly_val);
            }
            else
            {
                crc_val <<= 1;
            }
        }
    }

    return crc_val;
}

int32_t fidm_i2c_write(int32_t fd, uint8_t reg, uint8_t *data, uint8_t len)
{
    uint8_t buf[len];
    int32_t iRetVal;
    uint8_t iCount;
    int32_t eStatus = FIDM_I2C_STATUS_OK;

    if (len > 72) {
        eStatus = FIDM_I2C_STATUS_ERROR;
        goto out;
    }

    buf[0] = reg;
    for (iCount = 1; iCount < len; iCount++)
        buf[iCount] = data[iCount - 1];

    iRetVal = i2c_write(fd, buf, len);
    if (len != iRetVal) {
        DEBUG_PRINT(stderr, "i2c_write() FAILED, iRetVal=%d", iRetVal);
        eStatus = FIDM_I2C_STATUS_ERROR;
        goto fail;
    }

fail:
out:
    return eStatus;
}

int32_t fidm_i2c_read(int32_t fd, uint8_t reg, uint8_t *data, uint8_t len)
{
    int32_t iRetVal;
    int32_t eStatus = FIDM_I2C_STATUS_OK;

    if (len > 72) {
        eStatus = FIDM_I2C_STATUS_ERROR;
        goto out;
    }

    iRetVal = i2c_combined_writeread(fd, &reg, 1, data, len);
    if (len != iRetVal) {
        DEBUG_PRINT(stderr, "i2c_read() FAILED, iRetVal=%d \n", iRetVal);
        eStatus = FIDM_I2C_STATUS_ERROR;
        goto fail;
    }

fail:
out:
    return eStatus;
}

int32_t fidm_98x_link(int32_t i2c_fd)
{
	/*
	 *it will implement later for the fdp link switch over
	 *and bridgechip need to Clear BC CRC Flags
	 *otherwise it's hard to judge the detect link
	 */
	return true;
/*
	uint8_t readdata[1] = {0};
	int32_t i;
	for (i = 0; i < 20; i++) {
		fidm_i2c_read(i2c_fd, 0x0c, &readdata[0], 1);
		if ((readdata[0] & 0x01) == 1)
			return true;
		else
			(void) usleep(100 * 1000);
	}
	DEBUG_PRINT(stderr, "%s: Readed 0xc = 0x%02x", __func__, readdata[0]);
	return false;
*/
}

