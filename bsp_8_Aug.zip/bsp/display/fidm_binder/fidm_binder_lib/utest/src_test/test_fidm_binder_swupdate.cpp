#include "fidm_binder_common.h"
#include "fidm_binder.h"
#include <iostream>
#include <gmock/gmock.h>
using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c_header.h"
#include "i2c_mock.h"
#ifdef __cplusplus
}
#endif

using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

class I2C_TEST: public ::testing::Test {
protected:
  UT_i2c_mock ut_i2c_mock_obj;
    void SetUp() override {
        ut_i2c_mock_ptr = &ut_i2c_mock_obj;
      }
    void TearDown() override {
     ut_i2c_mock_ptr = NULL;
    }
};


TEST_F(I2C_TEST,fidm_binder_query_device_info_pass){
	const char *devnode_status="asdf";
	const char *devnode_control="sdfg";
	FidmDeviceInfo	FidmDeviceInfoobj;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(0));	
	EXPECT_CALL(ut_i2c_mock_obj,i2c_set_slave_addr(_,_,_)).WillOnce(Return(0));	
	EXPECT_CALL(ut_i2c_mock_obj,i2c_combined_writeread(_,_,_,_,_)).WillRepeatedly(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_close(_)).WillOnce(Return());
	EXPECT_NE(0,fidm_binder_query_device_info(devnode_status,devnode_control,&FidmDeviceInfoobj));
}

TEST_F(I2C_TEST,fidm_binder_query_device_link_pass){
	const char *devnode_status="asdf";
	uint16_t serializer_i2c_address;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_set_slave_addr(_,_,_)).WillOnce(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_combined_writeread(_,_,_,_,_)).WillRepeatedly(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_close(_)).WillOnce(Return());
	EXPECT_NE(0,fidm_binder_query_device_link(devnode_status,serializer_i2c_address));
}

TEST_F(I2C_TEST,fidm_swupdater_status_loop_pass){
	int32_t i2c_fd=2;
	FIDM_BootLoaderStatus eBLStatus;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_combined_writeread(_,_,_,_,_)).WillRepeatedly(Return(0));
	EXPECT_EQ(0,fidm_swupdater_status_loop(i2c_fd,eBLStatus));
}
TEST_F(I2C_TEST,fidm_swupdater_client_init_pass){
	const char *devnode_status="asdf";
	const char *devnode_control="sdfg";
	fidm_update_handle handle;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(1));
	handle=fidm_swupdater_client_init(devnode_status,devnode_control);
	EXPECT_EQ(0,0);
}

TEST(GTest,fidm_swupdater_dealloc_instance_pass){
	fidm_update_handle handle;
	fidm_swupdater_dealloc_instance(handle);
	EXPECT_EQ(0,0);
}

TEST(GTest,fidm_swupdater_status_check_pass){
	uint32_t status;
	FIDM_BootLoaderStatus eBLStatus;
	EXPECT_NE(0,fidm_swupdater_status_check(status,eBLStatus));
}
 
TEST(GTest,fidm_swupdater_client_get_info_pass){
	fidm_update_handle fidm_handle;
	FidmVersionInfo	FidmVersionInfoobj;
	FidmVersionInfo *FidmVersionInfop=&FidmVersionInfoobj;
	EXPECT_NE(0,fidm_swupdater_client_get_info(fidm_handle,FidmVersionInfop));
}

TEST(GTest,fidm_swupdater_client_do_update_pass){
	fidm_update_handle fidm_handle;
	DisplayUpdateParams update_paramsobj;
	const DisplayUpdateParams *update_params=&update_paramsobj;
	EXPECT_NE(0,fidm_swupdater_client_do_update(fidm_handle,update_params));
}

TEST_F(I2C_TEST,fidm_swupdater_client_deinit_pass){
	fidm_update_handle fidm_handle;
	fidm_swupdater_client_deinit(fidm_handle);
	EXPECT_EQ(0,0);
}
