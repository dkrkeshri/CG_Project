#include "fidm_binder_common.h"
#include "fidm_binder.h"
#include <iostream>
#include <gmock/gmock.h>
using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c_header.h"
#include "i2c_mock.h"
#ifdef __cplusplus
}
#endif

using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

class I2C_TEST: public ::testing::Test {
protected:
  UT_i2c_mock ut_i2c_mock_obj;
    void SetUp() override {
        ut_i2c_mock_ptr = &ut_i2c_mock_obj;
      }
    void TearDown() override {
     ut_i2c_mock_ptr = NULL;
    }
};

TEST(GTest,fidm_binder_diagnosis_dealloc_instance){
	fidm_binder_diagnosis_handle handle;
	fidm_binder_diagnosis_dealloc_instance(handle);
	EXPECT_EQ(0,0);
   
}

TEST_F(I2C_TEST,fidm_binder_diagnosis_client_init_pass){
	const char *devnode_status="asdf";
	const char *devnode_control="sdfg";
	fidm_update_handle handle;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(1));
	handle=fidm_binder_diagnosis_client_init(devnode_status,devnode_control);
	EXPECT_EQ(0,0);
}

TEST(GTest,fidm_binder_diagnosis_query_blob_pass){
	fidm_binder_diagnosis_handle handle;
	uint16_t base_address;
	char buf;
	size_t buf_size=32;
	EXPECT_NE(0,fidm_binder_diagnosis_query_blob(handle,base_address,&buf,buf_size));
}

TEST(GTest,fidm_binder_diagnosis_query_details_pass){
	fidm_binder_diagnosis_handle handle;
	FidmDiagnosisDetails FidmDiagnosisDetailsobj;
	FidmDiagnosisDetails *details=&FidmDiagnosisDetailsobj;
	EXPECT_NE(0,fidm_binder_diagnosis_query_details(handle,details));
}

TEST_F(I2C_TEST,fidm_binder_diagnosis_query_reset_count_pass){
	fidm_binder_diagnosis_handle handle;
	uint16_t count;
	EXPECT_NE(0,fidm_binder_diagnosis_query_reset_count(handle,&count));
}

TEST_F(I2C_TEST,fidm_binder_diagnosis_query_powerup_count_pass){
	fidm_binder_diagnosis_handle handle;
	uint16_t count;
	EXPECT_NE(0,fidm_binder_diagnosis_query_powerup_count(handle,&count));
}

TEST_F(I2C_TEST,fidm_binder_diagnosis_client_deinit_pass){
	fidm_binder_diagnosis_handle handle;
	fidm_binder_diagnosis_client_deinit(handle);
	EXPECT_EQ(0,0);
}
