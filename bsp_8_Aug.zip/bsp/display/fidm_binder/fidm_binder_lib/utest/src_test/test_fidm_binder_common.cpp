#include "fidm_binder_common.h"
#include <iostream>
#include <gmock/gmock.h>
#include <gtest/gtest.h>
//using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c_header.h"
#include "i2c_mock.h"
#ifdef __cplusplus
}
#endif
using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

class I2C_TEST: public ::testing::Test {
protected: 
  UT_i2c_mock ut_i2c_mock_obj;
    void SetUp() override {
        ut_i2c_mock_ptr = &ut_i2c_mock_obj;
      }
    void TearDown() override {
     ut_i2c_mock_ptr = NULL;
    }
};

TEST_F(I2C_TEST,fidm_i2c_write_pass){
	int32_t fd=2;
	uint8_t reg=3;
	uint8_t data;
	uint8_t len=5;
	EXPECT_CALL(ut_i2c_mock_obj, i2c_write(_,_,_)).WillOnce(Return(0));
	EXPECT_NE(0,fidm_i2c_write(fd,reg,&data,len));
}

TEST_F(I2C_TEST,fidm_i2c_read_pass){
	int32_t fd=2;
	uint8_t reg=3;
	uint8_t data;
	uint8_t len=5;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_combined_writeread(_,_,_,_,_)).WillOnce(Return(0));
	EXPECT_NE(0,fidm_i2c_read(fd,reg,&data,len));
}

TEST(GTest,fidm_get_binsize_pass){
	const char *filename="some.txt";
	EXPECT_NE(0,fidm_get_binsize(filename));
}

TEST(GTest,fidm_printf_pass){
	FILE fp;
	const char *temp="aqwse";
	va_list ap;
	fidm_printf(&fp,temp,ap);
	EXPECT_EQ(0,0);
}

TEST(GTest,fidm_read_bin_pass){
	const char *temp="aqwse";
	uint8_t buf;
	uint32_t size=32;
	EXPECT_NE(0,fidm_read_bin(temp,&buf,size));
}

TEST(GTest,fidm_crc16_xmodem_pass){
	uint8_t meg;
	uint32_t length=12;
	EXPECT_NE(0,fidm_crc16_xmodem(&meg,length));
}

TEST(GTest,fidm_compute_CRC8_SAE_J180_pass){
	uint8_t mesg;
	uint8_t length=12;
	EXPECT_NE(0,fidm_compute_CRC8_SAE_J180(&mesg,length));
}

TEST(GTest,fidm_98x_link_pass){
	int32_t i2c_fd=2;
	EXPECT_EQ(1,fidm_98x_link(i2c_fd));
}

TEST(Gtest,fidm_logger_init_pass){
	fidm_logger_init();
	EXPECT_EQ(0,0);
}

