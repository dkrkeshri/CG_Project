#ifndef __FIDM_UPDATE_LIB__
#define __FIDM_UPDATE_LIB__

#ifndef EXPORT_API
#define EXPORT_API __attribute__((visibility("default")))
#endif

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef  __cplusplus
extern "C" {   // Keep header compatible with being used from C++ code.
#endif
typedef enum {
    FIDM_Default       = 0x00, // No change from the Bootloader State Machine Status
    FIDM_BLModeActive  = 0x01, // Bootloader (BL) Mode Active
    FIDM_AppUnlocked   = 0x02, // Application Unlocked
    FIDM_AppErased     = 0x04, // Application Erased
    FIDM_WriteSucceed  = 0x08, // Flash Write Successful
    FIDM_ErrSessionKey = 0x10, // Session Key Error
    FIDM_ErrEraseKey   = 0x20, // Erase Key Error
    FIDM_ErrCRC        = 0x40, // CRC Error
    FIDM_ErrVoltage    = 0x80, // Voltage Error
    //  FIDM_ErrProgramming     = 0x08,     // Programming Error
    //  FIDM_ErrUnknown         = 0x09,     // Unknown Error
} FIDM_BootLoaderStatus;

typedef struct {
    const int8_t *version;
    const char *fw_filename;
    void (*show_progress)(float fraction,
                          int32_t duration); /* value is 0.0f .. 1.0f */
} DisplayUpdateParams;

typedef struct {
    uint16_t HardwareVer;    // Hardware Version of the FIDM
    uint16_t FirmwareVer;    // Firmware Version of the FIDM
    uint8_t DisplayID;       // Identification number of display
    uint8_t SoftwarePart[8]; // 8 Digit Partnumber, ASCIIencoded.
    uint8_t HardwarePart[8]; // 8 Digit Partnumber, ASCIIencoded.
} FidmVersionInfo;

typedef struct {
    uint8_t display_id;            // Identification number of display
    uint8_t touch_id;              // Identification number of touch controller
    uint8_t software_part[8];      // 8 Digit Partnumber, ASCIIencoded.
    uint8_t hardware_part[8];      // 8 Digit Partnumber, ASCIIencoded.
    uint16_t hardware_version;     // Hardware Version of the FIDM
    uint16_t firmware_version;     // Firmware Version of the FIDM
    bool hvac_switch_pack_present; // Identification to determine hvac switch present or not
} FidmDeviceInfo;

typedef struct {
    bool oldi_edp_error;
    bool display_error;
    bool display_temporary_shutoff;
    bool gate_source_driver_error;
    bool watchdog_or_mcu_reset_error;
    bool abnormal_poweron_reset;
    bool i2c_management_error;
    bool lvds_link_lock_error;
    bool backlight_error;
    bool backlight_led_fault;
    bool backlight_over_voltage;
    bool backlight_under_voltage;
    bool backlight_over_current;
    bool backlight_temperature_high;
    bool backlight_temperature_low;
    bool backlight_error_occurred;
} FidmDiagnosisDetails;

typedef int32_t fidm_update_handle;
typedef int32_t fidm_binder_diagnosis_handle;

EXPORT_API fidm_update_handle fidm_swupdater_client_init(
    const char *devnode_status, const char *devnode_control);

EXPORT_API int32_t fidm_swupdater_client_get_info(
    fidm_update_handle fidm_handle, FidmVersionInfo *fidm_version_info);

EXPORT_API int32_t fidm_swupdater_client_do_update(
    fidm_update_handle fidm_handle, const DisplayUpdateParams *update_params);

EXPORT_API void fidm_swupdater_client_deinit(fidm_update_handle fidm_handle);

EXPORT_API fidm_binder_diagnosis_handle fidm_binder_diagnosis_client_init(
    const char *devnode_status, const char *devnode_control);

EXPORT_API int32_t fidm_binder_diagnosis_query_blob(
           fidm_binder_diagnosis_handle handle,uint16_t base_address,
           char *buf,size_t buf_size);

EXPORT_API int32_t fidm_binder_diagnosis_query_details(
           fidm_binder_diagnosis_handle handle,FidmDiagnosisDetails *details);

EXPORT_API int32_t fidm_binder_diagnosis_query_reset_count(
           fidm_binder_diagnosis_handle handle,uint16_t *count);

EXPORT_API int32_t fidm_binder_diagnosis_query_powerup_count(
           fidm_binder_diagnosis_handle handle,uint16_t *count);

EXPORT_API void fidm_binder_diagnosis_client_deinit(fidm_binder_diagnosis_handle handle);

int fidm_binder_query_device_info(
    const char *devnode_status, const char *devnode_control,FidmDeviceInfo *fidm_device_info);
#ifdef UNIT_TEST
void fidm_swupdater_dealloc_instance(
    fidm_update_handle handle);
void fidm_binder_diagnosis_dealloc_instance(
    fidm_binder_diagnosis_handle handle);
int32_t fidm_swupdater_status_check(uint32_t status,FIDM_BootLoaderStatus eBLStatus);
int32_t fidm_swupdater_status_loop(int32_t i2c_fd,FIDM_BootLoaderStatus eBLStatus);
#endif

int fidm_binder_query_device_link(const char *devnode_status, uint16_t serializer_i2c_address);

#ifdef  __cplusplus
}
#endif

#endif //__FIDM_UPDATE_LIB__
