#ifndef __FIDM_SWUPDATER_COMMON__
#define __FIDM_SWUPDATER_COMMON__

#ifndef EXPORT_API
#define EXPORT_API __attribute__((visibility("default")))
#endif

#include <stdint.h>
#include <stdio.h>
#define verbosedebug 1

#define DEBUG_PRINT(sfd, _str_, ...)                                           \
    do {                                                                       \
        if (verbosedebug) {                                                    \
            fidm_printf(sfd, _str_, ##__VA_ARGS__);                            \
        }                                                                      \
    } while (0)

enum FIDM_UPDATE_PEC {
    FIDM_UPDATE_PEC_NO_Error = 0,
    FIDM_UPDATE_PEC_Err_Instance = -1,
    FIDM_UPDATE_PEC_Err_Handle = -2,
    FIDM_UPDATE_PEC_Err_EraseSW = -3,
    FIDM_UPDATE_PEC_Err_GetAppInfo = -4,
    FIDM_UPDATE_PEC_Err_RevokeCal = -5,
    FIDM_UPDATE_PEC_Err_EraseCal = -6,
    FIDM_UPDATE_PEC_Err_LengthExceeded = -7,
    FIDM_UPDATE_PEC_Err_FlashWrite = -8,
    FIDM_UPDATE_PEC_Err_DisplayID = -9,
    FIDM_UPDATE_PEC_Err_Undefined = -10,
    FIDM_UPDATE_PEC_Err_FileAccessDenied = -11,
    FIDM_UPDATE_PEC_Err_UpdatingTimer = -12,
    FIDM_UPDATE_PEC_Err_FileClose = -13,
    FIDM_UPDATE_PEC_Err_FileNotFound = -14,
    FIDM_UPDATE_PEC_Err_FileOpen = -15,
    FIDM_UPDATE_PEC_Err_DuringWrite = -16,
    FIDM_UPDATE_PEC_Err_DuringRead = -17,
    FIDM_UPDATE_PEC_Err_Insufficientvirtualmemory = -18,
    FIDM_UPDATE_PEC_Err_ProgramException = -19,
    FIDM_UPDATE_PEC_Err_BufNull = -20,
};
void fidm_printf(FILE *fp, const char *format, ...);
int32_t fidm_read_bin(const char *path, uint8_t *buf, uint32_t size);
int32_t fidm_get_binsize(const char *filename);
uint16_t fidm_crc16_xmodem(uint8_t *meg, uint32_t length);
uint8_t fidm_compute_CRC8_SAE_J180(uint8_t *mesg, uint8_t length);
int32_t fidm_i2c_write(int32_t fd, uint8_t reg, uint8_t *data, uint8_t len);
int32_t fidm_i2c_read(int32_t fd, uint8_t reg, uint8_t *data, uint8_t len);
int32_t fidm_98x_link(int32_t fd);
#ifdef UNIT_TEST
void fidm_logger_init(void);
#endif
#endif //__FIDM_SWUPDATER_COMMON__
