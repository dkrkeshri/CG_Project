#!/usr/bin/env bash
cd "$(dirname "$0")"

source test/utest/setenv_x86_64.sh

rm coverage.info
rm -rf Report


#cd ../../providers/utest/
#cd ../i2c-frontend/libvi2cdevnode/utest/
#rm *.gc* UT_libvi2cdevnode
#make test

cd ../i2c-frontend/vi2c-service/utest/
rm *.gc* UT_vi2c-service
make test
cd ../../../display
./code_coverage.sh

#rm a.txt
#cd ../../../
#rm coverage.info



