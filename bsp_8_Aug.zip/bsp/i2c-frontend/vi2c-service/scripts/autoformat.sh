#!/bin/bash

uncrustify -c .uncrustify --replace --no-backup ../src/*.c
uncrustify -c .uncrustify --replace --no-backup ../src/*.h
clang-format -i --style=file ../src/*.c ../src/*.cpp
clang-format -i --style=file ../src/*.h
