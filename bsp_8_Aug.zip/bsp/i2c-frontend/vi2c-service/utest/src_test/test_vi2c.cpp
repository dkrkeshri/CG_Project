#include <fcntl.h>
#include <gmock/gmock.h>
#include "UT-unistd-mock.h"
#include "config.h"
#include "vi2c-daemon.h"
#include "vi2c_logger.h"

TEST(vi2c, signal_handler_pass){
	int sig;
	signal_handler1(sig);
	EXPECT_EQ(0,0);
}

TEST(vi2c, vi2c_show_daemon_config_pass){
	vi2c_daemon_config cfg;
	vi2c_daemon_config *pcfg = &cfg;
	CONFIG_SHOW_TYPE type;
	vi2c_show_daemon_config1(pcfg, type);
	EXPECT_EQ(0,0);
}

TEST(vi2c, main_pass){
	char path[256]={0};
    strcpy(&path[0],"test.txt");
    fopen (&path[0],"w");
    extern char *optarg;
    optarg=&path[0];
    int argc=3;
    char arg1[256]={0};
    strcpy(&arg1[0],"./display_i2c.sh");
    char arg2[256]={0};
    strcpy(&arg2[0],"-h");
    char *argv[] = {&arg1[0],&arg2[0]};
	EXPECT_EQ(0,main1(argc, &argv[0]));
}
