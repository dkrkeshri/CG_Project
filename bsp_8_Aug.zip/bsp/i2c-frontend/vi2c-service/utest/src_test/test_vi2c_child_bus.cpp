#include <fcntl.h>
#include <gmock/gmock.h>
#include "config.h"
#include "vi2c-bus-contexts.h"
#include "UT-i2cdevnode-mock.h"
using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c_header.h"
#include "i2c_mock.h"
#ifdef __cplusplus
}
#endif
using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

class devnode_TEST: public ::testing::Test {
protected:
  UT_i2cdevnode_mock ut_i2cdevnode_mock_obj;
    void SetUp() override {
        ut_i2cdevnode_mock_ptr = &ut_i2cdevnode_mock_obj;
      }
    void TearDown() override {
        ut_i2cdevnode_mock_ptr = NULL;
    }
};

TEST(vi2c_bus_child,vi2c_bus_child_check_online_pass){
	struct vi2c_bus_child_context ctx;
	EXPECT_NE(0,vi2c_bus_child_check_online2(&ctx));
}

TEST(vi2c_bus_child,vi2c_bus_child_analize_ret_pass){
	struct vi2c_bus_child_context ctx;
	int ret;
	vi2c_bus_child_analize_ret2(&ctx, ret);
	EXPECT_EQ(0,0);
}

TEST(vi2c_bus_child, callback_send_recvbytes_pass){
	I2Cdevnode_funcs_parameters *node_ctx=(I2Cdevnode_funcs_parameters *)malloc(sizeof(I2Cdevnode_funcs_parameters));
	unsigned short slaveNo=1;
	uint8_t wdata=8;
	uint32_t wlen=1;
	uint8_t rdata=3;
	uint32_t rlen=2;
	EXPECT_NE(0, callback_send_recvbytes2((void *)node_ctx,slaveNo,&wdata,wlen,&rdata,rlen));
	free(node_ctx);
}

TEST(vi2c_bus_child, callback_send_pass){
	I2Cdevnode_funcs_parameters *node_ctx = (I2Cdevnode_funcs_parameters *)malloc(sizeof(I2Cdevnode_funcs_parameters));
	unsigned short slaveNo=1;
	unsigned char data =2;// (char*)malloc(0x401);
	unsigned char len=2;
	EXPECT_NE(0, callback_send2((void *)node_ctx,slaveNo, &data, len));
	free(node_ctx);
}


TEST(vi2c_bus_child, callback_recv_pass){
	//void *ctx;
	unsigned short slaveNo;
	unsigned char data =2;// (char*)malloc(0x401);
	unsigned char len;
	EXPECT_EQ(0, callback_recv2(NULL,slaveNo, &data, len));
	//free(data);
}

TEST(vi2c_bus_child, callback_stop_pass){
	//void *ctx;
	callback_stop2(NULL);
	EXPECT_EQ(0,0);
}

TEST(vi2c_bus_child, vi2c_bus_child_context_add_child_pass){
    struct vi2c_bus_child_context child_ctx;
	vi2c_bus_child_set_callbacks2(&child_ctx);
	EXPECT_EQ(0,0);
}

TEST(vi2c_bus_child, vi2c_bus_child_set_devnode_name_pass){
   struct vi2c_bus_child_context child_ctx;
   char *devnode_name = (char*)malloc(0x401);
	vi2c_bus_child_set_devnode_name2(&child_ctx,devnode_name);
	EXPECT_EQ(0,0);
	free(devnode_name);
}

TEST_F(devnode_TEST, vi2c_bus_child_destroy_pass){
	struct vi2c_bus_child_context ctx;
	EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__destroy(_));
	vi2c_bus_child_destroy(&ctx);
	EXPECT_EQ(0, 0);
}

TEST(vi2c_bus_child, vi2c_bus_child_get_name_pass){
	struct vi2c_bus_child_context ctx;
	vi2c_bus_child_get_name(&ctx);
	EXPECT_EQ(0,0);
}

TEST(vi2c_bus_child, vi2c_bus_child_set_online_pass){
	struct vi2c_bus_child_context ctx;
	bool online = true; 
	
	EXPECT_EQ(0, vi2c_bus_child_set_online(&ctx,online));
}

TEST(vi2c_bus_child, vi2c_bus_child_set_default_online_pass){
	struct vi2c_bus_child_context ctx;
	EXPECT_EQ(0,vi2c_bus_child_set_default_online(&ctx));
}

TEST_F(devnode_TEST, vi2c_bus_child_create_pass){
	vi2c_bus_tree_context tree_ctx;
	vi2c_bus_child_spec spec;
	EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__create(_));
	vi2c_bus_child_create(&tree_ctx,&spec);
	EXPECT_EQ(0,0);
}
