#include <fcntl.h>
#include <gmock/gmock.h>
#include "vi2c-bus-contexts.h"
#include "vi2c-daemon.h"
#include "vi2c_logger.h"

TEST(vi2c_daemon, vi2c_daemon_add_tree_pass){
	struct vi2c_bus_tree_context tree_ctx;
	EXPECT_EQ(0,vi2c_daemon_add_tree1(&tree_ctx));
}

TEST(vi2c_daemon, vi2c_daemon_init_pass){
	struct vi2c_daemon_config config;
	EXPECT_EQ(0, vi2c_daemon_init(&config));
}

TEST(vi2c_daemon, vi2c_daemon_set_default_online_pass){
	vi2c_daemon_set_default_online();
	EXPECT_EQ(0, 0);
}

TEST(vi2c_daemon, vi2c_daemon_start_pass){
	EXPECT_EQ(0, vi2c_daemon_start());
}

TEST(vi2c_daemon, stop_pass){
	vi2c_daemon_stop();
	EXPECT_EQ(0, 0);
}

TEST(vi2c_daemon, vi2c_daemon_destroy_pass){
	vi2c_daemon_destroy();
	EXPECT_EQ(0, 0);
}

TEST(vi2c_daemon,getdaemon_pass){
	get_daemon();
	EXPECT_EQ(0, 0);
}