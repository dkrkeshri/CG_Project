#include <fcntl.h>
#include <gmock/gmock.h>
#include "vi2c_logger.h"

TEST(vi2c_logger, vi2c_logger_init_pass){
	
	EXPECT_EQ(0,vi2c_logger_init());
}

TEST(vi2c_logger, vi2c_logger_set_state_pass){
	bool inited=true;
	vi2c_logger_set_state(inited);
	EXPECT_EQ(0, 0);
}

TEST(vi2c_logger, vi2c_logger_get_state_pass){
	EXPECT_EQ(true, vi2c_logger_get_state());
}

TEST(vi2c_logger, vi2c_logger_set_loglevel_pass){
	int level;
	vi2c_logger_set_loglevel(level);
	EXPECT_EQ(0,0);

}

TEST(vi2c_logger, vi2c_printf_pass){
	void *ctx;
	char *format = (char*)malloc(0x401);
	vi2c_printf(NULL, format);
	EXPECT_EQ(0,0);
}

TEST(vi2c_logger, vi2c_err_printf_pass){
	void *ctx;
	char *format = (char*)malloc(0x401);
	//const char *f = "abc";	
	vi2c_err_printf(NULL,format);
	EXPECT_EQ(0,0);
	free(format);
}
