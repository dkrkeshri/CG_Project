#include <fcntl.h>
#include <gmock/gmock.h>
#include "config.h"


CfgCleaner CfgCleanerObj;
//CfgCleaner CfgCleaner();

TEST(config, onlinekey_check_valid1_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	EXPECT_EQ(false,onlinekey_check_valid1(a));
	free(a);
}

TEST(config, onlinekey_is_online1_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	EXPECT_EQ(false,onlinekey_is_online1(a));
	free(a);
}

TEST(config, vi2c_delete_daemon_config_pass){
	vi2c_daemon_config cfg;
	vi2c_delete_daemon_config(&cfg);
	EXPECT_EQ(0, 0);
}

TEST(config, vi2c_parse_config_pass){
	char *a =(char*) malloc(0x401);
	memset(a,0x00,0x401);
	memset(a,0x1,0x400);
	EXPECT_NE(0, vi2c_parse_config(a));
	free(a);
}

TEST(config, wipe_pass){
	CfgCleaner CfgCleanerObj;
	CfgCleanerObj.wipe();
	EXPECT_EQ(0,0);
}

TEST(config, set_string_pass){
	char *b =(char*) malloc(0x401);
	memset(b,0x00,0x401);
	memset(b,0x1,0x400);
	const char *ptr = NULL;
	EXPECT_EQ(true, CfgCleanerObj.set_string(&ptr, b));
	free(b);
}

TEST(config, set_string1_pass){
	const char *ptr = NULL;
	std::string value ="abc";
	EXPECT_EQ(true, CfgCleanerObj.set_string(&ptr, value ));
	
}

TEST(config, vi2c_get_daemon_config_pass){
	vi2c_get_daemon_config();
	EXPECT_EQ(0,0);
}