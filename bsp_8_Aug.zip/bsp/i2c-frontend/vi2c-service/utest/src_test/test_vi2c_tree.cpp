#include <iostream>
#include <gmock/gmock.h>
#include "config.h"
#include "vi2c-bus-contexts.h"
#include "UT-i2cdevnode-mock.h"
#include "vi2c_logger.h"
using ::testing::_;
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdexcept>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c_header.h"
#include "i2c_mock.h"
#ifdef __cplusplus
}
#endif

using namespace std;
using namespace testing;
using ::testing::_;
using ::testing::Invoke;
using ::testing::DoAll;
using ::testing::internal::Function;

class I2C_TEST: public ::testing::Test {
protected:
  UT_i2c_mock ut_i2c_mock_obj;
  UT_i2cdevnode_mock ut_i2cdevnode_mock_obj;
    void SetUp() override {
        ut_i2c_mock_ptr = &ut_i2c_mock_obj;
		ut_i2cdevnode_mock_ptr = &ut_i2cdevnode_mock_obj;
      }
    void TearDown() override {
     ut_i2c_mock_ptr = NULL;
	 ut_i2cdevnode_mock_ptr = NULL;
    }
};


TEST_F(I2C_TEST, fidm_i2c_init_pass){
	vi2c_bus_tree_context ctx;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(0));
	EXPECT_EQ(0,fidm_i2c_init1(&ctx));
}

TEST_F(I2C_TEST, fidm_i2c_deinit_pass){
	 vi2c_bus_tree_context ctx;
	 EXPECT_CALL(ut_i2c_mock_obj,i2c_close(_)).WillOnce(Return());
	fidm_i2c_deinit1(&ctx);
	EXPECT_EQ(0, 0);
}

TEST_F(I2C_TEST, fidm_i2c_write_pass){
	 vi2c_bus_tree_context ctx;
	unsigned char data =2;//= (unsigned char*)malloc(0x401);
	unsigned char len =2 ;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_write(_,_,_)).WillOnce(Return(0));
	EXPECT_EQ(0, fidm_i2c_write1(&ctx, &data, len));
	//free(data);
}

TEST_F(I2C_TEST, fidm_i2c_read_only_pass){
	 vi2c_bus_tree_context ctx;
	unsigned char data ;//= (unsigned char*)malloc(0x401);
	unsigned char len=1;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_read(_,_,_)).WillOnce(Return(0));
	EXPECT_EQ(0, fidm_i2c_read_only1(&ctx, &data, len));
	//free(data);
}

TEST(vi2c_tree, vi2c_bus_tree_set_helpers_pass){
	 vi2c_bus_tree_context ctx;
	vi2c_bus_tree_set_helpers1(&ctx);
	EXPECT_EQ(0,0);
}

TEST(vi2c_tree, vi2c_bus_tree_context_set_online_pass){
	 vi2c_bus_tree_context *ctx=(vi2c_bus_tree_context*)calloc(1,sizeof(vi2c_bus_tree_context));
	bool online = true; 
	EXPECT_EQ(0, vi2c_bus_tree_context_set_online(ctx,online));
	free(ctx);
}

TEST(vi2c_tree, vi2c_bus_tree_context_set_default_online_pass){
	 vi2c_bus_tree_context *ctx=(vi2c_bus_tree_context*)calloc(1,sizeof(vi2c_bus_tree_context));
	EXPECT_EQ(0,vi2c_bus_tree_context_set_default_online(ctx));
	free(ctx);
}

//want  vi2c_bus_tree_self_config1

TEST_F(I2C_TEST, vi2c_bus_tree_context_create_pass){
	//vi2c_bus_tree_spec tree_spec;
	vi2c_bus_tree_spec *ctx =( vi2c_bus_tree_spec*)calloc(1,sizeof(vi2c_bus_tree_spec));// &actx;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj, i2c_close(_)).WillRepeatedly(Return());
	//EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__create(_)).WillOnce(Return(0));
	//EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__destroy(_));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_set_slave_addr(_,_,_)).WillOnce(Return(0));
	vi2c_bus_tree_context_create(ctx);
	EXPECT_EQ(0,0);
}


//randomly passes or fails
TEST_F(I2C_TEST, vi2c_bus_tree_populate_buses_pass){
	  //vi2c_bus_tree_context actx;
	 vi2c_bus_tree_context *ctx =( vi2c_bus_tree_context*)calloc(1,sizeof(vi2c_bus_tree_context));// &actx;
	 //EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__enableSlave(_,_,_)).WillRepeatedly(Return(0));
	vi2c_bus_tree_populate_buses1(ctx);
	EXPECT_EQ(0,0);
	free(ctx);
}


TEST(vi2c_tree, vi2c_bus_tree_context_add_child_pass){
	//vi2c_bus_tree_context tree;
	vi2c_bus_tree_context *tree_ctx=(vi2c_bus_tree_context *)calloc(1,sizeof(vi2c_bus_tree_context));
    //vi2c_bus_child_context child ;
	vi2c_bus_child_context *child_ctx=(vi2c_bus_child_context *)calloc(1,sizeof(vi2c_bus_child_context));
	MAX_CHILD_BUSES ;
	vi2c_bus_tree_context_add_child1(tree_ctx, child_ctx);
	EXPECT_EQ(0,0);
	free(tree_ctx);
	free(child_ctx);
}


TEST_F(I2C_TEST, vi2c_bus_tree_self_config_pass){
	 vi2c_bus_tree_context *ctx= (vi2c_bus_tree_context*)calloc(1,sizeof(vi2c_bus_tree_context));
	 vi2c_bus_tree_spec *tree_ctx=(vi2c_bus_tree_spec *)calloc(1,sizeof(vi2c_bus_tree_spec));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_open(_)).WillOnce(Return(0));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_set_slave_addr(_,_,_)).WillOnce(Return(0));
	//EXPECT_CALL(ut_i2c_mock_obj,i2c_set_bus_speed(_,_,_)).WillOnce(Return(-1));
	EXPECT_EQ(0, vi2c_bus_tree_self_config1(ctx, tree_ctx));
	free(ctx);
	free(tree_ctx);
}


// double free error
TEST_F(I2C_TEST, vi2c_bus_tree_context_destroy_pass){
	vi2c_bus_tree_context tctx;
	vi2c_bus_tree_context *tree_ctx=(vi2c_bus_tree_context *)calloc(1,sizeof(vi2c_bus_tree_context));
	EXPECT_CALL(ut_i2c_mock_obj,i2c_close(_)).WillRepeatedly(Return());
	//EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__create(_));
	//EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__destroy(_));
	vi2c_bus_tree_context_destroy(tree_ctx);
	EXPECT_EQ(0,0);
	//free(tree_ctx);
}


TEST_F(I2C_TEST, fidm_i2c_writeread_pass){
	// vi2c_bus_tree_context actx;
	// vi2c_bus_tree_context *ctx=&actx;
	vi2c_bus_tree_context *ctx =( vi2c_bus_tree_context*)calloc(1,sizeof(vi2c_bus_tree_context));// &actx;
	uint8_t wbuf=2;
	uint32_t wlen=3;
	uint8_t rbuf=5;
	uint32_t rlen =0;
	EXPECT_CALL(ut_i2c_mock_obj,i2c_combined_writeread(_,_,_,_,_)).WillOnce(Return(0));
	EXPECT_CALL(ut_i2cdevnode_mock_obj, i2cdevnode__enableSlave(_,_,_)).WillRepeatedly(Return(0));
	EXPECT_EQ(0, fidm_i2c_writeread1(ctx,&wbuf,wlen,&rbuf,rlen));
	free(ctx);
}


TEST_F(I2C_TEST, fidm_i2c_set_slave_pass){
	 vi2c_bus_tree_context ctx ;
	 EXPECT_CALL(ut_i2c_mock_obj,i2c_set_slave_addr(_,_,_)).WillOnce(Return(0));
	EXPECT_EQ(0, fidm_i2c_set_slave1(&ctx));
}
