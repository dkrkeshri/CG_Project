
/******************************************************************
*FILE: vi2c-child-bus.c
*SW-COMPONENT: virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "vi2c-bus-contexts.h"
#include "vi2c_logger.h"
#ifdef UNIT_TEST
#include "ipc_header.h"
#include "i2c_mock.h"
#endif

#ifdef UNIT_TEST
int vi2c_bus_child_check_online2(struct vi2c_bus_child_context *ctx)
#else
static int vi2c_bus_child_check_online(struct vi2c_bus_child_context *ctx)
#endif
{
    return ctx->online;
}

/*
static int vi2c_bus_child_check_address(struct vi2c_bus_child_context *ctx,
                                        unsigned short addr)
{
    return 0;
}

static int vi2c_bus_child_check_registers(struct vi2c_bus_child_context *ctx,
                                          unsigned char reg, unsigned int len)
{
    return 0;
}
*/
#ifdef UNIT_TEST
void vi2c_bus_child_analize_ret2(struct vi2c_bus_child_context *ctx,
                                       int ret)
#else
static void vi2c_bus_child_analize_ret(struct vi2c_bus_child_context *ctx,
                                       int ret)
#endif
{
}

/* i2c_read fiunction callback */
#ifdef UNIT_TEST
int callback_send_recvbytes2(void *ctx, unsigned short slaveNo,  uint8_t *wdata,
		uint32_t wlen, uint8_t *rdata, uint32_t rlen)
#else
static int callback_send_recvbytes(void *ctx, unsigned short slaveNo,  uint8_t *wdata,
		uint32_t wlen, uint8_t *rdata, uint32_t rlen)
#endif
{

    I2Cdevnode_funcs_parameters *node_ctx = (I2Cdevnode_funcs_parameters *) ctx;
    struct vi2c_bus_child_context *c =
        (struct vi2c_bus_child_context *) node_ctx->context;
    int ret;
    static int ctx_not_avail = 0;
    static int tree_not_avail = 0;
    static int bus_not_online = 0;

    // Do initial sanity checks
    if (!c) {
        LOG_ERROR("ctx not available");
        if(ctx_not_avail < 10){
            LOG_EM("callback_send_recvbytes:ctx not available\n");
            ctx_not_avail++;
        }
        return -EINVAL;
    }

    if (!c->tree_context) {
        LOG_ERROR("ctx->tree_context not available");
        if(tree_not_avail < 10){
            LOG_EM("callback_send_recvbytes:ctx->tree_context not available\n");
            tree_not_avail++;
        }
        return -ENODEV;
    }

    // First check if the bus is online
    #ifdef UNIT_TEST
    ret = vi2c_bus_child_check_online2(c);
    #else
     ret = vi2c_bus_child_check_online(c);
     #endif
    if (!ret) {
        // Log a fault here. We do not need to update any counters because
        // no real issue with underlying HW happened yet
        LOG_ERROR("bus not online");
        if(bus_not_online < 10){
            LOG_EM("callback_send_recvbytes:bus not online\n");
            bus_not_online++;
        }
        return ret;
    }
#if 0 // TODO: Need implement and check here
	// Check that access is addressed to the right device
	ret = vi2c_bus_child_check_address(c, slaveNo);
	if (!ret) {
		// Log a fault here. We do not need to update any counters because
		// no real issue with underlying HW happened yet
		LOG_ERROR("address not permitted");
		return ret;
	}

	// Check if the register is in allowed range
	ret = vi2c_bus_child_check_registers(c, reg, len);
	if (!ret) {
		// Log a fault here. We do not need to update any counters because
		// no real issue with underlying HW happened yet
		LOG_ERROR("registers access denied");
		return ret;
	}
#endif
    // Ask the tree to execute the transaction
    ret = c->tree_context->helpers.send_recvbytes(c->tree_context, wdata, wlen, rdata,
                                                  rlen);

    // Analize the ret code like:
    //   - Update fault counter (all, sequential)
    //   - For the success reset fault counter
    #ifdef UNIT_TEST
    vi2c_bus_child_analize_ret2(c, ret);
    #else
    vi2c_bus_child_analize_ret(c, ret);
    #endif
    ctx_not_avail = 0;
    tree_not_avail = 0;
    bus_not_online = 0;
    return ret;
}

/* i2c_write fiunction callback */
#ifdef UNIT_TEST
int callback_send2(void *ctx, unsigned short slaveNo, unsigned char *data,
                         unsigned int len)
#else
static int callback_send(void *ctx, unsigned short slaveNo, unsigned char *data,
                         unsigned int len)
#endif
{
    I2Cdevnode_funcs_parameters *node_ctx = (I2Cdevnode_funcs_parameters *) ctx;
    struct vi2c_bus_child_context *c =
        (struct vi2c_bus_child_context *) node_ctx->context;
    int ret;
    static int ctx_not_avail = 0;
    static int tree_not_avail = 0;
    static int bus_not_online = 0;

    // Do initial sanity checks
    if (!c) {
        LOG_ERROR("ctx not available");
        if(ctx_not_avail < 10){
            LOG_EM("callback_send:ctx not available\n");
            ctx_not_avail++;
        }
        return -EINVAL;
    }

    if (!c->tree_context) {
        LOG_ERROR("ctx->tree_context not available");
        if(tree_not_avail < 10){
            LOG_EM("callback_send:ctx->tree_context not available\n");
            tree_not_avail++;
        }
        return -ENODEV;
    }

    // First check if the bus is online
    #ifdef UNIT_TEST
    ret = vi2c_bus_child_check_online2(c);
    #else
    ret = vi2c_bus_child_check_online(c);
    #endif
    if (!ret) {
        // Log a fault here. We do not need to update any counters because
        // no real issue with underlying HW happened yet
        LOG_ERROR("bus not online");
        if(bus_not_online < 10){
            LOG_EM("callback_send:bus not online\n");
            bus_not_online++;
        }
        return ret;
    }
#if 0 // TODO: Need implement and check here
	// Check that access is addressed to the right device
	ret = vi2c_bus_child_check_address(c, slaveNo);
	if (!ret) {
		// Log a fault here. We do not need to update any counters because
		// no real issue with underlying HW happened yet
		LOG_ERROR("address not permitted");
		return ret;
	}

	// Check if the register is in allowed range
	ret = vi2c_bus_child_check_registers(c, reg, len);
	if (!ret) {
		// Log a fault here. We do not need to update any counters because
		// no real issue with underlying HW happened yet
		LOG_ERROR("registers access denied");
		return ret;
	}
#endif
    // Ask the tree to execute the transaction
    ret = c->tree_context->helpers.sendbytes(c->tree_context, data,
                                                  len);

    // Analize the ret code like:
    //   - Update fault counter (all, sequential)
    //   - For the success reset fault counter
    #ifdef UNIT_TEST
    vi2c_bus_child_analize_ret2(c, ret);
    #else
    vi2c_bus_child_analize_ret(c, ret);
    #endif
    ctx_not_avail = 0;
    tree_not_avail = 0;
    bus_not_online = 0;
    return ret;

}

#ifdef UNIT_TEST
int callback_recv2(void *ctx, unsigned short slaveNo, unsigned char *data,
                         unsigned int len)
#else
static int callback_recv(void *ctx, unsigned short slaveNo, unsigned char *data,
                         unsigned int len)
#endif
{
    // Implement in a similar way as above
    /*I2Cdevnode_funcs_parameters *node_cb = (I2Cdevnode_funcs_parameters
    *)(ctx);
    return fidm_i2c_read_only(node_cb->i2c_fd, data, len);
        */
    return 0;
}

#ifdef UNIT_TEST
int callback_stop2(void *ctx)
#else
static int callback_stop(void *ctx)
#endif
{
    return 0;
}

#ifdef UNIT_TEST
void vi2c_bus_child_set_callbacks2(
    struct vi2c_bus_child_context *child_ctx)
#else
static void vi2c_bus_child_set_callbacks(
    struct vi2c_bus_child_context *child_ctx)
#endif
{
	#ifdef UNIT_TEST
    child_ctx->callbacks.sendbytes = callback_send2;
    child_ctx->callbacks.recvbytes = callback_recv2;
    child_ctx->callbacks.send_recvbytes = callback_send_recvbytes2;
    child_ctx->callbacks.stop = callback_stop2;
    #else
    child_ctx->callbacks.sendbytes = callback_send;
    child_ctx->callbacks.recvbytes = callback_recv;
    child_ctx->callbacks.send_recvbytes = callback_send_recvbytes;
    child_ctx->callbacks.stop = callback_stop;
    #endif

    child_ctx->callbacks.log_info_print = vi2c_printf;
    child_ctx->callbacks.log_error_print = vi2c_err_printf;
    child_ctx->callbacks.context = child_ctx;
}

#ifdef UNIT_TEST
void vi2c_bus_child_set_devnode_name2(
    struct vi2c_bus_child_context *child_ctx, const char *devnode_name)
#else
static void vi2c_bus_child_set_devnode_name(
    struct vi2c_bus_child_context *child_ctx, const char *devnode_name)
#endif
{
    snprintf(child_ctx->callbacks.devnode_name,
             sizeof(child_ctx->callbacks.devnode_name), "%s", devnode_name);
}

struct vi2c_bus_child_context *vi2c_bus_child_create(
    struct vi2c_bus_tree_context *tree_ctx, struct vi2c_bus_child_spec *spec)
{
    struct vi2c_bus_child_context *child_ctx;
#ifndef UNIT_TEST
    child_ctx = calloc(1, sizeof(*child_ctx));
#else
    child_ctx = (vi2c_bus_child_context*)calloc(1, sizeof(*child_ctx));
#endif
    if (!child_ctx)
        return NULL;

    child_ctx->tree_context = tree_ctx; // give treectx to child_ctx

    /* Store a reference to the configuration
       We can later use it to get device node names and etc... */
    child_ctx->bus_spec = spec;
	#ifdef UNIT_TEST
    vi2c_bus_child_set_callbacks2(child_ctx);
    vi2c_bus_child_set_devnode_name2(child_ctx, spec->devnode_name);
    #else
    vi2c_bus_child_set_callbacks(child_ctx);
    vi2c_bus_child_set_devnode_name(child_ctx, spec->devnode_name);
	#endif
	
    /* Finally create the virtual I2C node */
    child_ctx->dn = i2cdevnode__create(&child_ctx->callbacks);
    if (child_ctx->dn == 0) {
        LOG_ERROR("i2cdevnode__create fail");
        LOG_EM("i2cdevnode_%s_create fail.\n",spec->devnode_name);
        free(child_ctx);
        return NULL;
    }

    return child_ctx;
}

void vi2c_bus_child_destroy(struct vi2c_bus_child_context *ctx)
{
    i2cdevnode__destroy(ctx->dn);
}

const char *vi2c_bus_child_get_name(struct vi2c_bus_child_context *ctx)
{
    return ctx->bus_spec->public_name;
}

int vi2c_bus_child_set_online(struct vi2c_bus_child_context *ctx, bool online)
{
    ctx->online = online;
    return 0;
}

int vi2c_bus_child_set_default_online(struct vi2c_bus_child_context *ctx)
{
    // FIXME: That is hardcode
    // The real code shall take default online/offline state from configuration
    return vi2c_bus_child_set_online(ctx, 1);
}
