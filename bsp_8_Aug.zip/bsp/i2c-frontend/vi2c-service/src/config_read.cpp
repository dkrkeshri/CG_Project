/**
 * config file reader, according to feature #905163, story #934503
 *
 * This file contains the code to read and parse a config file from a json file,
 * and place the results in the config struct which was already in this program.
 * The struct filled in is the   struct vi2c_daemon_config .
 *
 * Uses the json parser from the lib_tdaemon.
 *
 * When changing from static C-source config to parser, the struct was only
 * extended for the  bDefaultOnline  fields.
 */

#include "config.h"
#include "vi2c_logger.h"
#include "txt_procfuncs.h"
#include <fcntl.h>
#include <jsdata.h>
#include <memory>             // for <std::nothrow> new
#include <smalljs.h>
#include <txtdaemon_common.h> // for text-file load function
#ifdef UNIT_TEST
#include "i2c_mock.h"
#include "smalljs.h"
#include "sal_cp_log.h"
#include "vi2c_logger.h"
#endif

/**
 * class containing the   struct vi2c_daemon_config , managing string-mem.
 *
 * The config structure is defined to refer to several char* strings.
 * Allocating these at runtime by a config-file parser has the problem
 * of finding a good spot to deallocate them on exit.
 *
 * The purpose of this class is to do just this. take care of
 * allocating and deallocating the char* strings in the struct.
 */
 
 #ifndef UNIT_TEST
class CfgCleaner
{
  public:
    CfgCleaner();
    ~CfgCleaner();

    void wipe();

    bool set_string(const char **field, const char *value);
    bool set_string(const char **field, std::string &value);

    struct vi2c_daemon_config cfg;
};
#else
using namespace std;
#endif

/// check if a string passed in is valid of the online mode: 'online' or 'offline'.
#ifdef UNIT_TEST
bool onlinekey_check_valid1(const char *value);
#else
static bool onlinekey_check_valid(const char *value);
#endif

/// check if a string passed in is 'online'; shall first check if valid..
#ifdef UNIT_TEST
bool onlinekey_is_online1(const char *value);
#else
static bool onlinekey_is_online(const char *value);
#endif

// using these to hold the struct passed out so they are auto-cleaned up on
// exit.
static CfgCleaner stat_cfg;

struct vi2c_daemon_config *vi2c_get_daemon_config()
{
    return &stat_cfg.cfg;
}

void vi2c_delete_daemon_config(struct vi2c_daemon_config *cfg)
{
    stat_cfg.wipe();
}

/**
 * @brief Function to load and parse the configuration for this process.
 *
 * Given a filename, the function will read the file, call
 * parse_json(), then creat the config struct and pick all needed
 * fields from the json datastructure into the configuration.
 *
 * @param conf_file_name   Textfile to parse. Used with open().
 * @return The returnvalue is zero on success or an errorcode on failure.
 */
int vi2c_parse_config(const char *conf_file_name)
{
    std::string err;
    char *filedata = NULL;
    int ret;
    JSDataNode *n;
    JSDataNodeArray *n_devs;
    std::string valstr;

    // first, load the file.
    ret = EIO;
    filedata = tdi_load_textfile(conf_file_name, &ret);
    if (!filedata) {
        if (!ret)
            ret = EIO;
        LOG_ERROR("vi2c_parse_config failed: cannot read '%s'", conf_file_name);
        return ret;
    }

    // parse as json.
    std::unique_ptr<JSDataNode> jd(parse_json(filedata, &err));
    free(filedata);
    filedata = NULL;

    // failed? (broken json format)
    if (!jd) {
        LOG_ERROR("vi2c_parse_config failed: %s", err.c_str());
        return EINVAL;
    }

    // verify basic structure. Must have a list named 'devices'.
    if (!jd->get_field("devices", &n) || n->type != JSTYPE_array) {
        LOG_ERROR("vi2c_parse_config failed: file should contain a list named "
                  "'devices'");
        return EINVAL;
    }
    n_devs = (JSDataNodeArray *) n;
    // list shall not be longer than what is allowed in static config size.
    if (n_devs->count() > MAX_HOST_BUSES) {
        LOG_ERROR(
            "vi2c_parse_config failed: too many devices. Static max is %d",
            (int) MAX_HOST_BUSES);
        return EINVAL;
    }

    // prepare config struct
    stat_cfg.wipe();

    // read fields from root level
    if (jd->get_field_string("name", &valstr, true, 100))
        stat_cfg.set_string(&stat_cfg.cfg.name, valstr);
    if (jd->get_field_string("logfile", &valstr, true, 255))
        stat_cfg.set_string(&stat_cfg.cfg.logfilename, valstr);

    // loop all 'devices'
    for (unsigned int i = 0; i < n_devs->count(); i++) {
        n = n_devs->get(i);
        int valint;
        std::string dname;
        JSDataNodeArray *n_chb;

        if (!n)
            break;   // coverity complaint n-could-be-null
        if (n->type != JSTYPE_object) {
            LOG_ERROR("vi2c_parse_config failed: items in 'devices' shall be "
                      "objects.");
            return EINVAL;
        }
        JSDataNodeObject *n_dev = (JSDataNodeObject *) n;
        vi2c_bus_tree_spec *ts = stat_cfg.cfg.vi2c_bus_trees + i;

        dname = "<noname>";
        if (n_dev->get_field_string("name", &dname, true, 100)) {
            stat_cfg.set_string(&(ts->name), dname);
        }
        if (!n_dev->get_field_string("host-i2c-bus", &valstr, false, 256) ||
            valstr.size() < 1) {
            LOG_ERROR(
                "vi2c_parse_config failed: cannot get name for device #%u", i);
            return EINVAL;
        }
        stat_cfg.set_string(&(ts->host_i2c_bus), valstr);

        if (!n_dev->get_field_integer("i2c-address", &valint, false, true, 0,
                                      1023)) {
            LOG_ERROR("vi2c_parse_config failed: cannot get i2c address for "
                      "device #%u",
                      i);
            return EINVAL;
        }
        ts->i2c_address = (unsigned short) valint;

        valstr = "online";
		#ifdef UNIT_TEST
        if (!n_dev->get_field_string("default-mode", &valstr, true, 8) ||
            !onlinekey_check_valid1(valstr.c_str())) {
		#else
		if (!n_dev->get_field_string("default-mode", &valstr, true, 8) ||
            !onlinekey_check_valid(valstr.c_str())) {
		#endif
            LOG_ERROR("vi2c_parse_config failed: invalid 'default-mode'. "
                      "expect 'online' or 'offline'");
        }
		#ifdef UNIT_TEST
        ts->bDefaultOnline = onlinekey_is_online1(valstr.c_str());
		#else
		ts->bDefaultOnline = onlinekey_is_online(valstr.c_str());
		#endif

        // loop "child-buses"
        if (!n_dev->get_field("child-buses", &n) || n->type != JSTYPE_array) {
            LOG_ERROR("vi2c_parse_config failed: each 'device' shall have a "
                      "list named 'child-buses'");
            return EINVAL;
        }
        n_chb = (JSDataNodeArray *) n;
        if (n_chb->count() > MAX_CHILD_BUSES) {
            LOG_ERROR("vi2c_parse_config failed: device #%u has too many "
                      "child-buses. Static max is %d",
                      i, (int) MAX_CHILD_BUSES);
            return EINVAL;
        }

        // loop all child-buses
        for (unsigned int j = 0; j < n_chb->count(); j++) {
            n = n_chb->get(j);

            if (n->type != JSTYPE_object) {
                LOG_ERROR("vi2c_parse_config failed: items in "
                          "'devices/*/child-buses' shall be objects.");
                return EINVAL;
            }
            JSDataNodeObject *n_c = (JSDataNodeObject *) n;

            vi2c_bus_child_spec *cs = ts->child_buses + j;

            valstr = "";
            if (!n_c->get_field_string("name", &valstr, true, 100)) {
                LOG_ERROR("vi2c_parse_config failed: cannot get name for "
                          "device #%u childbus #%u",
                          i, j);
                return EINVAL;
            }
            stat_cfg.set_string(&(cs->public_name), valstr);

            if (!n_c->get_field_string("devnode-name", &valstr, false, 256)) {
                LOG_ERROR("vi2c_parse_config failed: cannot get devnode-name "
                          "for device #%u childbus #%u",
                          i, j);
                return EINVAL;
            }
            stat_cfg.set_string(&(cs->devnode_name), valstr);

            valstr = "online";
			#ifdef UNIT_TEST
            if (!n_c->get_field_string("default-mode", &valstr, true, 8) ||
                !onlinekey_check_valid1(valstr.c_str())) {
			#else
			if (!n_c->get_field_string("default-mode", &valstr, true, 8) ||
                !onlinekey_check_valid(valstr.c_str())) {
			#endif
                LOG_ERROR("vi2c_parse_config failed: invalid 'default-mode'. "
                          "expect 'online' or 'offline'");
            }
			#ifdef UNIT_TEST
            cs->bDefaultOnline = onlinekey_is_online1(valstr.c_str());
			#else
			cs->bDefaultOnline = onlinekey_is_online(valstr.c_str());
			#endif
        }
    }

    return 0;
}

/// constructor. memsets the config struct to zeroes.
CfgCleaner::CfgCleaner()
{
    memset(&cfg, 0, sizeof(cfg));
}

/// destructor. calls wipe to deallocated all linked strings.
CfgCleaner::~CfgCleaner()
{
    wipe();
}

/// The wipe function sets all string pointers to NULL to deallocate them. See set_string().
void CfgCleaner::wipe()
{
    set_string(&cfg.name, NULL);
    set_string(&cfg.logfilename, NULL);
    for (int i = 0; i < MAX_HOST_BUSES; i++) {
        vi2c_bus_tree_spec *ts = cfg.vi2c_bus_trees + i;
        set_string(&(ts->host_i2c_bus), NULL);
        for (int j = 0; j < MAX_CHILD_BUSES; j++) {
            vi2c_bus_child_spec *cs = ts->child_buses + j;
            set_string(&(cs->public_name), NULL);
            set_string(&(cs->devnode_name), NULL);
        }
    }
    memset(&cfg, 0, sizeof(cfg));
}

/// Assign a string. deallocates old string. allocates a copy for value.
bool CfgCleaner::set_string(const char **field, const char *value)
{
    char *newfield;
    // clear old
    if (*field)
        delete[] * field;
    *field = NULL;
    // if assigning NULL, leave blank.
    if (!value)
        return true;
    // create copy and assign.
    int l = strlen(value);
    newfield = new (std::nothrow) char[l + 1];
    if (!newfield)
        return false;
    memcpy(newfield, value, l + 1); // +1 to copy the null-terminator.
    // fields look const to caller. Inside here, we cast away const to set the
    // field.
    *field = (const char *) newfield;
    return true;
}

/// C++ compatible variant of set_string. Takes a std::string instead. Calls the other.
bool CfgCleaner::set_string(const char **field, std::string &value)
{
    return set_string(field, value.c_str());
}

/// Check if a string is a valid value for the online/offline config field.
#ifdef UNIT_TEST
bool onlinekey_check_valid1(const char *value)
#else
static bool onlinekey_check_valid(const char *value)
#endif
{
    if (!strcmp(value, "on") || !strcmp(value, "online"))
        return true;
    if (!strcmp(value, "off") || !strcmp(value, "offline"))
        return true;
    return false;
}

/// Check if a string is the 'online' keyword of a config. online_check_valid() first!
#ifdef UNIT_TEST
bool onlinekey_is_online1(const char *value)
#else
static bool onlinekey_is_online(const char *value)
#endif
{
    return (!strcmp(value, "on") || !strcmp(value, "online"));
}
