/******************************************************************
*FILE: vi2c.c
*SW-COMPONENT: virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

#include <stdlib.h>
#include <stdbool.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include "config.h"
#include "vi2c-daemon.h"
#include "vi2c_logger.h"
#ifdef UNIT_TEST
#include "i2c_mock.h"
#include "slog2_header.h"
#endif

#ifndef UNIT_TEST
typedef enum
{
    SHOW_CONSOLE=1,
    SHOW_SLOG
}CONFIG_SHOW_TYPE;
#endif
////////////////////////////////////////////////////////////////////
//
static int program_run = 1;
#ifdef UNIT_TEST
void signal_handler1(int sig)
#else
void signal_handler(int sig)
#endif
{
	LOG_CRITICAL_INFO("vi2c_logger_init fail\n");
    LOG_EM("vi2c_logger_init fail\n");
	program_run = 0;
}
#ifdef UNIT_TEST
void vi2c_show_daemon_config1(struct vi2c_daemon_config *cfg, CONFIG_SHOW_TYPE type)
#else
void vi2c_show_daemon_config(struct vi2c_daemon_config *cfg, CONFIG_SHOW_TYPE type)
#endif
{
    switch (type) {
        case SHOW_CONSOLE:
            printf("cfg name  '%s'\n", cfg->name ? cfg->name : "NULL");
            printf("cfg log  '%s'\n",
                cfg->logfilename ? cfg->logfilename : "<none>");
            for (int i = 0; i < MAX_HOST_BUSES; i++) {
                if (!cfg->vi2c_bus_trees[i].host_i2c_bus)
                    break;
                printf("cfg   dev#%d name '%s'\n", i, cfg->vi2c_bus_trees[i].name);
                printf("cfg     dev#%d i2c host bus  '%s'\n", i,
                    cfg->vi2c_bus_trees[i].host_i2c_bus);
                printf("cfg     dev#%d i2c adr    %u\n", i,
                    (unsigned int) cfg->vi2c_bus_trees[i].i2c_address);
                printf("cfg     dev#%d default %s\n", i,
                    cfg->vi2c_bus_trees[i].bDefaultOnline ? "online"
                                                            : "offline");
                for (int j = 0; j < MAX_CHILD_BUSES; j++) {
                    struct vi2c_bus_child_spec *cs =
                        cfg->vi2c_bus_trees[i].child_buses + j;
                    if (!cs->devnode_name)
                        break;
                    printf("cfg     dev#%d   ch#%d name '%s'\n", i, j,
                        cs->public_name ? cs->public_name : "NULL");
                    printf("cfg     dev#%d     ch#%d devnode '%s'\n", i, j,
                        cs->devnode_name);
                    printf("cfg     dev#%d     ch#%d default %s\n", i, j,
                        cs->bDefaultOnline ? "online" : "offline");
                }
            }
            break;
        case SHOW_SLOG:
            LOG_INFO("cfg name  '%s'", cfg->name ? cfg->name : "NULL");
            LOG_INFO("cfg log  '%s'",
                    cfg->logfilename ? cfg->logfilename : "<none>");
            for (int i = 0; i < MAX_HOST_BUSES; i++) {
                if (!cfg->vi2c_bus_trees[i].host_i2c_bus)
                    break;
                LOG_INFO("cfg   dev#%d name '%s'", i, cfg->vi2c_bus_trees[i].name);
                LOG_INFO("cfg     dev#%d i2c host bus  '%s'", i,
                        cfg->vi2c_bus_trees[i].host_i2c_bus);
                LOG_INFO("cfg     dev#%d i2c adr    %u", i,
                        (unsigned int) cfg->vi2c_bus_trees[i].i2c_address);
                LOG_INFO("cfg     dev#%d default %s", i,
                        cfg->vi2c_bus_trees[i].bDefaultOnline ? "online"
                                                                : "offline");
                for (int j = 0; j < MAX_CHILD_BUSES; j++) {
                    struct vi2c_bus_child_spec *cs =
                        cfg->vi2c_bus_trees[i].child_buses + j;
                    if (!cs->devnode_name)
                        break;
                    LOG_INFO("cfg     dev#%d   ch#%d name '%s'", i, j,
                            cs->public_name ? cs->public_name : "NULL");
                    LOG_INFO("cfg     dev#%d     ch#%d devnode '%s'", i, j,
                            cs->devnode_name);
                    LOG_INFO("cfg     dev#%d     ch#%d default %s", i, j,
                            cs->bDefaultOnline ? "online" : "offline");
                }
            }
            break;
        default:
            break;
    }

    return;
}
#ifdef UNIT_TEST
int main1(int argc, char *argv[])
#else
int main(int argc, char *argv[])
#endif
{
    struct vi2c_daemon_config *cfg = NULL;
    int ret;
    int opt;
    char bDbgConf = 0;
    const char *configFile;

    // look at command-line options.
    configFile = NULL;
    #ifdef UNIT_TEST
    if ((opt = getopt(argc, argv, "c:xh")) != -1) {
    #else
    while ((opt = getopt(argc, argv, "c:xh")) != -1) {
    #endif
        switch (opt) {
            case 'c':
                configFile = optarg;
                break;

            case 'x':
                bDbgConf = 1;
                break;

            case 'h':
                printf("valid options:\n");
                printf(" -c <filename>     Specify config file.\n");
                printf(" -x                debug-config. Just print config and "
                       "exit.\n");
                printf(" -h                show list of options.\n");
                return 0;

            default:
                printf("for list of valid options, use '-h'.\n");
                return 1;
        }
    }

    if (!configFile) {
        fprintf(
            stderr,
            "need to have a configfile to start the daemon. Use option -c .\n");
        LOG_EM("need to have a configfile to start the daemon. Use option -c .\n");
        return 1;
    }

    if (vi2c_logger_init() == EOK)
        vi2c_logger_set_state(true);
    else
        LOG_ERROR("vi2c_logger_init fail\n");

    ret = vi2c_parse_config(configFile);
    if (ret) {
        // Log parser failure and exit
        LOG_ERROR("vi2c_parse_config fail (ret=%d)\n", ret);
        LOG_EM("vi2c_parse_config fail (ret=%d)\n", ret);
        return 1;
    }

    cfg = vi2c_get_daemon_config();
    if (!cfg) {
        // Log configuration error and exit
        LOG_ERROR("vi2c_get_daemon_config fail\n");
        LOG_EM("vi2c_get_daemon_config fail\n");
        return 1;
    }

    // a piece of debug code. print config and exit.
    if (bDbgConf) {
    	#ifdef UNIT_TEST
        vi2c_show_daemon_config1(cfg, SHOW_CONSOLE);
        vi2c_show_daemon_config1(cfg, SHOW_SLOG);
        #else
        vi2c_show_daemon_config(cfg, SHOW_CONSOLE);
        vi2c_show_daemon_config(cfg, SHOW_SLOG);
        #endif
        vi2c_delete_daemon_config(cfg);
        return 1;
    }

    ret = vi2c_daemon_init(cfg);
    if (ret) {
        // Log daemon initialization failure and exit
        LOG_ERROR("vi2c_daemon_init fail (ret=%d)\n", ret);
        LOG_EM("vi2c_daemon_init fail (ret=%d)\n", ret);
        vi2c_delete_daemon_config(cfg);
        return 1;
    }
    LOG_INFO("vi2c daemon init was successful");

    vi2c_daemon_set_default_online();

    vi2c_daemon_start();
    #ifdef UNIT_TEST
    signal(SIGTERM, signal_handler1);
    signal(SIGINT, signal_handler1); // Ctrl+C
    #else
    signal(SIGTERM, signal_handler);
    signal(SIGINT, signal_handler); // Ctrl+C
    #endif

    LOG_INFO("vi2c daemon started to serve requests");
    // Place here signal handling and stop daemon when it is interrupted
    // Wait for a signal...
    while (program_run) {
        (void)usleep(1000 * 1000);
    };
    LOG_CRITICAL_INFO("vi2c daemon was interupted");

    vi2c_daemon_stop();

    vi2c_daemon_destroy();

    vi2c_delete_daemon_config(cfg);
    LOG_CRITICAL_INFO("vi2c daemon was de-initialized and is stopped");

    return 0;
}
