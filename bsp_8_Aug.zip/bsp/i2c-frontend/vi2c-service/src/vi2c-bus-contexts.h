#pragma once

#include <stdbool.h>

#include "config.h"
#include "i2cdevnode.h"

#ifdef UNIT_TEST
int fidm_i2c_init1(struct vi2c_bus_tree_context *ctx);
int fidm_i2c_set_slave1(struct vi2c_bus_tree_context *ctx);
void fidm_i2c_deinit1(struct vi2c_bus_tree_context *ctx);
int fidm_i2c_write1(struct vi2c_bus_tree_context *ctx, unsigned char *data, unsigned char len);
int fidm_i2c_writeread1(struct vi2c_bus_tree_context *ctx, uint8_t* wbuf, uint32_t wlen, uint8_t *rbuf, uint32_t rlen);
int fidm_i2c_read_only1(struct vi2c_bus_tree_context *ctx, unsigned char *data, unsigned char len);
int vi2c_bus_tree_context_add_child1(struct vi2c_bus_tree_context *tree_ctx,struct vi2c_bus_child_context *child_ctx);
void vi2c_bus_tree_set_helpers1(struct vi2c_bus_tree_context *ctx);
int vi2c_bus_tree_self_config1(struct vi2c_bus_tree_context *ctx,struct vi2c_bus_tree_spec *tree_spec);
void vi2c_bus_tree_populate_buses1(struct vi2c_bus_tree_context *tree_ctx);

int vi2c_bus_child_check_online2(struct vi2c_bus_child_context *ctx);
void vi2c_bus_child_analize_ret2(struct vi2c_bus_child_context *ctx, int ret);
int callback_send_recvbytes2(void *ctx, unsigned short slaveNo,  uint8_t *wdata, uint32_t wlen, uint8_t *rdata, uint32_t rlen);
int callback_send2(void *ctx, unsigned short slaveNo, unsigned char *data, unsigned int len);
int callback_recv2(void *ctx, unsigned short slaveNo, unsigned char *data, unsigned int len);
int callback_stop2(void *ctx);
void vi2c_bus_child_set_callbacks2(struct vi2c_bus_child_context *child_ctx);
void vi2c_bus_child_set_devnode_name2(struct vi2c_bus_child_context *child_ctx, const char *devnode_name);
#endif

/***************************************************/
/* Context structures
* We can use them to track all activities
*/

struct vi2c_bus_tree_context;

/* A context of a single virtual I2C bus
   Shall contain following:
     - All callbacks that are passed to the virtual I2C lib
         - Device node handle returned by the virtual I2C lib
         - Current status (like online / offline)
         - Reference to the configuration
         - Fault counters
         - Reference to the host I2C bus context */
struct vi2c_bus_child_context {
    I2Cdevnode_funcs_parameters callbacks;
    struct i2cdevnode *dn;

    struct vi2c_bus_child_spec *bus_spec;
    struct vi2c_bus_tree_context *tree_context;

    bool online;
};

/* A context of a single host I2C with multiple child virtual I2Cs
    Shall contain following:
          - List of child virtual I2C buses (their contexts)
          - Reference to configuration
          - Fault caounters */
struct vi2c_bus_tree_context {
    // Child buses and their contexts
    struct vi2c_bus_child_context *child_buses[MAX_CHILD_BUSES];
    int nchild_buses;

    struct vi2c_bus_tree_spec *tree_spec;
    int host_fd;
    unsigned char address;

    bool online;

    struct {
        int (*sendbytes)(struct vi2c_bus_tree_context *ctx, unsigned char *data,
                         unsigned char len);
        /* process a RECV request */
        int (*recvbytes)(struct vi2c_bus_tree_context *ctx, unsigned char *data,
                         unsigned char len);
        /* process a RECV request */
        int (*send_recvbytes)(struct vi2c_bus_tree_context *ctx, uint8_t* wdata, uint32_t wlen,
                              uint8_t *rdata, uint32_t rlen);
        /* process a STOP request */
        int (*stop)(struct vi2c_bus_tree_context *ctx);
        /* process a RESET request */
        int (*busreset)(struct vi2c_bus_tree_context *ctx);
    } helpers;
};

/*********************************************
* Child Virtual I2C bus functions
*/

/* Functions to create a destroy child bus contexts */
struct vi2c_bus_child_context *vi2c_bus_child_create(
    struct vi2c_bus_tree_context *tree_ctx, struct vi2c_bus_child_spec *spec);
void vi2c_bus_child_destroy(struct vi2c_bus_child_context *ctx);

/* Function to change bus online/offline mode */
int vi2c_bus_child_set_online(struct vi2c_bus_child_context *ctx, bool online);

int vi2c_bus_child_set_default_online(struct vi2c_bus_child_context *ctx);

/* Returns a public name of the virtual I2C child */
const char *vi2c_bus_child_get_name(struct vi2c_bus_child_context *ctx);

/*********************************************
* Functions for the virtual tree
*/

/* Functions to create a destroy i2c tree contexts */
struct vi2c_bus_tree_context *vi2c_bus_tree_context_create(
    struct vi2c_bus_tree_spec *tree_spec);
void vi2c_bus_tree_context_destroy(struct vi2c_bus_tree_context *ctx);

/* Function to change online/offline mode for the complete tree */
int vi2c_bus_tree_context_set_online(struct vi2c_bus_tree_context *ctx,
                                     bool online);

int vi2c_bus_tree_context_set_default_online(struct vi2c_bus_tree_context *ctx);

/* Function to find a child by its name */
struct vi2c_bus_child_context *vi2c_bus_tree_context_find_child(
    const char *name);
void vi2c_bus_tree_context_destroy(struct vi2c_bus_tree_context *tree_ctx);
