
/******************************************************************
*FILE: vi2c-daemon.c
*SW-COMPONENT: virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

#include <errno.h>
#include <string.h>

#include "vi2c-bus-contexts.h"
#include "vi2c-daemon.h"
#include "vi2c_logger.h"
#ifdef UNIT_TEST
#include "i2c_mock.h"
#endif
struct vi2_daemon {
    struct vi2c_bus_tree_context *bus_trees[MAX_HOST_BUSES];
    int nbus_trees;
};

static struct vi2_daemon __vi2_daemon;

// Use this function to take an instance of the daemon
struct vi2_daemon *get_daemon()
{
    return &__vi2_daemon;
}
#ifdef UNIT_TEST
int vi2c_daemon_add_tree1(struct vi2c_bus_tree_context *tree_ctx)
#else
static int vi2c_daemon_add_tree(struct vi2c_bus_tree_context *tree_ctx)
#endif
{
    if (MAX_HOST_BUSES <= __vi2_daemon.nbus_trees) {
        return -ENOMEM;
    }

    __vi2_daemon.bus_trees[__vi2_daemon.nbus_trees] = tree_ctx;

    __vi2_daemon.nbus_trees++;

    return 0;
}

int vi2c_daemon_init(struct vi2c_daemon_config *config)
{
    struct vi2c_bus_tree_context *tree_ctx;
    struct vi2c_bus_tree_spec *tree_spec;
    int ret = 0;

    memset(&__vi2_daemon, 0, sizeof(__vi2_daemon));

    tree_spec = config->vi2c_bus_trees;
    while (tree_spec && tree_spec->host_i2c_bus) {
        LOG_INFO("vi2c_bus_tree_context_create %s", tree_spec->host_i2c_bus);
        tree_ctx = vi2c_bus_tree_context_create(tree_spec);
        if (!tree_ctx) {
            // Log fault
            LOG_ERROR("vi2c_bus_tree_context_create fail: %s",
                      tree_spec->host_i2c_bus);
            LOG_EM("vi2c_bus_tree_context_create fail: %s",
                                    tree_spec->host_i2c_bus);
            vi2c_daemon_destroy();
            return -EFAULT;
        }
	#ifdef UNIT_TEST
        ret = vi2c_daemon_add_tree1(tree_ctx);
        #else
        ret = vi2c_daemon_add_tree(tree_ctx);
        #endif
        if (ret) {
            LOG_ERROR("vi2c_daemon_add_tree fail (ret=%d)", ret);
            LOG_EM("vi2c_daemon_add_tree fail (ret=%d)", ret);
            vi2c_daemon_destroy();
            return ret;
        }

        tree_spec++;
    }
    LOG_INFO("total vi2c_daemon : %d", __vi2_daemon.nbus_trees);
    LOG_EM("total vi2c_daemon : %d", __vi2_daemon.nbus_trees);
    return ret;
}

void vi2c_daemon_set_default_online()
{
    struct vi2c_bus_tree_context *tree_ctx;
    int ret;
    int i;

    LOG_INFO("vi2c_daemon_set_default_online total vi2c_daemon : %d",
             __vi2_daemon.nbus_trees);
    for (i = 0; i < __vi2_daemon.nbus_trees; i++) {
        tree_ctx = __vi2_daemon.bus_trees[i];
        LOG_INFO("vi2c_daemon_set_default_online nbus_trees index >> %d", i);
        ret = vi2c_bus_tree_context_set_default_online(tree_ctx);
        if (ret) {
            LOG_ERROR("vi2c_bus_tree_context_set_default_online failed (ret=%d)\n", ret);
            LOG_EM("vi2c_bus_tree_context_set_default_online failed (ret=%d)\n", ret);
            return;
        }
    }
}

/* Start full operation of the daemon */
int vi2c_daemon_start()
{
    return 0;
}

void vi2c_daemon_stop()
{
}

/* Clean-up */
void vi2c_daemon_destroy()
{
    int i;
    struct vi2c_bus_tree_context *tree_ctx;
    for (i = 0; i < __vi2_daemon.nbus_trees; i++) {
        tree_ctx = __vi2_daemon.bus_trees[i];
        LOG_INFO("vi2c_daemon_destroy nbus_trees index >> %d", i);
        LOG_EM("vi2c_daemon_destroy nbus_trees index >> %d", i);
        vi2c_bus_tree_context_set_online(tree_ctx, false);
        vi2c_bus_tree_context_destroy(tree_ctx);
    }
}
