#pragma once

/***************************************************/
/* Configuration structures
* We can initiliaze them and use them to create buses
*/

#define MAX_CHILD_BUSES 16
#define MAX_HOST_BUSES 8
#include <string>
#ifdef __cplusplus
extern "C" { /* Keep header compatible with being used from C++ code. */
#endif

#ifdef UNIT_TEST
bool onlinekey_check_valid1(const char *value);
bool onlinekey_is_online1(const char *value);
#endif
/* Specification for a one virtual I2C bus */
struct vi2c_bus_child_spec {
    const char *public_name;  // "logical" name of the bus
    const char *devnode_name; // Device node to create
    char bDefaultOnline;      // ..... todo: not yet used.

    // Shall also get following:
    //  - default policy (online / offline)
    //  - list of allowed registers
    //  - failure-handling policy (like 3 sequential faults
    //    means a complete fault
};

/* Specification for a one host bus and dependent virtual buses */
struct vi2c_bus_tree_spec {
    const char *name;           // ..... todo: not yet used.
    const char *host_i2c_bus;   // Name of the host I2C bus
    unsigned short i2c_address; // Address of the shared chip
    char bDefaultOnline; // default to online? zero = def-to-offline   .....
                         // todo: not yet used.

    struct vi2c_bus_child_spec
        child_buses[MAX_CHILD_BUSES]; // Specifications of all the
                                      // child buses

    // Shall also get following:
    //  - failure-handling policy (like 3 sequential faults
    //    means a complete fault)
};

/* Overall daemon configuration */
struct vi2c_daemon_config {
    const char *name;
    char bUseSlogger2;
    const char *logfilename;
    struct vi2c_bus_tree_spec
        vi2c_bus_trees[MAX_HOST_BUSES]; // List of the buses
                                        // Default mode
};
#ifdef UNIT_TEST
class CfgCleaner
{
  public:
    CfgCleaner();
    ~CfgCleaner();

    void wipe();

    bool set_string(const char **field, const char *value);
    bool set_string(const char **field, std::string &value);

    struct vi2c_daemon_config cfg;
};
#endif

int vi2c_parse_config(const char *conf_file_name);
struct vi2c_daemon_config *vi2c_get_daemon_config();
void vi2c_delete_daemon_config(struct vi2c_daemon_config *cfg);

#ifdef __cplusplus
}
#endif
