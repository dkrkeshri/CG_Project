/******************************************************************
*FILE: vi2c-tree.c
*SW-COMPONENT: virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

#include <errno.h>
#include <stdlib.h>
#include <unistd.h>

#include "vi2c_logger.h"
#ifndef UNIT_TEST
#ifndef NO_I2C_IMPLEMENTATION
#include "i2c_client.h"
#endif
#endif
#ifdef UNIT_TEST
#include "i2c_mock.h"
#include "slog2_header.h"
#endif
#include "config.h"
#include "vi2c-bus-contexts.h"

#define VI2C_RW_PRINT_LEN 128
#ifdef UNIT_TEST
int fidm_i2c_init1(struct vi2c_bus_tree_context *ctx)
#else
static int fidm_i2c_init(struct vi2c_bus_tree_context *ctx)
#endif
{
    int ret = 0;

#ifndef NO_I2C_IMPLEMENTATION
    ret = i2c_open(
        (char *) ctx->tree_spec
            ->host_i2c_bus); // i2c_open is defined with non-const name...
    if (ret > 0) {
        ctx->host_fd = ret;
        LOG_INFO("Host i2c open SUCCESS : %s", ctx->tree_spec->host_i2c_bus);
        LOG_EM("Host i2c open SUCCESS : %s", ctx->tree_spec->host_i2c_bus);
    } else {
        LOG_ERROR("Host i2c open failed, (%d)%s", ret, strerror(errno));
        LOG_EM("Host i2c open failed, (%d)%s", ret, strerror(errno));
    }
#endif

    return ret;
}

#ifdef UNIT_TEST
int fidm_i2c_set_slave1(struct vi2c_bus_tree_context *ctx)
#else
static int fidm_i2c_set_slave(struct vi2c_bus_tree_context *ctx)
#endif
{
    int ret = 0;
#ifndef NO_I2C_IMPLEMENTATION
 #ifndef UNIT_TEST																							//NEED TO MODIFY
    LOG_INFO("BUS %s i2c_set_slave_addr 0x%x", ctx->tree_spec->host_i2c_bus,ctx->tree_spec->i2c_address);
 #else
 // LOG_INFO("BUS %s i2c_set_slave_addr 0x%x", ctx->tree_spec->host_i2c_bus,ctx->tree_spec->i2c_address);
 #endif																										//NEED TO MODIFY
    ret = i2c_set_slave_addr(ctx->host_fd, ctx->tree_spec->i2c_address, I2C_ADDRFMT_7BIT);
#endif
    return ret;
}

#ifdef UNIT_TEST
void fidm_i2c_deinit1(struct vi2c_bus_tree_context *ctx)
#else
static void fidm_i2c_deinit(struct vi2c_bus_tree_context *ctx)
#endif
{
#ifndef NO_I2C_IMPLEMENTATION
    i2c_close(ctx->host_fd);

    ctx->host_fd = -1;
#endif
}

#ifdef UNIT_TEST
int fidm_i2c_write1(struct vi2c_bus_tree_context *ctx,
                          unsigned char *data, unsigned char len)
#else
static int fidm_i2c_write(struct vi2c_bus_tree_context *ctx,
                          unsigned char *data, unsigned char len)
#endif
{
    // In general:
    // Check that all things are in place:
    //  - Online mode
    //  - Valid FD
    //  - No other faults, etc...
    int iRetVal = -1;

#ifndef NO_I2C_IMPLEMENTATION
    unsigned char iCount;

    iRetVal = i2c_write(ctx->host_fd, data, len);
    if (len != iRetVal) {
        LOG_ERROR("i2c_write() FAILED, iRetVal=%d", iRetVal);
        for (iCount = 0; iCount <= len; iCount++) {
            LOG_ERROR("data=0x%02x", data[iCount]);
            LOG_EM("i2c_write FAILED.Host_id=%s, data=0x%02x",
                                ctx->tree_spec->host_i2c_bus, data[iCount]);
        }
        goto fail;
    }

fail:
#endif
    return iRetVal;
}

#ifdef UNIT_TEST
int fidm_i2c_writeread1(struct vi2c_bus_tree_context *ctx, uint8_t* wbuf, uint32_t wlen,
                         uint8_t *rbuf, uint32_t rlen)
#else
static int fidm_i2c_writeread(struct vi2c_bus_tree_context *ctx, uint8_t* wbuf, uint32_t wlen,
                         uint8_t *rbuf, uint32_t rlen)
#endif
{
    int iRetVal = -1;

#ifndef NO_I2C_IMPLEMENTATION
    unsigned char iCount;
    char rwbuf[VI2C_RW_PRINT_LEN] = {0};
    #ifdef UNIT_TEST
    int str_len = -1;
    #else
    int str_len = 0;
    #endif
    int snp_len = 0;
    memset(rbuf, 0, sizeof(rlen));
    iRetVal = i2c_combined_writeread(ctx->host_fd, wbuf, wlen, rbuf, rlen);
    if (rlen != iRetVal) {
   // #ifndef UNIT_TEST																									//NEED TO MODIFY
        LOG_ERROR("Bus %s, i2c_combined_writeread() FAILED, iRetVal=%d", ctx->tree_spec->host_i2c_bus, iRetVal);
        LOG_EM("Bus %s, i2c_combined_writeread() FAILED, iRetVal=%d", ctx->tree_spec->host_i2c_bus, iRetVal);
        str_len = snprintf (rwbuf, VI2C_RW_PRINT_LEN, "wbuf ="); /* make sure LEN enough, avoid memory stomped */
    //#endif																												//NEED TO MODIFY
        if (str_len < 0) {
            goto fail;
        }
        for (iCount = 0; iCount < wlen; iCount++) {
            snp_len = snprintf (rwbuf + str_len, VI2C_RW_PRINT_LEN - str_len - 1, " 0x%02x", wbuf[iCount]);
            if (snp_len < 0) {
                goto fail;
            } else {
                str_len += snp_len;
            }
        }
        LOG_ERROR("%s", rwbuf);
        LOG_EM("%s", rwbuf);
        memset(rwbuf, 0, VI2C_RW_PRINT_LEN);
        str_len = snprintf (rwbuf, VI2C_RW_PRINT_LEN, "rbuf =");
        if (str_len < 0) {
            goto fail;
        }
        for (iCount = 0; iCount < rlen; iCount++) {
            snp_len = snprintf (rwbuf + str_len, VI2C_RW_PRINT_LEN - str_len - 1, " 0x%02x", rbuf[iCount]);
            if (snp_len < 0) {
                goto fail;
            } else {
                str_len += snp_len;
            }
        }
        LOG_ERROR("%s", rwbuf);
        LOG_EM("%s", rwbuf);
        goto fail;
    }

fail:
#endif
    return iRetVal;
}

#ifdef UNIT_TEST
int fidm_i2c_read_only1(struct vi2c_bus_tree_context *ctx,
                              unsigned char *data, unsigned char len)
#else
static int fidm_i2c_read_only(struct vi2c_bus_tree_context *ctx,
                              unsigned char *data, unsigned char len)
#endif
{
    int iRetVal = -1;

#ifndef NO_I2C_IMPLEMENTATION
    unsigned char iCount;

    iRetVal = i2c_read(ctx->host_fd, data, len);
    if (len != iRetVal) {
        LOG_ERROR("i2c_read() FAILED, iRetVal=%d", iRetVal);
        for (iCount = 0; iCount <= len; iCount++) {
            LOG_ERROR("data=0x%02x", data[iCount]);
            LOG_EM("i2c_read FAILED.Host_id=%s, data=0x%02x",
                                ctx->tree_spec->host_i2c_bus, data[iCount]);
        }
        goto fail;
    }

fail:
#endif
    return iRetVal;
}
#ifdef UNIT_TEST
int vi2c_bus_tree_context_add_child1(struct vi2c_bus_tree_context *tree_ctx, struct vi2c_bus_child_context *child_ctx)
#else
static int vi2c_bus_tree_context_add_child(struct vi2c_bus_tree_context *tree_ctx, struct vi2c_bus_child_context *child_ctx)
#endif
{
    if (MAX_CHILD_BUSES <= tree_ctx->nchild_buses) {
        return -ENOMEM;
    }
 //#ifndef UNIT_TEST																	//NEED TO MODIFY
    tree_ctx->child_buses[tree_ctx->nchild_buses] = child_ctx;
    child_ctx->tree_context = tree_ctx;
    tree_ctx->nchild_buses++;
 //#endif																				//NEED TO MODIFY
    return 0;
}

#ifdef UNIT_TEST
void vi2c_bus_tree_set_helpers1(struct vi2c_bus_tree_context *ctx)
#else
static void vi2c_bus_tree_set_helpers(struct vi2c_bus_tree_context *ctx)
#endif
{
	#ifdef UNIT_TEST
    ctx->helpers.sendbytes = fidm_i2c_write1;
    ctx->helpers.recvbytes = fidm_i2c_read_only1;
    ctx->helpers.send_recvbytes = fidm_i2c_writeread1;
    #else
    ctx->helpers.sendbytes = fidm_i2c_write;
    ctx->helpers.recvbytes = fidm_i2c_read_only;
    ctx->helpers.send_recvbytes = fidm_i2c_writeread;
    #endif
}

#ifdef UNIT_TEST
int vi2c_bus_tree_self_config1(struct vi2c_bus_tree_context *ctx,
                                     struct vi2c_bus_tree_spec *tree_spec)
#else
static int vi2c_bus_tree_self_config(struct vi2c_bus_tree_context *ctx,
                                     struct vi2c_bus_tree_spec *tree_spec)
#endif
{
    int fd;
    // As of now just copy a reference for the static configuration
    ctx->tree_spec = tree_spec;
	#ifdef UNIT_TEST
    fd = fidm_i2c_init1(ctx);
     #else
     fd = fidm_i2c_init(ctx);
     #endif
    if (fd < 0){
        LOG_ERROR("fidm_i2c_init failed (%d)%s", fd, strerror(errno));
        LOG_EM("vi2c_fidm_i2c_init failed (%d)%s", fd, strerror(errno));
    }
    #ifdef UNIT_TEST
    fidm_i2c_set_slave1(ctx);
    #else
    fidm_i2c_set_slave(ctx);
    #endif
    // todo: create a function to set speed
    unsigned int speed = 0;
//#ifndef UNIT_TEST																	//NEED TO MODIFY
    if (i2c_set_bus_speed(ctx->host_fd, I2C_SPEED_FAST, &speed) < 0){
        LOG_ERROR("i2c_set_bus_speed failed");
        LOG_EM("vi2c_i2c_set_bus_speed failed");
    }
    else
        LOG_INFO("BUS %s i2c_set_bus_speed type %d", ctx->tree_spec->host_i2c_bus, speed);
printf("DEBUG %d %s\n",__LINE__,__func__);
    /*Todo: Below i2c_deinit code was added to resolve coverity issue but
     *it leads to vi2c not working for brightness and faceplate
     */
    //fidm_i2c_deinit(ctx);
//#endif																				//NEED TO MODIFY
    return EOK;
}

#ifdef UNIT_TEST
void vi2c_bus_tree_populate_buses1(struct vi2c_bus_tree_context *tree_ctx)
#else
static void vi2c_bus_tree_populate_buses(struct vi2c_bus_tree_context *tree_ctx)
#endif
{
    struct vi2c_bus_child_context *child_ctx;
    int i = 0;

    for (i = 0; i < tree_ctx->nchild_buses; i++) {
        child_ctx = tree_ctx->child_buses[i];

        i2cdevnode__enableSlave(child_ctx->dn, tree_ctx->tree_spec->i2c_address,1);
        LOG_INFO("Device node %s enabled",
                 child_ctx->bus_spec->devnode_name); // weller
    }
}

struct vi2c_bus_tree_context *vi2c_bus_tree_context_create(
    struct vi2c_bus_tree_spec *tree_spec)
{
    struct vi2c_bus_child_context *child_ctx;
    struct vi2c_bus_tree_context *tree_ctx;
    struct vi2c_bus_child_spec *child_spec;
    int ret;
    tree_ctx = (struct vi2c_bus_tree_context *)calloc(1, sizeof(*tree_ctx));
    if (!tree_ctx) {
        LOG_ERROR("calloc tree_ctx failed\n");
        LOG_EM("vi2c_calloc tree_ctx failed\n");
        return NULL;
    }
	#ifdef UNIT_TEST
    ret = vi2c_bus_tree_self_config1(
        tree_ctx,
        tree_spec); // Take the name of the host I2C bus, policies, etc
    #else
    ret = vi2c_bus_tree_self_config(
        tree_ctx,
        tree_spec);
    #endif
    if (ret != EOK) {
        LOG_ERROR("vi2c_bus_tree_self_config failed\n");
        LOG_EM("vi2c_bus_tree_self_config failed\n");
        goto free_tree_ctx;
    }
	#ifdef UNIT_TEST
    vi2c_bus_tree_set_helpers1(tree_ctx);
	#else
	vi2c_bus_tree_set_helpers(tree_ctx);
	#endif
    child_spec = tree_spec->child_buses;
    while (child_spec && child_spec->devnode_name) {
        child_ctx = vi2c_bus_child_create(tree_ctx, child_spec);
        if (!child_ctx) {
            LOG_ERROR("vi2c_bus_child_create fail for %s",
                      child_spec->devnode_name);
            LOG_EM("vi2c_bus_child_create fail for %s",
                      child_spec->devnode_name);
            goto cleanup_tree_ctx;
        }
	#ifdef UNIT_TEST
        ret = vi2c_bus_tree_context_add_child1(tree_ctx, child_ctx);
        #else
        ret = vi2c_bus_tree_context_add_child(tree_ctx, child_ctx);
        #endif
        if (ret != 0) {
            LOG_ERROR("vi2c_bus_tree_context_add_child fail (ret=%d)", ret);
            LOG_EM("vi2c_bus_tree_context_add_child fail, ret=%d\n",ret);
            goto cleanup_tree_ctx;
        }
        child_spec++;
    }
    // Show all the device nodes
    #ifdef UNIT_TEST
    vi2c_bus_tree_populate_buses1(tree_ctx);
    #else
    vi2c_bus_tree_populate_buses(tree_ctx);
    #endif
    return tree_ctx;

cleanup_tree_ctx:
// vi2c_bus_tree_context_destroy(tree_ctx);
free_tree_ctx:
	 #ifdef UNIT_TEST
    fidm_i2c_deinit1(tree_ctx);
    #else
    fidm_i2c_deinit(tree_ctx);
    #endif
    free(tree_ctx);
    return NULL;
}

int vi2c_bus_tree_context_set_online(struct vi2c_bus_tree_context *ctx,
                                     bool online)
{
    struct vi2c_bus_child_context *child_ctx;
    int ret = 0;
    int ret_offline = 0;
    int i;

    if (online) {
        if (ctx->online) {
            return 0; // Nothing to do we are online
        }
        // Open I2C bus
        // Set slave address
        ctx->online = true;

        // Finally make all child buses online
        for (i = 0; i < ctx->nchild_buses; i++) {
            child_ctx = ctx->child_buses[i];
            ret = vi2c_bus_child_set_default_online(child_ctx);
            if (ret) {
                LOG_ERROR("BUS %s set online fail (ret=%d)",
                          child_ctx->bus_spec->devnode_name, ret);
                LOG_EM("BUS %s set online fail (ret=%d)",
                          child_ctx->bus_spec->devnode_name, ret);
                return ret;
            }
            LOG_CRITICAL_INFO("Bus %s set online",
                              child_ctx->bus_spec->devnode_name);
            LOG_EM("Bus %s set online",
                               child_ctx->bus_spec->devnode_name);
        }
    } else {
        if (!ctx->online) {
            return 0; // Nothing to do we are online
        }

        // First suspend all child buses
        for (i = 0; i < ctx->nchild_buses; i++) {
            child_ctx = ctx->child_buses[i];
            ret_offline = vi2c_bus_child_set_online(child_ctx, false);
            if (ret_offline) {
                LOG_ERROR("Bus %s set offline fail (return value: %d)",
                              child_ctx->bus_spec->devnode_name, ret_offline);
                LOG_EM("Bus %s set offline fail (return value: %d)",
                              child_ctx->bus_spec->devnode_name, ret_offline);
            } else {
                LOG_CRITICAL_INFO("Bus %s set offline",
                              child_ctx->bus_spec->devnode_name);
                LOG_EM("Bus %s set offline",child_ctx->bus_spec->devnode_name);
            }

            ret += ret_offline;
        }

        ctx->online = false;

        // Close fd
    }
    return ret;
}

int vi2c_bus_tree_context_set_default_online(struct vi2c_bus_tree_context *ctx)
{
    // FIXME: That is hardcode
    // The real code shall take default online/offline state from configuration
    return vi2c_bus_tree_context_set_online(ctx, 1);
}

void vi2c_bus_tree_context_destroy(struct vi2c_bus_tree_context *tree_ctx)
{
//#ifndef UNIT_TEST															//NEED TO MODIFY
    struct vi2c_bus_child_context *child_ctx;
    int i;
    for (i = 0; i < tree_ctx->nchild_buses; i++) {
        child_ctx = tree_ctx->child_buses[i];
        vi2c_bus_child_destroy(child_ctx);
        free(child_ctx);
    }
    #ifdef UNIT_TEST
    fidm_i2c_deinit1(tree_ctx);
    free(tree_ctx);
    #else
    fidm_i2c_deinit(tree_ctx);
    free(tree_ctx);
    #endif
  // #endif																	//NEED TO MODIFY
   
}
