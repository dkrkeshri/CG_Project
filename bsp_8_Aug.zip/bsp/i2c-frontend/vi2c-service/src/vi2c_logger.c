/******************************************************************
*FILE: vi2c_logger.c
*SW-COMPONENT: virtual i2c resource manager logger
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#ifndef UNIT_TEST
#include <sys/slog2.h>
#include <process.h>
#include <sys/slogcodes.h>
#else
#include "slog2_header.h"
#include "i2cdevnode.h"
#include "i2c_mock.h"
#include "UT-unistd-mock.h"
#include "ipc_header.h"
#endif
#ifdef __cplusplus
extern "C" {
#endif

static slog2_buffer_set_config_t sBufferConfig;
slog2_buffer_t pBufferHandle[1];
static bool bLogBufferInitialized = false;
static char buffer_name[32];
static bool slog_initialized = false;
/*
 * debug mode  : g_loglevel = SLOG2_INFO
 * release mode: g_loglevel = SLOG2_ERROR
 */
static int g_loglevel = SLOG2_INFO; // SLOG2_INFO:5, SLOG2_ERROR:2

int vi2c_logger_init(void)
{
    int ret = -1;

    if (!bLogBufferInitialized) {
        snprintf(buffer_name, 32, "vi2c");
        // Create buffers for slog2
        sBufferConfig.buffer_set_name = buffer_name;
        sBufferConfig.num_buffers = 1;
        sBufferConfig.verbosity_level = SLOG2_INFO;

        sBufferConfig.buffer_config[0].buffer_name = "HI";
        sBufferConfig.buffer_config[0].num_pages = 1;

        if (-1 == slog2_register(&sBufferConfig, pBufferHandle, 0)) {
            memset((char *) pBufferHandle, 0, sizeof(pBufferHandle));
            fprintf(stdout, "%s Failed to register slogger2 buffer\n",
                    __FUNCTION__);
            ret = -1;
        } else {
            bLogBufferInitialized = true;
            ret = EOK;
        }
    }

    return ret;
}

void vi2c_logger_set_state(bool inited)
{
    slog_initialized = inited;
}

bool vi2c_logger_get_state()
{
    return slog_initialized;
}

void vi2c_logger_set_loglevel(int level)
{
    g_loglevel = level;
}

void vi2c_printf(void *ctx, const char *format, ...)
{
    va_list args;
    va_start(args, format);

    if (slog_initialized) {
        if (SLOG2_INFO <= g_loglevel)
            vslog2f(pBufferHandle[0], 0, SLOG2_INFO, format, args);
    } else {
        vfprintf(stdout, format, args);
    }

    va_end(args);
}

void vi2c_err_printf(void *ctx, const char *format, ...)
{
    va_list args;
    va_start(args, format);

    if (slog_initialized) {
        vslog2f(pBufferHandle[0], 0, SLOG2_ERROR, format, args);
    } else {
        vfprintf(stderr, format, args);
    }

    va_end(args);
}
#ifdef UNIT_TEST
}
#endif
#ifdef __cpluplus
}
#endif
