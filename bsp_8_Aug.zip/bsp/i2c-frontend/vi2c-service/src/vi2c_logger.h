#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#ifndef UNIT_TEST
#include <process.h>
#include "utils.h"
#include <sys/slog2.h>
#include <sys/slogcodes.h>
#else
//#include "logger.h"
#endif
#ifndef _VI2C_LOGGER_H_
#define _VI2C_LOGGER_H_
#include <pthread.h>
#include <dirent.h>
#ifdef __cplusplus
extern "C" {
#endif

#define LIB_NAME                       "VI2C"

// extern slog2_buffer_t pBufferHandle[1];
int vi2c_logger_init();
void vi2c_logger_set_state(bool inited);
bool vi2c_logger_get_state();
void vi2c_logger_set_loglevel(int level);
void vi2c_printf(void *ctx, const char *format, ...);
void vi2c_err_printf(void *ctx, const char *format, ...);


#define LOG_INFO(fmt, ...)                                                     \
    vi2c_printf(NULL, "[TID:%d][%s:%d]INFO " fmt, gettid(), __FUNCTION__,       \
                __LINE__, ##__VA_ARGS__)
#define LOG_CRITICAL_INFO(fmt, ...)                                            \
    vi2c_err_printf(NULL, "[TID:%d][%s:%d]CRIT " fmt, gettid(), __FUNCTION__,   \
                    __LINE__, ##__VA_ARGS__)

#define LOG_ERROR(fmt, ...)                                                    \
    vi2c_err_printf(NULL, "[TID:%d][%s:%d]ERROR " fmt, gettid(), __FUNCTION__,  \
                    __LINE__, ##__VA_ARGS__)

#define LOG_EM(fmt, ...)                                                    \
        vWritePrintfErrmem((LIB_NAME ": " fmt), ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif
