#ifndef __VI2C_DAEMON__
#define __VI2C_DAEMON__

#include "config.h"

struct vi2_daemon;

#ifdef UNIT_TEST
typedef enum
{
    SHOW_CONSOLE=1,
    SHOW_SLOG
}CONFIG_SHOW_TYPE;

int main1(int argc, char *argv[]);
void signal_handler1(int sig);
void vi2c_show_daemon_config1(struct vi2c_daemon_config *cfg, CONFIG_SHOW_TYPE type);
int vi2c_daemon_add_tree1(struct vi2c_bus_tree_context *tree_ctx);
#endif
/* Initialize daemon from a configuration */
int vi2c_daemon_init(struct vi2c_daemon_config *config);

/* Set online/offline policies as given in the configuration */
void vi2c_daemon_set_default_online();

/* Start full operation of the daemon */
int vi2c_daemon_start();
void vi2c_daemon_stop();

/* Clean-up */
void vi2c_daemon_destroy();

/* Gt an instance of the daemon from where-ever */
struct vi2_daemon *get_daemon();
#endif
