#!/usr/bin/env bash
cd "$(dirname "$0")"

source test/setenv_x86_64.sh

rm coverage.info
rm -rf Report


cd libvi2cdevnode/utest/
rm *.gc* UT_libvi2cdevnode
make test

cd ../../vi2c-service/utest/
rm *.gc* UT_vi2c-service
make test
cd ../../
./code_coverage.sh

#rm a.txt
#cd ../../../
#rm coverage.info



