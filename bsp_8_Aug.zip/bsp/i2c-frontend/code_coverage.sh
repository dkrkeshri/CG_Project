#!/bin/bash
rm -rf Report/
mkdir Report
mock_exclude="$(pwd)"
display_api="$(cd ..;pwd)"
lcov --directory . --capture --output-file coverage.info --rc lcov_branch_coverage=1
lcov --remove coverage.info '/usr/include/*' '/usr/lib/*' $PWD"/utest/*" \
	$PWD"/i2c-frontend/libvi2cdevnode/utest/src_test/*" \
	$PWD"/utest/src_test/*" \
	$PWD"/i2c-frontend/libvi2cdevnode/utest/src_test/*"   \
	$PWD"/i2c-frontend/vi2c-service_my/src/*"   \
	$PWD"/i2c-frontend/libvi2cdevnode/utest/src_test/*"   \
	$PWD"/utest/src_test/*"   \
	$display_api"/display/api/lib_tdaemon/public/*" \
	$display_api"/display/api/lib_tdaemon/src/*" \
	$display_api"/display/ds90ux9xx-drivers/utest/mocks/sys/*" \
	$display_api"/display/instance-manager/utest/mocks/sys/*" \
	$display_api"/display/test/utest/mock/display_utest_mock/inc/*" \
	$display_api"/display/test/utest/mock/i2c_mock/inc/*" \
	$display_api"/display/test/utest/mock/i2c_mock/src/*" \
	$display_api"/display/test/utest/mock/ipc_mock/inc/*" \
	$display_api"/display/test/utest/mock/ipc_mock/src/*" \
	$display_api"/display/test/utest/mock/posix_mock/inc/*" \
	$display_api"/display/test/utest/mock/posix_mock/src/*" \
	$display_api"/display/test/utest/mock/slog2_mock/src/*" \
	$display_api"/display/test/utest/mock/display_utest_mock/src/*" \
        ${mock_exclude}"/test/utest/mock/posix_mock/inc/*" --rc lcov_branch_coverage=1 -o coverage.info
genhtml coverage.info -t Dispaly_API --branch-coverage --output-directory Report/
