#pragma once
/******************************************************************
*FILE: i2cdevnode.h
*SW-COMPONENT: library of virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/

/**
 * i2cdevnode
 *
 * This is a static library, implementing a 'derived' i2c devicenode.
 * It creates a QNX resource manager which behaves just like an I2C
 * driver and can be connected to from any program expecting an I2C.
 *
 * On the other end, on the program linking this library, it provides
 * a simple callback interface to feed the driver with data which appears
 * to go to or come from the bus.
 *
 * To use:
 *  - Fill in a struct I2Cdevnode_funcs_parameters
 *    with parameters and callback pointers.
 *  - Call i2cdevnode__create() to create the node (with own thread)
 *  - call i2cdevnode__enableSlave() to enable slave devices on the bus.
 *      for any slave-address without an enabled slave, any reads and
 *      writes are rejected and will not trigger callbacks.
 *  - service any callbacks received.
 *    Note: callbacks can arrive anytime after creation. Thes come
 *      from a worker thread inside this module.
 *  - When shutting down, call i2cdevnode__destroy() to remove the node.
 *  - when error-logging needs to go not to stderr but elsewhere,
 *      fill in the  log_error_print  member of the create struct.
 *      leaving it null will send messages to stdout or stderr.
 *
 * Achim Dahlhoff (CM/ESO)
 */

#include <stdint.h>
#include "ipc_header.h"
#ifdef  __cplusplus
extern "C" {   /* Keep header compatible with being used from C++ code. */
#endif

struct i2cdevnode;


/**
 * struct I2Cdevnode_funcs_parameters
 *
 * This struct contains all callbacks and parameters for the
 * derived I2C device-node. Pass to i2cdevnode__create().
 *
 * The 'context' field is passed to all callbacks. Use to refer
 * to the caller's instance data.
 *
 * All callbacks are called from the worker-thread created inside
 * the devnode object whenever the device node receives I/O requests.
 * The callbacks shall return somewhat timely as the program
 * accessing the devicenode waits in send-blocked state.
 *
 * Default error and status printing goes to stdout/stderr.
 * To redirect (for example to some error-memory), fill in
 * function pointer  log_info_printf  in the parameters.
 * To suppress any logging, assign empty function stubs.
 * Leaving them null will enable stdout printing.
 */
typedef struct
{
	/* name of the devnode to create, such as "/dev/i2c42" */
	char devnode_name[64];
	/* process a SEND request */
	int (*sendbytes)(void *ctx, unsigned short slaveNo, unsigned char *data, unsigned int len);
	/* process a RECV request */
	int (*recvbytes)(void *ctx, unsigned short slaveNo, unsigned char *data, unsigned int len);
	/* process a RECV request */
	int (*send_recvbytes)(void *ctx, unsigned short slaveNo, uint8_t *wdata, uint32_t wlen,
			uint8_t *rdata, uint32_t rlen);
	/* process a STOP request */
	int (*stop)(void *ctx);
	/* process a RESET request */
	int (*busreset)(void *ctx);
	/* The context, 'ctx', passed to all callbacks. */
	void *context;
	/* flag indicating if using 10-bit addressing. Set to 0 for 8-bit. */
	char bUse10BitAddress;
	/* set this to request a call to the busreset callback on startup of node. */
	char bCallBusresetOnCreate;
	/* set this to request a call to the busreset callback on shutdown of node. */
	char bCallBusresetOnDestroy;
	/* for debugging. triggers some printf. Set to 0, 1, 2 or 3. Zero is mostly silent. */
	unsigned char debug_verbose_level;
	/* callback for error and status logging. Null sends to stdio. */
	void (*log_info_print)(void *ctx,const char *string, ...);
	void (*log_error_print)(void *ctx,const char *string, ...);
    int i2c_fd;
} I2Cdevnode_funcs_parameters;




/**
 * i2cdevnode__create
 *
 * Creates the dev-node. Pass in a filled I2Cdevnode_funcs_parameters
 * structure. The struct may be deallocated after the call.
 * On returning, the node is up and running
 * (This call blocks waiting for it to come up)
 *
 * The devnode shall be deallocated when exiting. See i2cdevnode__destroy().
 *
 * Returns opaque handle for use with the other functions if successful.
 */
struct i2cdevnode *i2cdevnode__create(const I2Cdevnode_funcs_parameters *create_param);

/**
 * i2cdevnode__destroy
 *
 * Clean up the dev-node created in i2cdevnode__create(). Takes down the
 * worker thread and device-node. When this function call is done, the node
 * is gone (blocks waiting for this).
 */
void  i2cdevnode__destroy(struct i2cdevnode *node);

/**
 * i2cdevnode__enableSlave
 *
 * By default, all slave-numbers of the virtual I2C bus are unavailable.
 * This function enables/disables a slave.
 *
 * Returns zero if successful, non-zero otherwise. Should not fail unless QNX fails.
 */
int   i2cdevnode__enableSlave(struct i2cdevnode *node, unsigned short slaveNo, char bDoEnable);

/**
 * i2cdevnode__get_context
 *
 * Retrieve the 'context' pointer which was passed inside the struct to
 * i2cdevnode__create().
 *
 * Returns the 'context' pointer.
 */
void *i2cdevnode__get_context(struct i2cdevnode *node);

#ifdef UNIT_TEST
#define MAX_I2C_READ_SIZE 64*1024
#define _DEVCTL_DATA(msg)    ((void *)(sizeof(msg) + (char *)(&msg)))
struct i2cdevnode
{
    /* stuff for resource-manager */
    /* the iofunc_attr_t struct must be first. */
    iofunc_attr_t ioattr;
    resmgr_io_funcs_t io_funcs;
    dispatch_t *dpp;
    resmgr_attr_t rattr;
    resmgr_connect_funcs_t connect_funcs;

    iofunc_funcs_t mp_io_funcs;
    iofunc_mount_t mntdat;

    int (*org_devctl)(resmgr_context_t*,io_devctl_t*,RESMGR_OCB_T*);

    I2Cdevnode_funcs_parameters cb;

    struct i2cslave *slaves[128];

    /* worker thread pid */
    int wthread_pid;

    /* sig-back channel (temporary) */
    int chan_sigback;

    /* signal to end */
    char bQuitting;
};
#define IOFUNC_ATTR_T           struct ioattr_device
typedef struct ioattr_device {
        iofunc_attr_t attr;
        struct bc_com *bc_com;
} ioattr_device_t;
typedef struct
{
    iofunc_ocb_t head;
    struct i2cdevnode *node;
    /* keeping track of selected slave per OCB. */
    char bSlaveSelected;    /* set_slave_addr was called. */
    unsigned short slaveAddr;   /* slave address from last set_slave_addr. */
    /* set bus speed. Not really used but can be read back. */
    unsigned int bus_speed;
    /* can read or write only once. (since there is no file-offset in I2C) */
    char didRead;
    char didWrite;
    unsigned char xbuf[MAX_I2C_READ_SIZE];
} I2CDEVNODE_OCB;

void *threadProc(void *arg);
int thrSigFromMain(message_context_t *ctp,int code,unsigned flags,void *handle);
IOFUNC_OCB_T *thr_io_ocb_calloc(resmgr_context_t *ctp, IOFUNC_ATTR_T *attr);
void thr_io_ocb_free(IOFUNC_OCB_T *ocb);
int  thr_slave_alloc(struct i2cdevnode *node,unsigned char slav);
void thr_slave_dealloc(struct i2cdevnode *node,unsigned char slav);
int thr_selected_slave(I2CDEVNODE_OCB *fh,const i2c_addr_t *cmd_adr);
void thr_select_slave(I2CDEVNODE_OCB *fh,unsigned short slav);
int thr_io_open(resmgr_context_t *ctp, io_open_t *msg, RESMGR_HANDLE_T *handle, void *extra);
int thr_io_devctl(resmgr_context_t *ctp, io_devctl_t *msg, RESMGR_OCB_T *ocb);
int thr_io_devctl_setslave(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_setbusspeed(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_mastersend(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_masterrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_send(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_recv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
int thr_io_devctl_sendrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
void stdio_log_print(void *ctx,const char *string, ...);
void stderr_log_print(void *ctx,const char *string, ...);
#endif

#ifdef  __cplusplus
};
#endif

