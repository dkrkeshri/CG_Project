/******************************************************************
*FILE: i2cdevnode.c
*SW-COMPONENT: library of virtual i2c resource manager
*DESCRIPTION: Serves as an example for copyright comments
*COPYRIGHT: (C) 2020 Robert Bosch GmbH
*
*The reproduction, distribution and utilization of this file as
*well as the communication of its contents to others without express
*authorization is prohibited. Offenders will be held liable for the
*payment of damages. All rights reserved in the event of the grant
*of a patent, utility model or design.
******************************************************************/


#include <errno.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#ifndef UNIT_TEST
#include <sys/dispatch.h>
#include <sys/iofunc.h>
#include <sys/neutrino.h>
#include <sys/resmgr.h>
#include <hw/i2c.h>
#include <strlib.h>
#else 
#include "slog2_header.h"
#include "i2cdevnode.h"
#include "i2c_mock.h"
#include "UT-unistd-mock.h"
#include "ipc_header.h"
#endif
#include <unistd.h>


#define CODE_PULSE_MAIN2THR_QUIT 0x47
#define CODE_PULSE_MAIN2THR_CREATESLAVE 0x48
#define CODE_PULSE_THR2MAIN_STARTUPDONE 0x49
#define CODE_PULSE_THR2MAIN_TERMINATING 0x4a

#define DEFAULT_BUS_SPEED 100000

/* enable this so read-commands will not fail with no-slave-selected. for test and debugging. */
#define PRESELECT_SLAVE 42

struct i2cslave;
#ifndef UNIT_TEST
struct i2cdevnode
{
    /* stuff for resource-manager */
    /* the iofunc_attr_t struct must be first. */
    iofunc_attr_t ioattr;
    resmgr_io_funcs_t io_funcs;
    dispatch_t *dpp;
    resmgr_attr_t rattr;
    resmgr_connect_funcs_t connect_funcs;

    iofunc_funcs_t mp_io_funcs;
    iofunc_mount_t mntdat;

    int (*org_devctl)(resmgr_context_t*,io_devctl_t*,RESMGR_OCB_T*);

    I2Cdevnode_funcs_parameters cb;

    struct i2cslave *slaves[128];

    /* worker thread pid */
    int wthread_pid;

    /* sig-back channel (temporary) */
    int chan_sigback;

    /* signal to end */
    char bQuitting;
};
#endif
struct i2cslave
{
    /* fix coverity warning(Memory illegal accesses):malloc memset len 0 */
    unsigned int reserved;
};

/*as defined in AMSS/platform/resources/i2c_drv/i2c_drv.c*/
#ifndef UNIT_TEST
#define MAX_I2C_READ_SIZE 64*1024

typedef struct
{
    iofunc_ocb_t head;
    struct i2cdevnode *node;
    /* keeping track of selected slave per OCB. */
    char bSlaveSelected;    /* set_slave_addr was called. */
    unsigned short slaveAddr;   /* slave address from last set_slave_addr. */
    /* set bus speed. Not really used but can be read back. */
    unsigned int bus_speed;
    /* can read or write only once. (since there is no file-offset in I2C) */
    char didRead;
    char didWrite;
    unsigned char xbuf[MAX_I2C_READ_SIZE];
} I2CDEVNODE_OCB;
#endif
#ifndef UNIT_TEST
static void *threadProc(void *arg);
static int thrSigFromMain(message_context_t *ctp,int code,unsigned flags,void *handle);
static IOFUNC_OCB_T *thr_io_ocb_calloc(resmgr_context_t *ctp, IOFUNC_ATTR_T *attr);
static void thr_io_ocb_free(IOFUNC_OCB_T *ocb);
static int  thr_slave_alloc(struct i2cdevnode *node,unsigned char slav);
static void thr_slave_dealloc(struct i2cdevnode *node,unsigned char slav);
static int thr_selected_slave(I2CDEVNODE_OCB *fh,const i2c_addr_t *cmd_adr);
static void thr_select_slave(I2CDEVNODE_OCB *ocb,unsigned short slav);
static int thr_io_open(resmgr_context_t *ctp, io_open_t *msg, RESMGR_HANDLE_T *handle, void *extra);
static int thr_io_devctl(resmgr_context_t *ctp, io_devctl_t *msg, RESMGR_OCB_T *ocb);
static int thr_io_devctl_setslave(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_setbusspeed(resmgr_context_t *ctp,I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_mastersend(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_masterrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_send(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_recv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static int thr_io_devctl_sendrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg);
static void stdio_log_print(void *,const char *string, ...);
static void stderr_log_print(void *,const char *string, ...);
#endif
#ifdef DEBUG_ENABLED
#define PRINT(fmt, ...) \
do { \
    if (self) { \
        self->cb.log_info_print(NULL, fmt, ##__VA_ARGS__); \
    }\
}while (0)
#else
#define PRINT(fmt, ...)  /*Do nothing */
#endif /* DEBUG_ENABLED */

#define PRINT_ER(fmt,...) \
do { \
    if (self) { \
        self->cb.log_error_print(NULL, fmt, ##__VA_ARGS__); \
    }\
}while (0)

struct i2cdevnode *i2cdevnode__create(const I2Cdevnode_funcs_parameters *create_param)
{
    struct i2cdevnode *self;
    int ret;
printf("%d\n",__LINE__);
    /* create our struct. */
    self = (struct i2cdevnode*)malloc(sizeof(*self));
printf("%d\n",__LINE__);
    if(!self)
        return 0;
    memset( self , 0 , sizeof(*self) );
printf("%d\n",__LINE__);
    self->wthread_pid = -1;
printf("%d\n",__LINE__);
    self->chan_sigback = -1;
printf("%d\n",__LINE__);

    /* copy whole create-params struct. Caller might deallocate it. */
    self->cb = *create_param;
printf("%d\n",__LINE__);

    /* if not filled in, set log-to-stdout */
    if(!self->cb.log_info_print)
        self->cb.log_info_print = stdio_log_print;
printf("%d\n",__LINE__);
    if(!self->cb.log_error_print)
        self->cb.log_error_print = stderr_log_print;
printf("%d\n",__LINE__);
    /* Create a message channel we use for the thread-setup-done signal. */
    ret = ChannelCreate(_NTO_CHF_PRIVATE);  /* .... use the ugly  _NTO_CHF_THREAD_DEATH ? */
printf("%d\n",__LINE__);
    if(ret<0)
    {
printf("%d\n",__LINE__);
        i2cdevnode__destroy(self);
printf("%d\n",__LINE__);
        return 0;
    }
    self->chan_sigback = ret;
printf("%d\n",__LINE__);


    /* create worker thread for the devnode. */
    ret = ThreadCreate(0,threadProc,self,0); /* ... null thread attributes? */
    if(ret<0)
    {
printf("%d\n",__LINE__);
        i2cdevnode__destroy(self);
printf("%d\n",__LINE__);
        return 0;
    }
    self->wthread_pid = ret;
printf("%d\n",__LINE__);

    /* wait for thread to signal that it is ready to run or it has failed to start. */
    PRINT("main: into ack-loop.");
    for(;;)
    {
        struct _pulse pul;
    printf("%d\n",__LINE__);
        if(MsgReceivePulse_r(self->chan_sigback,&pul,sizeof(pul),0))
        {
    printf("%d\n",__LINE__);

            PRINT_ER("main: MsgReceivePulse_r failed");
            i2cdevnode__destroy(self);
    printf("%d\n",__LINE__);
            return 0;   /* error. */
        }

    printf("%d\n",__LINE__);
        PRINT("main: MsgReceivePulse_r passed.");
        /* have a pulse. */
        if(pul.code==CODE_PULSE_THR2MAIN_STARTUPDONE)
            break;  /* thread is ready and running. */
        if(pul.code==CODE_PULSE_THR2MAIN_TERMINATING)
        {
            /* thread has failed to set up itself and has exited. */
            i2cdevnode__destroy(self);
            return 0;   /* error. */
        }
    }

    PRINT("main: init done.");
    return self;
}

void  i2cdevnode__destroy(struct i2cdevnode *node)
{
    if(!node)return;
    if( node->wthread_pid>=0 )
    {
        void *thr_retcode;
        /* thread is running. tell it to stop and wait for this. */
        if( node->dpp )
        {
            int con_id = message_connect(node->dpp,0);
            if(con_id>=0)
            {
                MsgSendPulse(con_id,-1,CODE_PULSE_MAIN2THR_QUIT,1);
                ConnectDetach(con_id);
            }else{
                /* ..... bad error. cannot tell thread to quit!
                       should log this somehow. */
            }
        }
        /* wait for thread to exit. */
        ThreadJoin(node->wthread_pid,&thr_retcode);
        node->wthread_pid = -1;
    }
    if(node->chan_sigback>=0)
    {
        ChannelDestroy(node->chan_sigback);
        node->chan_sigback = -1;
    }
    memset( node , 0xfe , sizeof(*node) );
    free(node);
}

int i2cdevnode__enableSlave(struct i2cdevnode *node,unsigned short slaveNo,char bDoEnable)
{
    int con_id;
    int ret;
    if( ! node->dpp )
        return -1;
    con_id = message_connect(node->dpp,0);
    if(con_id<0)
        return -1;
    ret = MsgSendPulse(
            con_id ,
            -1 ,    /* default priority. */
            CODE_PULSE_MAIN2THR_CREATESLAVE ,
            slaveNo|(bDoEnable?0x8000:0)  /* slave number and enable/disable flag */
    );
    ConnectDetach(con_id);

    if(ret)
        return -1;
    return 0;
}

void *i2cdevnode__get_context(struct i2cdevnode *node)
{
    return node->cb.context;
}
#ifndef UNIT_TEST
static void *threadProc(void *arg)
#else
void *threadProc(void *arg)
#endif
{
    struct i2cdevnode *self = (struct i2cdevnode*)arg;
    int ret;
    int i;
    int chan2main = -1;
    int pathID = -1;
    dispatch_context_t  *ctp = 0;

    /* connect to the channel of the main-thread which waits for our done-response. */
    chan2main = ConnectAttach(0,0,self->chan_sigback,_NTO_SIDE_CHANNEL,_NTO_COF_CLOEXEC);
    if(chan2main<0)
        goto leave; /* ... uh have a problem. Cannot report to main-thread. */

    /* need a dispatch-context for worker loop */
    self->dpp = dispatch_create();
    if(!self->dpp)
    {
        PRINT_ER("couldn't dispatch_create: %s", strerror(errno));
        goto leave; /* ... main is waiting??? */
    }

    pulse_attach(self->dpp,0,CODE_PULSE_MAIN2THR_QUIT,thrSigFromMain,self);
    pulse_attach(self->dpp,0,CODE_PULSE_MAIN2THR_CREATESLAVE,thrSigFromMain,self);

    /* now create the dev-node. */

    /* Set the connect functions and I/O functions tables to defaults. */
    iofunc_func_init(_RESMGR_CONNECT_NFUNCS,&self->connect_funcs,_RESMGR_IO_NFUNCS,&self->io_funcs);
    iofunc_mount_init(&self->mntdat,sizeof(self->mntdat));

    /* Add own functions for open/read/write */
    self->org_devctl = self->io_funcs.devctl;
    self->connect_funcs.open = thr_io_open;
    self->io_funcs.devctl = thr_io_devctl;

    /* hook own functions for allocating the OCB to have more control and to keep the slave-address. */
    memset( &self->mp_io_funcs , 0 , sizeof(iofunc_funcs_t) );
    self->mp_io_funcs.nfuncs = _IOFUNC_NFUNCS;
#ifndef UNIT_TEST
    self->mp_io_funcs.ocb_calloc = thr_io_ocb_calloc;
#endif
    self->mp_io_funcs.ocb_free = thr_io_ocb_free;

    self->mntdat.funcs = &self->mp_io_funcs;

    /* initialize our device description structure */
    iofunc_attr_init(&self->ioattr,S_IFCHR|0666,NULL,NULL);
    self->ioattr.mount = &self->mntdat;
    PRINT("node name: %s", self->cb.devnode_name);
    /* now really add to resmgr. */
    pathID = resmgr_attach(
                    self->dpp,
                    &self->rattr,
                    self->cb.devnode_name,
                    _FTYPE_ANY,
                    _RESMGR_FLAG_BEFORE,
                    &self->connect_funcs,
                    &self->io_funcs,
                    &self->ioattr
    );
    if(pathID<0)
    {
        PRINT_ER("thr: failed to do resmgr_attach. errno=%d",(int)(errno));
        goto leave;
    }

    ctp = dispatch_context_alloc(self->dpp);
    if(!ctp)
        goto leave;

    /* signal main-thread that setup is done and successful. */
    PRINT("thr: MsgSendPulse ");
    ret = MsgSendPulse(chan2main,-1,CODE_PULSE_THR2MAIN_STARTUPDONE,1);
    PRINT(" returned %d",ret);


    /* worker loop here */


    ret = message_connect(self->dpp,0);  /* this creates the internal mq. */
    if(ret>=0)
        ConnectDetach(ret);
    else
        goto leave;

    /* at startup, after spawning our virtual bus, send a stop to it. */
    if( self->cb.bCallBusresetOnCreate && self->cb.busreset )
        self->cb.busreset(self->cb.context);
    else if(self->cb.stop)
        self->cb.stop(self->cb.context);


    PRINT("thr: into loop.");
    while(!self->bQuitting)
    {
        if( ! (ctp=dispatch_block(ctp)) )
        {
            PRINT_ER(" dispatch_block failed: %s", strerror(errno));
            break;
        }
        dispatch_handler(ctp);
    }

    /* leaving loop. call busreset if this was configured. */
    if( self->cb.bCallBusresetOnDestroy && self->cb.busreset )
        self->cb.busreset(self->cb.context);

leave:
    PRINT("thr: leaving");
    if(ctp)
        dispatch_context_free(ctp);

    if(pathID>=0)
        resmgr_detach(self->dpp,pathID,_RESMGR_DETACH_ALL);

    if(self->dpp)
    {
        dispatch_destroy(self->dpp);
        self->dpp = 0;
    }
    /* dealloc slave structs */
    for(i=0;i<128;i++)
        thr_slave_dealloc(self,i);
    /* signal main that we're quitting. */
    if(chan2main>=0)
    {
        MsgSendPulse(chan2main,-1,CODE_PULSE_THR2MAIN_TERMINATING,0);
        ConnectDetach(chan2main);
    }

    return 0;
}
#ifndef UNIT_TEST
static int thrSigFromMain(message_context_t *ctp,int code,unsigned flags,void *handle)
#else
int thrSigFromMain(message_context_t *ctp,int code,unsigned flags,void *handle)
#endif
{
    struct i2cdevnode *self = (struct i2cdevnode*)handle;
    if( code == CODE_PULSE_MAIN2THR_CREATESLAVE )
    {
        /* Command from API to create or remove a slave. */
        /* ctp->msg is of type  resmgr_iomsgs_t *  */
        int value = ctp->msg->pulse.value.sival_int;
        char bDoEnable;

        bDoEnable = (value&0x8000)!=0;
        if(self->cb.debug_verbose_level>=2)
        {
            if(bDoEnable)
                PRINT("thr: create a slave (%d).", value&0x7FFF); /* value&0x7FFF is slave address */
            else
                PRINT("thr: remove a slave (%d).", value&0x7FFF);
        }
        if(bDoEnable)
            thr_slave_alloc(self,value);
        else
            thr_slave_dealloc(self,value);
    }
    if( code == CODE_PULSE_MAIN2THR_QUIT )
    {

        PRINT("thr: got quit signal.");
        self->bQuitting = 1;
    }

    return 0;
}
#ifndef UNIT_TEST
static IOFUNC_OCB_T *thr_io_ocb_calloc(resmgr_context_t *ctp, IOFUNC_ATTR_T *attr)
#else
IOFUNC_OCB_T *thr_io_ocb_calloc(resmgr_context_t *ctp, IOFUNC_ATTR_T *attr)
#endif
{
    I2CDEVNODE_OCB *res;
    res = (I2CDEVNODE_OCB*)malloc(sizeof(I2CDEVNODE_OCB));
    if(!res)return 0;
    memset( res , 0 , sizeof(I2CDEVNODE_OCB) );
    return (IOFUNC_OCB_T*)res;
}
#ifndef UNIT_TEST
static void thr_io_ocb_free(IOFUNC_OCB_T *ocb)
#else
void thr_io_ocb_free(IOFUNC_OCB_T *ocb)
#endif
{
    free(ocb);
}
#ifndef UNIT_TEST
static int  thr_slave_alloc(struct i2cdevnode *node,unsigned char slav)
#else
int  thr_slave_alloc(struct i2cdevnode *node,unsigned char slav)
#endif
{
    struct i2cslave *sl;
    if(slav>=128)
        return -1; /* invalid number */
    if(node->slaves[slav])
        return 0;   /* already created. */
    sl = (struct i2cslave*)malloc(sizeof(*sl));
    if(!sl)
        return -1; /* malloc failed. */
    memset(sl,0,sizeof(*sl));
    /* ... need more init? */
    node->slaves[slav] = sl;
    return 0;
}
#ifndef UNIT_TEST
static void thr_slave_dealloc(struct i2cdevnode *node,unsigned char slav)
#else
void thr_slave_dealloc(struct i2cdevnode *node,unsigned char slav)
#endif
{
    if(slav>=128)
        return; /* invalid number */
    if(!node->slaves[slav])
        return; /* alrady gone or never created. */
    /* ... wipe/deregister? */
    free(node->slaves[slav]);
    node->slaves[slav] = 0;
}
#ifndef UNIT_TEST
static int thr_selected_slave(I2CDEVNODE_OCB *fh,const i2c_addr_t *cmd_adr)
#else
int thr_selected_slave(I2CDEVNODE_OCB *fh,const i2c_addr_t *cmd_adr)
#endif
{
    /* if have a slave-address from a set_slave command, take that. */
    if( fh && fh->bSlaveSelected )
        return fh->slaveAddr;
    /* if have a non-zero address from command, take that. */
    if( cmd_adr && (cmd_adr->fmt||cmd_adr->addr) )
        return (unsigned short)(cmd_adr->addr);
    /* if have a command-address, take it even if it is zero. */
    if( cmd_adr )
        return (unsigned short)(cmd_adr->addr);
    /* have nothing. Fail. */
    return -1;
}
#ifndef UNIT_TEST
static void thr_select_slave(I2CDEVNODE_OCB *fh,unsigned short slav)
#else
void thr_select_slave(I2CDEVNODE_OCB *fh,unsigned short slav)
#endif
{
    fh->bSlaveSelected = 1;
    fh->slaveAddr = slav;
}
#ifndef UNIT_TEST
static int thr_io_open(resmgr_context_t *ctp, io_open_t *msg, RESMGR_HANDLE_T *handle, void *extra)
#else
int thr_io_open(resmgr_context_t *ctp, io_open_t *msg, RESMGR_HANDLE_T *handle, void *extra)
#endif
{
    struct i2cdevnode *self = (struct i2cdevnode*)handle;
    I2CDEVNODE_OCB *fh;
    int ret;

    if(self->cb.debug_verbose_level>=3)
    {
        PRINT("DEBUG2:  self = 0x%016" PRIxPTR "",self);
        PRINT("DEBUG2:  verbose = %d",(int)(self->cb.debug_verbose_level));
    }


    PRINT("thr:   lib  thr_io_open()");

    ret = iofunc_open_default(ctp, msg, (iofunc_attr_t *)handle, extra);
    if(ret==0)
    {
        fh = (I2CDEVNODE_OCB*)resmgr_ocb(ctp);
        fh->node = self;
        fh->bSlaveSelected = 0;
        fh->slaveAddr = 0;
        fh->didRead = 0;
        fh->didWrite = 0;
#ifdef PRESELECT_SLAVE
        fh->bSlaveSelected = 1;
        fh->slaveAddr = PRESELECT_SLAVE;
        fh->bus_speed = DEFAULT_BUS_SPEED;
#endif
    }
    return ret;
}

/* sizes passed to the IO functions from QNX are a mess.
 * There is a size in the ctp, the ctp->info.msglen
 * in the head of the message is the io_devctl_t struct,
 * which has two more sizes. combine_len and nbytes.
 *
 * sizeof(io_devctl_t)    = 16
 * sizeof(i2c_send_t)     = 16
 * sizeof(i2c_recv_t)     = 16
 * sizeof(i2c_sendrecv_t) = 20
 *
 * examples:
 *  set-slave sends a i2c_addr_t , size 8,   msglen=24, comblen=16, i.nbytes=8
 */

#define DEVCTL_BUFFER_SIZE (256+sizeof(io_devctl_t)+sizeof(i2c_sendrecv_t))

typedef struct
{
    int32_t dcmd;
    const char *name;
} dbg_dio_names;

static const dbg_dio_names debug_print_ioctl_names[] = {
    {DCMD_I2C_SET_SLAVE_ADDR,"I2C_SET_SLAVE_ADDR"},
    {DCMD_I2C_SET_BUS_SPEED ,"I2C_SET_BUS_SPEED"},
    {DCMD_I2C_MASTER_SEND   ,"I2C_MASTER_SEND"},
    {DCMD_I2C_MASTER_RECV   ,"I2C_MASTER_RECV"},
    {DCMD_I2C_SEND          ,"I2C_SEND"},
    {DCMD_I2C_RECV          ,"I2C_RECV"},
    {DCMD_I2C_SENDRECV      ,"I2C_SENDRECV"},
    {DCMD_I2C_LOCK          ,"I2C_LOCK"},
    {DCMD_I2C_UNLOCK        ,"I2C_UNLOCK"},
    {DCMD_I2C_DRIVER_INFO   ,"I2C_DRIVER_INFO"},
    {DCMD_I2C_STATUS        ,"I2C_STATUS"},
    {DCMD_I2C_BUS_RESET     ,"I2C_BUS_RESET"},
    {0,0}
};

/*
 * i2c read operation use DCMD_I2C_SENDRECV to call i2c_combined_writeread
 * int i2c_combined_writeread(int fd, void * wbuff, uint32_t wlen, void* rbuff, uint32_t rlen )
 *
 * i2c write option use DCMD_I2C_MASTER_SEND to call int i2c_write
 * int i2c_write(int fd, void *buf, uint32_t len)
 */
#ifndef UNIT_TEST
static int thr_io_devctl(resmgr_context_t *ctp, io_devctl_t *msg, RESMGR_OCB_T *ocb)
#else
int thr_io_devctl(resmgr_context_t *ctp, io_devctl_t *msg, RESMGR_OCB_T *ocb)
#endif
{
    I2CDEVNODE_OCB *fh = (I2CDEVNODE_OCB*)ocb;
    int status;

#ifdef PUBLIC_FEATURE_RIM_ALL

    /*
     * Validate access permission:
     * Check the I2C device was opened with both read and write permission (i.e. O_RDWR).
     */
    if ((ctp == NULL) || (msg == NULL) || (ocb == NULL)) {
        return EINVAL;
    }

    if ((ocb->hdr.ioflag & _IO_FLAG_RD) != _IO_FLAG_RD) {
        return EPERM;
    }

    if ((ocb->hdr.ioflag & _IO_FLAG_WR) != _IO_FLAG_WR) {
        return EPERM;
    }

#endif

    status = iofunc_devctl_default(ctp, msg, (iofunc_ocb_t *)ocb);
    if (status != _RESMGR_DEFAULT)
        return status;

    status = -EINVAL;
    switch(msg->i.dcmd)
    {
    case DCMD_I2C_SET_SLAVE_ADDR:
        status = thr_io_devctl_setslave(ctp, fh, msg);
        break;
    case DCMD_I2C_SET_BUS_SPEED:
        status = thr_io_devctl_setbusspeed(ctp, fh, msg);
        break;

    case DCMD_I2C_MASTER_SEND:  //
        status = thr_io_devctl_mastersend(ctp, fh, msg);
        break;
    case DCMD_I2C_SEND:
        status = thr_io_devctl_send(ctp, fh, msg);
        break;
    case DCMD_I2C_MASTER_RECV:
        status = thr_io_devctl_masterrecv(ctp, fh, msg);
        break;
    case DCMD_I2C_RECV:
        status = thr_io_devctl_recv(ctp, fh, msg);
        break;
    case DCMD_I2C_SENDRECV:  //i2c_read
        status = thr_io_devctl_sendrecv(ctp, fh, msg);
        break;
    case DCMD_I2C_LOCK:
    case DCMD_I2C_UNLOCK:
        memset(&msg->o, 0, sizeof(msg->o));
        msg->o.ret_val = 0;
        status = _RESMGR_PTR(ctp, msg, sizeof(msg->o));
        break;

    case DCMD_I2C_DRIVER_INFO:
        status = ENOSYS;
        break;

    default:
        status = ENOSYS;
        break;
    }
    return status;
}
#ifndef UNIT_TEST
static int thr_io_devctl_setslave(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_setslave(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    const i2c_addr_t *in;
    
    if(msg->i.nbytes<sizeof(i2c_addr_t))
        return -EINVAL;

    in = (const i2c_addr_t *)_DEVCTL_DATA(msg->i);
    /* check if having a valid address. */
    if(in->addr>=1024) /*_Uint32t            addr;*/
        return -EINVAL;
    if( self->cb.bUse10BitAddress==0 && in->addr>=128 )
        return -EINVAL;
    if( in->fmt==I2C_ADDRFMT_7BIT && in->addr>=128 )
        return -EINVAL;

    /* we are ignoring the 7 or 10 bit mode. It is chosen in create-params. */

    thr_select_slave(fh,in->addr);

    PRINT_ER("node:%s, thr:set slave-address to 0x%x", self->cb.devnode_name, (unsigned int)fh->slaveAddr);

    msg->o.ret_val=0;
    return _RESMGR_PTR(ctp, msg, sizeof(msg->o));

}
#ifndef UNIT_TEST
static int thr_io_devctl_setbusspeed(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_setbusspeed(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
#ifdef DEBUG_ENABLED
    struct i2cdevnode *self = fh->node;
#endif
    unsigned int *in;
    unsigned int tmp;

    if(msg->i.nbytes<sizeof(i2c_addr_t))
        return -EINVAL;

    in = (unsigned int *)_DEVCTL_DATA(msg->i);

    PRINT("thr:  thr_io_devctl_setbusspeed %u",*in);
    /* check if having a valid bus speed. */
    if( *in<95 || *in>=5250000 )  /* bus speeds are 100 to 5M, with a tolerance of 5% extra. */
        return -EINVAL;

    /* swap. take in new, and return old speed. */
    tmp = fh->bus_speed;
    fh->bus_speed = *in;
    *in = tmp;

    PRINT("thr:  set bus speed to %u",(unsigned int)fh->bus_speed);

    msg->o.ret_val=0;
    return _RESMGR_PTR(ctp, msg, sizeof(msg->o));

}
#ifndef UNIT_TEST
static int thr_io_devctl_mastersend(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_mastersend(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    int slav = 0;
    unsigned char *buf;
    void * inputPtr;
    i2c_masterhdr_t* mheader;

    if(msg->i.nbytes < sizeof(i2c_masterhdr_t))
        return -EINVAL;

    /* if invalid slave, return fail. */
    slav =  thr_selected_slave(fh, 0);
    if( slav<0 || slav>=128 )
        return -ENOENT;

    /* no callback set up? */
    if(!self->cb.sendbytes)
        return -ENOTSUP;

    inputPtr = _DEVCTL_DATA(msg->i);
    mheader = (i2c_masterhdr_t*)inputPtr;

    buf = (unsigned char *)inputPtr + (sizeof(i2c_masterhdr_t)); // in-buffer
    PRINT("%s : buf:0x%x,0x%x, len:%d",  __func__, buf[0], buf[1], mheader->len);
    
    memset(&msg->o, 0, sizeof(msg->o));
    msg->o.ret_val = self->cb.sendbytes(&self->cb, (unsigned short)slav, buf, mheader->len);
    PRINT("msg->o.ret_val :%d",  msg->o.ret_val);
    msg->o.nbytes = 0;
    
#ifdef PUBLIC_FEATURE_RIM_ALL
    if (msg->o.ret_val < 0)
    {
        return EIO;
    }
#endif

    SETIOV(&ctp->iov[0], msg, sizeof(msg->o));

    return _RESMGR_NPARTS(1);
}
#ifndef UNIT_TEST
static int thr_io_devctl_masterrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_masterrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    i2c_masterhdr_t *rheader;
    void * inputPtr;
    int slav;
    int n;

    inputPtr = _DEVCTL_DATA(msg->i);
    rheader = (i2c_masterhdr_t *)inputPtr;

    if(msg->i.nbytes<sizeof(i2c_masterhdr_t))
        return -EINVAL;

    /* if invalid slave, return fail. */
    slav =  thr_selected_slave(fh,0);
    if( slav<0 || slav>=128 )
        return -ENOENT;

    /* no callback set up? */
    if(!self->cb.recvbytes)
        return -ENOTSUP;

    n = self->cb.recvbytes(self->cb.context, (unsigned short)slav, fh->xbuf, rheader->len);
    memset(&msg->o, 0, sizeof(msg->o));
    msg->o.ret_val = n;
    if(n >= 0)
    {
        msg->o.nbytes = sizeof(*rheader)+n;
        SETIOV(ctp->iov, &msg->o, sizeof(*msg)+sizeof(*rheader));
        SETIOV(ctp->iov+1, fh->xbuf, n);
    }
    else
    {
#ifdef PUBLIC_FEATURE_RIM_ALL
        return EIO;
#else
        msg->o.nbytes = sizeof(*rheader);
        SETIOV(ctp->iov, &msg->o, sizeof(*msg)+sizeof(*rheader));
        SETIOV(ctp->iov+1, fh->xbuf, 0);
#endif
    }
    return _RESMGR_NPARTS(2);
}
#ifndef UNIT_TEST
static int thr_io_devctl_send(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_send(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    int slav = 0;
    unsigned char *buf;
    void * inputPtr;
    i2c_send_t* wheader;

    inputPtr = _DEVCTL_DATA(msg->i);
    wheader = (i2c_send_t*)inputPtr;

    if(msg->i.nbytes<sizeof(i2c_send_t))
        return -EINVAL;

    /* no callback set up? */
    if(!self->cb.sendbytes)
        return -ENOTSUP;

    /* if invalid slave, return fail. */
    slav =  thr_selected_slave(fh, &wheader->slave);
    if( slav<0 || slav>=128 )
        return -ENOENT;

    buf = (unsigned char *)inputPtr + (sizeof(i2c_send_t)); // in-buffer
    PRINT("%s : buf:0x%x,0x%x, len:%d",  __func__, buf[0], buf[1], wheader->len);
    
    memset(&msg->o, 0, sizeof(msg->o));
    msg->o.ret_val = self->cb.sendbytes(&self->cb, (unsigned short)slav, buf, wheader->len);
    PRINT("msg->o.ret_val :%d",  msg->o.ret_val);
    msg->o.nbytes = 0;
#ifdef PUBLIC_FEATURE_RIM_ALL
    if (msg->o.ret_val < 0)
    {
        return EIO;
    }
#endif
    SETIOV(&ctp->iov[0], msg, sizeof(msg->o));

    return _RESMGR_NPARTS(1);
}
#ifndef UNIT_TEST
static int thr_io_devctl_recv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_recv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    void * inputPtr;
    i2c_recv_t *rheader;
    int n;
    int slav;

    inputPtr = _DEVCTL_DATA(msg->i);
    rheader = (i2c_recv_t *)inputPtr;

    if(msg->i.nbytes<sizeof(i2c_recv_t))
        return -EINVAL;

    /* no callback set up? */
    if(!self->cb.recvbytes)
        return -ENOTSUP;

    slav =  thr_selected_slave(fh, &rheader->slave);
    if( slav<0 || slav>=128 )
        return -ENOENT;

    n = self->cb.recvbytes(self->cb.context,(unsigned short)slav, fh->xbuf, rheader->len);
    memset(&msg->o, 0, sizeof(msg->o));
    msg->o.ret_val = n;
    if(n >= 0)
    {
        msg->o.nbytes = sizeof(*rheader)+n;
        SETIOV(ctp->iov, &msg->o, sizeof(*msg)+sizeof(*rheader));
        SETIOV(ctp->iov+1, fh->xbuf, n);
    }
    else
    {
#ifdef PUBLIC_FEATURE_RIM_ALL
        return EIO;
#else
        msg->o.nbytes = sizeof(*rheader);
        SETIOV(ctp->iov, &msg->o, sizeof(*msg)+sizeof(*rheader));
        SETIOV(ctp->iov+1, fh->xbuf, 0);
#endif
    }
    return _RESMGR_NPARTS(2);
}
#ifndef UNIT_TEST
static int thr_io_devctl_sendrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#else
int thr_io_devctl_sendrecv(resmgr_context_t *ctp, I2CDEVNODE_OCB *fh, io_devctl_t *msg)
#endif
{
    struct i2cdevnode *self = fh->node;
    int slav;
    unsigned char *buf;
    int n;
    i2c_sendrecv_t * wrheader;
    void * inputPtr = _DEVCTL_DATA(msg->i);

    wrheader = (i2c_sendrecv_t *)inputPtr;

    /* no callback set up? */
    if(!self->cb.send_recvbytes)
        return -ENOTSUP;

    /* if invalid slave, return fail. */
    slav =  thr_selected_slave(fh, &wrheader->slave);
    if( slav<0 || slav>=128 )
        return -ENOENT;

    if(msg->i.nbytes < sizeof(i2c_sendrecv_t))
        return -EINVAL;

    buf = (unsigned char *)inputPtr + (sizeof(i2c_sendrecv_t)); // in-buffer

#ifdef DEBUG
    {
        int i;
        PRINT("send buffer");
        for(i = 0; i < wrheader->send_len; i++)
        {
            PRINT("buf[%d] = 0x%x",i, buf[i]);
        }
    }
#endif
    n = self->cb.send_recvbytes(&self->cb, (unsigned short)slav, buf, wrheader->send_len, fh->xbuf, wrheader->recv_len);

    PRINT_ER("wlen:%d, rlen:%d, send_recvbytes return: %d", wrheader->send_len, wrheader->recv_len, n);

#ifdef DEBUG
    {
        int i;
        PRINT("receive buffer");
        for(i = 0; i < wrheader->recv_len; i++)
        {
            PRINT("fh->xbuf[%d] = 0x%x",i, fh->xbuf[i]);
        }
    }
#endif
    memset(&msg->o, 0, sizeof(msg->o));

    //n = wrheader->recv_len;
    msg->o.ret_val = n;

    if(n >= 0)
    {
        msg->o.nbytes = sizeof(*wrheader)+n;
        SETIOV(ctp->iov, &msg->o, sizeof(msg->o)+sizeof(*wrheader));
        SETIOV(ctp->iov+1, fh->xbuf, n);
    }
    else
    {
#ifdef PUBLIC_FEATURE_RIM_ALL
        return EIO;
#else
        msg->o.nbytes = sizeof(*wrheader);
        SETIOV(ctp->iov, &msg->o, sizeof(*msg)+sizeof(*wrheader));
        SETIOV(ctp->iov+1, fh->xbuf, 0);
#endif
    }
    return _RESMGR_NPARTS(2);
}

/**
 * Function stdio_log_printf() is used if caller does not specify
 * a log_info_printf function in the create-params.
 */
#ifndef UNIT_TEST
static void stdio_log_print(void *ctx,const char *string, ...)
#else
void stdio_log_print(void *ctx,const char *string, ...)
#endif
{
    printf("I2Cnode: %s",string);
}

/**
 * Function stdio_log_printf() is used if caller does not specify
 * a log_error_printf function in the create-params.
 */
#ifndef UNIT_TEST
static void stderr_log_print(void *ctx,const char *string, ...)
#else
void stderr_log_print(void *ctx,const char *string, ...)
#endif
{
    fprintf(stderr,"I2Cnode error: %s",string);
}
