
#include <fcntl.h>
#include <gmock/gmock.h>
#include "UT-unistd-mock.h"
#include "vi2c-bus-contexts.h"
#include "i2cdevnode.h"
#include "ipc_header.h"

using namespace std;
class Gtest
{
    public:
	Gtest(){
    }
    ~Gtest(){
    }
};

TEST(i2cdevnode, i2cdevnode__destroy_pass)
{
	struct i2cdevnode *self=NULL;
  //self = (struct i2cdevnode*)malloc(sizeof(*self));      
       //int handle =0;
       i2cdevnode__destroy(self);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}


TEST(i2cdevnode, i2cdevnode__create_pass)
{
       struct i2cdevnode *node;
       node = (struct i2cdevnode*)malloc(sizeof(*node));
       node->wthread_pid=0;
       node->dpp=(dispatch_t *)calloc(1,sizeof(dispatch_t));
	struct vi2c_bus_child_context *child_ctx;
	child_ctx = (vi2c_bus_child_context*)calloc(1, sizeof(struct vi2c_bus_child_context));
       struct ret; 
       // int handle =0;
       i2cdevnode__create(&child_ctx->callbacks);
        EXPECT_EQ(0,0);
free(child_ctx);
        // shall have quotes on end.
}


TEST(i2cdevnode, i2cdevnode__get_context_pass)
{
 struct i2cdevnode *node=(struct i2cdevnode*)calloc(1,sizeof(struct i2cdevnode));       
       // int handle =0;
       i2cdevnode__get_context(node);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}


TEST(i2cdevnode, i2cdevnode__enableSlave_pass)
{
	struct vi2c_bus_child_context *child_ctx;
	child_ctx = (vi2c_bus_child_context*)calloc(1, sizeof(struct vi2c_bus_child_context));
	child_ctx->dn=(struct i2cdevnode*)calloc(1,sizeof(struct i2cdevnode));
	//struct vi2c_bus_tree_context *tree_ctx;
	//tree_ctx = (struct vi2c_bus_tree_context *)calloc(1, sizeof(struct vi2c_bus_child_context));
	//tree_ctx->tree_spec=(struct vi2c_bus_tree_spec*)calloc(1,sizeof(struct vi2c_bus_child_spec));
	//child_ctx = tree_ctx->child_buses[0];
        int ret;
       // int handle =0;
	ret=i2cdevnode__enableSlave(child_ctx->dn, 1,1);
	EXPECT_NE(ret,0);
	free(child_ctx);
	free(child_ctx->dn);
        // shall have quotes on end.
}

TEST(i2cdevnode, threadProc_pass)
{
	void *arg;
	struct i2cdevnode *self = (struct i2cdevnode*)arg;
       // int handle =0;
       threadProc(self);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}
TEST(i2cdevnode, thrSigFromMain_pass)
{
	int ret;
	struct _resmgr_context *cpt=NULL;
int code;unsigned flags;void *handle;  
       // int handle =0;
       ret=thrSigFromMain(cpt,code,flags,handle);
        EXPECT_EQ(ret,0);

        // shall have quotes on end.
}

TEST(i2cdevnode, hr_to_ocb_calloc_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t)); 
	IOFUNC_ATTR_T *attr = (ioattr_device_t*)calloc(1,sizeof(ioattr_device_t));
       // int handle =0;
       thr_io_ocb_calloc(ctp, attr);
        EXPECT_EQ(0,0);
	free(ctp);
	free(attr);

        // shall have quotes on end.
}


TEST(i2cdevnode, thr_io_ocb_free_pass)
{
       // int handle =0;
       thr_io_ocb_free( NULL);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_slave_alloc_pass)
{
	int ret;
	struct i2cdevnode *self;
	unsigned char slav;
       // int handle =0;
       ret=thr_slave_alloc(self,slav);
        EXPECT_NE(ret,-22);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_slave_dealloc_pass)
{
	unsigned char slav=200;
	struct i2cdevnode *node;
       // int handle =0;
       thr_slave_dealloc( node,slav);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_selected_slave_pass)
{
	i2c_sendrecv_t * wrheader=(i2c_sendrecv_t*)calloc(1,sizeof(i2c_sendrecv_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
	int ret;
	unsigned char slav;
       // int handle =0;
       ret=thr_selected_slave( fh,&wrheader->slave);
        EXPECT_NE(ret,-1);
	free(fh);
	free(wrheader);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_open_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
        io_open_t *msg=(io_open_t*)calloc(1,sizeof(io_open_t));
	RESMGR_HANDLE_T *handle = (RESMGR_HANDLE_T*)calloc(1,sizeof(RESMGR_HANDLE_T));
	void *extra;
	int ret;
       // int handle =0;
       ret=thr_io_open( ctp,msg,handle,extra);
        EXPECT_EQ(ret,1);
	free(ctp);
	free(msg);
	free(handle);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_pass)
{
	RESMGR_OCB_T *ocb=(RESMGR_OCB_T *)calloc(1,sizeof(RESMGR_OCB_T));
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	void *extra=NULL;
       // int handle =0;
       //ret=thr_io_devctl( ctp,msg,ocb);
       ret=thr_io_devctl(NULL,NULL,NULL);
        EXPECT_EQ(ret,0);
	free(ctp);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_setslave_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
	void *extra=NULL;
       // int handle =0;
       ret=thr_io_devctl_setslave( ctp,fh,msg);
        EXPECT_EQ(ret,-22);
	free(ctp);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_setbusspeed_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_setbusspeed( ctp,fh,msg);
        EXPECT_EQ(ret,-22);
	free(ctp);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_mastersend_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_mastersend( ctp,fh,msg);
        EXPECT_EQ(ret,-22);

	free(ctp);
	free(fh);
	free(msg);
        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_masterrecv_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_masterrecv( ctp,fh,msg);
        EXPECT_EQ(ret,-22);
	free(ctp);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_send_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_send( ctp,fh,msg);
        EXPECT_EQ(ret,-22);
	free(ctp);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_recv_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_recv( ctp,fh,msg);
        EXPECT_EQ(ret,-22);
	free(ctp);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_io_devctl_sendrecv_pass)
{
	resmgr_context_t *ctp=(resmgr_context_t*)calloc(1,sizeof(resmgr_context_t));
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
        fh->node= (struct i2cdevnode *)calloc(1,sizeof(struct i2cdevnode));
	int ret;
	unsigned short slav;
       // int handle =0;
       ret=thr_io_devctl_sendrecv( ctp,fh,msg);
        EXPECT_EQ(ret,-95);
	free(ctp);
	free(fh->node);
	free(fh);
	free(msg);

        // shall have quotes on end.
}

TEST(i2cdevnode, stdio_log_print_pass)
{
	int ret;
	const char *string="test";
       // int handle =0;
       stdio_log_print( NULL,string);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}

TEST(i2cdevnode, stderr_log_print_pass)
{
	int ret;
	const char *string="test";
       // int handle =0;
       stderr_log_print( NULL,string);
        EXPECT_EQ(0,0);

        // shall have quotes on end.
}

TEST(i2cdevnode, thr_select_slave_pass)
{
	int ret;
       	I2CDEVNODE_OCB *fh=(I2CDEVNODE_OCB*)calloc(1,sizeof(I2CDEVNODE_OCB));
       	io_devctl_t *msg=(io_devctl_t*)calloc(1,sizeof(io_devctl_t));
	const i2c_addr_t *in;
        in = (const i2c_addr_t *)_DEVCTL_DATA(msg->i);;
	//const char *string=150;
       // int handle =0;
        thr_select_slave( fh,in->addr);
        EXPECT_EQ(0,0);
	free(fh);

        // shall have quotes on end.
}


