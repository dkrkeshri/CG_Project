#!/usr/bin/env bash

export OSLIST=linux
export CPULIST=x86_64


