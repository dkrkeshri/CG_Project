/***************************************************************************//**
*  \file       test_app.c
*
*  \details    Userspace application to test the Device driver
*
*  \author     EmbeTronicX
*
*  \Tested with Linux raspberrypi 5.10.27-v7l-embetronicx-custom+
*
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include<sys/ioctl.h>
//#include <linux/gpio.h>
#include "gpio.h"
 // #include "gpio-utils.h"
 
#define DEVICE_NAME "dummy_gpiochip" //"gpiochip0"

#define INPUT      1<<2
#define OUTPUT  1<<3

int gpio_open(const char *device_name);
int gpio_close(int fd);
int get_chipInfo(int fd);
int get_gpioline_value(int fd,int line);
int set_gpioLine_value(int fd,int line,int value);
int gpio_change_dir(int fd,int line,int direction);

int fd;
int main()
{
	    int option = 0;
		int line,value,direction;
		fd = gpio_open(DEVICE_NAME);
		
		while(1)
		{
	    printf("\n0.exit \n1.get_chipInfo\n2.gpio_change_dir\n3.get_gpioline_value\n4.set_gpioLine_value\n");
		scanf("%d",&option);
			if(option == 0)
			{
				break;
			}
		
			switch(option)
			{
				case 1:
					get_chipInfo(fd);
					break;
				case 2:
					printf("Enter pin value (1-10):");
					scanf("%d",&line);
					if(line < 1 && line >10)
					{
						printf("Invalid  pin value %d\n",line);
						break;
					}
					printf("Enter direction (0 for Input & 1 for output):");
					scanf("%d",&direction);
					if(direction < 0 && direction >1)
					{
						printf("Invalid  pin value %d\n",line);
						break;
					}
					gpio_change_dir(fd,line,direction);
					break;
				case 3:
					printf("Enter pin value (1-10):");
					scanf("%d",&line);
					if(line < 1 && line >10)
					{
						printf("Invalid  pin value %d\n",line);
						break;
					}
					get_gpioline_value(fd,line);
				break;
				case 4:
				    printf("Enter pin value (1-10):");
					scanf("%d",&line);
					if(line < 1 && line >10)
					{
						printf("Invalid  pin value %d\n",line);
						break;
					}
					printf("Enter gpio value (0 or 1):");
					scanf("%d",&value);
					if(value < 0 && value >1)
					{
						printf("Invalid  value %d\n",value);
						break;
					}
					set_gpioLine_value(fd,line,value);
				break;
				default:
					break;
			}
		}
		gpio_close(fd);
}

int gpio_open(const char *device_name)
{
	char chrdev_name[100];
	int fd;
	int ret;

	ret = snprintf(chrdev_name,sizeof(chrdev_name), "/dev/%s", device_name);
	
	fd = open(chrdev_name, 0);
	
	if(fd < 0) 
	{
			printf("Cannot open device file...\n");
			return -1;
	}
	{
			printf("\nopened gpio device file\n");
			return fd;
	}
	
}
int gpio_close( int fd)
{
	int ret;

	ret = close(fd);
	
	if (ret == -1) {
		printf("Failed to close GPIO device file");
	}
	else
	{
		printf("\nclosed GPIO device file\n");
	}
	return ret;
}
int gpio_change_dir(int fd,int line,int direction)
{		

	int ret;
	struct gpio_v2_line_config config;
	struct gpio_v2_line_request req;


		
	if(direction == 0)
	{
		memset(&config, 0, sizeof(config));
		config.flags = INPUT;
		req.offsets[0] = line-1;
		req.config = config;
	}
	else if(direction == 1 )
	{
		memset(&config, 0, sizeof(config));
		config.flags = OUTPUT;
		req.offsets[0] = line-1;
		req.config = config;
	}
	
	ret = ioctl(fd, GPIO_V2_GET_LINE_IOCTL, &req);
	
	if(ret < 0 )
	{
		printf("Failed to change gpio direction");
		return -1;
	}
	else
	{
		printf("\nchanged gpio line direction \n");
		return ret;
	}
		
}
int get_gpioline_value(int fd,int line)
{
	struct gpio_v2_line_values lineValue;
	int ret;

    lineValue.mask = line;
	printf("Entered get_gpioline_value");
	ret = ioctl(fd, GPIO_V2_LINE_GET_VALUES_IOCTL, &lineValue);
	
	if (ret == -1) {
		printf("Failed to issue CHIPINFO IOCTL\n");
		ret =  -1;
	}
	else
	{
		printf("\nSuccessfully read gpio value \n");
		printf("\nThe value of gpio line %d  is %lld\n",line,lineValue.bits);
		return ret;
	}
}
int set_gpioLine_value(int fd,int line,int value)
{
	struct gpio_v2_line_values lineValue;
	int ret;
	
	lineValue.mask  = line;
	lineValue.bits   = value;
	
	ret = ioctl(fd, GPIO_V2_LINE_SET_VALUES_IOCTL, &lineValue);

	if (ret == -1) {
		printf("Failed to issue CHIPINFO IOCTL\n");
		return -1;
	}
	else
	{
		printf("\nChanged output value\n");
		return ret;
	}
	
}

int  get_chipInfo(int fd)
{
	struct gpiochip_info cinfo;			
	struct gpio_v2_line_info linfo;
	int ret;
	int i;

	/* Inspect this GPIO chip */
	ret = ioctl(fd, GPIO_GET_CHIPINFO_IOCTL, &cinfo);
	if (ret == -1) {
		printf("Failed to issue CHIPINFO IOCTL\n");
	}
	else
	{
		printf("\n///......GPIO CHIP INFO ....../// \n");
		printf("GPIO chip name : %s\nGPIO Lable : %s\nGPIO lines : %u\n",
			cinfo.name, cinfo.label, cinfo.lines);	
		
		printf("\n///......GPIO LINE INFO ......///");
		for (i = 0; i < cinfo.lines; i++) {

		memset(&linfo, 0, sizeof(linfo));
		linfo.offset = i;

		ret = ioctl(fd, GPIO_V2_GET_LINEINFO_IOCTL, &linfo);
		if (ret == -1) {			
			perror("Failed to issue LINEINFO IOCTL\n");
		}
		else
		{
			printf("\nline %2d : ", linfo.offset);
			
			if(linfo.flags & GPIO_V2_LINE_FLAG_INPUT)
			{
				printf(" Direction : Input,");
			}
			if(linfo.flags & GPIO_V2_LINE_FLAG_OUTPUT)
			{
				printf(" Direction : Output,");
			}
			if(linfo.flags & GPIO_V2_LINE_FLAG_BIAS_PULL_UP)
			{
				printf(" Pull-up Enabled,");
			}
			if(linfo.flags & GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN)
			{
				printf(" Pull-down Enabled,");
			}
			if(linfo.flags & GPIO_V2_LINE_FLAG_OPEN_SOURCE)
			{
				printf(" Open source,");
			}
			if(linfo.flags & GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN)
			{
				printf(" Open Drain,");
			}	
		}
	}
		printf("\n");
	}
	return 1;
	
}
