#!/bin/bash
rm test_app
gcc -o test_app test_app.c
