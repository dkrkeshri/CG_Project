#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include<linux/slab.h>                 //kmalloc()
#include<linux/uaccess.h>              //copy_to/from_user()
#include "gpio.h"
// #include <linux/ioctl.h>
#include <linux/sysfs.h>
#include <linux/kobject.h>

//for sysfs
volatile int etx_value = 0;

#define MAX_GPIO_LINES 10
int32_t value = 0;

dev_t dev = 0;
static struct class *dev_class;
static struct cdev etx_cdev;
struct kobject *kobj_ref;

///*********** GPIO CHIP_INFO ******////
static struct gpiochip_info cinfo = {"gpio_driver","12345",MAX_GPIO_LINES};

static struct gpio_v2_line_info line_info[MAX_GPIO_LINES];
static struct gpio_v2_line_info  temp_line_info;

static int gpio_values[MAX_GPIO_LINES];
/*
** Function Prototypes
*/
static int      __init etx_driver_init(void);
static void     __exit etx_driver_exit(void);
static int      etx_open(struct inode *inode, struct file *file);
static int      etx_release(struct inode *inode, struct file *file);
static ssize_t  etx_read(struct file *filp, char __user *buf, size_t len,loff_t * off);
static ssize_t  etx_write(struct file *filp, const char *buf, size_t len, loff_t * off);
static long     etx_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
static int      gpio_init(void);
static int      change_pin_direction(unsigned long arg);
static int      get_pin_status(unsigned long arg);
static int      set_pin_value(unsigned long arg);

/*
 * sysfs function prototypes
 * */

static ssize_t sysfs_show( struct kobject *kobj, struct kobj_attribute *attr,char* buf);
static ssize_t sysfs_store( struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count);
struct kobj_attribute etx_attr = __ATTR(etx_value, 0660, sysfs_show, sysfs_store);


/*
** File operation sturcture
*/
static struct file_operations fops =
{
	.owner          = THIS_MODULE,
	.read           = etx_read,
	.write          = etx_write,
	.open           = etx_open,
	.unlocked_ioctl = etx_ioctl,
	.release        = etx_release,
};


/*
** This function will be called when we read the sysfs file
*/
static ssize_t sysfs_show(struct kobject *kobj,struct kobj_attribute *attr, char *buf)
{
	pr_info("Sysfs - Read!!!\n");
	return sprintf(buf, "%d", etx_value);
}

/*
** This function will be called when we write the sysfsfs file
*/
static ssize_t sysfs_store(struct kobject *kobj, struct kobj_attribute *attr,const char *buf, size_t count)
{
	pr_info("Sysfs - Write!!!\n");
	sscanf(buf,"%d",&etx_value);
	return count;
}

static int   gpio_init(void)
{
	int pin_offset = 0;
	while(pin_offset < MAX_GPIO_LINES)
	{
		line_info[pin_offset].offset = pin_offset+1;
		line_info[pin_offset].flags  = GPIO_V2_LINE_FLAG_INPUT|GPIO_V2_LINE_FLAG_BIAS_PULL_UP;
		gpio_values[pin_offset] = 0;
		pin_offset++;
	}
	return 1;
}

static int  change_pin_direction(unsigned long arg)
{
   struct gpio_v2_line_request req;
   if( 0 == copy_from_user(&req ,(struct gpio_v2_line_request *)arg, sizeof(struct gpio_v2_line_request)))
   {
	   if(req.config.flags == GPIO_V2_LINE_FLAG_INPUT)
	   {
		   line_info[req.offsets[0]].flags = GPIO_V2_LINE_FLAG_INPUT|GPIO_V2_LINE_FLAG_BIAS_PULL_UP;
		   gpio_values[req.offsets[0]] = 1;
		}
		else if(req.config.flags == GPIO_V2_LINE_FLAG_OUTPUT)
		{
			line_info[req.offsets[0]].flags = GPIO_V2_LINE_FLAG_OUTPUT|GPIO_V2_LINE_FLAG_OPEN_SOURCE;
			gpio_values[req.offsets[0]] = 0;
		}
   }
   return 0;
}
static int  get_pin_status(unsigned long arg)
{
	struct gpio_v2_line_values lineValue;
	//lineValue.bits = 1;
	if(	0 ==	copy_from_user(&lineValue,(struct gpio_v2_line_values *)arg,sizeof(struct gpio_v2_line_values)))
	{
		lineValue.bits  = gpio_values[lineValue.mask];
	 }
	if( 0 == copy_to_user((struct gpio_v2_line_values *)arg,&lineValue , sizeof(struct gpio_v2_line_values)))
	{
		pr_info("reading done\n");
	}
	return 0;
}

static int   set_pin_value(unsigned long arg)
{

	struct gpio_v2_line_values lineValue;
	if(	0 ==	copy_from_user(&lineValue,(struct gpio_v2_line_values *)arg,sizeof(struct gpio_v2_line_values)))
	{
		gpio_values[lineValue.mask] = lineValue.bits;
	}
	return 0;
}
/*
** This function will be called when we open the Device file
*/
static int etx_open(struct inode *inode, struct file *file)
{
	pr_info("Device File Opened...!!!\n");
	return 0;
}

/*
** This function will be called when we close the Device file
*/
static int etx_release(struct inode *inode, struct file *file)
{
	pr_info("Device File Closed...!!!\n");
	return 0;
}

/*
** This function will be called when we read the Device file
*/
static ssize_t etx_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
	pr_info("Read Function\n");
	return 0;
}

/*
** This function will be called when we write the Device file
*/
static ssize_t etx_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
	pr_info("Write function\n");
	return len;
}

/*
** This function will be called when we write IOCTL on the Device file
*/
static long etx_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	 switch(cmd) {
		case GPIO_GET_CHIPINFO_IOCTL:

			if( copy_to_user((struct gpiochip_info *) arg, &cinfo, sizeof(struct gpiochip_info)) )
			pr_info("reading chip info\n");
			break;

		case GPIO_V2_GET_LINEINFO_IOCTL:

			if( copy_from_user(&temp_line_info ,(struct gpio_v2_line_info *)arg, sizeof(struct gpio_v2_line_info)))
			{
				pr_info("copying from user space fialed\n");
			}

			if( copy_to_user((struct gpio_v2_line_info *) arg, &line_info[temp_line_info.offset], sizeof(struct gpio_v2_line_info)) )
			pr_info("reading line info\n");
			break;

		case GPIO_V2_LINE_GET_VALUES_IOCTL:

			get_pin_status(arg);
			pr_info("reading line values\n");
			break;

		case GPIO_V2_GET_LINE_IOCTL:

			change_pin_direction(arg);
			pr_info("changing pin direction\n");
			break;

		case GPIO_V2_LINE_SET_VALUES_IOCTL:
			set_pin_value(arg);
			pr_info("changing output value\n");
			break;

		default:
			pr_info("Default\n");
			return -1;
			break;
	}
	return 0;
}

/*
** Module Init function
*/
static int __init etx_driver_init(void)
{
	/*Allocating Major number*/
	if((alloc_chrdev_region(&dev, 0, 1, "etx_Dev")) <0){
		pr_err("Cannot allocate major number\n");
		return -1;
	}
	pr_info("Major = %d Minor = %d \n",MAJOR(dev), MINOR(dev));

	/*Creating cdev structure*/
	cdev_init(&etx_cdev,&fops);

	/*Adding character device to the system*/
	if((cdev_add(&etx_cdev,dev,1)) < 0){
		pr_err("Cannot add the device to the system\n");
		goto r_class;
	}

	/*Creating struct class*/
	if((dev_class = class_create(THIS_MODULE,"etx_class")) == NULL){
		pr_err("Cannot create the struct class\n");
		goto r_class;
	}

	/*Creating device*/
	if((device_create(dev_class,NULL,dev,NULL,"dummy_gpiochip")) == NULL){
		pr_err("Cannot create the Device 1\n");
		goto r_device;
	}

	gpio_init();

	/*creating a directory in /sys/kernel*/
	kobj_ref = kobject_create_and_add( "etx_sysfs",kernel_kobj );

	/* creating sysfs file for etx_value*/
	if ( sysfs_create_file ( kobj_ref, &etx_attr.attr) ){
		pr_err("can't create sysfs file..\n");
		goto r_sysfs;
	}

	pr_info("Device Driver Insert...Done!!!\n");
	return 0;

r_sysfs:
	kobject_put ( kobj_ref );
	sysfs_remove_file ( kernel_kobj, &etx_attr.attr);

r_device:
	class_destroy(dev_class);
r_class:
	unregister_chrdev_region(dev,1);
	return -1;
}

/*
** Module exit function
*/
static void __exit etx_driver_exit(void)
{
	kobject_put(kobj_ref);
	sysfs_remove_file(kernel_kobj,&etx_attr.attr);
	device_destroy(dev_class,dev);
	class_destroy(dev_class);
	cdev_del(&etx_cdev);
	unregister_chrdev_region(dev, 1);
	pr_info("Device Driver Remove...Done!!!\n");
}

module_init(etx_driver_init);
module_exit(etx_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Bhagavan");
MODULE_DESCRIPTION("GPIO Mocking driver");
MODULE_VERSION("1.0");