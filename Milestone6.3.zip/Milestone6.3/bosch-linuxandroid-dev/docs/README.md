README.md - Milestone 6.3 release
NOTE:- VPN should be disconnect, if code execution on virtualbox.

=================================================
1. Pre-Requisite
=================================================
1.1 Required libraries.

NOTE:- VPN should be disconnect, if code execution on virtualbox.

$ sudo apt-get update –y 
$ sudo apt-get install -y libtool automake libjson-c-dev
$ sudo apt-get install –y tcl8.6-dev swig 
$ sudo apt install libgtest-dev cmake
if gtest build failed, execute below steps
$cd /usr/src/gtest
$sudo cmake CMakeLists.txt
$sudo make
$sudo cp *.a /usr/lib

$ sudo apt-get install libgmock-dev
if gmock build failed, execute below steps
$cd /usr/src/googletest/googlemock/
$ sudo mkdir build
$ sudo cmake ..
$ sudo make
$ sudo cp googlemock/*.a /usr/lib

$ sudo apt-get install i2c-tools
$ sudo modprobe i2c-dev
$ sudo modprobe i2c-stub chip_addr=0x0a

1.2 check i2c device number 
$i2cdetect -l
i2c-1	unknown   	SMBus stub driver               	N/A

1.3 updatethe i2c stub-driver bus number at daemon/src/common/inc/error.h file. Like below
#define I2C_ENTRY   "i2c_on_entry open 9 0x0A"
#define I2C_WORD_ENTRY "i2c_on_entry open 9 0x0A"

1.4 Export the path of shared Libraries to LD_LIBRARY_PATH in the terminal
$export LD_LIBRARY_PATH=<shared_lib_path> 
  -- before run the server daemon and gtest export lib path is must.
  -- Note: <shared_lib_path> should be Absolute Path only, it cannot be Relative Path
  NOTE:-this library path will be available after compilation successful

1.5 GPIO driver
   -- for X86_64 , prebuilt gpio driver is already exist in below path.
	-- drivers/gpio_driver/pre-builts/driver_module/driver.ko
   
   -- for insert module
	-- sudo insmod driver.ko
   -- for remove module
	-- sudo rmmod driver.ko
   
   -- for other platforms build the gpio driver, source code is availble in below path.
	-- drivers/gpio_driver/driver_src

   -- driver test application prebuilt and src paths are below.
	-- prebuiltpath: drivers/gpio_driver/pre-builts/test_application/test_app
	-- source path:  drivers/gpio_driver/test_src
   -- run test appliation
	-- sudo ./test_app
   

=================================================
2. Compilation & Execution of Server Program
=================================================
2.1 Modify "log_file_path" in Configuration file
$ cd config/
$ vim config_file.ini -> change <log_file_path> to your corresponding Absolute/Relative path

2.2 Compilation of Server & Client Program
$ chmod 777 command.sh
$ ./command.sh

2.2 Excluding Google Test build while Compilation of Server & Client Program 
$ ./command.sh --exclude=gtest

Note: 1) <command.sh> is the script file for automake commands. It will generate all executables in out folder.
	  2) Chmod 777 is used to make command.sh into executable
	  3) modify prefix path in the command.sh to out folder
		
2.3 Execution of Server Program 
$ cd out/bin
$ sudo ./server_daemon -c <path_of_config_file>

Note: <path_of_config_file> is mandatory argument
	  Server program does not exit.

2.4 Execution of Server Program with different options in command line arguments

	1.5.1 To change Log File Path [use -f option]
	$ ./server -c <path_of_config_file> -f  <log_file_path>
	
	1.5.2 To change Log Level [use -l option]
	$ ./server -c <path_of_config_file> -l  <log_level>
	
	1.5.3 To change both Log File Path and Log Level [Use -f & -l options]
	$ ./server -c <path_of_config_file> -f  <log_file_path>  -l  <log_level>
						[OR]
	$ ./server  -c <path_of_config_file> -l  <log_level>  -f  <log_file_path>

	Note: Below mentioned arguments can be given in any order in Command Line.
			1) -c <path_of_config_file>
			2) -f <log_file_path>
			3) -l <log_level>

<path_of_config_file>  :  /home/CY/Desktop/Logging/config/config_file.ini (Absolute Path)
						  ../../daemon/config/config_file.ini 							  (Relative Path)

<log_file_path> :	/home/CY/Desktop/Logging/Logs.txt (Absolute Path - Recommended)
					../logs.txt 						  (Relative Path)

<log_level>		:	ERROR [Default Log Level]
					WARN
					INFO
					DEBUG
					
Note: <log_level> is case sensitive.
	   Log Level Priority Order:  DEBUG < INFO < WARN < ERROR.


=================================================
3. Execution of Client Program
=================================================
3.1 Execution of Client Program
$ cd out/bin
$ ./client ../../client_program/req1.txt [For Client: Logs are displayed on Console because Logging Module is implemented only for Server]

3.2 Execution of second client program
$ cd out/bin
$ ./client ../../client_program/req2.txt

NOTE: 1.change the IP address and port nuumber in req1.txt and req2.txt
		

=================================================
4. Checking Log Files
=================================================
4.1 Parsing to the Location of Log File if <log_file_path> is not given as a Command Line argument, and opening Log File
$ cd <Log_file_path_given_in_config_file>/
$ vim <log_file.txt>

4.2 Parsing to the Location of the Log File if valid <log_file_path> is given as a Command Line argument, and opening Log File
$ cd <log_file_path_given_in_Command_Line_argument>
$ vim Logs.txt


=====================================================
5. Modifying Configuration File for Testing purpose
=====================================================
5.1 Parsing to the Location of Config File
$ cd <path_of_config_file_given_in_Command_Line>/

5.2 Modifying Configuration file
$ vim config_file.ini

	4.2.1 Changing "state" parameter in configuration.ini file
	state : <state_param>

	4.2.2 Changing "path" parameter in configuration.ini file
	path : <log_file_path>
	
	4.2.3 Changing "log_sink" parameter in configuration.ini file
	log_sink : <log_sink_param>
	
	4.2.4 Changing "log_level" parameter in configuration.ini file
	log_level : <log_level_param>

	4.2.5 Changing the "disp_config" paramater in configuration.ini file
	disp_config : <path_to_the_dispaly_config_file>
	
<state_param> :	suspended
				connected
				awaiting
				configured
				
<log_file_path> : /home/CY/Desktop/Logging/Logs.txt (Absolute path - Recommended)
				  ../logs.txt 							(Relative path)
				  
<log_sink_param> : 0    	(console)
					1 	    (file)

<log_level_param> : ERROR [Default Log Level]
					WARN
					INFO
					DEBUG
				
<path_to_the_dispaly_config_file> : ../config/display_config/Display1_config_file.json

					
========================================================================
6. Shared library
========================================================================
6.1 Location of Shared Libraries
$ cd out/lib

6.2 shared library will be created in "out/lib" directory.
lib-logger.so

6.3 shared library for tcl script will be in "out/bin" directory.
lib-hal_interface.so

========================================================================
7. Unit test
========================================================================
7.1 Execution of Google Test
$ cd out/bin
$ ./acousticout_google_test -c <config_test.ini>
  --NOTE: <config_test.ini> = ../../daemon/config/config_file.ini (Relative Path)

Note: 	1) Test report will be given on the console.
	2) Test should be run in different terminal.

========================================================================
8. Cleaning of Files
======================================================================== 
8.1 Run the following commands in the same order to remove auto-generated files & the files created by "make":
$ make clean
$ make dist-clean

Note: Run the above mentioned commands in the top level directory where command.sh is present

========================================================================
9. Changing Client Requests session-id and request-id
======================================================================== 
9.1 Go to the client program src code and change the string
$ cd client_program/config
$ Change the requests in json files.

