#!/bin/bash
rm -rf Report/
mkdir Report
#gcovr -r . --exclude-unreachable-branches --html --html-details -o Report/example-html-details.html
lcov --capture --directory . --output-file coverage.info
lcov --remove coverage.info '/usr/include/*' '/usr/lib/*' -o coverage.info
genhtml coverage.info -t displayCTL --output-directory Report/