/**
  * @file          test_display_parse_json.h
  *
  * @brief        Unit test for display_parse_json
  *
  * @author     external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "logging_testsuite.h"
 
extern "C"
{
	#include "../daemon/src/common/inc/displayparsejson.h"
}

extern int num_of_states;
extern "C" int g_argc;
extern "C" char ** g_argv;

/* check display_parse_json function
 * Expecting 0 on success.
 */
TEST(display_parse_json, display_parse_json_pass)
{
	if(loggingEnable()){
		char filename[256] = {0};
		strcpy(&filename[0], "../../daemon/config/display_config/Display0_Config_File.json");
		json_parsing_init(config_params);
		EXPECT_EQ( 0, display_parse_json(&filename[0], 0));
	}
	loggingDisable();
}

TEST(display_parse_json, display_parse_json_fail)
{
	if(loggingEnable()){
		char filename[256] = {0};
		strcpy(&filename[0],"invalidDisplayFile");
		json_parsing_init(config_params);
		EXPECT_NE( 0, display_parse_json(&filename[0], 5));
	}
	loggingDisable();
}

/* check validate_json_data function
 * Expecting 0 on success.
 */
TEST(display_parse_json, validate_json_data_pass)
{
	if(loggingEnable()){
		json_parsing_init(config_params);
		char filename[256] = {0};
		strcpy(&filename[0],"../../daemon/config/display_config/Display0_Config_File.json");
		display_parse_json(&filename[0], 0);
		memset(&filename[0], 0x00, 256);
		strcpy(&filename[0],"../../daemon/config/display_config/Display1_Config_File.json");
		display_parse_json(&filename[0], 1);
		memset(&filename[0], 0x00, 256);
		strcpy(&filename[0],"../../daemon/config/display_config/Display2_Config_File.json");
		display_parse_json(&filename[0], 2);
		for(int i = 0; i < 3 ; ++i) {
			EXPECT_EQ( 0, validate_json_data(i));
		}
	}
	loggingDisable();
}

//"TODO: Getting Segmentation Fault, need to work on validate_json_data_fail case"
/*TEST(display_parse_json, validate_json_data_fail)
{
	if(loggingEnable()){
		json_parsing_init(config_params);
		printf("%s, %d\n", __func__, __LINE__);
		//display_parse_json("invalidDisplayFile", 4);						//67, 69 (4) then segmentation fault not even entering 221
		//display_parse_json("../../daemon/config/display_config/invalidDisplayFile.json", 0);
		display_parse_json("../../daemon/config/display_config/Display0_Config_File.json", 0);
		//get_state_index("invalidState", 0);
		printf("%s, %d\n", __func__, __LINE__);
		EXPECT_EQ( DISP_JSON_ERR_UNSTABLE_FALL_BACK_STATE, validate_json_data(0));				//67, 69 (0's) then not executing 221 line, test case failed
	}
	loggingDisable();
}*/

/* check get_state_index function
 * Expecting 0 on success.
 */
TEST(display_parse_json, get_state_index_pass)
{
	if(loggingEnable()){
		char filename[256] = {0};
		strcpy(&filename[0],"../../daemon/config/display_config/Display0_Config_File.json");
		json_parsing_init(config_params);
		display_parse_json(&filename[0], 0);
		memset(&filename[0], 0x00, 256);
		strcpy(&filename[0],"connected");
		EXPECT_EQ( 3, get_state_index(&filename[0], 0));
	}
	loggingDisable();
}

TEST(display_parse_json, get_state_index_fail)
{
	if(loggingEnable()){
		char filename[256] = {0};
		strcpy(&filename[0],"../../daemon/config/display_config/Display0_Config_File.json");
		json_parsing_init(config_params);
		display_parse_json(&filename[0], 0);
		memset(&filename[0], 0x00, 256);
		strcpy(&filename[0],"invalidState");
		EXPECT_EQ( 0, get_state_index(&filename[0], 0));
	}
	loggingDisable();
}

/* TEST4  check json_parsing_init function
 * Expecting 0 on success.
 */
TEST(display_parse_json, json_parsing_init_pass)
{
	if(loggingEnable()){
		EXPECT_EQ( 0, json_parsing_init(config_params));
	}
	loggingDisable();
}

TEST(display_parse_json, json_parsing_init_fail)
{
	PRINT_OPEN(log_fp);
	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	EXPECT_EQ( 0, json_parsing_init(config_params));
	PRINT_CLOSE(log_fp);
}
TEST(display_parse_json, json_encoder_pass)
{
	char server_message[MSG_SIZE]={0};
	char request_data[MSG_SIZE]={0};
	char reply_data[MSG_SIZE]={0};
	char buffer[MSG_SIZE] = {0};
	char resp[MSG_SIZE] = {0};
	char reply[MSG_SIZE] = {0};
	memset(server_message, 0x00, sizeof(server_message));
	memset(request_data, 0x00, sizeof(request_data));
	strcpy(&request_data[0],"session-id :1\trequest-id:1\tresult :OK");
	memset(reply_data, 0x00, sizeof(reply_data));
	for (int i = 0; i < 3; i++) {
		snprintf(buffer, sizeof(buffer),
		"display-id-%d :%d \t",i,i);
		strcat(reply_data,buffer);
	}
	snprintf(buffer, sizeof(buffer),
		"display-id-4 :Not \t");
	strcat(reply_data,buffer);
	strcpy(&resp[0],RESPONSE);
	strcpy(&reply[0],REPLY);
	if(loggingEnable()){
		EXPECT_EQ( 0,  json_encoder(&resp[0], &request_data[0], &reply[0],&reply_data[0],&server_message[0]));
		EXPECT_EQ(DISP_JSON_ERR_BUFF_NULL,  json_encoder(&resp[0], &request_data[0], NULL,NULL,&server_message[0]));
		EXPECT_EQ(DISP_JSON_ERR_BUFF_NULL,  json_encoder(&resp[0], &request_data[0], &reply[0],&reply_data[0],NULL));
	}
	loggingDisable();
}