/**
  * @file        test_backend.h
  *
  * @brief      Unit test for backend
  *
  * @author   external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

extern "C"
{
	#include "../daemon/src/logging/inc/backend.h"
	#include "logging_testsuite.h"
}

extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;
extern "C" int g_argc;
extern "C" char ** g_argv;

void local_init(){
	config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config, 0x00, sizeof(st_log_config));
	get_config_info(g_argc, g_argv, config_params);

	logging_interface = (st_logger*)malloc(sizeof(st_logger));
	memset(logging_interface, 0x00, sizeof(st_logger));
	logging_interface->log_sink = config_params->log_config->log_sink;
}

void local_deinit(){
	if(logging_interface){
		free(logging_interface);
		logging_interface = NULL;
	}
	if(config_params){
		if(config_params->log_config){
			free(config_params->log_config);
			config_params->log_config = NULL;
		}
		free(config_params);
		config_params = NULL;
	}
}

/* check logger_init function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, logger_init_pass)
{
	PRINT_OPEN(log_fp);
	local_init();

	EXPECT_EQ( 0, logger_init(config_params, logging_interface));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, logger_init_fail1)
{
	PRINT_OPEN(log_fp);
	local_init();
	logging_interface->log_sink = 3;

	EXPECT_EQ( LOG_ERR_INVALID_LOGSINK_PARAM, logger_init(config_params, logging_interface));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

/*TEST(backend, logger_init_fail2)
{
	PRINT_OPEN(log_fp);
	local_init();
	//needs to update logging interfaceto fail backendopen file
	//load_log_config(logging_interface, config_params->log_config);
	printf("%s, %d\n", __func__, __LINE__);
	//strcpy((logging_interface->params), (char *)"../logs/invalidLogs.txt");
	//strcpy(((st_log_config *)logging_interface->params)->path, (char *)"../logs/invalidLogs.txt");
	//((st_log_config *)logging_interface->params)->path = (char *)"../logs/invalidLogs.txt";
	//logging_interface->params)->path = (char *)"../logs/invalidLogs.txt";
	logging_interface->params = (char *)"../logs/invalidLogs.txt";
	printf("%s, %d\n", __func__, __LINE__);

	EXPECT_EQ( BE_ERR_BE_OPEN_FAIL, logger_init(config_params, logging_interface));

	PRINT_CLOSE(log_fp);
	local_deinit();
}*/

/* check load_log_config function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, load_log_config_pass)
{
	PRINT_OPEN(log_fp);
	local_init();

	EXPECT_EQ( 0, load_log_config(logging_interface, config_params->log_config));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, load_log_config_fail)
{
	PRINT_OPEN(log_fp);
	local_init();
	logging_interface->log_sink = 3;

	EXPECT_EQ( LOG_ERR_INVALID_LOGSINK_PARAM, load_log_config(logging_interface, config_params->log_config));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

/* check lib_logging_load function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, lib_logging_load_pass)
{
	PRINT_OPEN(log_fp);
	local_init();

	EXPECT_EQ( 0, lib_logging_load(logging_interface, config_params->log_config));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, lib_logging_load_fail1)
{
	PRINT_OPEN(log_fp);
	config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config, 0x00, sizeof(st_log_config));
	st_logger *logging_interface1 = NULL;

	EXPECT_EQ( BE_ERR_BE_NULL_PARAM, lib_logging_load(logging_interface1, config_params->log_config));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

/*TEST(backend, lib_logging_load_fail2)
{
	PRINT_OPEN(log_fp);
	local_init();																												//need to change library path or .so library name for this case. Library path is not changing
	system("printenv |grep LD_LIBRARY_PATH");
	system("export LD_LIBRARY_PATH='/home/sysadmin/Desktop/bosch-linuxandroid-dev/code/out'");
	system("sudo ldconfig");
	system("printenv |grep LD_LIBRARY_PATH");

	//logging_interface->backendhandle = dlopen("lib-invalid-logger.so", RTLD_NOW);

	EXPECT_NE( 0, lib_logging_load(logging_interface, config_params));

	PRINT_CLOSE(log_fp);
	local_deinit();
	system("export LD_LIBRARY_PATH=/home/sysadmin/Desktop/bosch-linuxandroid-dev/code/out/lib");
	system("sudo ldconfig");
	//#define LOG_LIBRARY_NAME "lib-logger.so"
}*/

/* check lib_logging_unload function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, lib_logging_unload_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret_val  =  SUCCESS;
	ret_val = lib_logging_load(logging_interface, config_params->log_config);
	if(ret_val == SUCCESS){
		EXPECT_EQ( 0, lib_logging_unload(logging_interface));
	}

	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, lib_logging_unload_fail1)
{
	PRINT_OPEN(log_fp);
	config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config, 0x00, sizeof(st_log_config));
	st_logger *logging_interface1 = NULL;
	lib_logging_load(logging_interface1, config_params->log_config);

	EXPECT_EQ( BE_ERR_BE_NULL_PARAM, lib_logging_unload(logging_interface1));

	PRINT_CLOSE(log_fp);
	local_deinit();
}

/* check backend_open function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, backend_open_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret = load_log_config(logging_interface, config_params->log_config);
	if (ret == SUCCESS){
		EXPECT_EQ( 0, backend_open(logging_interface));
	}

	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, backend_open_fail)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret = load_log_config(logging_interface, config_params->log_config);
	if(ret == SUCCESS) {
		logging_interface->params = NULL;
		EXPECT_EQ( BE_ERR_BE_NULL_PARAM, backend_open(logging_interface));
	}
	PRINT_CLOSE(log_fp);
	local_deinit();
}

/* check backend_close function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, backend_close_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret = load_log_config(logging_interface, config_params->log_config);
	if(ret == SUCCESS){
		backend_open(logging_interface);
		EXPECT_EQ( 0, backend_close(logging_interface));
	}
	PRINT_CLOSE(log_fp);
	local_deinit();
}

/*TEST(backend, backend_close_fail)
{
	PRINT_OPEN(log_fp);
	local_init();
	load_log_config(logging_interface, config_params->log_config);
	strcpy(((st_log_config *)logging_interface->params)->path, (char *)"../logs/invalidLogs.txt");
	backend_open(logging_interface);

	EXPECT_EQ( BE_ERR_BE_CLOSE_FAIL, backend_close(logging_interface));    //seg fault in API, log_beops_close(); as it cannot close the file which is doesn't exist.

	PRINT_CLOSE(log_fp);
	local_deinit();
}*/

/* check logger_deinit function
 * Expecting 0 on success and error code on failure
 */
TEST(backend, logger_deinit_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret = logger_init(config_params, logging_interface);
	if(ret == SUCCESS) {
		EXPECT_EQ( 0, logger_deinit(logging_interface));
	}
	logging_interface = NULL;
	PRINT_CLOSE(log_fp);
	local_deinit();
}

TEST(backend, logger_deinit_fail)
{
	PRINT_OPEN(log_fp);
	local_init();
	int ret = logger_init(config_params, logging_interface);
	free(logging_interface);
	logging_interface = NULL;
	if(ret == SUCCESS) {
		EXPECT_EQ( BE_ERR_BE_NULL_PARAM, logger_deinit(logging_interface));
	}
	PRINT_CLOSE(log_fp);
	local_deinit();
}