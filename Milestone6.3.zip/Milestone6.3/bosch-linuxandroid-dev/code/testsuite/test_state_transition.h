/**
  * @file   test_dispatcher.h    
  *
  * @brief  Unit test for dispatcher
  *
  * @author  external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

using namespace std;
extern "C"
{
	#include "../daemon/src/state_machine/inc/statemachine.h"
	#include "../daemon/src/common/inc/displayparsejson.h"
	#include "logging_testsuite.h"
}
extern "C" int g_argc;
extern "C" char ** g_argv;

//"TODO: Need to work on sm_state_transition_init fail case"
/* TEST 1 check sm_state_transition_init()
 * Expecting 0 on success.
 */

TEST(st_transition, sm_state_transition_init_pass)
{
	int display_id;
	if(loggingEnable()){
		sm_state_transition_init(display_id);
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_create_table fail case"
/* TEST 2 check sm_create_table
 * Expecting 0 on success.
 */

TEST(st_transition, sm_create_table_pass)
{
	int display_id;
	if(loggingEnable()){
		sm_create_table(display_id);
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_show_table fail case"
/* TEST 3 check sm_show_table
 * Expecting 0 on success.
 */

TEST(st_transition, sm_show_table_pass)
{
	int display_id;
	if(loggingEnable()){
		sm_show_table(display_id);
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_get_adj_vertex fail case"
/* TEST 4 check sm_get_adj_vertex
 * Expecting 0 on success.
 */

TEST(st_transition, sm_get_adj_vertex_pass)
{
	int vertex;
	int *adj_cnt;
	int *adj_arr;
	int display_id;
	if(loggingEnable()){
		EXPECT_NE(0,sm_get_adj_vertex(vertex,adj_cnt,adj_arr,display_id));
	}
    loggingDisable();
}

//"TODO: Need to work on sm_enqueue fail case"
/* TEST 5 check sm_enqueue
 * Expecting 0 on success.
 */
TEST(st_transition, sm_enqueue_pass)
{
	st_sm_path path;
	if(loggingEnable()){
		sm_enqueue(path);
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_dequeue fail case"
/* TEST 6 check sm_dequeue
 * Expecting 0 on success.
 */

TEST(st_transition, sm_dequeue_pass)
{
	st_sm_edges *edges;
	edges=(st_sm_edges*)malloc(sizeof(st_sm_edges));
	memset(edges,0x00,sizeof(st_sm_edges));
	if(loggingEnable()){
		sm_dequeue(edges);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
	free(edges);
}

//"TODO: Need to work on sm_disp_queue fail case"
/* TEST 7 check sm_disp_queue
 * Expecting 0 on success.
 */
TEST(st_transition, sm_disp_queue_pass)
{
	if(loggingEnable()){
		sm_disp_queue();
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_create_transition_path fail case"
/* TEST 8 check sm_create_transition_path
 * Expecting 0 on success errorcode on failure
 */
TEST(st_transition, sm_create_transition_path_pass)
{
	char src_str[100];
	char dest_str[100];
	int display_id;
	if(loggingEnable()){
		EXPECT_NE(0,sm_create_transition_path(src_str,dest_str,display_id));
	}
    loggingDisable();
}

//"TODO: Need to work on sm_display_path_array fail case"
/* TEST 11 check sm_display_path_array
 * Expecting 0
 */
TEST(st_transition, sm_display_path_array_pass)
{
	if(loggingEnable()){
		sm_display_path_array();
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on sm_deinit_path_transition fail case"
/* TEST 14 check sm_deinit_path_transition
 * Expecting 1 on success  errorcode on failure
 */
TEST(st_transition, sm_deinit_path_transition_pass)
{
	if(loggingEnable()){
		sm_deinit_path_transition();
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on st_state_transition fail case"
/* TEST 15 check st_state_transition
 * Expecting st_state_transition
 */
TEST(st_transition, st_state_transition_pass)
{
	if(loggingEnable()){
		sm_get_state_trans_path();
		EXPECT_EQ(0,0);
	}
    loggingDisable();
}

//"TODO: Need to work on errCheck_state_machine fail case"
/* TEST 16 check errCheck_state_machine
 * Expecting 0 on success  errorcode on failure
 */
TEST(st_transition, errCheck_state_machine_pass)
{
	int src;
	int dest;
	if(loggingEnable()){
		EXPECT_NE(0,errCheck_state_machine(src, dest));
	}
    loggingDisable();
}

//"TODO: Need to work on sm_get_state_id fail case"
/* TEST 17 check sm_get_state_id
 * Expecting 0 on success  errorcode on failure
 */
TEST(st_transition, sm_get_state_id_pass)
{
	st_state_transition *st_state_transition;
	char *state = (char*)malloc(1024);
	memset(state,0x00,1024);
	strcpy(state,"awaiting");
	int display_id;
	if(loggingEnable()){
		EXPECT_NE(0,sm_get_state_id(state, 1));
	}
    loggingDisable();
}

//"TODO: Need to work on ssm_get_state_name fail case"
/* TEST 18 check sm_get_state_name
 * Expecting 0 on success  errorcode on failure
 */ 
TEST(st_transition, sm_get_state_name_pass)
{
	int val;
	int display_id;
	if(loggingEnable()){
		EXPECT_NE(nullptr,sm_get_state_name(val,display_id));
	}
    loggingDisable();
}