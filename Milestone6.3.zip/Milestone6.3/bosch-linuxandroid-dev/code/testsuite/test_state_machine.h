/**
  * @file       test_state_machine.h
  *
  * @brief      Unit test for  test_state_machine
  *
  * @author     external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */ 

#include <iostream>
#include <pthread.h>
#include <semaphore.h>
using namespace std;
extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;
extern "C"
{
	#include "../daemon/src/common/inc/get_config_info.h"
	#include "../daemon/src/state_machine/inc/statemachine.h"
	#include "../daemon/src/common/inc/displayparsejson.h"
	#include "../daemon/src/common/inc/definations.h"
	#include "logging_testsuite.h"
}

//"TODO: Need to work on sm_tcl_proc fail case"
TEST(state,sm_tcl_proc_pass)
{
	char state;
	int display_id;
	int state_ret_val = SUCCESS;
	if(loggingEnable()){
		tcl_init();
		mockClass  mockClassObj;
		EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ(0,sm_tcl_proc(&state,display_id,&state_ret_val));
	}
	loggingDisable();
}

//"TODO: Need to work on sm_assign_fallback_state fail case"
/* TEST2  check sm_assign_fallback_state_file function
 * Expecting 0 on success.
 */

TEST(state,sm_assign_fallback_state_pass)
{
	
	st_state_transition *st_state_transition;
	int display_id=0;
	char *prev_state = (char*)malloc(1024);
	memset(prev_state,0x00,1024);
	strcpy(prev_state,"awaiting");
	char *tar_state= (char*)malloc(1024);
	memset(tar_state,0x00,1024);
	strcpy(prev_state,"connected");
	
	if(loggingEnable()){
		json_parsing_init(config_params );
		
		sm_create_transition_path(prev_state,tar_state,display_id);
		st_state_transition =sm_get_state_trans_path();
	
		EXPECT_EQ(0,sm_assign_fallback_state(st_state_transition,display_id,prev_state,tar_state));
	}
	loggingDisable();
	free(prev_state);
	free(tar_state);
}

//"TODO: Need to work on sm_state_machine_init fail case"
/* TEST3  check sm_state_machine_init_file function
 * Expecting 0 on success.
 */
 
TEST(state,sm_state_machine_init_pass)
{	
	
	st_clientinfo *dispathcer_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
	memset(dispathcer_info,0x00,sizeof(st_clientinfo));
	st_sm_thread_args *thread_args=(st_sm_thread_args*)malloc(sizeof(st_sm_thread_args));
	memset(thread_args,0x00,sizeof(st_sm_thread_args));
	if(loggingEnable()){
		sem_init(&thread_args->req_complete,0,1);
		EXPECT_EQ(0,sm_state_machine_init(dispathcer_info,&thread_args));
		
	}
	loggingDisable();
	free(dispathcer_info);
	free(thread_args);
}
//"TODO: Need to work on sm_state_machine_thread fail case"
/* TEST4  check sm_state_machine_thread function
 * Expecting 0 on success.
 */

TEST(state,sm_state_machine_thread_pass)
{	
	if(loggingEnable()){
		
		mockClass  mockClassObj;
		EXPECT_CALL(mockClassObj, sm_state_machine_thread(_));
		EXPECT_EQ(0,0);
	}
	loggingDisable();
}






