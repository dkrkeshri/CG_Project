/**
  * @file        test_init.h
  *
  * @brief      Unit test for test_init
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

using namespace std;
extern "C"
{
	#include "../daemon/src/init/inc/daemon_init.h"
	#include "../daemon/src/server/inc/server.h"
	#include "logging_testsuite.h"
}

extern "C" int g_argc;
extern "C" char ** g_argv;
extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;


/* check daemon_initfunction
 * Expecting 0 on success.
 */
TEST(daemon_init,daemon_init_pass)
{
	PRINT_OPEN(log_fp);
	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	EXPECT_NE(0,daemon_init(config_params));
	free(config_params->log_config);
	config_params->log_config=NULL;
	free(config_params);
	config_params = NULL;
	PRINT_CLOSE(log_fp);
}

TEST(daemon_init,daemon_init_fail)
{
	if(loggingEnable()){
		EXPECT_NE(DAEMON_INVALID_SOCKET,daemon_init(config_params));
	}
	loggingDisable();
}

/* check daemon_de_initfunction
 * Expecting 0 on success.
 */
TEST(daemon_init,daemon_de_init_pass)
{
	int  server_socket = DAEMON_INVALID_SOCKET;
	int client_socket = DAEMON_INVALID_SOCKET;
	if(loggingEnable()){
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, close(_)).WillRepeatedly(Return(0));
		EXPECT_EQ(SERVER_ERR_CLOSE_FAIL,daemon_de_init(server_socket,client_socket, config_params));
	}
	loggingDisable();
}
