/**
  * @file        test_tcl_init.h
  *
  * @brief      Unit test for test_tcl_init
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

using namespace std;
extern "C"
{
	#include "logging_testsuite.h"
}

extern "C" int g_argc;
extern "C" char ** g_argv;

/* check tcl_init function
 * Expecting 0 on success.
 */
TEST(tcl_init,tcl_init_pass)
{
	if(loggingEnable()){
		EXPECT_EQ(0,tcl_init());
	}
	loggingDisable();
}
/*
 * tcl_init API has no parameters. So,it has only pass case
 */


/* check tcl_proc_callfunction
 * Expecting 0 on success.
 */
TEST(tcl_init,tcl_proc_call_pass)
{
	char proc_func[BUF_SIZE];
	if(loggingEnable()){
		memset(proc_func, 0x00,sizeof(proc_func));
		snprintf(proc_func,sizeof(proc_func),I2C_WORD_ENTRY);
		EXPECT_EQ(0,tcl_proc_call(proc_func,NULL));
	}
	loggingDisable();
}

//"TODO: Need to work on tcl_proc_call fail case"
