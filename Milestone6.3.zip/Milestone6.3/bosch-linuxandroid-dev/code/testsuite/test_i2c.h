/**
  * @file        test_i2c.h
  *
  * @brief      Unit test for i2c_module
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

extern "C"
{
	#include "../daemon/src/adapters/i2c/i2c.h"
	#include "logging_testsuite.h"
}

extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;

/*
 * i2c_dev_open - Function
 */
TEST(i2c, i2c_dev_open_pass)
{
	char i2cstring[64] = {0};
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		i2c_dev_open(&i2cstring[0], 10,0x0C);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
}
/**
  * i2c_dev_open API is void return type
  */

/*
 * i2c_dev_close - Function
 */
TEST(i2c, i2c_dev_close_pass)
{
	char i2cstring[64] = {0};
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		i2c_dev_open(&i2cstring[0], 9,0x0A);
		EXPECT_CALL(mockClassObj, close(_)).WillRepeatedly(Return(0));

		i2c_dev_close(&i2cstring[0]);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
}
/**
  * i2c_dev_close API is void return type
  */

/*
 * i2c_is_connected - Function
 */
TEST(i2c, i2c_is_connected_pass)
{
	char i2cstring[64] = {0};
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		i2c_dev_open(&i2cstring[0], 9,0x0A);
		i2c_is_connected(1, 0x0A);
		EXPECT_EQ(0,0);
		i2c_dev_close(&i2cstring[0]);
	}
	loggingDisable();
}
/**
  * i2c_is_connected API is void return type
  */

/*
 * i2c_op - Function
 */
TEST(i2c, i2c_op_pass)
{
	if(loggingEnable()){
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, i2c_op(_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ(0, 0);
	}
	loggingDisable();
}
/**
  * i2c_op API is void return type
  */

/*
 * i2c_send - Function
 */
/*TEST(i2c, i2c_send_pass)
{
	char i2cstring[64] = {0};
	char *buff = (char *)malloc(64);
	char addbuff[64] = {0};
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		i2c_send(&i2cstring[0], 6, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}*/
/**
  * i2c_send API is void return type
  */

/*
 * i2c_recv - Function
 */
/*TEST(i2c, i2c_recv_pass)
{
	char i2cstring[64] = {0};
	char *buff = (char *)malloc(64);
	char addbuff[64] = {0};
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		sprintf(&addbuff[0], "%lld",  (long long int)&buff[0]);
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		i2c_send(&i2cstring[0], 6,&addbuff[0]);
		i2c_recv(&i2cstring[0], 6,&addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}*/
/**
  * i2c_recv API is void return type
  */

/*
 * get_value - Function
 */
TEST(i2c, get_value_pass)
{
	char i2cstring[64] = {0};
	int index;
	st_i2c_addr i2c_addr[10];
	if(loggingEnable()){
		strcpy(&i2cstring[0], "open");
		EXPECT_NE(0, get_value(&i2cstring[0], &i2c_addr[0], &index));
	}
	loggingDisable();
}

/*
 * i2c_update - Function
 */
//"TODO: Getting Segmentation Fault, need to work on i2c_update_pass case"
/*TEST(i2c, i2c_update_pass)			//segmentation fault
{
	if(loggingEnable()){
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, i2c_op(_,_)).WillRepeatedly(Return(1));
		printf("%s, %d\n", __func__, __LINE__);
		//char *mask = (char *)0x7f1ea80019a0;
		//mask = 0x7f1ea80019a0;
		//i2c_update("open", 69, mask, 1);
		//reg_addr: 69, mask: 0x7f1ea80019a0, value: 1
		i2c_update("open", 69, "0x7f1ea80019a0", 1);
		//i2c_update("open", 69, "0x1010_1010", 1);
		//i2c_update("open", 0x45, "0x1010_1010", 0x01);		//segmentation fault at 176,token = strtok(mask,"x");
		EXPECT_EQ(0,0);
	}
	printf("%s, %d\n", __func__, __LINE__);
	loggingDisable();
}*/
/**
  * i2c_update API is void return type
  */