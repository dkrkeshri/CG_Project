/**
  * @file        test_session_registry.h
  *
  * @brief      Unit test for session_registry
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "logging_testsuite.h"

extern "C"
{
	#include "../daemon/src/session_registry/inc/sessionregistry.h"
}

st_session_registry_ht **session_hash_table = {NULL};
st_clientinfo *info_array = (st_clientinfo*)malloc(sizeof(st_clientinfo));

/* ss_reg_session_registry  - Function
 * return value -- session hash table
 */
TEST(session_registry, ss_reg_session_registry_pass)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path, filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");
		session_hash_table = ss_reg_session_registry(info_array,&session_registry_status);

		EXPECT_NE( 0, sizeof(*session_hash_table));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_session_registry_fail)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path, filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		st_clientinfo *info_array1 = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		info_array1 = NULL;

		session_hash_table = ss_reg_session_registry(info_array1, &session_registry_status);

		EXPECT_EQ( 0, (*session_hash_table));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

/* check ss_reg_create_session_ht function 
 * Expecting 0 on success, errorcode on failure, 1 if same clients sends duplicate sess-id and req-id.
 */
TEST(session_registry, ss_reg_create_session_ht_pass)
{
	FILE *fp;
	char  *filepath;
	
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 15;
		info_array->request_id = 5;
		info_array->display_id  = 1;
		info_array->arg_timeout = 200;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display-list");
		strcpy(info_array->arg_mode,"asynchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(0, ss_reg_create_session_ht(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_create_session_ht_fail1)
{
	FILE *fp;
	char  *filepath;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		st_clientinfo *tmp_client_request_info = NULL;
		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		EXPECT_EQ(SS_REG_ERR_INVAL_REQ, ss_reg_create_session_ht(tmp_client_request_info));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_create_session_ht_fail2)	//check why ss_reg_create_session_ht is called 2 times in this test func
{
	FILE *fp;
	char  *filepath;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 5;
		info_array->request_id = 5;
		info_array->display_id  = 1;
		info_array->arg_timeout = 200;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display-list");
		strcpy(info_array->arg_mode,"asynchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		ss_reg_create_session_ht(info_array);

		info_array->session_id = 5;
		info_array->request_id = 5;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_INSERT_NODE_FOR_SESS_FAIL, ss_reg_create_session_ht(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_create_session_ht_fail3)	//check why ss_reg_create_session_ht is called 3 times in this test func
{
	FILE *fp;
	char  *filepath;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		st_clientinfo *tmp_client_request_info = NULL;
		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 2;
		info_array->request_id = 1;
		info_array->display_id  = 1;
		info_array->arg_timeout = 200;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display-list");
		strcpy(info_array->arg_mode,"asynchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		ss_reg_create_session_ht(info_array);

		info_array->session_id = 6;
		info_array->request_id = 4;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");
		ss_reg_create_session_ht(info_array);

		info_array->session_id = 2;
		info_array->request_id = 1;
		info_array->display_id  = 1;
		info_array->arg_timeout = 150;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display-list");
		strcpy(info_array->arg_mode,"asynchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_INSERT_NODE_FOR_SESS_FAIL, ss_reg_create_session_ht(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

/* check ss_reg_search_sess_id function 
 * Expecting 0 if not present, 1 if present, errorcode on failure.
 */
TEST(session_registry, ss_reg_search_sess_id_pass)
{
	FILE *fp;
	char  *filepath;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}

		strcpy(config_params->log_config->path, filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		EXPECT_EQ(0, ss_reg_search_sess_id(5, 1));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

//"TODO: Need to work on ss_reg_search_sess_id fail case"

/* check ss_reg_deleteSessiontable_entry function 
 * Expecting 0 on success, errorcode on failure, 1 if there is no req. to delete.
 */
//"TODO: Need to work on ss_reg_deleteSessiontable_entry_pass case"
/*TEST(session_registry, ss_reg_deleteSessiontable_entry_pass)
{
	FILE *fp;						//case is failing, its taking the default value as the client request no. is not in the hash table.
	char  *filepath;				//Check how to get the hash table info and pass parameters
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		memset((void *)info_array,0, sizeof(st_clientinfo));	

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		session_hash_table = ss_reg_session_registry(info_array,&session_registry_status);

		EXPECT_EQ(0, ss_reg_deleteSessiontable_entry(session_hash_table, 29, 2, info_array->client_address));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}*/
 
TEST(session_registry, ss_reg_deleteSessiontable_entry_fail)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		session_hash_table = ss_reg_session_registry(info_array,&session_registry_status);

		EXPECT_EQ(DEFAULT_VAL, ss_reg_deleteSessiontable_entry(session_hash_table, 29, 2, info_array->client_address));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

/* check ss_reg_errChk_client_request_info function 
 * Expecting 0 on success, else errorcode on failure.
 */
TEST(session_registry, ss_reg_errChk_client_request_info_pass)
{
	info_array->session_id = 8;
	info_array->request_id = 2;
	info_array->display_id  = 1;
	info_array->arg_timeout = 400;
	strcpy(info_array->arg_target_state,"connected");
	strcpy(info_array->command,"ss_reg_display");
	strcpy(info_array->arg_mode,"synchronous");
	strcpy(info_array->arg_monitor ,"\0");
	strcpy(info_array->arg_method ,"\0");
	strcpy(info_array->client_address, "127.0.0.1");

	EXPECT_EQ(0, ss_reg_errChk_client_request_info(info_array));
}

TEST(session_registry, ss_reg_errChk_client_request_info_fail)
{
	st_clientinfo *info_array1 = (st_clientinfo*)malloc(sizeof(st_clientinfo));
	info_array1 = NULL;

	EXPECT_EQ(SS_REG_ERR_CLI_REQ_INFO, ss_reg_errChk_client_request_info(info_array1));
}

/* check  ss_reg_errChk_deleteSessiontable_entry function 
 * Expecting 0 on success,else errorcode on failure.
 */
TEST(session_registry, ss_reg_errChk_deleteSessiontable_entry_pass)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		session_hash_table = ss_reg_session_registry(info_array,&session_registry_status);

		EXPECT_EQ(0, ss_reg_errChk_deleteSessiontable_entry(session_hash_table, 29, 2, info_array->client_address));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_errChk_deleteSessiontable_entry_fail1)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	st_session_registry_ht **session_hash_table1 = {NULL};
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_ERR_DEL_SESS_ENTRY, ss_reg_errChk_deleteSessiontable_entry(session_hash_table1, 29, 2, info_array->client_address));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_errChk_deleteSessiontable_entry_fail2)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	st_session_registry_ht **session_hash_table1 = {NULL};
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_ERR_DEL_SESS_ENTRY, ss_reg_errChk_deleteSessiontable_entry(session_hash_table1, -1, 2, info_array->client_address));
		EXPECT_EQ(SS_REG_ERR_DEL_SESS_ENTRY, ss_reg_errChk_deleteSessiontable_entry(session_hash_table1, 29, -1, info_array->client_address));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

/* check  ss_reg_errChk_search function 
 * Expecting 0 on success, else errorcode on failure.
 */
TEST(session_registry, ss_reg_errChk_search_pass)
{
	EXPECT_EQ(0, ss_reg_errChk_search(5, 1));
}

TEST(session_registry, ss_reg_errChk_search_fail)
{
	EXPECT_EQ(SS_REG_ERR_SEARCH, ss_reg_errChk_search(5, -1));
	EXPECT_EQ(SS_REG_ERR_SEARCH, ss_reg_errChk_search(-1, 1));
}

//need to write test cases for void function, ss_reg_display

/* check  ss_reg_validate_client_info function 
 * Expecting 0 on success, else errorcode on failure.
 */
TEST(session_registry, ss_reg_validate_client_info_pass)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_NE(0, ss_reg_validate_client_info(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_validate_client_info_fail1)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = -21;
		info_array->request_id = -22;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_ERR_PARAMS_ERROR, ss_reg_validate_client_info(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_validate_client_info_fail2)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 21;
		info_array->request_id = 22;
		info_array->arg_timeout = -400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_ERR_PARAMS_ERROR, ss_reg_validate_client_info(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

TEST(session_registry, ss_reg_validate_client_info_fail3)
{
	FILE *fp;
	char  *filepath;
	int session_registry_status = ERR_VAL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		info_array->session_id = 41;
		info_array->request_id = 2;
		info_array->arg_timeout = 100;
		strcpy(info_array->arg_target_state,"awaiting");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"ss_reg_display");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		EXPECT_EQ(SS_REG_ERR_PARAMS_ERROR, ss_reg_validate_client_info(info_array));

		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}

/* check ss_reg_insert_newnode_for_session function 
 * Expecting 0 on success, else errorcode on failure.
 */
TEST(session_registry, ss_reg_insert_newnode_for_session_pass)
{
	int session_index, sessionId, requestId, req_index;
	info_array->session_id = 8;
	info_array->request_id = 2;
	info_array->display_id  = 1;
	info_array->arg_timeout = 400;
	strcpy(info_array->arg_target_state,"connected");
	strcpy(info_array->command,"ss_reg_display");
	strcpy(info_array->arg_mode,"synchronous");
	strcpy(info_array->arg_monitor ,"\0");
	strcpy(info_array->arg_method ,"\0");
	strcpy(info_array->client_address, "127.0.0.1");
	sessionId = info_array->session_id;

	session_index = (sessionId % SESSION_RES_HT_SIZE);

	EXPECT_EQ(0, ss_reg_insert_newnode_for_session(session_index, info_array));

}

//"TODO: Need to work on ss_reg_insert_newnode_for_session fail case"

/* check ss_reg_insert_newnode_for_req_queue function 
 * Expecting 0 on success, else errorcode on failure.
 */
//"TODO: Need to work on ss_reg_insert_newnode_for_req_queue_pass case"
/*TEST(session_registry, ss_reg_insert_newnode_for_req_queue_pass)
{
	int session_index, sessionId, requestId, req_index;								//need to check why its failing
	info_array->session_id = 15;
	info_array->request_id = 5;
	info_array->display_id  = 1;
	info_array->arg_timeout = 200;
	strcpy(info_array->arg_target_state,"connected");
	strcpy(info_array->command,"ss_reg_display-list");
	strcpy(info_array->arg_mode,"asynchronous");
	strcpy(info_array->arg_monitor ,"\0");
	strcpy(info_array->arg_method ,"\0");
	strcpy(info_array->client_address, "127.0.0.1");
	sessionId = info_array->session_id;
	session_index = (sessionId % SESSION_RES_HT_SIZE);
	requestId = info_array->request_id;
	req_index = (requestId % CLIENT_REQ_HT_SIZE);

	EXPECT_EQ(0, ss_reg_insert_newnode_for_req_queue(session_index, req_index, info_array));
}*/

//"TODO: Need to work on ss_reg_insert_newnode_for_req_queue_fail case"
/*TEST(session_registry, ss_reg_insert_newnode_for_req_queue_fail)			//segmentation fault
{
	int session_index, sessionId, requestId, req_index;
	info_array->session_id = 8;
	info_array->request_id = 2;
	info_array->display_id  = 4;
	info_array->arg_timeout = 400;
	strcpy(info_array->arg_target_state,"connected");
	strcpy(info_array->command,"ss_reg_display");
	strcpy(info_array->arg_mode,"synchronous");
	strcpy(info_array->arg_monitor ,"\0");
	strcpy(info_array->arg_method ,"\0");
	strcpy(info_array->client_address, "127.0.0.1");
	sessionId = info_array->session_id;

	session_index = (sessionId % SESSION_RES_HT_SIZE);
	requestId = info_array->request_id;
	req_index = (requestId % CLIENT_REQ_HT_SIZE);

	EXPECT_EQ(SS_REG_ERR_DUP_ID, ss_reg_insert_newnode_for_req_queue(session_index, req_index, info_array));
}*/

/* check ss_reg_delete_session function 
 * Expecting 0 on success, else errorcode on failure.
 */
//"TODO: Need to work on ss_reg_delete_session_pass case"
/*TEST(session_registry, ss_reg_delete_session_pass)
{
	FILE *fp;																					//segmentation fault
	char  *filepath;
	int session_registry_status = ERR_VAL;
	int sess_index;
	st_session_registry_ht *session_ht_curr = NULL;
	st_session_registry_ht *session_ht_prev = NULL;
	filepath = (char *)"Log_process.txt";
	if(loggingEnable()){

		fp = fopen(filepath ,"w+");
		if ( fp == NULL) {
			printf("File open failed\n");
		}
		strcpy(config_params->log_config->path,filepath);
		config_params->log_config->log_sink = 1;
		config_params->log_config->log_level = 3;

		memset((void *)info_array,0, sizeof(st_clientinfo));	

		info_array->session_id = 8;
		info_array->request_id = 2;
		info_array->display_id  = 1;
		info_array->arg_timeout = 400;
		strcpy(info_array->arg_target_state,"connected");
		strcpy(info_array->command,"ss_reg_display");
		strcpy(info_array->arg_mode,"synchronous");
		strcpy(info_array->arg_monitor ,"\0");
		strcpy(info_array->arg_method ,"\0");
		strcpy(info_array->client_address, "127.0.0.1");

		session_hash_table = ss_reg_session_registry(info_array,&session_registry_status);
		sess_index = (29 % SESSION_RES_HT_SIZE);
		session_ht_curr = session_hash_table[sess_index];
		session_ht_prev = session_ht_curr;
		printf("%s, %d\n", __func__, __LINE__);
		EXPECT_EQ(0, ss_reg_delete_session(sess_index, session_ht_curr, session_ht_prev, session_hash_table));
		printf("%s, %d\n", __func__, __LINE__);
		fclose(fp);
		remove(filepath);
	}
	loggingDisable();
}*/

//"TODO: Need to work on ss_reg_delete_session_fail case"

//"TODO: Need to work on ss_reg_del_req_with_same_sess pass and fail cases"
