/**
  * @file        Logging_testsuite.h
  *
  * @brief      Unit test cases
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#ifndef _CONFIG_TESTSUITE_H_
#define _CONFIG_TESTSUITE_H_

#include "gmock/gmock.h"
#include <semaphore.h>

extern "C"
{
	#include "../daemon/src/adapters/i2c/i2c.h"
}

using testing::Return;
using testing::Matcher;
using testing::AtLeast;
using testing::_;
using ::testing::InitGoogleTest;
using ::testing::AtLeast;

char configure_state[] = "configured";
char suspend_state[] ="suspended";
char awaiting_state[] ="awaiting";
char connect_state[] = "connected";

char warn[] = "WARN";
char error[] = "ERROR";
char info[] = "INFO";
char debug[] = "DEBUG";
char critical[] = "CRITICAL";  /*Error case */
bool loggingEnable();
void loggingDisable();

#define CRITICAL -1

class mocking {
public:
  virtual ~mocking() {}
 
  virtual ssize_t send(int sockfd, const void *buf, size_t len, int flags) = 0;
  virtual int accept(int sockfd, struct sockaddr *addr, socklen_t * addrlen)= 0;
  virtual int open(const char *pathname, int flags) = 0;
  virtual int ioctl(int fd, unsigned long request, short *addr) = 0;
  virtual int close(int fd) = 0;
  virtual int i2c_op(const con_t* ctx, msg_t *msg) = 0;
  //virtual ssize_t read(int fd, void *buf, size_t count) = 0;
  virtual ssize_t write(int fd, const void *buf, size_t count) =0;
 //virtual int connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen)=0;
 // virtual int socket(int domain, int type, int protocol) = 0;
 // virtual ssize_t recv(int socket, void *buffer, size_t length, int flags) =0;
  virtual int	sem_wait(sem_t *sem) = 0;
  virtual int sem_init(sem_t *sem, int pshared, unsigned int value) = 0;
  virtual void sm_state_machine_thread(void *args) = 0;

};

class mockClass : public mocking {
public:
	MOCK_METHOD4( send, ssize_t  (int , const void *, size_t , int ));
	MOCK_METHOD3( accept, int  (int , struct sockaddr *,socklen_t *));
	MOCK_METHOD2(open, int(const char *, int));
	MOCK_METHOD3(ioctl, int(int, unsigned long, short *));
	MOCK_METHOD1(close, int(int));
	MOCK_METHOD2(i2c_op, int(const con_t*, msg_t *));
	//MOCK_METHOD3( read, ssize_t  (int , void *,size_t ));
	MOCK_METHOD3( write, ssize_t  (int , const void *,size_t ));
	//MOCK_METHOD3(connect, int(int, const struct sockaddr *,socklen_t));
	//MOCK_METHOD3(socket, int(int, int ,int));
	//MOCK_METHOD4( recv , ssize_t (int , void *, size_t , int ));
	MOCK_METHOD1(sm_state_machine_thread, void(void *));
	MOCK_METHOD1(sem_wait, int(sem_t *));
	MOCK_METHOD3(sem_init, int(sem_t *,int, unsigned int));

        virtual ~mockClass(){}
};

#endif
