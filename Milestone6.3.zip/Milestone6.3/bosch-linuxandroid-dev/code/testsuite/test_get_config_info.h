/**
  * @file         test_config_info.h
  *
  * @brief       Unit test for test_config_info
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */
#include <iostream>
using namespace std;
extern "C"
{
	#include "../daemon/src/common/inc/get_config_info.h"
	#include "../daemon/src/logging/inc/logger_internal.h"
	#include "../daemon/src/logging/inc/loggerDaemon.h"
	#include "../daemon/src/common/inc/displayparsejson.h"
	#include "../daemon/src/common/inc/definations.h"
	#include "../daemon/src/common/inc/error.h"
}

#include "logging_testsuite.h"

extern "C" int g_argc;
extern "C" char ** g_argv;

/* check read_config_file function
 * Expecting 0 on success.
 */
TEST(get_config_info, read_config_file_pass)
{
	FILE *fp, *filewrite;
	char  *filepath = NULL;
	char  *filewrite_path = NULL;
	int no_of_disp;
	filepath = (char *)"Log_wrong_state.txt";
	filewrite_path = (char *)"config_test.txt";

	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	fp = fopen(filepath ,"w+");
	if ( fp == NULL) {
		printf("File open failed\n");
	}
	filewrite = fopen(filewrite_path, "w+");
	if ( filewrite == NULL) {
		printf("%s %d \n",__FILE__,__LINE__);
		printf("Filewrite open failed\n");
	}
	else{
		fputs("path : Log_wrong_state.txt\n", filewrite);
		fputs("log_level : CRITICAL\n", filewrite);
		fputs("log_sink : 1\n", filewrite);
	}
	strcpy(config_params->log_config->path,filepath);
	config_params->log_config->log_sink = 1;
	config_params->log_config->log_level = 5;

	fclose(fp);
	fclose(filewrite);

	EXPECT_NE(0,read_config_file(config_params, filewrite_path));

	PRINT_CLOSE(log_fp);

	remove(filewrite_path);
	remove(filepath);
	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

//"TODO: Need to work on read_config_file fail case"

/* check  get_config_info function
 * Expecting 0 on success.
 */
TEST(get_config_info, get_config_info_pass)
{
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(0, get_config_info(g_argc, g_argv, config_params));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, get_config_info_fail)
{
	int g_argc=0;
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(CMD_LINE_ERR_CMD_LINE_ARGS_ABSENT,get_config_info(g_argc, g_argv,config_params));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, get_config_info_fail1)
{
	int g_argc=1;
	g_argv[0]=const_cast<char*>("../../daemon/config/invalid_config_file.ini");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_NE(CMD_LINE_ERR_READ_CONFIG_FAIL,get_config_info(g_argc, g_argv,config_params));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

//"TODO: Need to work on get_config_info fail case"

/* check  process_cmd_line_args function
 * Expecting 0 on success.
 */
TEST(get_config_info, process_cmd_line_args_pass)
{
	char config_file_path[BUF_SIZE];

	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	EXPECT_EQ(0, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_fail)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/invalid.txt";
	int g_argc=5;
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	EXPECT_EQ(CMD_LINE_ERR_INVALID_PARAM, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_pass1)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/config_file.ini";
	int g_argc=7;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	g_argv[2]=const_cast<char*>("../../daemon/config/config_file.ini");
	g_argv[3]=const_cast<char*>("-f");
	g_argv[4]=const_cast<char*>("../../logs/log.txt");
	g_argv[5]=const_cast<char*>("-l");
	g_argv[6]=const_cast<char*>("INFO");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	EXPECT_EQ(0, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_pass2)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/config_file.ini";
	int g_argc=4;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	g_argv[2]=const_cast<char*>("../../daemon/config/config_file.ini");
	g_argv[3]=const_cast<char*>("-h");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	EXPECT_EQ(CMD_LINE_ERR_HELPER_NOTIFY, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_fail1)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/invalid_config_file.ini";
	int g_argc=4;
	int i = INIT_VAL;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	g_argv[2]=const_cast<char*>("../../daemon/config/config_file.ini");
	g_argv[3]=const_cast<char*>("-f");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(CMD_LINE_ERR_LOG_FILE_PATH_ABSENT, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_fail2)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/config_file.ini";
	int g_argc=2;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(CMD_LINE_ERR_CONFIG_PATH_ABSENT, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_fail3)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/invalid_config_file.ini";
	int g_argc=4;
	int i = INIT_VAL;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	g_argv[2]=const_cast<char*>("../../daemon/config/config_file.ini");
	g_argv[3]=const_cast<char*>("-l");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(CMD_LINE_ERR_LOG_LVL_ABSENT, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

TEST(get_config_info, process_cmd_line_args_fail4)
{
	char config_file_path[BUF_SIZE]="../../daemon/config/invalid_config_file.ini";
	int g_argc=4;
	g_argv[0]=const_cast<char*>("./server_daemon");
	g_argv[1]=const_cast<char*>("-c");
	g_argv[2]=const_cast<char*>("../../daemon/config/config_file.ini");
	g_argv[3]=const_cast<char*>("-k");
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));
	EXPECT_EQ(CMD_LINE_ERR_INVLD_CMD_LINE_ARGS, process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));
	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}
//"TODO: Need to work on process_cmd_line_args fail case"

/* check  errChk_process_cmd_line_args function
 * Expecting 0 on success.
 */
TEST(get_config_info, errChk_process_cmd_line_args_pass)
{
	char *config_file_path = NULL;
	config_file_path = (char *)"config_test.txt";

	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	EXPECT_EQ(0, errChk_process_cmd_line_args(g_argc, g_argv, config_params->log_config, config_file_path));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

//"TODO: Need to work on errChk_process_cmd_line_args fail case"

/* check  trim_leading_and_trailing_spaces function
 * Expecting 0 on success.
 */
TEST(get_config_info, trim_leading_and_trailing_spaces_pass)
{
	char buf[256] = {0};
	memset(&buf[0], 0x00, sizeof(buf));
	PRINT_OPEN(log_fp);
	strcpy(&buf[0], " name ");
	EXPECT_EQ(0, trim_leading_and_trailing_spaces(&buf[0]));
	PRINT_CLOSE(log_fp);
}

//"TODO: Need to work on trim_leading_and_trailing_spaces fail case"

/* check  check_log_level_param function
 * Expecting log_level on success, -1 on failure.
 */
TEST(get_config_info, check_log_level_param_pass1)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ(1, check_log_level_param("DEBUG"));
	PRINT_CLOSE(log_fp);
}

TEST(get_config_info, check_log_level_param_pass2)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ(2, check_log_level_param("INFO"));
	PRINT_CLOSE(log_fp);
}

TEST(get_config_info, check_log_level_param_pass3)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ(3, check_log_level_param("WARN"));
	PRINT_CLOSE(log_fp);
}

TEST(get_config_info, check_log_level_param_pass4)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ(4, check_log_level_param("ERROR"));
	PRINT_CLOSE(log_fp);
}

TEST(get_config_info, check_log_level_param_fail1)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ(-1, check_log_level_param("critical"));
	PRINT_CLOSE(log_fp);
}

/* check check_logfile_path_param with wrong Path
 * Expecting other than 0 on success.
 */
TEST(get_config_info, check_logfile_path_param_fail)
{
	FILE *fp;
	char filepath[256] = {0};
	strcpy(&filepath[0], "Log_wrong_path.txt");
	remove(&filepath[0]);

	PRINT_OPEN(log_fp);

	fp = fopen(&filepath [0],"w+");
	if ( fp == NULL) {
		printf("File open failed\n");
	}
	EXPECT_NE(0, check_logfile_path_param(NULL));
	fclose(fp);

	PRINT_CLOSE(log_fp);
}

//"TODO: Need to work on check_logfile_path_param pass case"

/* check_disp_config_path with wrong disp config path
 * Expecting 0 on success, else -1 on failure.
 */
TEST(get_config_info, check_disp_config_path_fail)
{
	char buf[] = "critical.txt";
	PRINT_OPEN(log_fp);
	EXPECT_NE(0, check_disp_config_path(&buf[0]));
	PRINT_CLOSE(log_fp);
}

//"TODO: Need to work on check_disp_config_path pass case"

/* check log sink parameter with wrong log sink
 * Expecting 0 on success, else -1 on failure.
 */
TEST(get_config_info, check_logsink_param_fail)
{
	PRINT_OPEN(log_fp);

	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	config_params->log_config->log_sink = 5;

	EXPECT_NE(0, check_logsink_param(config_params->log_config->log_sink));

	PRINT_CLOSE(log_fp);

	free(config_params->log_config);
	config_params->log_config = NULL;
	free(config_params);
	config_params = NULL;
}

//"TODO: Need to work on check_logsink_param pass case"
