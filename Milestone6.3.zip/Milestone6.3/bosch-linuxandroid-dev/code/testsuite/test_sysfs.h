/**
  * @file        test_sysfs.h
  *
  * @brief      Unit test for sysfs_module
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

extern "C"
{
	#include "../daemon/src/adapters/sysfs/sysfs_adapter.h"
	#include "logging_testsuite.h"
}

extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;

#define SYSFS_READ_FILE		"sysfs_ctrl /sys/bus/usb/devices/usb1/manufacturer 1"
#define SYSFS_WRITE_FILE	"sysfs_ctrl /sys/class/leds/input3\:\:capslock/brightness 2"

/*
 * sysfs_adapter_ctrl - Function
 */
TEST(sysfs, sysfs_adapter_ctrl_pass_read)
{
	char sysfsstring[256] = {0};
	char *buff = (char *)malloc(256);
	char addbuff[64] = {0};
	int *length = NULL;
	if(loggingEnable()){
		strcpy(&sysfsstring[0],"/sys/bus/usb/devices/usb1/manufacturer");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		length = (int*)&buff[0];
		*length = 40; 
		sysfs_adapter_ctrl(&sysfsstring[0], SYSFS_READ, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}

TEST(sysfs, sysfs_adapter_ctrl_pass_read2)
{
	char sysfsstring[256] = {0};
	char *buff = (char *)malloc(256);
	char addbuff[64] = {0};
	int *length = NULL;
	if(loggingEnable()){
		strcpy(&sysfsstring[0],"/sys/bus/usb/devices/usb1/manufacturer");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		length = (int*)&buff[0];
		*length =0; 
		sysfs_adapter_ctrl(&sysfsstring[0], SYSFS_READ, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}


TEST(sysfs, sysfs_adapter_ctrl_pass_write)
{
	char sysfsstring[256] = {0};
	char *buff = (char *)malloc(256);
	char addbuff[64] = {0};
	int *length = NULL;
	if(loggingEnable()){
		strcpy(&sysfsstring[0],"1.txt");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		length = (int*)&buff[0];
		*length = 1;
		buff[4] = 0x31; 
		mockClass mockClassObj;
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_CALL(mockClassObj, write(_,_,_)).WillRepeatedly(Return(0));
		sysfs_adapter_ctrl(&sysfsstring[0], SYSFS_WRITE, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}
TEST(sysfs, sysfs_adapter_ctrl_fail)
{
	char sysfsstring[256] = {0};
	char *buff = (char *)malloc(256);
	char addbuff[64] = {0};
	int *length = NULL;
	if(loggingEnable()){
		strcpy(&sysfsstring[0],"/sys/bus/usb/devices/usb1/manufacturer1");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		sysfs_adapter_ctrl(&sysfsstring[0], SYSFS_READ, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}

TEST(sysfs, sysfs_adapter_ctrl_fail2)
{
	char sysfsstring[256] = {0};
	char *buff = (char *)malloc(256);
	char addbuff[64] = {0};
	int *length = NULL;
	if(loggingEnable()){
		strcpy(&sysfsstring[0],"/sys/bus/usb/devices/usb1/manufacturer");
		sprintf(&addbuff[0], "%lld", (long long int)&buff[0]);
		length = (int*)&buff[0];
		*length = 0; 
		sysfs_adapter_ctrl(&sysfsstring[0], 3, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	free(buff);
	buff = NULL;
	loggingDisable();
}

TEST(sysfs, sysfs_adapter_ctrl_fail3)
{
	char addbuff[64] = {0};
	if(loggingEnable()){
		sysfs_adapter_ctrl(NULL, 3, &addbuff[0]);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
}



