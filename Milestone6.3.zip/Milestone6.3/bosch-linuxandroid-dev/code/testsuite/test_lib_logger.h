/**
  * @file        test_lib_logger.h
  *
  * @brief      Unittest for lib_logger
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "logging_testsuite.h"
 
extern "C"
{
	#include "../daemon/src/logging/inc/loggerDaemon.h"
	#include "../daemon/src/logging/inc/logger_internal.h"
}

extern "C" int g_argc;
extern "C" char ** g_argv;

/* check log_init function
 * Expecting 0 on success and error code on failure
 */
//"TODO: Need to work on log_init_pass1 case"
/*TEST(lib_logger, log_init_pass1)				//sometimes passing and sometimes failing
{
	PRINT_OPEN(log_fp);
	local_init();
	EXPECT_EQ( 0, log_init(logging_interface));
	PRINT_CLOSE(log_fp);
	local_deinit();
}*/

//"TODO: Need to work on log_init_pass2 case"
/*TEST(lib_logger, log_init_pass2)				//sometimes passing and sometimes failing
{
	PRINT_OPEN(log_fp);
	local_init();
	logging_interface->log_sink = 0;
	EXPECT_EQ( 0, log_init(logging_interface));
	PRINT_CLOSE(log_fp);
	local_deinit();
}*/

//"TODO: Need to work on log_init_fail case"
/*TEST(lib_logger, log_init_fail)
{
	PRINT_OPEN(log_fp);
	local_init();						//taking log_sink as 0 because of which its failing, need to check
	config_params->log_config->log_sink = -3;
	logging_interface->log_sink = -3;
	//((st_log_config *)(logging_interface)->params)->log_sink = -1;
	EXPECT_EQ( LOG_ERR_LOG_INIT_INVALID_PARAM, log_init(logging_interface));
	PRINT_CLOSE(log_fp);
	local_deinit();
}*/

/* check log_update_logsink function
 * Expecting 0 on success and error code on failure
 */
TEST(lib_logger, log_update_logsink_pass1)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ( 0, log_update_logsink(1));
	PRINT_CLOSE(log_fp);
}

TEST(lib_logger, log_update_logsink_pass2)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ( 0, log_update_logsink(0));
	PRINT_CLOSE(log_fp);
}

TEST(lib_logger, log_update_logsink_fail)
{
	PRINT_OPEN(log_fp);
	EXPECT_EQ( LOG_ERR_INVALID_LOGSINK_PARAM, log_update_logsink(2));
	PRINT_CLOSE(log_fp);
}

/* check log_deinit function
 * Expecting 0 on success
 */
TEST(lib_logger, log_deinit_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	EXPECT_EQ( 0, log_deinit());
	PRINT_CLOSE(log_fp);
	local_deinit();
}
/* 
 * log_deinit API has no parameters, so it only has pass case.
 */

/* check log_get_file_fp function
 * Expecting 0 on success
 */
TEST(lib_logger, log_get_file_fp_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	log_init(logging_interface);
	EXPECT_EQ( 0, log_get_file_fp());
	log_deinit();
	local_deinit();
	PRINT_CLOSE(log_fp);
}
/* 
 * log_get_file_fp API has no parameters, so it only has pass case.
 */

/*
 * check log_processing function
 */
//"TODO: Need to work on log_processing_pass case"
 /*TEST(lib_logger, log_processing_pass)
{
	PRINT_OPEN(log_fp);
	local_init();
	log_init(logging_interface);						//check what needs to be given for line no. and fmt parameters
	log_update_logsink(1);
	PRINT("DEBUG: log_processing\n");
	//check line no. 111 from backend.c
	//log_processing(DEBUG, DEBUG_FEATURE_ENABLE, "../daemon/src/logging/src/backend.c", );
	EXPECT_EQ( 0, 0);

	log_deinit();
	local_deinit();
	PRINT_CLOSE(log_fp);
}*/