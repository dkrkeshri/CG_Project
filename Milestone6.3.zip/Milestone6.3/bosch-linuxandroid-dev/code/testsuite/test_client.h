/**
  * @file        test_client.h
  *
  * @brief      Unit test for test_client
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */


using namespace std;
extern "C"
{
	#include "../client_program/inc/client.h"
	#include "logging_testsuite.h"
}

extern "C" int g_argc;
extern "C" char ** g_argv;

/* check clientStartfunction
 * Expecting 0 on success.
 */

TEST(client,clientStart_fail)
{
	unsigned char fileName[64]="../../client_program/invalid.txt";
	PRINT_OPEN(log_fp);
	EXPECT_NE(CLI_ERR_CONNECT_FAIL,clientStart(fileName));
	PRINT_CLOSE(log_fp);
}

TEST(client,clientStart_fail2)
{
	unsigned char fileName[64]="../../client_program/invalid.txt";
	PRINT_OPEN(log_fp);
	EXPECT_EQ(CLI_ERR_FOPEN_FAIL,clientStart(fileName));
	PRINT_CLOSE(log_fp);
}

TEST(client,clientStart_fail3)
{
	unsigned char fileName[64]="../../client_program/invalid.txt";
	PRINT_OPEN(log_fp);
	EXPECT_NE(CLI_ERR_FREAD_FAIL,clientStart(fileName));
	PRINT_CLOSE(log_fp);
}

TEST(client,clientStart_fail4)
{
	int socket_desc=0;
	unsigned char fileName[64]="../../client_program/invalid.txt";
	PRINT_OPEN(log_fp);
	EXPECT_NE(CLI_ERR_SOCK_FAIL,clientStart(fileName));
	PRINT_CLOSE(log_fp);
}

TEST(client,clientStart_pass)
{
	unsigned char fileName[64]="../../client_program/req1.txt";
	mockClass  mockClassObj1;
	set_skp_receive(1);
	EXPECT_EQ(0,clientStart(fileName));
}
