/**
  * @file        test_gpio.h
  *
  * @brief      Unit test for gpio_module
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "logging_testsuite.h"
 
extern "C"
{
	#include "../daemon/src/adapters/gpio/gpio.h"
}

/* gpio_open  - Function
 * Expecting greater or equal to 0 on success, lessthan 0 on failure.
 */
TEST(gpio_module, gpio_open_pass)
{
	if(loggingEnable()){
		mockClass  mockClassObj;
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		EXPECT_GT( gpio_open(&gpio_name[0], &gpio_drv_name[0], 34, 0), 0);
		get_gpio_number(&gpio_name[0]);
		 gpio_close(&gpio_name[0]);
	}
	loggingDisable();
}

//"TODO: Need to work on gpio_open fail case"

/* gpio_close  - Function
 *
 */
TEST(gpio_module, gpio_close_pass)
{
	if(loggingEnable()){
		mockClass mockClassObj;
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		EXPECT_CALL(mockClassObj, open(_,_)).WillRepeatedly(Return(0));
		gpio_open(&gpio_name[0], &gpio_drv_name[0], 34, 0);
		EXPECT_CALL(mockClassObj, close(_)).WillRepeatedly(Return(0));
		EXPECT_NE( 0, gpio_close(&gpio_name[0]));
	}
	loggingDisable();
}

//"TODO: Need to work on gpio_close fail case"

/* get_gpio_number  - Function
 * Expecting gpio number.
 */
TEST(gpio_module, get_gpio_number_pass)
{
	if(loggingEnable()){
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		gpio_open(&gpio_name[0], &gpio_drv_name[0], 34, 0);
		EXPECT_EQ( 34, get_gpio_number(&gpio_name[0]));
		gpio_close(&gpio_name[0]);
	}
	loggingDisable();
}

//"TODO: Need to work on get_gpio_number fail case"

/* gpio_change_dir  - Function
 * Expecting greater or equal to 0 on success, lessthan 0 on failure.
 */
TEST(gpio_module, gpio_change_dir_pass)
{
	if(loggingEnable()){
		EXPECT_NE( gpio_change_dir(34, 0), 0);
	}
	loggingDisable();
}

//"TODO: Need to work on gpio_change_dir fail case"

/* get_gpioline_value  - Function
 *
 */
TEST(gpio_module, get_gpioline_value_pass)
{
	if(loggingEnable()){
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		gpio_open(&gpio_name[0], &gpio_drv_name[0], 34, 0);
		set_gpioLine_value(&gpio_name[0], 1);
		EXPECT_EQ( -1, get_gpioline_value(&gpio_name[0]));
		gpio_close(&gpio_name[0]);
	}
	loggingDisable();
}

//"TODO: Need to work on get_gpioline_value fail case"

/* set_gpioLine_value  - Function
 *
 */
TEST(gpio_module, set_gpioLine_value_pass)
{
	if(loggingEnable()){
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		gpio_open(&gpio_name[0],&gpio_drv_name[0], 34, 0);
		EXPECT_EQ( -1, set_gpioLine_value(&gpio_name[0], 1));
		gpio_close(&gpio_name[0]);
	}
	loggingDisable();
}

//"TODO: Need to work on set_gpioLine_value fail case"

/* get_chipInfo  - Function
 * Expecting 1 on success.
 */
TEST(gpio_module, get_chipInfo_pass)
{
	if(loggingEnable()){
		char gpio_name[64 ] ={0};
		char gpio_drv_name[64] = {0};
		mockClass  mockClassObj;
		strcpy(&gpio_name[0], "reset");
		strcpy(&gpio_drv_name[0], "gpiochip");
		gpio_open(&gpio_name[0], &gpio_drv_name[0], 34, 0);
		EXPECT_CALL(mockClassObj, ioctl(_,_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ( 1, get_chipInfo());
		gpio_close(&gpio_name[0]);
	}
	loggingDisable();
}


TEST(gpio_module, gpio_change_dir_pass2)
{
	if(loggingEnable()){
		EXPECT_NE( gpio_change_dir(34, 1), 0);
	}
	loggingDisable();
}

TEST(gpio_module, gpio_chipInfo_display_pass)
{
	if(loggingEnable()){
		int gpios= (GPIO_V2_LINE_FLAG_INPUT|
							GPIO_V2_LINE_FLAG_OUTPUT|
							GPIO_V2_LINE_FLAG_BIAS_PULL_UP|
							GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN|
							GPIO_V2_LINE_FLAG_OPEN_SOURCE|
							GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN);
		gpio_chipInfo_display(gpios);
		EXPECT_EQ( 0, 0);
	}
	loggingDisable();
}
/*
 * get_chipInfo API has no parameters, so only has Pass case
 */
