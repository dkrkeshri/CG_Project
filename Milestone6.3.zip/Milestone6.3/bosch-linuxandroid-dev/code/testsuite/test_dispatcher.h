/**
  * @file   test_dispatcher.h    
  *
  * @brief  Unit test for dispatcher
  *
  * @author  external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

using namespace std;
extern "C"
{
	#include "../daemon/src/dispatcher/inc/dispatcher.h"
	#include "logging_testsuite.h"
}
extern "C" int g_argc;
extern "C" char ** g_argv;
extern "C" st_config_params *config_params;
extern "C" st_logger *logging_interface;


/* check dis_check_duplicate_req_in_queue_function
 * Expecting 0 on success.
 */
TEST(dispatcher, dis_check_duplicate_req_in_queue_pass)
{
	st_clientinfo *client_request_info = NULL;
	if(loggingEnable()){
		client_request_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(client_request_info,0x00,sizeof(st_clientinfo));
		mockClass  mockClassObj;
		EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
		EXPECT_NE(SERVER_ERR_SEND_FAIL, dis_check_duplicate_req_in_queue(client_request_info));
	}
	loggingDisable();
	if(client_request_info)
		free(client_request_info);
}

//"TODO: Need to work on dis_check_duplicate_req_in_queue fail case"

/* check dis_add_req_to_queue_function
 * Expecting 0 on success.
 */
TEST(dispatcher, dis_add_req_to_queue_pass)
{
	st_clientinfo *client_request_info = NULL;
	if(loggingEnable()){
		client_request_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(client_request_info,0x00,sizeof(st_clientinfo));
		EXPECT_EQ(0,dis_add_req_to_queue(client_request_info));
	}
	loggingDisable();
	 if(client_request_info)
		free(client_request_info);
}

TEST(dispatcher, dis_add_req_to_queue_fail)
{
	st_clientinfo *client_request_info = NULL;
	st_client_request_ht	*newNode = NULL;
	if(loggingEnable()){
		client_request_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(client_request_info,0x00,sizeof(st_clientinfo));
		EXPECT_NE(DIS_ERR_MALLOC_FAIL,dis_add_req_to_queue(client_request_info));
	}
	loggingDisable();
	 if(client_request_info)
		free(client_request_info);
}

/*
 * check dis_add_req_to_display_queue void type function
 */
TEST(dispatcher, dis_add_req_to_display_queue_pass)
{
	st_clientinfo *display_req = NULL;
	st_sm_thread_args *thread_args=NULL;
	int display_id = 0;
	 if(loggingEnable()){
		display_req = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(display_req, 0x00, sizeof(st_clientinfo));         
		thread_args = (st_sm_thread_args*)malloc(sizeof(st_sm_thread_args));
		memset(thread_args,0x00,sizeof(st_sm_thread_args));
		dis_add_req_to_display_queue(display_req,display_id,&thread_args);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
	if(display_req){
		free(display_req);
		display_req=NULL;
	}
	if(thread_args){
		free(thread_args);
		thread_args=NULL;
	}
}

TEST(dispatcher, dis_add_req_to_display_queue_pass1)
{
	st_clientinfo *display_req = NULL;
	st_sm_thread_args *thread_args=NULL;
	int display_id = 0;
	 if(loggingEnable()){
		display_req = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(display_req, 0x00, sizeof(st_clientinfo));
		thread_args = (st_sm_thread_args*)malloc(sizeof(st_sm_thread_args));
		memset(thread_args,0x00,sizeof(st_sm_thread_args));
	    thread_args[display_id].pos = 1;
		dis_add_req_to_display_queue(display_req,display_id,&thread_args);
		EXPECT_EQ(0,0);
	}
	loggingDisable();
	if(display_req){
		free(display_req);
		display_req=NULL;
	}
	if(thread_args){
		free(thread_args);
		thread_args=NULL;
	}
}

/* check dis_init_function
 * Expecting 0 on success.
 */
TEST(dispatcher, dis_init_pass)
{
	st_clientinfo *clientinfo = NULL;
	st_sm_thread_args* thread_args = NULL;
	
	if(loggingEnable()){
		clientinfo = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(clientinfo,0x00,sizeof(st_clientinfo));	
		thread_args = (st_sm_thread_args*)malloc(sizeof(st_sm_thread_args));
		memset(thread_args,0x00,sizeof(st_sm_thread_args));
		EXPECT_EQ(0,dis_init(clientinfo,&thread_args));
	}
	loggingDisable();
	if(clientinfo){
		free(clientinfo);
		clientinfo=NULL;
	}
	if(thread_args){
		free(thread_args);
		thread_args=NULL;
	}
}

//"TODO: Need to work on dis_init fail case"

/* check dis_process_req_queue_function
 * Expecting st_clientinfo*.
 */
 TEST(dispatcher, dis_process_req_queue_pass)
{
	st_client_request_ht *req_queue_head= NULL;
	st_sm_thread_args* thread_args= NULL;
	if(loggingEnable()){
		req_queue_head= (st_client_request_ht*)malloc(sizeof(st_client_request_ht));
		memset(req_queue_head, 0x00, sizeof(st_client_request_ht));
		req_queue_head->start = 1;
		thread_args = (st_sm_thread_args*)malloc(sizeof(st_sm_thread_args));
		memset(thread_args, 0x00, sizeof(st_sm_thread_args));
		EXPECT_NE(nullptr,dis_process_req_queue(req_queue_head, &thread_args));
	}
	loggingDisable();
	if(thread_args){
		free(thread_args);
		thread_args=NULL;
	}
	if(req_queue_head)
	{
		free(req_queue_head);
		req_queue_head = NULL;
	}
}

/* check dis_print_req_queue_function
 * Expecting 0 on success.
 */
TEST(dispatcher, dis_print_req_queue_pass)
{
	if(loggingEnable()){
		EXPECT_EQ(0, dis_print_req_queue());
	}
	loggingDisable();
}
