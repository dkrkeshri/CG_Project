/**
  * @file        test_config_info.h
  *
  * @brief      Unit test for test_config_info
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

using namespace std;
extern "C"
{
	#include "../daemon/src/server/inc/server.h"
	#include "logging_testsuite.h"
}

extern "C" int g_argc;
extern "C" char ** g_argv;

//int server_fd, client_fd;
//st_clientinfo *clientinfo;

/* check server_initfunction
 * Expecting server socket on success.
 */
TEST(server, server_init_pass)
{
	if(loggingEnable()){
		int server_fd;
		server_fd = server_init();
		EXPECT_NE(0,server_fd);
		//server_de_init(server_fd, 1);
		//close(server_fd);
	}
	loggingDisable();
}

//"TODO: Need to work on server_init fail case"

/* check server_accept_new_connectionfunction
 * Expecting client socket on success.
 */
TEST(server, server_accept_new_connection_pass)
{
	int server_fd = 0, client_fd = 0;
	struct sockaddr_in client_addr;

	if(loggingEnable()){
		st_client_args *client_st;
		client_st = (st_client_args*)malloc(sizeof(st_client_args));
		memset(client_st,0x00,sizeof(st_client_args));

		mockClass  mockClassObj;
		EXPECT_CALL(mockClassObj, accept(_,_,_)).WillRepeatedly(Return(0));

		client_st = server_accept_new_connection(server_fd);
		EXPECT_TRUE( (NULL== client_st));
	}
	loggingDisable();
}

//"TODO: Need to work on server_accept_new_connection fail case"

/* check client_ackfunction
 * Expecting 0 on success.
 */
TEST(server, client_ack_pass)
{
	int server_fd, client_fd;
	struct sockaddr_in client_addr;
	st_client_args *client_st;
	char message[64] = {0};

	if(loggingEnable()) {
		strcpy(&message[0], "SendData");
		mockClass  mockClassObj;
		EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ(SERVER_ERR_SEND_FAIL,client_ack(client_fd, &message[0]));
	}
	loggingDisable();
}

//"TODO: Need to work on client_ack fail case"

/* check server_get_client_infofunction
 * Expecting 0 on success.
 */
TEST(server, server_get_client_info_pass)
{
	char buffer[2048] = {0};
	int  client_fd = 5;
	char ipaddr [64] ={0};
	st_clientinfo clientinfo;
	int ret_val = 0;

	if(loggingEnable()){
	         FILE * fp1 = fopen("../../client_program/config/client9.json", "r");
		if ( fp1 == NULL) {
			printf("open  failed\n");
		}

		fseek(fp1, 0, SEEK_END);
		int size = ftell(fp1);
		fseek(fp1, 0, SEEK_SET);

		if (fread(buffer, size, DEFAULT_VAL, fp1) == 0) {
			printf("Fread failed\n");
		}
		fclose(fp1);
		strcpy(&ipaddr[0],"127.0.0.1");
		EXPECT_EQ(0, server_get_client_info(&buffer[0], client_fd, &ipaddr[0], &clientinfo));
	}
	loggingDisable();
}

//"TODO: Need to work on server_get_client_info fail case"

/* check server_de_initfunction
 * Expecting 0 on success.
 */
TEST(server, client_de_init_pass)
{
	int server_fd, client_fd;
   if(loggingEnable()){
		server_fd = server_init();
		if((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
			perror("socket fails");
		}
		EXPECT_EQ(0,server_de_init(server_fd, client_fd));
	}
	loggingDisable();
}

//"TODO: Need to work on client_de_init fail case"

/* check process_enumerate_displayfunction
 * Expecting 0 on success.
 */
TEST(server, process_enumerate_display_pass)
{
	st_clientinfo *clientinfo = NULL;

	if(loggingEnable()){
		clientinfo = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(clientinfo,0x00,sizeof(st_clientinfo));

		char filename[256] = {0};
		strcpy(&filename[0], "../../daemon/config/display_config/Display0_Config_File.json");
		json_parsing_init(config_params);
		EXPECT_EQ( 0, display_parse_json(&filename[0], 0));

		mockClass  mockClassObj;
		st_notify_msg *newnode =(st_notify_msg *) malloc(sizeof(struct notify_event_msg));
		newnode->socket_number = 0;
		pthread_mutex_init(&newnode->notify_lock,NULL);
		EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ(0,process_enumerate_display(1,clientinfo, newnode));
		free(newnode);
	}
	loggingDisable();
	if(clientinfo){
		free(clientinfo);
	}
}

TEST(server, process_display_info_pass)
{
	st_display_config display_info;
	st_clientinfo *clientinfo = NULL;
	display_info.display_components[0] = (char*)malloc(256);
	memset(display_info.display_components[0] , 0x00, 256);
	strcpy(display_info.display_components[0], "touch");
	strcpy(&display_info.display_name[0],"test");

	if(loggingEnable()){

		mockClass  mockClassObj;
		clientinfo = (st_clientinfo*)malloc(sizeof(st_clientinfo));
		memset(clientinfo,0x00,sizeof(st_clientinfo));
		st_notify_msg *newnode =(st_notify_msg *) malloc(sizeof(struct notify_event_msg));
		newnode->socket_number = 0;
		pthread_mutex_init(&newnode->notify_lock,NULL);
		EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
		EXPECT_EQ(0,process_display_info(&display_info,clientinfo, newnode));
		free(newnode);
	}
	loggingDisable();
	if(display_info.display_components[0]){
		free(display_info.display_components[0]);
	}
	if(clientinfo){
		free(clientinfo);
	}
}
#if 0
TEST(server,notify_msg_proc_pass)
{
	st_notify_msg *newnode =(st_notify_msg *) malloc(sizeof(struct notify_event_msg));
	newnode->socket_number = 0;
	pthread_mutex_init(&newnode->notify_lock,NULL);
	mockClass  mockClassObj;
	EXPECT_CALL(mockClassObj, send(_,_,_,_)).WillRepeatedly(Return(0));
	EXPECT_CALL(mockClassObj, sem_wait(_)).WillRepeatedly(Return(0));
	notify_msg_proc(newnode);
	EXPECT_EQ(0,0);
	free(newnode);
}
#endif
//"TODO: Need to work on process_enumerate_display fail case"