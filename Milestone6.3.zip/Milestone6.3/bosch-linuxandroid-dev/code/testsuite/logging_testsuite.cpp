/**
  * @file        Logging_testsuite.cpp
  *
  * @brief      Unit test cases
  *
  * @author    external.chaneswarareddy.yemme@in.bosch.com
  *
  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include <gtest/gtest.h>
#include <iostream>
#include <string.h>

#include "logging_testsuite.h"
#include "test_get_config_info.h"
#include "test_backend.h"
#include "test_display_parse_json.h"
#include "test_i2c.h"
#include "test_lib_logger.h"
#include "test_server.h"
#include "test_gpio.h"
#include "test_session_registry.h"
#include "test_dispatcher.h"
#include "test_state_machine.h"
#include "test_state_transition.h"
#include "test_sysfs.h"
#include "test_client.h"
#include "test_tcl_init.h"
#include "test_init.h"

extern "C"{
	#include "../daemon/src/common/inc/get_config_info.h"
	#include "../daemon/src/logging/inc/logger_internal.h"
	#include "../daemon/src/logging/inc/loggerDaemon.h"
	#include "../daemon/src/logging/inc/backend.h"
}

using namespace std;

int g_argc;
char ** g_argv;
char  *filewrite_path;

extern "C" {
	#include "../daemon/src/session_registry/inc/sessionregistry.h"
}

st_config_params *config_params;
st_logger *logging_interface;
bool loggingEnable()
{
    int ret_val = SUCCESS;
	bool status = true;
	config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));

	logging_interface = (st_logger*)malloc(sizeof(st_logger));
	memset(logging_interface,0x00,sizeof(st_logger));

	memset(config_params->log_config,0x00,sizeof(st_log_config));

	PRINT_OPEN(log_fp);

	ret_val = get_config_info(g_argc, g_argv,config_params);

	if (ret_val != SUCCESS) {
		if (ret_val != CMD_LINE_ERR_HELPER_NOTIFY)
			PRINT("@%s: Logging Module init Failed\n", __func__);
		status =  false;
		goto end;
	}

	/* Creating Shared Library and Linking to Consol/File */
	logging_interface->log_sink = config_params->log_config->log_sink;
	ret_val = logger_init(config_params,logging_interface);

	if (ret_val != SUCCESS) {
		PRINT("Backend Load Failed\n");
		status =  false;
	}
end:
	PRINT_CLOSE(log_fp);
	return status;
}

void loggingDisable()
{
	PRINT_OPEN(log_fp);
	if(logging_interface){
		logger_deinit(logging_interface);
	}
	if(config_params){
		if(config_params->log_config){
			free(config_params->log_config);
		}
	free(config_params);
	}
	PRINT_CLOSE(log_fp);
}
/* 
 * read_from_file    - function to read log file
 * @file_fp              FILE descriptor
 * @state                config file state
 * @level                log level
 * return_value        1 on success , 0 on failure
 */
#if 0
int read_from_file( char * file_fp, char *level)
{
	FILE *fp;
	int ret=0;
	char *string_found= NULL;
	char *state_found= NULL;
	char  line[256];

	/* temp variables*/
	int temp1 = 0;
	int temp2 = 0;
	int temp3 = 0;
	int temp4 = 0; 

	fp = fopen( file_fp,"r");
	if ( fp == NULL)
		printf("File open failed\n");

	while(fgets(line, sizeof(line), fp) != NULL) {
		if ( string_found = strstr(line,debug) ) {
			temp1  = 1;
		}
		else if (string_found = strstr(line,info)) {
			temp2= 1;
		}
		else if (string_found = strstr(line,warn)) {
			temp3= 1;
		}
		else if (string_found = strstr(line,error)) {
			temp4 = 1;
		}
	}

	if ( level == debug) {
		if ( temp1 == 1 && temp2 == 1 && temp3 == 1 && temp4 == 1)
			ret =1;
	}
	else if ( level == info){
		if( temp2 ==1 && temp3 == 1 && temp4 ==1)
			ret =1;
	}
	else if ( level == warn) {
		if( temp3 ==1 && temp4 ==1)
			ret = 1;
	}
	else{
		if ( temp4 == 1)
			ret =1;
	}
	return (ret );
}

/* print_logs       dump the logs into log file
 * @param void
 * @return_type  void
 */

void print_logs()
{
	LOG_PRINT(DEBUG, "[%d] @%s :DEBUG\n", 
								getpid(), __func__);
	LOG_PRINT(INFO, "[%d] @%s:INFO \n", 
								getpid(), __func__);
	LOG_PRINT(WARN, "[%d] @%s :WARN\n", 
								getpid(), __func__);
	LOG_PRINT(ERROR, "[%d] @%s:ERROR \n",
								getpid(), __func__);
}

/* create_config_file  create config file for testing
 * @input              nothing
 * @return_type     0 on success -1 on failure
 */

int create_config_file()
{
	FILE *filewrite;
	int ret=0;

	filewrite_path = g_argv[2];

	filewrite = fopen(filewrite_path, "w+");
	if ( filewrite == NULL) {
		printf("Filewrite open failed\n");
		ret = ERR_VAL;
	}

	fputs("path : Log_process.txt\n", filewrite);
	fputs("log_level : WARN\n", filewrite);
	fputs("log_sink : file\n", filewrite);

	fclose(filewrite);

	return ret;
}
#endif

int main(int argc, char ** argv)
{
	g_argc = argc;
	g_argv = argv;
	//create_config_file();
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}