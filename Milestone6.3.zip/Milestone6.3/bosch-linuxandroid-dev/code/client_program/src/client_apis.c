/**

  * @file       client_apis.c

  * @brief      Client_apis file

  *

  * @author     EXTERNAL Chappidi Nitish Reddy <external.NitishReddy.Chappidi@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <malloc.h>
#include "../inc/client.h"
int skip_receive = 0;
void set_skp_receive( int val){
	skip_receive = val;
}

int clientStart(unsigned char* fileName)
{
    	int socket_desc;
	int ret_val = SUCCESS;
	struct sockaddr_in server_addr;
    	unsigned char server_message[MSG_SIZE] = {0}, file_path[MSG_SIZE]={0}, client_message[MSG_SIZE] = {0};
	unsigned char ip_addr[BUF_SIZE] ={0};;
	int port_no = 0;
	int req_count = 0;
	int loop_count = 0;
	int ret=0;
	int lenth=0;
    	char buffer[MSG_SIZE];
    	FILE *fp1 = NULL;
	FILE *fp = NULL;

	// Clean buffers:
	memset(server_message,0x00,sizeof(server_message));
	memset(client_message,0x00,sizeof(client_message));
	memset(ip_addr,0x00,sizeof(ip_addr));
	// Create socket:
	socket_desc = socket(AF_INET, SOCK_STREAM, 0);
	if(socket_desc < 0){
	printf("Unable to create socket\n");
		ret_val = CLI_ERR_SOCK_FAIL;
	goto cleanup;
	}
    	printf("Socket created successfully\n");
	fp = fopen(fileName, "r");
	if (fp == NULL) {
		printf("fopen failed for ");
		ret_val = CLI_ERR_FOPEN_FAIL;
		goto cleanup;
	}
	if (NULL == fgets(ip_addr, BUF_SIZE, fp))
		goto cleanup;
	port_no = atoi(fgets(client_message, sizeof(client_message), fp));
	memset(client_message,0x00,sizeof(client_message));
	req_count = atoi(fgets(client_message, sizeof(client_message), fp));

	// Set port and IP the same as server-side:
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port_no);
	server_addr.sin_addr.s_addr = inet_addr(ip_addr);

	// Send connection request to server:
	if(connect(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0){
	printf("Unable to connect\n");
		ret_val = CLI_ERR_CONNECT_FAIL;
	goto cleanup;
	}
	printf("Connected with server successfully\n");

	memset(file_path,'\0',sizeof(file_path));
	while(loop_count < req_count) {
		printf("loop entry\n");
		memset(file_path,0x00,sizeof(file_path));
		memset(client_message,0x00,sizeof(client_message));
		memset(buffer,0x00,sizeof(buffer));
		if (NULL == fgets(file_path, sizeof(file_path), fp)) {
			printf("loop break\n");
			break;
		}

		lenth=strlen(file_path);
		file_path[lenth-1]=0x00;
		printf("Request  filepath %s  \n",file_path);
		fp1 = fopen(file_path, "r");
		if ( fp1 == NULL) {
			printf("Fopen failed\n");
			ret_val = CLI_ERR_FREAD_FAIL;
			goto cleanup;
		}

		fseek(fp1, 0, SEEK_END);
		int size = ftell(fp1);

		fseek(fp1, 0, SEEK_SET);

		if (fread(buffer, size, DEFAULT_VAL, fp1) == 0) {
			printf("Fread failed\n");
		}

		fclose(fp1);
		strcpy(client_message, buffer);
		strcat(client_message,"\0");
		printf("Msg to Server: \n%s\n", client_message);
		// Send the message to server:
		if(send(socket_desc, client_message, strlen(client_message), 0) < 0) {
		    printf("Unable to send message\n");
				ret_val = CLI_ERR_SEND_FAIL;
		    goto cleanup;
		}
		memset(client_message,0x00,sizeof(client_message));
		while(1) {
			if ((skip_receive == 0) && (recv(socket_desc, server_message, sizeof(server_message), 0) <= 0)) {
				printf("Error while receiving server's msg\n");
				ret_val = CLI_ERR_RECV_FAIL;
				goto cleanup;
			} else {
				if(skip_receive){
					strcpy(server_message, RESULT);
				}
				printf("Reply:\n %s\n", server_message);
				if ((strstr(server_message, REQ_SERVED) != NULL)
				|| (strstr(server_message, CLI_INFO_ERR) != NULL)
				|| (strstr(server_message, CLI_REQ_PARAM_INVALID) != NULL)
				|| (strstr(server_message, TIMEOUT_BFR_PROCESSING) != NULL)
				|| (strstr(server_message, REQ_COMPLETE) != NULL)
				|| (strstr(server_message, DISP_INFO_END) != NULL)
				|| (strstr(server_message, PROCESS_FAIL_OR_UNSTABLE_STATE) != NULL)
				|| (strstr(server_message, RESULT) != NULL)) {
					memset(server_message,0x00, sizeof(server_message));
					break;
				}
			}
		}
		//getchar();
		loop_count = loop_count + 1;
		printf("\n");
	}
cleanup:
	// closing file
	if(fp != NULL) {
		fclose(fp);
	}

    // Close the socket:
	printf("close socket\n");
    	close(socket_desc);
    	return ret_val;
}
