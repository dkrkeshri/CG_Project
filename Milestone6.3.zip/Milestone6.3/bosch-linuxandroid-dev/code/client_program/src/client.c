/**

  * @file       client_init.c

  * @brief      Client Program

  *

  * @author     EXTERNAL Chappidi Nitish Reddy <external.NitishReddy.Chappidi@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <malloc.h>
#include "inc/client.h"

int main(int argc, char *argv[]){
	int ret_val = SUCCESS;
	if (argc > 1) {
	if (strcmp(argv[1], "-h") == SUCCESS){
		printf("specify path of req1.txt:(<client_program/req1.txt>)\n");
		printf("\t req1.txt : 1.socket num:127.0.0.1\t 2.port num:8000 \t\t\t                     3.No.of.requirements:3 \t 4.Path:json files\n");
		printf("\nspecify path of req2.txt for client_2:(<client_program/req2.txt>)\n");
		printf("\t req2.txt : 1.socket num:192.168.0 \t 2.port num:8000 \t\t\t                     3.No.of.requirements:10\t 4.Path:json files\n");
		ret_val=FAILURE;
		goto end;
        }else  {
		ret_val = clientStart(argv[1]);
	} 
	 }else {
		printf("Client Execution Format shoule be: ./client <client-req_txt_path>\n");
		ret_val = FAILURE;
	}
end:
	return ret_val;
}
