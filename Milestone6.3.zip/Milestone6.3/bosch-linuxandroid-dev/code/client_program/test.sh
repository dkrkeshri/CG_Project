#!/bin/bash
# Our custom function
client_func(){
  echo `./client ../../client_program/req$1.txt`
}
# For loop 2 times
for i in {1..2}
do
	client_func $i & # Put a function in the background
done
 
## Put all client_func in the background and bash 
## would wait until those are completed 
## before displaying all done message
wait 
echo "All done"
