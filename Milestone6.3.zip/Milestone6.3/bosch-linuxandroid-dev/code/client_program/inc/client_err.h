/**

  * @file       loggerDaemon.h

  * @brief      Logging Module Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#ifndef _CLIENT_ERR_H_
#define _CLIENT_ERR_H_

/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/types.h>

/****************************************************************************
 * MACROS
 ****************************************************************************/
#define SUCCESS			0
#define FAILURE            -1
#define CLI_ERR_BASE			0x3000

#define CLI_ERR_SOCK_FAIL		CLI_ERR_BASE + 0x01
#define CLI_ERR_FOPEN_FAIL		CLI_ERR_BASE + 0x02
#define CLI_ERR_CONNECT_FAIL		CLI_ERR_BASE + 0x03
#define CLI_ERR_SEND_FAIL		CLI_ERR_BASE + 0x04
#define CLI_ERR_RECV_FAIL		CLI_ERR_BASE + 0x05


#define CLI_INFO_ERR			"Client request Information is Invalid"
#define CLI_REQ_PARAM_INVALID		"Invalid Parameters are sent by client"
#define TIMEOUT_BFR_PROCESSING		"Timeout before Processing the Request"
#define PROCESS_FAIL_OR_UNSTABLE_STATE	"Unstable target-state specified in the client request or processing of client request failed"

#endif /* _CLIENT_ERR_ */
