/**

  * @file       loggerDaemon.h

  * @brief      Logging Module Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#ifndef _DEFINITIONS_H_
#define _DEFINITIONS_H_

/****************************************************************************
 * MACROS
 ****************************************************************************/

#define BUF_SIZE		512
#define MSG_SIZE		2048
#define REQ_SERVED		"request received and finished processing"
#define DISP_INFO_END	"Display Info End"
#define REQ_COMPLETE	"request completed"
#define RESULT			"reply"
#define RESPONSE			"response"

#define CLIENT_CONFI_FILE	"../../client_program/req.txt"

#endif /* _DEFINITIONS_H_ */
