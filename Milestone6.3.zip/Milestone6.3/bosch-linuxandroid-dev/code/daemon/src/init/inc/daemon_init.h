/**

  * @file       Init.h

  * @brief      Init Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#ifndef _DAEMON_INIT_H_
#define _DAEMON_INIT_H_

/*****************************************************************************
HEADER FILES
****************************************************************************/
#include"../../common/inc/get_config_info.h"
/*****************************************************************************
FUNCTION  PROTOTYPES
****************************************************************************/
int daemon_init(st_config_params *log_params);
int daemon_de_init(int server_socket, int client_socket,st_config_params *log_params);

#endif /* _DAEMON_INIT_H_ */
