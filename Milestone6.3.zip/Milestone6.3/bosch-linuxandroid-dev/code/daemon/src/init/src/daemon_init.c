/**

  * @file	   daemon_init.c

  * @brief	  Initializing the Daemon.

  *

  * @author	 EXTERNAL Chappidi Nitish Reddy <external.NitishReddy.Chappidi@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#define _GNU_SOURCE

#include "../inc/daemon_init.h"
#include "../../common/inc/error.h"
#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/definations.h"
#include "../../server/inc/server.h"
#include "../../state_machine/inc/statemachine.h"
#include "../../logging/inc/backend.h"
#include "../../common/inc/displayparsejson.h"
/*
 * daemon_init: Function that intializes Daemon
 * @param: argc	 No. of Command Line arguments
 * @param: argv	 All Command Line args are stored in argv
 * @return_value:   Returns server_socket on success, -1 on failure
 */
int daemon_init(st_config_params *config_params)
{
	FUNCTION_START();
	int server_socket = DAEMON_INVALID_SOCKET;
	int ret_val = SUCCESS;

	LOG_PRINT(DEBUG,"Server init is calling\n");
	server_socket = server_init();
	if (server_socket == SERVER_ERR_BIND_FAIL ||
		server_socket == SERVER_ERR_SOCK_FAIL ||
		server_socket == SERVER_ERR_LISTEN_FAIL) {
		LOG_PRINT( ERROR, "Server init Failed\n");
		memset(config_params,0x00,sizeof(config_params));
		LOG_PRINT(ERROR, "Logger init failed\n");
		ret_val = DAEMON_INVALID_SOCKET;
		goto end;

	}

	ret_val = server_socket;
end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * daemon_de_init: Function that deinitializes the Daemon.
 *				   Deinitializing log_module, server, etc.,
 * @param: server_socket	Server Socket
 * @param: client_socket	Client Socket
 * @return_value: 0 on success, else -1 on failure
 */
int daemon_de_init(int server_socket, int client_socket, st_config_params *config_params)
{
	FUNCTION_START();
	int ret_val = SUCCESS;
	LOG_PRINT(DEBUG,"Deinitializing Server\n");
	/* Deinitializing Server */
	ret_val = server_de_init(server_socket, client_socket);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Server Deinit Failed\n");
				goto end;
	}
	LOG_PRINT(INFO, "Server Deinit Successful\n");

	memset(config_params,0x00,sizeof(config_params));

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

