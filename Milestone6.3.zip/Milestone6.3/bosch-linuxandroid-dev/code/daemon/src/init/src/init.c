/**

  * @file	   init.c

  * @brief	  Initializing the Daemon.

  *

  * @author	 EXTERNAL Chappidi Nitish Reddy <external.NitishReddy.Chappidi@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */
#define _GNU_SOURCE
#include "../../common/inc/error.h"
#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/definations.h"
#include "../inc/daemon_init.h"
#include "../../server/inc/server.h"
#include "../../state_machine/inc/statemachine.h"
#include "../../logging/inc/backend.h"
#include "../../common/inc/displayparsejson.h"
#include "../../dispatcher/inc/dispatcher.h"

/*
 * main: Function to accept new connection from clients
 * @param: server_socket	 Server Socket
 * @return_value:   Returns client_socket on success,else -1 on failure
 */
int main(int argc, char *argv[])
{
	int  client_socket;
	int  ret_val = SUCCESS;
	int client_count = SUCCESS;
	int i = INIT_VAL;
	int no_of_disp;
	SA_IN client_addr;
	fd_set readfds;
	pthread_t tid[MAX_CLIENTS];
	char thread_name[THREAD_NAME_LEN];
	int display_id = 0;
	pthread_t disp_tid;
	st_event_split * event_split = (st_event_split *)malloc(sizeof(st_event_split));
	memset(event_split,0x00,sizeof(st_event_split));
	event_split->event_msg = (st_event_msg *) malloc(sizeof(st_event_msg));
	memset(event_split->event_msg,0x00,sizeof(st_event_msg));


	int  server_socket = DAEMON_INVALID_SOCKET;
	st_sm_thread_args **thread_args;

	pthread_t  notifier_tid;
	st_notify_msg *msg =(st_notify_msg *)malloc(sizeof(struct notify_event_msg));
	st_notify_msg *head =(st_notify_msg *)malloc(sizeof(struct notify_event_msg));
	head->socket_number = 0;
	pthread_mutex_init(&head->notify_lock,NULL);

	PRINT_OPEN(log_fp);
	st_client_args *client_args = (st_client_args*)malloc(sizeof(st_client_args));
	st_config_params *config_params = (st_config_params*)malloc(sizeof(st_config_params));
	memset(config_params,0x00,sizeof(st_config_params));
	config_params->log_config = (st_log_config *)malloc(sizeof(st_log_config));

	st_logger *logging_interface = (st_logger*)malloc(sizeof(st_logger));
	memset(logging_interface,0x00,sizeof(st_logger));

	memset(client_args,0x00,sizeof(st_client_args));
	memset(config_params->log_config,0x00,sizeof(st_log_config));

	if(pthread_create(&disp_tid, NULL, disp_split_method_proc, event_split)
													!= INIT_VAL ){
				LOG_PRINT(ERROR,"Thread Creation Failed\n");
			sprintf(thread_name,"disp_split_thr");
			pthread_setname_np(disp_tid, thread_name);
	}


	ret_val = get_config_info(argc, argv,config_params);
	if (ret_val != SUCCESS) {
		if (ret_val != CMD_LINE_ERR_HELPER_NOTIFY)
			PRINT("@%s: Logging Module init Failed\n", __func__);
		goto unint;
	}
	/* Creating Shared Library and Linking to Consol/File */
	logging_interface->log_sink = config_params->log_config->log_sink;
	ret_val = logger_init(config_params,logging_interface);
	if (ret_val != SUCCESS) {
		PRINT("Backend Load Failed\n");
		goto unint;
	}
	PRINT_CLOSE(log_fp);
	
	thread_args = (st_sm_thread_args**) malloc(sizeof(st_sm_thread_args*) * config_params->no_of_disp_config);
	for (i = 0; i < config_params->no_of_disp_config ; i++) {
		thread_args[i] = (st_sm_thread_args*) malloc(sizeof(st_sm_thread_args));
		memset(thread_args[i],0x00,sizeof(st_sm_thread_args));
	}
	/* JSON parsing*/
	ret_val = json_parsing_init(config_params);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Json parsing Failed\n");
		goto unint;
	}
	
	LOG_PRINT(DEBUG,"Daemon Initialization\n");
	/*Daemon Initialization*/
	server_socket = daemon_init(config_params);
	if (server_socket == DAEMON_INVALID_SOCKET) {
		LOG_PRINT(ERROR,"Daemon Initialization failed\n");
		ret_val = DAEMON_INVALID_SOCKET;
		goto unint;
	}
	
	LOG_PRINT(DEBUG,"tcl init failed\n");
	ret_val = tcl_init();
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR, "tcl init failed\n");
		goto unint;
	}

	for ( i=0 ; i < config_params->no_of_disp_config ;i++ ) {
			thread_args[i]->display_id = i;
			thread_args[i]->pos = 1;
			thread_args[i]->notify_msg = head;
			thread_args[i]->event_split = event_split;
			if( pthread_create(&tid[i], NULL, sm_state_machine_thread, thread_args[i]) 
													!= INIT_VAL )
				LOG_PRINT(ERROR,"Thread Creation Failed\n");
			sprintf(thread_name,"sm_thr%d",i);
			pthread_setname_np(tid[i], thread_name);
	}

	st_notify_msg * tmp = head;

	do{
		client_args = server_accept_new_connection(server_socket);
		if (client_args->client_socket == DAEMON_INVALID_SOCKET) {

			LOG_PRINT(ERROR, "Accepting New Connection Failed\n");
			
			/*Daemon Deinitialization*/
			ret_val = daemon_de_init(server_socket, client_socket, config_params);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "@%s:Daemon Deinitialization Failed\n");
				goto unint;
			}
			
			ret_val = DAEMON_INVALID_SOCKET;
			goto unint;
		}
	
	
		st_notify_msg *new =(st_notify_msg *) malloc(sizeof(struct notify_event_msg));
		new->socket_number = client_args->client_socket;
		pthread_mutex_init(&new->notify_lock,NULL);
		tmp->next = new;
		tmp=tmp->next;
	
		msg = new;
		client_args->no_of_disp = config_params->no_of_disp_config;

		thread_args[0]->notify_msg = msg;
		client_args->thread_args = thread_args;
		thread_args[0]->event_split = event_split;
		if( pthread_create(&tid[0], NULL, session_thread, client_args)
													!= SUCCESS )
			LOG_PRINT(ERROR,  "Session Thread Creation Failed\n");
		if( pthread_create(&notifier_tid,NULL,notify_msg_proc,msg)!= SUCCESS)
			LOG_PRINT(ERROR, "Notifier Thread Creation Failed\n");
		sprintf(thread_name,"Sess_thr%d",client_count);
		pthread_setname_np(tid[0], thread_name);
		client_count = client_count + 1;
	}while(1);


	memset(config_params,0x00,sizeof(config_params));
	
unint: 
	free(client_args);
	PRINT_OPEN(log_fp);
	logger_deinit(logging_interface);
	free(config_params->log_config);
	free(config_params);
	PRINT_CLOSE(log_fp);

	return ret_val;
}
