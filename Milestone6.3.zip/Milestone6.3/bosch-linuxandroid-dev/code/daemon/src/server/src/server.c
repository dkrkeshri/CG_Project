/**

  * @file	  server.c

  * @brief	  Server Program.

  *

  * @author	 EXTERNAL Chappidi Nitish Reddy <external.NitishReddy.Chappidi@in.bosch.com>
						EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>
  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 
#define _GNU_SOURCE

#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/displayparsejson.h"
#include "../inc/server.h"
#include "../../common/inc/error.h"
#include "../../common/inc/definations.h"
#include "../../session_registry/inc/sessionregistry.h"
#include <json-c/json.h>
#include"../../dispatcher/inc/dispatcher.h"
#include "../inc/server.h"

//extern st_sm_thread_args **thread_args;

const  st_event_map event_mapper[]= {
	{"invalid",INVALID},
	{"connected",CONNECTED},
	{"awaiting",AWAITING},
	{"suspended",SUSPENDED}
};

/* Mapping event string to event number */
et_event_enum map_string_to_event( char *event_str)
{
	int ret_val= SUCCESS;
	int num_event_map= sizeof(event_mapper)/sizeof(st_event_map);
	for (int i =0;i < num_event_map;i++ )
	{
		if(strcmp(event_str,event_mapper[i].event_str)==0)
		{
			ret_val=event_mapper[i].event_enum;
			goto end;
		}
	}
	ret_val = EVENT_SPLIT_STR_MAP_FAILED ;
end:
       return ret_val;
}

int map_event_to_string( et_event_enum event_num, char* ret_str)
{
	int num_event_map= sizeof(event_mapper)/sizeof(st_event_map);
	//char ret_str[BUF_SIZE];

	for (int i =0;i < num_event_map;i++ )
	{

		if(event_mapper[i].event_enum == event_num)
		{
			strcpy(ret_str,event_mapper[i].event_str);
			goto end;
		}
	}

	strcpy(ret_str,INVALID_STR);
end:
	return SUCCESS;
}

char *req_arr[REQ_SIZE] = {
        "session-id",
        "request-id",
        "display-id",
        "command",
	"arguments"
};
char *arg_arr[ARG_REQ_SIZE] = {
        "target-state",
        "mode",
        "timeout-ms",
        "query",
        "event-type",
        "enable"
};

enum commandid {
        SESSION_ID = 0, REQUEST_ID, DISPLAY_ID, COMMAND, ARGUMENT
};

enum arg_commandid {
       TARGET_STATE=0, MODE, TIMEOUT_MS,QUERY,EVENT_TYPE,ENABLE
};

/*  timer_thread_proc - timer thread
 * @param  arg -  void *
 * return value	- void *
 */

void *timer_thread_proc(void* args)
{
	FUNCTION_START();
	int time_diff_msec = SUCCESS;
	int ret_val = SUCCESS;
	int timeout = 0;
	int client_socket = 0;
	char server_message[MSG_SIZE];
	char request_data[MSG_SIZE];
	char reply_data[MSG_SIZE];
	st_clientinfo *client_info = NULL;;
	static struct timeval t1;
	struct timeval t0 ;


	pthread_detach(pthread_self());
	st_timer_args *tm_args = (st_timer_args*)args;

	while(1){
		LOG_PRINT(ERROR,"waiting for timer start\n");
		sem_wait(&tm_args->start_timer);
		LOG_PRINT(ERROR,"timer start sem received\n");
		gettimeofday(&t1, INIT_VAL);
		client_info = tm_args->client_info;
		timeout = tm_args->client_info->arg_timeout;
		client_socket = tm_args->client_socket;
		t0 = tm_args->t0;
		st_notify_msg* notify_msg = tm_args->notify_msg;
		LOG_PRINT(ERROR,"get time of day\n");
		while (client_info->disconnect_thread == 1) {
			time_diff_msec = (int) (((t1.tv_sec - t0.tv_sec)*1000.0f )+ ((t1.tv_usec - t0.tv_usec)/1000.0f));
			if(time_diff_msec >= timeout) {
				memset(server_message, 0x00, sizeof(server_message));
				memset(request_data, 0x00, sizeof(request_data));
				memset(reply_data, 0x00, sizeof(reply_data));
				sprintf(request_data,"session-id:%d\trequest-id:%d\tresult:NOK",client_info->session_id,client_info->request_id);
				sprintf(reply_data,"error:%s",TIME_OUT);
				ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);

				pthread_mutex_lock(&notify_msg->notify_lock);
				strcpy(notify_msg->message_buffer,server_message );
				sem_post(&notify_msg->notify_sem);
				break;
			}else if (time_diff_msec < timeout) {
				gettimeofday(&t1, INIT_VAL);
				continue;
			}
		}
	}
	FUNCTION_END(0);
	pthread_exit(NULL);
}

/* Session thread - thread will be created for different client request
 * @param  arg -  thread args
 * return value	- void *
 */
void * session_thread(void *arg)
{
	FUNCTION_START();
	int  client_socket;
	int session_registry_status = ERR_VAL;
	int ret_val = SUCCESS;
	int no_of_disp_config_files;
	char client_addr[BUF_SIZE];
	char client_message[MSG_SIZE];
	char server_message[MSG_SIZE]; 
	struct timeval t0;
	st_session_registry_ht **session_hash_table;
	st_timer_args *timer_args =NULL;
	pthread_t thread_id;
	st_clientinfo *client_info_array = NULL;
	st_client_request_ht *req_queue_head = NULL;
	st_clientinfo	*req_to_process = NULL;
	pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
	st_sm_thread_args **thread_args;
	st_notify_msg * notify_msg = (st_notify_msg *) malloc (sizeof(st_notify_msg));
	st_event_split * event_split ;


	struct dispatcher_parse disp_parse;
	int tid = gettid();
	char thread_name[THREAD_NAME_LEN];
	int thread_no=0;
	int state_index;
	char stable[256] = "no";
	char state[256] = "suspend";
	char request_data[MSG_SIZE];
	char reply_data[MSG_SIZE];

	disp_parse.client_info_array = (st_clientinfo*)malloc(sizeof(st_clientinfo));

	timer_args = (st_timer_args*) malloc(sizeof(st_timer_args));
	memset(timer_args,0x00,sizeof(st_timer_args));
	sem_init(&timer_args->start_timer,0,0);

	if( pthread_create(&thread_id, NULL, timer_thread_proc, timer_args)!= INIT_VAL ){
			LOG_PRINT(ERROR, "Thread Creation Failed\n");
			sprintf(thread_name,"tmr_proc:%d",thread_no);
			pthread_setname_np(thread_id, thread_name);
	}
	client_info_array = (st_clientinfo*)malloc(sizeof(st_clientinfo));

	st_client_args *arg_s = (st_client_args *)arg;
	thread_args = arg_s->thread_args;
	notify_msg = thread_args[0]->notify_msg;
	event_split=thread_args[0]->event_split;
	timer_args->notify_msg = notify_msg ;
	pthread_mutex_init(&event_split->event_process_lock,NULL);

	do {
		st_client_args *args = (st_client_args *)arg;
		memset(client_message, 0x00, sizeof(client_message));
		memset(server_message, 0x00, sizeof(server_message));
		memset(client_addr,0x00,sizeof(client_addr));

		memset(client_info_array,0x00,sizeof(st_clientinfo));
		memset(disp_parse.client_info_array,0x00,sizeof(st_clientinfo));
		memset(&disp_parse.client_info_array->arg_target_state[0],0x00,sizeof(256));
		disp_parse.no_of_disp_config_files = args->no_of_disp;
		no_of_disp_config_files = args->no_of_disp;

		client_socket = args->client_socket;
		disp_parse.thread_args = args->thread_args;
		thread_args = args->thread_args;
		pthread_detach(pthread_self());
		/* Receive client's message */

		ret_val  = recv(client_socket, client_message,
										sizeof(client_message), 0);
		LOG_PRINT(INFO, "client_message : %s",client_message);
		if (ret_val <= 0) {
			if ( ret_val == DISCONNECT) {
				/*Client got disconnected*/
				LOG_PRINT(ERROR,"[%d] client %s got disconnected\n",tid,client_addr);
			} else { 
				LOG_PRINT(ERROR, "[%d]Receiving msg Failed\n",tid);
			}
			goto cleanup;
		}

		strcpy(client_addr,args->client_addr);
		gettimeofday(&timer_args->t0, 0);
		/*Parsing Client String and Storing Info. into structure*/
		ret_val = server_get_client_info(client_message,client_socket,client_addr,disp_parse.client_info_array);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR, "get client info Failed\n");
			memset(server_message, 0x00, sizeof(server_message));
			memset(request_data, 0x00, sizeof(request_data));
			sprintf(request_data,"%s","Server reply:Invalid Parameters are received from client");
			ret_val = json_encoder(RESPONSE, &request_data[0], NULL,NULL,&server_message[0]);

			/* sending Message to Client */
			pthread_mutex_lock(&notify_msg->notify_lock);
			strcpy(notify_msg->message_buffer,server_message );
			sem_post(&notify_msg->notify_sem);
			goto end;
		}
		timer_args->client_info = disp_parse.client_info_array;

		if (timer_args->client_info->arg_timeout != NO_TIMEOUT) {
			  timer_args->client_socket = client_socket;
			  disp_parse.client_info_array->disconnect_thread = TIMER_START;
				sem_post(&timer_args->start_timer);
		}
		/*LOG_PRINT(INFO, "[%d]Msg from client: Sess-id =%d Req-id=%d\n" \
			"display-id=%d command=%s\n" \
			"arg_mode=%s arg_timeout=%d " \
			"arg_monitor=%s arg_method=%s\n" \
			"arg_target_state=%s client_address=%s\n",tid,
			disp_parse.client_info_array->session_id , disp_parse.client_info_array->request_id,
			disp_parse.client_info_array->display_id, disp_parse.client_info_array->command,
			disp_parse.client_info_array->arg_mode,
			disp_parse.client_info_array->arg_timeout, 
			disp_parse.client_info_array->arg_monitor, disp_parse.client_info_array->arg_method,
			disp_parse.client_info_array->arg_target_state,
			disp_parse.client_info_array->client_address);*/
			disp_parse.client_info_array->max_display_count = no_of_disp_config_files;
			ret_val = ss_reg_validate_client_info(disp_parse.client_info_array);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "Information from client is Invalid\n");
				disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
				memset(server_message, 0x00, sizeof(server_message));
				memset(request_data, 0x00, sizeof(request_data));
				memset(reply_data, 0x00, sizeof(reply_data));
				sprintf(request_data,"session-id:%d\trequest-id:%d\tresult:NOK",disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
				sprintf(reply_data,"error:%s",CLIENT_REQ_INVALID);

				ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);

				/* sending Message to Client */
				pthread_mutex_lock(&notify_msg->notify_lock);
				strcpy(notify_msg->message_buffer,server_message );
				sem_post(&notify_msg->notify_sem);
				goto end;
			}
		if ( disp_parse.client_info_array->display_id >= no_of_disp_config_files ) {
			memset(server_message, 0x00, sizeof(server_message));
			memset(request_data, 0x00, sizeof(request_data));
			memset(reply_data, 0x00, sizeof(reply_data));
			sprintf(request_data, "session-id:%d\trequest-id:%dtresult : NOK", disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
			sprintf(reply_data, "error:%s",DISP_ID_OUT_OF_RANGE);
			ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
			pthread_mutex_lock(&notify_msg->notify_lock);
			strcpy(notify_msg->message_buffer,server_message );
			sem_post(&notify_msg->notify_sem);
			disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
			goto end;
		}

	/* Checking if Client Request is of asynchronous mode */
		ret_val = strcmp(disp_parse.client_info_array->arg_mode, ASYNC_MODE) ;
		if ( ret_val == SUCCESS) {
			memset(server_message, 0x00, sizeof(server_message));
			memset(request_data, 0x00, sizeof(request_data));
			//memset(reply_data, 0x00, sizeof(reply_data));
			sprintf(request_data,"session-id:%d\trequest-id:%d\tresult:OK",disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
			//sprintf(reply_data,"request received for async mode\n");
			ret_val = json_encoder(RESPONSE, &request_data[0], NULL,NULL,&server_message[0]);

			pthread_mutex_lock(&notify_msg->notify_lock);
			strcpy(notify_msg->message_buffer,server_message );
			sem_post(&notify_msg->notify_sem);
			LOG_PRINT(INFO, "Async mode reply done\n");
		}

		/* Checking For Subscribe and Unsubscribe */
		ret_val = strcmp(disp_parse.client_info_array->command, EVENT_SUBSCRIBE);
		if ( ret_val == SUCCESS) {
			ret_val = process_event_subscribe( disp_parse.client_info_array,notify_msg,event_split);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "process_enumerate_subscribe failed\n");
				memset(server_message, 0x00, sizeof(server_message));
				memset(request_data, 0x00, sizeof(request_data));
				memset(reply_data, 0x00, sizeof(reply_data));
				sprintf(request_data, "session-id:%d\trequest-id:%d\tresult:NOK", disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
				sprintf(reply_data, "error:%s",EVENT_SUBSCRIPTION_FAILED);
				ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
				pthread_mutex_lock(&notify_msg->notify_lock);
				strcpy(notify_msg->message_buffer,server_message );
				sem_post(&notify_msg->notify_sem);
			}
			else{
				memset(server_message, 0x00, sizeof(server_message));
				memset(request_data, 0x00, sizeof(request_data));
				memset(reply_data, 0x00, sizeof(reply_data));
				sprintf(request_data, "session-id:%d\trequest-id:%d\tresult:OK", disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
				sprintf(reply_data, "EventSubscription:%s-done",disp_parse.client_info_array->arg_enable);
				ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
				pthread_mutex_lock(&notify_msg->notify_lock);
				strcpy(notify_msg->message_buffer,server_message );
				sem_post(&notify_msg->notify_sem);
			}
			disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
			goto end;
		}
		/* Checking For Enumerate Display */
		ret_val = strcmp(disp_parse.client_info_array->command, DISPLAY_ENUMERATE);

		if ( ret_val == SUCCESS) {
			ret_val = process_enumerate_display(no_of_disp_config_files, disp_parse.client_info_array,notify_msg);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "process_enumerate_display failed\n");
			}
			LOG_PRINT(INFO, "DISPLAY_ENUMERATE reply done\n");
			disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
			goto end;
		}
		if ( strcmp(disp_parse.client_info_array->command, DISPLAY_INFO) == 0) {
			int display_detect = 0;
			for(int k =0; k < no_of_disp_config_files; k++){
				if(display_config_info[k]->display_id  == disp_parse.client_info_array->display_id){
					display_detect = 1;
					break;
				}
			}
			if(display_detect){
				ret_val = process_display_info(display_config_info[disp_parse.client_info_array->display_id], disp_parse.client_info_array ,notify_msg);
				if (ret_val != SUCCESS) {
					LOG_PRINT(ERROR, "process_display_info failed\n");
				}
			}
			disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
			goto end;
		}

	if (strcmp(disp_parse.client_info_array->command, DISPLAY_GET_FSM_STATE) == 0) {
		memset(server_message, 0x00, sizeof(server_message));
		//strcpy(state,disp_parse.thread_args[disp_parse.client_info_array->display_id]->curr_state);
		strcpy(state,thread_args[disp_parse.client_info_array->display_id]->curr_state);
		state_index = get_state_index(state, disp_parse.client_info_array->display_id);
		memset(request_data, 0x00, sizeof(request_data));
		memset(reply_data, 0x00, sizeof(reply_data));
		if((strcmp(display_config_info[disp_parse.client_info_array->display_id]->state_machine[state_index]->state_type, "stable") ==0) 
		|| (strcmp(display_config_info[disp_parse.client_info_array->display_id]->state_machine[state_index]->state_type, "target") ==0)){
			strcpy(stable,"yes");
		}
		else {
			strcpy(stable,"no");
		}
		sprintf(request_data,"session-id:%d\trequest-id:%d\tresult:OK",disp_parse.client_info_array->session_id, disp_parse.client_info_array->request_id);
		sprintf(reply_data,"state:%s\tstable:%s",state, stable);

		json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
		disp_parse.client_info_array->disconnect_thread =TIMER_STOP;
		pthread_mutex_lock(&notify_msg->notify_lock);
		strcpy(notify_msg->message_buffer,server_message );
		sem_post(&notify_msg->notify_sem);
		goto end;
	}
		/* Dispatcher: Get Client Info. for particular session id */
		ret_val = dis_init(disp_parse.client_info_array,thread_args);

end:
		if ( ret_val == SERVER_ERR_SEND_FAIL) 
			break;
		continue;
cleanup:
		break;

	}while(1);

	LOG_PRINT(DEBUG,"[%d]session_thread functionality is completed\n",tid);
	free(timer_args);
	timer_args = NULL;
	free(disp_parse.client_info_array);
	disp_parse.client_info_array = NULL;

	/* Closing Client Socket */
	close(client_socket);

	FUNCTION_END(0);
	/* Exiting the Thread */
	pthread_exit(NULL);

}


/*
+ * notify_msg_proc: Function to notifier msg
+ * @param: struct notify_msg
+ * @return value void 
+ */
 

void* notify_msg_proc(void *arg)
{
	int ret_val = 0;
	int *sem_value,ret1 ;
	st_notify_msg* notify_msg = (st_notify_msg *) arg;

	sem_init(&notify_msg->notify_sem,0,0);
	while(1){
		sem_wait(&notify_msg->notify_sem);
		ret_val = send(notify_msg->socket_number, notify_msg->message_buffer, strlen(notify_msg->message_buffer),0);
		memset(notify_msg->message_buffer,0x00,sizeof(notify_msg->message_buffer));
		//ret_val = send(notify_msg->socket_number, notify_msg->message_buffer, strlen(notify_msg->message_buffer),MSG_DONTWAIT);
		pthread_mutex_unlock(&notify_msg->notify_lock);
	}
}

int process_display_info(st_display_config *display_info, st_clientinfo* client_info, st_notify_msg* notify_msg)
{
	int ret_val = 0;
	char touch[256];
	int i =0;
	char server_message[MSG_SIZE];
	char buffer[MSG_SIZE];
	char request_data[MSG_SIZE];
	char reply_data[MSG_SIZE];
	memset(touch, 0x00, 256);

	strcpy(touch, "no");
	memset(server_message, 0x00, sizeof(server_message));
	memset(request_data, 0x00, MSG_SIZE);
	memset(reply_data, 0x00, MSG_SIZE);

	sprintf(request_data, "session-id:%d\trequest-id:%d\tresult : OK", client_info->session_id, client_info->request_id);
	while(1) {
		if(strcmp(display_info->display_components[i], "touch") == 0) {
			memset(touch, 0x00, 256);
			strcpy(touch,"yes");
			break;
		}
		i++;
	}
	sprintf(reply_data, "tag:%s\tdisplay-type: %d\ttouch:%s\tconnectivity:%s",display_info->display_name, display_info->display_part_number,touch, display_info->connectivity_type);
	json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
	pthread_mutex_lock(&notify_msg->notify_lock);
	strcpy(notify_msg->message_buffer,server_message );
	sem_post(&notify_msg->notify_sem);

end:
	return ret_val;

}


/*
 * accept_new_connection: Function to accept new connection from clients
 * @param: server_socket	 Server Socket
 * @return_value:   Returns client_socket on success,else errorno on failure
 */
st_client_args* server_accept_new_connection(int server_socket)
{
	FUNCTION_START();
	int client_socket;
	int ret_val = SUCCESS;
	SA_IN client_addr;
	int addr_size = sizeof(client_addr);
	st_client_args* args = NULL;
	if (server_socket < 0) {
		goto end;
	}
	args = (st_client_args*)malloc(sizeof(st_client_args));
	memset(args,0x00,sizeof(st_client_args));

	/*Accept New Connection from Client*/
	client_socket = accept(server_socket, 
							(SA *)&client_addr, 
							(socklen_t *)&addr_size);
	if (client_socket == DAEMON_INVALID_SOCKET) {
		LOG_PRINT(ERROR, "Socket accept Failed\n");
		goto free;
	}

	LOG_PRINT(INFO, "Client connected at IP: %s & port: %i\n", inet_ntoa(client_addr.sin_addr), 
						  ntohs(client_addr.sin_port));

	args->client_socket = client_socket;
	strcpy(args->client_addr,inet_ntoa(client_addr.sin_addr));
	goto end;

free:
	free(args);
	args = NULL;
end:
	FUNCTION_END(0);
	return args;
}

/*
 * server_get_client_info:		   function to get client info from client request
 * @param: client_message[]	  client info from request
 * @return_value:   Returns 0 on success, errorno on failure
 */

int server_get_client_info(char client_message[], int client_socket, char *client_addr, st_clientinfo *client_info)
{
	FUNCTION_START();
	int i, j;
	int ret_val = SUCCESS;
	struct json_object * parsed_json;
	struct json_object * request;
	struct json_object * req;
	struct json_object * variable;
	char *key = NULL; 
	char *token = NULL;

	/* Error Checking for parameters */
	if (client_message ==  NULL && client_socket == DAEMON_INVALID_SOCKET 
		&& client_addr == NULL) {
		ret_val = SERVER_ERR_CLIENT_INFO_FAIL;
		goto end;
	}
	LOG_PRINT(DEBUG,"Error Checking for parameters is completed");

	memset(client_info, 0x00, sizeof(st_clientinfo));

	client_info->session_id = SESS_DEF_ID;
	client_info->request_id = REQ_DEF_ID;
	client_info->display_id  = DIS_DEF_ID;
	client_info->arg_timeout = TIMEOT_DEF_VAL;

	parsed_json = json_tokener_parse(client_message);  
	if (json_object_object_get_ex(parsed_json, "request", &request)) {
		req = json_object_array_get_idx(request, 0);
	}
	for (i =0; i < CLIENT_REQ_SIZE; i++) {
		switch (i) {
			case SESSION_ID:
            	if (json_object_object_get_ex(req, req_arr[SESSION_ID], &variable)) {
					client_info->session_id = json_object_get_int(variable);
            	}
            	break;
        	case REQUEST_ID:
            	if (json_object_object_get_ex(req, req_arr[REQUEST_ID], &variable)) {
					client_info->request_id = json_object_get_int(variable);
            	}
            	break;
			case DISPLAY_ID:
				if (json_object_object_get_ex(req, req_arr[DISPLAY_ID], &variable)) {
					client_info->display_id = json_object_get_int(variable);
				}
				break;
			case COMMAND:
				if (json_object_object_get_ex(req, req_arr[COMMAND], &variable)) {
					strcpy(client_info->command, json_object_get_string(variable));
				}
				break;
			case ARGUMENT:
					if (json_object_object_get_ex(req, req_arr[ARGUMENT], &request)) {
						req = json_object_array_get_idx(request, 0);
					}
					for (j = 0; j < ARG_REQ_SIZE; j++) {
						switch (j) {
							case TARGET_STATE:
								if (json_object_object_get_ex(req, arg_arr[TARGET_STATE], &variable)) {
									strcpy(client_info->arg_target_state, json_object_get_string(variable));
								}
								break;
							case MODE:
								if (json_object_object_get_ex(req, arg_arr[MODE], &variable)) {
									strcpy(client_info->arg_mode, json_object_get_string(variable));
								}
								break;
							case TIMEOUT_MS:
								if (json_object_object_get_ex(req, arg_arr[TIMEOUT_MS], &variable)) {
									client_info->arg_timeout = json_object_get_int(variable);
								}
								break;
							case QUERY:
								if(strcmp(client_info->command,DISPLAY_EXECUTE_QUERY) == 0){
									if (json_object_object_get_ex(req, arg_arr[QUERY], &variable)) {
										strcpy(client_info->query , json_object_get_string(variable));
									}
								}
								break;
							case EVENT_TYPE:
								if (json_object_object_get_ex(req, arg_arr[EVENT_TYPE], &variable)) {
									strcpy(client_info->arg_event_type , json_object_get_string(variable));
								}
								break;
							case ENABLE:
								if (json_object_object_get_ex(req, arg_arr[ENABLE], &variable)) {
									strcpy(client_info->arg_enable , json_object_get_string(variable));
								}
								break;
							default:
								ret_val=JSN_ERR_ARG_REQ_WRG;
								goto end;
						}
					}
					break;
			default:
				ret_val=JSN_ERR_ARG_REQ_WRG;
				goto end;
        }
    }
    /* Copying Client IP Address */
	strcpy(client_info->client_address,client_addr);
	client_info->socket_fd = client_socket;

end:
 	FUNCTION_END(ret_val);
 	return ret_val;
}

/*
 * process subscribed and unsubscribed event
 * @return_value:   Returns 0 on success,else errorno on failure
 */

int process_event_subscribe ( st_clientinfo *client_info_array,st_notify_msg * notify_msg,st_event_split * event_split)
{
	FUNCTION_START();
	int ret_val = SUCCESS;
	char buffer[MSG_SIZE];
	char server_message[MSG_SIZE];
	char request_data[MSG_SIZE];
	pthread_mutex_lock(&event_split->event_process_lock);
	st_client_socket * recv_event = event_split->root;
	st_client_socket * prev_recv_event = NULL;

	while(recv_event)
	{
		if(recv_event->socket_number==client_info_array->socket_fd && recv_event->display_ID == client_info_array->display_id)
		{
			break;
		}
		prev_recv_event = recv_event;
		recv_event=recv_event->next;

	}

	if(recv_event)
	{

		//recv_event->display_ID = client_info_array->display_id;
		//recv_event->socket_number = client_info_array->socket_fd;
		//recv_event->notify = notify_msg;
		//tmp->next=NULL;

	}
	else
	{
		recv_event= (st_client_socket *)malloc(sizeof(st_client_socket));
		recv_event->display_ID = client_info_array->display_id;
		recv_event->socket_number = client_info_array->socket_fd;
		recv_event->next=NULL;
		recv_event->notify = notify_msg;
		if(prev_recv_event != NULL)
			prev_recv_event->next = recv_event;
		//event_split->root=recv_event;

	}
	et_event_enum num= map_string_to_event(client_info_array
			->arg_event_type);
	if( strcmp(client_info_array->arg_enable,"on") == 0)
	{
		recv_event->subscribed_event_type |= num;
	}
	else
	{
		recv_event->subscribed_event_type &= (~num);
	}

	pthread_mutex_unlock(&event_split->event_process_lock);

end:
	FUNCTION_END(ret_val);
	return ret_val;
}
/*
 * process_enumerate_display: funtion to display the display-id 
 * @param: int no_of_disp_config - number of display json file
 * @param: st_clientinfo client info 
 * @return_value:   Returns 0 on success,else errorno on failure
 */

int process_enumerate_display (int no_of_disp_config, st_clientinfo *client_info,st_notify_msg * notify_msg)
{
	FUNCTION_START();
	int i = 0;
	int ret_val = SUCCESS;
	char buffer[MSG_SIZE];
	char server_message[MSG_SIZE];
	char request_data[MSG_SIZE];
	char reply_data[MSG_SIZE];
	memset(server_message, 0x00, sizeof(server_message));

	memset(request_data, 0x00, sizeof(request_data));
	sprintf(request_data,"session-id :%d\trequest-id:%d\tresult :OK",client_info->session_id, client_info->request_id);
	memset(reply_data, 0x00, sizeof(reply_data));
	for (i = 0; i < no_of_disp_config; i++) {

		snprintf(buffer, sizeof(buffer), 
		"display-id-%d :%d \t",i, display_config_info[i]->display_id );
		strcat(reply_data,buffer);
	}

	memset(server_message, 0x00, sizeof(server_message));
	ret_val = json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
	//here based on error code we need to add some error case
	pthread_mutex_lock(&notify_msg->notify_lock);
	strcpy(notify_msg->message_buffer,server_message );
	sem_post(&notify_msg->notify_sem);
	LOG_PRINT(DEBUG,"Display Info End\n");

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * server_init: Initializes Server by creating Socket, Bind, Listen
 * @param: void	 No. of Command Line arguments
 * @return_value:   Returns server_socket on success,else errorno on failure
 */
int server_init(void)
{
	FUNCTION_START();
	int server_socket = DAEMON_INVALID_SOCKET;
	SA_IN server_addr;
	int ret_val = SUCCESS;
	int on = 1;

	/*Server Socket Creation*/
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0) {
		LOG_PRINT(ERROR, "Server Socket Create Failed\n");
		ret_val = SERVER_ERR_SOCK_FAIL;
		goto end;
	}
	LOG_PRINT(DEBUG,"Socket is Created\n");

	/*SetSockOpt for PORT Reuse*/
	ret_val = setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR|SO_REUSEPORT, (const char *) &on, sizeof(on));
	if (ret_val < 0)
	{
		LOG_PRINT(ERROR,"setsockopt failed\n");
		goto end;
	}

	/*Initializing Server Address*/
	server_addr.sin_family	  = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port		= htons(PORT);
	LOG_PRINT(DEBUG,"Initialized Server Address");

	/*Socket Binding*/
	ret_val = bind(server_socket, (SA *)&server_addr, sizeof(server_addr));
	if (ret_val < 0) {
		LOG_PRINT(ERROR,"Socket Binding Failed\n");
		ret_val = SERVER_ERR_BIND_FAIL;
		goto end;
	}

	/*Listening to clients*/
	ret_val = listen(server_socket, MAX_CLIENTS);
	if (ret_val < SUCCESS) {
		LOG_PRINT(ERROR,"Socket Listen Failed\n");
		ret_val = SERVER_ERR_LISTEN_FAIL;
		goto end;
	}

	ret_val = server_socket;

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * server_de_init: Function to deinitialize the server line closing sockets.
 * @param: server_socket	Server Socket
 * @param: client_socket	Client Socket
 * @return_value: 0 on success, else errorno on failure
 */
int server_de_init(int server_socket, int client_socket)
{
	FUNCTION_START();
	int ret_val = SUCCESS;

	LOG_PRINT(DEBUG,"closing server socket ....\n");
	/* Closing Server Socket */
	ret_val = close(server_socket);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Unable to close server socket\n");
		ret_val = SERVER_ERR_CLOSE_FAIL;
		goto end;
	}

	LOG_PRINT(DEBUG,"closing client socket ....\n");
	if ( client_socket != DAEMON_INVALID_SOCKET) {
		/* Closing Client Socket */
		ret_val = close(client_socket);
		if (ret_val == DAEMON_INVALID_SOCKET) {
			LOG_PRINT(ERROR,"Unable to close client socket\n");
			ret_val = SERVER_ERR_CLOSE_FAIL;
			goto end;
		}
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * client_ack: Function to acknowledge the client with message
 * @param: client_socket	Client Socket
 * @param: char *server message - serevr message
 * @return_value: 0 on success, else  SERVER_ERR_SEND_FAIL on failure
 */

int client_ack(int client_socket , char *server_message)
{
	FUNCTION_START();
	int ret_val = SUCCESS;
	if (send(client_socket, server_message, 
					MSG_SIZE, 0) < 0) {
		LOG_PRINT(ERROR, "send Msg Failed\n");
		ret_val = SERVER_ERR_SEND_FAIL;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}
