#ifndef _SERVER_H_
#define _SERVER_H_

/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
#include <pthread.h>
#include "../../common/inc/definations.h"
#include "../../common/inc/displayparsejson.h"

#define PORT            8000
#define MAX_CLIENTS     200
/****************************************************************************
 * TYPEDEF
 ****************************************************************************/
typedef struct sockaddr_in SA_IN;
typedef struct sockaddr SA;


/****************************************************************************
 * FUNCTION PROTOTYPES
 ****************************************************************************/
 
 void *timer_thread_proc(void* args);
 void * session_thread(void *arg);
 void* notify_msg_proc(void *msg);
 st_notify_msg * notify_struct_update(st_notify_msg* head,int socket_number);
 struct client_args* server_accept_new_connection(int server_socket);
 int server_get_client_info(char client_message[], int client_socket, char *client_addr, st_clientinfo *client_info);
 int process_enumerate_display (int, st_clientinfo *client_info,st_notify_msg *notify_msg);
 int server_init(void);
 int server_de_init(int server_socket, int client_socket);
 int client_ack(int client_socket , char *server_message);
 int process_display_info(st_display_config *display_info, st_clientinfo* client_info, st_notify_msg* notify_msg);
 int process_event_subscribe ( st_clientinfo *client_info_array,st_notify_msg * notify_msg,st_event_split * event_split);
 et_event_enum map_string_to_event( char *event_str);
 #endif /* _SERVER_H_ */
