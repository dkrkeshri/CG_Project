#ifndef _DISPATCHER_H_
#define _DISPATCHER_H_

/***************************************************************************** HEADER FILES
 ****************************************************************************/

#include "../../session_registry/inc/sessionregistry.h"

/****************************************************************************
 * FUNCTION PROTOTYPES
 ****************************************************************************/
 
int dis_init(st_clientinfo *,st_sm_thread_args **);
int dis_add_req_to_queue(st_clientinfo *client_request_info);
int dis_check_duplicate_req_in_queue(st_clientinfo *client_request_info);
st_clientinfo* dis_process_req_queue(st_client_request_ht *req_queue_head,st_sm_thread_args**);
int errChk_dispatcher(st_session_registry_ht* session_table_ht[],int session_id);
void dis_add_req_to_display_queue( st_clientinfo *display_req, int display_id,st_sm_thread_args** thread_args);
int dis_print_req_queue(void);
void * disp_split_method_proc(void * arg);

#endif /* _DISPATCHER_H_ */
