/**
  * @file	  dispatcher.c

  * @brief	 Dispatcher function

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/definations.h"
#include "../../common/inc/error.h"
#include "../inc/dispatcher.h"

st_client_request_ht	*req_queue_head = NULL;
st_clientinfo req_to_sm;

/* dispatcher   - Dispatcher function
 * @param: session_table_ht	-  session hash table
 * @param: session_id			  - session ID
 * return value : returns client_info structure address in session_hash_table
 */ 
int dis_init(st_clientinfo*  client_info, st_sm_thread_args** thread_args)
 {
	FUNCTION_START();
	int i;
	
	dis_add_req_to_display_queue(client_info, client_info->display_id,thread_args);

	LOG_PRINT(INFO, "Dispatcher Function is Successful\n");

	FUNCTION_END(0);
	return 0;
}

/* dis_add_req_to_queue   - Add request into queue 
 * @param: st_clientinfo	-  client info 
 * return value : returns 0 on success error code on failure
 */ 

int dis_add_req_to_queue(st_clientinfo *client_request_info)
{
	FUNCTION_START();
	st_client_request_ht	*newNode = NULL;
	st_client_request_ht	*req_queue = NULL;
	int ret_val = INIT_VAL;

	newNode = (st_client_request_ht*) malloc(sizeof(st_client_request_ht));
	if (newNode == NULL) {
			LOG_PRINT(ERROR,"Malloc failed");
			ret_val = DIS_ERR_MALLOC_FAIL;
			goto end;
	}

	/* Copying Clinet Request Info. into newNode */
	memcpy(&newNode->client_info, client_request_info, sizeof(st_clientinfo));
	newNode->link = NULL;
	newNode->start = 0;
	LOG_PRINT(DEBUG,"Copied Clinet Request Info. into newNode\n");
	LOG_PRINT(ERROR,"session_id=%d display_id=%d\n",client_request_info->session_id,client_request_info->display_id);
	if (req_queue_head == NULL) {
		newNode->start =1;
		req_queue_head = newNode;
		
	} else {
		ret_val = dis_check_duplicate_req_in_queue(client_request_info);
		if (ret_val == DEFAULT_VAL) {
				LOG_PRINT(ERROR,"Duplicate Client Request\n");
				ret_val = DIS_ERR_DUP_CLI_REQ;
				goto end;
		}
		req_queue = req_queue_head;
		while (req_queue->link != NULL) {
			req_queue = req_queue -> link;
		}
		req_queue -> link = newNode;
	}
	
	//free(newNode);
	//newNode=NULL;
end:

	FUNCTION_END(ret_val);
	return ret_val;
		
}

/*  print_req_queue  - print request into queue 
 * @param: void
 * return value : returns 0 on success error code on failure
 */ 


int dis_print_req_queue(void)
{
	FUNCTION_START();
	st_client_request_ht	*req_queue = NULL;
	int ret_val = INIT_VAL;

	req_queue = req_queue_head;
	LOG_PRINT(DEBUG,"Printing request into queue\n");
	while (req_queue != NULL) {
		LOG_PRINT(ERROR,"Req_Queue\n========================\nSess-id =%d\nReq-id=%d\n" \
                        "Display-id=%d\nCommand=%s\nArg_mode=%s\n" \
                        "arg_timeout=%d\narg_monitor=%s\narg_method=%s\n" \
                        "arg_target_state=%s\nclient_address=%s\n\n", 
                        req_queue->client_info.session_id ,
                        req_queue->client_info.request_id,
                        req_queue->client_info.display_id, 
                        req_queue->client_info.command,
                        req_queue->client_info.arg_mode,
                        req_queue->client_info.arg_timeout,
                        req_queue->client_info.arg_monitor, 
                        req_queue->client_info.arg_method,
                        req_queue->client_info.arg_target_state, 
                        req_queue->client_info.client_address);
		req_queue = req_queue -> link;
	}
	
	FUNCTION_END(ret_val);
	return ret_val;
}

/*  dis_check_duplicate_req_in_queue  - check duplicate request into queue 
 * @param: st_clientinfo : client info
 * return value : returns 0 on success error code on failure
 */ 

int dis_check_duplicate_req_in_queue(st_clientinfo *client_request_info)
{
	FUNCTION_START();
	st_client_request_ht	*req_queue = NULL;
	int ret_val = INIT_VAL;
	req_queue = req_queue_head;
	LOG_PRINT(DEBUG,"checking duplicate request into queue \n");
	while (req_queue != NULL) {
		LOG_PRINT(DEBUG,"session_id=%d req_session_id=%d\n",req_queue->client_info.session_id, client_request_info->session_id);
		if ((req_queue->client_info.session_id == client_request_info->session_id) 
			&& (req_queue->client_info.request_id == client_request_info->request_id)
			&& (strcmp(req_queue->client_info.client_address, client_request_info->client_address) == INIT_VAL)) {
			ret_val = DEFAULT_VAL;
			goto end;
		}
		req_queue = req_queue -> link;
	}

end:
	   FUNCTION_END(ret_val);
	   return ret_val;
}

/*  dis_add_req_to_display_queue  -  add request to display queue
 * @param: st_clientinfo : client info
 * @param : display_id
 * return value :void
 */ 

void dis_add_req_to_display_queue( st_clientinfo *display_req, int display_id,st_sm_thread_args** thread_args)
{
	FUNCTION_START();
	st_sm_thread_args *newnode=NULL;
	int i = INIT_VAL;
	int state_index;
	st_sm_thread_args* req_queue=NULL, *prev_req_queue=NULL;
	static int j = INIT_VAL;
	int value;
	pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
	
	//pthread_mutex_lock(&lock);
	newnode = (st_sm_thread_args*) malloc(sizeof(st_sm_thread_args));
	if (newnode == NULL) {
		LOG_PRINT(ERROR,"Malloc failed");
		goto end;
	}
	memset(newnode,0x00,sizeof(newnode));
	newnode->dispathcer_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
	memset(newnode->dispathcer_info,0x00,sizeof(st_clientinfo));
	memcpy(newnode->dispathcer_info, display_req, sizeof(st_clientinfo));
	
	newnode->display_id = display_id;
	newnode->next = NULL;
	LOG_PRINT(DEBUG,"Adding req to queue\n");
	if( thread_args[display_id]->pos == 1) {
		newnode->first_req = thread_args[display_id]->first_req;
		newnode->req_complete = thread_args[display_id]->req_complete;
		newnode->next_req = thread_args[display_id]->next_req; 
		memcpy(thread_args[display_id],newnode,sizeof(st_sm_thread_args));

		if ( sem_post(&thread_args[display_id]->first_req) != 0) {
			LOG_PRINT(ERROR,"sem_wait failed\n");
		}
		sem_getvalue(&thread_args[display_id]->first_req,&value);
		thread_args[display_id]->pos = 0;
		thread_args[display_id]->start = 1;
	}else{
		req_queue = thread_args[display_id];
		
		newnode->first_req = thread_args[display_id]->first_req;
		newnode->next_req = thread_args[display_id]-> next_req; 
		newnode->req_complete = thread_args[display_id]->req_complete;
		while(req_queue != NULL) {
			prev_req_queue = req_queue;
			req_queue = req_queue->next;
		}
		prev_req_queue->next = newnode;
		thread_args[display_id]->start = 0;
		sem_post(&thread_args[display_id]->next_req);
	}
	
end:
	FUNCTION_END(0);
	return;
}

/*  dis_process_req_queue  -  process the request queue
 * @param:  st_client_request_ht: request queue
 * return value : st_clientinfo*
 */


st_clientinfo* dis_process_req_queue(st_client_request_ht *req_queue,st_sm_thread_args** thread_args)
{	
	FUNCTION_START();
	st_client_request_ht *req = req_queue;
	
	if (req_queue_head != NULL) {
		req_queue_head = req_queue -> link;
	}
	LOG_PRINT(DEBUG,"Processing the Req queue\n");	
	req_to_sm = req->client_info;
	
	//dis_print_req_queue();
	dis_add_req_to_display_queue(&req_to_sm,req->client_info.display_id,thread_args);
		
	if ( req->start != 1) {
		free(req);
		req= NULL;
	}

	FUNCTION_END(&req_to_sm);
	return (&req_to_sm);
}


void * disp_split_method_proc(void * arg)
{
	st_event_split * event_split_msg= (st_event_split*) arg;
	sem_init(&event_split_msg->event_notify,0,0);

	while(1){
	sem_wait(&event_split_msg->event_notify);
	st_client_socket * recv_event = event_split_msg->root;
	while(recv_event != NULL)
	{
		if((event_split_msg->event_msg->recieved_event_type == 
		recv_event->subscribed_event_type & event_split_msg->event_msg->recieved_event_type) && (event_split_msg->event_msg->display_ID == recv_event->display_ID))
		{
			pthread_mutex_lock(&recv_event->notify->notify_lock);
			strcat(recv_event->notify->message_buffer,event_split_msg->event_msg->msg_buf);
			sem_post(&recv_event->notify->notify_sem);
			break;
			}
		recv_event = recv_event->next;
	}
	}
}
