/**

  * @file	   get_config_info.c

  * @brief	  Get Configuration Info. from Cmd Line and Config File

  *

  * @author	 external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../inc/get_config_info.h"
#include "../inc/error.h"
#include "../inc/definations.h"

//st_sm_thread_args **thread_args;

/*
 * get_config_info: Get Configuration Info. from Cmd Line and Config File
 * @param: argc		No. of Command Line arguments
 * @param: argv		All Command Line args are stored in argv
 * @return_value:  	0 on success, -1 on failure
 */
int get_config_info(int argc, char *argv[], st_config_params *config_params)
{
	char config_file_path[BUF_SIZE];
	int ret_val = SUCCESS;
	
	PRINT("DEBUG: Processing Command Line arguments\n");
	/* Processing Command Line arguments */
	if (argc > 1) {
		ret_val = process_cmd_line_args(argc, argv, config_params->log_config, 
														config_file_path);
		if ((ret_val == CMD_LINE_ERR_INVLD_CONFIG_PATH_OR_NO_R_PER)
			|| (ret_val == MANDATORY_FIELD_ABSENT)
			|| (ret_val == CMD_LINE_ERR_HELPER_NOTIFY)) {
		   goto ret;
		} else if (ret_val != SUCCESS) {
			PRINT("Invalid Command Line arguments are given. " \
				   "Hence Config file settings are followed\n");
		}
	} else {
		PRINT("Command Line args are mandatory " \
			   "(Config File Path)\n");
		ret_val = CMD_LINE_ERR_CMD_LINE_ARGS_ABSENT;
		goto ret;
	}
	
	PRINT("DEBUG: Reading Configuration file\n");
	/*Reading Configuration file*/
	ret_val = read_config_file(config_params, config_file_path);
	if (ret_val != SUCCESS) {
		PRINT(" Config file content is wrong/access fail\n");
		ret_val = CMD_LINE_ERR_READ_CONFIG_FAIL;
		goto ret;
	}

ret:
	return ret_val;
}


/*
 * @process_cmd_line_args: Processes Command Line args, if they are valid then
 * 						   config_file settings will be replaced with 
 *						 cmd line settings
 * @param: no_of_args	  No.of Command Line arguments
 * @param: argv			All Command Line arguments are stored in argv
 * @return_value:		  0 on success, -1 on failure
 */
int process_cmd_line_args(int no_of_args, char *argv[], 
				st_log_config *log_config, char *config_file_path)
{
	
	int i = 0;
	int cmd_line_log_level = LOG_LVL_INVALID;
	int mandatory_field = MANDATORY_FIELD_ABSENT;
	FILE *fp = NULL;
	int ret_val = SUCCESS;
	//st_log_config *log_config = (st_log_config*)malloc(sizeof(st_log_config));
	
	/*Check Parameters*/
	ret_val = errChk_process_cmd_line_args(no_of_args, argv, log_config,
								config_file_path);
	if (ret_val != SUCCESS) {
		PRINT("Invalid arguments\n");
		ret_val = CMD_LINE_ERR_INVALID_PARAM;
		goto cleanup;
	}

	PRINT("DEBUG: Parsing all Command Line Arguments\n");
	/*Parsing all Command Line Arguments*/
	for (i = 1; i < no_of_args; i = i + 2) {
		/*Checking Command Line argument for file*/
		if (strcmp(argv[i], "-f") == SUCCESS) {
			if ((i + 1) >= no_of_args) {
				PRINT("File Path arg. in cmd line is Not given\n");
				ret_val = CMD_LINE_ERR_LOG_FILE_PATH_ABSENT;
				goto cleanup;
			} else {
				ret_val = access(argv[i + 1], F_OK);
				if (ret_val == SUCCESS) {
					/*File already exists*/
					fp = fopen(argv[i + 1], "r");
					if (fp == NULL) {
						PRINT("No Read access to open file in " \
								"Cmd Line\n");
						ret_val = CMD_LINE_ERR_NO_READ_ACCESS_LOG_FILE;
						goto cleanup;
					} else {
						fclose(fp);
						strcpy(log_config->path,argv[i + 1]);
					}
				} else {
					/*File does not exist*/
					fp = fopen(argv[i + 1], "w+");
					if (fp == NULL) {
						PRINT("Invalid Log File Path in " \
								"Cmd Line arg or No Write Permission\n");
						ret_val = CMD_LINE_ERR_INVLD_LOGPATH_OR_NO_W_PER;
						goto cleanup;
					} else {
						fclose(fp);
						remove(argv[i + 1]);

						strcpy(log_config->path,argv[i + 1]);
						ret_val = SUCCESS;
					}
				}
			}

		  /*Checking Command Line argument for Log_Level*/
		} else if (strcmp(argv[i], "-l") == SUCCESS) {
			if ((i + 1) >= no_of_args) {
				PRINT("Log Level in cmd line is not given\n");
				ret_val = CMD_LINE_ERR_LOG_LVL_ABSENT;
				goto cleanup;
			} else {
				cmd_line_log_level = check_log_level_param(argv[i + 1]);
				if (cmd_line_log_level == LOG_LVL_INVALID) {
					PRINT("Wrong Log Lvl in cmd Line. " \
						   "Config Log Lvl settings will be followed\n");
					ret_val = LOG_LVL_INVALID;
					goto cleanup;
				} else {
					log_config->log_level = cmd_line_log_level;
				}
			}

		} else if (strcmp(argv[i], "-c") == SUCCESS) {
			if ((i + 1) >= no_of_args) {
				PRINT("Config. file path in Cmd Line is " \
										"not given\n");
				ret_val = CMD_LINE_ERR_CONFIG_PATH_ABSENT;
				goto cleanup;
			} else {

				/* Setting the mandatory field */
				mandatory_field = MANDATORY_FIELD_PRESENT;

				ret_val = access(argv[i + 1], F_OK);
				if(ret_val == SUCCESS) {
					strcpy(config_file_path,argv[i + 1]);
				}
				else {
					PRINT("Invalid Config File Path in Cmd Line " \
							"Or No Read access\n");
					ret_val = CMD_LINE_ERR_INVLD_CONFIG_PATH_OR_NO_R_PER;
					goto cleanup;
				} 
			}
		} else if (strcmp(argv[i], "-h") == SUCCESS) {
			PRINT_HELP("Supported command line arguments\n");
			PRINT_HELP("\t -f <file>\t\t-   specify the log File path[optional]\n");
			PRINT_HELP("\t -l <log_level>\t\t-   specify the Log level[optional]\n");
			PRINT_HELP("\t -c <config_file_path>\t-   Path of config file[Mandatory]\n\n");
			PRINT_HELP("example content of config file\n");
			PRINT_HELP("\tpath : ../../logs/logs.txt\n \tlog_level : INFO\n \tlog_sink : 1\n \tdisp0-config : Display0_Config_File.json\n");
			ret_val = CMD_LINE_ERR_HELPER_NOTIFY;
			goto cleanup;
		} else {
			PRINT("Invalid Cmd Line args\n");
			ret_val = CMD_LINE_ERR_INVLD_CMD_LINE_ARGS;
			goto cleanup;
		}
	}

	//memcpy(logger->params,log_config,sizeof(st_log_config));;
	if (mandatory_field == MANDATORY_FIELD_ABSENT) {
		PRINT("Config File Path is mandatory field in " \
				"Cmd Line arg.\n");
		ret_val = MANDATORY_FIELD_ABSENT;
		goto cleanup;
	}

cleanup:
	//free(log_config);
	return ret_val;
}

/*
 * @errChk_process_cmd_line_args: Checks the parameters of Function
 *								"process_cmd_line_args"
 * @param: no_of_args		  No. of Command Line arguments
 * @param: argv				All Command Line arguments are stored here
 * @param: config_params	   config parameter structure
 * @param: config_file_path	path to the config file
 * @return_value:			  0 on success, -1 on failure
 */
int  errChk_process_cmd_line_args(int no_of_args, char *argv[],
			   st_log_config *log_config_params	, char *config_file_path) 
{
	
	int i = 0;
	int ret_val = SUCCESS;

	if (no_of_args <= DEFAULT_VAL) {
		ret_val = CMD_LINE_ERR_INVALID_CMD_ARGS_COUNT;
		goto cleanup;
	}

	for (i = DEFAULT_VAL; i < no_of_args; i++) {
		if (argv[i] == NULL) {
			ret_val = CMD_LINE_ERR_CMD_ARGS_NULL_VAL_ERR;
			goto cleanup;
		}
	}
	PRINT("DEBUG: No NULL Argument\n");
	
	if (( log_config_params == NULL) || (config_file_path == NULL)) {
		ret_val = CMD_LINE_ERR_CONF_PARAM_OR_CONF_FILE_PATH_NULL;
		goto cleanup;
	}

cleanup:
	
	return ret_val;
}


/*
 * trim_leading_and_trailing_spaces: Trims Leading and Trailing white/tab
 *								   spaces in the string str
 * @param: str	String whose leading and trailing spaces needs to be trimmed
 * @return_value: 0 on success, -1 on failure
 */
int trim_leading_and_trailing_spaces(char *str)
{	
	
	int i = 0;
	int j = 0;
	int ret_val = SUCCESS;

	if (str == NULL) {
		ret_val = RD_CONF_ERR_STR_NULL;
	}

	for (i = 0; (str[i] == ' ') || (str[i] == '\t'); i++) {
		;
	}

	for (j = 0; str[i]; i++) {
		str[j++] = str[i];
	}
	str[j] = '\0';

	for (i = 0; str[i] != '\0'; i++) {
		if ((str[i] != ' ') && ( str[i] != '\t'))
			j = i;
	}
	str[j+1] = '\0';

ret:
	
	return ret_val;
}

/*
 * check_log_level_param: checks log_level is valid or not, if valid assigns
 *						log_level based on the string "config_log_level"
 * @param: config_log_level   string which contains log level
 * @return_value:			 returns log_level on success, else -1 on failure
 */
int check_log_level_param(const char *config_log_level)
{
	int ret_val = SUCCESS;

	if (config_log_level == NULL) {
		ret_val = RD_CONF_ERR_LOG_LVL_NULL;
	}
	if (strcmp(config_log_level, "ERROR") == SUCCESS) {
		ret_val = ERROR;
	} else if (strcmp(config_log_level, "INFO") == SUCCESS) {
		ret_val = INFO;
	} else if (strcmp(config_log_level, "WARN") == SUCCESS) {
		ret_val = WARN;
	} else if (strcmp(config_log_level, "DEBUG") == SUCCESS) {
		ret_val = DEBUG;
	} else {
		PRINT("Invalid Log Level\n");
		ret_val = LOG_LVL_INVALID;
	}

ret:
	
	return ret_val;
}


/*
 * check_logfile_path_param: checks logfile path is valid or not
 * @param: config_path	 Path of the log file where logs are dumped
 * @return_value:		  0 on success, else -1 on failure
 */
int check_logfile_path_param(const char *config_path)
{
	
	FILE *config_logfile_fp = NULL;
	int  file_access_ret_val = SUCCESS;
	int  ret_val = SUCCESS;
	if (config_path == NULL) {
		ret_val = RD_CONF_ERR_PATH_NULL;
		goto ret;
	}

	PRINT("DEBUG: given config_path is not null\n");
	file_access_ret_val = access(config_path, F_OK);
	if (file_access_ret_val == SUCCESS) {
		/*File already exists*/
		config_logfile_fp = fopen(config_path, "r");
		if (config_logfile_fp == NULL) {
			PRINT("Unable to Open Log File. No Read access\n");
			ret_val = RD_CONF_ERR_LOG_FILE_NO_R_PER;
		} else {
			fclose(config_logfile_fp);
		}
	}
	else  {
		/*File does not exist*/
		config_logfile_fp = fopen(config_path, "w+");
		if (config_logfile_fp == NULL) {
			PRINT("Invalid File Path or No Write Permission\n");
			ret_val = RD_CONF_ERR_INVALID_LOG_PATH_OR_NO_W_PER;
		} else {
			fclose(config_logfile_fp);
			remove(config_path);
		}
	} 

ret:
	
	return ret_val;
}


/*
 * check_disp_config_path: checks display confog file path is valid or not
 * @param: config_path	 Path of the Display Config File
 * @return_value:		  0 on success, else -1 on failure
 */
int check_disp_config_path(const char *disp_config_path)
{
	
	FILE *config_logfile_fp = NULL;
	int  file_access_ret_val = SUCCESS;
	int  ret_val = SUCCESS;

	if (disp_config_path == NULL) {
		ret_val = RD_CONF_ERR_DISP_CONF_PATH_NULL;
		goto ret;
	}

	PRINT("DEBUG: given dis_config_path is not null\n");
	file_access_ret_val = access(disp_config_path, F_OK);
	if (file_access_ret_val == SUCCESS) {
		/*File already exists*/
		config_logfile_fp = fopen(disp_config_path, "r");
		if (config_logfile_fp == NULL) {
			PRINT("Unable to Open Log File. No Read access\n");
			ret_val = RD_CONF_ERR_DISP_CONF_FILE_NO_R_PER;
		} else {
			fclose(config_logfile_fp);
		}
	} else {
		/* File Does nor exist */
		PRINT("Invalid File Path or File Does not " \
		"exist in the specified path\n");
		ret_val = RD_CONF_ERR_DISP_FILE_ABSENT_OR_INVLD_PATH;
	}

ret:
	
	return ret_val;
}

/*
 * check_logsink_param: checks logsink is valid or not
 * @param: config_log_sink	 Indicates whether Logs should be dumped 
 *							 on console or file
 * @return_value:  0 on success, else -1 on failure
 */
int  check_logsink_param(int config_log_sink)
{
	
	int ret_val = SUCCESS;

	if (config_log_sink < 0) {
		ret_val = RD_CONF_ERR_LOG_SINK_FAIL;
		goto ret;
	}
	PRINT("DEBUG: config_log_sink is Successful\n");
	if ((config_log_sink != LOG_SINK_CONSOLE)
			&&  (config_log_sink !=  LOG_SINK_FILE)) {
		PRINT("Invalid Log sink in config file\n");
		ret_val = RD_CONF_ERR_INVLD_LOGSINK_IN_CONFIG_FILE;
		
	}
ret:
	
	return ret_val;
}


/*
 * read_config_file: Reads the configuration file and does initial settings
 *				   based on the parameters in the config. file
 * @param: void
 * @return_value: int
 */
int read_config_file(st_config_params *config_params, 
					 char *config_file_path)
{
	
	char *name	  = NULL;
	char *value	 = NULL;
	FILE *config_fp = NULL;
	int log_sink;
	char line[BUF_SIZE];
	int  ret_val = SUCCESS;
	static int display_id = 0;
	int i =0;
	int no_of_disp_config_files = 0;
	pthread_t tid[5];
	st_log_config *log_config = config_params->log_config;
	
	if ((config_params == NULL) || (config_file_path == NULL) || (config_params->log_config == NULL)) {
		ret_val = RD_CONF_ERR_PARAM_OR_PATH_NULL;
		goto end;
	}

	config_fp = fopen(config_file_path, "r");
	if (config_fp == NULL) {
		PRINT("unable to open config_file in Read Mode\n");
		ret_val = RD_CONF_ERR_CONF_FILE_R_MODE_FOPEN_ERR;
		goto end;
	}
	
	while (fgets(line, sizeof(line), config_fp) != NULL) {
		name  = strtok(line, ":");
		value = strtok(NULL, ":");

		trim_leading_and_trailing_spaces(name);
		trim_leading_and_trailing_spaces(value);

		/*Replacing New line character with Null character*/
		value[strlen(value) - 1] = '\0';

		if (strcmp(name, "path") == SUCCESS) {
			/* If Log File Path is not given in Cmd Line arg.
			   Take Log Level from Config File */
			if (SUCCESS == strcmp(log_config->path, "")) {
				char *txtexist = strstr(value, ".txt");
				if (txtexist && check_logfile_path_param(value) != INVAL) {
					strcpy(log_config->path,value);
				} else {
					PRINT("Invalid Log file Path in Config File\n");
					ret_val = RD_CONF_ERR_CONFIG_FILE_INVLD_LOG_PATH;
					goto cleanup;
				}
			}
		} else if (strcmp(name, "log_level") == SUCCESS) {
			/* If Log Level(Valid) is not mentioned in Cmd Line args.
			   Take Log Level from Config File */
			//if (log_config->log_level == LOG_LVL_INVALID) {
				/*Get Log Level*/
				log_config->log_level = check_log_level_param(value);
				if(log_config->log_level == LOG_LVL_INVALID) {
					PRINT("Invalid Log Lvl in Config file. " \
							"Hence Default Log Level is set\n");
					log_config->log_level = DEFAULT_LOG_LVL_IS_ERROR_LVL;
				}
			//}
		} else if (strcmp(name, "log_sink") == SUCCESS) {

			log_sink = atoi(value);
			if (check_logsink_param(log_sink) == SUCCESS) {
				log_config->log_sink = log_sink;
			} else {
				PRINT("Invalid Log sink in Config File\n");
				ret_val = RD_CONF_ERR_CONFIG_FILE_INVLD_LOG_SINK;
				goto cleanup;
			}
		} else if (strstr(name, "disp") != NULL) {
			ret_val = check_disp_config_path(value);
			if (ret_val != SUCCESS) {
				PRINT("Invalid display Config file %s\n",value);
				continue;
			}
			config_params->display_path[no_of_disp_config_files] = (char*)malloc(256*sizeof(char));
			strcpy(config_params->display_path[no_of_disp_config_files],value);
			no_of_disp_config_files++;
		} else {
			PRINT("Invalid Name in Config file\n");
			ret_val = RD_CONF_ERR_CONFIG_FILE_INVLD_PARAM;
			goto cleanup;
		}
	}
	if(no_of_disp_config_files == 0)
	{
		ret_val = RD_CONF_ERR_CONFIG_FILE_INVLD_PARAM;
		goto cleanup;
	}
	PRINT("DEBUG: all possible cases for config file are passed\n");
	config_params->no_of_disp_config = no_of_disp_config_files;
	//memcpy(config_params->logging_interface->params, log_config,sizeof(st_log_config));

cleanup:	
	fclose(config_fp);
	
end:
	PRINT("%s end\n",__func__);
	return ret_val;
}