/**
  * @file	  display parse json.c

  * @brief	 parsing json file for display

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../inc/error.h"
#include "../inc/displayparsejson.h"
#include "../inc/definations.h"
#include <json-c/json.h>
#include "../../state_machine/inc/statemachine.h"

int num_of_states;
//st_sm_thread_args **thread_args;

char * arr[REQ_SIZE] = {
        "display-name",
        "display-part-number",
        "display-components",
        "connectivity-type",
		"default-state",
		"state-machine"
};
char * state_machine_arr[STATE_MACHINE_SIZE] = {
        "state",
        "actions",
        "next-state",
        "fall-back",
        "state-type"
};
    
enum commandid {
        DISPLAY_NAME = 0, DISPLAY_PART_NUMBER, DISPLAY_COMPONENTS, CONNECTIVITY_TYPE, DEFAULT_STATE, STATE_MACHINE
};

enum state_machine_commandid {
       STATE=0, ACTIONS, NEXT_STATE, FALL_BACK, STATE_TYPE
};

/* display_parse_json -- parsing json file
 * @param - filepath -- path to the dispaly config file
 * @return value -- 0 on success -1 on failure
 */

int display_parse_json( char *filepath, int display_id)
{
	FUNCTION_START();
	FILE *fp;
	char buffer[MSG_SIZE];

	struct json_object *parsed_json;
	
	struct json_object *variable;
	struct json_object *sub_variable;	
	struct json_object *state_machine_obj;
	struct json_object *next_state_ref;
    struct json_object *disp_comp;
	
	int i = 0;
	int j = 0;
	int l=0,x=0;
	int ret_val = SUCCESS;

	fp = fopen(filepath, "r");
	if ( fp == NULL) {
		LOG_PRINT(ERROR,"Fopen failed\n");
		ret_val = FAILURE;
		goto end;
	}

	fseek(fp, 0, SEEK_END);
	int size = ftell(fp);

	fseek(fp, 0, SEEK_SET);

	if (fread(buffer, size, DEFAULT_VAL, fp) == 0) {
		LOG_PRINT(ERROR,"Fread failed\n");
		ret_val = DISP_JSON_ERR_FREAD_FAIL;
		goto end;
	}

	fclose(fp);
	
	display_config_info[display_id]->display_id = display_id;

	parsed_json = json_tokener_parse(buffer);

	for (i = 0; i < REQ_SIZE; i++) {

        switch (i) {
		case DISPLAY_NAME:

            if (json_object_object_get_ex(parsed_json, arr[DISPLAY_NAME], &variable)) {
                  strcpy(display_config_info[display_id]->display_name, json_object_get_string(variable));
            }
			break;
		case DISPLAY_PART_NUMBER:

            if (json_object_object_get_ex(parsed_json, arr[DISPLAY_PART_NUMBER], &variable)) {
		    	display_config_info[display_id]->display_part_number = json_object_get_int(variable);
            }
			break;
		case DISPLAY_COMPONENTS:

            if (json_object_object_get_ex(parsed_json, arr[DISPLAY_COMPONENTS], &variable)) {
               	for (j=INIT_VAL ; j < json_object_array_length(variable); j++) {
		              	display_config_info[display_id]->display_components[j] = (char *) malloc(BUF_SIZE*sizeof(char));
		              	state_machine_obj = json_object_array_get_idx(variable, j);
						strcpy(display_config_info[display_id]->display_components[j], json_object_get_string(state_machine_obj));
	            }	
            }
			break;
        case CONNECTIVITY_TYPE:

			if (json_object_object_get_ex(parsed_json, arr[CONNECTIVITY_TYPE], &variable)) {
					strcpy(display_config_info[display_id]->connectivity_type, json_object_get_string(variable));
			}
			break;
        case DEFAULT_STATE:

            if (json_object_object_get_ex(parsed_json, arr[DEFAULT_STATE], &variable)) {
               	strcpy(display_config_info[display_id]->default_state,  json_object_get_string(variable));
            }
            break;
        case STATE_MACHINE:
	
            if (json_object_object_get_ex(parsed_json, arr[STATE_MACHINE], &variable)) {
            	num_of_states = json_object_array_length(variable);
		
               	for (j = INIT_VAL ; j < json_object_array_length(variable); j++) {
			
					display_config_info[display_id]->state_machine[j] = (st_dspl_state_mac *) malloc(BUF_SIZE*sizeof(st_dspl_state_mac));
					state_machine_obj = json_object_array_get_idx(variable, j);
			
					for(x=0; x<STATE_MACHINE_SIZE; x++){
				
						switch(x)
						{
					
						case STATE:
            				if (json_object_object_get_ex(state_machine_obj, state_machine_arr[STATE], &sub_variable)) {
								strcpy(display_config_info[display_id]->state_machine[j]->state, json_object_get_string(sub_variable));
            				}
            				break;
            			case ACTIONS:
            				if (json_object_object_get_ex(state_machine_obj, state_machine_arr[ACTIONS], &sub_variable)) {
								strcpy(display_config_info[display_id]->state_machine[j]->actions, json_object_get_string(sub_variable));
            				}
            				break;
            			case NEXT_STATE:
            				if (json_object_object_get_ex(state_machine_obj, state_machine_arr[NEXT_STATE], &sub_variable)) {
                				for (l = INIT_VAL; l < json_object_array_length(sub_variable); l++) {
									display_config_info[display_id]->state_machine[j]->next_state[l] = (char *) malloc(BUF_SIZE*sizeof(char));
									next_state_ref = json_object_array_get_idx(sub_variable, l);
									strcpy(display_config_info[display_id]->state_machine[j]->next_state[l], json_object_get_string(next_state_ref));
								}
            				}
            				break;
            			case FALL_BACK:
            				if (json_object_object_get_ex(state_machine_obj, state_machine_arr[FALL_BACK], &sub_variable)) {
                					strcpy(display_config_info[display_id]->state_machine[j]->fall_back,"\0");
									if (sub_variable != NULL) {
										strcpy(display_config_info[display_id]->state_machine[j]->fall_back,  json_object_get_string(sub_variable));
									}
            				}
            				break;
            			case STATE_TYPE:
            				if (json_object_object_get_ex(state_machine_obj, state_machine_arr[STATE_TYPE], &sub_variable)) {
                				strcpy(display_config_info[display_id]->state_machine[j]->state_type, json_object_get_string(sub_variable));
								display_config_info[display_id]->state_machine[j]->state_id = j+1;
            				}
            				break;
            			default:
            				ret_val = JSN_ERR_ARG_REQ_WRG;
							goto end;
            				break;
            			}
					}
				}
                	
            }
            break;
        default:
            goto end;
			break;
	
        }
    }
end:  
		FUNCTION_END(ret_val);  
 		return ret_val;
}

/* validate_json_data - function will check the json data
 * @param- void
 * @return_type : 0 on success -1 on failure
*/
int validate_json_data(int display_id)
{
	FUNCTION_START();
	int i = 0;
	int state_index = 0;
	int ret_val= 0;
	for (i = 0; i < num_of_states ; i++) {
		if (strcmp(display_config_info[display_id]->state_machine[i]->fall_back,"\0") != SUCCESS) {

            state_index 
            = get_state_index(display_config_info[display_id]->state_machine[i]->fall_back, display_id);
			if (strcmp(display_config_info[display_id]->state_machine[state_index]->state_type,
                        "unstable") == SUCCESS) {
				LOG_PRINT(INFO,"fall back state is unstable\n");
				ret_val = DISP_JSON_ERR_UNSTABLE_FALL_BACK_STATE;
				goto ret;
			}
		}
	}

ret:
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * get_state_index: Get index of particular state
 * @param: state   given state
 * @return_value:   Returns 0 on success,else -1 on failure
 */

int get_state_index(char* state, int display_id)
{
	FUNCTION_START();
	int i = 0;
	int ret_val = 0;
	for ( i = 0; i< num_of_states; i++) {
		if (strcmp(display_config_info[display_id]->state_machine[i]->state, state) == SUCCESS) {
			ret_val = i;
		}
	}
end:
	FUNCTION_END(ret_val);
	return ret_val;
}


int json_parsing_init(st_config_params *config_params)
{
	FUNCTION_START();
	int i =0;
	int display_id =0;
	int ret_val =SUCCESS;
	pthread_t tid[5];
	char thread_name[THREAD_NAME_LEN];
	
	display_config_info = (st_display_config**) malloc(sizeof(st_display_config*) * config_params->no_of_disp_config);
	for (i = 0; i < config_params->no_of_disp_config ; i++) {
		display_config_info[i] = (st_display_config*) malloc(sizeof(st_display_config));
		memset(display_config_info[i],0x00,sizeof(st_display_config));
	}
	for (i = 0; i < config_params->no_of_disp_config ; i++) {

			ret_val = display_parse_json(config_params->display_path[i],display_id);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR,"Parsing of Display Config File failed\n");
				ret_val = RD_CONF_ERR_DISP_CONF_FILE_PARSE_FAIL;
				goto cleanup;
			}
			ret_val = validate_json_data(display_id);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR,"validate_json_data failed\n");
				ret_val =  RD_CONF_ERR_JSON_DATA_INVALID;
				goto cleanup;
			}

			sm_state_transition_init(display_id);

			//thread_args[display_id]->display_id = i;
			//thread_args[display_id]->pos = 1;
			////if( pthread_create(&tid[i], NULL, sm_state_machine_thread, thread_args[i]) 
			////										!= INIT_VAL )
			////	LOG_PRINT(ERROR,"Thread Creation Failed\n");
			////pthread_setname_np(tid[i], "State_machine_thread");
			display_id++;
			
	}
cleanup:
	FUNCTION_END(ret_val);
	return ret_val;
}

int json_encoder(char* request, char* request_buf, char *reply, char* reply_buf, char* out_buf)
{
	int ret_val = SUCCESS;
	char* token = NULL;
	char strings[10][256] = {0} ;
	char key[256] ={0};
	char value[256] = {0};
	int  i =0;
	json_object * jobjRespBlockTop = json_object_new_object();
	json_object * jobjRespBlock = json_object_new_object();
	json_object * jobjReplyBlock = json_object_new_object();

	if((request == NULL) ||(request_buf == NULL) ||(out_buf == NULL) ){
		LOG_PRINT(ERROR,"request/request_buf is empty");
		ret_val = DISP_JSON_ERR_BUFF_NULL;
		goto end;
	}

	token = strtok(request_buf,"\t");
	while( token != NULL ) {
		strcpy(strings[i++], token);
		token = strtok(NULL, "\t");
	}
	for(int j = 0; j < i; j++)
	{
		splitString(&strings[j][0], &key[0], &value[0]);
		if((value[0] >= 0x30) && (value[0]<= 0x39)){
			json_object_object_add(jobjRespBlock, &key[0], json_object_new_int(atoi( &value[0])));
		}
		else{
			json_object_object_add(jobjRespBlock, &key[0], json_object_new_string( &value[0]));
		}
	}
	json_object *jarrayResp = json_object_new_array();

	if((reply == NULL) ||(reply_buf == NULL) ){
		LOG_PRINT(ERROR,"reply/reply_buf is empty");
		ret_val = DISP_JSON_ERR_BUFF_NULL;
		goto copy;
	}

	i =0;
	token = strtok(reply_buf,"\t");
	while( token != NULL ) {
		strcpy(strings[i++], token);
		token = strtok(NULL, "\t");
	}
	for(int j = 0; j < i; j++)
	{
		splitString(&strings[j][0], &key[0], &value[0]);
		if((value[0] >= 0x30) && (value[0]<= 0x39)){
			json_object_object_add(jobjReplyBlock, &key[0], json_object_new_int(atoi( &value[0])));
		}
		else{
			json_object_object_add(jobjReplyBlock, &key[0], json_object_new_string( &value[0]));
		}
	}

	json_object *jarrayReply = json_object_new_array();
	json_object_array_add(jarrayReply,jobjReplyBlock);

	json_object_object_add(jobjRespBlock, reply, jarrayReply);

copy:

	json_object_array_add(jarrayResp,jobjRespBlock);
	json_object_object_add(jobjRespBlockTop,request, jarrayResp);
	strcpy(out_buf, json_object_to_json_string(jobjRespBlockTop));
end:
	return ret_val;
}
int splitString(char *inputStr, char*key, char* value)
{
	char *ch = NULL;
	ch = strtok(inputStr, ":");
	 while (ch != NULL) {
		 strcpy(&key[0], ch);
		 ch = strtok(NULL, " :");
		  strcpy(&value[0], ch);
		  break;
	 }
	 return 0;
}
