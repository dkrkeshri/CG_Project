#ifndef _DISPLAYPARSEJSON_H_
#define _DISPLAYPARSEJSON_H_

/***************************************************************************** 
HEADER FILES
 ****************************************************************************/
#include "../inc/definations.h"

typedef struct display_config {
	int  display_id;
	char display_name[BUF_SIZE];
	int  display_part_number;
	char *display_components[BUF_SIZE];
	char connectivity_type[BUF_SIZE];
	char default_state[BUF_SIZE];
	st_dspl_state_mac *state_machine[BUF_SIZE];
}st_display_config;
	
st_display_config **display_config_info;

/****************************************************************************
 * FUNCTION  PROTOTYPES
 ****************************************************************************/
int display_parse_json( char *filepath, int display_id);
int validate_json_data(int display_id);
int get_state_index(char * state, int display_id);
int json_parsing_init(st_config_params *);
int json_encoder(char* request, char* request_buf, char *reply, char* reply_buf, char* out_buf);
int splitString(char *inputStr, char*key, char* value);
#endif /*_DISPLAYPARSEJSON_H_*/

