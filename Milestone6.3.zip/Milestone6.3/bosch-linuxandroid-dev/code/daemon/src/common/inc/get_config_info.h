 /**

  * @file       get_config_info.h

  * @brief      Get Config Header File.

  *

  * @author     external.Veerendra.Kamsali@in.bosch.com

  *

  * @copyright (c) 2022 Robert Bosch GmbH, Hildesheim

  */ 
 #ifndef __GET_CONFIG__
 #define __GET_CONFIG__
 
 #include "../../logging/inc/loggerDaemon.h"
 #include "../../logging/inc/logger_internal.h"
 
/****************************************************************************
 * STRUCTURE DECLARATION
 ****************************************************************************/
typedef struct config_params {
	st_log_config *log_config;
	int no_of_disp_config;
	char *display_path[BUF_SIZE];
}st_config_params;


/****************************************************************************
 * FUNCTION  PROTOTYPES
 ****************************************************************************/
char * string_copy( const char *src, char *dest);
int  get_config_info(int argc, char *argv[], st_config_params *config_params);
int  clear_config_info(st_logger *log_params);
int  read_config_file(st_config_params *config_params, 
                      char *config_file_path);
extern int  trim_leading_and_trailing_spaces(char *str);
int  process_cmd_line_args(int no_of_args, char *argv[], 
              st_log_config *config_params, char *config_file_path);
int  check_log_level_param(const char *config_log_level);
int  check_state_param(const char *config_state);
int  check_logsink_param(int config_log_sink);
int check_logfile_path_param(const char *config_path);
int  errChk_process_cmd_line_args(int no_of_args, char *argv[],
            st_log_config *config_params, char *config_file_path);
int  errChk_read_config_file(st_config_params *config_params, 
                            char *config_file_path);
int  open_log_file(void);
int  link_log_sink(void);
int check_disp_config_path(const char *disp_config_path);
#endif /*__GET_CONFIG__ */