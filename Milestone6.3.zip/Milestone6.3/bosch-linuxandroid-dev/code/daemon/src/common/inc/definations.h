/**

  * @file       loggerDaemon.h

  * @brief      Logging Module Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#ifndef _DEFINATIONS_H_
#define _DEFINATIONS_H_
/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <tcl8.6/tcl.h>
#include <sys/time.h>
#include <stdbool.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <sys/syscall.h>
#define gettid() ((pid_t)syscall(SYS_gettid))

/****************************************************************************
 * MACROS
 ****************************************************************************/
#define BUF_SIZE			256
#define MSG_SIZE        		2048

#define LOG_SINK_CONSOLE		0
#define LOG_SINK_FILE			1


#define REQ_SIZE 6
#define CLIENT_REQ_SIZE 5
#define DISPLAY_STATE 3
#define ARG_REQ_SIZE 6

#define TIMER_START 1
#define TIMER_STOP 0

#define NO_TIMEOUT -1

#define SESS_DEF_ID -1
#define REQ_DEF_ID   -1
#define TIMEOT_DEF_VAL -1
#define DIS_DEF_ID -1

#define STATE_MACHINE_SIZE 5
#define THREAD_NAME_LEN 32

#define DISPLAY_ENUMERATE 					"enumerate-displays"
#define EVENT_SUBSCRIBE                                          "eventsubscribe"
#define DISPLAY_INFO 							"display-info"
#define DISPLAY_SET_TOUCH_STATE				"display-set-touch-state"
#define DISPLAY_GET_TOUCH_STATE				"display-get-touch-state"
#define DISPLAY_EXECUTE_QUERY				"display-execute-query"
#define MONITOR_GET_STATE					"monitor-get-state"
#define DISPLAY_SET_FSM_STATE				"display-set-fsm-state"
#define DISPLAY_GET_FSM_STATE				"display-get-fsm-state"
#define  ASYNC_MODE							"asynchronous"
#define REQ_COMPLETE						"request completed"
#define QUERY_PIXEL_SWAP_WORK_AROUND		"pixel_swap_workaround"

#define RESPONSE								"response"
#define REPLY								"reply"


/****************************************************************************
 * STRUCTURE DECLARATION
 ****************************************************************************/

typedef enum enum_event{
	INVALID=-1, CONNECTED=1, AWAITING=2, SUSPENDED=4
}et_event_enum;

typedef struct event_map
{
	char *event_str;
	et_event_enum event_enum;
}st_event_map;

typedef struct display_state_machine {
	char state[BUF_SIZE];
	char actions[BUF_SIZE];
	char *next_state[4];
	char fall_back[BUF_SIZE];
	char state_type[BUF_SIZE];
	int state_id;
}st_dspl_state_mac;

st_dspl_state_mac state_machine_info;

typedef struct notify_event_msg
{
	int socket_number;
	char message_buffer[MSG_SIZE];
	sem_t notify_sem;
	pthread_mutex_t notify_lock;
	struct notify_event_msg *next; 
}st_notify_msg;

typedef struct client_info{
	int  session_id;
	int  request_id;
	int  display_id;
	char command[BUF_SIZE];
	char arg_mode[BUF_SIZE];
	int  arg_timeout;
	char arg_event_type[BUF_SIZE];
	char arg_enable[BUF_SIZE];
	char query[BUF_SIZE];
	char arg_monitor[BUF_SIZE];
	char arg_method[BUF_SIZE];
	char arg_target_state[BUF_SIZE];
	char client_address[BUF_SIZE];
	int socket_fd;
	volatile int disconnect_thread;
	int max_display_count;
}st_clientinfo;


typedef struct event_msg{
int recieved_event_type;
int display_ID;
char msg_buf[2048];
struct event_msg* next;
}st_event_msg;

typedef struct client_socket{
int  subscribed_event_type;
int display_ID;
int socket_number;
st_notify_msg *notify;
struct client_socket *next;
}st_client_socket;

typedef struct event_split{
st_client_socket *root;
pthread_mutex_t event_process_lock;
sem_t event_notify;
st_event_msg* event_msg;
}st_event_split;

 typedef struct sm_thread_args {
	st_clientinfo *dispathcer_info;
	int display_id;
	sem_t first_req;
	sem_t req_complete;
	int pos;
	sem_t next_req;
	int start;
	int client_socket;
	char curr_state[BUF_SIZE];
	struct sm_thread_args *next;
	st_notify_msg *notify_msg;
	st_event_split *event_split;
}st_sm_thread_args;

typedef struct timer_args 
{
	struct timeval t0;
	sem_t start_timer;
	st_clientinfo *client_info;
	int client_socket;
	st_notify_msg *notify_msg;
}st_timer_args;

typedef struct client_args
{
	int client_socket;
	char client_addr[BUF_SIZE];
	int no_of_disp;
	st_sm_thread_args **thread_args;
}st_client_args;

typedef struct socket_node {
	int socket;
	int event_type;
	struct socket_node *next;
}st_sock_node;

struct dispatcher_parse {
	st_sm_thread_args **thread_args;
	st_clientinfo *client_info_array;
	int no_of_disp_config_files;
	pthread_mutex_t lock;
};


/****************************************************************************
 * FUNCTION  PROTOTYPES
 ****************************************************************************/
void hal_layer_print(char  *);
int tcl_init();
void init_backend (void);
int tcl_proc(char * state, int display_id);
int tcl_proc_call(char *proc ,char *struct_var);

#endif /* _DEFINATIONS_H_ */
