#ifndef _STATEMACHINE_H_
#define _STATEMACHINE_H_

/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
 #include <pthread.h>
 #include "../../common/inc/definations.h"
 
/***************************************************************************** TYPEDEF
 ****************************************************************************/
#define NO_OF_VERTEX 4

typedef struct sm_graph_t
{
    int vertex;
    struct sm_graph_t *adj_vertex;
}st_sm_graph;

typedef struct sm_path_t
{
	int src;
	int dest;	
	struct sm_path_t *next;
}st_sm_path;

typedef struct queue_t
{
	st_sm_path *front;
	st_sm_path *rear;	
}st_queue;

typedef struct sm_edges_t
{
	int src;
	int dest;	
}st_sm_edges;

typedef struct state_transition_t 
{
	char data[BUF_SIZE];
	struct state_transition_t  *next_node;
}st_state_transition;

typedef struct sm_table_array {
	st_sm_graph sm_table[NO_OF_VERTEX];
}st_sm_table_array;
 
/****************************************************************************
 * FUNCTION PROTOTYPES
 ****************************************************************************/
void *sm_state_machine_thread(void *args);
int sm_tcl_proc(char * state, int display_id, int* state_ret_val);
int sm_assign_fallback_state(struct state_transition_t *st_state_transition, int display_id, char*, char*);
int sm_state_machine_init(st_clientinfo *dispathcer_info,st_sm_thread_args **);
void sm_state_transition_init(int display_id);
void sm_create_table(int display_id);
void sm_show_table( int display_id);
void sm_enqueue(struct sm_path_t);
int sm_get_adj_vertex(int ,int *,int *,int);
int sm_dequeue( struct sm_edges_t *);
void sm_disp_queue(void);
int sm_create_transition_path(char *,char *,int display_id);
void sm_init_path_array(int src);
int sm_update_path_array(int,int);
void sm_display_path_array();
int sm_path_exist(int);
int sm_find_shortest_path(int ,int,int);
void sm_deinit_path_transition();
struct state_transition_t * sm_get_state_trans_path();
int errCheck_state_machine(int,int);
int sm_get_state_id(char *state,int display_id);
char* sm_get_state_name(int val,int display_id);
int errChk_state_machine(st_clientinfo *client_request_info);
int disp_parse_event( st_event_split * event_split);


#endif /* _STATEMACHINE_H_ */
