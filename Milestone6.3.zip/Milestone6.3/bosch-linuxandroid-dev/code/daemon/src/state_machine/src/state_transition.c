/**
  * @file	  state_transition.c

  * @brief	 state transition function dest find the path
  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include "../../common/inc/get_config_info.h"
#include "../../common/inc/displayparsejson.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/error.h"
#include "../inc/statemachine.h"

st_sm_edges *path_array = NULL;
st_queue sm_queue = {NULL,NULL};
st_sm_table_array sm_table_arr[NO_OF_VERTEX];
st_state_transition *head = NULL,*state_transition = NULL;
extern int num_of_states;

/* sm_state_transition_init() - Function will create state machine table
 * @param - void
 * return-type - void
 */
void sm_state_transition_init(int display_id)
{
	FUNCTION_START();
	sm_create_table(display_id);
	//sm_show_table(display_id);
	FUNCTION_END(0);
}

/* create_sm_table  - function will create state machine table
 * @param- void
 * return-type - void
 */
void sm_create_table(int display_id)
{
	FUNCTION_START();
	int vertex_num = 0;
	int cnt = 0;
	int adj_ver  = 0;
	int status ;
	st_sm_graph *new_adj = NULL;
	st_sm_graph *adj = NULL;
	
	LOG_PRINT(DEBUG,"creating state machine table\n");
	for (vertex_num = 0;vertex_num < num_of_states ;vertex_num++) {
		cnt = 0;
		sm_table_arr[display_id].sm_table[vertex_num].vertex = sm_get_state_id(display_config_info[display_id]->state_machine[vertex_num]->state,display_id);
		adj = &sm_table_arr[display_id].sm_table[vertex_num];
		while (display_config_info[display_id]->state_machine[vertex_num]->next_state[cnt] != NULL) {
			new_adj = (st_sm_graph *)malloc(sizeof(st_sm_graph));
			adj_ver  = sm_get_state_id(display_config_info[display_id]->state_machine[vertex_num]->next_state[cnt],display_id);
			new_adj->vertex = adj_ver;
			new_adj->adj_vertex = NULL;
			adj->adj_vertex = new_adj;
			adj = new_adj;
			++cnt;
		}
	}
	FUNCTION_END(0);
}

/* sm_show_table  - function will show state machine table
 * @param- void
 * return-type - void
 */
void sm_show_table(int display_id)
{
	FUNCTION_START();
	int cnt = 0;
	int adj_ver  = 0;
	st_sm_graph *new_adj = NULL;
	st_sm_graph *adj = NULL;
	
	LOG_PRINT(DEBUG,"state machine table\n");
	for (cnt = 0;cnt < num_of_states ;cnt++) {
		adj = sm_table_arr[display_id].sm_table[cnt].adj_vertex;
		while(adj != NULL) {
			  adj = adj->adj_vertex;
		}
	}
	new_adj = NULL;
	adj = NULL;
	FUNCTION_END(0);
	
}
/* sm_get_adj_vertex  - function to get adject vertex
 * @param- int vertex 
 * @param - int adj_cnt
 * @param - int adj_arr
 * return-type - 0 on success errorno on error
 */
int sm_get_adj_vertex(int vertex,int *adj_cnt,int *adj_arr,int display_id)
{
	FUNCTION_START();
	st_sm_graph *adj = NULL;
	int cnt = 0;
	int ret_val = SUCCESS;
	
	if(vertex <= 0) {
		LOG_PRINT(ERROR,"Invaid vertex %d \n", vertex);
		ret_val = ST_MAC_ERR_INV_VER;
		return ret_val;
	}
	adj = sm_table_arr[display_id].sm_table[vertex-1].adj_vertex;
	LOG_PRINT(DEBUG,"getting adject vertex\n");
	while(adj != NULL) {
		  adj_arr[cnt] = adj->vertex;
		  adj = adj->adj_vertex;
		  ++cnt;
	}
	*adj_cnt = cnt;
	FUNCTION_END(ret_val);
	return ret_val;
}

/* sm_enqueue  - function to push the path in the queue
 * @param- path
 * return-type - void
 */

void sm_enqueue(st_sm_path path)
{
	FUNCTION_START();
	st_sm_path *newNode;
	
	newNode = (st_sm_path*)malloc(sizeof(st_sm_path));
	
	newNode->src  = path.src;
	newNode->dest      = path.dest;
	newNode -> next = NULL;
	
	if (sm_queue.front == NULL) {	
		sm_queue.front = newNode;
		sm_queue.rear  = newNode;
	} else {
		sm_queue.rear -> next = newNode;
		sm_queue.rear  = newNode;
	}
	FUNCTION_END(0);	
}

/* sm_dequeue  - function to pop the path src queue
 * @param- edges
 * return-type -  0 on success errorcode on error
 */
int sm_dequeue( st_sm_edges *edges )
{
	FUNCTION_START();
	int ret_val=SUCCESS;
	if (sm_queue.front  == NULL) {
		ret_val = ERR_VAL;
		goto end;
	} else {
		st_sm_path *front = sm_queue.front ;
		edges->src = front->src;
		edges->dest =  front->dest;
		sm_queue.front    = sm_queue.front -> next;
		free(front);
		ret_val = 0;
		goto end;
	}
end:	
		FUNCTION_END(ret_val);
		return ret_val;
	
}

/* sm_disp_queue  - function to display queue
 * @param- void
 * return-type - void
 */
void sm_disp_queue(void)
{
	FUNCTION_START();
	if (sm_queue.front  == NULL) {
	} else {
		st_sm_path *front = sm_queue.front;
		while(front != NULL) {
			front = front -> next;
		}
	}
	FUNCTION_END(0);
}

/* sm_create_transition_path  - function to find the path dest the target state
 * @param- src
 * @param - dest
 * return-type - 0 on success errorcode on failure
 */
int sm_create_transition_path(char *src_str,char  *dest_str,int display_id)
{
	FUNCTION_START();
	int src   = sm_get_state_id(src_str,display_id);
	int dest = sm_get_state_id(dest_str,display_id);
	st_sm_path path;
	st_sm_edges edges;
	int state = src;	
	int adj_arr[5];
	int adj_cnt = 0;
	int ret_val = SUCCESS;
	

	if (ERR_VAL == errCheck_state_machine(src,dest)) {
		LOG_PRINT(ERROR,"Source and destination are invalid \n");
		ret_val = ST_MAC_ERR_INV_SRC_DEST;
		return ret_val;
	}

	path_array 
      = (st_sm_edges *) calloc(num_of_states ,sizeof(st_sm_edges));

	sm_init_path_array(src);
	
	while(1) {
		sm_get_adj_vertex(state,&adj_cnt,&adj_arr[0],display_id);

		for ( int i = 0;i<adj_cnt;i++) {
			edges.src = state;
			edges.dest = adj_arr[i];
							
			if (sm_path_exist(edges.dest) == 0) {
				path.src = edges.src;
				path.dest = edges.dest;
				sm_enqueue(path);
			}
		}

		if (0 == sm_dequeue(&edges)) {
			while (ERR_VAL == sm_update_path_array(edges.dest,edges.src)) {
				if (ERR_VAL == sm_dequeue(&edges)) {
					break;
				}
			}
			state = edges.dest;
			continue;
		} else
			break;
	}

	//sm_display_path_array();

	LOG_PRINT(DEBUG,"Checking the shortest path\n");
	if (sm_find_shortest_path(src,dest,display_id) != SUCCESS) {
		ret_val = ST_MAC_ERR_PATH_NOT_FOUND;
		goto clean;
	}

clean:
	free(path_array);
	path_array = NULL;
	FUNCTION_END(ret_val);
	return ret_val;

}

/* sm_init_path_array  - function to initialize path array
 * @param- src
 * return-type - void
 */

void sm_init_path_array(int src)
{
	FUNCTION_START();
	int i = 0;
	for (i = 0;i<num_of_states;i++) {
		if (i == (src-1)) {
			path_array[i].dest = -1;
			path_array[i].src = -1;
		} else {
			path_array[i].dest = i+1;
		}
	}
	FUNCTION_END(0);
}

/* sm_update_path_array  - function to update the path array 
 * @param- src
 * @param - dest
 * return-type - 0 on success - on failure
 */
int sm_update_path_array(int dest,int src)
{
	FUNCTION_START();
	int ret_val = SUCCESS;
	if (sm_path_exist(dest) == 0) {
			path_array[dest-1].src = src;
			goto end;
	} 
	ret_val = ST_MAC_ERR_UPD_PTH_ARR;

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/* sm_display_path_array  - function to display the path array 
 * @param- void
 * return-type: void
 */

void sm_display_path_array()
{
	FUNCTION_START();
	
	for (int i = 0; i<num_of_states; i++) {
	}
	FUNCTION_END(0);
}

/* sm_path_exist  - function to check path exist or not
 * @param- path
 * return-type - 1 on success  0 on failure
 */

int sm_path_exist(int path)
{
	FUNCTION_START();
	int ret_val=SUCCESS;
	if (path_array[path-1].src == 0) {
		ret_val = 0;
		goto end;
	}else if(path_array[path-1].src > 0) {
		ret_val = ERR_VAL;
		goto end;
	}else{
		ret_val =  ERR_VAL;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/* find_shortest_path  - function to find the shortest path
 * @param- src
 * @param - dest
 * return-type : 1 on success  errorcode on failure
 */

int sm_find_shortest_path(int src ,int dest,int display_id)
{
	FUNCTION_START();
	int cnt = 0;
	int path_to_travel[10] = {0,};
	int ret_val = SUCCESS;
	st_state_transition  *curr_node = NULL,*new_node = NULL,*state_node = NULL;
	
	sm_deinit_path_transition();
	LOG_PRINT(DEBUG,"returning from sm_deinit_path_transition\n");
	if ((path_array[dest-1].dest <= 0) 
        || (path_array[dest-1].src <= 0)) {
		ret_val = ST_MAC_ERR_SHORT_PATH;
		goto end;
	} else {	
			while (path_array[dest-1].src != -1) {				
				path_to_travel[cnt] = path_array[dest-1].dest;
				dest = path_array[dest-1].src;
				cnt++;
			}
			 path_to_travel[cnt] = src;

			if (cnt != 0) {
				for (int i = cnt;i >= 0; i--) {
					if(head == NULL) {
						head = (st_state_transition *) \
                                malloc(sizeof(st_state_transition));
						// head->data = path_to_travel[i];
						strcpy(head->data,sm_get_state_name(path_to_travel[i],display_id));
						head->next_node = NULL;
						curr_node = head;
					} else {
						new_node = (st_state_transition *) \
                                    malloc(sizeof(st_state_transition ));
						// new_node->data = path_to_travel[i];
						strcpy(new_node->data,sm_get_state_name(path_to_travel[i],display_id));
						new_node->next_node = NULL;
						curr_node->next_node = new_node;
						curr_node = new_node;
					}
				}
			}
			LOG_PRINT(INFO, "Linked List path ==>");
			
			state_node = head;
			while (state_node != NULL) {
				LOG_PRINT(INFO, "%s ",state_node->data);
				state_node = state_node->next_node;
			}
			goto end;
	}
end:
		FUNCTION_END(ret_val);
	return ret_val;
}

/* sm_deinit_path_transition  - function to deinit the path 
 * @param- void
 * return-type - void
 */
void sm_deinit_path_transition(void)
{
	FUNCTION_START();
	st_state_transition *state_node = NULL,*next = NULL;
	state_node = head;
	
	while (state_node != NULL ) {
		if (state_node->next_node != NULL) {
			next = state_node->next_node;
		}
		free(state_node);
		state_node = next;
		next = NULL;
	}
	head = NULL;
	state_node = NULL ;
	next = NULL;
	FUNCTION_END(0);
}

/* sm_get_state_trans_path  - function to get the linked list of path
 * @param- void
 * return-type - st_state_transition
 */
st_state_transition * sm_get_state_trans_path()
{
	return head;
}

/* errCheck_state_machine  - function to check state machine
 * @param- src
 * @param - dest
 * return-type - 0 on success  errorcode on failure
 */
int errCheck_state_machine(int src,int dest)
{
	FUNCTION_START();
	int ret_val = 0;
	
	if ((src <=0 ) || (dest <= 0 ) || (src == dest)) {
		ret_val = ERR_VAL;
		goto end;
	}
	
end:
	FUNCTION_END(ret_val);
	return ret_val;
}

/* sm_get_state_id  - function to get state id
 * @param- state
 * @param - display-id
 * return-type - state id on success  0 on failure
 */

int sm_get_state_id(char *state,int display_id)
{
		FUNCTION_START();
		int state_index = 0;
		int ret_val = 0;
		state_index = get_state_index(state,display_id);
		
		if(state_index != ERR_VAL)
		{
			ret_val = display_config_info[display_id]->state_machine[state_index]->state_id;
			goto end;
		}
		ret_val =0;
end:
		FUNCTION_END(ret_val);
		return ret_val;
}

/* sm_get_state_name  - function to state name
 * @param- val
 * @param - display-id
 * return-type - state_name  on success  "\0" on failure
 */
char* sm_get_state_name(int val,int display_id)
{
		FUNCTION_START();
		char *ret_val;
		if((val > 0) && (val <= num_of_states ))
		{
			ret_val = display_config_info[display_id]->state_machine[val-1]->state;
			goto end;
		}
		
		ret_val = "\0";
		
end:
	FUNCTION_END(ret_val);
	return ret_val;
}

