/**
  * @file	  state_machine.c

  * @brief	 Identify the state machine of the requests

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include "../../common/inc/get_config_info.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/error.h"
#include "../../common/inc/displayparsejson.h"
#include "../../common/inc/definations.h"
#include "../../session_registry/inc/sessionregistry.h"
#include "../inc/statemachine.h"
#include "../../dispatcher/inc/dispatcher.h"
#include "../../server/inc/server.h"
//#include "../../adapters/sysfs/sysfs_adapter.h"
//extern st_sm_thread_args **thread_args;

/* state_machine   - State machine function
 * @param: dispathcer_info	- Info from dispathcer
 * return value : 0 on success , errorcode on failure
 */
void *sm_state_machine_thread(void *args)
{
	FUNCTION_START();
	st_sm_thread_args *thread_args = (st_sm_thread_args *)args;
	int display_id = thread_args->display_id;
	int value;
	int ret_val = SUCCESS;
	int state_index = 0;
	int j = 0;
	int client_socket;
	static char def_state[BUF_SIZE];
	char tar_state[BUF_SIZE];
	char prev_state[BUF_SIZE];
	st_session_registry_ht **session_hash_table;
	st_session_registry_ht **session_table;
	st_clientinfo *dispathcer_info = (st_clientinfo*)malloc(sizeof(st_clientinfo));
	st_state_transition *st_state_transition = NULL;
	pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
	char server_message[MSG_SIZE]; 
	unsigned long *ptr = malloc(256);
	memset(dispathcer_info,0x00,sizeof(st_clientinfo));
	strcpy(thread_args->curr_state, display_config_info[display_id]->default_state);
	sem_init(&thread_args->first_req,0,0);
	sem_init(&thread_args->next_req,0,0); 
	sem_init(&thread_args->req_complete,0,0);
	st_notify_msg * notify_msg ;
	st_notify_msg * tmp ;
	st_event_split * event_split ;
	pthread_t disp_tid;
	char thread_name[16];
	char state[512];
	st_event_split * event_split_msg ;
	char request_data[MSG_SIZE];
	char reply_data[MSG_SIZE];

	notify_msg = (thread_args->notify_msg);
	event_split = (thread_args->event_split);

	if( sem_wait(&thread_args->first_req) != 0) {
		LOG_PRINT(ERROR, "sem wait failed\n");
		ret_val = ST_MAC_ERR_SEM_FAIL;
		goto bat;
	}

	LOG_PRINT(DEBUG,"display_id=%d sem wait Successful\n",display_id);
	memset(tar_state,0x00,sizeof(tar_state));
	memset(prev_state,0x00,sizeof(prev_state));

	st_sm_thread_args *request = thread_args;
	int state_ret_val = SUCCESS;
	char command[BUF_SIZE] ={0};

	do {
		pthread_mutex_lock(&lock);
		while(request != NULL) {
			dispathcer_info = request->dispathcer_info;
			client_socket = dispathcer_info->socket_fd;
			state_index = get_state_index(dispathcer_info->arg_target_state,display_id);
			if (strcmp(display_config_info[display_id]->state_machine[state_index]->state_type,
                "unstable") == 0) {
					ret_val = ST_MAC_ERR_UNSTABLE_STATE;
					LOG_PRINT(ERROR,"Requested state is unstable\n");
					goto bat;
			}
			LOG_PRINT(ERROR,"display_id=%d tid=%d\n",display_id,gettid());
			strcpy(tar_state,dispathcer_info->arg_target_state);
			state_ret_val = SUCCESS;
			memset(&command[0], 0x00, BUF_SIZE);
			if (/*(strcmp(dispathcer_info->command,DISPLAY_SET_FSM_STATE) == 0) || */
				/* (strcmp(dispathcer_info->command,DISPLAY_SET_TOUCH_STATE) == 0) || */
				(strcmp(dispathcer_info->command,DISPLAY_GET_TOUCH_STATE) == 0) ||
				(strcmp(dispathcer_info->command,DISPLAY_EXECUTE_QUERY) == 0)  ||
				(strcmp(dispathcer_info->command,"monitors-get-state") == 0) ){
					strcpy(command, dispathcer_info->command);
					if(strcmp(dispathcer_info->command,DISPLAY_EXECUTE_QUERY) == 0)
					{
						LOG_PRINT(INFO, "Received query is%s \n",dispathcer_info->query);
						strcpy(command, dispathcer_info->query);
					}
					ret_val = sm_tcl_proc(command,display_id, &state_ret_val);
					goto bat;
				}
			else if ( (strcmp(dispathcer_info->command,DISPLAY_SET_FSM_STATE) == 0) ||
				(strcmp(dispathcer_info->command,DISPLAY_SET_TOUCH_STATE) == 0) ) {
					strcpy(command, dispathcer_info->command);
					ret_val = sm_tcl_proc(command,display_id, &state_ret_val);
				}

			if ( j == 0) {
				strcpy(def_state, display_config_info[display_id]->default_state);
				strcpy(prev_state ,def_state);
				j++;
			}
			state_index = get_state_index(tar_state,display_id);
			if ( strcmp(prev_state,tar_state) == 0) {
				LOG_PRINT(ERROR,"display_id=%d tid=%d\n",display_id,gettid());
				LOG_PRINT(INFO, "We are already in %s state\n",tar_state);
				goto bat;
			} else {
				ret_val = sm_create_transition_path(prev_state, tar_state,display_id);
				if( ret_val != SUCCESS) {
					LOG_PRINT(ERROR,"create_path failed path not found\n");
					goto bat;
				}
			}
			st_state_transition = sm_get_state_trans_path(); 
			while(st_state_transition != NULL && strcmp(prev_state,tar_state) != 0) {
				if ((strcmp(def_state, st_state_transition->data) == 0) 
						|| (strcmp(prev_state, st_state_transition->data) != 0)) {
						LOG_PRINT(INFO, "Target State: %s \n", st_state_transition->data);

						ret_val = sm_tcl_proc(st_state_transition->data,display_id, &state_ret_val);
						if (ret_val != SUCCESS) {
							LOG_PRINT(ERROR," tcl_proc failed\n");
							if (sm_assign_fallback_state(st_state_transition,display_id,prev_state,tar_state) 
									!= SUCCESS) {
								LOG_PRINT(ERROR,"assign_fallback_state failed\n");
								goto bat;
							}
							continue;
						}
						strcpy(prev_state,st_state_transition->data);
						strcpy(thread_args->curr_state, prev_state);
						if(strcmp(st_state_transition->data,def_state) == 0) {
							strcpy(def_state, "\0");
						}
				}
				st_state_transition = st_state_transition->next_node;
			}
bat:
	memset(server_message, 0x00, 	MSG_SIZE);
	char buff[MSG_SIZE] = {0};
	memset(&buff[0], 0x00, MSG_SIZE);
	memset(&request_data[0], 0x00, MSG_SIZE);
	memset(&reply_data[0], 0x00, MSG_SIZE);
	char error_buff[64] = {0};
	strcpy(&error_buff[0], "EFAULT");
	if (ret_val != SUCCESS) {
		sprintf(request_data, "session-id:%d\trequest-id:%d\tdisplay-id:%d\tresult:",dispathcer_info->session_id, dispathcer_info->request_id, dispathcer_info->display_id);
		 if(strcmp(dispathcer_info->command,DISPLAY_GET_TOUCH_STATE) == 0){
			strcpy(&error_buff[0], "EPARAM");
		 }
		 strcat(&request_data[0],&error_buff[0]);

		if(strcmp(dispathcer_info->command,DISPLAY_SET_FSM_STATE) == 0){
			sprintf(&reply_data[0], "error: failed to set fm state with error code:%d", ret_val);
		}
		else if(strcmp(dispathcer_info->command,DISPLAY_SET_TOUCH_STATE) == 0){
			sprintf(&reply_data[0], "error:failed to set touch state with error code:%d", ret_val);
		}
		else if(strcmp(dispathcer_info->command,DISPLAY_GET_TOUCH_STATE) == 0){
			sprintf(&reply_data[0], " error:failed to get touch state with error code:%d", ret_val);
		}
		else if (strcmp(dispathcer_info->command,DISPLAY_EXECUTE_QUERY) == 0){
			if(strcmp(dispathcer_info->query, QUERY_PIXEL_SWAP_WORK_AROUND) == 0){
				sprintf(&reply_data[0], "error:failed  %s query  with error code:%d", QUERY_PIXEL_SWAP_WORK_AROUND,ret_val);
			}
		}

	} else {
		sprintf(request_data, "session-id:%d\trequest-id:%d\tdisplay-id:%d\tresult: OK",
		dispathcer_info->session_id, dispathcer_info->request_id, dispathcer_info->display_id);
		//sprintf(server_message,"Response: \n session-id:%d \n request-id:%d \n display-id:%d \n result: OK \n",
		//dispathcer_info->session_id, dispathcer_info->request_id, dispathcer_info->display_id);
		if(strcmp(dispathcer_info->command,DISPLAY_GET_TOUCH_STATE) == 0){
			sprintf(&reply_data[0], "touch-status:active\ttouch-driver-status:probed\ttouch-driver_relevence:%s",state_ret_val?"applicable":"not applicable");
		}
		else if (strcmp(dispathcer_info->command,DISPLAY_EXECUTE_QUERY) == 0){
			if(strcmp(dispathcer_info->query, QUERY_PIXEL_SWAP_WORK_AROUND) == 0){
				sprintf(&reply_data[0], " %s: query exeuted",QUERY_PIXEL_SWAP_WORK_AROUND);
			}
		}
	}
	json_encoder(RESPONSE, &request_data[0], REPLY,&reply_data[0],&server_message[0]);
	LOG_PRINT(INFO, "Msg to Client: %s", server_message);
	/* sending Message to Client */
	tmp = notify_msg ;
	while (tmp != NULL){
		if(tmp->socket_number == client_socket )
		{
			pthread_mutex_lock(&tmp->notify_lock);
			memset(tmp->message_buffer,0x00,sizeof(2048));
			strcpy(tmp->message_buffer,server_message);
			sem_post(&tmp->notify_sem);
			break;
		}
		tmp = tmp ->next ;
	}
	//get_session_table(ptr);
	//session_hash_table = *ptr;

	dispathcer_info->disconnect_thread =TIMER_STOP;
	if(strcmp(prev_state,tar_state) != 0){
		if(event_split->root != NULL){
			pthread_mutex_lock(&event_split->event_process_lock);
			memset(event_split->event_msg->msg_buf,0x00,sizeof(event_split->event_msg->msg_buf));
			int event = map_string_to_event(tar_state);
			event_split->event_msg->recieved_event_type = event ;
			event_split->event_msg->display_ID = display_id;
			sprintf(state,"display_id %d  event %s triggered ",display_id,st_state_transition->data);
			strcpy(event_split->event_msg->msg_buf,state);
			pthread_mutex_unlock(&event_split->event_process_lock);
			disp_parse_event(event_split);
		}
	}
	pthread_mutex_unlock(&lock);
	//st_sm_thread_args *req = thread_args;
	//st_sm_thread_args *delete_req;
	//while(req != NULL) {
	//	req = req->next;
	//}

	//ret_val = ss_reg_deleteSessiontable_entry(session_hash_table, 
	//									   dispathcer_info->session_id, 
	//									   dispathcer_info->request_id,
	//									   dispathcer_info->client_address);
	//	if (ret_val != SUCCESS) {
	//		LOG_PRINT(ERROR, " Client Reqest Deletion Failed\n");
	//	}
	//delete_req = request;

	sem_wait(&thread_args->next_req);
	request = request->next;

	//free(delete_req);
	//delete_req = NULL;
	//pthread_mutex_unlock(&lock);
	}

	}while(1);

end:
	FUNCTION_END(0);
	return NULL;
}

/*
 * sm_tcl_proc: calling tcl proc 
 * @param: char	 client state
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
 
int sm_tcl_proc(char *state, int display_id, int* state_ret_val)
{
	FUNCTION_START();

	int state_index = ERR_VAL;
	char proc_func[BUF_SIZE];
	int ret_val = SUCCESS;
	char *buffer= (char*)malloc(256);
	st_dspl_state_mac *i2c_struct_var;
	int *length = NULL;

	#if 1
	memset(proc_func, 0x00,sizeof(proc_func));
	//here replace theSYSFS_READ_FILE with SYSFS_GPIO_READ for gpio read sysfs
	// create new macro and gpio read sysfs string (in string 1 means read)
	sprintf(proc_func,"%s",SYSFS_GPIO_READ);
	memset(buffer, 0x00,256);
	length = (int*)&buffer[0];
	*length = 40; // here change the value for how many bytes wants to read
	ret_val = tcl_proc_call(proc_func,buffer);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR, "%s failed  \n", proc_func);
		ret_val = ST_MAC_ERR_SYSFS_READ_FAIL;
		goto ret;
	}
	LOG_PRINT(ERROR, "sysfs read data len %d is %s  \n", *length, &buffer[4]);

	//set the capslock brightness ON
	memset(proc_func, 0x00,sizeof(proc_func));
	//here replace theSYSFS_WRITE_FILE with SYSFS _GPIO_WRITE for gpio write sysfs
	// create new macro and gpio write sysfs string (in string 2 means write)
	sprintf(proc_func,"%s",SYSFS_GPIO_WRITE);
	memset(buffer, 0x00,256);
	*length = 1;// here change the length value for how many bytes wants to write
	buffer[4] = 0x31; // set the value to write on sysfs
	ret_val = tcl_proc_call(proc_func,buffer);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR, "%s failed  \n", proc_func);
		ret_val = ST_MAC_ERR_SYSFS_WRITE_FAIL;
		goto ret;
	}
	#endif

	if( (strcmp(state,DISPLAY_SET_FSM_STATE)== 0)||
		(strcmp(state,DISPLAY_SET_TOUCH_STATE) == 0) ||
		(strcmp(state,DISPLAY_GET_TOUCH_STATE) == 0) ||
		(strcmp(state,QUERY_PIXEL_SWAP_WORK_AROUND) == 0)  ||
		(strcmp(state,"monitors-get-state") == 0)) {
			memset(proc_func, 0x00,sizeof(proc_func));
				sprintf(proc_func,"%s",I2C_WORD_ENTRY);
			ret_val = tcl_proc_call(proc_func,NULL);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "%s failed  \n", proc_func);
				ret_val = ST_MAC_ERR_I2C_ENTRY_FAIL;
				goto ret;
			}
		if( (strcmp(state,DISPLAY_SET_FSM_STATE)== 0)  ||
			(strcmp(state,DISPLAY_SET_TOUCH_STATE) == 0) ||
			(strcmp(state,QUERY_PIXEL_SWAP_WORK_AROUND) == 0)){

				memset(proc_func, 0x00,sizeof(proc_func));
				sprintf(proc_func, "%s 0x%x",I2C_DISPLAY_STATE_READ, (0x8000|display_id));
					memset(buffer, 0x00,256);

				ret_val = tcl_proc_call(proc_func,buffer);
				if (ret_val != SUCCESS) {
					LOG_PRINT(ERROR, "%s failed  \n", proc_func);
					ret_val = ST_MAC_ERR_I2C_RD_FAIL;
					goto ret;
				}
				ret_val = buffer[0];

				memset(proc_func, 0x00,sizeof(proc_func));
				sprintf(proc_func, "%s 0x%x",I2C_DISPLAY_STATE_WRITE, (0x8000|display_id));

					memset(buffer, 0x00,256);
				if (strcmp(state,DISPLAY_SET_FSM_STATE) == 0)
					buffer[0] = ret_val | SET_FM_STATE;
				else if(strcmp(state,DISPLAY_SET_TOUCH_STATE) == 0)
					buffer[0] = ret_val | SET_DISPLAY_STATE;
				else if(strcmp(state,QUERY_PIXEL_SWAP_WORK_AROUND) == 0)
					buffer[0] = ret_val | PIXEL_WRAP_AROUND;

				ret_val = tcl_proc_call(proc_func,buffer);
				if (ret_val != SUCCESS) {
					LOG_PRINT(ERROR, "%s failed  \n", proc_func);
					ret_val = ST_MAC_ERR_I2C_WR_FAIL;
					goto ret;
				}
		}
		else if((strcmp(state,DISPLAY_GET_TOUCH_STATE) == 0) ||(strcmp(state,"monitors-get-state") == 0) ){
			memset(proc_func, 0x00,sizeof(proc_func));
			sprintf(proc_func, "%s 0x%x",I2C_DISPLAY_STATE_READ, (0x8000|display_id));
			//sprintf(proc_func, "%s",I2C_DISPLAY_STATE_READ);
			//sprintf(proc_func,  " 0x%x",(0x8000|display_id ));
				memset(buffer, 0x00,256);
			ret_val = tcl_proc_call(proc_func,buffer);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR, "%s failed  \n", proc_func);
				ret_val = ST_MAC_ERR_I2C_RD_FAIL;
				goto ret;
			}
			*state_ret_val = (int)buffer[0];
		}

		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func, "%s",I2C_WORD_EXIT);

		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_EXIT_FAIL;
			goto ret;
		}
	}
    else if ( (strcmp(state,"suspended") == 0) )
	{
		state_index = get_state_index(state,display_id);
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_ENTRY);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_ENTRY_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WRITE);
		memset(buffer, 0x00,256);
		buffer[0] = 0xcc;
		ret_val = tcl_proc_call(proc_func,buffer);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_WR_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_UPDATE);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_UP_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_READ);
		memset(buffer, 0x00,256);
		ret_val = tcl_proc_call(proc_func, buffer);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_RD_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_EXIT);

		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_EXIT_FAIL;
			goto ret;
		}
	}
	else if ((strcmp(state,"awaiting") == 0) ) {
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WORD_ENTRY);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_ENTRY_FAIL;
			goto ret;
		}

		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WORD_WRITE);
		memset(buffer, 0x00,256);
		buffer[0] = 0xCC;
		buffer[1] = 0xDD;
		ret_val = tcl_proc_call(proc_func,buffer);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_WR_FAIL;
			goto ret;
		}

		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WORD_UPDATE);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_UP_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WORD_READ);
		memset(buffer, 0x00,256);
		ret_val = tcl_proc_call(proc_func, buffer);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_RD_FAIL;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",I2C_WORD_EXIT);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_I2C_EXIT_FAIL;
			goto ret;
		}
	}

	else
	{
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",GPIO_OPEN);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_GPIO_OPEN;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",GPIO_SET);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_GPIO_SET;
			goto ret;
		}
		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",GPIO_GET);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "%s failed  \n", proc_func);
			ret_val = ST_MAC_ERR_GPIO_GET;
			goto ret;
		}

		memset(proc_func, 0x00,sizeof(proc_func));
		sprintf(proc_func,"%s",GPIO_CLOSE);
		ret_val = tcl_proc_call(proc_func,NULL);
		if (ret_val != SUCCESS) {
			LOG_PRINT(INFO, "proc_%s_processing failed  \n", state);
			ret_val = ST_MAC_ERR_GPIO_CLOSE;
			goto ret;
		}
	}
ret:
	free(buffer);
	buffer = NULL;
	FUNCTION_END(ret_val);
	return ret_val;
}

/*
 * sm_assign_fallback_state: assigning fall back as default state
 * @param: def_state	 
 * @return_value:   void
 */
 
int sm_assign_fallback_state(struct state_transition_t *st_state_transition, int display_id,char* prev_state, char* tar_state)
{
	FUNCTION_START();
	int ret_val  = SUCCESS;
	int state_index = INVALID_STATE_INDEX;
	char *target_state = tar_state;
	char  *previous_state = prev_state;

    state_index = get_state_index(st_state_transition->data,display_id);
	strcpy(target_state,display_config_info[display_id]->state_machine[state_index]->fall_back);
	strcpy(previous_state,st_state_transition->data);
	LOG_PRINT(DEBUG,"path checking  for fallback_state\n");
	ret_val = sm_create_transition_path(previous_state, target_state,display_id);
	if ( ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"path not found for fallback_state\n");
		ret_val = ST_MAC_ERR_FALLBACK_PATH_FAIL;
		goto clear;
	}

	st_state_transition = sm_get_state_trans_path();
	st_state_transition = st_state_transition->next_node;

clear:
	FUNCTION_END(ret_val);
	return ret_val;
}

/* state_machine_init   - State machine function
 * @param: dispathcer_info	- Info from dispathcer
 * @param: int display_id
 * return value : 0 on success , errorcode on failure
 */
int sm_state_machine_init(st_clientinfo *dispathcer_info,st_sm_thread_args **thread_args)
{
	FUNCTION_START();
	int state_index;
	int ret_val = SUCCESS;
	int display_id = dispathcer_info->display_id;

	LOG_PRINT(DEBUG,"checking the Target state\n");
	state_index = get_state_index(dispathcer_info->arg_target_state,display_id);
	if (strcmp(display_config_info[display_id]->state_machine[state_index]->state_type, "unstable") == 0) {
		LOG_PRINT(ERROR,"Requested state is unstable\n");
		sem_wait(&thread_args[display_id]->req_complete);
		ret_val = ST_MAC_ERR_UNSTABLE_STATE;
		goto deinit;
	}

	sem_wait(&thread_args[display_id]->req_complete);

deinit:
	FUNCTION_END(ret_val);
	return ret_val;
}


int disp_parse_event( st_event_split * event_split)
{
	FUNCTION_START();
	int ret_val  = SUCCESS;
	pthread_mutex_lock(&event_split->event_process_lock);
	sem_post(&event_split->event_notify);
	pthread_mutex_unlock(&event_split->event_process_lock);
	FUNCTION_END(ret_val);
	return ret_val;
}
