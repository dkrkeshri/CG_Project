/**
  * @file	  Session_registry.c

  * @brief	 Creation of session

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>
		EXTERNAL Chappidi Nitish Reddy<external.NitishReddy.Chappidi@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include "../../common/inc/get_config_info.h"
#include "../../common/inc/displayparsejson.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
#include "../../common/inc/definations.h"
#include "../../common/inc/error.h"
#include "../inc/sessionregistry.h"

st_session_registry_ht *session_table[SESSION_RES_HT_SIZE] = {NULL};
st_client_request_ht  *client_request_ht[CLIENT_REQ_HT_SIZE] = {NULL};

/* ss_reg_session_registry  - Function create session data structure
 * @param - client_request_info	-  client request
 * return value -- session hash table
 */
st_session_registry_ht** ss_reg_session_registry(st_clientinfo *client_request_info, 
										  int *session_registry_status)
{
	FUNCTION_START();
	int i = 0;
	int j = 0;
	int ret_val = SUCCESS;
	*session_registry_status = 0;

	LOG_PRINT(DEBUG,"Error Checking of Parameters\n");
	/* Error Checking of Parameters */
	ret_val = ss_reg_errChk_client_request_info(client_request_info);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR," Invalid client Req. \n");
		*session_registry_status = SS_REG_ERR_CREAT_FAIL;
		*session_table = NULL;
		goto end;
	}

	LOG_PRINT(DEBUG,"Adding Client Request to the Hash Table\n");
	/* Adding Client Request to the Hash Table */
	ret_val = ss_reg_create_session_ht(client_request_info);
	if (ret_val != SUCCESS) {
		if ((ret_val == SS_REG_ERR_INVAL_SSID) || (ret_val ==  SS_REG_ERR_MALLOC_FAIL)) {
			LOG_PRINT(ERROR,"Create session failed");
			*session_registry_status = SS_REG_ERR_CREAT_FAIL;
			*session_table = NULL;
			goto end;
		} else if (ret_val == SS_REG_ERR_DUP_ID) {
			LOG_PRINT(ERROR,"Create session failed - Client has " \
			"sent duplicate sess-id and req-id\n");
			*session_registry_status = SS_REG_ERR_DUPL_ID;
			*session_table = NULL;
			goto end;
		}
	}
	LOG_PRINT(INFO,"Added Client Request to the Queue\n");
end:
	FUNCTION_END(session_table);
	return session_table;
}

void get_session_table(unsigned long *ptr) 
{
	//st_session_registry_ht** session_ht_table;
	
	*ptr = (unsigned long)session_table;
	//return (void*)session_table;
	
}


/* ss_reg_create_session_ht		- Function create session table for client request
 * @param client_request_info - client request
 * return value -	0 on success, errorcode on failure, 1 if same clients sends 
					duplicate sess-id and req-id
 */
int ss_reg_create_session_ht(st_clientinfo *client_request_info)
{
	
	FUNCTION_START();
	int session_index,sessionId, requestId;
	int req_index;
	int ret_val = INIT_VAL;
	st_session_registry_ht *temp;
	st_session_registry_ht *newSessionID;
	st_client_request_ht  *samesessionID;
	st_client_request_ht * samesess_temp;
	st_client_request_ht * samesess_temp2;

	LOG_PRINT(DEBUG,"Error Checking of Parameters\n");
	/* Error Checking for Parameters */
	ret_val = ss_reg_errChk_client_request_info(client_request_info);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Invalid Client Req.\n");
		ret_val = SS_REG_ERR_INVAL_REQ;
		goto end;
	}

	sessionId = client_request_info->session_id;

	session_index = (sessionId % SESSION_RES_HT_SIZE);

	LOG_PRINT(DEBUG,"Search if already a client request is present with same session id\n");
	/* Search if already a client request is present with same session id */
	ret_val = ss_reg_search_sess_id(session_index, sessionId);
	
	if  (ret_val == SUCCESS) {

		ret_val = ss_reg_insert_newnode_for_session(session_index, client_request_info);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR,"Inersting New Node for Session Failed\n");
			ret_val = SS_REG_INSERT_NODE_FOR_SESS_FAIL;
			goto end;
		}

	} else if (ret_val == SS_REG_ID_FOUND) { 

		requestId = client_request_info->request_id;
		
		req_index = (requestId % CLIENT_REQ_HT_SIZE);

		ret_val = ss_reg_insert_newnode_for_req_queue(session_index, req_index, client_request_info);
		if (ret_val != SUCCESS) {
			LOG_PRINT(ERROR,"Insert New Request for Same session Failed\n");
			ret_val = SS_REG_INSERT_NODE_FOR_SESS_FAIL;
			goto end;
		}

	} else if (ret_val == SS_REG_ERR_INVAL_SSID) {
		goto end;
	}
end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/* ss_reg_search_sess_id --- ss_reg_search_sess_id search for session Id in hash table
 * @param index   -- index of table
 * @param sessionId -- sessionId value to be searched
 * return value -  0 if not present, 1 if present, errorcode on  failure
 */
int ss_reg_search_sess_id(int index, int sessionId)
{
	
	FUNCTION_START();
	st_session_registry_ht *traverse;
	int ret_val = SUCCESS;

	LOG_PRINT(DEBUG,"Error Checking of Parameters\n");
	/* Error Checking of Parameters */
	ret_val = ss_reg_errChk_search(index,sessionId);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Invalid sessionId or index\n");
		ret_val = SS_REG_ERR_INVAL_SSID;											
		goto end;
	}
	
	LOG_PRINT(DEBUG,"search session-id\n");
	if (session_table[index] == NULL){
		LOG_PRINT(ERROR,"search session-id not found\n");
		ret_val = SUCCESS;  
		goto end;
	} else {
		for (traverse = session_table[index]; traverse != NULL; traverse = traverse->link) {

			if (traverse->client_info.session_id == sessionId) {
					LOG_PRINT(ERROR,"search session-id found\n");
					ret_val = SS_REG_ID_FOUND;
					goto end;
			}
		}
		
		if (traverse == NULL) {
		   	LOG_PRINT(ERROR,"search session-id not found\n");
			ret_val = SUCCESS;
			goto end;
		}
	}
end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/* ss_reg_deleteSessiontable_entry : Delete the entry from hash table
 * @param: session_table_ht  -- Session hash table
 * @param : sessionID   -- Session ID
 * @return value: 0 on success, errorcode on failure, 1 if there is no req. to delete
 */
int ss_reg_deleteSessiontable_entry(st_session_registry_ht* session_table_ht[],
							int sess_id, int req_id, char client_address[])
{
	st_session_registry_ht *session_ht_curr = NULL;
	st_session_registry_ht *session_ht_prev = NULL;

	st_client_request_ht *client_ht_curr = NULL;
	st_client_request_ht *client_ht_prev = NULL;
	int sess_index = -1;
	int req_index = -1;
	int i = 0;
	int req_index_with_same_sess_id = ERR_VAL;
	int ret_val = SUCCESS;
	ret_val = ss_reg_errChk_deleteSessiontable_entry(session_table_ht, sess_id, 
											  req_id, client_address);
	if (ret_val != SUCCESS) {
		LOG_PRINT(ERROR,"Invalid Parameters\n");
		ret_val = SS_REG_ERR_INVAL_PRM;
		goto end;
	}
	sess_index = (sess_id % SESSION_RES_HT_SIZE);
	session_ht_curr = session_table_ht[sess_index];
	session_ht_prev = session_ht_curr;
	LOG_PRINT(DEBUG,"find the session-id\n");
	/* Traversing to the path where we find the session-id */
	while (session_ht_curr != NULL) {
		if (session_ht_curr->client_info.session_id == sess_id) {
			break;
		}
		session_ht_prev = session_ht_curr;
		session_ht_curr = session_ht_curr -> link;
	}
	LOG_PRINT(DEBUG,"Request is present in Session Hash table \n");
	/* Request is present in Session Hash table */
	if (session_ht_curr != NULL) {
		if ((session_ht_curr->client_info.request_id ==  req_id) 
			&& (strcmp(session_ht_curr->client_info.client_address, 
				client_address) == INIT_VAL)) {
			ret_val = ss_reg_delete_session(sess_index, session_ht_curr, session_ht_prev, session_table_ht);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR,"Deleting session in session table failed\n");
				ret_val = SS_REG_DEL_NODE_FOR_SESS_FAIL;
				goto end;
			}

		} else {
			ret_val = ss_reg_del_req_with_same_sess(req_id, session_ht_curr, client_address);
			if (ret_val != SUCCESS) {
				LOG_PRINT(ERROR,"Deleting req. in request queue with same session id failed\n");
				ret_val = SS_REG_DEL_NODE_FOR_CL_REQ_WITH_SAME_SESS_FAIL;
				goto end;
			}

		}
	} else {
		LOG_PRINT(ERROR,"Specified Client Request is not present " \
		"in hash table to delete\n");
		ret_val = DEFAULT_VAL;
		goto end;
	}
	LOG_PRINT(INFO,"Client Request deleted Successfully\n");
end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/*
 * ss_reg_errChk_client_request_info: Error Check for request from client.
 * @param: client_request_info	 client request
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
int ss_reg_errChk_client_request_info(st_clientinfo *client_request_info)
{
	FUNCTION_START();
	int ret_val = SUCCESS;

	if (client_request_info ==  NULL) {
		ret_val = SS_REG_ERR_CLI_REQ_INFO;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/*
 * errChk_deleteSessiontable_entry: Err Chk for deleteSessiontable_entry func.
 * @param: session_table_ht	 session table
 * @param:sess-id   				 sessionID
 * @param:req-id   					 RequestID
 * @param:client_address		 Client IP address
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
int ss_reg_errChk_deleteSessiontable_entry(st_session_registry_ht *session_table_ht[],
								int sess_id, int req_id, char client_address[])
{
	FUNCTION_START();
	int ret_val = SUCCESS;

	if ((session_table_ht ==  NULL)  ||  (client_address == NULL)
		|| (strcmp(client_address, "\0") == INIT_VAL)) {
		ret_val = SS_REG_ERR_DEL_SESS_ENTRY;
		goto end;
	}
	
	LOG_PRINT(DEBUG,"checking sess_id and req_id\n");
	if ((sess_id < INIT_VAL) || (req_id < INIT_VAL)) {
		ret_val = SS_REG_ERR_DEL_SESS_ENTRY;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/*
 * ss_reg_errChk_search: Error Check for ss_reg_search func.
 * @param: session_table_ht	 session table
 * @param:session-id   sessionID
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
int ss_reg_errChk_search(int index,int session_id)
{
	FUNCTION_START();
	int ret_val = SUCCESS;

	if (session_id < INIT_VAL || index < INIT_VAL) {
		ret_val = SS_REG_ERR_SEARCH;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/* ss_reg_display  -- displays the hash table entries
 * @param:session_table   -- session table
 * @return value - void 
 */
void ss_reg_display(st_session_registry_ht* session_table[])
{
	FUNCTION_START();
	int i = 0;
	int j = 0;
	st_session_registry_ht *traverse ;
	st_client_request_ht *tempclien;

	for(i = 0; i < SESSION_RES_HT_SIZE; i++) {

		for(traverse = session_table[i]; traverse != NULL; traverse = traverse->link) {

			LOG_PRINT(INFO, "Entries in %d index\n", i);
			LOG_PRINT(INFO, "Display Session-id=%d\nRequest-id=%d\n" \
			"Display-id=%d\nCommand=%s\n" \
			"arg_mode=%s\narg_timeout=%d\narg_monitor=%s\narg_method=%s\n" \
			"arg_target_state=%s\nClient_address=%s\n\n", 
			traverse->client_info.session_id , traverse->client_info.request_id, 
			traverse->client_info.display_id, traverse->client_info.command,
			traverse->client_info.arg_mode,
			traverse->client_info.arg_timeout, 
			traverse->client_info.arg_monitor, traverse->client_info.arg_method,
			traverse->client_info.arg_target_state,
			traverse->client_info.client_address);

			for (j = 0; j < CLIENT_REQ_HT_SIZE; j++) {
				if (traverse -> client_request_ht[j] != NULL) {
					for(tempclien = traverse -> client_request_ht[j]; 
						tempclien!=NULL; tempclien = tempclien->link) {
						LOG_PRINT(INFO, "Client request Sess-id =%d\nReq-id=%d\n" \
						"Display-id=%d\nCommand=%s\nArg_mode=%s\n" \
						"arg_timeout=%d\narg_monitor=%s\narg_method=%s\n" \
						"arg_target_state=%s\nclient_address=%s\n\n", 
						tempclien->client_info.session_id ,
						tempclien->client_info.request_id,
						tempclien->client_info.display_id, 
						tempclien->client_info.command,
						tempclien->client_info.arg_mode,
						tempclien->client_info.arg_timeout,
						tempclien->client_info.arg_monitor, 
						tempclien->client_info.arg_method,
						tempclien->client_info.arg_target_state, 
						tempclien->client_info.client_address);
					}
				}
			}
		}
	}
	FUNCTION_END(0);
	return;
}


/*
 * ss_reg_validate_client_info: Validates the parameters sent by Client
 * @param: client_req_info		Client Information structure
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
int ss_reg_validate_client_info(st_clientinfo *client_req_info)
{
	FUNCTION_START();
	int ret_val = SUCCESS;

	if ((client_req_info->session_id < INIT_VAL)
		|| (client_req_info->request_id < INIT_VAL) || ((strcmp(client_req_info->arg_mode, "synchronous") != INIT_VAL)
		&& (strcmp(client_req_info->arg_mode, "asynchronous") != INIT_VAL))){
		ret_val = SS_REG_ERR_PARAMS_ERROR;
		goto end;
	}
	if(strcmp(client_req_info->command , DISPLAY_ENUMERATE) == 0){
		goto end;
	}
	LOG_PRINT(DEBUG,"Checking arg_mode\n");
	if( ((client_req_info->display_id < INIT_VAL)
			||(client_req_info->display_id > client_req_info->max_display_count))){
		ret_val = SS_REG_ERR_PARAMS_ERROR;
		goto end;
	}

	if((strcmp(client_req_info->command , DISPLAY_INFO) == 0) || (strcmp(client_req_info->command , EVENT_SUBSCRIBE) == 0 )){
		goto end ;
	}

	if((client_req_info->arg_timeout < INIT_VAL))
	{
		ret_val = SS_REG_ERR_PARAMS_ERROR;
		goto end;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}


/*
 * ss_reg_insert_newnode_for_session: Validates the parameters sent by Client
 * @param: client_req_info		Client Information structure
 * @return_value:   Returns 0 on success,else errorcode on failure
 */
int ss_reg_insert_newnode_for_session(int session_index, st_clientinfo *client_request_info)
{
	FUNCTION_START();
	st_session_registry_ht *newSessionID;
	st_session_registry_ht *traverse;
	int ret_val = SUCCESS;
	int i ;
	
	/* insert new node if sessionID doesnt exist*/
	newSessionID = (st_session_registry_ht*) 
									malloc(sizeof(st_session_registry_ht));
	if (newSessionID == NULL) {
		LOG_PRINT(ERROR,"Malloc failed");
		ret_val = SS_REG_ERR_MALLOC_FAIL;
		goto end;
	}
	LOG_PRINT(DEBUG,"new node\n");
	
	for ( i =0 ; i <CLIENT_REQ_HT_SIZE ; i++ ) {
		newSessionID->client_request_ht[i] = NULL;
	}
	memcpy(&newSessionID->client_info, client_request_info,
											sizeof(st_clientinfo));
	newSessionID->link = NULL;
	if (session_table[session_index] == NULL) {
		session_table[session_index] = newSessionID;
	} else {
		traverse = session_table[session_index];
		while(traverse -> link != NULL)
		{
			traverse = traverse->link;
		}
		traverse->link = newSessionID;
	}

end:
	FUNCTION_END(ret_val);
	return ret_val;
}


//ss_reg_insert_newrequest_for_same_sess
int ss_reg_insert_newnode_for_req_queue(int session_index, int req_index, st_clientinfo *client_request_info)
{
	FUNCTION_START();
	st_client_request_ht  *samesessionID;
	st_client_request_ht * samesess_trav;
	st_client_request_ht * samesess_trav2;
	st_session_registry_ht *traverse;
	int ret_val = SUCCESS;

	LOG_PRINT(DEBUG," Make a queue of request , if sessionID exist\n");
	/* Make a queue of request , if sessionID exist */
		samesessionID = (st_client_request_ht*) 
									malloc(sizeof(st_client_request_ht));
		if (samesessionID == NULL) {
			LOG_PRINT(ERROR,"Malloc failed");
			ret_val = SS_REG_ERR_MALLOC_FAIL;
			goto end;
		}
		
		LOG_PRINT(DEBUG,"Copying Clinet Request Info. into new node\n");
		/* Copying Clinet Request Info. into new node */
		memcpy(&samesessionID->client_info, client_request_info,
							sizeof(st_clientinfo));
		samesessionID->link = NULL;
		
		traverse = session_table[session_index];
		while (traverse ->link != NULL) {
			if (traverse->client_info.session_id 
				 == samesessionID->client_info.session_id) {
				break;
			}
			traverse = traverse -> link;
		}
		LOG_PRINT(DEBUG,"Traverse is Completed\n");

		if (traverse->client_request_ht[req_index] == NULL) {
			
			if (traverse->client_info.request_id 
				== samesessionID->client_info.request_id) {
				
				if (strcmp(traverse->client_info.client_address, 
					samesessionID->client_info.client_address) == INIT_VAL) {
					LOG_PRINT(ERROR,"Duplication of sess_id & req_id\n");
					ret_val = SS_REG_ERR_DUP_ID;
					goto end;
				}
			}

			traverse->client_request_ht[req_index] = samesessionID;
			
		} else {
			samesess_trav = traverse->client_request_ht[req_index];

			while(samesess_trav != NULL) {
				if (samesess_trav->client_info.request_id 
					== samesessionID->client_info.request_id) {
		
					if (strcmp(samesess_trav->client_info.client_address, 
						samesessionID->client_info.client_address)==INIT_VAL) {
				
						LOG_PRINT(ERROR,"Duplication of sess_id and " \
						"req_id\n");
						ret_val = SS_REG_ERR_DUP_ID;
						goto end;
					}
				}
				samesess_trav2 = samesess_trav;

				samesess_trav = samesess_trav->link;
			}
			samesess_trav2 -> link = samesessionID;
		}
		ret_val = SUCCESS;

end:
	FUNCTION_END(ret_val);
	return ret_val;
}



int ss_reg_delete_session(int sess_index, st_session_registry_ht *session_ht_curr, 
											st_session_registry_ht *session_ht_prev, st_session_registry_ht* session_table_ht[])
{
	FUNCTION_START();
	int i = 0;
	st_client_request_ht *client_ht_curr = NULL;
	int req_index_with_same_sess_id = ERR_VAL;
	int ret_val = SUCCESS;

	LOG_PRINT(DEBUG,"Checking req index with same session id\n");
	for (i = 0; i < CLIENT_REQ_HT_SIZE; i++) {
		client_ht_curr = session_ht_curr->client_request_ht[i];
		if (client_ht_curr != NULL) {

			req_index_with_same_sess_id = i;
			break;
		}
	}
	LOG_PRINT(DEBUG,"Delete Session\n");
	if (req_index_with_same_sess_id != ERR_VAL) {
		memcpy(&session_ht_curr->client_info, 
			   &client_ht_curr->client_info, sizeof(st_clientinfo));
		session_ht_curr->client_request_ht[req_index_with_same_sess_id]
		= client_ht_curr -> link;

		client_ht_curr -> link = NULL;

		free(client_ht_curr);

		client_ht_curr = NULL;
	} else {
		if(session_ht_prev != session_ht_curr) {

			/* delete operation -> to next session table node */
			session_ht_prev -> link = session_ht_curr -> link;
			session_ht_curr -> link  = NULL;
			free(session_ht_curr);
			session_ht_curr = NULL;
		} else {
			if (session_ht_prev->link == NULL) {
				session_table_ht[sess_index] = NULL;
			} else {

				session_ht_curr = session_ht_curr -> link;
				session_table_ht[sess_index] = session_ht_curr;
				session_ht_prev = NULL;
			}

			free(session_ht_prev);
			session_ht_prev	= NULL; 
		}
	}
end:
	FUNCTION_END(ret_val);
	return ret_val;
}


int ss_reg_del_req_with_same_sess(int req_id, st_session_registry_ht *session_ht_curr, char client_address[])
{
	FUNCTION_START();
	st_client_request_ht *client_ht_curr = NULL;
	st_client_request_ht *client_ht_prev = NULL;
	int req_index = ERR_VAL;
	int ret_val = SUCCESS;
	
	req_index = (req_id % CLIENT_REQ_HT_SIZE);
	client_ht_curr = session_ht_curr->client_request_ht[req_index];
	LOG_PRINT(DEBUG,"Delete req with same session id\n");
	if ((client_ht_curr->client_info.request_id == req_id) 
		&& (strcmp(client_ht_curr->client_info.client_address,
				   client_address) == INIT_VAL)) {
		session_ht_curr->client_request_ht[req_index] 
		= client_ht_curr -> link;
		
		client_ht_curr -> link = NULL;
		free(client_ht_curr);
		client_ht_curr = NULL;
	} else {
		client_ht_prev = client_ht_curr;
		client_ht_curr = client_ht_curr -> link;
		while (client_ht_curr != NULL) {

			if ((client_ht_curr->client_info.request_id == req_id) 
				&& (strcmp(client_ht_curr->client_info.client_address, 
						   client_address) == INIT_VAL)) {

				client_ht_prev -> link = client_ht_curr -> link;
				client_ht_curr -> link = NULL;
				free(client_ht_curr);
				client_ht_curr = NULL;

				LOG_PRINT(ERROR,"Client Request deleted " \
				"successfully\n");

				ret_val = SS_REG_ERR_CL_REQ_DEL;
				goto end;
			}
			client_ht_prev = client_ht_curr;
			client_ht_curr = client_ht_curr -> link;
		}
		LOG_PRINT(DEBUG,"Delete Client Req from hash table\n");
		if (client_ht_curr == NULL) {
			/*Request Not present*/
			LOG_PRINT(ERROR," Specified Client Request is " \
			"not present in hash table to delete\n");
			ret_val = SS_REG_ERR_CL_REQ_HASH_TABLE;
			goto end;
		}
	}
end:
	FUNCTION_END(ret_val);	
	return ret_val;
}
