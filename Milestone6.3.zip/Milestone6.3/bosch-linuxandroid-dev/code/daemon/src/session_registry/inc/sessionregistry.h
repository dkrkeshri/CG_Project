#ifndef _SESSIONREGISTRY_H_
#define _SESSIONREGISTRY_H_

/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
 #include "../../common/inc/definations.h"
 
 /***************************************************************************** MACROS
 ****************************************************************************/
#define SESSION_RES_HT_SIZE     10
#define CLIENT_REQ_HT_SIZE      2
 
 
 /****************************************************************************
 * TYPEDEF
 ****************************************************************************/
 typedef struct client_request_ht {
	st_clientinfo client_info;
	int start;
	struct client_request_ht *link;
}st_client_request_ht;

typedef struct session_registry_ht {
	st_clientinfo client_info;
	st_client_request_ht *client_request_ht[CLIENT_REQ_HT_SIZE]; 
	struct session_registry_ht *link;
}st_session_registry_ht;
 
 
 /****************************************************************************
 * FUNCTION PROTOTYPES
 ****************************************************************************/
 
 st_session_registry_ht** ss_reg_session_registry(st_clientinfo *client_request_info,
					   int *session_registry_status);
int ss_reg_create_session_ht(st_clientinfo *client_request_info);
int ss_reg_search_sess_id(int session_index, int sessionId);
int ss_reg_deleteSessiontable_entry(st_session_registry_ht* session_table_ht[], 
							   int session_id,int req_id, char *client_address);
int ss_reg_errChk_client_request_info(st_clientinfo *client_request_info);
int ss_reg_errChk_deleteSessiontable_entry(st_session_registry_ht* session_table_ht[],
				    int sess_id, int req_id, char *client_address);
int ss_reg_errChk_search(int index,int session_id);
void ss_reg_display(st_session_registry_ht* session_table[]);
int ss_reg_validate_client_info(st_clientinfo *client_req_info);
int ss_reg_insert_newnode_for_session(int session_index, st_clientinfo *client_request_info);
int ss_reg_insert_newnode_for_req_queue(int session_index, int req_index, st_clientinfo *client_request_info);
int ss_reg_delete_session(int sess_index, st_session_registry_ht *session_ht_curr, 
			st_session_registry_ht *session_ht_prev, st_session_registry_ht* session_table_ht[]);
int ss_reg_del_req_with_same_sess(int req_id, st_session_registry_ht *session_ht_curr, char client_address[]);

#endif /* _SESSIONREGISTRY_H_ */
