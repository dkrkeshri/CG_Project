/**
  * @file	  sysfs_adapter.c

  * @brief	 sysfs adapter source file

  *

  * @author external.chaneswarareddy.yemme@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>

#include "../../logging/inc/loggerDaemon.h"
#include "../../common/inc/error.h"
#include "sysfs_adapter.h"
#define gettid() 0

int sysfs_adapter_ctrl(char* sysfsFile, int ctrlType,  char *buff){
	int ret_val = SUCCESS;
	int *length = NULL;
	char*buffer =  (uint8_t*)atol(buff);
	if( (sysfsFile == NULL) || (buffer == NULL)){
		LOG_PRINT(INFO, "Buffer NULL\n");
		ret_val = SYSFS_INVALID_ARGS_ERR;
		goto end;
	}
	length = (int*)&buffer[0];
	if(ctrlType == SYSFS_READ){
		ret_val = sys_adapter_read(sysfsFile, &buffer[4], length);
	}
	else if (ctrlType == SYSFS_WRITE){
		ret_val = sys_adapter_write(sysfsFile, &buffer[4], length);
	}
	else {
		LOG_PRINT(INFO, "INVALID Operation\n");
		ret_val = SYSFS_INVALID_OP;
	}
end:
	return ret_val;
}

int sys_adapter_read(char* sysfsFile, char *buffer, int* length){
	int ret_val = SUCCESS;
	int fd = 0;
	int readLen = 0;

	fd = open(sysfsFile, O_RDONLY);
	if (fd <= 0) {
		LOG_PRINT(INFO, "Failed to open %s\n", sysfsFile);
		ret_val = SYSFS_FILE_OPEN_ERR;
		goto end;
	} 
	LOG_PRINT(INFO, "before buffer %s length0x%x\n",buffer, *length);
	readLen = read(fd, buffer, *length);
	if(readLen <= 0){
		LOG_PRINT(INFO, "Failed to read sysfs file\n");
		ret_val = SYSFS_FILE_READ_ERR;
		* length = 0;
		goto end;
	}
	LOG_PRINT(INFO, "After buffer %s length 0x%x\n",buffer,readLen );
	*length = readLen;
	LOG_PRINT(INFO, "Sysfs(%s) Read Successful \n",sysfsFile);
end:
	if(fd)
		close(fd);
	return ret_val;
      
}

int sys_adapter_write(char* sysfsFile, char *buffer, int* length){
	int ret_val = SUCCESS;
	int fd = 0;
	int writeLen = 0;

	fd = open(sysfsFile, O_WRONLY);
	if (fd <= 0) {
		LOG_PRINT(INFO, "Failed to open %s\n", sysfsFile);
		ret_val = SYSFS_FILE_OPEN_ERR;
		goto end;
	}
	LOG_PRINT(INFO, "before %s buffer %s length0x%x\n",sysfsFile, buffer, *length);
	writeLen = write(fd, buffer, *length);
	if(writeLen < 0){
		LOG_PRINT(INFO, "Failed to write sysfs file\n");
		ret_val = SYSFS_FILE_WRITE_ERR;
		goto end;
	}
	LOG_PRINT(INFO, "After buffer %s length0x%x\n",buffer,writeLen );
	if(*length  != writeLen){
		ret_val = SYSFS_FILE_WRITE_INCOMPLETE;
		LOG_PRINT(INFO, "given length is not matched with write function return value\n");
		goto end;
	}
	LOG_PRINT(INFO, "Sysfs(%s) Write Successful \n",sysfsFile);
end:
	if(fd)
		close(fd);
	return ret_val;      
}
