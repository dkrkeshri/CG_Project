/**
  * @file	  sysfs_adapter.h

  * @brief	 sysfs adapter header file

  *

  * @author external.chaneswarareddy.yemme@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim
  */
#ifndef _SYSFSADAPTER_H_
#define _SYSFSADAPTER_H_

#define SYSFS_READ									0x01
#define SYSFS_WRITE									0x02


/****************************************************************************
 * FUNCTION PROTOTYPES
 ****************************************************************************/
int sysfs_adapter_ctrl(char* sysfsFile, int ctrlType, char *buffer);
int sys_adapter_read(char* sysfsFile, char *buffer, int* length);
int sys_adapter_write(char* sysfsFile, char *buffer, int* length);

#endif /* _SYSFSADAPTER_H_ */