/**

  * @file	 hal_layer.c

  * @brief	  Hal layer program

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>
  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#include "../logging/inc/loggerDaemon.h"
#include "../logging/inc/logger_internal.h"
#include "../common/inc/get_config_info.h"
#include "../common/inc/definations.h"


/* hal_layer_print -- print the values in hal layer
 * @param: ptr_arg  -- pointer arguments
 * return void
 */
 
void init_backend (void) {

	char *name = NULL;

	st_logger configs;
	
	name = malloc(BUF_SIZE);

	configs.backendhandle = dlopen(LOG_LIBRARY_NAME, RTLD_NOW);

	snprintf(name, BUF_SIZE, "%s", "log_processing");
	log_fcn = dlsym(configs.backendhandle, name);
	
	free(name);
	name = NULL;

}
 
 
void hal_layer_print(char *ptr_arg)
{

	st_dspl_state_mac *struct_var;
	
	struct_var = (st_dspl_state_mac *)(atol(ptr_arg));

	
    LOG_PRINT(INFO, "actions:%s state_type =%s \n", 
                struct_var->actions,struct_var->state_type);
}
