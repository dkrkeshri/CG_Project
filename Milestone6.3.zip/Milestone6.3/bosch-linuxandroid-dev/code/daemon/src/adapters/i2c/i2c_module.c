/**
  * @file	  i2c_module.c
 
  * @brief	 Initialization of i2c

  *

  * @author	EXTERNAL Bhagavan Bamidi (Global Edge, MS/ECF1-XC) <external.bamidi.bhagavan@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <assert.h>
#include <string.h>
#include "i2c.h"
#include "../../logging/inc/loggerDaemon.h"
#define INIT_VAL        0
#define DEFAULT_VAL     1

con_t ctx = {INIT_VAL};

st_i2c_addr i2c_addr[10];
//char *i2c_address_array[10][256];
static int number_of_devices = 0;
#define gettid() 0

/* -----------------------------------------------------------------------------
 * @brief   Performs either writing or reading from I2C device
 *
 * @param   [in] ctx operation context
 * @param   [in/out] msg: msg contains buffer with information on
 *          how to store or retreive information.
 *          If msg->is_write is true, then data will be stored otherwise
 *          data will be read. In case of reading msg->buf must point
 *          to the buffer which is big enough to store 'msg->buf.sz' bytes,
 *          (otherwise memory can be corrupted).
 * @returns 1 on success, otherwise 0.
-------------------------------------------------------------------------------- */
int i2c_op(const con_t* ctx, msg_t *msg) {
    // check if connected
    if (!ctx->dev) {
        return INIT_VAL;
    }
    struct i2c_smbus_ioctl_data 	args;
    union i2c_smbus_data data;
    int res = DEFAULT_VAL;
    args.read_write = msg->is_write?I2C_SMBUS_WRITE:I2C_SMBUS_READ;
    args.command = msg->reg;
	args.size = I2C_SMBUS_BYTE_DATA;		// #define I2C_SMBUS_BYTE_DATA	    2   its in uapi/linux/i2c.h
	if (ctx->access_width) { 
		args.size = I2C_SMBUS_WORD_DATA;		// #define I2C_SMBUS_WORD_DATA	    3  its in uapi/linux/i2c.h
	}
    args.data = &data;
    // can't use msg->buf->sz as it's updated in case of read
    size_t data_len = msg->buf->sz;
    // Write/Read byte after byte. On write, bytes are stored
    // in i2c registers contiguously (first byte in reg=0,
    // second in reg=DEFAULT_VAL, ...)
    for (int i=0; i<data_len; i++) {
		if (ctx->access_width) { 
			data.word = msg->buf->w[i];
		} else {
			data.byte = msg->buf->b[i];
		}
        args.command = msg->reg + i;
        if (ioctl(ctx->dev, I2C_SMBUS, &args) < INIT_VAL) {
            return INIT_VAL;
        }
        if (!msg->is_write) {
			if (ctx->access_width) { 
				msg->buf->w[i] = data.word;
			}else {
				msg->buf->b[i] = data.byte;
			}
            msg->buf->sz = i + DEFAULT_VAL;
        }
    }
    return res;
}

short get_value(char* string_ID, st_i2c_addr *i2c_addr, int *index)
{
	int i =0;
	char *uniqueID = NULL;
	short i2cAddress = 0xFF;
	for(i =0; i < number_of_devices; i ++)
	{
		uniqueID = i2c_addr[i].string_id;
		if(strcmp(uniqueID, string_ID) == 0) {
			i2cAddress = (short)i2c_addr[i].reg_addr;
			*index = i;
			break;
		}
	}
	return i2cAddress;
}

void i2c_send(char* string_id,int register_addr,char* value)
{
 
	int reg_offset = INIT_VAL;
	short slave_addr;
	int mask;
	int index;
	slave_addr = get_value(string_id, i2c_addr, &index);
	if( i2c_addr[index].is_i2c_connected == 0) {
			LOG_PRINT(ERROR,"i2c device is already disconnected\n");
			goto end;
	}
	if ( register_addr & REGISTER_ACCESS_MASK ) { 
		
		ctx.access_width = 1;
	}
	register_addr = register_addr & 0xFF;
    // test data sending
	buf_t data_send;
	
	if (ctx.access_width) {
		data_send.w = (uint16_t*)atol(value);
	}else {
		data_send.b = (uint8_t*)atol(value);
	}
	data_send.sz = 1;
    msg_t msg = {
        .buf = (buf_t *)&data_send,
        .is_write = 1,
        .reg = register_addr
    };
	if (!i2c_op(&ctx, &msg)) {
		//PANIC("Can't Send data to i2c device and slave on %d",slave_addr);
	} else {
		if (ctx.access_width) {
			LOG_PRINT(INFO, "Data sent :  actions==>%x\n", msg.buf->w[0]);
		}else {
			LOG_PRINT(INFO, "Data sent :  actions==>%x\n", msg.buf->b[0]);
		}
	}
end:
	return;
}

void i2c_update(char *string_id,int reg_addr,char* mask,int value)
{
	int reg_offset = INIT_VAL;
	int mask_value;
	char *token;
	short slave_addr;
	int index;
	int value_1;
	char *buffer = (char*) malloc(256);
	short *buffer1 = (short*)malloc(256);
	char* mask_string = (char*)malloc(256);
	slave_addr = get_value(string_id,i2c_addr,&index);
	if( i2c_addr[index].is_i2c_connected == 0) {
			LOG_PRINT(ERROR,"i2c device is already Disconnected\n");
			goto end;
	}
   token = strtok(mask,"x");
   /* walk through other tokens */
   while( token != NULL ) {
      token = strtok(NULL, "_");
	  if ( token != NULL) {
		strcat(mask_string,token);
	  }
   }
    mask_value = (int) strtol(mask_string, NULL, 2);
   	buf_t data_send1;
	
	if (ctx.access_width) {
		data_send1.w = (uint16_t*)buffer1;
	}else {
		data_send1.b = (uint8_t*)buffer;
	}
	data_send1.sz = 1;
    msg_t msg1 = {
        .buf = (buf_t *)&data_send1,
        .is_write = 0,
        .reg = reg_addr
    };

	if (!i2c_op(&ctx, &msg1)) {
        //PANIC("Can't Send data to device %d and slave on %d", slave_addr,reg_addr);
    }
   
	if(ctx.access_width) {
		value_1 = mask_value & buffer1[0];
	} else {
		value_1 = mask_value & buffer[0];
	}
	mask_value = value_1 | value;

    buf_t data_send;
	
	if (ctx.access_width) {
		data_send.w = (uint16_t*)&mask_value;
	}else {
		data_send.b = (uint8_t*)&mask_value;
	}
	data_send.sz = 1;

    msg_t msg= {
        .buf = (buf_t *)&data_send,
        .is_write = 1,
        .reg = reg_addr
    };
	if (!i2c_op(&ctx, &msg)) {
		//PANIC("Can't Send data to device %d and slave on %d", slave_addr,reg_addr);
	}
	else {
		if (ctx.access_width) {
			LOG_PRINT(INFO, "Data update :  actions==>%x \n", msg.buf->w[0]);
		}else {
			LOG_PRINT(INFO, "Data update :  actions==>%x \n", msg.buf->b[0]);
		}
	}
end:
	free(buffer);
	buffer = NULL;
	free(buffer1);
	buffer1 = NULL;
	free(mask_string);
	mask_string = NULL;
	
	return;
}


void i2c_recv(char* string_id,int reg_addr, char* buffer) 
{	
	int reg_offset = INIT_VAL;
	short slave_addr;
	int index;
	char *buffer_str;
	buffer_str = (char*)atol(buffer);
	slave_addr = get_value(string_id,i2c_addr,&index);

	if( i2c_addr[index].is_i2c_connected == 0) {
			LOG_PRINT(ERROR,"i2c device is already Disconnected\n");
			goto end;
	}
	
	buf_t data_send;
	
	if (ctx.access_width) {
		data_send.w = (uint16_t*)buffer_str;
	}else {
		data_send.b = (uint8_t*)buffer_str;
	}
	data_send.sz = 1;

	
    msg_t msg = {
        .buf = &data_send,
        .is_write = 0,
        .reg = reg_addr
    };
	
	if (!i2c_op(&ctx, &msg)) {
		LOG_PRINT(INFO, "Can't receive data from device %d and slave on %d\n",
			slave_addr,reg_addr);
	}else {
		if(ctx.access_width) {
			LOG_PRINT(INFO, "Data Recived :  actions==>%x \n", msg.buf->w[0]);
		}else{
			LOG_PRINT(INFO, "Data Recived :  actions==>%x \n", msg.buf->b[0]);
		}
	}
end:
	return;
}

void i2c_dev_open(char *string_id, int bus_number, int i2c_address) {
	
    char filename[BUF_SIZE];
	char *unique_id ;
	short slave_addr;
	int i ;
	sprintf(filename, "/dev/i2c-%d", bus_number);
	i2c_addr[number_of_devices].is_i2c_connected = 0;
	slave_addr = (short )(i2c_address);
	for ( i=0 ; i < 10; i++ ) {
		if(i2c_addr[i].is_i2c_connected == 0) {
			strcpy(i2c_addr[i].string_id, string_id);
			i2c_addr[i].reg_addr = i2c_address;
			i2c_addr[i].is_i2c_connected = 1;
			break;
		}
	}
	
	number_of_devices++;
	
    if ((ctx.dev = open(filename, O_RDWR)) < INIT_VAL) {
        LOG_PRINT(INFO,"Failed to open the i2c bus %d", ctx.dev);
    }
	else
	{
		LOG_PRINT(INFO, "I2C Bus opened \n");
	}
	ctx.access_width = 0;
    if (ioctl(ctx.dev, I2C_SLAVE, slave_addr) < INIT_VAL) {
         LOG_PRINT(INFO,"Can't acquire bus access");
    }
}


void i2c_dev_close(char *string_id) 
{
	int i =0;
	for ( i=0 ; i < 10; i++ ) {
		if (strcmp(string_id,i2c_addr[i].string_id ) == 0) {
			memset(&i2c_addr[i],0x0,sizeof(i2c_addr[i]));
			break;
		}
	}
	if (ctx.dev) {
        close(ctx.dev);
		ctx.dev = INIT_VAL;
		number_of_devices--;
		 LOG_PRINT(INFO, "I2C Bus Closed\n");
    }
	else
	{
		 LOG_PRINT(INFO, "I2C Bus is not opened\n");
	}
}

void i2c_is_connected(int device_id, int slave_addr)  {
    // Device wasn't opened
    if (!ctx.dev) {
        goto end;
    }

    // Check if slave reponds to reads
    uint8_t tmp[DEFAULT_VAL];
    buf_t b = {
        .b = tmp,
        .sz = DEFAULT_VAL
    };
    msg_t msg = {
        .buf = &b,
        .is_write = INIT_VAL,
        .reg = INIT_VAL
    };

    if (i2c_op(&ctx, &msg)) {
		  LOG_PRINT(INFO, "I2C device %d and slave on %d is already connected\n",
			device_id,slave_addr);
	
	}
	else
	{
		goto end;
	}
end:
     LOG_PRINT(INFO, "I2C device %d and slave on %d is not connected\n", 
	 device_id,slave_addr);
}
