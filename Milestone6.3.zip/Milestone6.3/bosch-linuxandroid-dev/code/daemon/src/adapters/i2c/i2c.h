/**
  * @file	  i2c.h
 
  * @brief	 Header File for i2c

  *

  * @author	EXTERNAL Bhagavan Bamidi (Global Edge, MS/ECF1-XC) <external.bamidi.bhagavan@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#ifndef I2C_H_
#define I2C_H_

#include <stdint.h>
#include <stdbool.h>
#include "../../logging/inc/loggerDaemon.h"
#include "../../logging/inc/logger_internal.h"
//#include "../../common/inc/definations.h"

#define REGISTER_ACCESS_MASK 0x8000
// Max message size in bytes. Corresponds to number of registers
// in i2c-stub
#define MAX_BUFFER_SIZE 256U

#define LOG(...)                                                      \
    do {                                                              \
        (void) printf("[%s() %s:%d] ", __func__, __FILE__, __LINE__); \
        (void) printf(__VA_ARGS__);                                   \
        (void) printf("\n");                                          \
    } while (0)

#define PANIC(...)              \
    do {                        \
        LOG(__VA_ARGS__);       \
        exit(EXIT_FAILURE);     \
    } while(0)

// Simple struct with a pointer to buffer and it's length
typedef struct buf_t {
    uint8_t *b;  // pointer to some buffer
    uint16_t *w;
    size_t sz;   // it's size
} buf_t;

typedef struct i2c_addr 
{
	char string_id[BUF_SIZE];
	int reg_addr;
	bool is_i2c_connected;
}st_i2c_addr;

#define CHECK_BUF(x)                            \
do {                                            \
    if (!(x) || !(x)->b)                        \
        goto end;                               \
} while(0)

// Connection context
typedef struct con_t {
    int dev;    // connection file descriptor
    bool access_width; // FALSE - 8 bit register read TRUE - 16 bit register read
} con_t;

// Stores a buffer stores message to write or that was read.
typedef struct msg_t {
    buf_t *buf;     // buffer stores data received/to be sent to i2c slave
    uint8_t reg;    // register in i2c-stub to start with
    int is_write;   // 1 for write, 0 for read
} msg_t;

/* -----------------------------------------------------------------------------
 * @brief   Opens persistent connection to I2C slave
 *
 * @param   [out] ctx operation context
 * @param   [in ] device_num number corresponds to character device
 *                which should be used for connection. For example if
 *                device to be used is /dev/i2c-8, then device_num=8
 * @param   [in ] slave_addr address of the I2C slave. In this example
 *                it is always set to 0x03
 * @returns 1 on success and sets 'ctx', 0 otherwise.
-------------------------------------------------------------------------------- */
//int i2c_dev_open(con_t *ctx, int device_num, int slave_id);

int i2c_op(const con_t* ctx, msg_t *msg);
/* -----------------------------------------------------------------------------
 * @brief   Closes connection to I2C slave
 *
 * @param   [in] ctx operation context
-------------------------------------------------------------------------------- */
//void i2c_dev_close(con_t *ctx);

/* -----------------------------------------------------------------------------
 * @brief   Checks if connection is opened and I2C slave responds to commands
 *
 * @param   [in] ctx operation context
 *
 * @returns 1 on success, otherwise 0
-------------------------------------------------------------------------------- */
void i2c_is_connected(int device_num, int slave_addr);

/* -----------------------------------------------------------------------------
 * @brief   Encrypts, authenticates and sends data to I2C device
 *
 * @param   [in] ctx operation context
 * @param   [in] plaintext - buffer with a plaintext to send
 * @returns 1 on success, 0 otherwise.
-------------------------------------------------------------------------------- */
void i2c_send(char* string_id,int register_addr,char* value);

/* -----------------------------------------------------------------------------
 * @brief   Receives, authenticates and decrypts data from I2C slave
 *
 * @param   [in] ctx operation context
 * @param   [out] plaintext - buffer to store decrypted data in. Buffer
 *          must be big enough to store data + TAG_LEN bytes.
 * @returns 1 on success, 0 otherwise (in case data can't be received or
            decrypted or authenticated).
-------------------------------------------------------------------------------- */
void i2c_recv(char* string_id,int reg_addr, char* buffer);
void i2c_dev_open(char *string_id, int bus_number, int i2c_address);
void i2c_dev_close(char *string_id);
short get_value(char* string_ID, st_i2c_addr *i2c_addr, int *index);
void i2c_update(char *string_id,int reg_addr,char* mask,int value);

#endif // I2C_H_
