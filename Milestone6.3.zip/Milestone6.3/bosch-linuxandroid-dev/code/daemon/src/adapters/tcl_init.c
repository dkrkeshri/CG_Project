/**
  * @file	  tcl_init.c
  
  * @brief	 Initialization of tcl interpreter

  *

  * @author	EXTERNAL Shanbog Pavitra <external.Pavitra.Shanbog@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */

#include "../common/inc/get_config_info.h"
#include "../logging/inc/loggerDaemon.h"
#include "../logging/inc/logger_internal.h"
#include "../common/inc/definations.h"
#include "../common/inc/error.h"

Tcl_Interp *interp; /* tcl Interpreter for application. */

/*
* tcl_init   - initialize tcl interpreter
 * @param: no parameter
 * return value : 0 on success -1 on failure
 */
 
int tcl_init(void)
{
	int ret_val = SUCCESS;
	interp = Tcl_CreateInterp();

	if (Tcl_Init(interp) == TCL_ERROR) {

		LOG_PRINT(ERROR, "@%s: TCl init failed\n", __func__);
		ret_val = TCL_ERR_INIT_FAIL;
		goto deinit;
	}

	Tcl_GlobalEval(interp ,"source ../../daemon/src/adapters/tcl_layer.tcl");
	Tcl_GlobalEval(interp ,"init_backend");
	
deinit:
	return ret_val;
}


/* tcl_proc_call   - calling tcl proc to send data to tcl
 * @param: proc	      - tcl proc name
 * @param: struct_var - structure to pass to tcl script
 * return value : 0 on success and -1 on failure
 */
 
int tcl_proc_call(char *proc ,char *struct_var)
{
	int ret_val = SUCCESS;
	char buffer[BUF_SIZE] = {INIT_VAL};
	char tcl_cmd[BUF_SIZE] = {INIT_VAL};
	
	if (struct_var != NULL)
	{
		snprintf(buffer, sizeof(buffer) , "%ld",(long int) struct_var);
		Tcl_SetVar( interp, "tcl_var",(char *)&buffer, INIT_VAL);
		strcpy(&tcl_cmd[INIT_VAL],proc);
		strcat(&tcl_cmd[strlen(proc)]," $tcl_var");
	}
	 else {
	 	strcpy(&tcl_cmd[INIT_VAL],proc);
	}
	
	if (TCL_OK != Tcl_GlobalEval(interp ,tcl_cmd))
	{
		LOG_PRINT(ERROR, "@%s: calling tcl proc failed\n", 
                        __func__);
		ret_val = TCL_ERR_TCL_PROC_FAIL;
		goto proc_fail;
	}
proc_fail:
	return ret_val;
	
}
