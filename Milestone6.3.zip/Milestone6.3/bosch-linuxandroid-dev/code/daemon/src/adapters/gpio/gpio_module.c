/**
  * @file	  gpio_module.c
  
  * @brief	 Initialization of gpio

  *

  * @author	EXTERNAL Bhagavan Bamidi (Global Edge, MS/ECF1-XC) <external.bamidi.bhagavan@in.bosch.com>

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include<sys/ioctl.h>
#include "gpio.h"
#include "../../logging/inc/loggerDaemon.h"
#include "../../common/inc/error.h"
 
#define INPUT      1<<2
#define OUTPUT  1<<3

gpio_con_t  gpio_ctx = {INIT_VAL};
st_gpio_mapping gpio_mapping[10]; 
static int no_of_gpio = 0;

#define gettid() 0

int gpio_open(const char *gpio_name,char * gpio_driver_name,int gpio_number,int operation)
{
	char chrdev_name[BUF_SIZE];
	int ret;
	int ret_val = SUCCESS;
	int set_dir_ret_val ;

	ret = snprintf(chrdev_name,sizeof(chrdev_name), "/dev/%s", gpio_driver_name);
	gpio_mapping[no_of_gpio].is_gpio_connected = 0;
	
	if (gpio_mapping[no_of_gpio].is_gpio_connected == 0)
	{
	    strcpy(gpio_mapping[no_of_gpio].string_id,gpio_name);
	    strcpy(gpio_mapping[no_of_gpio].chip_number,gpio_driver_name);
	    gpio_mapping[no_of_gpio].gpio_number = gpio_number;
	    gpio_mapping[no_of_gpio].is_gpio_connected = 1;
		no_of_gpio++;
	}
	
	gpio_ctx.dev = open(chrdev_name, 0);
	
	if(gpio_ctx.dev < 0) {
		LOG_PRINT(INFO,"Cannot open device file...\n");
		ret_val = HAL_ERR_GPIO_OPEN;
		goto end;
	} 
	LOG_PRINT(INFO,"opened gpio device file...\n");
	set_dir_ret_val = gpio_change_dir(gpio_mapping[no_of_gpio].gpio_number,operation);
	if(set_dir_ret_val == ERR_VAL ){
		LOG_PRINT(INFO,"gpio set direction failed \n");
		ret_val = set_dir_ret_val;
		goto end;
	}

end:
	return ret_val;
	
}
int gpio_close(char *string_id)
{
	int ret;
	int i;
	for (i=0;i<no_of_gpio;i++){
		if (strcmp(string_id,gpio_mapping[i].string_id ) == 0) {
			memset(&gpio_mapping[i],0x0,sizeof(gpio_mapping[i]));
			break;
		}
	}
	
	ret = close(gpio_ctx.dev);
	
	if (ret == ERR_VAL) {
		LOG_PRINT(INFO,"Failed to close GPIO device file...\n");
		gpio_ctx.dev = INIT_VAL;
	}
	LOG_PRINT(INFO,"closed GPIO device file..\n");
	return ret;
}

int get_gpio_number(char * string_id )
{
	int gpio_line;
	for(int i =0 ;i<no_of_gpio;i++){
	    if(strcmp(string_id,gpio_mapping[i].string_id) == 0 )
	   {
		   gpio_line = gpio_mapping[i].gpio_number;
		   break;
	   }
	}
	return gpio_line;
}

int gpio_change_dir(int line,int direction)
{		

	int ret;
	struct gpio_v2_line_config config;
	struct gpio_v2_line_request req;

	if(direction == INIT_VAL) {
		memset(&config, INIT_VAL, sizeof(config));
		config.flags = INPUT;
		req.offsets[INIT_VAL] = line - DEFAULT_VAL;
		req.config = config;
	} else if(direction == DEFAULT_VAL ) {
		memset(&config, INIT_VAL, sizeof(config));
		config.flags = OUTPUT;
		req.offsets[INIT_VAL] = line - DEFAULT_VAL;
		req.config = config;
	}

	ret = ioctl(gpio_ctx.dev, GPIO_V2_GET_LINE_IOCTL, &req);

	if(ret < INIT_VAL ) {
		LOG_PRINT(INFO,"Failed to change gpio direction..\n");
		return ERR_VAL;
	} else {
		LOG_PRINT(INFO,"changed gpio line direction..\n");
		return ret;
	}
		
}

int get_gpioline_value(char * string_id)
{
	struct gpio_v2_line_values lineValue;
	int ret;
	int line;

	line = get_gpio_number(string_id);		

	lineValue.mask = line;
	ret = ioctl(gpio_ctx.dev, GPIO_V2_LINE_GET_VALUES_IOCTL, &lineValue);
	
	if (ret == ERR_VAL) {
		LOG_PRINT(INFO,"Failed to issue CHIPINFO IOCTL..\n");
		ret =  ERR_VAL;
		goto end;
	} 
	LOG_PRINT(INFO,"Successfully read gpio value..\n");
	LOG_PRINT(INFO,"The value of gpio line %d  is %lld\n", line, lineValue.bits);
	
end:
		return ret;
}

int set_gpioLine_value(char *string_id,int value)
{
	struct gpio_v2_line_values lineValue;
	int ret;
	int line;

	line = get_gpio_number(string_id);		
	
	lineValue.mask  = line;
	lineValue.bits   = value;
	
	ret = ioctl(gpio_ctx.dev, GPIO_V2_LINE_SET_VALUES_IOCTL, &lineValue);

	if (ret == ERR_VAL) {
		LOG_PRINT(INFO,"Failed to issue GPIO_V2_LINE_SET_VALUES_IOCTL\n");
		ret = ERR_VAL;
		goto end;
	} 
	LOG_PRINT(INFO,"Changed gpio value to %d \n", value);
end:
	return ret;
}
void gpio_chipInfo_display(int gpios){

	if(gpios& GPIO_V2_LINE_FLAG_INPUT)
	{
		LOG_PRINT(INFO,"Direction : Input\n");
	}
	if(gpios & GPIO_V2_LINE_FLAG_OUTPUT)
	{
		LOG_PRINT(INFO,"Direction : Output\n");
	}
	if(gpios & GPIO_V2_LINE_FLAG_BIAS_PULL_UP)
	{
		LOG_PRINT(INFO,"Pull-up Enabled\n");
	}
	if(gpios & GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN)
	{
		LOG_PRINT(INFO,"Pull-down Enabled\n");
	}
	if(gpios & GPIO_V2_LINE_FLAG_OPEN_SOURCE)
	{
		LOG_PRINT(INFO,"Open source\n");
	}
	if(gpios & GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN)
	{
		LOG_PRINT(INFO,"Open Drain\n");
	}
}

int  get_chipInfo()
{
	struct gpiochip_info cinfo;			
	struct gpio_v2_line_info linfo;
	int ret;
	int i;

	/* Inspect this GPIO chip */
	ret = ioctl(gpio_ctx.dev, GPIO_GET_CHIPINFO_IOCTL, &cinfo);
	if (ret == ERR_VAL) {
		LOG_PRINT(INFO,"Failed to issue GPIO_GET_CHIPINFO_IOCTL \n");
	} else {
		LOG_PRINT(INFO,"GPIO chip name : %s\nGPIO Lable : %s\nGPIO lines : %u\n", 
				cinfo.name, cinfo.label, cinfo.lines);	
			
		for (i = INIT_VAL; i < cinfo.lines; i++) {

		memset(&linfo, INIT_VAL, sizeof(linfo));
		linfo.offset = i;

		ret = ioctl(gpio_ctx.dev, GPIO_V2_GET_LINEINFO_IOCTL, &linfo);
		if (ret == ERR_VAL) {
			LOG_PRINT(INFO,"Failed to issue  GPIO_V2_GET_LINEINFO_IOCTL\n");
		} else {
			LOG_PRINT(INFO,"line %2d : \n", linfo.offset);
			gpio_chipInfo_display((int)linfo.flags);
		}
	}
	}
	return DEFAULT_VAL;
	
}
