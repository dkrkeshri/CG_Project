/**

  * @file	   backend.c

  * @brief	  Loading, Unloading of Backend func. to open & close shared lib.

  *

  * @author	 external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#include "../../common/inc/get_config_info.h"
#include "../inc/loggerDaemon.h"
#include "../inc/logger_internal.h"
#include "../../common/inc/error.h"
#include "../../common/inc/definations.h"
#include "../inc/backend.h"

int logger_init(st_config_params *config_params,st_logger * logging_interface)
{
	int  ret_val = SUCCESS;

	ret_val = load_log_config(logging_interface, config_params->log_config);
	if(ret_val != SUCCESS){
		goto ret;
	}
	PRINT("DEBUG:backend open\n");
	ret_val = backend_open(logging_interface);
	PRINT("Backend open failed1\n");
	if (ret_val != SUCCESS) {
		PRINT("Backend open failed\n");
		ret_val = BE_ERR_BE_OPEN_FAIL;
		goto ret;
	}
ret:
	return ret_val;
}

int load_log_config(st_logger *logger, st_log_config* config)
{
	int  ret_val = SUCCESS;

	if((logger->log_sink == LOG_SINK_CONSOLE) ||
		 (logger->log_sink == LOG_SINK_FILE)) {
		  ret_val = lib_logging_load(logger,config);
	}
	else{
		PRINT("Unsupported Log sink\n");
		ret_val = LOG_ERR_INVALID_LOGSINK_PARAM;
	}
	return ret_val;
}

/*
 * @lib_logging_load: Loading of Backend function to open shared lib.
 * @param: logger	   Parameters of Config structure
 * @return_value:	   0 on success, error code on failure
 */
int lib_logging_load(st_logger *logger,st_log_config *config)
{
	int  ret_val = SUCCESS;
	char *error = NULL;
	
	if((logger == NULL) || ( config == NULL)){
		ret_val = BE_ERR_BE_NULL_PARAM;
		goto end;
	}
	log_fcn = NULL;

	PRINT("backload entry\n");
	PRINT("DEBUG: logger\n");
	error = dlerror();

	logger->backendhandle = dlopen(LOG_LIBRARY_NAME, RTLD_NOW);
	error = dlerror(); 
	if (error != NULL) {
		PRINT("Error in dlopen - %s\n", error);
		ret_val = BE_ERR_DL_OPEN_FAIL;
		goto end;
	}
	logger->params = (st_log_config*)malloc(sizeof(st_log_config));
	memset(logger->params,0x00,sizeof(st_log_config));
	memcpy(logger->params, config, sizeof(st_log_config));

	logger->beops = (st_backend_ops*)malloc(sizeof(st_backend_ops));
	memset(logger->beops,0x00,sizeof(st_backend_ops));

	PRINT("DEBUG: log_init\n");
	error = dlerror();

	logger->beops->open = dlsym(logger->backendhandle, LOG_INIT);
	error = dlerror();
	if (error != NULL) {
		PRINT("dlsym Failed:%s\n", error);
		ret_val = BE_ERR_LOG_INIT_DL_SYM_FAIL;
		goto end;
	}

	PRINT("DEBUG: log_deinit\n");
	logger->beops->close = dlsym(logger->backendhandle, LOG_DEINIT);
	error = dlerror();
	if (error != NULL) {
		PRINT("dlsym Failed:%s\n", error);
		ret_val = BE_ERR_LOG_DEINIT_DL_SYM_FAIL;
		goto end;
	}

	PRINT("DEBUG: log_processing\n");
	log_fcn = dlsym(logger->backendhandle, LOG_API);
	error = dlerror();
	if (error != NULL) {
		PRINT("dlsym Failed:%s\n", error);
		ret_val = BE_ERR_LOG_PROCESS_DL_SYM_FAIL;
		goto end;
	}

end:
	PRINT("DEBUG:lib_logging_load end");
	return ret_val;
}

/*
 * @lib_logging_unload: Backend Unload function to Close shared lib.
 * @param: logger	   Parameters of Config structure
 * @return_value:	   0 on success, error code on failure
 */
int lib_logging_unload(st_logger *logger)
{
	
	int ret_val = SUCCESS;
	char *error = NULL;

	if ((logger == NULL) || (logger->params== NULL) || (logger->beops== NULL)) {
		ret_val = BE_ERR_BE_NULL_PARAM;
		goto ret;
	}

	LOG_PRINT(DEBUG,"DEBUG: calling Backend Close\n");
	ret_val = backend_close(logger);
	if (ret_val != SUCCESS) {
		PRINT("Backend Close Failed\n");
		ret_val = BE_ERR_BE_CLOSE_FAIL;
		goto ret;
	}

	error = dlerror();

	PRINT("DEBUG: calling dlclose\n");
	ret_val = dlclose(logger->backendhandle);
	error = dlerror();
	if (error != NULL) {
		PRINT("dlclose Failed: %s\n", error);
		ret_val = BE_ERR_DL_CLOSE_FAIL;
		goto ret;
	}

ret:
	return ret_val;
}


/*
 * @backend_open:   This function calls log_init function in shared lib
 * @param: logger	   Parameters of Config structure
 * @return_value:	   0 on success, error code on failure
 */
int backend_open(void *logger)
{
	PRINT("DEBUG:Backend open\n");
	int ret_val = SUCCESS;
	st_logger *log = (st_logger *)logger;
	if((log == NULL) || ( log->beops == NULL) || ( log->beops->open == NULL) || (log->params == NULL))
	{	PRINT("ERROR:NULL pointer\n");
		ret_val = BE_ERR_BE_NULL_PARAM;
		goto end;
	}
	ret_val = log->beops->open(log->params);

	if (ret_val != SUCCESS) {
		PRINT("Backend Open Failed\n");
		ret_val = BE_ERR_BE_OPEN_FAIL;
	}
end:
	PRINT("DEBUG:Backend open end\n");
	return ret_val;
}


/*
 * @backend_close:   This function calls log_deinit function in shared lib
 * @param: logger	   void
 * @return_value:	   0 on success, error code on failure
 */
int backend_close(st_logger *logger)
{
	
	int ret_val = SUCCESS;
	ret_val = logger->beops->close();
	if (ret_val != SUCCESS) {
		PRINT("Backend Close Failed\n");
		ret_val = BE_ERR_BE_CLOSE_FAIL;
	}

	
	return ret_val;
}

int logger_deinit(st_logger* logger){
	int ret_val = SUCCESS;
	if(logger == NULL){
		ret_val = BE_ERR_BE_NULL_PARAM;
		goto ret;
	}
	lib_logging_unload(logger);
	if(logger->beops)
		free(logger->beops);
	if(logger->params)
		free(logger->params);
	if(logger)
		free(logger);
ret:
	return ret_val;
}