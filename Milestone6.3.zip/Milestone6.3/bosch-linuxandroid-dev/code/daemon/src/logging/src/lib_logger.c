/**

  * @file	   lib_logger.c

  * @brief	  Shared Lib for Logging Module.

  *

  * @author	 external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#include <time.h>
#include "../../common/inc/error.h"
#include "../inc/loggerDaemon.h"
#include "../inc/logger_internal.h"
#include "../../common/inc/get_config_info.h"
#include "../../common/inc/definations.h"


static int recent_log_sink = LOG_SINK_CONSOLE;	 // 0: Console,  1: File
static FILE *logfp = NULL;
static st_log_config logger;
/*
 * log_init: Opening of Log File
 * @param: logFilelogger	Config Parameters
 * @return_value: 0 on success, errorcode on failure
 */
int log_init(void *logFilelogger)
{
	int ret_val = SUCCESS;

	/* Error Check of Parameters */
	if (logFilelogger == NULL) {
		//PRINT("Invalid Parameters\n");
		ret_val = LOG_ERR_LOG_INIT_INVALID_PARAM;
		goto ret;
	}
	memcpy(&logger, logFilelogger, sizeof(st_log_config));
	if ((logger.path == NULL) || (logger.log_sink < 0)){
		//PRINT("Invalid Parameters\n");
		ret_val = LOG_ERR_LOG_INIT_INVALID_PARAM;
		goto ret;
	}
	logfp = stdout;
	/* Get Process ID */
	logger.pid = getpid();
	if (logger.log_sink == LOG_SINK_FILE) {
		ret_val = log_get_file_fp();
		recent_log_sink = LOG_SINK_FILE;
	} else {
		/* Console Case */
		logfp = stdout;
		recent_log_sink = LOG_SINK_CONSOLE;
	}

ret:

	return ret_val;
}


/*
 * log_update_logsink: Function to update log sink to console/File 
 * @param: log_sink_param		Console/File
 * @return_value: 0 on success, errorcode on failure
 */
int log_update_logsink(int log_sink_param)
{
	
	int ret_val = SUCCESS;

	if (log_sink_param == LOG_SINK_FILE) {
		if (recent_log_sink != LOG_SINK_FILE) {
			log_get_file_fp();
			recent_log_sink = LOG_SINK_FILE;
		}
	} else if (log_sink_param ==LOG_SINK_CONSOLE) {
		if (recent_log_sink != LOG_SINK_CONSOLE) {
			logfp = stdout;
			recent_log_sink = LOG_SINK_CONSOLE;
		}
	} else {
		PRINT("Invalid log_sink_param \n");
		ret_val = LOG_ERR_INVALID_LOGSINK_PARAM;
	}

	
	return ret_val;
}


/*
 * log_deinit: Closing of Log File
 * @param: void
 * @return_value: 0 on success, errorcode on failure
 */
int log_deinit(void)
{
	
	int ret_val = SUCCESS;

	/*If Recent Log Sink is File*/
	if (recent_log_sink == LOG_SINK_FILE) {
		fclose(logfp);
	}
	
	
	return ret_val;
}


/*
 * log_processing: PRINTs Logs in the File/Console
 * @param: level	Log Level
 * @param: fmt		Format
 * @param: ...		variable list of arguments
 * @return_value: void
 */
void log_processing(int level, int enable_extra_feature, int tid,char const *file_name, unsigned int line_no, const char *fmt, ...)
{
	
	va_list arg;
	int no_of_chars_PRINTed = 0;
	long long ms;
	struct timeval te;
	time_t timestamp = time(NULL);

	if (fmt == NULL) {
		PRINT("Invalid Log File logger\n");
		goto ret;
	}
	
	/* Default Log Level is ERROR Level */
	if ((level > ERROR) || (level < DEBUG)) {
		level = ERROR;
	}

	/* If Log Sink is File */
	if (recent_log_sink == LOG_SINK_FILE) {
		if (logger.file_size > FILE_MAX_LIMIT) {
			fclose(logfp);
			logfp = fopen(logger.path, "r+");
	
			logger.file_size = 0;
		}
	}
	if (level >= logger.log_level) {
		
		va_start(arg, fmt);
		if (enable_extra_feature == DEBUG_FEATURE_ENABLE) {
			gettimeofday(&te,NULL);
			ms=te.tv_usec/1000;
			//no_of_chars_PRINTed += fprintf(logfp, "[%.19s:%.3lld] [PID: %d] @%s (Line %u): ",ctime(&timestamp),ms,logger.pid, file_name, line_no);
		}

		if(ENABLE_TIMESTAMP == (enable_extra_feature & ENABLE_TIMESTAMP)) {
			fprintf(logfp,"[%.19s:%.3lld]",ctime(&timestamp),ms);
		}
		if(ENABLE_PID == (enable_extra_feature & ENABLE_PID)) {
			fprintf(logfp,"[PID:%d]",logger.pid);
		}
		if( ENABLE_TID == (enable_extra_feature & ENABLE_TID)) {
			fprintf(logfp,"[TID:%d]",tid);
		}
		if(ENABLE_FILENAME == (enable_extra_feature & ENABLE_FILENAME)) {
			fprintf(logfp,"@%s",file_name);
		}
		if(ENABLE_LINENUM == (enable_extra_feature & ENABLE_LINENUM)) {
			fprintf(logfp,":%u ::",line_no);
		}
		no_of_chars_PRINTed += vfprintf(logfp, fmt, arg);
		va_end(arg);

		/* If Log Sink is File */
		if (recent_log_sink == LOG_SINK_FILE) {
			logger.file_size = logger.file_size + no_of_chars_PRINTed;
			fflush(logfp);
		}
	}

ret:
	return ;
}

/*
 * log_get_file_fp: get Log File Poiter
 * @param: void
 * @return_value: 0 on success, errorcode on failure
 */
int log_get_file_fp(void)
{
		FILE *logfptemp = NULL;
		int ret_val = SUCCESS;
		/*File Case */
		ret_val = access(logger.path, F_OK);

		if (ret_val == SUCCESS) {
			/*File is Present and Hence Opened Log file in append mode*/
			logfptemp = fopen(logger.path, "a");
			if (logfptemp  == NULL) {
				PRINT("fopen failed\n");
				ret_val = LOG_ERR_FOPEN_FAIL;
			} else {
				logfp = logfptemp;
				logger.file_size = ftell(logfp);
			}
		} else {
			/*Opened Log file in write mode*/
			logfptemp  = fopen(logger.path, "w+");
			if (logfptemp  == NULL) {
				PRINT("fopen failed\n");
				ret_val = LOG_ERR_FOPEN_FAIL;
			} else {
				logfp = logfptemp ;
				ret_val = SUCCESS;
			}
		}

				
		return ret_val;
}