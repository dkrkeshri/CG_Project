/**

  * @file       loggerDaemon.h

  * @brief      Logging Module Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#ifndef _LOGGERDAEMON_H_
#define _LOGGERDAEMON_H_

/****************************************************************************
 * HEADER FILES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/types.h>
#include <dlfcn.h>
/****************************************************************************
 * MACROS
 ****************************************************************************/
#define DEBUG               		1
#define INFO                		2
#define WARN                		3
#define ERROR               		4

#define LOG_LIBRARY_NAME "lib-logger.so"
#define LOG_INIT "log_init"
#define LOG_DEINIT "log_deinit"
#define LOG_API "log_processing"

#define FUNC_DEBUG  0
#define ENABLE_PID  			    0x01
#define ENABLE_LINENUM            	0x02
#define ENABLE_TIMESTAMP 		    0x04
#define ENABLE_FILENAME	        	0x08
#define ENABLE_TID 					0x10
#define ENABLE_TIMESTAMP_AND_FILENAME	(ENABLE_TIMESTAMP|ENABLE_PID|ENABLE_FILENAME|ENABLE_LINENUM|ENABLE_TID  )	//0: Disable    1: Enable
#define DEBUG_FEATURE_ENABLE		0	//0: Disable	1: Enable
#define LOG_CONSOLE			1 	// 0: Console,  1: File
#define LOG_ADD_DEBUG_LINE(value)			printf("%s %d %d\n",__func__,__LINE__,value)

#define LOG_PRINT(level, fmt, ...)	\
	if(log_fcn != NULL) \
		log_fcn(level, ENABLE_TIMESTAMP_AND_FILENAME,gettid(), __FILE__, __LINE__, fmt, ##__VA_ARGS__)
//#define LOG_PRINT(level, fmt, ...)	printf(fmt, ##__VA_ARGS__)
#define PRINT_HELP(fmt, ...)		printf(fmt, ##__VA_ARGS__)

FILE *log_fp;
#define PRINT_OPEN(FP){\
if(LOG_CONSOLE!=0)\
FP=fopen("../../output.txt","a");}

#define PRINT_CLOSE(FP){\
if(LOG_CONSOLE!=0)\
if(FP) \
fclose(FP);}

#define PRINT(fmt,...){\
if(LOG_CONSOLE==0)\
log_fp = stdout;\
fprintf(log_fp,fmt " %s %d\n", ##__VA_ARGS__, __FILE__,__LINE__);\
fflush(log_fp);}


#if FUNC_DEBUG
#define FUNCTION_START() log_fcn(INFO,ENABLE_TIMESTAMP_AND_FILENAME,gettid(), __FILE__, __LINE__,"%s start\n",__func__);
#define FUNCTION_END(errorCode) log_fcn(INFO,ENABLE_TIMESTAMP_AND_FILENAME,gettid(), __FILE__, __LINE__,"%s returns %d\n",__func__,errorCode);
#else
#define FUNCTION_START() //not supported
#define FUNCTION_END(erroCode) //not supported
#endif
 
/****************************************************************************
 * STRUCTURE DECLARATION
 ****************************************************************************/

typedef struct backend_ops {
    int (*open)(void *params);
    int (*close)(void);
}st_backend_ops;

typedef struct logger {
	int log_sink;
	void *params; /*st_log_config */
	void *backendhandle;
	st_backend_ops *beops;
}st_logger;

/****************************************************************************
 * FUNCTION  PROTOTYPES
 ****************************************************************************/
void (*log_fcn)(int level, int enable_extra_feature, int tid, char const *file_name, unsigned int line_no, const char *fmt, ...);

#endif /* _LOGGERDAEMON_H_ */
