/**

  * @file       logger_internal.h

  * @brief      Logging Module Header File.

  *

  * @author     external.NitishReddy.Chappidi@in.bosch.com

  *

  * @copyright (c) 2021 Robert Bosch GmbH, Hildesheim

  */ 

#ifndef _LOGGER_INTERNAL_H_
#define _LOGGER_INTERNAL_H_

#define BUF_SIZE			256
#define DEFAULT_LOG_LVL_IS_ERROR_LVL  	4
#define FILE_MAX_LIMIT      		2000000 /*No. of Bytes for 2MB*/

typedef struct log_config {
    char path[BUF_SIZE];
    int log_sink;
    int  log_level;
    int  file_size;
    int  pid;
}st_log_config;

int log_init(void *logFileParams);
int log_update_logsink(int log_sink_param);
int log_deinit(void);
void log_processing(int level, int enable_extra_feature,int tid, char const *file_name, unsigned int line_no, const char *fmt, ...);
int log_get_file_fp(void);

#endif /* _LOGGER_INTERNAL_H_ */
