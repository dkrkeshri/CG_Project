/**

  * @file       backend.h

  * @brief      Backend Header File.

  *

  * @author     external.Veerendra.Kamsali@in.bosch.com

  *

  * @copyright (c) 2022 Robert Bosch GmbH, Hildesheim

  */ 
#ifndef __BACKEND__
#define __BACKEND__
/****************************************************************************
 * FUNCTION  PROTOTYPES
 ****************************************************************************/
int logger_init(st_config_params *config_params,st_logger *logging_interface);
int load_log_config(st_logger *logger, st_log_config* config);
int  lib_logging_load(st_logger *params,st_log_config *config);
int  lib_logging_unload(st_logger *params);
int  backend_open(void *params);
int  backend_close(st_logger *params);
int logger_deinit(st_logger* logger);
#endif /*__BACKEND__ */