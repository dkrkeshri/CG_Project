#/bin/.sh

aclocal
autoconf
autoscan

autoreconf -i


libtoolize --automake
automake --add-missing

GTEST_EXCLUDE="--exclude=gtest"
if [ "$1" == "$GTEST_EXCLUDE" ]; then
	./configure --prefix=$PWD/out GTEST=0
else
	./configure --prefix=$PWD/out GTEST=1
fi
make
make install
